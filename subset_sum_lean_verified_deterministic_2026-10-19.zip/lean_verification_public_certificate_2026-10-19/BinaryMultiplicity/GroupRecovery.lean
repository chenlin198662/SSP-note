import BinaryMultiplicity.RecoveryWork
import BinaryMultiplicity.AllocateWork
import BinaryMultiplicity.SparseMerge

namespace BinaryMultiplicity.Recovery
open Optss

def rowSum (rows : List (Entry×List Bool)) : ℤ :=
  (rows.map (fun x => (binaryDigitsValue x.2:ℤ)*x.1.value)).sum

theorem rowSum_constant (rows : List (Entry×List Bool)) (w : ℤ)
    (hw : ∀x∈rows,x.1.value=w) : rowSum rows=(SumTree.sumWords rows:ℤ)*w := by
  induction rows with
  | nil => simp [rowSum,SumTree.sumWords]
  | cons x xs ih =>
    have hh := hw x List.mem_cons_self
    have ht := ih (fun y hy => hw y (List.mem_cons_of_mem _ hy))
    simp only [rowSum,SumTree.sumWords,List.map_cons,List.sum_cons,Nat.cast_add] at *
    rw [hh,ht]
    ring

def recoverOne (group : Merged) (count : List Bool) : List (Entry×List Bool) :=
  match group.tree with
  | none => []
  | some tree => tree.allocate count

def recoverOneWork (group : Merged) (count : List Bool) : ℕ :=
  match group.tree with
  | none => 4
  | some tree => tree.allocateWork count+4

theorem paired_mem {α β : Type*} {R : α→β→Prop} {xs : List α} {ys : List β}
    (h : List.Forall₂ R xs ys) {b : β} (hb : b∈ys) : ∃a∈xs,R a b := by
  induction h with
  | nil => simp at hb
  | cons hab ht ih =>
    rcases List.mem_cons.mp hb with rfl | hb
    · exact ⟨_,List.mem_cons_self,hab⟩
    · obtain ⟨a,ha,hr⟩ := ih hb
      exact ⟨a,List.mem_cons_of_mem _ ha,hr⟩

/-- A cached balanced group tree reconstructs individual record counts in
the original order within that group, with exact total selected multiplicity. -/
theorem recoverOne_spec (g : List Entry) (hg : g≠[]) (count : List Bool)
    (hc : binaryDigitsValue count ≤ (mergedEntry g).capacity) :
    (recoverOne (mergeGroup g).1 count).map Prod.fst=g ∧
      (∀x∈recoverOne (mergeGroup g).1 count,binaryDigitsValue x.2 ≤ x.1.capacity) ∧
      SumTree.sumWords (recoverOne (mergeGroup g).1 count)=binaryDigitsValue count := by
  cases ht : (SumTree.build (g.map (fun x => (x,x.count)))).1 with
  | none =>
    have he := (SumTree.build_none (g.map (fun x => (x,x.count)))).mp ht
    have hz : g=[] := List.map_eq_nil_iff.mp he
    exact (hg hz).elim
  | some tree =>
    have hs := SumTree.build_spec (g.map (fun x => (x,x.count))) tree ht
    have hb : binaryDigitsValue count ≤ binaryDigitsValue tree.word := by
      simpa only [mergedEntry,mergeGroup,ht,Entry.capacity] using hc
    have ha := SumTree.allocate_spec tree hs.2.1 count hb
    have ho := ha.1.order
    rw [hs.1] at ho
    simp only [List.map_map,Function.comp_def,List.map_id] at ho
    simp only [recoverOne,mergeGroup,ht]
    refine ⟨by simpa using ho,?_,ha.2⟩
    intro x hx
    have hrel := ha.1
    rw [hs.1] at hrel
    have hm : ∃y∈g.map (fun x => (x,x.count)), y.1=x.1 ∧ binaryDigitsValue x.2 ≤ binaryDigitsValue y.2 :=
      paired_mem hrel hx
    obtain ⟨y,hy,he,hb⟩ := hm
    obtain ⟨z,hz,rfl⟩ := List.mem_map.mp hy
    rw [←he]
    exact hb

theorem recoverOne_sum (g : List Entry) (hg : g≠[]) (count : List Bool)
    (hc : binaryDigitsValue count ≤ (mergedEntry g).capacity)
    (hw : ∀x∈g,x.value=(mergedEntry g).value) :
    rowSum (recoverOne (mergeGroup g).1 count)=
      (binaryDigitsValue count:ℤ)*(mergedEntry g).value := by
  have hs := recoverOne_spec g hg count hc
  rw [rowSum_constant _ _ (by
    intro x hx
    apply hw
    rw [←hs.1]
    exact List.mem_map.mpr ⟨x,hx,rfl⟩),hs.2.2]

end BinaryMultiplicity.Recovery
