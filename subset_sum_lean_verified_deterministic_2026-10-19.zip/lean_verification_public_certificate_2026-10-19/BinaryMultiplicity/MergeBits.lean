import BinaryMultiplicity.SparseMergeWork
import BinaryMultiplicity.TreeWidths

namespace BinaryMultiplicity
open Optss

theorem normalize_bits (x : Entry) : x.normalize.bits ≤ x.bits := by
  have hw : (x.normalize.weight).digits=bitListTrim x.weight.digits := by
    cases h : bitListTrim x.weight.digits <;>
      simp [Entry.normalize,Entry.normalizeWeight,ConvolutionDraft.CanonicalOutput.normalize,h]
  have h1 := bitListTrim_length_le x.weight.digits
  have h2 := bitListTrim_length_le x.count
  simp only [Entry.bits,Entry.normalize,hw]
  change (Entry.normalizeWeight x.weight).digits.length+(bitListTrim x.count).length+2 ≤ _
  change (Entry.normalizeWeight x.weight).digits=bitListTrim x.weight.digits at hw
  rw [hw]
  omega

theorem normalized_bits (xs : List Entry) : inputSize (normalized xs) ≤ inputSize xs := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
      have h := normalize_bits x
      simp only [inputSize,normalized,List.map_cons,List.sum_cons] at *
      omega

theorem merged_count_length (g : List Entry) : (mergedEntry g).count.length ≤ countBits g+g.length := by
  cases ht : (SumTree.build (g.map (fun x => (x,x.count)))).1 with
  | none => simp [mergedEntry,mergeGroup,ht]
  | some tree =>
      have h := SumTree.allWidths_root _ tree (SumTree.build_allWidths _ tree ht)
      simpa [mergedEntry,mergeGroup,ht,SumTree.inputBits,countBits,List.map_map,Function.comp_def] using h

theorem inputSize_eq (g : List Entry) :
    inputSize g=(g.map (fun x => x.weight.digits.length)).sum+countBits g+2*g.length := by
  induction g with
  | nil => rfl
  | cons x xs ih =>
      simp only [inputSize,countBits,Entry.bits,List.map_cons,List.sum_cons,List.length_cons] at *
      omega

theorem mergedEntry_bits (g : List Entry) (hg : g≠[]) :
    (mergedEntry g).bits ≤ inputSize g+g.length := by
  have hc := merged_count_length g
  have hm : g.headD zeroEntry∈g := by cases g <;> simp_all
  have hh : (g.headD zeroEntry).weight.digits.length ≤ (g.map (fun x => x.weight.digits.length)).sum :=
    List.single_le_sum (fun n _ => Nat.zero_le n) (g.headD zeroEntry).weight.digits.length
      (List.mem_map.mpr ⟨g.headD zeroEntry,hm,rfl⟩)
  have hs := inputSize_eq g
  have hp : 0<g.length := List.length_pos_iff.mpr hg
  have hw : (mergedEntry g).weight=(g.headD zeroEntry).weight := rfl
  simp only [Entry.bits,hw]
  omega

theorem inputSize_flatten (gs : List (List Entry)) :
    inputSize gs.flatten=(gs.map inputSize).sum := by
  induction gs with
  | nil => rfl
  | cons g gs ih =>
      simpa [inputSize,List.map_append,List.sum_append] using congrArg (fun n => inputSize g+n) ih

theorem sum_mergedEntry_bits (gs : List (List Entry)) (h : ∀g∈gs,g≠[]) :
    (gs.map (fun g => (mergedEntry g).bits)).sum ≤ (gs.map inputSize).sum+(gs.map List.length).sum := by
  induction gs with
  | nil => rfl
  | cons g gs ih =>
      have hg := mergedEntry_bits g (h g List.mem_cons_self)
      have ht := ih (fun a ha => h a (List.mem_cons_of_mem _ ha))
      simp only [List.map_cons,List.sum_cons]
      omega

theorem merged_bits (xs : List Entry) : inputSize (merged xs) ≤ inputSize xs+xs.length := by
  rw [merged_eq,inputSize,List.map_map]
  have hsum : (((grouped xs).map (fun g => (mergedEntry g).bits)).sum) ≤
      ((grouped xs).map inputSize).sum+((grouped xs).map List.length).sum := by
    exact sum_mergedEntry_bits _ (Trie.groups_nonempty _)
  have he := ((grouped_partition xs).map Entry.bits).sum_eq
  change inputSize (grouped xs).flatten=inputSize (normalized xs) at he
  rw [inputSize_flatten] at he
  rw [he,grouped_lengths xs] at hsum
  exact hsum.trans (Nat.add_le_add_right (normalized_bits xs) _)

end BinaryMultiplicity
