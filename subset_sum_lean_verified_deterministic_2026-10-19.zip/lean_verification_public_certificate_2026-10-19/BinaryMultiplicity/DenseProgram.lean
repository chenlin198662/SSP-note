import BinaryMultiplicity.ReducedBounds
import SubsetSum.CostedCappedHistogram
import SubsetSum.ScalarInitialState

namespace BinaryMultiplicity.Dense
open Optss SubsetSum SubsetSum.CostedArrayProgram SubsetSum.ExternalCostContracts

def pairs (N : ℕ) (xs : List Entry) : List (ℕ×ℕ) :=
  xs.map (fun x => (ScalarHistogramArray.index N x.value,x.capacity))

def row (N : ℕ) (values counts : Array ℤ) (i : ℕ) : Program (ℕ×ℕ) := do
  let a ← call (.read values i)
  let c ← call (.read counts i)
  let j ← call (.add a (N:ℤ))
  pure (j.toNat,c.toNat)

/-- Materialize the bounded residual words once, then use the already
charged capped histogram. The allocation is made only after sparse reduction. -/
def run (N : ℕ) (xs : List Entry) : Program (Array ℤ) := do
  let values ← call (.fromList (xs.map Entry.value))
  let counts ← call (.fromList (xs.map (fun x => (x.capacity:ℤ))))
  let addressed ← mapM (fun i : Fin xs.length => row N values counts i.val) (List.finRange xs.length)
  let K ← call (.natMultiply 2 N)
  let V ← CostedBoxIndex.natAdd K 1
  CostedCappedHistogram.run V K addressed

theorem row_value (F : ExactIntegerConvolution) (N : ℕ) (xs : List Entry) (i : Fin xs.length) :
    (row N (xs.map Entry.value).toArray (xs.map (fun x => (x.capacity:ℤ))).toArray i.val).value F=
      (ScalarHistogramArray.index N (xs.get i).value,(xs.get i).capacity) := by
  simp [row,bind,pure,Program.value_bind,Program.value_pure,call,Program.value,Op.value,
    ScalarHistogramArray.index,List.getElem?_map,List.getElem?_eq_getElem]

theorem run_value (F : ExactIntegerConvolution) (N : ℕ) (xs : List Entry) :
    (run N xs).value F=CostedCappedHistogram.histogram (2*N+1) (2*N) (pairs N xs) := by
  simp only [run,bind,Program.value_bind,call,Program.value,Op.value]
  have he : (mapM (fun i : Fin xs.length =>
      row N (xs.map Entry.value).toArray (xs.map (fun x => (x.capacity:ℤ))).toArray i.val)
      (List.finRange xs.length)).value F=pairs N xs := by
    rw [mapM_value]
    simp only [row_value]
    rw [←List.ofFn_eq_map]
    simpa only [pairs,List.get_eq_getElem] using
      List.ofFn_getElem_eq_map xs (fun x => (ScalarHistogramArray.index N x.value,x.capacity))
  rw [he,CostedBoxIndex.natAdd_value,CostedCappedHistogram.run_value]

theorem run_bounded (F : ExactIntegerConvolution) (N : ℕ) (xs : List Entry) :
    CostedDenseArray.Bounded ((run N xs).value F) (2*N+1) (2*N).size := by
  rw [run_value]
  exact CostedCappedHistogram.capped_bounded _ _ _
    (CostedCappedHistogram.histogram_size _ _ _) (CostedCappedHistogram.histogram_capped _ _ _)

theorem run_capacity (F : ExactIntegerConvolution) (N : ℕ) (xs : List Entry)
    (z : ScalarTypeCompression.SignedType N) :
    (((run N xs).value F)[ScalarHistogramArray.index N z.val]?.getD 0).toNat=
      min (2*N) (CostedCappedHistogram.weight (pairs N xs) (ScalarHistogramArray.index N z.val)) := by
  rw [run_value]
  have h := CostedCappedHistogram.histogram_get (2*N+1) (2*N) (pairs N xs)
    (ScalarHistogramArray.index N z.val) (ScalarHistogramArray.index_lt N z.val
      (ScalarTypeCompression.type_bounds N z))
  dsimp only [CostedCappedHistogram.read] at h
  rw [h]
  exact Int.toNat_natCast _

theorem run_mass (F : ExactIntegerConvolution) (N : ℕ) (xs : List Entry) :
    (∑i,CostedScalarTypes.capacity N ((run N xs).value F) i) ≤ 4*N^2 := by
  have hb : ∀i:Fin (2*N),CostedScalarTypes.capacity N ((run N xs).value F) i ≤ 2*N := by
    intro i
    have hc := CostedCappedHistogram.histogram_capped (2*N+1) (2*N) (pairs N xs)
      (ScalarHistogramArray.index N (ScalarTypeIndex.value N i))
    rw [CostedScalarTypes.capacity,run_value]
    dsimp only [CostedCappedHistogram.read] at hc
    omega
  calc
    _ ≤ ∑_i:Fin (2*N),2*N := Finset.sum_le_sum (fun i _ => hb i)
    _ = _ := by simp; ring

end BinaryMultiplicity.Dense
