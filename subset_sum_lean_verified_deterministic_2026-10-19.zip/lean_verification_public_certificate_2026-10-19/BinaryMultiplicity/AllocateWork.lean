import BinaryMultiplicity.Allocate
import BinaryMultiplicity.TreeResource

namespace BinaryMultiplicity.SumTree
open Optss
variable {α : Type}

/-- All reconstruction subtractions remain local to a capacity subtree.
The sum of their widths is bounded by input width times balanced height. -/
theorem allocateWork_bound (tree : SumTree α) (hv : tree.Valid)
    (hc : tree.AllCanonical) (hr : tree.LocalResource) (target : List Bool)
    (ht : BitListCanonical target) (hq : binaryDigitsValue target≤binaryDigitsValue tree.word) :
    allocateWork tree target ≤ 64*(tree.height+1)*tree.resource := by
  induction tree generalizing target with
  | leaf a w =>
      have hw := canonical_target_width (.leaf a w) hc target ht hq
      have hres := localResource_root (.leaf a w) hr
      simp only [allocateWork,bitListTrimVisits_eq,height,word] at *
      nlinarith
  | node w l r il ir =>
      obtain ⟨hvl,hvr,he⟩ := hv
      obtain ⟨hcw,hcl,hcr⟩ := hc
      obtain ⟨hrw,hrl,hrr⟩ := hr
      have hlr := localResource_root l hrl
      have hrr' := localResource_root r hrr
      have hlpos : 1≤l.resource := by omega
      have hrpos : 1≤r.resource := by omega
      have htarget := canonical_target_width (.node w l r) ⟨hcw,hcl,hcr⟩ target ht hq
      have hB : target.length≤l.resource+r.resource := by
        rw [resource_node] at hrw
        change target.length≤w.length at htarget
        omega
      have hlB : l.word.length≤l.resource+r.resource := by omega
      have hcmp := compareWork_bound target l.word _ hB hlB
      have hsub := subtractWork_bound target l.word _ hB hlB
      have hlen : l.entries.length≤l.resource := Nat.le_add_left _ _
      have hheightl : l.height ≤ max l.height r.height := le_max_left _ _
      have hheightr : r.height ≤ max l.height r.height := le_max_right _ _
      have hmL := Nat.mul_le_mul_right l.resource (Nat.mul_le_mul_left 64
        (Nat.add_le_add_right hheightl 1))
      have hmR := Nat.mul_le_mul_right r.resource (Nat.mul_le_mul_left 64
        (Nat.add_le_add_right hheightr 1))
      by_cases hbranch : bitListLE l.word target=true
      · have hle := (bitListLE_correct _ _).mp hbranch
        have hs : binaryDigitsValue (bitListTrim (bitListSub target l.word))=
            binaryDigitsValue target-binaryDigitsValue l.word := by
          rw [bitListTrim_value,bitListSub_correct]
        have hq' : binaryDigitsValue (bitListTrim (bitListSub target l.word))≤binaryDigitsValue r.word := by
          change binaryDigitsValue target≤binaryDigitsValue w at hq
          rw [hs]; omega
        have hL := il hvl hcl hrl l.word (allCanonical_root l hcl) (le_refl _)
        have hR := ir hvr hcr hrr _ (bitListTrim_canonical _) hq'
        simp only [allocateWork,if_pos hbranch,height,resource_node]
        nlinarith only [hcmp,hsub,hlen,hL,hR,hmL,hmR,hlpos,hrpos]
      · have hlt : binaryDigitsValue target<binaryDigitsValue l.word := by
          have hn : ¬binaryDigitsValue l.word≤binaryDigitsValue target :=
            fun h => hbranch ((bitListLE_correct _ _).mpr h)
          omega
        have hL := il hvl hcl hrl target ht hlt.le
        have hR := ir hvr hcr hrr [] (bitListTrim_canonical []) (by simp [binaryDigitsValue])
        simp only [allocateWork,if_neg hbranch,height,resource_node]
        nlinarith only [hcmp,hlen,hL,hR,hmL,hmR,hlpos,hrpos]

theorem built_allocateWork (xs : List (α × List Bool)) (tree : SumTree α)
    (hbuild : (build xs).1=some tree) (hc : ∀x∈xs,BitListCanonical x.2)
    (target : List Bool) (ht : BitListCanonical target)
    (hq : binaryDigitsValue target≤binaryDigitsValue tree.word) :
    allocateWork tree target ≤ 64*(xs.length.size+1)*(inputBits xs+xs.length) := by
  obtain ⟨he,hv,hh⟩ := build_spec xs tree hbuild
  have h := allocateWork_bound tree hv (build_allCanonical xs tree hbuild hc)
    (build_localResource xs tree hbuild) target ht hq
  have hr : tree.resource=inputBits xs+xs.length := by simp only [resource,he]
  rw [hr] at h
  exact h.trans (Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 64 (Nat.add_le_add_right hh 1)))

end BinaryMultiplicity.SumTree
