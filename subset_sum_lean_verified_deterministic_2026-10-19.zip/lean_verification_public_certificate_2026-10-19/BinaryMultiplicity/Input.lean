import BinaryMultiplicity.TrieGroups
import ConvolutionDraft.CanonicalOutput

namespace BinaryMultiplicity
open Optss

/-- Binary multiplicity input is a list of records, not a list of copies.
The count field may have arbitrarily many bits. -/
structure Entry where
  weight : BitListInteger
  count : List Bool

namespace Entry
def value (x : Entry) : ℤ := x.weight.value
def capacity (x : Entry) : ℕ := binaryDigitsValue x.count
def bits (x : Entry) : ℕ := x.weight.digits.length+x.count.length+2
def key (x : Entry) : List Bool := x.weight.negative::x.weight.digits

theorem key_value (x y : Entry) (h : x.key=y.key) : x.value=y.value := by
  have hh := List.cons.inj h
  cases x with
  | mk xw xc => cases y with
    | mk yw yc => cases xw; cases yw; simp only [key,List.cons.injEq] at h; obtain ⟨rfl,rfl⟩ := h; rfl

def normalizeWeight (z : BitListInteger) : BitListInteger :=
  ConvolutionDraft.CanonicalOutput.normalize ⟨z.negative,bitListTrim z.digits⟩

theorem trimmed_value (z : BitListInteger) :
    (⟨z.negative,bitListTrim z.digits⟩ : BitListInteger).value=z.value := by
  simp only [BitListInteger.value,signedBitsValue,bitListTrim_value]

theorem normalizeWeight_value (z : BitListInteger) : (normalizeWeight z).value=z.value := by
  rw [normalizeWeight,ConvolutionDraft.CanonicalOutput.normalize_value,trimmed_value]

theorem normalizeWeight_representation (z : BitListInteger) :
    normalizeWeight z=integerBitRepresentation z.value := by
  rw [normalizeWeight,ConvolutionDraft.CanonicalOutput.normalize_representation _ (bitListTrim_canonical _),trimmed_value]

def normalize (x : Entry) : Entry := ⟨normalizeWeight x.weight,bitListTrim x.count⟩
def normalizeWork (x : Entry) : ℕ := 12*x.bits+12

theorem normalize_value (x : Entry) : x.normalize.value=x.value := normalizeWeight_value _
theorem normalize_capacity (x : Entry) : x.normalize.capacity=x.capacity := bitListTrim_value _

theorem normalize_key_iff (x y : Entry) : x.normalize.key=y.normalize.key ↔ x.value=y.value := by
  constructor
  · intro h
    simpa only [normalize_value] using key_value x.normalize y.normalize h
  · intro h
    simp only [normalize,key,normalizeWeight_representation]
    change x.weight.value=y.weight.value at h
    rw [h]

theorem normalize_key_length (x : Entry) : x.normalize.key.length ≤ x.bits := by
  have h1 := bitListTrim_length_le x.weight.digits
  have hh : (normalizeWeight x.weight).digits=bitListTrim x.weight.digits := by
    cases h : bitListTrim x.weight.digits <;>
      simp [normalizeWeight,ConvolutionDraft.CanonicalOutput.normalize,h]
  simp only [normalize,key,List.length_cons,hh,bits]
  omega

end Entry

def inputBits (xs : List Entry) (target : BitListInteger) : ℕ :=
  (xs.map Entry.bits).sum+target.digits.length+1

def normalized (xs : List Entry) : List Entry := xs.map Entry.normalize
def grouped (xs : List Entry) : List (List Entry) := Trie.groups (Trie.build Entry.key (normalized xs))

theorem grouped_partition (xs : List Entry) : (grouped xs).flatten.Perm (normalized xs) :=
  (Trie.build_groups_partition Entry.key (normalized xs)).1

theorem grouped_uniform (xs : List Entry) (g : List Entry) (hg : g∈grouped xs)
    (a b : Entry) (ha : a∈g) (hb : b∈g) : a.value=b.value :=
  Entry.key_value a b (Trie.build_groups_uniform Entry.key (normalized xs) g hg a b ha hb)

theorem normalized_keyBits (xs : List Entry) :
    Trie.keyBits Entry.key (normalized xs) ≤ (xs.map Entry.bits).sum+xs.length := by
  induction xs with
  | nil => simp [normalized,Trie.keyBits]
  | cons x xs ih =>
      have h := Entry.normalize_key_length x
      simp only [normalized,List.map_cons,Trie.keyBits,List.sum_cons,List.length_cons] at *
      omega

theorem sparse_group_work (xs : List Entry) :
    Trie.buildWork Entry.key (normalized xs)+Trie.groupsWork (Trie.build Entry.key (normalized xs)) ≤
      26*((xs.map Entry.bits).sum+xs.length)+2 := by
  have hb := Trie.buildWork_bound Entry.key (normalized xs)
  have hg := Trie.groupsWork_build Entry.key (normalized xs)
  have hl := normalized_keyBits xs
  omega

end BinaryMultiplicity
