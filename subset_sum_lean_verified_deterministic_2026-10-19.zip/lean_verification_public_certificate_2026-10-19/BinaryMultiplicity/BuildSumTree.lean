import BinaryMultiplicity.SumTree
import ConvolutionDraft.Metadata

namespace BinaryMultiplicity.SumTree
open Optss
variable {α : Type}

def initial (xs : List (α × List Bool)) : List (SumTree α) :=
  xs.map (fun x => .leaf x.1 x.2)

def build (xs : List (α × List Bool)) : Option (SumTree α) × ℕ :=
  let count := ConvolutionDraft.InputMeasure.count xs
  let depth := ConvolutionDraft.Metadata.bitLength count.1
  let trees := initial xs
  let out := rounds depth.1 trees
  (out.head?,count.2+depth.2+8*count.1+roundsWork depth.1 trees+4)

def inputBits (xs : List (α × List Bool)) : ℕ := (xs.map (fun x => x.2.length)).sum

theorem initial_entries (xs : List (α × List Bool)) : forestEntries (initial xs)=xs := by
  induction xs with
  | nil => rfl
  | cons x xs ih => simpa [initial,forestEntries,entries] using congrArg (List.cons x) ih

theorem initial_bits (xs : List (α × List Bool)) : bits (initial xs)=inputBits xs := by
  simp [initial,bits,inputBits,List.map_map,Function.comp_def,word]

theorem initial_valid (xs : List (α × List Bool)) : ∀t∈initial xs,t.Valid := by
  intro t ht
  obtain ⟨a,ha,rfl⟩ := List.mem_map.mp ht
  trivial

theorem initial_height (xs : List (α × List Bool)) : ∀t∈initial xs,t.height ≤ 0 := by
  intro t ht
  obtain ⟨a,ha,rfl⟩ := List.mem_map.mp ht
  exact le_refl _

theorem build_value (xs : List (α × List Bool)) :
    (build xs).1=(rounds xs.length.size (initial xs)).head? := by
  simp only [build,ConvolutionDraft.InputMeasure.count_value,ConvolutionDraft.Metadata.bitLength_value]

theorem build_none (xs : List (α × List Bool)) : (build xs).1=none ↔ xs=[] := by
  rw [build_value,List.head?_eq_none_iff]
  constructor
  · intro h
    have he := rounds_entries xs.length.size (initial xs)
    rw [h,initial_entries] at he
    exact he.symm
  · rintro rfl
    simp [initial,rounds]

theorem build_spec (xs : List (α × List Bool)) (out : SumTree α) (h : (build xs).1=some out) :
    out.entries=xs ∧ out.Valid ∧ out.height ≤ xs.length.size := by
  let trees := rounds xs.length.size (initial xs)
  have hlen : trees.length ≤ 1 := rounds_single _ _ (by
    simp only [initial,List.length_map]
    exact (Nat.lt_size_self _).le)
  have he : forestEntries trees=xs := (rounds_entries _ _).trans (initial_entries xs)
  have hh : trees.head?=some out := by simpa only [build_value] using h
  have hall : ∀t∈trees,t.Valid := rounds_valid _ _ (initial_valid xs)
  have hheight : ∀t∈trees,t.height ≤ xs.length.size := by
    simpa only [Nat.zero_add] using rounds_height xs.length.size (initial xs) (initial_height xs)
  cases ht : trees with
  | nil => simp [ht] at hh
  | cons t tail =>
      have heq : t=out := by simpa [ht] using hh
      have htail : tail=[] := by simp only [ht,List.length_cons] at hlen; exact List.length_eq_zero.mp (by omega)
      subst t
      have hmem : out∈trees := by simp [ht]
      refine ⟨?_,hall out hmem,hheight out hmem⟩
      simpa [ht,htail,forestEntries] using he

def total (xs : List (α × List Bool)) : List Bool :=
  match (build xs).1 with
  | none => []
  | some out => out.word

theorem total_value (xs : List (α × List Bool)) :
    binaryDigitsValue (total xs)=(xs.map (fun x => binaryDigitsValue x.2)).sum := by
  cases h : (build xs).1 with
  | none =>
      have he := (build_none xs).mp h
      subst xs
      simp [total,h,binaryDigitsValue]
  | some out =>
      obtain ⟨he,hv,_⟩ := build_spec xs out h
      simpa only [total,h,he] using word_value out hv

def buildBudget (m B : ℕ) : ℕ :=
  1+m*(2*m.size+6)+16*(m.size+3)^3+8*m+
    (1+m.size*(32*(B+m)+5))+4

theorem build_work (xs : List (α × List Bool)) :
    (build xs).2 ≤ buildBudget xs.length (inputBits xs) := by
  have hc := ConvolutionDraft.InputMeasure.count_work xs xs.length (le_refl _)
  have hd := ConvolutionDraft.Metadata.bitLength_work xs.length
  have hr := roundsWork_bound xs.length.size (initial xs)
  have hlen : (initial xs).length=xs.length := by simp [initial]
  rw [initial_bits,hlen] at hr
  simp only [build,ConvolutionDraft.InputMeasure.count_value,ConvolutionDraft.Metadata.bitLength_value]
  unfold buildBudget
  omega

end BinaryMultiplicity.SumTree
