import BinaryMultiplicity.BuildSumTree
import BinaryMultiplicity.CountSemantics

namespace BinaryMultiplicity
open Optss

structure Merged where
  entry : Entry
  tree : Option (SumTree Entry)

def zeroEntry : Entry := ⟨⟨false,[]⟩,[]⟩

def mergeGroup (g : List Entry) : Merged × ℕ :=
  let leaves := g.map (fun x => (x,x.count))
  let built := SumTree.build leaves
  let count := match built.1 with
    | none => []
    | some t => t.word
  (⟨⟨(g.headD zeroEntry).weight,count⟩,built.1⟩,built.2+4*g.length+8)

def mergedEntry (g : List Entry) : Entry := (mergeGroup g).1.entry

theorem merged_value (g : List Entry) : (mergedEntry g).value=(g.headD zeroEntry).value := rfl

theorem merged_capacity (g : List Entry) : (mergedEntry g).capacity=capacitySum g := by
  dsimp only [mergedEntry,mergeGroup,Entry.capacity]
  have h := SumTree.total_value (g.map (fun x => (x,x.count)))
  cases hb : (SumTree.build (g.map (fun x => (x,x.count)))).1 <;>
    simp only [SumTree.total,hb] at h ⊢ <;>
    exact h.trans (by rw [List.map_map]; rfl)

theorem mergeGroup_tree (g : List Entry) (hg : g≠[]) :
    ∃t,(mergeGroup g).1.tree=some t ∧ t.entries=g.map (fun x => (x,x.count)) ∧
      t.Valid ∧ t.height ≤ g.length.size := by
  have hn : (SumTree.build (g.map (fun x => (x,x.count)))).1≠none := by
    intro hnone
    have he := (SumTree.build_none _).mp hnone
    exact hg (List.map_eq_nil_iff.mp he)
  obtain ⟨t,ht⟩ := Option.ne_none_iff_exists'.mp hn
  have hs := SumTree.build_spec _ t ht
  refine ⟨t,ht,hs.1,hs.2.1,?_⟩
  simpa only [List.length_map] using hs.2.2

theorem mergeGroup_work (g : List Entry) :
    (mergeGroup g).2 ≤ SumTree.buildBudget g.length
      ((g.map (fun x => x.count.length)).sum)+4*g.length+8 := by
  have h := SumTree.build_work (g.map (fun x => (x,x.count)))
  simp only [List.length_map,SumTree.inputBits,List.map_map,Function.comp_def] at h
  exact Nat.add_le_add_right (Nat.add_le_add_right h _) _

theorem feasible_grouped_entry (xs : List Entry) (g : List Entry) (hg : g∈grouped xs) (t : ℤ) :
    Feasible g t ↔ Feasible [mergedEntry g] t := by
  apply feasible_merge_group g (mergedEntry g)
  · intro x hx
    rw [merged_value]
    have hne := Trie.groups_nonempty (Trie.build Entry.key (normalized xs)) g hg
    have hh : g.headD zeroEntry∈g := by cases g <;> simp_all
    exact grouped_uniform xs g hg x _ hx hh
  · exact merged_capacity g

def merge (xs : List Entry) : List Merged × ℕ :=
  let groups := grouped xs
  let rows := groups.map mergeGroup
  (rows.map Prod.fst,
    ((xs.map Entry.normalizeWork).sum)+
      Trie.buildWork Entry.key (normalized xs)+Trie.groupsWork (Trie.build Entry.key (normalized xs))+
      (rows.map Prod.snd).sum+4*groups.length+8)

def merged (xs : List Entry) : List Entry := (merge xs).1.map Merged.entry

theorem merged_eq (xs : List Entry) : merged xs=(grouped xs).map mergedEntry := by
  simp [merged,merge,mergedEntry,List.map_map,Function.comp_def]

theorem feasible_normalized (xs : List Entry) (t : ℤ) : Feasible (normalized xs) t ↔ Feasible xs t := by
  induction xs generalizing t with
  | nil => rfl
  | cons x xs ih =>
      simp only [normalized,List.map_cons,feasible_cons,Entry.normalize_capacity,Entry.normalize_value]
      simpa only [normalized] using (show
        (∃n ≤ x.capacity,∃s,Feasible (normalized xs) s ∧ (n:ℤ)*x.value+s=t) ↔
        (∃n ≤ x.capacity,∃s,Feasible xs s ∧ (n:ℤ)*x.value+s=t) from by simp only [ih])

theorem feasible_merge_groups (gs : List (List Entry))
    (h : ∀g∈gs,∀t,Feasible g t ↔ Feasible [mergedEntry g] t) (t : ℤ) :
    Feasible gs.flatten t ↔ Feasible (gs.map mergedEntry) t := by
  induction gs generalizing t with
  | nil => rfl
  | cons g gs ih =>
      have hg := h g List.mem_cons_self
      have ht := ih (fun x hx => h x (List.mem_cons_of_mem _ hx))
      change Feasible (g++gs.flatten) t ↔ Feasible ([mergedEntry g]++gs.map mergedEntry) t
      simp only [feasible_append,hg,ht]

/-- Exact sparse merge semantics. Normalization and grouping are literal
program outputs; no list of physical copies is constructed. -/
theorem merge_feasible (xs : List Entry) (t : ℤ) : Feasible (merged xs) t ↔ Feasible xs t := by
  rw [merged_eq]
  exact (feasible_merge_groups (grouped xs) (feasible_grouped_entry xs) t).symm.trans
    ((feasible_perm (grouped_partition xs) t).trans (feasible_normalized xs t))

end BinaryMultiplicity
