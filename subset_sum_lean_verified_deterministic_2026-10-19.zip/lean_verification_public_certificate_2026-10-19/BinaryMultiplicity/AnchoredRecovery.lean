import BinaryMultiplicity.MergedRecovery
import BinaryMultiplicity.ReducedBounds

namespace BinaryMultiplicity.Recovery
open Optss

theorem anchor_data (xs : List Entry) (tree : SumTree Entry)
    (htree : (WeightedTotals.run xs).full=some tree) (target limit : List Bool)
    (htarget : binaryDigitsValue target<WeightedTotals.total xs) :
    let out := AnchoredInstance.run tree target limit
    out.anchor.map Prod.fst=positiveEntries xs ∧
      (∀x∈out.anchor,binaryDigitsValue x.2 ≤ x.1.capacity) ∧
      (binaryDigitsValue out.pivot.residual:ℤ)+anchorValue out.anchor=(binaryDigitsValue target:ℤ) := by
  dsimp only
  obtain ⟨before,after,he,hprefix,hq,hr⟩ := Pivot.run_spec xs tree htree target htarget
  let p := Pivot.run tree target
  let raw := AnchorRows.fill tree p.path p.anchor
  have hs := WeightedTotals.full_spec xs tree htree
  have hw := AnchorRows.weightedTree_weights xs tree htree
  have htotal := WeightedTotals.full_value xs
  simp only [htree,WeightedTotals.storedWord] at htotal
  have ht : binaryDigitsValue target<binaryDigitsValue tree.word := by rwa [htotal]
  have hb : ∀x∈raw,binaryDigitsValue x.2 ≤ x.1.capacity :=
    AnchorRows.fill_bounds tree target p.anchor hq.le
  have horder : raw.map Prod.fst=xs := by
    rw [show raw=AnchorRows.fill tree p.path p.anchor from rfl,AnchorRows.fill_order,hs.1]
    simp [WeightedTotals.weightedLeaves,List.map_map,Function.comp_def]
  have hposorder : (AnchoredInstance.positiveRows raw).map Prod.fst=positiveEntries xs := by
    calc
      _=(raw.map Prod.fst).map positiveEntry := by
        simp only [AnchoredInstance.positiveRows,List.map_map]; rfl
      _=positiveEntries xs := by rw [horder]; rfl
  have hbpos : ∀x∈AnchoredInstance.positiveRows raw,binaryDigitsValue x.2 ≤ x.1.capacity := by
    intro x hx; obtain ⟨y,hy,rfl⟩ := List.mem_map.mp hx; exact hb y hy
  have hfill := AnchorRows.fill_total tree hs.2.1 hw target p.anchor ht
  have hd : 0<binaryDigitsValue (tree.descend target).payload.weight.digits := by
    change 0<WeightedTotals.magnitude p.entry
    have hr' : binaryDigitsValue p.residual<WeightedTotals.magnitude p.entry := hr
    omega
  have hdiv := bitListDivision_correct (tree.descend target).residual
    (tree.descend target).payload.weight.digits hd
  have hdivision : binaryDigitsValue p.anchor*WeightedTotals.magnitude p.entry+
      binaryDigitsValue p.residual=binaryDigitsValue (tree.descend target).residual := by
    dsimp only [p,Pivot.run,WeightedTotals.magnitude]
    rw [hdiv.1,hdiv.2]
    nlinarith only [Nat.mod_add_div (binaryDigitsValue (tree.descend target).residual)
      (binaryDigitsValue (tree.descend target).payload.weight.digits)]
  have hsum : AnchorRows.total raw+binaryDigitsValue p.residual=binaryDigitsValue target := by
    change AnchorRows.total raw+binaryDigitsValue (tree.descend target).residual=
      binaryDigitsValue target+binaryDigitsValue p.anchor*WeightedTotals.magnitude p.entry at hfill
    omega
  refine ⟨hposorder,hbpos,?_⟩
  change (binaryDigitsValue p.residual:ℤ)+anchorValue (AnchoredInstance.positiveRows raw)=_
  rw [AnchoredInstance.positiveRows_anchor]
  exact_mod_cast (by omega : binaryDigitsValue p.residual+AnchorRows.total raw=binaryDigitsValue target)

theorem anchored_recovery (xs : List Entry) (tree : SumTree Entry)
    (htree : (WeightedTotals.run xs).full=some tree) (target limit : List Bool)
    (htarget : binaryDigitsValue target<WeightedTotals.total xs)
    (counts : List (List Bool))
    (hw : BitWitness (AnchoredInstance.run tree target limit).capped counts
      (binaryDigitsValue (AnchoredInstance.run tree target limit).pivot.residual)) :
    BitWitness (positiveEntries xs)
      (restoreRows (AnchoredInstance.run tree target limit).anchor counts) (binaryDigitsValue target) := by
  have h := anchor_data xs tree htree target limit htarget
  have hw' := uncap_witness limit _ counts _ hw
  have hr := restoreRows_correct (AnchoredInstance.run tree target limit).anchor h.2.1 counts _ hw'
  rw [h.1,h.2.2] at hr
  exact hr

end BinaryMultiplicity.Recovery
