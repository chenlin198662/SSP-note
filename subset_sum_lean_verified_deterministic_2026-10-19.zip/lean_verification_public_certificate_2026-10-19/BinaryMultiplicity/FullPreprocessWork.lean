import BinaryMultiplicity.PreprocessWork

namespace BinaryMultiplicity
open Optss

theorem merged_length (xs : List Entry) : (merged xs).length ≤ xs.length := by
  rw [merged_eq,List.length_map]
  exact grouped_length xs

namespace FullPreprocess

/-- The original serialized size includes record delimiters, target and radius.
It therefore measures padding too, and needs no canonical input hypothesis. -/
def inputLength (xs : List Entry) (target : BitListInteger) (radius : List Bool) : ℕ :=
  inputSize xs+xs.length+target.digits.length+radius.length+1

noncomputable def logFactor (L : ℕ) : ℕ :=
  2*WeightedTotals.multiplierConstant*(WeightedTotals.productLog (2*L))^WeightedTotals.multiplierPower+
  512*(L.size+3)^3+4096*(L.size+1)+4096

/-- Actual complete preprocessing. The final term displays the honest
restoring-division and cap-comparison factor rather than hiding it as unit cost. -/
theorem run_work (xs : List Entry) (target : BitListInteger) (radius : List Bool)
    (N : ℕ) (hweights : ∀x∈xs,x.value.natAbs ≤ N)
    (hradius : binaryDigitsValue radius ≤ N) :
    let L := inputLength xs target radius
    (run xs target radius).work ≤
      16*L*logFactor L+4096*L*(N.size+1) := by
  dsimp only
  let L := inputLength xs target radius
  let ys := BinaryMultiplicity.merged xs
  have hL : 1 ≤ L := by dsimp [L,inputLength]; omega
  have hm : xs.length ≤ L := by dsimp [L,inputLength]; omega
  have hi : inputSize xs ≤ L := by dsimp [L,inputLength]; omega
  have ht : target.digits.length ≤ L := by dsimp [L,inputLength]; omega
  have hr : radius.length ≤ L := by dsimp [L,inputLength]; omega
  have hym : ys.length ≤ xs.length := merged_length xs
  have hyi : inputSize ys ≤ inputSize xs+xs.length := merged_bits xs
  have hymL : ys.length ≤ L := hym.trans hm
  have hyiL : inputSize ys ≤ 2*L := by omega
  have hs : xs.length.size ≤ L.size := Nat.size_le_size hm
  have hys : ys.length.size ≤ L.size := Nat.size_le_size hymL
  have hlog : WeightedTotals.productLog (WeightedTotals.inputSize ys) ≤
      WeightedTotals.productLog (2*L) := by
    apply Nat.size_le_size
    change 2*(inputSize ys+3)+1 ≤ _
    omega
  change WeightedTotals.productLog (inputSize ys) ≤ WeightedTotals.productLog (2*L) at hlog
  have hw := WeightedTotals.run_work_nearlinear ys
  change (WeightedTotals.run ys).work ≤
      2*WeightedTotals.multiplierConstant*(inputSize ys+ys.length)*
        (WeightedTotals.productLog (inputSize ys))^WeightedTotals.multiplierPower+
      256*(inputSize ys+ys.length+1)*(ys.length.size+3)^3+20*ys.length+8 at hw
  have hw' : (WeightedTotals.run ys).work ≤
      6*WeightedTotals.multiplierConstant*L*
        (WeightedTotals.productLog (2*L))^WeightedTotals.multiplierPower+
      1024*L*(L.size+3)^3+20*L+8 := by
    apply hw.trans
    have ht1 : 2*WeightedTotals.multiplierConstant*(inputSize ys+ys.length)*
        (WeightedTotals.productLog (inputSize ys))^WeightedTotals.multiplierPower ≤
        2*WeightedTotals.multiplierConstant*(3*L)*
        (WeightedTotals.productLog (2*L))^WeightedTotals.multiplierPower := by gcongr <;> omega
    have ht2 : 256*(inputSize ys+ys.length+1)*(ys.length.size+3)^3 ≤
        256*(4*L)*(L.size+3)^3 := by gcongr <;> omega
    nlinarith only [ht1,ht2,hymL]
  have ha := Preprocess.after_work ys target radius N.size
    (Preprocess.merged_weight_length xs N hweights)
  dsimp only at ha
  have hmerge := merge_work_nearlinear xs
  have hmerge' : (merge xs).2 ≤ 384*L*(L.size+3)^3+92*L+10 := by
    apply hmerge.trans
    have ht1 : 128*(inputSize xs+2*xs.length)*(xs.length.size+3)^3 ≤
        128*(3*L)*(L.size+3)^3 := by gcongr <;> omega
    nlinarith only [ht1,hm,hi]
  have hafter : (Preprocess.after ys target radius).2 ≤
      (WeightedTotals.run ys).work+
      2048*L*(L.size+2*N.size+2) := by
    apply ha.trans
    have hT : inputSize ys+ys.length+target.digits.length+radius.length+1 ≤ 2*L := by
      dsimp [L,inputLength]
      omega
    have hn := Nat.size_le_size hradius
    apply Nat.add_le_add_left
    calc
      _ ≤ 1024*(2*L)*(L.size+2*N.size+2) :=
        Nat.mul_le_mul (Nat.mul_le_mul_left 1024 hT) (by omega)
      _ = _ := by ring
  have hgroups : (merge xs).1.length ≤ L := by
    simpa only [ys,merged,List.length_map] using hymL
  change (merge xs).2+(Preprocess.after ys target radius).2+4*(merge xs).1.length+8 ≤ _
  dsimp only [logFactor]
  nlinarith only [hmerge',hafter,hw',hgroups,hL]

end FullPreprocess
end BinaryMultiplicity
