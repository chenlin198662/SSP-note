import BinaryMultiplicity.AnchorRows

namespace BinaryMultiplicity.AnchorRows
open Optss

def total (xs : List (Entry × List Bool)) : ℕ :=
  (xs.map (fun x => binaryDigitsValue x.2*WeightedTotals.magnitude x.1)).sum

theorem total_append (xs ys : List (Entry × List Bool)) : total (xs++ys)=total xs+total ys := by
  simp [total,List.map_append,List.sum_append]

def Weights (tree : SumTree Entry) : Prop :=
  ∀x∈tree.entries,binaryDigitsValue x.2=WeightedTotals.weight x.1

theorem full_total (tree : SumTree Entry) (hv : tree.Valid) (hw : Weights tree) :
    total (tree.entries.map (fun x => (x.1,x.1.count)))=binaryDigitsValue tree.word := by
  rw [SumTree.word_value tree hv]
  unfold total
  rw [List.map_map]
  congr 1
  apply List.map_congr_left
  intro x hx
  rw [hw x hx]
  simp [WeightedTotals.weight,WeightedTotals.magnitude,Entry.capacity,mul_comm]

theorem zero_total (tree : SumTree Entry) :
    total (tree.entries.map (fun x => (x.1,[])))=0 := by
  simp [total,List.map_map,Function.comp_def,binaryDigitsValue]

theorem fill_bounds (tree : SumTree Entry) (target q : List Bool)
    (hq : binaryDigitsValue q≤(tree.descend target).payload.capacity) :
    ∀x∈fill tree (tree.descend target).path q,binaryDigitsValue x.2≤x.1.capacity := by
  induction tree generalizing target with
  | leaf a w => simpa [fill,fillAcc,SumTree.descend] using hq
  | node w l r il ir =>
      by_cases hc : bitListLE l.word target=true
      · simp only [SumTree.descend,if_pos hc] at hq ⊢
        rw [fill_node_true]
        intro x hx
        rcases List.mem_append.mp hx with hx|hx
        · obtain ⟨a,ha,rfl⟩ := List.mem_map.mp hx
          rfl
        · exact ir _ hq x hx
      · simp only [SumTree.descend,if_neg hc] at hq ⊢
        rw [fill_node_false]
        intro x hx
        rcases List.mem_append.mp hx with hx|hx
        · exact il _ hq x hx
        · obtain ⟨a,ha,rfl⟩ := List.mem_map.mp hx
          exact Nat.zero_le _

theorem fill_total (tree : SumTree Entry) (hv : tree.Valid) (hw : Weights tree)
    (target q : List Bool) (ht : binaryDigitsValue target<binaryDigitsValue tree.word) :
    total (fill tree (tree.descend target).path q)+binaryDigitsValue (tree.descend target).residual =
      binaryDigitsValue target+binaryDigitsValue q*WeightedTotals.magnitude (tree.descend target).payload := by
  induction tree generalizing target with
  | leaf a w => simp [fill,fillAcc,SumTree.descend,total,add_comm]
  | node w l r il ir =>
      obtain ⟨hvl,hvr,he⟩ := hv
      have hwl : Weights l := fun x hx => hw x (by simp [SumTree.entries,hx])
      have hwr : Weights r := fun x hx => hw x (by simp [SumTree.entries,hx])
      change binaryDigitsValue target<binaryDigitsValue w at ht
      by_cases hc : bitListLE l.word target=true
      · have hle := (bitListLE_correct _ _).mp hc
        have hs : binaryDigitsValue (bitListTrim (bitListSub target l.word))=
            binaryDigitsValue target-binaryDigitsValue l.word := by
          rw [bitListTrim_value,bitListSub_correct]
        have hb : binaryDigitsValue (bitListTrim (bitListSub target l.word))<binaryDigitsValue r.word := by
          rw [hs]; omega
        have hh := ir hvr hwr _ hb
        simp only [SumTree.descend,if_pos hc,fill_node_true,total_append,full_total l hvl hwl]
        omega
      · have hb : binaryDigitsValue target<binaryDigitsValue l.word := by
          have hn : ¬binaryDigitsValue l.word≤binaryDigitsValue target :=
            fun h => hc ((bitListLE_correct _ _).mpr h)
          omega
        have hh := il hvl hwl target hb
        simp only [SumTree.descend,if_neg hc,fill_node_false,total_append,zero_total,Nat.add_zero]
        exact hh

theorem weightedTree_weights (xs : List Entry) (tree : SumTree Entry)
    (ht : (WeightedTotals.run xs).full=some tree) : Weights tree := by
  have he := (WeightedTotals.full_spec xs tree ht).1
  intro x hx
  rw [he] at hx
  obtain ⟨a,ha,rfl⟩ := List.mem_map.mp hx
  exact FastProduct.run_value _ _

end BinaryMultiplicity.AnchorRows
