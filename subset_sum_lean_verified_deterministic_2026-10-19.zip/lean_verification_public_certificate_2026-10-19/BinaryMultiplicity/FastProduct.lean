import BinaryMultiplicity.Input
import Optss.BinaryMultiplication

namespace BinaryMultiplicity.FastProduct
open Optss SubsetSum.ExternalCostContracts

def unsigned (xs : List Bool) : BitListInteger := ⟨false,xs⟩
def zero : BitListInteger := ⟨false,[]⟩

/-- The first coefficient of the proved stored Boolean convolution. This
uses the complete measured frontend, including copying and canonicalization. -/
def run (xs ys : List Bool) : List Bool :=
  ((ConvolutionDraft.CanonicalOutput.run [unsigned xs] [unsigned ys]).headD zero).digits

def work (xs ys : List Bool) : ℕ :=
  ConvolutionDraft.CanonicalOutput.work [unsigned xs] [unsigned ys]+8

theorem head_value (xs ys : List Bool) :
    ((ConvolutionDraft.CanonicalOutput.run [unsigned xs] [unsigned ys]).headD zero).value =
      (binaryDigitsValue xs : ℤ)*binaryDigitsValue ys := by
  have h := ConvolutionDraft.StoredFrontend.run_coeff [unsigned xs] [unsigned ys] 0
  rw [←ConvolutionDraft.CanonicalOutput.run_values] at h
  simpa [ExecutablePackedConvolution.signedCoefficient,unsigned,
    BitListInteger.value,signedBitsValue,List.getD] using h

theorem head_canonical (xs ys : List Bool) :
    integerBitRepresentation
      ((ConvolutionDraft.CanonicalOutput.run [unsigned xs] [unsigned ys]).headD zero).value =
      (ConvolutionDraft.CanonicalOutput.run [unsigned xs] [unsigned ys]).headD zero := by
  have hl := ConvolutionDraft.CanonicalOutput.run_length [unsigned xs] [unsigned ys]
  have hc := ConvolutionDraft.CanonicalOutput.run_canonical [unsigned xs] [unsigned ys]
  cases he : ConvolutionDraft.CanonicalOutput.run [unsigned xs] [unsigned ys] with
  | nil => simp [he] at hl
  | cons z zs => exact hc z (by simp [he])

theorem run_eq_bits (xs ys : List Bool) :
    run xs ys=(binaryDigitsValue xs*binaryDigitsValue ys).bits := by
  have hc := congrArg BitListInteger.digits (head_canonical xs ys)
  rw [head_value] at hc
  simpa [run,integerBitRepresentation,Int.natCast_mul] using hc.symm

theorem run_value (xs ys : List Bool) :
    binaryDigitsValue (run xs ys)=binaryDigitsValue xs*binaryDigitsValue ys := by
  rw [run_eq_bits,binaryDigitsValue_bits]

theorem run_length (xs ys : List Bool) : (run xs ys).length ≤ xs.length+ys.length := by
  rw [run_eq_bits,Nat.size_eq_bits_len]
  exact (nat_mul_size_le _ _).trans (Nat.add_le_add
    (Nat.size_le.mpr (binaryDigitsValue_lt_pow xs))
    (Nat.size_le.mpr (binaryDigitsValue_lt_pow ys)))

theorem work_bound (xs ys : List Bool) :
    work xs ys ≤ fftBudget
      (ConvolutionDraft.CanonicalOutput.polynomial.eval 1)
      ConvolutionDraft.CanonicalOutput.polynomial.natDegree 2 (xs.length+ys.length)+8 := by
  have h := ConvolutionDraft.CanonicalOutput.work_fftBudget
    [unsigned xs] [unsigned ys] (xs.length+ys.length)
    (by simp [unsigned]) (by simp [unsigned]) (by simp)
  exact Nat.add_le_add_right h 8

end BinaryMultiplicity.FastProduct
