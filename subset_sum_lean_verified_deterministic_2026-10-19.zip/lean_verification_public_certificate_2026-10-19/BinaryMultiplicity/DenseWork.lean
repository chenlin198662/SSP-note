import BinaryMultiplicity.DenseProgram

namespace BinaryMultiplicity.Dense
open Optss SubsetSum SubsetSum.CostedArrayProgram SubsetSum.ExternalCostContracts

theorem row_cost (F : ExactIntegerConvolution) (rates : Rates) (N B : ℕ)
    (xs : List Entry) (i : Fin xs.length) (hN : N.size ≤ B) (hlen : xs.length.size ≤ B)
    (hv : ∀x∈xs,x.value.natAbs.size ≤ B) (hc : ∀x∈xs,x.capacity.size ≤ B) :
    (row N (xs.map Entry.value).toArray (xs.map (fun x => (x.capacity:ℤ))).toArray i.val).cost F rates ≤
      8*B+3 := by
  have hi := (Nat.size_le_size i.isLt.le).trans hlen
  have hv' := hv (xs.get i) (List.get_mem _ _)
  have hc' := hc (xs.get i) (List.get_mem _ _)
  simp only [row,bind,pure,Program.cost_bind,Program.value_bind,Program.cost_pure,
    call,Program.cost,Program.value,Op.value,Op.charge,Array.size_toArray,List.length_map,
    Nat.add_zero]
  simp [List.getElem?_toArray,List.getElem?_map,List.getElem?_eq_getElem i.isLt,
    Option.map_some,Option.getD_some,Int.natAbs_natCast]
  simp only [List.get_eq_getElem] at hv' hc'
  omega

theorem run_cost (F : ExactIntegerConvolution) (rates : Rates) (N B : ℕ)
    (xs : List Entry) (hN : N.size ≤ B) (hlen : xs.length.size ≤ B)
    (hv : ∀x∈xs,x.value.natAbs.size ≤ B) (hc : ∀x∈xs,x.capacity.size ≤ B)
    (hbound : ∀x∈xs,x.value.natAbs ≤ N) :
    (run N xs).cost F rates ≤ (N+xs.length+1)*128*(B+3)^2 := by
  have hw := CostedDenseArray.fromList_charge_le rates (xs.map Entry.value) B (by
    intro x hx; obtain ⟨y,hy,rfl⟩ := List.mem_map.mp hx; exact hv y hy)
  have hcopy := CostedDenseArray.fromList_charge_le rates (xs.map (fun x => (x.capacity:ℤ))) B (by
    intro x hx; obtain ⟨y,hy,rfl⟩ := List.mem_map.mp hx; simpa only [Int.natAbs_natCast] using hc y hy)
  simp only [List.length_map] at hw hcopy
  have hmap := CostedDenseArray.mapM_cost_le F rates
    (fun i:Fin xs.length => row N (xs.map Entry.value).toArray
      (xs.map (fun x => (x.capacity:ℤ))).toArray i.val) (List.finRange xs.length) (8*B+3)
    (fun i _ => row_cost F rates N B xs i hN hlen hv hc)
  simp only [List.length_finRange] at hmap
  have hhist := CostedCappedHistogram.run_cost F rates (2*N+1) (2*N) B (pairs N xs)
    (by
      intro e he; obtain ⟨x,hx,rfl⟩ := List.mem_map.mp he
      apply ScalarHistogramArray.index_lt
      have hh := hbound x hx
      constructor <;> omega)
    (by intro e he; obtain ⟨x,hx,rfl⟩ := List.mem_map.mp he; exact hc x hx)
  have hk := nat_mul_size_le 2 N
  have htwo : (2:ℕ).size=2 := by simpa using (Nat.size_pow (n:=1))
  have hvsize := nat_add_size_le_sum (2*N) 1
  simp only [htwo,Nat.size_one] at hk hvsize
  have hk' : (2*N).size ≤ B+2 := by omega
  have hv' : (2*N+1).size ≤ B+4 := by omega
  have hhist' : (CostedCappedHistogram.run (2*N+1) (2*N) (pairs N xs)).cost F rates ≤
      (2*N+2)*(B+5)+xs.length*(8*(3*B+7)+1) := by
    apply hhist.trans
    simp only [pairs,List.length_map]
    apply Nat.add_le_add
    · exact Nat.mul_le_mul_left (2*N+2) (by omega)
    · apply Nat.mul_le_mul_left
      omega
  have hw' := hw.trans (show 1+xs.length*(B+xs.length.size+1) ≤ 1+xs.length*(2*B+1) by gcongr; omega)
  have hcopy' := hcopy.trans (show 1+xs.length*(B+xs.length.size+1) ≤ 1+xs.length*(2*B+1) by gcongr; omega)
  have hmultiply : (2+N.size+1)^2 ≤ (B+3)^2 := Nat.pow_le_pow_left (by omega) _
  have he : (mapM (fun i:Fin xs.length => row N (xs.map Entry.value).toArray
      (xs.map (fun x => (x.capacity:ℤ))).toArray i.val) (List.finRange xs.length)).value F=pairs N xs := by
    rw [mapM_value]
    simp only [row_value]
    rw [←List.ofFn_eq_map]
    simpa only [pairs,List.get_eq_getElem] using
      List.ofFn_getElem_eq_map xs (fun x => (ScalarHistogramArray.index N x.value,x.capacity))
  simp only [run,bind,Program.cost_bind,Program.value_bind,call,Program.cost,Program.value,Op.value,
    Program.cost_pure,Nat.add_zero,he,CostedBoxIndex.natAdd_value,CostedBoxIndex.natAdd_cost]
  simp only [Op.charge,htwo,Nat.size_one]
  change 1+(List.map (fun z => z.natAbs.size+(xs.map Entry.value).length.size+1) (xs.map Entry.value)).sum ≤ _ at hw
  change 1+(List.map (fun z => z.natAbs.size+(xs.map (fun x => (x.capacity:ℤ))).length.size+1)
    (xs.map (fun x => (x.capacity:ℤ)))).sum ≤ _ at hcopy
  simp only [pairs,List.length_map] at hhist
  simp only [Op.charge] at hw' hcopy'
  nlinarith only [hw',hcopy',hmap,hhist',hk',hmultiply]

end BinaryMultiplicity.Dense
