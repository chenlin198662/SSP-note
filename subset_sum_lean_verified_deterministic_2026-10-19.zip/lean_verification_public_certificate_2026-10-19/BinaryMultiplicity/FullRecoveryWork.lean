import BinaryMultiplicity.FullRecovery
import BinaryMultiplicity.WitnessBits

namespace BinaryMultiplicity.Recovery
open Optss

def recoverReducedWork (prepared : FullPreprocess.Output) (out : AnchoredInstance.Output)
    (counts : List (List Bool)) : ℕ :=
  let restored := restoreRows out.anchor counts
  let original := uncomplement (prepared.merged.map Merged.entry) restored
  restoreRowsWork out.anchor counts+
    uncomplementWork (prepared.merged.map Merged.entry) restored+
    recoverManyWork prepared.merged original+4*prepared.merged.length+12

theorem anchor_bits (xs : List Entry) (tree : SumTree Entry)
    (htree : (WeightedTotals.run xs).full=some tree) (target limit : List Bool)
    (htarget : binaryDigitsValue target<WeightedTotals.total xs) :
    anchorBits (AnchoredInstance.run tree target limit).anchor ≤ countBits xs := by
  have hs := WeightedTotals.full_spec xs tree htree
  have h := AnchorRows.fill_wordBits tree target (Pivot.run tree target).anchor
    (AnchorRows.pivot_anchor_length xs tree htree target htarget)
  have he : AnchorRows.capacityBits tree=countBits xs := by
    rw [AnchorRows.capacityBits,hs.1]
    simp [WeightedTotals.weightedLeaves,countBits,List.map_map,Function.comp_def]
  rw [he] at h
  simpa [anchorBits,AnchoredInstance.run,AnchoredInstance.positiveRows,
    AnchorRows.wordBits,Pivot.run,List.map_map,Function.comp_def] using h

/-- Complete recovery to original normalized records is input-linear up to
the balanced-tree logarithm, including all large-count subtraction/copy work. -/
theorem recoverReduced_work (xs : List Entry) (target : BitListInteger) (radius : List Bool)
    (out : AnchoredInstance.Output)
    (ho : (FullPreprocess.run xs target radius).answer=.reduced out)
    (counts : List (List Bool))
    (hw : BitWitness out.capped counts (binaryDigitsValue out.pivot.residual)) :
    recoverReducedWork (FullPreprocess.run xs target radius) out counts ≤
      512*(xs.length.size+1)*(inputSize xs+xs.length+1)+32*wordBits counts := by
  let ys := BinaryMultiplicity.merged xs
  obtain ⟨tree,ht,hr,rfl⟩ := Preprocess.after_reduced ys target radius out ho
  let shifted := Preprocess.shiftedTarget target (WeightedTotals.storedWord (WeightedTotals.run ys).negative)
  let output := AnchoredInstance.run tree shifted.digits (Preprocess.limit radius)
  let restored := restoreRows output.anchor counts
  let original := uncomplement ys restored
  have hd := anchor_data ys tree ht shifted.digits (Preprocess.limit radius) hr
  have hp := anchored_recovery ys tree ht shifted.digits (Preprocess.limit radius) hr counts hw
  have hpb := BitWitness.wordBits hp (restoreRows_canonical _ _)
  have hcp : countBits (positiveEntries ys)=countBits ys := by
    simp [countBits,positiveEntries,positiveEntry,List.map_map,Function.comp_def]
  rw [hcp] at hpb
  have hu := uncomplement_correct ys restored _ hp
  have hub := BitWitness.wordBits hu (uncomplement_canonical ys restored (restoreRows_canonical _ _))
  have hab := anchor_bits ys tree ht shifted.digits (Preprocess.limit radius) hr
  have hal : output.anchor.length=ys.length := by
    simpa [positiveEntries] using congrArg List.length hd.1
  have hrestore := restoreRowsWork_bound output.anchor counts
  have huncomp := uncomplementWork_bound ys restored
  have hgroup := merged_recovery_work xs original _ hu
  have hcount : countBits ys ≤ inputSize xs+xs.length :=
    (show countBits ys ≤ inputSize ys by rw [inputSize_eq]; omega).trans (merged_bits xs)
  have hlen : ys.length ≤ xs.length := by
    dsimp only [ys]
    rw [merged_eq,List.length_map]
    exact grouped_length xs
  have hglen : (merge xs).1.length=ys.length := by
    dsimp only [ys]
    rw [merged_eq,List.length_map]
    simp [merge]
  change wordBits restored ≤ countBits ys at hpb
  change wordBits original ≤ countBits ys at hub
  change anchorBits output.anchor ≤ countBits ys at hab
  rw [hal] at hrestore
  change restoreRowsWork output.anchor counts+uncomplementWork ys restored+
    recoverManyWork (merge xs).1 original+4*(merge xs).1.length+12 ≤ _
  rw [hglen]
  have hm : inputSize xs+xs.length+1 ≤
      (xs.length.size+1)*(inputSize xs+xs.length+1) := by
    exact Nat.le_mul_of_pos_left _ (by omega)
  nlinarith only [hrestore,huncomp,hgroup,hcount,hlen,hpb,hub,hab,hm]

end BinaryMultiplicity.Recovery
