import BinaryMultiplicity.FullPreprocessWork

namespace BinaryMultiplicity.FullPreprocess
open Optss

theorem productLog_twice (L : ℕ) : WeightedTotals.productLog (2*L) ≤ 6*(L.size+1) := by
  have hm := Nat.size_le_size (show 2*(2*L+3)+1 ≤ 8*(L+1) by omega)
  have hp := nat_mul_size_le 8 (L+1)
  have ha := nat_add_size_le_sum L 1
  have he : (8:ℕ).size=4 := by simpa using (Nat.size_pow (n:=3))
  simp only [Nat.size_one] at ha
  dsimp only [WeightedTotals.productLog]
  omega

noncomputable def logCoefficient : ℕ :=
  2*WeightedTotals.multiplierConstant*6^WeightedTotals.multiplierPower+512*27+8192
noncomputable def logPower : ℕ := WeightedTotals.multiplierPower+3

theorem logFactor_bound (L : ℕ) :
    logFactor L ≤ logCoefficient*(L.size+1)^logPower := by
  let e := WeightedTotals.multiplierPower
  let x := L.size+1
  have hx : 1 ≤ x := by dsimp [x]; omega
  have he : x^e ≤ x^(e+3) := Nat.pow_le_pow_right hx (by omega)
  have h3 : x^3 ≤ x^(e+3) := Nat.pow_le_pow_right hx (by omega)
  have h1 : x ≤ x^(e+3) := by
    simpa only [pow_one] using (Nat.pow_le_pow_right hx (show 1 ≤ e+3 by omega))
  have h0 : 1 ≤ x^(e+3) := one_le_pow₀ hx
  have hp := productLog_twice L
  have hpow : (WeightedTotals.productLog (2*L))^e ≤ 6^e*x^(e+3) := by
    calc
      _ ≤ (6*x)^e := Nat.pow_le_pow_left hp e
      _ = 6^e*x^e := mul_pow _ _ _
      _ ≤ _ := Nat.mul_le_mul_left _ he
  have hcube : (L.size+3)^3 ≤ 27*x^(e+3) := by
    calc
      _ ≤ (3*x)^3 := Nat.pow_le_pow_left (by dsimp [x]; omega) _
      _ = 27*x^3 := by ring
      _ ≤ _ := Nat.mul_le_mul_left _ h3
  have hmult := Nat.mul_le_mul_left (2*WeightedTotals.multiplierConstant) hpow
  dsimp only [logFactor,logCoefficient,logPower]
  change 2*WeightedTotals.multiplierConstant*(WeightedTotals.productLog (2*L))^e+
    512*(L.size+3)^3+4096*x+4096 ≤
    (2*WeightedTotals.multiplierConstant*6^e+512*27+8192)*x^(e+3)
  nlinarith only [hmult,hcube,h1,h0]

/-- An explicit fixed logarithmic power suffices for every original input. -/
theorem run_work_explicit_log (xs : List Entry) (target : BitListInteger) (radius : List Bool)
    (N : ℕ) (hweights : ∀x∈xs,x.value.natAbs ≤ N)
    (hradius : binaryDigitsValue radius ≤ N) :
    let L := inputLength xs target radius
    (run xs target radius).work ≤
      16*logCoefficient*L*(L.size+1)^logPower+4096*L*(N.size+1) := by
  dsimp only
  have h := run_work xs target radius N hweights hradius
  dsimp only at h
  have hm := Nat.mul_le_mul_left (16*inputLength xs target radius)
    (logFactor_bound (inputLength xs target radius))
  nlinarith only [h,hm]

end BinaryMultiplicity.FullPreprocess
