import BinaryMultiplicity.WeightedTotals
import Optss.BitListDivision

namespace BinaryMultiplicity
open Optss

theorem SumTree.descend_residual_width {α : Type*} (tree : SumTree α) (target : List Bool) :
    (tree.descend target).residual.length ≤ target.length := by
  induction tree generalizing target with
  | leaf a w => rfl
  | node w l r il ir =>
      simp only [SumTree.descend]
      split
      · apply (ir _).trans
        rw [bitListTrim_length,bitListSub_correct]
        exact (Nat.size_le_size (Nat.sub_le _ _)).trans
          (Nat.size_le.mpr (binaryDigitsValue_lt_pow target))
      · exact il _

structure Pivot where
  path : List Bool
  entry : Entry
  anchor : List Bool
  residual : List Bool

namespace Pivot

def run (tree : SumTree Entry) (target : List Bool) : Pivot :=
  let crossing := tree.descend target
  let divided := bitListDivision crossing.residual crossing.payload.weight.digits
  ⟨crossing.path,crossing.payload,divided.quotient,divided.remainder⟩

def work (tree : SumTree Entry) (target : List Bool) : ℕ :=
  let crossing := tree.descend target
  tree.descendWork target+
    bitListDivisionBitWork crossing.residual crossing.payload.weight.digits+12

theorem run_spec (xs : List Entry) (tree : SumTree Entry)
    (ht : (WeightedTotals.run xs).full=some tree) (target : List Bool)
    (hbound : binaryDigitsValue target<WeightedTotals.total xs) :
    let out := run tree target
    ∃before after,
      xs=before++out.entry::after ∧
      binaryDigitsValue target=WeightedTotals.total before+
        binaryDigitsValue out.anchor*WeightedTotals.magnitude out.entry+binaryDigitsValue out.residual ∧
      binaryDigitsValue out.anchor<out.entry.capacity ∧
      binaryDigitsValue out.residual<WeightedTotals.magnitude out.entry := by
  dsimp only
  obtain ⟨he,hv,_,_⟩ := WeightedTotals.full_spec xs tree ht
  have htotal := WeightedTotals.full_value xs
  simp only [ht,WeightedTotals.storedWord] at htotal
  obtain ⟨before,w,after,hentries,hs,hr⟩ := tree.descend_spec hv target (by rwa [htotal])
  have hm : ((tree.descend target).payload,w)∈WeightedTotals.weightedLeaves xs := by
    rw [←he,hentries]; simp
  obtain ⟨x,hx,hxw⟩ := List.mem_map.mp hm
  have hx1 : x=(tree.descend target).payload := congrArg Prod.fst hxw
  have hw : w=FastProduct.run (tree.descend target).payload.weight.digits
      (tree.descend target).payload.count := by
    have hh := congrArg Prod.snd hxw
    simpa only [hx1] using hh.symm
  rw [hw,FastProduct.run_value] at hr
  have hd : 0<binaryDigitsValue (tree.descend target).payload.weight.digits := by
    by_contra hn
    have hz : binaryDigitsValue (tree.descend target).payload.weight.digits=0 := by omega
    rw [hz,zero_mul] at hr
    omega
  have hdiv := bitListDivision_correct (tree.descend target).residual
    (tree.descend target).payload.weight.digits hd
  have hq : binaryDigitsValue (bitListDivision (tree.descend target).residual
      (tree.descend target).payload.weight.digits).quotient <
      (tree.descend target).payload.capacity := by
    rw [hdiv.1]
    exact (Nat.div_lt_iff_lt_mul hd).mpr (by simpa [Entry.capacity,mul_comm] using hr)
  have hrem := Nat.mod_lt (binaryDigitsValue (tree.descend target).residual) hd
  have hprefix : (before.map Prod.fst)++(tree.descend target).payload::after.map Prod.fst=xs := by
    have h := congrArg (List.map Prod.fst) hentries
    rw [he] at h
    simpa [WeightedTotals.weightedLeaves,List.map_map,Function.comp_def] using h.symm
  have hbefore : SumTree.sumWords before=WeightedTotals.total (before.map Prod.fst) := by
    unfold SumTree.sumWords WeightedTotals.total
    rw [List.map_map]
    congr 1
    apply List.map_congr_left
    intro z hz
    have hz' : z∈WeightedTotals.weightedLeaves xs := by
      rw [←he,hentries]; simp [hz]
    obtain ⟨a,ha,rfl⟩ := List.mem_map.mp hz'
    exact FastProduct.run_value _ _
  refine ⟨before.map Prod.fst,after.map Prod.fst,hprefix.symm,?_,hq,?_⟩
  · dsimp only [run,WeightedTotals.magnitude]
    rw [hdiv.1,hdiv.2,←hbefore]
    have hn := Nat.mod_add_div (binaryDigitsValue (tree.descend target).residual)
      (binaryDigitsValue (tree.descend target).payload.weight.digits)
    nlinarith
  · dsimp only [run,WeightedTotals.magnitude]
    rw [hdiv.2]
    exact hrem

/-- The division factor is explicit: no fast-division assertion is used. -/
theorem work_bound (tree : SumTree Entry) (target : List Bool) (B W : ℕ)
    (ht : tree.AllWidths B) (hw : target.length≤B)
    (hd : 0<binaryDigitsValue (tree.descend target).payload.weight.digits)
    (hW : (tree.descend target).payload.weight.digits.length≤W) :
    work tree target ≤ 32*(B+1)*(tree.height+1)+16*(B+1)*(W+1)+12 := by
  have hc := tree.descendWork_bound target B ht hw
  have hl := tree.descend_residual_width target
  have hdw := bitListDivisionBitWork_bound (tree.descend target).residual
    (tree.descend target).payload.weight.digits hd
  have hm : 16*((tree.descend target).residual.length+1)*
      ((tree.descend target).payload.weight.digits.length+1) ≤ 16*(B+1)*(W+1) := by
    gcongr <;> omega
  dsimp only [work]
  omega

end Pivot
end BinaryMultiplicity
