import BinaryMultiplicity.DenseProgram
import SubsetSum.TypeAggregation

namespace BinaryMultiplicity.Dense
open Optss SubsetSum SubsetSum.ScalarTypeCompression SubsetSum.TypeAggregation
open SubsetSum.ExternalCostContracts

theorem grouped_witness_iff {ι κ G : Type*} [Fintype ι] [Fintype κ]
    [DecidableEq κ] [AddCommMonoid G] (f : ι → κ) (c : ι → ℕ) (w : κ → G) (t : G) :
    (∃x:ι→ℕ,(∀i,x i ≤ c i) ∧ (∑i,x i • w (f i))=t) ↔
    (∃y:κ→ℕ,(∀j,y j ≤ TypeAggregation.grouped f c j) ∧ (∑j,y j • w j)=t) := by
  constructor
  · rintro ⟨x,hx,hs⟩
    exact ⟨TypeAggregation.grouped f x,grouped_mono f x c hx,by rwa [grouped_weighted_sum]⟩
  · rintro ⟨y,hy,hs⟩
    have hc : ∀j,y j ≤ TypeAggregation.capped f c (∑i,c i) j := by
      intro j
      exact le_min ((hy j).trans (grouped_le_total f c j)) (hy j)
    obtain ⟨x,hx,he,_⟩ := exists_ungroup f c (∑i,c i) y hc
    refine ⟨x,hx,?_⟩
    rw [←grouped_weighted_sum]
    simpa only [he] using hs

def nonzero (xs : List Entry) : List Entry := xs.filter (fun x => decide (x.value≠0))

theorem feasible_nonzero (xs : List Entry) (t : ℤ) : Feasible (nonzero xs) t ↔ Feasible xs t := by
  induction xs generalizing t with
  | nil => rfl
  | cons x xs ih =>
    by_cases hx : x.value=0
    · simp only [nonzero,List.filter_cons,hx,ne_eq,not_true_eq_false,decide_false,Bool.false_eq_true,if_false]
      rw [←nonzero,ih,feasible_cons]
      constructor
      · intro h; exact ⟨0,by omega,t,h,by simp⟩
      · rintro ⟨n,hn,s,hs,he⟩
        simp only [hx,mul_zero,zero_add] at he
        simpa only [he] using hs
    · simp only [nonzero,List.filter_cons,hx,ne_eq,not_false_eq_true,decide_true,if_true]
      change Feasible (x::nonzero xs) t ↔ Feasible (x::xs) t
      simp only [feasible_cons,ih]

theorem pairs_weight (N : ℕ) (xs : List Entry) (z : ℤ) (hz : -(N:ℤ) ≤ z)
    (hb : ∀x∈xs,-(N:ℤ) ≤ x.value) :
    CostedCappedHistogram.weight (pairs N xs) (ScalarHistogramArray.index N z)=
      (xs.map (fun x => if x.value=z then x.capacity else 0)).sum := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    have he := ScalarHistogramArray.index_inj N x.value z (hb x List.mem_cons_self) hz
    simp only [pairs,List.map_cons,CostedCappedHistogram.weight_cons,List.sum_cons]
    simp only [he]
    exact congrArg (fun a => (if x.value=z then x.capacity else 0)+a)
      (ih (fun y hy => hb y (List.mem_cons_of_mem _ hy)))

theorem nonzero_sum (xs : List Entry) (z : ℤ) (hz : z≠0) :
    ((nonzero xs).map (fun x => if x.value=z then x.capacity else 0)).sum=
      (xs.map (fun x => if x.value=z then x.capacity else 0)).sum := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    by_cases hx : x.value=0
    · simpa [nonzero,List.filter_cons,hx,hz,Ne.symm hz] using ih
    · simp only [nonzero,List.filter_cons,hx,ne_eq,not_false_eq_true,decide_true,if_true,
        List.map_cons,List.sum_cons]
      exact congrArg (fun a => (if x.value=z then x.capacity else 0)+a) ih

def typeAddress (N : ℕ) (xs : List Entry)
    (hb : ∀x∈xs,x.value.natAbs ≤ N) (i : Fin (nonzero xs).length) : SignedType N :=
  ⟨((nonzero xs).get i).value,by
    have hm := List.mem_filter.mp (List.get_mem (nonzero xs) i)
    have hh := hb _ hm.1
    apply (mem_signedTypes _ _).mpr
    exact ⟨of_decide_eq_true hm.2,by omega,by omega⟩⟩

theorem type_grouped (N : ℕ) (xs : List Entry)
    (hb : ∀x∈xs,x.value.natAbs ≤ N) (z : SignedType N) :
    TypeAggregation.grouped (typeAddress N xs hb) (fun i => ((nonzero xs).get i).capacity) z=
      CostedCappedHistogram.weight (pairs N xs) (ScalarHistogramArray.index N z.val) := by
  rw [pairs_weight N xs z.val (type_bounds N z).1 (fun x hx => by have h:=hb x hx; omega)]
  rw [←nonzero_sum xs z.val ((mem_signedTypes _ _).mp z.property).1]
  rw [←List.ofFn_getElem_eq_map,List.sum_ofFn]
  apply Finset.sum_congr rfl
  intro i _
  simp only [typeAddress,Subtype.ext_iff,List.get_eq_getElem]

/-- The dense capped count table has exactly the reduced instance's feasible
sums in the promised short target interval, without expanding any count. -/
theorem run_feasible (F : ExactIntegerConvolution) (N : ℕ) (xs : List Entry)
    (hN : 0<N) (hb : ∀x∈xs,x.value.natAbs ≤ N) (r : ℕ) (hr : r<N) :
    InteriorReduction.CountFeasible (ScalarInitialState.items N)
      (fun i => (CostedScalarTypes.capacity N ((run N xs).value F) i:ℤ))
      {fun _ => (r:ℤ)} ↔ Feasible xs (r:ℤ) := by
  rw [ScalarInitialState.scalar_feasible]
  simp_rw [run_capacity]
  have hcap := ScalarProximity.cap_counts_iff (fun z:SignedType N => z.val)
    (fun z => CostedCappedHistogram.weight (pairs N xs) (ScalarHistogramArray.index N z.val))
    N (r:ℤ) hN (type_bounds N) ⟨by positivity,by exact_mod_cast hr⟩
  simp only [min_comm] at hcap
  rw [←hcap]
  rw [←feasible_nonzero xs (r:ℤ),feasible_indexed]
  have h := grouped_witness_iff (typeAddress N xs hb)
    (fun i => ((nonzero xs).get i).capacity) (fun z:SignedType N => z.val) (r:ℤ)
  simp only [type_grouped,nsmul_eq_mul,typeAddress] at h
  exact h.symm

end BinaryMultiplicity.Dense
