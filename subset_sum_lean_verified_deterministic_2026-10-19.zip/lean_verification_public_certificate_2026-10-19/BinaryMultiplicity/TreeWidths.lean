import BinaryMultiplicity.BuildSumTree
import BinaryMultiplicity.Crossing

namespace BinaryMultiplicity.SumTree
open Optss
variable {α : Type}

theorem pair_allWidths (ts : List (SumTree α)) (B : ℕ)
    (hb : bits ts+ts.length ≤ B) (h : ∀t∈ts,t.AllWidths B) :
    ∀t∈pair ts,t.AllWidths B := by
  induction ts using pair.induct with
  | case1 a b ts ih =>
      intro t ht
      rcases List.mem_cons.mp ht with rfl | ht
      · refine ⟨?_,h a (by simp),h b (by simp)⟩
        have hw := join_width a b
        simp only [bits,List.map_cons,List.sum_cons,List.length_cons] at hb
        exact hw.trans (by omega)
      · apply ih (by
          simp only [bits,List.map_cons,List.sum_cons,List.length_cons] at hb ⊢
          omega) (fun t ht => h t (by simp [ht])) t ht
  | case2 ts ht => cases ts with
    | nil => simp [pair]
    | cons a ts => cases ts <;> simp_all [pair]

theorem rounds_allWidths (fuel : ℕ) (ts : List (SumTree α)) (B : ℕ)
    (hb : bits ts+ts.length ≤ B) (h : ∀t∈ts,t.AllWidths B) :
    ∀t∈rounds fuel ts,t.AllWidths B := by
  induction fuel generalizing ts with
  | zero => exact h
  | succ fuel ih =>
      exact ih (pair ts) ((pair_potential ts).trans hb) (pair_allWidths ts B hb h)

theorem initial_allWidths (xs : List (α × List Bool)) :
    ∀t∈initial xs,t.AllWidths (inputBits xs+xs.length) := by
  intro t ht
  obtain ⟨a,ha,rfl⟩ := List.mem_map.mp ht
  have hm : a.2.length∈xs.map (fun x => x.2.length) := List.mem_map.mpr ⟨a,ha,rfl⟩
  have hs := List.single_le_sum (fun n _ => Nat.zero_le n) a.2.length hm
  change a.2.length ≤ inputBits xs+xs.length
  exact hs.trans (Nat.le_add_right _ _)

/-- Every cached internal total in the actual balanced build fits in the
aggregate input width. No output-word premise is required. -/
theorem build_allWidths (xs : List (α × List Bool)) (t : SumTree α)
    (ht : (build xs).1=some t) : t.AllWidths (inputBits xs+xs.length) := by
  have hm : t∈rounds xs.length.size (initial xs) :=
    List.mem_of_mem_head? (by simpa only [build_value] using ht)
  apply rounds_allWidths _ _ _ _ (initial_allWidths xs) t hm
  rw [initial_bits]
  simp only [initial,List.length_map,le_refl]

theorem built_descendWork (xs : List (α × List Bool)) (t : SumTree α)
    (ht : (build xs).1=some t) (target : List Bool)
    (hw : target.length ≤ inputBits xs+xs.length) :
    descendWork t target ≤ 32*(inputBits xs+xs.length+1)*(xs.length.size+1) := by
  have h := descendWork_bound t target _ (build_allWidths xs t ht) hw
  have hh := (build_spec xs t ht).2.2
  exact h.trans (Nat.mul_le_mul_left _ (Nat.add_le_add_right hh 1))

end BinaryMultiplicity.SumTree
