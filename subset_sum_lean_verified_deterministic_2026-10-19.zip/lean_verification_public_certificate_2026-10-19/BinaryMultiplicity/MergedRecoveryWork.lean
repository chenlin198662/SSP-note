import BinaryMultiplicity.MergedRecovery
import BinaryMultiplicity.SparseMergeWork

namespace BinaryMultiplicity.Recovery
open Optss

theorem recoverOne_work (g : List Entry) (count : List Bool)
    (hcanon : ∀x∈g,BitListCanonical x.count)
    (hc : binaryDigitsValue count ≤ (mergedEntry g).capacity) :
    recoverOneWork (mergeGroup g).1 (bitListTrim count) ≤
      64*(g.length.size+1)*(countBits g+g.length)+4 := by
  cases ht : (SumTree.build (g.map (fun x => (x,x.count)))).1 with
  | none => simp [recoverOneWork,mergeGroup,ht]
  | some tree =>
    have hb : binaryDigitsValue (bitListTrim count) ≤ binaryDigitsValue tree.word := by
      simpa only [bitListTrim_value,mergedEntry,mergeGroup,ht,Entry.capacity] using hc
    have h := SumTree.built_allocateWork (g.map (fun x => (x,x.count))) tree ht
      (by intro x hx; obtain ⟨y,hy,rfl⟩:=List.mem_map.mp hx; exact hcanon y hy)
      _ (bitListTrim_canonical _) hb
    simp only [List.length_map,SumTree.inputBits,List.map_map,Function.comp_def] at h
    simp only [recoverOneWork,mergeGroup,ht]
    exact Nat.add_le_add_right h 4

theorem recoverMany_work (groups : List (List Entry)) (m : ℕ)
    (hne : ∀g∈groups,g≠[]) (hlen : ∀g∈groups,g.length ≤ m)
    (hcanon : ∀g∈groups,∀x∈g,BitListCanonical x.count)
    (counts : List (List Bool)) (t : ℤ)
    (hw : BitWitness (groups.map mergedEntry) counts t) :
    recoverManyWork (groups.map (fun g => (mergeGroup g).1)) counts ≤
      64*(m.size+1)*((groups.map countBits).sum+(groups.map List.length).sum)+
      4*(groups.map List.length).sum+16*groups.length+wordBits counts+1 := by
  induction groups generalizing counts t with
  | nil => simp [recoverManyWork,wordBits]
  | cons g gs ih =>
    cases counts with
    | nil => cases hw
    | cons c cs =>
      cases hw with
      | cons hc ht =>
        have hg := recoverOne_work g c (hcanon g List.mem_cons_self) hc
        have hs := Nat.size_le_size (hlen g List.mem_cons_self)
        have hm := Nat.mul_le_mul_right (countBits g+g.length)
          (Nat.mul_le_mul_left 64 (Nat.add_le_add_right hs 1))
        have hspec := recoverOne_spec g (hne g List.mem_cons_self) (bitListTrim c)
          (by simpa only [bitListTrim_value] using hc)
        have hl := congrArg List.length hspec.1
        simp only [List.length_map] at hl
        have hh := ih (fun x hx => hne x (List.mem_cons_of_mem _ hx))
          (fun x hx => hlen x (List.mem_cons_of_mem _ hx))
          (fun x hx => hcanon x (List.mem_cons_of_mem _ hx)) cs _ ht
        simp only [List.map_cons,List.sum_cons,List.length_cons,recoverManyWork,wordBits,
          bitListTrimVisits_eq,hl] at *
        nlinarith only [hg,hm,hh]

/-- Reconstruction from the cached original merge trees has aggregate
linear-times-logarithmic work, plus reading the supplied selected counts. -/
theorem merged_recovery_work (xs : List Entry) (counts : List (List Bool)) (t : ℤ)
    (hw : BitWitness (merged xs) counts t) :
    recoverManyWork (merge xs).1 counts ≤
      64*(xs.length.size+1)*(inputSize xs+xs.length)+20*xs.length+wordBits counts+1 := by
  have hc : ∀g∈grouped xs,∀x∈g,BitListCanonical x.count := by
    intro g hg x hx
    have hm : x∈normalized xs := (grouped_partition xs).mem_iff.mp (List.mem_flatten.mpr ⟨g,hg,hx⟩)
    obtain ⟨y,hy,rfl⟩ := List.mem_map.mp hm
    exact bitListTrim_canonical _
  rw [merged_eq] at hw
  have h := recoverMany_work (grouped xs) xs.length (Trie.groups_nonempty _)
    (grouped_member_length xs) hc counts t hw
  rw [grouped_lengths xs] at h
  have hm := Nat.mul_le_mul_left (64*(xs.length.size+1))
    (Nat.add_le_add_right (grouped_countBits xs) xs.length)
  have hg := grouped_length xs
  have he : (merge xs).1=(grouped xs).map (fun g => (mergeGroup g).1) := by
    simp only [merge,List.map_map,Function.comp_def]
  rw [he]
  omega

end BinaryMultiplicity.Recovery
