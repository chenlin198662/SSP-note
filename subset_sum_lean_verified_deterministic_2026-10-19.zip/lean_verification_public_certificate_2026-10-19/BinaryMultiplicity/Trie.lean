import Mathlib.Data.List.Perm.Basic
import Mathlib.Data.List.Basic
import Mathlib.Tactic

/-! A sparse Boolean-key grouping table. No numerical weight interval is
enumerated. Payloads are stored pointers; insertion never adds multiplicities.
Equal-key multiplicities are summed later by a balanced tree. -/
namespace BinaryMultiplicity

inductive Trie (α : Type*) where
  | empty
  | node (here : List α) (zero one : Trie α)
  deriving Inhabited

namespace Trie
variable {α : Type*}

def insert (key : List Bool) (value : α) : Trie α → Trie α
  | .empty => match key with
    | [] => .node [value] .empty .empty
    | false::ks => .node [] (insert ks value .empty) .empty
    | true::ks => .node [] .empty (insert ks value .empty)
  | .node here zero one => match key with
    | [] => .node (value::here) zero one
    | false::ks => .node here (insert ks value zero) one
    | true::ks => .node here zero (insert ks value one)
termination_by key.length

def lookup (key : List Bool) : Trie α → List α
  | .empty => []
  | .node here zero one => match key with
    | [] => here
    | false::ks => lookup ks zero
    | true::ks => lookup ks one

def flatten : Trie α → List α
  | .empty => []
  | .node here zero one => here++flatten zero++flatten one

def nodes : Trie α → ℕ
  | .empty => 0
  | .node _ zero one => 1+nodes zero+nodes one

/-- Constant work per key cell and terminal visit. Payloads and count digits
are not copied or summed by insertion. Pointer bit overhead is separate. -/
def insertWork (key : List Bool) : ℕ := 12*(key.length+1)

theorem lookup_insert_same (key : List Bool) (v : α) (t : Trie α) :
    lookup key (insert key v t)=v::lookup key t := by
  induction key generalizing t with
  | nil => cases t <;> simp [insert,lookup]
  | cons b ks ih => cases b <;> cases t <;> simp [insert,lookup,ih]

theorem lookup_insert_other (key other : List Bool) (v : α) (t : Trie α)
    (h : other≠key) : lookup other (insert key v t)=lookup other t := by
  induction key generalizing t other with
  | nil =>
      cases other with
      | nil => exact (h rfl).elim
      | cons b bs => cases b <;> cases t <;> simp [insert,lookup]
  | cons b ks ih =>
      cases other with
      | nil => cases b <;> cases t <;> simp [insert,lookup]
      | cons c cs =>
        cases b <;> cases c <;> cases t <;> simp_all [insert,lookup]

theorem lookup_insert (key other : List Bool) (v : α) (t : Trie α) :
    lookup other (insert key v t)=if other=key then v::lookup other t else lookup other t := by
  by_cases h : other=key
  · subst other; simp [lookup_insert_same]
  · simp [h,lookup_insert_other key other v t h]

theorem flatten_insert (key : List Bool) (v : α) (t : Trie α) :
    (flatten (insert key v t)).Perm (v::flatten t) := by
  induction key generalizing t with
  | nil => cases t <;> simp [insert,flatten]
  | cons b ks ih =>
      cases b <;> cases t with
      | empty => simpa [insert,flatten] using ih (.empty : Trie α)
      | node here zero one =>
        simp only [insert,flatten]
        first
        | exact ((ih zero).append_left here |>.append_right (flatten one)).trans
            (by simp only [List.append_assoc]; exact List.perm_middle)
        | exact ((ih one).append_left (here++flatten zero)).trans List.perm_middle

theorem nodes_insert (key : List Bool) (v : α) (t : Trie α) :
    nodes (insert key v t) ≤ nodes t+key.length+1 := by
  induction key generalizing t with
  | nil => cases t <;> simp [insert,nodes]
  | cons b ks ih =>
      cases b <;> cases t with
      | empty => have h := ih (.empty : Trie α); simp only [insert,nodes,List.length_cons] at *; omega
      | node here zero one => simp only [insert,nodes,List.length_cons]; first | have := ih zero; omega | have := ih one; omega

def build (key : α → List Bool) : List α → Trie α
  | [] => .empty
  | x::xs => insert (key x) x (build key xs)

def buildWork (key : α → List Bool) : List α → ℕ
  | [] => 1
  | x::xs => insertWork (key x)+4+buildWork key xs

theorem lookup_build (key : α → List Bool) (xs : List α) (k : List Bool) :
    lookup k (build key xs)=xs.filter (fun x => decide (k=key x)) := by
  induction xs with
  | nil => simp [build,lookup]
  | cons x xs ih => simp [build,lookup_insert,ih,List.filter_cons]

theorem flatten_build (key : α → List Bool) (xs : List α) :
    (flatten (build key xs)).Perm xs := by
  induction xs with
  | nil => exact List.Perm.refl []
  | cons x xs ih => exact (flatten_insert (key x) x (build key xs)).trans (ih.cons x)

def keyBits (key : α → List Bool) (xs : List α) : ℕ :=
  (xs.map (fun x => (key x).length+1)).sum

theorem nodes_build (key : α → List Bool) (xs : List α) :
    nodes (build key xs) ≤ keyBits key xs := by
  induction xs with
  | nil => simp [build,nodes,keyBits]
  | cons x xs ih =>
      have h := nodes_insert (key x) x (build key xs)
      simp only [build,keyBits,List.map_cons,List.sum_cons] at *
      omega

theorem buildWork_bound (key : α → List Bool) (xs : List α) :
    buildWork key xs ≤ 1+16*keyBits key xs := by
  induction xs with
  | nil => simp [buildWork,keyBits]
  | cons x xs ih => simp only [buildWork,insertWork,keyBits,List.map_cons,List.sum_cons] at *; omega

end Trie
end BinaryMultiplicity
