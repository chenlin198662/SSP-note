import BinaryMultiplicity.Pivot
import BinaryMultiplicity.Residual

namespace BinaryMultiplicity.AnchorRows
open Optss

def nodes : SumTree Entry → ℕ
  | .leaf _ _ => 1
  | .node _ l r => nodes l+nodes r+1

/-- Tail-passing traversal, with count words shared from the stored input. -/
def rows (count : Entry → List Bool) : SumTree Entry → List (Entry × List Bool) → List (Entry × List Bool)
  | .leaf a _,tail => (a,count a)::tail
  | .node _ l r,tail => rows count l (rows count r tail)

theorem rows_eq (count : Entry → List Bool) (tree : SumTree Entry) (tail : List (Entry × List Bool)) :
    rows count tree tail=tree.entries.map (fun x => (x.1,count x.1))++tail := by
  induction tree generalizing tail with
  | leaf a w => rfl
  | node w l r il ir => simp [rows,SumTree.entries,il,ir,List.map_append,List.append_assoc]

def fillAcc : SumTree Entry → List Bool → List Bool → List (Entry × List Bool) → List (Entry × List Bool)
  | .leaf a _,_,q,tail => (a,q)::tail
  | .node _ l r,[],_,tail => rows (fun _ => []) l (rows (fun _ => []) r tail)
  | .node _ l r,b::bs,q,tail =>
      if b then rows Entry.count l (fillAcc r bs q tail)
      else fillAcc l bs q (rows (fun _ => []) r tail)

def fill (tree : SumTree Entry) (path q : List Bool) : List (Entry × List Bool) :=
  fillAcc tree path q []

theorem fillAcc_append (tree : SumTree Entry) (path q : List Bool) (tail : List (Entry × List Bool)) :
    fillAcc tree path q tail=fill tree path q++tail := by
  induction tree generalizing path tail with
  | leaf a w => rfl
  | node w l r il ir =>
      change fillAcc (.node w l r) path q tail=fillAcc (.node w l r) path q []++tail
      cases path with
      | nil => simp [fillAcc,fill,rows_eq,List.append_assoc]
      | cons b bs =>
          cases b with
          | false =>
              simp only [fillAcc,Bool.false_eq_true,if_false]
              rw [il,il,rows_eq,rows_eq]
              simp only [List.append_nil,List.append_assoc]
          | true =>
              simp only [fillAcc,if_true]
              rw [rows_eq,rows_eq,ir,ir]
              simp only [List.append_nil,List.append_assoc]

theorem fill_node_false (w : List Bool) (l r : SumTree Entry) (path q : List Bool) :
    fill (.node w l r) (false::path) q=
      fill l path q++r.entries.map (fun x => (x.1,[])) := by
  change fillAcc l path q (rows (fun _ => []) r [])=_
  rw [fillAcc_append,rows_eq,List.append_nil]

theorem fill_node_true (w : List Bool) (l r : SumTree Entry) (path q : List Bool) :
    fill (.node w l r) (true::path) q=
      l.entries.map (fun x => (x.1,x.1.count))++fill r path q := by
  simp [fill,fillAcc,rows_eq]

theorem fill_order (tree : SumTree Entry) (path q : List Bool) :
    (fill tree path q).map Prod.fst=tree.entries.map Prod.fst := by
  induction tree generalizing path with
  | leaf a w => rfl
  | node w l r il ir =>
      cases path with
      | nil => simp [fill,fillAcc,rows_eq,SumTree.entries,List.map_map,Function.comp_def]
      | cons b bs => cases b <;>
          simp [fill_node_false,fill_node_true,SumTree.entries,il,ir,List.map_map,Function.comp_def]

def rowsWork (tree : SumTree Entry) : ℕ := 4*nodes tree

def fillWork : SumTree Entry → List Bool → ℕ
  | .leaf _ _,_ => 4
  | .node _ l r,[] => rowsWork l+rowsWork r+4
  | .node _ l r,b::bs =>
      6+if b then rowsWork l+fillWork r bs else fillWork l bs+rowsWork r

theorem fillWork_bound (tree : SumTree Entry) (path : List Bool) :
    fillWork tree path≤6*nodes tree := by
  induction tree generalizing path with
  | leaf a w => simp [fillWork,nodes]
  | node w l r il ir =>
      cases path with
      | nil => simp [fillWork,rowsWork,nodes]; omega
      | cons b bs =>
          have hl := il bs
          have hr := ir bs
          cases b <;> simp [fillWork,rowsWork,nodes] <;> omega

theorem nodes_eq (tree : SumTree Entry) : nodes tree+1=2*tree.entries.length := by
  induction tree with
  | leaf a w => rfl
  | node w l r il ir => simp only [nodes,SumTree.entries,List.length_append]; omega

theorem fillWork_linear (tree : SumTree Entry) (path : List Bool) :
    fillWork tree path≤12*tree.entries.length := by
  have h := fillWork_bound tree path
  have hn := nodes_eq tree
  omega

end BinaryMultiplicity.AnchorRows
