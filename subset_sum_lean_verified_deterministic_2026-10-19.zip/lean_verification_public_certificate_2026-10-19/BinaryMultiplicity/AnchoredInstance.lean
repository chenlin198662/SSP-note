import BinaryMultiplicity.AnchorSpec
import BinaryMultiplicity.Cap
import BinaryMultiplicity.Complement

namespace BinaryMultiplicity.AnchoredInstance
open Optss

def positiveRows (rows : List (Entry × List Bool)) : List (Entry × List Bool) :=
  rows.map (fun x => (positiveEntry x.1,x.2))

theorem positiveRows_anchor (rows : List (Entry × List Bool)) :
    anchorValue (positiveRows rows)=(AnchorRows.total rows:ℤ) := by
  simp [positiveRows,anchorValue,AnchorRows.total,positive_value,
    WeightedTotals.magnitude,List.map_map,Function.comp_def,Nat.cast_sum,Nat.cast_mul]

structure Output where
  pivot : Pivot
  anchor : List (Entry × List Bool)
  residual : List Entry
  capped : List Entry
  work : ℕ

def run (tree : SumTree Entry) (target limit : List Bool) : Output :=
  let pivot := Pivot.run tree target
  let raw := AnchorRows.fill tree pivot.path pivot.anchor
  let anchor := positiveRows raw
  let residual := residualRows anchor
  let capped := capRows limit residual
  ⟨pivot,anchor,residual,capped,
    Pivot.work tree target+AnchorRows.fillWork tree pivot.path+
    (anchor.map (fun x => residualPairWork x.1 x.2)).sum+
    (residual.map (capEntryWork limit)).sum+12*raw.length+8⟩

theorem residualRows_value_bound (rows : List (Entry × List Bool)) (N : ℕ)
    (hv : ∀x∈rows,-(N:ℤ) ≤ x.1.value ∧ x.1.value ≤ N) :
    ∀x∈residualRows rows,-(N:ℤ) ≤ x.value ∧ x.value ≤ N := by
  intro x hx
  obtain ⟨y,hy,hxy⟩ := List.mem_flatMap.mp hx
  have h := hv y hy
  simp only [residualPair,List.mem_cons,List.not_mem_nil,or_false] at hxy
  rcases hxy with rfl|rfl
  · rw [negativeResidual_value]; omega
  · rw [positiveResidual_value]; exact h

theorem run_correct (xs : List Entry) (tree : SumTree Entry)
    (htree : (WeightedTotals.run xs).full=some tree)
    (target limit : List Bool) (N : ℕ) (hN : 0<N)
    (htarget : binaryDigitsValue target<WeightedTotals.total xs)
    (hlimit : binaryDigitsValue limit=2*N)
    (hweights : ∀x∈xs,WeightedTotals.magnitude x ≤ N) :
    let out := run tree target limit
    (Feasible out.capped (binaryDigitsValue out.pivot.residual) ↔
      Feasible (positiveEntries xs) (binaryDigitsValue target)) ∧
    binaryDigitsValue out.pivot.residual<N := by
  dsimp only
  obtain ⟨before,after,he,hprefix,hq,hr⟩ := Pivot.run_spec xs tree htree target htarget
  let p := Pivot.run tree target
  let raw := AnchorRows.fill tree p.path p.anchor
  have hs := WeightedTotals.full_spec xs tree htree
  have hw := AnchorRows.weightedTree_weights xs tree htree
  have htotal := WeightedTotals.full_value xs
  simp only [htree,WeightedTotals.storedWord] at htotal
  have ht : binaryDigitsValue target<binaryDigitsValue tree.word := by rwa [htotal]
  have hb : ∀x∈raw,binaryDigitsValue x.2 ≤ x.1.capacity :=
    AnchorRows.fill_bounds tree target p.anchor hq.le
  have horder : (raw.map Prod.fst)=xs := by
    rw [show raw=AnchorRows.fill tree p.path p.anchor from rfl,AnchorRows.fill_order,hs.1]
    simp [WeightedTotals.weightedLeaves,List.map_map,Function.comp_def]
  have hposorder : (positiveRows raw).map Prod.fst=positiveEntries xs := by
    calc
      _=(raw.map Prod.fst).map positiveEntry := by simp only [positiveRows,List.map_map]; rfl
      _=positiveEntries xs := by rw [horder]; rfl
  have hbpos : ∀x∈positiveRows raw,binaryDigitsValue x.2 ≤ x.1.capacity := by
    intro x hx
    obtain ⟨y,hy,rfl⟩ := List.mem_map.mp hx
    exact hb y hy
  have hmag : WeightedTotals.magnitude p.entry ≤ N := by
    apply hweights
    rw [he]; simp [p]
  have hsmall : binaryDigitsValue p.residual<N := hr.trans_le hmag
  have hfill := AnchorRows.fill_total tree hs.2.1 hw target p.anchor ht
  have hd : 0<binaryDigitsValue (tree.descend target).payload.weight.digits := by
    change 0<WeightedTotals.magnitude p.entry
    have hr' : binaryDigitsValue p.residual<WeightedTotals.magnitude p.entry := hr
    omega
  have hdiv := bitListDivision_correct (tree.descend target).residual
    (tree.descend target).payload.weight.digits hd
  have hdivision : binaryDigitsValue p.anchor*WeightedTotals.magnitude p.entry+
      binaryDigitsValue p.residual=binaryDigitsValue (tree.descend target).residual := by
    dsimp only [p,Pivot.run,WeightedTotals.magnitude]
    rw [hdiv.1,hdiv.2]
    nlinarith only [Nat.mod_add_div (binaryDigitsValue (tree.descend target).residual)
      (binaryDigitsValue (tree.descend target).payload.weight.digits)]
  have hsum : AnchorRows.total raw+binaryDigitsValue p.residual=binaryDigitsValue target := by
    change AnchorRows.total raw+binaryDigitsValue (tree.descend target).residual=
      binaryDigitsValue target+binaryDigitsValue p.anchor*WeightedTotals.magnitude p.entry at hfill
    omega
  have hz : (binaryDigitsValue p.residual:ℤ)+anchorValue (positiveRows raw)=binaryDigitsValue target := by
    rw [positiveRows_anchor]
    exact_mod_cast (by omega : binaryDigitsValue p.residual+AnchorRows.total raw=binaryDigitsValue target)
  have hvals : ∀x∈positiveRows raw,-(N:ℤ) ≤ x.1.value ∧ x.1.value ≤ N := by
    intro x hx
    obtain ⟨y,hy,rfl⟩ := List.mem_map.mp hx
    have hym : y.1∈xs := by rw [←horder]; exact List.mem_map.mpr ⟨y,hy,rfl⟩
    have hymag := hweights y.1 hym
    rw [positive_value]
    constructor
    · exact (neg_nonpos.mpr (Nat.cast_nonneg N)).trans (Nat.cast_nonneg _)
    · exact_mod_cast hymag
  have hres := residualRows_feasible (positiveRows raw) hbpos (binaryDigitsValue p.residual)
  rw [hposorder,hz] at hres
  have hcap := capRows_feasible (residualRows (positiveRows raw)) limit N hlimit hN
    (residualRows_value_bound _ N hvals) (binaryDigitsValue p.residual)
    ⟨by positivity,by exact_mod_cast hsmall⟩
  exact ⟨hcap.symm.trans hres,hsmall⟩

end BinaryMultiplicity.AnchoredInstance
