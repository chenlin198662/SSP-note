import BinaryMultiplicity.CountSemantics
import BinaryMultiplicity.Crossing

namespace BinaryMultiplicity
open Optss

def negativeResidual (x : Entry) (q : List Bool) : Entry := ⟨bitListIntegerNeg x.weight,q⟩
def positiveResidual (x : Entry) (q : List Bool) : Entry :=
  ⟨x.weight,bitListTrim (bitListSub x.count q)⟩
def residualPair (x : Entry) (q : List Bool) : List Entry :=
  [negativeResidual x q,positiveResidual x q]

theorem negativeResidual_value (x : Entry) (q : List Bool) :
    (negativeResidual x q).value= -x.value := bitListIntegerNeg_value _
theorem positiveResidual_value (x : Entry) (q : List Bool) :
    (positiveResidual x q).value=x.value := rfl
theorem positiveResidual_capacity (x : Entry) (q : List Bool) :
    (positiveResidual x q).capacity=x.capacity-binaryDigitsValue q := by
  exact (bitListTrim_value _).trans (bitListSub_correct _ _)

/-- The two residual multiplicities are the literal binary subtraction
outputs. A residual witness reconstructs an original count in range. -/
theorem residualPair_feasible (x : Entry) (q : List Bool)
    (hq : binaryDigitsValue q≤x.capacity) (r : ℤ) :
    Feasible (residualPair x q) r ↔
      Feasible [x] (r+(binaryDigitsValue q:ℤ)*x.value) := by
  rw [residualPair,feasible_cons]
  simp only [feasible_singleton]
  simp only [negativeResidual_value,positiveResidual_value,positiveResidual_capacity]
  change (∃a≤binaryDigitsValue q,∃s,(∃b≤x.capacity-binaryDigitsValue q,
    (b:ℤ)*x.value=s) ∧ (a:ℤ)*(-x.value)+s=r) ↔ _
  constructor
  · rintro ⟨a,ha,s,⟨b,hb,he⟩,hs⟩
    refine ⟨binaryDigitsValue q-a+b,by omega,?_⟩
    rw [Nat.cast_add,Int.ofNat_sub ha]
    linear_combination hs+he
  · rintro ⟨n,hn,he⟩
    by_cases hqn : binaryDigitsValue q≤n
    · refine ⟨0,by omega,((n-binaryDigitsValue q:ℕ):ℤ)*x.value,
        ⟨n-binaryDigitsValue q,by omega,rfl⟩,?_⟩
      rw [Int.ofNat_sub hqn]
      linear_combination he
    · have hnq : n≤binaryDigitsValue q := by omega
      refine ⟨binaryDigitsValue q-n,by omega,0,⟨0,by omega,by simp⟩,?_⟩
      rw [Int.ofNat_sub hnq]
      linear_combination he

def residualRows (xs : List (Entry × List Bool)) : List Entry :=
  xs.flatMap (fun x => residualPair x.1 x.2)
def anchorValue (xs : List (Entry × List Bool)) : ℤ :=
  (xs.map (fun x => (binaryDigitsValue x.2:ℤ)*x.1.value)).sum

theorem residualRows_feasible (xs : List (Entry × List Bool))
    (hb : ∀x∈xs,binaryDigitsValue x.2≤x.1.capacity) (r : ℤ) :
    Feasible (residualRows xs) r ↔ Feasible (xs.map Prod.fst) (r+anchorValue xs) := by
  induction xs generalizing r with
  | nil => simp [residualRows,anchorValue,feasible_nil]
  | cons x xs ih =>
      have hx := hb x List.mem_cons_self
      have hh := ih (fun y hy => hb y (List.mem_cons_of_mem _ hy))
      simp only [residualRows,List.flatMap_cons,feasible_append,List.map_cons,anchorValue,List.sum_cons]
      change (∃a b,Feasible (residualPair x.1 x.2) a ∧ Feasible (residualRows xs) b ∧ a+b=r) ↔
        Feasible ([x.1]++xs.map Prod.fst) (r+((binaryDigitsValue x.2:ℤ)*x.1.value+anchorValue xs))
      rw [feasible_append]
      constructor
      · rintro ⟨a,b,ha,hb,he⟩
        refine ⟨a+(binaryDigitsValue x.2:ℤ)*x.1.value,b+anchorValue xs,
          (residualPair_feasible x.1 x.2 hx a).mp ha,(hh b).mp hb,?_⟩
        omega
      · rintro ⟨a,b,ha,hb,he⟩
        refine ⟨a-(binaryDigitsValue x.2:ℤ)*x.1.value,b-anchorValue xs,
          (residualPair_feasible x.1 x.2 hx _).mpr ?_,(hh _).mpr ?_,by omega⟩
        · simpa using ha
        · simpa using hb

def residualPairWork (x : Entry) (q : List Bool) : ℕ :=
  SumTree.subtractWork x.count q+12

theorem residualPairWork_bound (x : Entry) (q : List Bool) :
    residualPairWork x q ≤ 10*(x.count.length+q.length)+18 := by
  have h := SumTree.subtractWork_bound x.count q (x.count.length+q.length)
    (by omega) (by omega)
  dsimp only [residualPairWork]
  omega

end BinaryMultiplicity
