import BinaryMultiplicity.Crossing
import BinaryMultiplicity.BuildSumTree

namespace BinaryMultiplicity.SumTree
open Optss
variable {α : Type}

/-- Reconstruct a chosen merged multiplicity using cached balanced capacity
totals. Each output is a binary count for one original record. -/
def allocate : SumTree α → List Bool → List (α × List Bool)
  | .leaf a _,target => [(a,bitListTrim target)]
  | .node _ left right,target =>
      if bitListLE left.word target then
        allocate left left.word++allocate right (bitListTrim (bitListSub target left.word))
      else
        allocate left target++allocate right []

def CountsBound (xs ys : List (α × List Bool)) : Prop :=
  List.Forall₂ (fun x y => x.1=y.1 ∧ binaryDigitsValue y.2≤binaryDigitsValue x.2) xs ys

theorem CountsBound.append {xs ys zs ws : List (α × List Bool)}
    (h : CountsBound xs ys) (g : CountsBound zs ws) : CountsBound (xs++zs) (ys++ws) := by
  induction h with
  | nil => exact g
  | cons hab h ih => exact List.Forall₂.cons hab ih

theorem CountsBound.order {xs ys : List (α × List Bool)} (h : CountsBound xs ys) :
    ys.map Prod.fst=xs.map Prod.fst := by
  induction h with
  | nil => rfl
  | cons hab h ih => simp only [List.map_cons]; exact congrArg₂ List.cons hab.1.symm ih

theorem allocate_spec (tree : SumTree α) (ht : tree.Valid) (target : List Bool)
    (hq : binaryDigitsValue target≤binaryDigitsValue tree.word) :
    CountsBound tree.entries (allocate tree target) ∧
      sumWords (allocate tree target)=binaryDigitsValue target := by
  induction tree generalizing target with
  | leaf a w =>
      refine ⟨List.Forall₂.cons ⟨rfl,?_⟩ List.Forall₂.nil,?_⟩
      · simpa only [bitListTrim_value] using hq
      · simp [allocate,sumWords,bitListTrim_value]
  | node w l r il ir =>
      obtain ⟨hl,hr,he⟩ := ht
      change binaryDigitsValue target≤binaryDigitsValue w at hq
      by_cases hc : bitListLE l.word target=true
      · have hle := (bitListLE_correct l.word target).mp hc
        have hs : binaryDigitsValue (bitListTrim (bitListSub target l.word))=
            binaryDigitsValue target-binaryDigitsValue l.word := by
          rw [bitListTrim_value,bitListSub_correct]
        have hb : binaryDigitsValue (bitListTrim (bitListSub target l.word))≤binaryDigitsValue r.word := by
          rw [hs]; omega
        have hleft := il hl l.word (le_refl _)
        have hright := ir hr _ hb
        simp only [allocate,if_pos hc,entries]
        refine ⟨CountsBound.append hleft.1 hright.1,?_⟩
        simp only [sumWords,List.map_append,List.sum_append] at hleft hright ⊢
        rw [hleft.2,hright.2,hs]
        omega
      · have hlt : binaryDigitsValue target<binaryDigitsValue l.word := by
          have hn : ¬binaryDigitsValue l.word≤binaryDigitsValue target :=
            fun h => hc ((bitListLE_correct _ _).mpr h)
          omega
        have hleft := il hl target hlt.le
        have hright := ir hr [] (by simp [binaryDigitsValue])
        simp only [allocate,if_neg hc,entries]
        refine ⟨CountsBound.append hleft.1 hright.1,?_⟩
        simp only [sumWords,List.map_append,List.sum_append] at hleft hright ⊢
        rw [hleft.2,hright.2]
        simp [binaryDigitsValue]

theorem allocate_length (tree : SumTree α) (target : List Bool) :
    (allocate tree target).length=tree.entries.length := by
  induction tree generalizing target with
  | leaf a w => rfl
  | node w l r il ir =>
      simp only [allocate]
      split <;> simp [entries,il,ir]

def allocateWork : SumTree α → List Bool → ℕ
  | .leaf _ _,target => bitListTrimVisits target+4
  | .node _ left right,target =>
      compareWork target left.word+4*left.entries.length+12+
        if bitListLE left.word target then
          subtractWork target left.word+allocateWork left left.word+
            allocateWork right (bitListTrim (bitListSub target left.word))
        else allocateWork left target+allocateWork right []

/-- Exact reconstructed order is the original record order, including zero
counts. The later runtime need not search a merged dictionary for each record. -/
theorem allocate_order (tree : SumTree α) (ht : tree.Valid) (target : List Bool)
    (hq : binaryDigitsValue target≤binaryDigitsValue tree.word) :
    (allocate tree target).map Prod.fst=tree.entries.map Prod.fst := by
  exact (allocate_spec tree ht target hq).1.order

end BinaryMultiplicity.SumTree
