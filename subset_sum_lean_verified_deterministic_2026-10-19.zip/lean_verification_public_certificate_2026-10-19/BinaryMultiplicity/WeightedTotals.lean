import BinaryMultiplicity.FastProduct
import BinaryMultiplicity.TreeWidths

namespace BinaryMultiplicity.WeightedTotals
open Optss

def magnitude (x : Entry) : ℕ := binaryDigitsValue x.weight.digits
def weight (x : Entry) : ℕ := magnitude x*x.capacity
def total (xs : List Entry) : ℕ := (xs.map weight).sum
def negative (xs : List Entry) : ℕ :=
  (xs.map (fun x => if x.weight.negative then weight x else 0)).sum

def weightedLeaves (xs : List Entry) : List (Entry × List Bool) :=
  xs.map (fun x => (x,FastProduct.run x.weight.digits x.count))

def negativeLeaves (xs : List (Entry × List Bool)) : List (Entry × List Bool) :=
  xs.map (fun x => (x.1,if x.1.weight.negative then x.2 else []))

structure Output where
  full : Option (SumTree Entry)
  negative : Option (SumTree Entry)
  work : ℕ

/-- Products are computed once and shared by the two balanced total trees. -/
def run (xs : List Entry) : Output :=
  let leaves := weightedLeaves xs
  let full := SumTree.build leaves
  let neg := SumTree.build (negativeLeaves leaves)
  ⟨full.1,neg.1,
    (xs.map (fun x => FastProduct.work x.weight.digits x.count)).sum+
    full.2+neg.2+12*xs.length+8⟩

def storedWord (t : Option (SumTree Entry)) : List Bool :=
  match t with |none=>[]|some t=>t.word

theorem full_value (xs : List Entry) :
    binaryDigitsValue (storedWord (run xs).full)=total xs := by
  have h := SumTree.total_value (weightedLeaves xs)
  dsimp only [run,storedWord]
  cases hb : (SumTree.build (weightedLeaves xs)).1 <;>
    simp only [SumTree.total,hb] at h ⊢ <;> rw [h] <;>
    simp [weightedLeaves,total,weight,magnitude,Entry.capacity,FastProduct.run_value,List.map_map,Function.comp_def] <;> rfl

theorem negative_value (xs : List Entry) :
    binaryDigitsValue (storedWord (run xs).negative)=negative xs := by
  have h := SumTree.total_value (negativeLeaves (weightedLeaves xs))
  have he : binaryDigitsValue (storedWord (run xs).negative)=
      ((negativeLeaves (weightedLeaves xs)).map (fun x => binaryDigitsValue x.2)).sum := by
    dsimp only [run,storedWord]
    cases hb : (SumTree.build (negativeLeaves (weightedLeaves xs))).1 <;>
      simpa only [SumTree.total,hb] using h
  rw [he]
  simp only [negativeLeaves,weightedLeaves,List.map_map,negative,Function.comp_def]
  congr 1
  apply List.map_congr_left
  intro x hx
  cases hs : x.weight.negative <;> simp [hs,weight,magnitude,Entry.capacity,FastProduct.run_value,binaryDigitsValue]

theorem weighted_width (xs : List Entry) :
    SumTree.inputBits (weightedLeaves xs) ≤ (xs.map Entry.bits).sum := by
  induction xs with
  | nil => simp [weightedLeaves,SumTree.inputBits]
  | cons x xs ih =>
      have hw := FastProduct.run_length x.weight.digits x.count
      simp only [weightedLeaves,SumTree.inputBits,List.map_cons,List.sum_cons,Entry.bits] at *
      omega

theorem negative_width (xs : List (Entry × List Bool)) :
    SumTree.inputBits (negativeLeaves xs) ≤ SumTree.inputBits xs := by
  induction xs with
  | nil => simp [negativeLeaves,SumTree.inputBits]
  | cons x xs ih =>
      cases hs : x.1.weight.negative <;>
        simp_all [hs,negativeLeaves,SumTree.inputBits] <;> omega

theorem full_spec (xs : List Entry) (tree : SumTree Entry) (ht : (run xs).full=some tree) :
    tree.entries=weightedLeaves xs ∧ tree.Valid ∧ tree.height ≤ xs.length.size ∧
      tree.AllWidths (SumTree.inputBits (weightedLeaves xs)+xs.length) := by
  have hs := SumTree.build_spec (weightedLeaves xs) tree ht
  have hw := SumTree.build_allWidths (weightedLeaves xs) tree ht
  have hl : (weightedLeaves xs).length=xs.length := by simp [weightedLeaves]
  rw [hl] at hs hw
  exact ⟨hs.1,hs.2.1,hs.2.2,hw⟩

def workBudget (xs : List Entry) : ℕ :=
  (xs.map (fun x => FastProduct.work x.weight.digits x.count)).sum+
  SumTree.buildBudget xs.length (SumTree.inputBits (weightedLeaves xs))+
  SumTree.buildBudget xs.length (SumTree.inputBits (negativeLeaves (weightedLeaves xs)))+
  12*xs.length+8

theorem run_work (xs : List Entry) : (run xs).work ≤ workBudget xs := by
  have hf := SumTree.build_work (weightedLeaves xs)
  have hn := SumTree.build_work (negativeLeaves (weightedLeaves xs))
  have hl : (weightedLeaves xs).length=xs.length := by simp [weightedLeaves]
  have hl' : (negativeLeaves (weightedLeaves xs)).length=xs.length := by
    simp [negativeLeaves,weightedLeaves]
  rw [hl] at hf
  rw [hl'] at hn
  dsimp only [run,workBudget]
  omega

end BinaryMultiplicity.WeightedTotals
