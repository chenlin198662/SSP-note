import BinaryMultiplicity.BuildSumTree

namespace BinaryMultiplicity.SumTree

theorem buildBudget_linear_log (m B L : ℕ) (hm : m.size≤L) :
    buildBudget m B ≤ 128*(B+m+1)*(L+3)^3 := by
  have hsmall : L+3≤(L+3)^3 := by
    have hp : 0<(L+3)*(L+3) := by positivity
    have h := Nat.mul_le_mul_left (L+3) (show 1≤(L+3)*(L+3) by omega)
    nlinarith only [h]
  have hcube : (m.size+3)^3≤(L+3)^3 := Nat.pow_le_pow_left (by omega) 3
  have hms : m.size≤(L+3)^3 := by omega
  have hm0 : 1≤(L+3)^3 := by omega
  have h1 := Nat.mul_le_mul_left m hms
  have h2 := Nat.mul_le_mul_left B hms
  have h3 := Nat.mul_le_mul_left m hm0
  have h4 := Nat.mul_le_mul_left B hm0
  unfold buildBudget
  nlinarith

theorem build_work_linear_log {α : Type} (xs : List (α × List Bool)) :
    (build xs).2 ≤ 128*(inputBits xs+xs.length+1)*(xs.length.size+3)^3 :=
  (build_work xs).trans (buildBudget_linear_log _ _ _ (le_refl _))

end BinaryMultiplicity.SumTree
