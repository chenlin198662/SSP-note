import BinaryMultiplicity.CountSemantics

namespace BinaryMultiplicity
open Optss

def positiveEntry (x : Entry) : Entry := ⟨⟨false,x.weight.digits⟩,x.count⟩
def positiveEntries (xs : List Entry) : List Entry := xs.map positiveEntry
def negativeOffset (xs : List Entry) : ℤ :=
  (xs.map (fun x => if x.weight.negative then (x.capacity:ℤ)*
    (binaryDigitsValue x.weight.digits:ℤ) else 0)).sum

theorem positive_capacity (x : Entry) : (positiveEntry x).capacity=x.capacity := rfl
theorem positive_value (x : Entry) : (positiveEntry x).value=(binaryDigitsValue x.weight.digits:ℤ) := rfl

/-- Complementing only the negatively signed counts is exact for arbitrary
binary multiplicities. It neither expands counts nor assumes positivity. -/
theorem feasible_positive (xs : List Entry) (t : ℤ) :
    Feasible xs t ↔ Feasible (positiveEntries xs) (t+negativeOffset xs) := by
  induction xs generalizing t with
  | nil => simp [positiveEntries,negativeOffset,feasible_nil]
  | cons x xs ih =>
      simp only [positiveEntries,List.map_cons,feasible_cons,positive_capacity]
      cases hs : x.weight.negative with
      | false =>
          have hv : x.value=(positiveEntry x).value := by
            simp [Entry.value,BitListInteger.value,signedBitsValue,hs,positiveEntry]
          have ho : negativeOffset (x::xs)=negativeOffset xs := by simp [negativeOffset,hs]
          rw [ho,hv]
          constructor
          · rintro ⟨n,hn,s,hf,he⟩
            exact ⟨n,hn,s+negativeOffset xs,(ih s).mp hf,by omega⟩
          · rintro ⟨n,hn,s,hf,he⟩
            refine ⟨n,hn,s-negativeOffset xs,(ih _).mpr ?_,by omega⟩
            simpa using hf
      | true =>
          have hv : x.value= -(positiveEntry x).value := by
            simp [Entry.value,BitListInteger.value,signedBitsValue,hs,positiveEntry]
          have ho : negativeOffset (x::xs)=(x.capacity:ℤ)*(positiveEntry x).value+negativeOffset xs := by
            simp [negativeOffset,hs,positive_value]
          rw [ho,hv]
          constructor
          · rintro ⟨n,hn,s,hf,he⟩
            refine ⟨x.capacity-n,Nat.sub_le _ _,s+negativeOffset xs,(ih s).mp hf,?_⟩
            rw [Int.ofNat_sub hn]
            linear_combination he
          · rintro ⟨n,hn,s,hf,he⟩
            refine ⟨x.capacity-n,Nat.sub_le _ _,s-negativeOffset xs,(ih _).mpr ?_,?_⟩
            · simpa using hf
            · rw [Int.ofNat_sub hn]
              linear_combination he

end BinaryMultiplicity
