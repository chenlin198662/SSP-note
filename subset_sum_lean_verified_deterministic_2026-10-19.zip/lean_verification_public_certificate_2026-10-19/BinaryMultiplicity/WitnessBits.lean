import BinaryMultiplicity.RecoveryWork

namespace BinaryMultiplicity.Recovery
open Optss

theorem BitWitness.wordBits {xs : List Entry} {counts : List (List Bool)} {t : ℤ}
    (hw : BitWitness xs counts t) (hc : ∀c∈counts,BitListCanonical c) :
    wordBits counts ≤ countBits xs := by
  induction xs generalizing counts t with
  | nil =>
    have hl := hw.length
    simp only [List.length_map,List.length_nil] at hl
    have he := List.length_eq_zero.mp hl
    simp [he,Recovery.wordBits,countBits]
  | cons x xs ih =>
    cases counts with
    | nil => cases hw
    | cons c cs =>
      cases hw with
      | cons hb ht =>
        have hc' := hc c List.mem_cons_self
        have hlen : c.length ≤ x.count.length := by
          rw [hc',Nat.size_eq_bits_len]
          exact (Nat.size_le_size hb).trans
            (Nat.size_le.mpr (binaryDigitsValue_lt_pow x.count))
        have hh := ih ht (fun y hy => hc y (List.mem_cons_of_mem _ hy))
        simp only [Recovery.wordBits,countBits,List.map_cons,List.sum_cons] at *
        omega

theorem restoreRows_canonical (rows : List (Entry×List Bool)) (counts : List (List Bool)) :
    ∀c∈restoreRows rows counts,BitListCanonical c := by
  induction rows generalizing counts with
  | nil => simp [restoreRows]
  | cons x rows ih =>
    cases counts with
    | nil =>
      simp only [restoreRows,List.mem_cons]
      intro c hc
      rcases hc with rfl | hc
      · exact bitListTrim_canonical []
      · exact ih [] c hc
    | cons a cs => cases cs with
      | nil =>
        simp only [restoreRows,List.mem_cons]
        intro c hc
        rcases hc with rfl | hc
        · exact bitListTrim_canonical []
        · exact ih [] c hc
      | cons b cs =>
        simp only [restoreRows,List.mem_cons]
        intro c hc
        rcases hc with rfl | hc
        · exact bitListTrim_canonical _
        · exact ih cs c hc

theorem uncomplement_canonical (xs : List Entry) (counts : List (List Bool))
    (hc : ∀c∈counts,BitListCanonical c) :
    ∀c∈uncomplement xs counts,BitListCanonical c := by
  induction xs generalizing counts with
  | nil => simp [uncomplement]
  | cons x xs ih =>
    cases counts with
    | nil =>
      simp only [uncomplement,List.mem_cons]
      intro c hm
      rcases hm with rfl | hm
      · exact bitListTrim_canonical []
      · exact ih [] (by simp) c hm
    | cons a cs =>
      simp only [uncomplement,List.mem_cons]
      intro c hm
      rcases hm with rfl | hm
      · split
        · exact bitListTrim_canonical _
        · exact hc a List.mem_cons_self
      · exact ih cs (fun y hy => hc y (List.mem_cons_of_mem _ hy)) c hm

end BinaryMultiplicity.Recovery
