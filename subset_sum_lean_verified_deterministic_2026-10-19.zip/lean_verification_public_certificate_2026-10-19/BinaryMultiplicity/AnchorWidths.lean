import BinaryMultiplicity.AnchoredInstance

namespace BinaryMultiplicity.AnchorRows
open Optss

def wordBits (xs : List (Entry × List Bool)) : ℕ := (xs.map (fun x=>x.2.length)).sum
def capacityBits (tree : SumTree Entry) : ℕ := (tree.entries.map (fun x=>x.1.count.length)).sum

theorem wordBits_append (xs ys : List (Entry × List Bool)) : wordBits (xs++ys)=wordBits xs+wordBits ys := by
  simp [wordBits,List.map_append,List.sum_append]
theorem capacityBits_node (w : List Bool) (l r : SumTree Entry) :
    capacityBits (.node w l r)=capacityBits l+capacityBits r := by
  simp [capacityBits,SumTree.entries,List.map_append,List.sum_append]
theorem wordBits_full (tree : SumTree Entry) :
    wordBits (tree.entries.map (fun x=>(x.1,x.1.count)))=capacityBits tree := by
  simp [wordBits,capacityBits,List.map_map,Function.comp_def]
theorem wordBits_zero (tree : SumTree Entry) :
    wordBits (tree.entries.map (fun x=>(x.1,[])))=0 := by
  simp [wordBits,List.map_map,Function.comp_def]

theorem fill_wordBits (tree : SumTree Entry) (target q : List Bool)
    (hq : q.length ≤ (tree.descend target).payload.count.length) :
    wordBits (fill tree (tree.descend target).path q) ≤ capacityBits tree := by
  induction tree generalizing target with
  | leaf a w => simpa [fill,fillAcc,SumTree.descend,wordBits,capacityBits,SumTree.entries] using hq
  | node w l r il ir =>
      by_cases hc : bitListLE l.word target=true
      · simp only [SumTree.descend,if_pos hc] at hq ⊢
        rw [fill_node_true,wordBits_append,wordBits_full,capacityBits_node]
        exact Nat.add_le_add_left (ir _ hq) _
      · simp only [SumTree.descend,if_neg hc] at hq ⊢
        rw [fill_node_false,wordBits_append,wordBits_zero,Nat.add_zero,capacityBits_node]
        exact (il _ hq).trans (Nat.le_add_right _ _)

theorem pivot_anchor_length (xs : List Entry) (tree : SumTree Entry)
    (htree : (WeightedTotals.run xs).full=some tree) (target : List Bool)
    (ht : binaryDigitsValue target<WeightedTotals.total xs) :
    (Pivot.run tree target).anchor.length ≤ (Pivot.run tree target).entry.count.length := by
  obtain ⟨before,after,he,hs,hq,hr⟩ := Pivot.run_spec xs tree htree target ht
  have hd : 0<binaryDigitsValue (tree.descend target).payload.weight.digits := by
    change 0<WeightedTotals.magnitude (Pivot.run tree target).entry
    omega
  have hcanonical := (bitListDivision_encodings (tree.descend target).residual
    (tree.descend target).payload.weight.digits hd).1
  have hvalue := (bitListDivision_correct (tree.descend target).residual
    (tree.descend target).payload.weight.digits hd).1
  change (bitListDivision _ _).quotient.length ≤ _
  rw [hcanonical,Nat.size_eq_bits_len]
  rw [←hvalue]
  exact (Nat.size_le_size hq.le).trans
    (Nat.size_le.mpr (binaryDigitsValue_lt_pow (Pivot.run tree target).entry.count))

end BinaryMultiplicity.AnchorRows
