import BinaryMultiplicity.Preprocess
import BinaryMultiplicity.MergeBits

namespace BinaryMultiplicity
open Optss

theorem value_natAbs (x : Entry) : x.value.natAbs=WeightedTotals.magnitude x := by
  cases h : x.weight.negative <;>
    simp [Entry.value,BitListInteger.value,signedBitsValue,h,WeightedTotals.magnitude]

theorem merged_value_mem (xs : List Entry) (y : Entry) (hy : y∈merged xs) :
    ∃x∈xs,y.value=x.value := by
  rw [merged_eq] at hy
  obtain ⟨g,hg,rfl⟩ := List.mem_map.mp hy
  have hne := Trie.groups_nonempty (Trie.build Entry.key (normalized xs)) g hg
  have hm : g.headD zeroEntry∈g := by cases g <;> simp_all
  have hf : g.headD zeroEntry∈(grouped xs).flatten := List.mem_flatten.mpr ⟨g,hg,hm⟩
  have hn : g.headD zeroEntry∈normalized xs := (grouped_partition xs).mem_iff.mp hf
  obtain ⟨x,hx,he⟩ := List.mem_map.mp hn
  refine ⟨x,hx,?_⟩
  rw [merged_value,←he,Entry.normalize_value]

namespace FullPreprocess

structure Output where
  merged : List Merged
  answer : Preprocess.Answer
  work : ℕ

/-- Public binary-capacity preparation. The group trees and anchor records
are retained for witness reconstruction; no physical-copy expansion occurs. -/
def run (xs : List Entry) (target : BitListInteger) (radius : List Bool) : Output :=
  let merged := merge xs
  let entries := merged.1.map Merged.entry
  let out := Preprocess.after entries target radius
  ⟨merged.1,out.1,merged.2+out.2+4*merged.1.length+8⟩

theorem run_correct (xs : List Entry) (target : BitListInteger) (radius : List Bool)
    (hweights : ∀x∈xs,x.value.natAbs ≤ binaryDigitsValue radius) :
    Preprocess.Correct xs target.value (run xs target radius).answer := by
  have hm : ∀y∈BinaryMultiplicity.merged xs,
      WeightedTotals.magnitude y ≤ binaryDigitsValue radius := by
    intro y hy
    obtain ⟨x,hx,he⟩ := merged_value_mem xs y hy
    rw [←value_natAbs,he]
    exact hweights x hx
  have h := Preprocess.after_correct (BinaryMultiplicity.merged xs) target radius hm
  have he := merge_feasible xs target.value
  change Preprocess.Correct xs target.value
    (Preprocess.after (BinaryMultiplicity.merged xs) target radius).1
  cases ha : (Preprocess.after (BinaryMultiplicity.merged xs) target radius).1 with
  | terminal b =>
      simp only [ha,Preprocess.Correct] at h ⊢
      exact h.trans he
  | reduced out =>
      simp only [ha,Preprocess.Correct] at h ⊢
      exact h.trans he

end FullPreprocess
end BinaryMultiplicity
