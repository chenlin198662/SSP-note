import BinaryMultiplicity.SumTree

namespace BinaryMultiplicity.SumTree
open Optss
variable {α : Type*}

structure Crossing (α : Type*) where
  path : List Bool
  payload : α
  residual : List Bool

/-- Follow cached subtree totals. At most one child is visited at each node;
there is no scan of all preceding leaves or expansion of multiplicities. -/
def descend : SumTree α → List Bool → Crossing α
  | .leaf a _,target => ⟨[],a,target⟩
  | .node _ left right,target =>
      if bitListLE left.word target then
        let out := descend right (bitListTrim (bitListSub target left.word))
        ⟨true::out.path,out.payload,out.residual⟩
      else
        let out := descend left target
        ⟨false::out.path,out.payload,out.residual⟩

def sumWords (xs : List (α × List Bool)) : ℕ :=
  (xs.map (fun x => binaryDigitsValue x.2)).sum

theorem descend_spec (tree : SumTree α) (ht : tree.Valid) (target : List Bool)
    (hbound : binaryDigitsValue target < binaryDigitsValue tree.word) :
    ∃before w after,
      tree.entries=before++((descend tree target).payload,w)::after ∧
      binaryDigitsValue target=sumWords before+binaryDigitsValue (descend tree target).residual ∧
      binaryDigitsValue (descend tree target).residual < binaryDigitsValue w := by
  induction tree generalizing target with
  | leaf a w => exact ⟨[],w,[],rfl,by simp [sumWords,descend],hbound⟩
  | node w left right il ir =>
      obtain ⟨hl,hr,hw⟩ := ht
      change binaryDigitsValue target < binaryDigitsValue w at hbound
      by_cases hc : bitListLE left.word target=true
      · have hle := (bitListLE_correct left.word target).mp hc
        have hs : binaryDigitsValue (bitListTrim (bitListSub target left.word))=
            binaryDigitsValue target-binaryDigitsValue left.word := by
          rw [bitListTrim_value,bitListSub_correct]
        have hb : binaryDigitsValue (bitListTrim (bitListSub target left.word)) <
            binaryDigitsValue right.word := by rw [hs]; omega
        obtain ⟨before,pivot,after,he,htarget,hsmall⟩ := ir hr _ hb
        refine ⟨left.entries++before,pivot,after,?_,?_,?_⟩
        · simp only [entries,descend,if_pos hc,he,List.append_assoc]
        · have hv := word_value left hl
          simp only [descend,if_pos hc,sumWords,List.map_append,List.sum_append]
          change binaryDigitsValue target=sumWords left.entries+sumWords before+_
          change binaryDigitsValue left.word=sumWords left.entries at hv
          omega
        · simpa only [descend,if_pos hc] using hsmall
      · have hb : binaryDigitsValue target < binaryDigitsValue left.word := by
          have hn : ¬binaryDigitsValue left.word ≤ binaryDigitsValue target :=
            fun h => hc ((bitListLE_correct _ _).mpr h)
          omega
        obtain ⟨before,pivot,after,he,htarget,hsmall⟩ := il hl target hb
        refine ⟨before,pivot,after++right.entries,?_,?_,?_⟩
        · simp only [entries,descend,if_neg hc,he,List.append_assoc,List.cons_append]
        · simpa only [descend,if_neg hc] using htarget
        · simpa only [descend,if_neg hc] using hsmall

theorem descend_depth (tree : SumTree α) (target : List Bool) :
    (descend tree target).path.length ≤ tree.height := by
  induction tree generalizing target with
  | leaf a w => simp [descend,height]
  | node w left right il ir =>
      simp only [descend]
      split
      · have h := ir (bitListTrim (bitListSub target left.word)); simp only [List.length_cons,height]; omega
      · have h := il target; simp only [List.length_cons,height]; omega

def AllWidths (B : ℕ) : SumTree α → Prop
  | .leaf _ w => w.length ≤ B
  | .node w left right => w.length ≤ B ∧ AllWidths B left ∧ AllWidths B right

theorem allWidths_root (B : ℕ) (tree : SumTree α) (h : tree.AllWidths B) : tree.word.length ≤ B := by
  cases tree <;> simp_all [AllWidths,word]

def compareWork (a b : List Bool) : ℕ :=
  bitListRippleGates 8 a b+bitListSubVisits a b+2

def subtractWork (a b : List Bool) : ℕ :=
  bitListRippleGates 8 a b+bitListSubVisits a b+bitListTrimVisits (bitListSub a b)+4

def descendWork : SumTree α → List Bool → ℕ
  | .leaf _ _,_ => 4
  | .node _ left right,target =>
      compareWork target left.word+8+
        if bitListLE left.word target then
          subtractWork target left.word+descendWork right (bitListTrim (bitListSub target left.word))
        else descendWork left target

theorem compareWork_bound (a b : List Bool) (B : ℕ) (ha : a.length ≤ B) (hb : b.length ≤ B) :
    compareWork a b ≤ 9*B+3 := by
  simp only [compareWork,bitListRippleGates_eq,bitListSubVisits_eq]
  omega

theorem subtractWork_bound (a b : List Bool) (B : ℕ) (ha : a.length ≤ B) (hb : b.length ≤ B) :
    subtractWork a b ≤ 10*B+6 := by
  have h := bitListSub_total_visits a b
  simp only [subtractWork,bitListRippleGates_eq]
  omega

theorem descendWork_bound (tree : SumTree α) (target : List Bool) (B : ℕ)
    (ht : tree.AllWidths B) (hwidth : target.length ≤ B) :
    descendWork tree target ≤ 32*(B+1)*(tree.height+1) := by
  induction tree generalizing target with
  | leaf a w => simp [descendWork,height]; omega
  | node w left right il ir =>
      obtain ⟨hw,hl,hr⟩ := ht
      have hleft := allWidths_root B left hl
      have hc := compareWork_bound target left.word B hwidth hleft
      simp only [descendWork]
      split
      · have hs := subtractWork_bound target left.word B hwidth hleft
        have hsub := bitListSub_length_le target left.word
        have htrim := bitListTrim_length_le (bitListSub target left.word)
        have hi := ir (bitListTrim (bitListSub target left.word)) hr (by omega)
        have hh : right.height ≤ max left.height right.height := le_max_right _ _
        simp only [height]
        nlinarith
      · have hi := il target hl hwidth
        have hh : left.height ≤ max left.height right.height := le_max_left _ _
        simp only [height]
        nlinarith

end BinaryMultiplicity.SumTree
