import BinaryMultiplicity.Complement
import BinaryMultiplicity.WeightedTotals

namespace BinaryMultiplicity
open Optss

theorem positive_feasible_bounds (xs : List Entry) (t : ℤ)
    (h : Feasible (positiveEntries xs) t) : 0 ≤ t ∧ t ≤ (WeightedTotals.total xs:ℤ) := by
  induction xs generalizing t with
  | nil =>
      have he : t=0 := by simpa [positiveEntries,feasible_nil] using h
      subst t
      simp [WeightedTotals.total]
  | cons x xs ih =>
      obtain ⟨n,hn,s,hs,he⟩ := (feasible_cons (positiveEntry x) (positiveEntries xs) t).mp h
      have hb := ih s hs
      have hmag : 0 ≤ (positiveEntry x).value := by rw [positive_value]; positivity
      have hprod := mul_le_mul_of_nonneg_right (show (n:ℤ) ≤ x.capacity by exact_mod_cast hn) hmag
      have hn0 : 0 ≤ (n:ℤ)*(positiveEntry x).value := mul_nonneg (by positivity) hmag
      have htotal : (WeightedTotals.total (x::xs):ℤ)=
          (x.capacity:ℤ)*(positiveEntry x).value+WeightedTotals.total xs := by
        simp [WeightedTotals.total,WeightedTotals.weight,WeightedTotals.magnitude,
          positive_value,Entry.capacity,Nat.cast_mul,mul_comm]
      rw [htotal]
      omega

theorem positive_total_feasible (xs : List Entry) :
    Feasible (positiveEntries xs) (WeightedTotals.total xs) := by
  induction xs with
  | nil => exact ⟨[],Witness.nil⟩
  | cons x xs ih =>
      apply (feasible_cons (positiveEntry x) (positiveEntries xs) _).mpr
      refine ⟨x.capacity,le_refl _,WeightedTotals.total xs,ih,?_⟩
      simp [WeightedTotals.total,WeightedTotals.weight,WeightedTotals.magnitude,
        positive_value,Entry.capacity,Nat.cast_mul,mul_comm]

theorem negativeOffset_eq (xs : List Entry) : negativeOffset xs=(WeightedTotals.negative xs:ℤ) := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
      change (if x.weight.negative then (x.capacity:ℤ)*binaryDigitsValue x.weight.digits else 0)+
        negativeOffset xs = ((if x.weight.negative then WeightedTotals.weight x else 0)+WeightedTotals.negative xs:ℕ)
      rw [Nat.cast_add,ih]
      cases h : x.weight.negative <;>
        simp [h,WeightedTotals.weight,WeightedTotals.magnitude,Entry.capacity,Nat.cast_mul,mul_comm]

end BinaryMultiplicity
