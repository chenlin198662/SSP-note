import BinaryMultiplicity.Residual
import SubsetSum.ScalarProximity

namespace BinaryMultiplicity
open Optss

theorem feasible_indexed (xs : List Entry) (t : ℤ) :
    Feasible xs t ↔ ∃f : Fin xs.length → ℕ,
      (∀i,f i≤(xs.get i).capacity) ∧ (∑i,(f i:ℤ)*(xs.get i).value)=t := by
  induction xs generalizing t with
  | nil => simp [feasible_nil,eq_comm]
  | cons x xs ih =>
      simp only [List.length_cons]
      rw [feasible_cons]
      constructor
      · rintro ⟨n,hn,s,hs,he⟩
        obtain ⟨f,hf,hv⟩ := (ih s).mp hs
        refine ⟨Fin.cons n f,?_,?_⟩
        · intro i
          refine Fin.cases ?_ (fun j => ?_) i
          · simpa using hn
          · simpa using hf j
        · have hs' : (∑i : Fin xs.length,(f i:ℤ)*xs[i.val].value)=s := by simpa using hv
          simpa [Fin.sum_univ_succ,hs'] using he
      · rintro ⟨f,hf,hv⟩
        refine ⟨f 0,by simpa using hf 0,∑i : Fin xs.length,(f i.succ:ℤ)*(xs.get i).value,
          (ih _).mpr ⟨fun i=>f i.succ,?_,rfl⟩,?_⟩
        · intro i; simpa using hf i.succ
        · simpa [Fin.sum_univ_succ] using hv

def capEntry (limit : List Bool) (x : Entry) : Entry :=
  ⟨x.weight,if bitListLE x.count limit then x.count else limit⟩
def capRows (limit : List Bool) (xs : List Entry) : List Entry := xs.map (capEntry limit)

theorem feasible_map_indexed (xs : List Entry) (f : Entry → Entry) (t : ℤ) :
    Feasible (xs.map f) t ↔ ∃c : Fin xs.length → ℕ,
      (∀i,c i≤(f (xs.get i)).capacity) ∧ (∑i,(c i:ℤ)*(f (xs.get i)).value)=t := by
  induction xs generalizing t with
  | nil => simp [feasible_nil,eq_comm]
  | cons x xs ih =>
      simp only [List.length_cons,List.map_cons]
      rw [feasible_cons]
      constructor
      · rintro ⟨n,hn,s,hs,he⟩
        obtain ⟨c,hc,hv⟩ := (ih s).mp hs
        refine ⟨Fin.cons n c,?_,?_⟩
        · intro i
          refine Fin.cases ?_ (fun j => ?_) i
          · simpa using hn
          · simpa using hc j
        · have hs' : (∑i : Fin xs.length,(c i:ℤ)*(f xs[i.val]).value)=s := by simpa using hv
          simpa [Fin.sum_univ_succ,hs'] using he
      · rintro ⟨c,hc,hv⟩
        refine ⟨c 0,by simpa using hc 0,∑i : Fin xs.length,(c i.succ:ℤ)*(f (xs.get i)).value,
          (ih _).mpr ⟨fun i=>c i.succ,?_,rfl⟩,?_⟩
        · intro i; simpa using hc i.succ
        · simpa [Fin.sum_univ_succ] using hv

theorem capEntry_value (limit : List Bool) (x : Entry) : (capEntry limit x).value=x.value := rfl
theorem capEntry_capacity (limit : List Bool) (x : Entry) :
    (capEntry limit x).capacity=min x.capacity (binaryDigitsValue limit) := by
  dsimp only [capEntry,Entry.capacity]
  by_cases h : bitListLE x.count limit=true
  · simp only [if_pos h,min_eq_left ((bitListLE_correct _ _).mp h)]
  · have hn : binaryDigitsValue limit≤binaryDigitsValue x.count := by
      have hh : ¬binaryDigitsValue x.count≤binaryDigitsValue limit := fun he => h ((bitListLE_correct _ _).mpr he)
      omega
    simp only [if_neg h,min_eq_right hn]

theorem capRows_feasible (xs : List Entry) (limit : List Bool) (N : ℕ)
    (hlimit : binaryDigitsValue limit=2*N) (hN : 0<N)
    (hv : ∀x∈xs,-(N:ℤ)≤x.value ∧ x.value≤N) (r : ℤ) (hr : 0≤r ∧ r<N) :
    Feasible xs r ↔ Feasible (capRows limit xs) r := by
  rw [feasible_indexed,capRows,feasible_map_indexed]
  have hcap := SubsetSum.ScalarProximity.cap_counts_iff
    (fun i : Fin xs.length => (xs.get i).value)
    (fun i : Fin xs.length => (xs.get i).capacity) N r hN
    (fun i => hv (xs.get i) (List.get_mem _ _)) hr
  simpa only [capEntry_value,capEntry_capacity,hlimit,nsmul_eq_mul] using hcap

def capEntryWork (limit : List Bool) (x : Entry) : ℕ :=
  SumTree.compareWork x.count limit+8

theorem capEntryWork_bound (limit : List Bool) (x : Entry) :
    capEntryWork limit x≤9*(x.count.length+limit.length)+11 := by
  have h := SumTree.compareWork_bound x.count limit (x.count.length+limit.length)
    (by omega) (by omega)
  dsimp only [capEntryWork]
  omega

end BinaryMultiplicity
