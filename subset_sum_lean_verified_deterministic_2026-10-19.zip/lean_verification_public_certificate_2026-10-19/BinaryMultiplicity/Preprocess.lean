import BinaryMultiplicity.AnchoredInstance
import BinaryMultiplicity.PositiveBounds
import BinaryMultiplicity.SparseMerge

namespace BinaryMultiplicity.Preprocess
open Optss

inductive Answer where
  | terminal (value : Bool)
  | reduced (out : AnchoredInstance.Output)

def Correct (xs : List Entry) (target : ℤ) : Answer → Prop
  | .terminal b => b=true ↔ Feasible xs target
  | .reduced out => Feasible out.capped (binaryDigitsValue out.pivot.residual) ↔ Feasible xs target

def shiftedTarget (target : BitListInteger) (negative : List Bool) : BitListInteger :=
  ConvolutionDraft.CanonicalOutput.normalize (bitListIntegerAdd target ⟨false,negative⟩)

theorem shifted_value (target : BitListInteger) (negative : List Bool) :
    (shiftedTarget target negative).value=target.value+(binaryDigitsValue negative:ℤ) := by
  rw [shiftedTarget,ConvolutionDraft.CanonicalOutput.normalize_value,bitListIntegerAdd_value]
  rfl

theorem shifted_negative (target : BitListInteger) (negative : List Bool) :
    (shiftedTarget target negative).negative=true ↔ (shiftedTarget target negative).value<0 := by
  have h := ConvolutionDraft.CanonicalOutput.normalize_representation
    (bitListIntegerAdd target ⟨false,negative⟩) (bitListIntegerAdd_canonical _ _)
  have hv := ConvolutionDraft.CanonicalOutput.normalize_value (bitListIntegerAdd target ⟨false,negative⟩)
  change shiftedTarget target negative=integerBitRepresentation _ at h
  change (shiftedTarget target negative).value=_ at hv
  rw [←hv] at h
  conv_lhs => rw [h]
  simp [integerBitRepresentation]

def limit (radius : List Bool) : List Bool := bitListTrim (false::radius)
theorem limit_value (radius : List Bool) : binaryDigitsValue (limit radius)=2*binaryDigitsValue radius := by
  simp [limit,bitListTrim_value,binaryDigitsValue]

def after (xs : List Entry) (target : BitListInteger) (radius : List Bool) : Answer × ℕ :=
  let totals := WeightedTotals.run xs
  let negative := WeightedTotals.storedWord totals.negative
  let full := WeightedTotals.storedWord totals.full
  let shifted := shiftedTarget target negative
  let limit := limit radius
  let header := totals.work+bitListIntegerAddCost target ⟨false,negative⟩+
    SumTree.compareWork shifted.digits full+SumTree.compareWork full shifted.digits+
    bitListTrimVisits (false::radius)+20
  if shifted.negative then (.terminal false,header)
  else if bitListLE shifted.digits full then
    if bitListLE full shifted.digits then (.terminal true,header)
    else match totals.full with
      | none => (.terminal false,header)
      | some tree =>
        let out := AnchoredInstance.run tree shifted.digits limit
        (.reduced out,header+out.work)
  else (.terminal false,header)

theorem after_correct (xs : List Entry) (target : BitListInteger) (radius : List Bool)
    (hweights : ∀x∈xs,WeightedTotals.magnitude x ≤ binaryDigitsValue radius) :
    Correct xs target.value (after xs target radius).1 := by
  let totals := WeightedTotals.run xs
  let negative := WeightedTotals.storedWord totals.negative
  let full := WeightedTotals.storedWord totals.full
  let shifted := shiftedTarget target negative
  have hneg : binaryDigitsValue negative=WeightedTotals.negative xs := WeightedTotals.negative_value xs
  have hfull : binaryDigitsValue full=WeightedTotals.total xs := WeightedTotals.full_value xs
  have hshift : shifted.value=target.value+negativeOffset xs := by
    rw [shifted_value,hneg,negativeOffset_eq]
  have hfeas : Feasible xs target.value ↔ Feasible (positiveEntries xs) shifted.value := by
    rw [hshift]; exact feasible_positive xs target.value
  dsimp only [after]
  change Correct xs target.value
    ((if shifted.negative then _ else if bitListLE shifted.digits full then
      if bitListLE full shifted.digits then _ else _ else _):Answer × ℕ).1
  by_cases hn : shifted.negative=true
  · simp only [if_pos hn,Correct,Bool.false_eq_true,false_iff]
    intro hf
    have hb := positive_feasible_bounds xs shifted.value (hfeas.mp hf)
    have ht := (shifted_negative target negative).mp hn
    change shifted.value<0 at ht
    rw [hshift] at ht
    omega
  · have hsign : shifted.negative=false := Bool.eq_false_iff.mpr hn
    have hval : shifted.value=(binaryDigitsValue shifted.digits:ℤ) := by
      simp [BitListInteger.value,signedBitsValue,hsign]
    simp only [if_neg hn]
    by_cases hle : bitListLE shifted.digits full=true
    · simp only [if_pos hle]
      by_cases hge : bitListLE full shifted.digits=true
      · simp only [if_pos hge,Correct,true_iff]
        apply hfeas.mpr
        have he : binaryDigitsValue shifted.digits=WeightedTotals.total xs := by
          have h1 := (bitListLE_correct _ _).mp hle
          have h2 := (bitListLE_correct _ _).mp hge
          omega
        rw [hval,he]
        exact positive_total_feasible xs
      · simp only [if_neg hge]
        have hlt : binaryDigitsValue shifted.digits<WeightedTotals.total xs := by
          have hnot : ¬binaryDigitsValue full≤binaryDigitsValue shifted.digits :=
            fun h=>hge ((bitListLE_correct _ _).mpr h)
          omega
        cases ht : (WeightedTotals.run xs).full with
        | none =>
            have hz : WeightedTotals.total xs=0 := by
              have h := WeightedTotals.full_value xs
              simpa [ht,WeightedTotals.storedWord,binaryDigitsValue] using h.symm
            omega
        | some tree =>
            simp only [ht,Correct]
            obtain ⟨before,after,he,_,_,hr⟩ := Pivot.run_spec xs tree ht shifted.digits hlt
            have hm : WeightedTotals.magnitude (Pivot.run tree shifted.digits).entry ≤ binaryDigitsValue radius := by
              apply hweights
              rw [he]; simp
            have hN : 0<binaryDigitsValue radius := by omega
            have hc := (AnchoredInstance.run_correct xs tree ht shifted.digits (limit radius)
              (binaryDigitsValue radius) hN hlt (limit_value radius) hweights).1
            exact hc.trans (by rw [←hval]; exact hfeas.symm)
    · simp only [if_neg hle,Correct,Bool.false_eq_true,false_iff]
      intro hf
      have hb := (positive_feasible_bounds xs shifted.value (hfeas.mp hf)).2
      have hnot : ¬binaryDigitsValue shifted.digits≤binaryDigitsValue full :=
        fun h=>hle ((bitListLE_correct _ _).mpr h)
      rw [hval] at hb
      have hh : binaryDigitsValue shifted.digits≤binaryDigitsValue full := by exact_mod_cast (hfull ▸ hb)
      exact hnot hh

end BinaryMultiplicity.Preprocess
