import BinaryMultiplicity.AnchoredRecovery
import BinaryMultiplicity.MergedRecoveryWork

namespace BinaryMultiplicity.Recovery
open Optss

theorem after_reduced_sign (xs : List Entry) (target : BitListInteger) (radius : List Bool)
    (out : AnchoredInstance.Output) (ho : (Preprocess.after xs target radius).1=.reduced out) :
    (Preprocess.shiftedTarget target
      (WeightedTotals.storedWord (WeightedTotals.run xs).negative)).negative=false := by
  cases hn : (Preprocess.shiftedTarget target
      (WeightedTotals.storedWord (WeightedTotals.run xs).negative)).negative with
  | false => rfl
  | true => simp only [Preprocess.after,hn,if_true] at ho; cases ho

def recoverReduced (prepared : FullPreprocess.Output) (out : AnchoredInstance.Output)
    (counts : List (List Bool)) : List (Entry×List Bool) :=
  let restored := restoreRows out.anchor counts
  let original := uncomplement (prepared.merged.map Merged.entry) restored
  recoverMany prepared.merged original

/-- Literal recovery from a valid capped residual witness to the original
input records (returned in stable grouped order). Each original normalized
record occurs once, even when multiple records have equal weights. -/
theorem recoverReduced_spec (xs : List Entry) (target : BitListInteger) (radius : List Bool)
    (out : AnchoredInstance.Output)
    (ho : (FullPreprocess.run xs target radius).answer=.reduced out)
    (counts : List (List Bool))
    (hw : BitWitness out.capped counts (binaryDigitsValue out.pivot.residual)) :
    let rows := recoverReduced (FullPreprocess.run xs target radius) out counts
    (rows.map Prod.fst).Perm (normalized xs) ∧
      (∀x∈rows,binaryDigitsValue x.2 ≤ x.1.capacity) ∧ rowSum rows=target.value := by
  dsimp only
  let ys := BinaryMultiplicity.merged xs
  have hs := after_reduced_sign ys target radius out ho
  obtain ⟨tree,ht,hr,rfl⟩ := Preprocess.after_reduced ys target radius out ho
  let shifted := Preprocess.shiftedTarget target
      (WeightedTotals.storedWord (WeightedTotals.run ys).negative)
  change shifted.negative=false at hs
  have hp := anchored_recovery ys tree ht shifted.digits (Preprocess.limit radius) hr counts hw
  have hu := uncomplement_correct ys _ (binaryDigitsValue shifted.digits) hp
  have hv : shifted.value=(binaryDigitsValue shifted.digits:ℤ) := by
    simp only [BitListInteger.value,signedBitsValue,hs,Bool.false_eq_true,if_false]
  have he : (binaryDigitsValue shifted.digits:ℤ)-negativeOffset ys=target.value := by
    have h := Preprocess.shifted_value target (WeightedTotals.storedWord (WeightedTotals.run ys).negative)
    rw [WeightedTotals.negative_value,←negativeOffset_eq] at h
    change shifted.value=_ at h
    rw [hv] at h
    omega
  rw [he] at hu
  exact merged_recovery xs _ target.value hu

end BinaryMultiplicity.Recovery
