import BinaryMultiplicity.WeightedTotals
import BinaryMultiplicity.TreeWork

namespace BinaryMultiplicity.WeightedTotals
open Optss SubsetSum.ExternalCostContracts

def inputSize (xs : List Entry) : ℕ := (xs.map Entry.bits).sum
noncomputable def multiplierConstant : ℕ := ConvolutionDraft.CanonicalOutput.polynomial.eval 1
noncomputable def multiplierPower : ℕ := ConvolutionDraft.CanonicalOutput.polynomial.natDegree
def productLog (L : ℕ) : ℕ := (2*(L+3)+1).size

theorem product_work (x : Entry) (L : ℕ) (hL : x.bits≤L) :
    FastProduct.work x.weight.digits x.count ≤
      2*multiplierConstant*(x.bits+1)*(productLog L)^multiplierPower+8 := by
  have h := FastProduct.work_bound x.weight.digits x.count
  have hs : (2*(x.weight.digits.length+x.count.length+3)+1).size≤productLog L := by
    apply Nat.size_le_size
    dsimp [productLog,Entry.bits] at *
    omega
  have hp := Nat.pow_le_pow_left hs multiplierPower
  have hm := Nat.mul_le_mul_left (2*multiplierConstant*(x.bits+1)) hp
  simp only [fftBudget] at h
  rw [show (2:ℕ).size=2 by simpa using (Nat.size_pow (n:=1))] at h
  dsimp only [multiplierConstant,multiplierPower,Entry.bits] at hm ⊢
  nlinarith only [h,hm]

theorem products_work (xs : List Entry) (L : ℕ) (hL : ∀x∈xs,x.bits≤L) :
    (xs.map (fun x => FastProduct.work x.weight.digits x.count)).sum ≤
      2*multiplierConstant*(inputSize xs+xs.length)*(productLog L)^multiplierPower+8*xs.length := by
  induction xs with
  | nil => simp [inputSize]
  | cons x xs ih =>
      have hx := product_work x L (hL x List.mem_cons_self)
      have ht := ih (fun y hy => hL y (List.mem_cons_of_mem _ hy))
      simp only [inputSize,List.map_cons,List.sum_cons,List.length_cons] at *
      nlinarith only [hx,ht]

theorem run_work_nearlinear (xs : List Entry) :
    (run xs).work ≤
      2*multiplierConstant*(inputSize xs+xs.length)*(productLog (inputSize xs))^multiplierPower+
      256*(inputSize xs+xs.length+1)*(xs.length.size+3)^3+20*xs.length+8 := by
  have hproducts := products_work xs (inputSize xs) (fun x hx =>
    List.single_le_sum (fun n _ => Nat.zero_le n) x.bits (List.mem_map.mpr ⟨x,hx,rfl⟩))
  have hf := SumTree.build_work_linear_log (weightedLeaves xs)
  have hn := SumTree.build_work_linear_log (negativeLeaves (weightedLeaves xs))
  have hfw := weighted_width xs
  have hnw := (negative_width (weightedLeaves xs)).trans hfw
  have hl : (weightedLeaves xs).length=xs.length := by simp [weightedLeaves]
  have hl' : (negativeLeaves (weightedLeaves xs)).length=xs.length := by simp [negativeLeaves,weightedLeaves]
  rw [hl] at hf
  rw [hl'] at hn
  have hm1 := Nat.mul_le_mul_right ((xs.length.size+3)^3)
    (Nat.mul_le_mul_left 128 (Nat.add_le_add_right hfw (xs.length+1)))
  have hm2 := Nat.mul_le_mul_right ((xs.length.size+3)^3)
    (Nat.mul_le_mul_left 128 (Nat.add_le_add_right hnw (xs.length+1)))
  dsimp only [run]
  dsimp only [inputSize] at hproducts ⊢
  nlinarith only [hproducts,hf,hn,hm1,hm2]

end BinaryMultiplicity.WeightedTotals
