import BinaryMultiplicity.GroupRecovery

namespace BinaryMultiplicity.Recovery
open Optss

def recoverMany : List Merged → List (List Bool) → List (Entry×List Bool)
  | [],_ => []
  | g::gs,c::cs => recoverOne g (bitListTrim c)++recoverMany gs cs
  | g::gs,[] => recoverOne g []++recoverMany gs []

def recoverManyWork : List Merged → List (List Bool) → ℕ
  | [],_ => 1
  | g::gs,c::cs => bitListTrimVisits c+recoverOneWork g (bitListTrim c)+
      4*(recoverOne g (bitListTrim c)).length+8+recoverManyWork gs cs
  | g::gs,[] => recoverOneWork g []+4*(recoverOne g []).length+8+recoverManyWork gs []

theorem recoverMany_spec (groups : List (List Entry))
    (hne : ∀g∈groups,g≠[]) (huniform : ∀g∈groups,∀x∈g,x.value=(mergedEntry g).value)
    (counts : List (List Bool)) (t : ℤ)
    (hw : BitWitness (groups.map mergedEntry) counts t) :
    let rows := recoverMany (groups.map (fun g => (mergeGroup g).1)) counts
    rows.map Prod.fst=groups.flatten ∧
      (∀x∈rows,binaryDigitsValue x.2 ≤ x.1.capacity) ∧ rowSum rows=t := by
  dsimp only
  induction groups generalizing counts t with
  | nil =>
    cases counts with
    | nil => cases hw; simp [recoverMany,rowSum]
    | cons c cs => cases hw
  | cons g gs ih =>
    cases counts with
    | nil => cases hw
    | cons c cs =>
      cases hw with
      | cons hc ht =>
        have hc' : binaryDigitsValue (bitListTrim c) ≤ (mergedEntry g).capacity := by
          simpa only [bitListTrim_value] using hc
        have hg := recoverOne_spec g (hne g List.mem_cons_self) (bitListTrim c) hc'
        have hv := recoverOne_sum g (hne g List.mem_cons_self) (bitListTrim c) hc'
          (huniform g List.mem_cons_self)
        have hh := ih (fun x hx => hne x (List.mem_cons_of_mem _ hx))
          (fun x hx => huniform x (List.mem_cons_of_mem _ hx)) cs _ ht
        simp only [List.map_cons,recoverMany,List.map_append,List.flatten_cons]
        refine ⟨by rw [hg.1,hh.1],?_,?_⟩
        · intro x hx
          rcases List.mem_append.mp hx with hx | hx
          · exact hg.2.1 x hx
          · exact hh.2.1 x hx
        · simp only [rowSum,List.map_append,List.sum_append] at hv hh ⊢
          rw [hv,hh.2.2,bitListTrim_value]

/-- The returned records are exactly the normalized original records, each
with its own count bound; the reconstruction never expands their copies. -/
theorem merged_recovery (xs : List Entry) (counts : List (List Bool)) (t : ℤ)
    (hw : BitWitness (merged xs) counts t) :
    let rows := recoverMany (merge xs).1 counts
    (rows.map Prod.fst).Perm (normalized xs) ∧
      (∀x∈rows,binaryDigitsValue x.2 ≤ x.1.capacity) ∧ rowSum rows=t := by
  dsimp only
  have hu : ∀g∈grouped xs,∀x∈g,x.value=(mergedEntry g).value := by
    intro g hg x hx
    rw [merged_value]
    exact grouped_uniform xs g hg x (g.headD zeroEntry) hx (by
      have hn := Trie.groups_nonempty (Trie.build Entry.key (normalized xs)) g hg
      cases g <;> simp_all)
  rw [merged_eq] at hw
  have h := recoverMany_spec (grouped xs) (Trie.groups_nonempty _) hu counts t hw
  dsimp only at h
  have he : (merge xs).1=(grouped xs).map (fun g => (mergeGroup g).1) := by
    simp only [merge,List.map_map,Function.comp_def]
  rw [he]
  exact ⟨h.1 ▸ grouped_partition xs,h.2⟩

end BinaryMultiplicity.Recovery
