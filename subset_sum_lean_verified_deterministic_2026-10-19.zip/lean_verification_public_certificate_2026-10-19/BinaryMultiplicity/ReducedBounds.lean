import BinaryMultiplicity.TrieDistinct
import BinaryMultiplicity.ResidualWork

namespace BinaryMultiplicity
open Optss

theorem capacitySum_le (xs : List Entry) (K : ℕ) (h : ∀x∈xs,x.capacity ≤ K) :
    capacitySum xs ≤ xs.length*K := by
  induction xs with
  | nil => simp [capacitySum]
  | cons x xs ih =>
      have hh := h x List.mem_cons_self
      have ht := ih (fun y hy => h y (List.mem_cons_of_mem _ hy))
      simp only [capacitySum,List.map_cons,List.sum_cons,List.length_cons] at *
      nlinarith only [hh,ht]

namespace AnchoredInstance

theorem run_length (xs : List Entry) (tree : SumTree Entry)
    (htree : (WeightedTotals.run xs).full=some tree) (target limit : List Bool) :
    (run tree target limit).capped.length=2*xs.length := by
  have hs := (WeightedTotals.full_spec xs tree htree).1
  have ho := AnchorRows.fill_order tree (Pivot.run tree target).path (Pivot.run tree target).anchor
  have hl := congrArg List.length ho
  rw [hs] at hl
  simp only [List.length_map,WeightedTotals.weightedLeaves] at hl
  simp only [run,capRows,List.length_map,residualRows_length,positiveRows,List.length_map,hl]

theorem run_capacities (tree : SumTree Entry) (target limit : List Bool) :
    ∀x∈(run tree target limit).capped,x.capacity ≤ binaryDigitsValue limit := by
  intro x hx
  obtain ⟨y,hy,rfl⟩ := List.mem_map.mp hx
  rw [capEntry_capacity]
  exact Nat.min_le_right _ _

theorem run_weights (xs : List Entry) (tree : SumTree Entry)
    (htree : (WeightedTotals.run xs).full=some tree) (target limit : List Bool)
    (N : ℕ) (hweights : ∀x∈xs,WeightedTotals.magnitude x ≤ N) :
    ∀x∈(run tree target limit).capped,x.value.natAbs ≤ N := by
  let raw := AnchorRows.fill tree (Pivot.run tree target).path (Pivot.run tree target).anchor
  have hs := (WeightedTotals.full_spec xs tree htree).1
  have horder : raw.map Prod.fst=xs := by
    rw [show raw=AnchorRows.fill tree (Pivot.run tree target).path (Pivot.run tree target).anchor from rfl,
      AnchorRows.fill_order,hs]
    simp [WeightedTotals.weightedLeaves,List.map_map,Function.comp_def]
  have hv : ∀x∈positiveRows raw,-(N:ℤ) ≤ x.1.value ∧ x.1.value ≤ N := by
    intro x hx
    obtain ⟨y,hy,rfl⟩ := List.mem_map.mp hx
    have hym : y.1∈xs := by rw [←horder]; exact List.mem_map.mpr ⟨y,hy,rfl⟩
    have hm := hweights y.1 hym
    change binaryDigitsValue y.1.weight.digits ≤ N at hm
    rw [positive_value]
    omega
  intro x hx
  obtain ⟨y,hy,rfl⟩ := List.mem_map.mp hx
  have h := residualRows_value_bound (positiveRows raw) N hv y hy
  rw [capEntry_value]
  omega

end AnchoredInstance

namespace Preprocess

/-- Every returned reduced payload is the literal output of the unique
crossing-tree branch, with the strict interior-range test retained. -/
theorem after_reduced (xs : List Entry) (target : BitListInteger) (radius : List Bool)
    (out : AnchoredInstance.Output) (ho : (after xs target radius).1=.reduced out) :
    ∃tree, (WeightedTotals.run xs).full=some tree ∧
      binaryDigitsValue (shiftedTarget target
        (WeightedTotals.storedWord (WeightedTotals.run xs).negative)).digits<WeightedTotals.total xs ∧
      out=AnchoredInstance.run tree (shiftedTarget target
        (WeightedTotals.storedWord (WeightedTotals.run xs).negative)).digits (limit radius) := by
  dsimp only [after] at ho
  split at ho
  · cases ho
  · split at ho
    · split at ho
      · cases ho
      · rename_i hn hle hge
        cases ht : (WeightedTotals.run xs).full with
        | none => simp only [ht] at ho; cases ho
        | some tree =>
            simp only [ht,Answer.reduced.injEq] at ho
            refine ⟨tree,rfl,?_,ho.symm⟩
            have hval := WeightedTotals.full_value xs
            have hnot : ¬binaryDigitsValue (WeightedTotals.storedWord (WeightedTotals.run xs).full) ≤
                binaryDigitsValue (shiftedTarget target
                  (WeightedTotals.storedWord (WeightedTotals.run xs).negative)).digits :=
              fun h => hge ((bitListLE_correct _ _).mpr h)
            omega
    · cases ho

structure ReducedBounds (N : ℕ) (out : AnchoredInstance.Output) : Prop where
  length : out.capped.length ≤ 4*N+2
  weights : ∀x∈out.capped,x.value.natAbs ≤ N
  capacities : ∀x∈out.capped,x.capacity ≤ 2*N
  mass : capacitySum out.capped ≤ (4*N+2)*(2*N)
  target : binaryDigitsValue out.pivot.residual<N

end Preprocess

namespace FullPreprocess

theorem run_reduced_bounds (xs : List Entry) (target : BitListInteger) (radius : List Bool)
    (hweights : ∀x∈xs,x.value.natAbs ≤ binaryDigitsValue radius)
    (out : AnchoredInstance.Output) (ho : (run xs target radius).answer=.reduced out) :
    Preprocess.ReducedBounds (binaryDigitsValue radius) out := by
  let N := binaryDigitsValue radius
  let ys := BinaryMultiplicity.merged xs
  have hmag : ∀y∈ys,WeightedTotals.magnitude y ≤ N := by
    intro y hy
    obtain ⟨x,hx,he⟩ := merged_value_mem xs y hy
    rw [←value_natAbs,he]
    exact hweights x hx
  obtain ⟨tree,htree,htarget,rfl⟩ := Preprocess.after_reduced ys target radius out ho
  let shifted := Preprocess.shiftedTarget target (WeightedTotals.storedWord (WeightedTotals.run ys).negative)
  have hlen := AnchoredInstance.run_length ys tree htree shifted.digits (Preprocess.limit radius)
  have hys := merged_length_le_radius xs N hweights
  change ys.length ≤ 2*N+1 at hys
  have hcap := AnchoredInstance.run_capacities tree shifted.digits (Preprocess.limit radius)
  rw [Preprocess.limit_value] at hcap
  have hmass := capacitySum_le _ (2*N) hcap
  have hml := Nat.mul_le_mul_right (2*N) (show
      (AnchoredInstance.run tree shifted.digits (Preprocess.limit radius)).capped.length ≤ 4*N+2 by omega)
  obtain ⟨before,after,he,_,_,hr⟩ := Pivot.run_spec ys tree htree shifted.digits htarget
  have hwm : WeightedTotals.magnitude (Pivot.run tree shifted.digits).entry ≤ N := by
    apply hmag
    rw [he]
    simp
  change Preprocess.ReducedBounds N (AnchoredInstance.run tree shifted.digits (Preprocess.limit radius))
  refine ⟨by omega,AnchoredInstance.run_weights ys tree htree shifted.digits _ N hmag,
    hcap,hmass.trans hml,?_⟩
  exact hr.trans_le hwm

end FullPreprocess
end BinaryMultiplicity
