import BinaryMultiplicity.TreeWidths

namespace BinaryMultiplicity.SumTree
open Optss
variable {α : Type}

def resource (tree : SumTree α) : ℕ := inputBits tree.entries+tree.entries.length

theorem resource_node (w : List Bool) (l r : SumTree α) :
    resource (.node w l r)=resource l+resource r := by
  simp [resource,entries,inputBits,List.map_append,List.sum_append]
  omega

def LocalResource : SumTree α → Prop
  | .leaf a w => w.length+1≤resource (.leaf a w)
  | .node w l r => w.length+1≤resource (.node w l r) ∧ LocalResource l ∧ LocalResource r

theorem localResource_root (tree : SumTree α) (h : tree.LocalResource) :
    tree.word.length+1≤tree.resource := by cases tree <;> simp_all [LocalResource,word]

theorem join_localResource (l r : SumTree α) (hl : l.LocalResource) (hr : r.LocalResource) :
    (join l r).LocalResource := by
  refine ⟨?_,hl,hr⟩
  have hw := join_width l r
  have hL := localResource_root l hl
  have hR := localResource_root r hr
  change (join l r).word.length+1≤resource (.node _ l r)
  rw [resource_node]
  omega

def AllCanonical : SumTree α → Prop
  | .leaf _ w => BitListCanonical w
  | .node w l r => BitListCanonical w ∧ AllCanonical l ∧ AllCanonical r

theorem allCanonical_root (tree : SumTree α) (h : tree.AllCanonical) :
    BitListCanonical tree.word := by cases tree <;> simp_all [AllCanonical,word]

theorem join_allCanonical (l r : SumTree α) (hl : l.AllCanonical) (hr : r.AllCanonical) :
    (join l r).AllCanonical := ⟨bitListTrim_canonical _,hl,hr⟩

theorem pair_closed (P : SumTree α → Prop)
    (hj : ∀l r,P l→P r→P (join l r)) (ts : List (SumTree α)) (h : ∀t∈ts,P t) :
    ∀t∈pair ts,P t := by
  induction ts using pair.induct with
  | case1 a b ts ih =>
      intro t ht
      rcases List.mem_cons.mp ht with rfl|ht
      · exact hj a b (h a (by simp)) (h b (by simp))
      · exact ih (fun t ht => h t (by simp [ht])) t ht
  | case2 ts ht => cases ts with
    | nil => simp [pair]
    | cons a ts => cases ts <;> simp_all [pair]

theorem rounds_closed (P : SumTree α → Prop)
    (hj : ∀l r,P l→P r→P (join l r)) (fuel : ℕ) (ts : List (SumTree α))
    (h : ∀t∈ts,P t) : ∀t∈rounds fuel ts,P t := by
  induction fuel generalizing ts with
  | zero => exact h
  | succ fuel ih => exact ih (pair ts) (pair_closed P hj ts h)

theorem build_localResource (xs : List (α × List Bool)) (tree : SumTree α)
    (ht : (build xs).1=some tree) : tree.LocalResource := by
  apply rounds_closed LocalResource join_localResource xs.length.size (initial xs)
  · intro t ht
    obtain ⟨a,ha,rfl⟩ := List.mem_map.mp ht
    simp [LocalResource,resource,entries,inputBits]
  · exact List.mem_of_mem_head? (by simpa only [build_value] using ht)

theorem build_allCanonical (xs : List (α × List Bool)) (tree : SumTree α)
    (ht : (build xs).1=some tree) (hc : ∀x∈xs,BitListCanonical x.2) : tree.AllCanonical := by
  apply rounds_closed AllCanonical join_allCanonical xs.length.size (initial xs)
  · intro t ht
    obtain ⟨a,ha,rfl⟩ := List.mem_map.mp ht
    exact hc a ha
  · exact List.mem_of_mem_head? (by simpa only [build_value] using ht)

theorem canonical_target_width (tree : SumTree α) (hc : tree.AllCanonical)
    (target : List Bool) (hcanon : BitListCanonical target)
    (hq : binaryDigitsValue target≤binaryDigitsValue tree.word) :
    target.length≤tree.word.length := by
  have hl := congrArg List.length (allCanonical_root tree hc)
  simp only [Nat.size_eq_bits_len] at hl
  rw [show target=(binaryDigitsValue target).bits from hcanon,Nat.size_eq_bits_len]
  exact (Nat.size_le_size hq).trans_eq hl.symm

end BinaryMultiplicity.SumTree
