import BinaryMultiplicity.AnchorWidths
import BinaryMultiplicity.SparseMergeWork

namespace BinaryMultiplicity
open Optss

def sourceCountBits (rows : List (Entry × List Bool)) : ℕ :=
  (rows.map (fun x => x.1.count.length)).sum

theorem residual_work_sum (rows : List (Entry × List Bool)) :
    (rows.map (fun x => residualPairWork x.1 x.2)).sum ≤
      10*(sourceCountBits rows+AnchorRows.wordBits rows)+18*rows.length := by
  induction rows with
  | nil => simp [sourceCountBits,AnchorRows.wordBits]
  | cons x xs ih =>
      have h := residualPairWork_bound x.1 x.2
      simp only [sourceCountBits,AnchorRows.wordBits,List.map_cons,List.sum_cons,List.length_cons] at *
      omega

theorem positiveResidual_length (x : Entry) (q : List Bool) :
    (positiveResidual x q).count.length ≤ x.count.length := by
  change (bitListTrim (bitListSub x.count q)).length ≤ _
  rw [bitListTrim_length,bitListSub_correct]
  exact (Nat.size_le_size (Nat.sub_le _ _)).trans
    (Nat.size_le.mpr (binaryDigitsValue_lt_pow x.count))

theorem residual_countBits (rows : List (Entry × List Bool)) :
    countBits (residualRows rows) ≤ sourceCountBits rows+AnchorRows.wordBits rows := by
  induction rows with
  | nil => simp [countBits,residualRows,sourceCountBits,AnchorRows.wordBits]
  | cons x xs ih =>
      have h := positiveResidual_length x.1 x.2
      simp only [residualRows,List.flatMap_cons,residualPair,List.cons_append,List.nil_append,
        countBits,sourceCountBits,AnchorRows.wordBits,List.map_cons,List.sum_cons,negativeResidual] at *
      omega

theorem residualRows_length (rows : List (Entry × List Bool)) :
    (residualRows rows).length=2*rows.length := by
  induction rows with
  | nil => rfl
  | cons x xs ih => simp [residualRows,residualPair] at *; omega

theorem cap_work_sum (xs : List Entry) (limit : List Bool) :
    (xs.map (capEntryWork limit)).sum ≤
      9*countBits xs+(9*limit.length+11)*xs.length := by
  induction xs with
  | nil => simp [countBits]
  | cons x xs ih =>
      have h := capEntryWork_bound limit x
      simp only [countBits,List.map_cons,List.sum_cons,List.length_cons] at *
      nlinarith only [h,ih]

end BinaryMultiplicity
