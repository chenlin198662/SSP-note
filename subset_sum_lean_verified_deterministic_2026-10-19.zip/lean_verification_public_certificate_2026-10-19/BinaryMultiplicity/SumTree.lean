import Optss.BitListArithmetic
import Mathlib.Tactic

namespace BinaryMultiplicity
open Optss

/-- Every internal total is stored as actual Boolean digits. Payloads identify
original types or records and are never expanded into physical copies. -/
inductive SumTree (α : Type*) where
  | leaf (payload : α) (word : List Bool)
  | node (word : List Bool) (left right : SumTree α)

namespace SumTree
variable {α : Type*}

def word : SumTree α → List Bool
  | .leaf _ w => w
  | .node w _ _ => w

def entries : SumTree α → List (α × List Bool)
  | .leaf a w => [(a,w)]
  | .node _ left right => entries left++entries right

def height : SumTree α → ℕ
  | .leaf _ _ => 0
  | .node _ left right => max (height left) (height right)+1

def Valid : SumTree α → Prop
  | .leaf _ _ => True
  | .node w left right => Valid left ∧ Valid right ∧
      binaryDigitsValue w=binaryDigitsValue left.word+binaryDigitsValue right.word

def join (left right : SumTree α) : SumTree α :=
  .node (bitListAdd left.word right.word) left right

def addWork (a b : List Bool) : ℕ :=
  bitListRippleGates 6 a b+bitListAddVisits a b+
    bitListTrimVisits (bitListAddAux false a b)+8

def joinWork (left right : SumTree α) : ℕ := addWork left.word right.word+8

theorem addWork_bound (a b : List Bool) : addWork a b ≤ 16*(a.length+b.length+1) := by
  have hv := bitListAdd_total_visits a b
  simp only [addWork,bitListRippleGates_eq]
  omega

theorem join_valid (left right : SumTree α) (hl : left.Valid) (hr : right.Valid) :
    (join left right).Valid := ⟨hl,hr,bitListAdd_correct _ _⟩

theorem word_value (t : SumTree α) (ht : t.Valid) :
    binaryDigitsValue t.word=((t.entries).map (fun a => binaryDigitsValue a.2)).sum := by
  induction t with
  | leaf a w => simp [word,entries]
  | node w left right il ir =>
    obtain ⟨hl,hr,hw⟩ := ht
    simpa only [word,entries,List.map_append,List.sum_append,←il hl,←ir hr] using hw

theorem join_width (left right : SumTree α) :
    (join left right).word.length ≤ left.word.length+right.word.length+1 := by
  have ht := bitListTrim_length_le (bitListAddAux false left.word right.word)
  have ha := bitListAddAux_length left.word right.word false
  change (bitListTrim _).length ≤ _
  omega

def pair : List (SumTree α) → List (SumTree α)
  | a::b::ts => join a b::pair ts
  | ts => ts

def pairWork : List (SumTree α) → ℕ
  | a::b::ts => joinWork a b+pairWork ts+4
  | [] => 1
  | [_] => 4

def bits (ts : List (SumTree α)) : ℕ := (ts.map (fun t => t.word.length)).sum
def forestEntries (ts : List (SumTree α)) : List (α × List Bool) := ts.flatMap entries

theorem pair_entries (ts : List (SumTree α)) : forestEntries (pair ts)=forestEntries ts := by
  induction ts using pair.induct with
  | case1 a b ts ih =>
      simp only [forestEntries] at ih
      simp [pair,forestEntries,join,entries,ih,List.append_assoc]
  | case2 ts ht => cases ts with
    | nil => norm_num [pair]
    | cons a ts => cases ts <;> simp_all [pair]

theorem pair_length (ts : List (SumTree α)) : (pair ts).length=(ts.length+1)/2 := by
  induction ts using pair.induct with
  | case1 a b ts ih => simp only [pair,List.length_cons,ih]; omega
  | case2 ts ht => cases ts with
    | nil => norm_num [pair]
    | cons a ts => cases ts <;> simp_all [pair]

theorem pair_bits (ts : List (SumTree α)) : bits (pair ts) ≤ bits ts+ts.length := by
  induction ts using pair.induct with
  | case1 a b ts ih =>
      have h := join_width a b
      simp only [pair,bits,List.map_cons,List.sum_cons,List.length_cons] at *
      omega
  | case2 ts ht => cases ts with
    | nil => simp [pair,bits]
    | cons a ts => cases ts <;> simp_all [pair]

theorem pairWork_bound (ts : List (SumTree α)) : pairWork ts ≤ 32*(bits ts+ts.length)+1 := by
  induction ts using pair.induct with
  | case1 a b ts ih =>
      have ha := addWork_bound a.word b.word
      simp only [pairWork,joinWork,bits,List.map_cons,List.sum_cons,List.length_cons] at *
      omega
  | case2 ts ht => cases ts with
    | nil => simp [pairWork,bits]
    | cons a ts => cases ts <;> simp_all [pairWork,bits] <;> omega

theorem pair_potential (ts : List (SumTree α)) :
    bits (pair ts)+(pair ts).length ≤ bits ts+ts.length := by
  induction ts using pair.induct with
  | case1 a b ts ih =>
      have h := join_width a b
      simp only [pair,bits,List.map_cons,List.sum_cons,List.length_cons] at *
      omega
  | case2 ts ht => cases ts with
    | nil => simp [pair,bits]
    | cons a ts => cases ts <;> simp_all [pair] <;> omega

theorem pair_valid (ts : List (SumTree α)) (h : ∀t∈ts,t.Valid) :
    ∀t∈pair ts,t.Valid := by
  induction ts using pair.induct with
  | case1 a b ts ih =>
      intro t ht
      rcases List.mem_cons.mp ht with rfl | ht
      · exact join_valid a b (h a (by simp)) (h b (by simp))
      · exact ih (fun s hs => h s (by simp [hs])) t ht
  | case2 ts ht => cases ts with
    | nil => simpa [pair] using h
    | cons a ts => cases ts <;> simp_all [pair]

theorem pair_height (ts : List (SumTree α)) (d : ℕ) (h : ∀t∈ts,t.height ≤ d) :
    ∀t∈pair ts,t.height ≤ d+1 := by
  induction ts using pair.induct with
  | case1 a b ts ih =>
      intro t ht
      rcases List.mem_cons.mp ht with rfl | ht
      · have ha := h a (by simp); have hb := h b (by simp)
        simp only [join,height]; omega
      · exact ih (fun s hs => h s (by simp [hs])) t ht
  | case2 ts ht => cases ts with
    | nil => simp [pair]
    | cons a ts => cases ts <;> simp_all [pair] <;> omega

def rounds : ℕ → List (SumTree α) → List (SumTree α)
  | 0,ts => ts
  | d+1,ts => rounds d (pair ts)

def roundsWork : ℕ → List (SumTree α) → ℕ
  | 0,_ => 1
  | d+1,ts => pairWork ts+roundsWork d (pair ts)+4

theorem rounds_entries (d : ℕ) (ts : List (SumTree α)) :
    forestEntries (rounds d ts)=forestEntries ts := by
  induction d generalizing ts with
  | zero => rfl
  | succ d ih => rw [rounds,ih,pair_entries]

theorem rounds_single (d : ℕ) (ts : List (SumTree α)) (h : ts.length ≤ 2^d) :
    (rounds d ts).length ≤ 1 := by
  induction d generalizing ts with
  | zero => simpa [rounds] using h
  | succ d ih =>
      apply ih
      rw [pair_length]
      rw [pow_succ] at h
      omega

theorem rounds_valid (d : ℕ) (ts : List (SumTree α)) (h : ∀t∈ts,t.Valid) :
    ∀t∈rounds d ts,t.Valid := by
  induction d generalizing ts with
  | zero => exact h
  | succ d ih => exact ih (pair ts) (pair_valid ts h)

theorem rounds_height (d : ℕ) (ts : List (SumTree α)) (h : ∀t∈ts,t.height ≤ k) :
    ∀t∈rounds d ts,t.height ≤ k+d := by
  induction d generalizing ts k with
  | zero => simpa [rounds] using h
  | succ d ih =>
      have hh := ih (ts:=pair ts) (k:=k+1) (pair_height ts k h)
      simpa [rounds,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using hh

theorem roundsWork_bound (d : ℕ) (ts : List (SumTree α)) :
    roundsWork d ts ≤ 1+d*(32*(bits ts+ts.length)+5) := by
  induction d generalizing ts with
  | zero => simp [roundsWork]
  | succ d ih =>
      have hp := pair_potential ts
      have hw := pairWork_bound ts
      have hi := ih (pair ts)
      have hm := Nat.mul_le_mul_left d (by omega :
        32*(bits (pair ts)+(pair ts).length)+5 ≤ 32*(bits ts+ts.length)+5)
      simp only [roundsWork]
      nlinarith only [hw,hi,hm]

end SumTree
end BinaryMultiplicity
