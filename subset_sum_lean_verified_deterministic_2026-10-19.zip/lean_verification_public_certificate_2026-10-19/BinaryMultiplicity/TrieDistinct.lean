import BinaryMultiplicity.PreparedWords

namespace BinaryMultiplicity.Trie
variable {α : Type*}

/-- Proof view of the occupied addresses, in the actual groups traversal order. -/
def occupied : Trie α → List (List Bool)
  | .empty => []
  | .node here zero one =>
    (if here.isEmpty then [] else [[]])++
      (occupied zero).map (false::·)++(occupied one).map (true::·)

theorem occupied_nodup (t : Trie α) : t.occupied.Nodup := by
  induction t with
  | empty => simp [occupied]
  | node here zero one iz io =>
      have hz : ((occupied zero).map (false::·)).Nodup := iz.map (fun _ _ h => List.cons.inj h |>.2)
      have ho : ((occupied one).map (true::·)).Nodup := io.map (fun _ _ h => List.cons.inj h |>.2)
      simp only [occupied]
      cases here <;> simp [hz,ho,List.nodup_append,List.disjoint_left,List.mem_map]

theorem occupied_lookup (t : Trie α) :
    t.occupied.map (fun k => lookup k t)=groups t := by
  induction t with
  | empty => rfl
  | node here zero one iz io =>
      rw [groups_node]
      cases here <;> simp [occupied,List.map_append,List.map_map,Function.comp_def,lookup,iz,io]

theorem lookup_occupied_nonempty (t : Trie α) (k : List Bool) (hk : k∈t.occupied) :
    lookup k t≠[] := by
  apply groups_nonempty t
  rw [←occupied_lookup]
  exact List.mem_map.mpr ⟨k,hk,rfl⟩

theorem build_group_keys (key : α → List Bool) (xs : List α) (fallback : α) :
    ((groups (build key xs)).map (fun g => key (g.headD fallback)))=
      (build key xs).occupied := by
  rw [←occupied_lookup,List.map_map]
  conv_rhs => rw [←List.map_id (build key xs).occupied]
  apply List.map_congr_left
  intro k hk
  have hn := lookup_occupied_nonempty (build key xs) k hk
  have hm : (lookup k (build key xs)).headD fallback∈lookup k (build key xs) := by
    cases h : lookup k (build key xs) <;> simp_all
  rw [lookup_build] at hm
  simp only [Function.comp_apply,id_eq,lookup_build]
  exact (of_decide_eq_true (List.mem_filter.mp hm).2).symm

end BinaryMultiplicity.Trie

namespace BinaryMultiplicity
open Optss

theorem merged_key_nodup (xs : List Entry) : ((merged xs).map Entry.key).Nodup := by
  rw [merged_eq,List.map_map]
  change ((grouped xs).map (fun g => Entry.key (g.headD zeroEntry))).Nodup
  rw [grouped,Trie.build_group_keys]
  exact Trie.occupied_nodup _

theorem merged_value_nodup (xs : List Entry) : ((merged xs).map Entry.value).Nodup := by
  have hk := merged_key_nodup xs
  rw [List.Nodup,List.pairwise_map] at hk ⊢
  apply hk.imp_of_mem
  intro a b ha hb hkey hvalue
  apply hkey
  have hac := Preprocess.merged_weight_canonical xs a ha
  have hbc := Preprocess.merged_weight_canonical xs b hb
  simp only [Entry.key,hac,hbc,hvalue]

/-- Sparse grouping has one output record per occurring integer weight. -/
theorem merged_length_le_radius (xs : List Entry) (N : ℕ)
    (hweights : ∀x∈xs,x.value.natAbs ≤ N) : (merged xs).length ≤ 2*N+1 := by
  have hn := merged_value_nodup xs
  have hs : ((merged xs).map Entry.value).toFinset ⊆ Finset.Icc (-(N:ℤ)) (N:ℤ) := by
    intro z hz
    obtain ⟨y,hy,rfl⟩ := List.mem_map.mp (List.mem_toFinset.mp hz)
    obtain ⟨x,hx,he⟩ := merged_value_mem xs y hy
    have h := hweights x hx
    rw [he,Finset.mem_Icc]
    omega
  have hc := Finset.card_le_card hs
  rw [List.toFinset_card_of_nodup hn,List.length_map,Int.card_Icc] at hc
  norm_num at hc
  omega

end BinaryMultiplicity
