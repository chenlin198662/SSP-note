import BinaryMultiplicity.RecoveryRows

namespace BinaryMultiplicity.Recovery
open Optss

def wordBits (xs : List (List Bool)) : ℕ := (xs.map List.length).sum
def anchorBits (xs : List (Entry×List Bool)) : ℕ := (xs.map (fun x => x.2.length)).sum

theorem subtraction_length (a b : List Bool) : (bitListTrim (bitListSub a b)).length ≤ a.length := by
  rw [bitListTrim_canonical,Nat.size_eq_bits_len,bitListTrim_value,bitListSub_correct]
  exact (Nat.size_le_size (Nat.sub_le _ _)).trans
    (Nat.size_le.mpr (binaryDigitsValue_lt_pow a))

def restoreRowsWork : List (Entry×List Bool) → List (List Bool) → ℕ
  | [],_ => 1
  | (_,q)::rows,a::b::counts => SumTree.subtractWork q a+
      SumTree.addWork (bitListTrim (bitListSub q a)) b+8+restoreRowsWork rows counts
  | _::rows,_ => 4+restoreRowsWork rows []

theorem restoreRowsWork_bound (rows : List (Entry×List Bool)) (counts : List (List Bool)) :
    restoreRowsWork rows counts ≤ 32*(anchorBits rows+wordBits counts+rows.length)+1 := by
  induction rows generalizing counts with
  | nil => simp [restoreRowsWork,anchorBits]
  | cons x rows ih =>
    cases counts with
    | nil =>
      have ht := ih []
      simp only [restoreRowsWork,anchorBits,wordBits,List.map_cons,List.sum_cons,List.map_nil,
        List.sum_nil,List.length_cons] at *
      omega
    | cons a counts => cases counts with
      | nil =>
        have ht := ih []
        simp only [restoreRowsWork,anchorBits,wordBits,List.map_cons,List.sum_cons,List.map_nil,
          List.sum_nil,List.length_cons] at *
        omega
      | cons b counts =>
        have ht := ih counts
        have hs := SumTree.subtractWork_bound x.2 a (x.2.length+a.length) (by omega) (by omega)
        have ha := SumTree.addWork_bound (bitListTrim (bitListSub x.2 a)) b
        have hl := subtraction_length x.2 a
        simp only [restoreRowsWork,anchorBits,wordBits,List.map_cons,List.sum_cons,List.length_cons] at *
        omega

def uncomplementWork : List Entry → List (List Bool) → ℕ
  | [],_ => 1
  | x::xs,c::cs => (if x.weight.negative then SumTree.subtractWork x.count c else 0)+8+
      uncomplementWork xs cs
  | _::xs,[] => 4+uncomplementWork xs []

theorem uncomplementWork_bound (xs : List Entry) (counts : List (List Bool)) :
    uncomplementWork xs counts ≤ 16*(countBits xs+wordBits counts+xs.length)+1 := by
  induction xs generalizing counts with
  | nil => simp [uncomplementWork,countBits]
  | cons x xs ih =>
    cases counts with
    | nil =>
      have ht := ih []
      simp only [uncomplementWork,countBits,wordBits,List.map_cons,List.sum_cons,List.map_nil,
        List.sum_nil,List.length_cons] at *
      omega
    | cons c cs =>
      have ht := ih cs
      have hs := SumTree.subtractWork_bound x.count c (x.count.length+c.length) (by omega) (by omega)
      simp only [uncomplementWork,countBits,wordBits,List.map_cons,List.sum_cons,List.length_cons] at *
      split <;> omega

end BinaryMultiplicity.Recovery
