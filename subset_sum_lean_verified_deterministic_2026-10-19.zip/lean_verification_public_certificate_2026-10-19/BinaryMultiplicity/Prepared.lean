import BinaryMultiplicity.DenseSemantics
import BinaryMultiplicity.DenseWork
import BinaryMultiplicity.LogNormalization

namespace BinaryMultiplicity.Prepared
open Optss SubsetSum SubsetSum.CostedArrayProgram SubsetSum.ExternalCostContracts

inductive Answer where
  | terminal (b : Bool)
  | reduced (counts : Array ℤ) (residual : ℕ)

structure Output where
  answer : Answer
  work : ℕ

def run (F : ExactIntegerConvolution) (rates : Rates)
    (xs : List Entry) (target : BitListInteger) (radius : List Bool) : Output :=
  let initial := FullPreprocess.run xs target radius
  match initial.answer with
  | .terminal b => ⟨.terminal b,initial.work+4⟩
  | .reduced out =>
      let table := Dense.run (binaryDigitsValue radius) out.capped
      ⟨.reduced (table.value F) (binaryDigitsValue out.pivot.residual),
        initial.work+table.cost F rates+8⟩

def CountFeasible (N : ℕ) (counts : Array ℤ) (r : ℕ) : Prop :=
  InteriorReduction.CountFeasible (ScalarInitialState.items N)
    (fun i => (CostedScalarTypes.capacity N counts i:ℤ)) {fun _ => (r:ℤ)}

def Correct (N : ℕ) (xs : List Entry) (target : ℤ) : Answer → Prop
  | .terminal b => b=true ↔ Feasible xs target
  | .reduced counts r =>
      r<N ∧ CostedDenseArray.Bounded counts (2*N+1) (2*N).size ∧
      (∑i,CostedScalarTypes.capacity N counts i) ≤ 4*N^2 ∧
      (CountFeasible N counts r ↔ Feasible xs target)

/-- The literal original binary-input call returns either a correct answer
or a correctly capped stored initial count table for the existing recursion. -/
theorem run_correct (F : ExactIntegerConvolution) (rates : Rates)
    (xs : List Entry) (target : BitListInteger) (radius : List Bool)
    (hb : ∀x∈xs,x.value.natAbs ≤ binaryDigitsValue radius) :
    Correct (binaryDigitsValue radius) xs target.value (run F rates xs target radius).answer := by
  have hc := FullPreprocess.run_correct xs target radius hb
  cases ho : (FullPreprocess.run xs target radius).answer with
  | terminal b => simpa only [run,ho,Correct,Preprocess.Correct] using hc
  | reduced out =>
    have hs := FullPreprocess.run_reduced_bounds xs target radius hb out ho
    have hN : 0<binaryDigitsValue radius := Nat.zero_lt_of_lt hs.target
    have hd := Dense.run_feasible F (binaryDigitsValue radius) out.capped hN hs.weights
      (binaryDigitsValue out.pivot.residual) hs.target
    rw [ho] at hc
    simp only [run,ho,Correct]
    exact ⟨hs.target,Dense.run_bounded F _ _,Dense.run_mass F _ _,hd.trans hc⟩

theorem reduced_work (F : ExactIntegerConvolution) (rates : Rates) (N : ℕ)
    (out : AnchoredInstance.Output) (hs : Preprocess.ReducedBounds N out) :
    (Dense.run N out.capped).cost F rates ≤ 896*(N+1)*(N.size+8)^2 := by
  let B := N.size+5
  have hlen : out.capped.length.size ≤ B := by
    have h := Nat.size_le_size hs.length
    have hh := Nat.lt_size_self N
    have hk : (4*N+2).size ≤ N.size+2 := by
      apply Nat.size_le.mpr
      rw [pow_add]
      norm_num
      omega
    dsimp [B]; omega
  have hk := nat_mul_size_le 2 N
  have ht : (2:ℕ).size=2 := by simpa using (Nat.size_pow (n:=1))
  have hcap : (2*N).size ≤ B := by dsimp [B]; omega
  have h := Dense.run_cost F rates N B out.capped (by dsimp[B]; omega) hlen
    (fun x hx => (Nat.size_le_size (hs.weights x hx)).trans (by dsimp[B]; omega))
    (fun x hx => (Nat.size_le_size (hs.capacities x hx)).trans hcap) hs.weights
  calc
    _ ≤ (N+out.capped.length+1)*128*(B+3)^2 := h
    _ ≤ (7*(N+1))*128*(B+3)^2 := by gcongr; have hl:=hs.length; omega
    _ = _ := by dsimp[B]; ring

/-- Complete preprocessing work with explicit polylogarithmic input factor
and the honest restoring-division size product. -/
theorem run_work (F : ExactIntegerConvolution) (rates : Rates)
    (xs : List Entry) (target : BitListInteger) (radius : List Bool)
    (hb : ∀x∈xs,x.value.natAbs ≤ binaryDigitsValue radius) :
    let L := FullPreprocess.inputLength xs target radius
    let N := binaryDigitsValue radius
    (run F rates xs target radius).work ≤
      16*FullPreprocess.logCoefficient*L*(L.size+1)^FullPreprocess.logPower+
      4096*L*(N.size+1)+896*(N+1)*(N.size+8)^2+8 := by
  dsimp only
  have hi := FullPreprocess.run_work_explicit_log xs target radius _ hb (le_refl _)
  dsimp only at hi
  cases ho : (FullPreprocess.run xs target radius).answer with
  | terminal b =>
      simp only [run,ho]
      omega
  | reduced out =>
      have hs := FullPreprocess.run_reduced_bounds xs target radius hb out ho
      have hd := reduced_work F rates _ out hs
      simp only [run,ho]
      omega

end BinaryMultiplicity.Prepared
