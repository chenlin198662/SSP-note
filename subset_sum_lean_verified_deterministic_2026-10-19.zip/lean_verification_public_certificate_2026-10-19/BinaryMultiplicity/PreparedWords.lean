import BinaryMultiplicity.FullPreprocess
import BinaryMultiplicity.WeightedWork

namespace BinaryMultiplicity.Preprocess
open Optss

theorem storedWord_build_length (xs : List (Entry × List Bool)) :
    (WeightedTotals.storedWord (SumTree.build xs).1).length ≤ SumTree.inputBits xs+xs.length := by
  cases ht : (SumTree.build xs).1 with
  | none => simp [WeightedTotals.storedWord]
  | some tree => exact SumTree.allWidths_root _ tree (SumTree.build_allWidths xs tree ht)

theorem full_length (xs : List Entry) :
    (WeightedTotals.storedWord (WeightedTotals.run xs).full).length ≤ inputSize xs+xs.length := by
  have h := storedWord_build_length (WeightedTotals.weightedLeaves xs)
  have hw := WeightedTotals.weighted_width xs
  have hl : (WeightedTotals.weightedLeaves xs).length=xs.length := by simp [WeightedTotals.weightedLeaves]
  rw [hl] at h
  exact h.trans (Nat.add_le_add_right hw _)

theorem negative_length (xs : List Entry) :
    (WeightedTotals.storedWord (WeightedTotals.run xs).negative).length ≤ inputSize xs+xs.length := by
  have h := storedWord_build_length (WeightedTotals.negativeLeaves (WeightedTotals.weightedLeaves xs))
  have hw := (WeightedTotals.negative_width _).trans (WeightedTotals.weighted_width xs)
  have hl : (WeightedTotals.negativeLeaves (WeightedTotals.weightedLeaves xs)).length=xs.length := by
    simp [WeightedTotals.negativeLeaves,WeightedTotals.weightedLeaves]
  rw [hl] at h
  exact h.trans (Nat.add_le_add_right hw _)

theorem normalize_digits (z : BitListInteger) :
    (ConvolutionDraft.CanonicalOutput.normalize z).digits=z.digits := by
  cases h : z.digits <;> simp [ConvolutionDraft.CanonicalOutput.normalize,h]

theorem shifted_length (target : BitListInteger) (negative : List Bool) :
    (shiftedTarget target negative).digits.length ≤ target.digits.length+negative.length+1 := by
  rw [shiftedTarget,normalize_digits]
  have h := bitListIntegerAdd_length target ⟨false,negative⟩
  exact h.trans (by simp only; omega)

theorem limit_length (radius : List Bool) : (limit radius).length ≤ radius.length+1 :=
  bitListTrim_length_le _

theorem merged_weight_canonical (xs : List Entry) (y : Entry) (hy : y∈BinaryMultiplicity.merged xs) :
    y.weight=integerBitRepresentation y.value := by
  rw [merged_eq] at hy
  obtain ⟨g,hg,rfl⟩ := List.mem_map.mp hy
  have hne := Trie.groups_nonempty (Trie.build Entry.key (normalized xs)) g hg
  have hm : g.headD zeroEntry∈g := by cases g <;> simp_all
  have hf : g.headD zeroEntry∈(grouped xs).flatten := List.mem_flatten.mpr ⟨g,hg,hm⟩
  have hn : g.headD zeroEntry∈normalized xs := (grouped_partition xs).mem_iff.mp hf
  obtain ⟨x,hx,he⟩ := List.mem_map.mp hn
  have hw : (mergedEntry g).weight=(g.headD zeroEntry).weight := rfl
  rw [merged_value,hw,←he,Entry.normalize_value]
  exact Entry.normalizeWeight_representation _

theorem merged_weight_length (xs : List Entry) (N : ℕ)
    (hweights : ∀x∈xs,x.value.natAbs ≤ N) :
    ∀y∈BinaryMultiplicity.merged xs,y.weight.digits.length ≤ N.size := by
  intro y hy
  obtain ⟨x,hx,he⟩ := merged_value_mem xs y hy
  rw [merged_weight_canonical xs y hy,integerBitRepresentation_length,he]
  exact Nat.size_le_size (hweights x hx)

end BinaryMultiplicity.Preprocess
