import BinaryMultiplicity.AnchoredWork

namespace BinaryMultiplicity.Recovery
open Optss

def BitWitness (xs : List Entry) (counts : List (List Bool)) (t : ℤ) : Prop :=
  Witness xs (counts.map binaryDigitsValue) t

def restoreCount (anchor minus plus : List Bool) : List Bool :=
  bitListAdd (bitListTrim (bitListSub anchor minus)) plus

def restoreRows : List (Entry×List Bool) → List (List Bool) → List (List Bool)
  | [],_ => []
  | (_,q)::rows,a::b::counts => restoreCount q a b::restoreRows rows counts
  | _::rows,_ => []::restoreRows rows []

theorem restoreCount_value (q a b : List Bool) : binaryDigitsValue (restoreCount q a b)=
    binaryDigitsValue q-binaryDigitsValue a+binaryDigitsValue b := by
  simp only [restoreCount,bitListAdd_correct,bitListTrim_value,bitListSub_correct]

/-- The executed inverse anchor map returns one count per original type. -/
theorem restoreRows_correct (rows : List (Entry×List Bool))
    (hbound : ∀x∈rows,binaryDigitsValue x.2 ≤ x.1.capacity)
    (counts : List (List Bool)) (t : ℤ) (hw : BitWitness (residualRows rows) counts t) :
    BitWitness (rows.map Prod.fst) (restoreRows rows counts) (t+anchorValue rows) := by
  induction rows generalizing counts t with
  | nil =>
    cases counts with
    | nil => cases hw; exact Witness.nil
    | cons c cs => cases hw
  | cons x rows ih =>
    cases counts with
    | nil => cases hw
    | cons a cs => cases cs with
      | nil => cases hw with | cons ha ht => cases ht
      | cons b cs =>
        cases hw with
        | cons ha ht => cases ht with
          | cons hb ht =>
            rename_i tailSum
            have hq := hbound x List.mem_cons_self
            have htail := ih (fun y hy => hbound y (List.mem_cons_of_mem _ hy)) cs _ ht
            have hcap : binaryDigitsValue (restoreCount x.2 a b) ≤ x.1.capacity := by
              rw [restoreCount_value]
              change binaryDigitsValue a ≤ binaryDigitsValue x.2 at ha
              rw [positiveResidual_capacity] at hb
              omega
            have he : (binaryDigitsValue (restoreCount x.2 a b):ℤ)*x.1.value+
                (tailSum+anchorValue rows)=
                ((binaryDigitsValue a:ℤ)*(negativeResidual x.1 x.2).value+
                  ((binaryDigitsValue b:ℤ)*(positiveResidual x.1 x.2).value+tailSum))+
                anchorValue (x::rows) := by
              rw [restoreCount_value,negativeResidual_value,positiveResidual_value]
              change binaryDigitsValue a ≤ binaryDigitsValue x.2 at ha
              rw [Nat.cast_add,Int.ofNat_sub ha]
              simp only [anchorValue,List.map_cons,List.sum_cons]
              ring
            exact he ▸ Witness.cons hcap htail

theorem uncap_witness (limit : List Bool) (xs : List Entry) (counts : List (List Bool)) (t : ℤ)
    (hw : BitWitness (capRows limit xs) counts t) : BitWitness xs counts t := by
  induction xs generalizing counts t with
  | nil => exact hw
  | cons x xs ih =>
    cases counts with
    | nil => cases hw
    | cons c cs => cases hw with
      | cons hc ht =>
        rw [capEntry_capacity] at hc
        exact Witness.cons (hc.trans (Nat.min_le_left _ _)) (ih cs _ ht)

def uncomplement : List Entry → List (List Bool) → List (List Bool)
  | [],_ => []
  | x::xs,c::cs => (if x.weight.negative then bitListTrim (bitListSub x.count c) else c)::uncomplement xs cs
  | _::xs,[] => []::uncomplement xs []

theorem uncomplement_correct (xs : List Entry) (counts : List (List Bool)) (t : ℤ)
    (hw : BitWitness (positiveEntries xs) counts t) :
    BitWitness xs (uncomplement xs counts) (t-negativeOffset xs) := by
  induction xs generalizing counts t with
  | nil =>
    cases counts with
    | nil => cases hw; exact Witness.nil
    | cons c cs => cases hw
  | cons x xs ih =>
    cases counts with
    | nil => cases hw
    | cons c cs => cases hw with
      | cons hc ht =>
        rename_i tailSum
        have hh := ih cs _ ht
        cases hs : x.weight.negative with
        | false =>
          have hv : x.value=(positiveEntry x).value := by
            simp [Entry.value,BitListInteger.value,signedBitsValue,hs,positiveEntry]
          have he : ((binaryDigitsValue c:ℤ)*x.value+(tailSum-negativeOffset xs))=
              ((binaryDigitsValue c:ℤ)*(positiveEntry x).value+tailSum)-negativeOffset (x::xs) := by
            simp only [negativeOffset,List.map_cons,List.sum_cons,hs,Bool.false_eq_true,if_false,zero_add]
            rw [hv]
            ring
          simpa only [uncomplement,hs,Bool.false_eq_true,if_false] using he ▸ Witness.cons hc hh
        | true =>
          have hv : x.value= -(positiveEntry x).value := by
            simp [Entry.value,BitListInteger.value,signedBitsValue,hs,positiveEntry]
          have hc' : binaryDigitsValue c ≤ x.capacity := hc
          have hb : binaryDigitsValue (bitListTrim (bitListSub x.count c)) ≤ x.capacity := by
            rw [bitListTrim_value,bitListSub_correct]
            exact Nat.sub_le _ _
          have he : (binaryDigitsValue (bitListTrim (bitListSub x.count c)):ℤ)*x.value+
              (tailSum-negativeOffset xs)=
              ((binaryDigitsValue c:ℤ)*(positiveEntry x).value+tailSum)-negativeOffset (x::xs) := by
            rw [bitListTrim_value,bitListSub_correct]
            change _ ≤ binaryDigitsValue x.count at hc'
            rw [Int.ofNat_sub hc',hv]
            simp only [negativeOffset,List.map_cons,List.sum_cons,hs,if_true,positive_value,Entry.capacity]
            ring
          simpa only [uncomplement,hs,if_true] using he ▸ Witness.cons hb hh

end BinaryMultiplicity.Recovery
