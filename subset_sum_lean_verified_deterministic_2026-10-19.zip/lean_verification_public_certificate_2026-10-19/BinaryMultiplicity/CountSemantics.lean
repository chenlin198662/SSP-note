import BinaryMultiplicity.Input

namespace BinaryMultiplicity

/-- A count witness; its length is the number of input records, not the
number of represented physical copies. -/
inductive Witness : List Entry → List ℕ → ℤ → Prop
  | nil : Witness [] [] 0
  | cons {x : Entry} {xs : List Entry} {n : ℕ} {ns : List ℕ} {t : ℤ}
      (bound : n ≤ x.capacity) (tail : Witness xs ns t) :
      Witness (x::xs) (n::ns) ((n : ℤ)*x.value+t)

def Feasible (xs : List Entry) (target : ℤ) : Prop := ∃counts,Witness xs counts target

theorem Witness.length {xs counts target} (h : Witness xs counts target) : counts.length=xs.length := by
  induction h <;> simp_all

theorem feasible_nil (t : ℤ) : Feasible [] t ↔ t=0 := by
  constructor
  · rintro ⟨counts,h⟩; cases h; rfl
  · rintro rfl; exact ⟨[],Witness.nil⟩

theorem feasible_cons (x : Entry) (xs : List Entry) (t : ℤ) :
    Feasible (x::xs) t ↔ ∃n ≤ x.capacity,∃s,Feasible xs s ∧ (n:ℤ)*x.value+s=t := by
  constructor
  · rintro ⟨counts,h⟩
    cases h with
    | cons hn ht => exact ⟨_,hn,_,⟨_,ht⟩,rfl⟩
  · rintro ⟨n,hn,s,⟨ns,hs⟩,he⟩
    exact he ▸ ⟨n::ns,Witness.cons hn hs⟩

theorem feasible_perm {xs ys : List Entry} (h : xs.Perm ys) (t : ℤ) :
    Feasible xs t ↔ Feasible ys t := by
  induction h generalizing t with
  | nil => rfl
  | cons x hp ih => simp only [feasible_cons,ih]
  | swap x y xs =>
      simp only [feasible_cons]
      constructor <;> rintro ⟨a,ha,s,⟨b,hb,u,hu,hs⟩,ht⟩
      · refine ⟨b,hb,_,⟨a,ha,u,hu,rfl⟩,?_⟩
        rw [←ht,←hs]; ring
      · refine ⟨b,hb,_,⟨a,ha,u,hu,rfl⟩,?_⟩
        rw [←ht,←hs]; ring
  | trans h1 h2 i1 i2 => exact (i1 t).trans (i2 t)

theorem feasible_append (xs ys : List Entry) (t : ℤ) :
    Feasible (xs++ys) t ↔ ∃a b,Feasible xs a ∧ Feasible ys b ∧ a+b=t := by
  induction xs generalizing t with
  | nil => simp [feasible_nil]
  | cons x xs ih =>
      simp only [List.cons_append,feasible_cons,ih]
      constructor
      · rintro ⟨n,hn,s,⟨a,b,ha,hb,hs⟩,ht⟩
        refine ⟨(n:ℤ)*x.value+a,b,⟨n,hn,a,ha,rfl⟩,hb,?_⟩
        omega
      · rintro ⟨a,b,⟨n,hn,c,hc,ha⟩,hb,ht⟩
        refine ⟨n,hn,c+b,⟨c,b,hc,hb,rfl⟩,?_⟩
        omega

def capacitySum (xs : List Entry) : ℕ := (xs.map Entry.capacity).sum

/-- All counts from zero through the sum of capacities are achievable inside
one equal-weight group. The reverse direction uses the explicit min split. -/
theorem feasible_same_value (xs : List Entry) (w t : ℤ)
    (h : ∀x∈xs,x.value=w) :
    Feasible xs t ↔ ∃n ≤ capacitySum xs,(n:ℤ)*w=t := by
  induction xs generalizing t with
  | nil => simp [feasible_nil,capacitySum,eq_comm]
  | cons x xs ih =>
      have hx := h x List.mem_cons_self
      have hh := fun y hy => h y (List.mem_cons_of_mem _ hy)
      rw [feasible_cons]
      constructor
      · rintro ⟨n,hn,s,hs,ht⟩
        obtain ⟨m,hm,he⟩ := (ih s hh).mp hs
        refine ⟨n+m,?_,?_⟩
        · simp only [capacitySum,List.map_cons,List.sum_cons] at *; omega
        · rw [Nat.cast_add,add_mul]
          rw [hx] at ht
          omega
      · rintro ⟨q,hq,he⟩
        let n := min x.capacity q
        let m := q-n
        have hn : n ≤ x.capacity := min_le_left _ _
        have hnq : n ≤ q := min_le_right _ _
        have hm : m ≤ capacitySum xs := by
          dsimp [m,n]
          simp only [capacitySum,List.map_cons,List.sum_cons] at hq ⊢
          omega
        have hnm : n+m=q := by dsimp [m]; omega
        refine ⟨n,hn,(m:ℤ)*w,(ih _ hh).mpr ⟨m,hm,rfl⟩,?_⟩
        rw [hx,←add_mul,←Nat.cast_add,hnm,he]

theorem feasible_singleton (x : Entry) (t : ℤ) :
    Feasible [x] t ↔ ∃n ≤ x.capacity,(n:ℤ)*x.value=t := by
  simp [feasible_cons,feasible_nil]

/-- Generic exact semantics of merging one equal-weight group. Both the
representative value and merged count are facts about actual stored outputs. -/
theorem feasible_merge_group (xs : List Entry) (out : Entry)
    (hvalue : ∀x∈xs,x.value=out.value) (hcount : out.capacity=capacitySum xs) (t : ℤ) :
    Feasible xs t ↔ Feasible [out] t := by
  rw [feasible_same_value xs out.value t hvalue,feasible_singleton,hcount]

end BinaryMultiplicity
