import BinaryMultiplicity.SparseMerge
import BinaryMultiplicity.TreeWork

namespace BinaryMultiplicity
open Optss

def countBits (xs : List Entry) : ℕ := (xs.map (fun x  =>  x.count.length)).sum
def inputSize (xs : List Entry) : ℕ := (xs.map Entry.bits).sum

theorem countBits_flatten (gs : List (List Entry)) :
    countBits gs.flatten=(gs.map countBits).sum := by
  induction gs with
  | nil  =>  rfl
  | cons g gs ih  =>  simpa [countBits,List.map_append,List.sum_append] using congrArg (fun n => countBits g+n) ih

theorem normalized_countBits (xs : List Entry) : countBits (normalized xs) ≤ inputSize xs := by
  induction xs with
  | nil  =>  rfl
  | cons x xs ih  => 
      have h := bitListTrim_length_le x.count
      simp only [countBits,inputSize,normalized,List.map_cons,List.sum_cons,Entry.normalize,Entry.bits] at *
      omega

theorem grouped_lengths (xs : List Entry) : ((grouped xs).map List.length).sum=xs.length := by
  have h := (grouped_partition xs).length_eq
  simpa [List.length_flatten,normalized] using h

theorem grouped_countBits (xs : List Entry) : ((grouped xs).map countBits).sum ≤ inputSize xs := by
  rw [←countBits_flatten]
  have he := ((grouped_partition xs).map (fun x => x.count.length)).sum_eq
  exact he.le.trans (normalized_countBits xs)

theorem nonempty_groups_length (gs : List (List Entry)) (h : ∀g∈gs,g≠[]) :
    gs.length ≤ (gs.map List.length).sum := by
  induction gs with
  | nil  =>  rfl
  | cons g gs ih  => 
      have hg := h g List.mem_cons_self
      have hp : 0<g.length := List.length_pos.mpr hg
      have ht := ih (fun a ha => h a (List.mem_cons_of_mem _ ha))
      simp only [List.length_cons,List.map_cons,List.sum_cons]
      omega

theorem grouped_length (xs : List Entry) : (grouped xs).length ≤ xs.length := by
  rw [←grouped_lengths xs]
  exact nonempty_groups_length _ (Trie.groups_nonempty _)

theorem grouped_member_length (xs : List Entry) (g : List Entry) (hg : g∈grouped xs) :
    g.length ≤ xs.length := by
  rw [←grouped_lengths xs]
  exact List.single_le_sum (fun n _ => Nat.zero_le n) g.length (List.mem_map.mpr ⟨g,hg,rfl⟩)

theorem sum_mergeGroup_work (gs : List (List Entry)) (m : ℕ) (h : ∀g∈gs,g.length ≤ m) :
    (gs.map (fun g => (mergeGroup g).2)).sum  ≤ 
      128*((gs.map countBits).sum+(gs.map List.length).sum+gs.length)*(m.size+3)^3+
      4*(gs.map List.length).sum+8*gs.length := by
  induction gs with
  | nil  =>  simp
  | cons g gs ih  => 
      have hg := mergeGroup_work g
      have hb := SumTree.buildBudget_linear_log g.length (countBits g) m.size
        (Nat.size_le_size (h g List.mem_cons_self))
      have ht := ih (fun x hx => h x (List.mem_cons_of_mem _ hx))
      change (mergeGroup g).2 ≤ SumTree.buildBudget g.length (countBits g)+4*g.length+8 at hg
      simp only [List.map_cons,List.sum_cons,List.length_cons]
      nlinarith only [hg,hb,ht]

theorem normalization_work_sum (xs : List Entry) :
    (xs.map Entry.normalizeWork).sum=12*inputSize xs+12*xs.length := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
      simp only [List.map_cons,List.sum_cons,Entry.normalizeWork,inputSize,List.length_cons] at *
      omega

/-- Sparse grouping and all balanced multiplicity sums have an explicit
linear-times-polylog input-bit bound, independent of the numeric weight range. -/
theorem merge_work_nearlinear (xs : List Entry) :
    (merge xs).2  ≤ 
      128*(inputSize xs+2*xs.length)*(xs.length.size+3)^3+
      38*inputSize xs+54*xs.length+10 := by
  have hg := sum_mergeGroup_work (grouped xs) xs.length (grouped_member_length xs)
  have hbits := grouped_countBits xs
  have hlen := grouped_length xs
  rw [grouped_lengths xs] at hg
  have hm := Nat.mul_le_mul_right ((xs.length.size+3)^3)
    (Nat.mul_le_mul_left 128 (show
      ((grouped xs).map countBits).sum+xs.length+(grouped xs).length ≤ inputSize xs+2*xs.length by omega))
  have htrie := sparse_group_work xs
  have hn := normalization_work_sum xs
  dsimp only [merge]
  simp only [List.map_map,Function.comp_def]
  rw [hn]
  change _ ≤ 128*(inputSize xs+2*xs.length)*(xs.length.size+3)^3+38*inputSize xs+54*xs.length+10
  change _ ≤ 26*(inputSize xs+xs.length)+2 at htrie
  nlinarith only [hg,hm,htrie,hlen]

end BinaryMultiplicity

