import BinaryMultiplicity.ResidualWork

namespace BinaryMultiplicity.AnchoredInstance
open Optss

theorem allWidths_mono (tree : SumTree Entry) {B C : ℕ} (h : B ≤ C) (ht : tree.AllWidths B) :
    tree.AllWidths C := by
  induction tree with
  | leaf a w => exact ht.trans h
  | node w l r il ir => exact ⟨ht.1.trans h,il ht.2.1,ir ht.2.2⟩

theorem run_work (xs : List Entry) (tree : SumTree Entry)
    (htree : (WeightedTotals.run xs).full=some tree) (target limit : List Bool)
    (htarget : binaryDigitsValue target<WeightedTotals.total xs) (W : ℕ)
    (hW : ∀x∈xs,x.weight.digits.length ≤ W) :
    let B := SumTree.inputBits (WeightedTotals.weightedLeaves xs)+xs.length+target.length
    (run tree target limit).work ≤
      32*(B+1)*(xs.length.size+1)+16*(B+1)*(W+1)+
      38*countBits xs+(18*limit.length+64)*xs.length+20 := by
  dsimp only
  let p := Pivot.run tree target
  let raw := AnchorRows.fill tree p.path p.anchor
  let rows := positiveRows raw
  let B := SumTree.inputBits (WeightedTotals.weightedLeaves xs)+xs.length+target.length
  have hs := WeightedTotals.full_spec xs tree htree
  obtain ⟨before,after,he,hprefix,hq,hr⟩ := Pivot.run_spec xs tree htree target htarget
  have hd : 0<binaryDigitsValue (tree.descend target).payload.weight.digits := by
    change 0<WeightedTotals.magnitude p.entry
    have hr' : binaryDigitsValue p.residual<WeightedTotals.magnitude p.entry := hr
    omega
  have hpW : (tree.descend target).payload.weight.digits.length ≤ W := by
    change p.entry.weight.digits.length ≤ W
    apply hW
    rw [he]; simp [p]
  have htreeB : tree.AllWidths B := allWidths_mono tree (Nat.le_add_right _ _) hs.2.2.2
  have hp := Pivot.work_bound tree target B W htreeB (by dsimp [B]; omega) hd hpW
  have hm := Nat.mul_le_mul_left (32*(B+1)) (Nat.add_le_add_right hs.2.2.1 1)
  have hfill := AnchorRows.fillWork_linear tree p.path
  have horder : raw.map Prod.fst=xs := by
    rw [show raw=AnchorRows.fill tree p.path p.anchor from rfl,AnchorRows.fill_order,hs.1]
    simp [WeightedTotals.weightedLeaves,List.map_map,Function.comp_def]
  have hlen : raw.length=xs.length := by simpa using congrArg List.length horder
  have htreelen : tree.entries.length=xs.length := by rw [hs.1]; simp [WeightedTotals.weightedLeaves]
  rw [htreelen] at hfill
  have hsource : sourceCountBits rows=countBits xs := by
    dsimp only [rows,positiveRows,sourceCountBits]
    rw [List.map_map]
    change (raw.map (fun x => x.1.count.length)).sum=countBits xs
    have he := congrArg (fun ys : List Entry => countBits ys) horder
    simpa [countBits,List.map_map,Function.comp_def] using he
  have hwords : AnchorRows.wordBits rows ≤ countBits xs := by
    have h := AnchorRows.fill_wordBits tree target p.anchor
      (AnchorRows.pivot_anchor_length xs tree htree target htarget)
    change AnchorRows.wordBits raw ≤ AnchorRows.capacityBits tree at h
    have he : AnchorRows.capacityBits tree=countBits xs := by
      rw [AnchorRows.capacityBits,hs.1]
      simp [WeightedTotals.weightedLeaves,countBits,List.map_map,Function.comp_def]
    rw [he] at h
    simpa [rows,positiveRows,AnchorRows.wordBits,List.map_map,Function.comp_def] using h
  have hrlen : rows.length=xs.length := by simp [rows,positiveRows,hlen]
  have hrw := residual_work_sum rows
  have hcb := residual_countBits rows
  have hcw := cap_work_sum (residualRows rows) limit
  rw [hsource,hrlen] at hrw
  rw [hsource] at hcb
  rw [residualRows_length,hrlen] at hcw
  change Pivot.work tree target+AnchorRows.fillWork tree p.path+
    (rows.map (fun x=>residualPairWork x.1 x.2)).sum+
    ((residualRows rows).map (capEntryWork limit)).sum+12*raw.length+8 ≤ _
  rw [hlen]
  change _ ≤ 32*(B+1)*(xs.length.size+1)+16*(B+1)*(W+1)+
    38*countBits xs+(18*limit.length+64)*xs.length+20
  nlinarith only [hp,hm,hfill,hrw,hcb,hcw,hwords]

end BinaryMultiplicity.AnchoredInstance
