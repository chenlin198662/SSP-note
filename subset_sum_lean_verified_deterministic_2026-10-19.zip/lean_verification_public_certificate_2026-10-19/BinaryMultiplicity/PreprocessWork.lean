import BinaryMultiplicity.PreparedWords
import BinaryMultiplicity.AnchoredWork

namespace BinaryMultiplicity.Preprocess
open Optss

theorem anchor_budget_le (B T C m s W r l : ℕ)
    (hT : 1 ≤ T) (hB : B ≤ 2*T) (hC : C ≤ T) (hm : m ≤ T) (hl : l ≤ r+1) :
    32*(B+1)*(s+1)+16*(B+1)*(W+1)+38*C+(18*l+64)*m+20 ≤
      512*T*(s+W+r+1) := by
  have h := show 32*(B+1)*(s+1)+16*(B+1)*(W+1)+38*C+(18*l+64)*m+20 ≤
      32*(2*T+1)*(s+1)+16*(2*T+1)*(W+1)+38*T+(18*(r+1)+64)*T+20 by gcongr
  have hs := Nat.mul_le_mul_right s hT
  have hW := Nat.mul_le_mul_right W hT
  have hr := Nat.mul_le_mul_right r hT
  nlinarith only [h,hs,hW,hr,hT]

theorem countBits_le_inputSize (xs : List Entry) : countBits xs ≤ inputSize xs := by
  rw [inputSize_eq]
  omega

theorem limit_length_numeric (radius : List Bool) :
    (limit radius).length ≤ (binaryDigitsValue radius).size+2 := by
  have hc := bitListTrim_canonical (false::radius)
  change BitListCanonical (limit radius) at hc
  rw [hc,Nat.size_eq_bits_len,limit_value]
  have h := nat_mul_size_le 2 (binaryDigitsValue radius)
  have he : (2:ℕ).size=2 := by simpa using (Nat.size_pow (n:=1))
  omega

/-- Full range dispatch plus actual anchor/residual/cap work. The only factor
outside a polylog of input bits is the explicitly displayed radius word length. -/
theorem after_work (xs : List Entry) (target : BitListInteger) (radius : List Bool)
    (W : ℕ) (hW : ∀x∈xs,x.weight.digits.length ≤ W) :
    let T := inputSize xs+xs.length+target.digits.length+radius.length+1
    (after xs target radius).2 ≤ (WeightedTotals.run xs).work+
      1024*T*(xs.length.size+W+(binaryDigitsValue radius).size+2) := by
  dsimp only
  let totals := WeightedTotals.run xs
  let negative := WeightedTotals.storedWord totals.negative
  let full := WeightedTotals.storedWord totals.full
  let shifted := shiftedTarget target negative
  let T := inputSize xs+xs.length+target.digits.length+radius.length+1
  let header := totals.work+bitListIntegerAddCost target ⟨false,negative⟩+
    SumTree.compareWork shifted.digits full+SumTree.compareWork full shifted.digits+
    bitListTrimVisits (false::radius)+20
  have hT : 1 ≤ T := by dsimp [T]; omega
  have hneg : negative.length ≤ inputSize xs+xs.length := negative_length xs
  have hfull : full.length ≤ inputSize xs+xs.length := full_length xs
  have hshift : shifted.digits.length ≤ T := (shifted_length target negative).trans (by dsimp [T]; omega)
  have htarg : target.digits.length ≤ T := by dsimp [T]; omega
  have hnf : negative.length ≤ T := by dsimp [T]; omega
  have hff : full.length ≤ T := by dsimp [T]; omega
  have ha := bitListIntegerAddCost_bound target ⟨false,negative⟩ T htarg hnf
  have hc := SumTree.compareWork_bound shifted.digits full T hshift hff
  have hd := SumTree.compareWork_bound full shifted.digits T hff hshift
  have htr : bitListTrimVisits (false::radius)=radius.length+2 := by
    simp [bitListTrimVisits_eq]
  have hheader : header ≤ totals.work+128*T := by
    have hr : radius.length ≤ T := by dsimp [T]; omega
    dsimp only [header]
    rw [htr]
    nlinarith only [ha,hc,hd,hr,hT]
  have hbase : header ≤ totals.work+1024*T*(xs.length.size+W+(binaryDigitsValue radius).size+2) := by
    have hm := Nat.mul_le_mul_left (128*T) (show 1 ≤ xs.length.size+W+(binaryDigitsValue radius).size+2 by omega)
    nlinarith only [hheader,hm]
  dsimp only [after]
  change ((if shifted.negative then _ else if bitListLE shifted.digits full then
      if bitListLE full shifted.digits then _ else _ else _):Answer × ℕ).2 ≤
    totals.work+1024*T*(xs.length.size+W+(binaryDigitsValue radius).size+2)
  split
  · exact hbase
  · split
    · split
      · exact hbase
      · rename_i hnegative hle hge
        cases ht : totals.full with
        | none => simpa only [header,full,ht] using hbase
        | some tree =>
            have hvalue : binaryDigitsValue full=WeightedTotals.total xs := WeightedTotals.full_value xs
            have htarget : binaryDigitsValue shifted.digits<WeightedTotals.total xs := by
              have hn : ¬binaryDigitsValue full ≤ binaryDigitsValue shifted.digits :=
                fun h=>hge ((bitListLE_correct _ _).mpr h)
              omega
            have hw := AnchoredInstance.run_work xs tree ht shifted.digits (limit radius) htarget W hW
            let B := SumTree.inputBits (WeightedTotals.weightedLeaves xs)+xs.length+shifted.digits.length
            have hwb := WeightedTotals.weighted_width xs
            change SumTree.inputBits (WeightedTotals.weightedLeaves xs) ≤ inputSize xs at hwb
            have hB : B ≤ 2*T := by dsimp [B,T]; omega
            have hC : countBits xs ≤ T := (countBits_le_inputSize xs).trans (by dsimp [T]; omega)
            have hm : xs.length ≤ T := by dsimp [T]; omega
            have hb := anchor_budget_le B T (countBits xs) xs.length xs.length.size W
              ((binaryDigitsValue radius).size+1)
              (limit radius).length hT hB hC hm (limit_length_numeric radius)
            have hwork : (AnchoredInstance.run tree shifted.digits (limit radius)).work ≤
                512*T*(xs.length.size+W+(binaryDigitsValue radius).size+2) := by
              simpa only [Nat.add_assoc] using hw.trans hb
            have hmono := Nat.mul_le_mul_left (128*T)
              (show 1 ≤ xs.length.size+W+(binaryDigitsValue radius).size+2 by omega)
            have hfinal : header+(AnchoredInstance.run tree shifted.digits (limit radius)).work ≤
                totals.work+1024*T*(xs.length.size+W+(binaryDigitsValue radius).size+2) := by
              nlinarith only [hheader,hwork,hmono]
            simpa only [header,full,ht] using hfinal
    · exact hbase

end BinaryMultiplicity.Preprocess

