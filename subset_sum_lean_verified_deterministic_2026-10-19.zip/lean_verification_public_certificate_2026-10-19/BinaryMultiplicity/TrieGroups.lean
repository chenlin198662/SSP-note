import BinaryMultiplicity.Trie

namespace BinaryMultiplicity.Trie
variable {α : Type*}

/-- Tail-passing traversal: every node is visited once, and whole payload
lists are linked by pointer. There is no concatenation of coefficient digits. -/
def groupsAcc : Trie α → List (List α) → List (List α)
  | .empty,tail => tail
  | .node here zero one,tail =>
      let children := groupsAcc zero (groupsAcc one tail)
      match here with
      | [] => children
      | _::_ => here::children

def groups (t : Trie α) : List (List α) := groupsAcc t []

def groupsWork (t : Trie α) : ℕ := 10*t.nodes+1

theorem groupsAcc_append (t : Trie α) (tail : List (List α)) :
    groupsAcc t tail=groups t++tail := by
  induction t generalizing tail with
  | empty => rfl
  | node here zero one iz io =>
      change groupsAcc (.node here zero one) tail=groupsAcc (.node here zero one) []++tail
      cases here <;> simp only [groupsAcc,iz,io,List.append_nil,List.cons_append,List.append_assoc]

theorem groups_node (here : List α) (zero one : Trie α) :
    groups (.node here zero one)=
      (if here.isEmpty then [] else [here])++groups zero++groups one := by
  cases here <;> dsimp only [groups,groupsAcc,List.isEmpty]
  all_goals simp only [groupsAcc_append,List.append_nil,List.nil_append,List.cons_append,
    if_true,Bool.false_eq_true,if_false,List.singleton_append]

theorem groups_flatten (t : Trie α) : (groups t).flatten=flatten t := by
  induction t with
  | empty => rfl
  | node here zero one iz io =>
      rw [groups_node]
      cases here <;> simp [List.flatten_append,iz,io,flatten,List.append_assoc]

theorem groups_nonempty (t : Trie α) : ∀g∈groups t,g≠[] := by
  induction t with
  | empty => simp [groups,groupsAcc]
  | node here zero one iz io =>
      rw [groups_node]
      intro g hg
      rcases List.mem_append.mp hg with hg | hg
      · rcases List.mem_append.mp hg with hg | hg
        · split_ifs at hg with hh
          · simp at hg
          · have he : g=here := by simpa using hg
            subst g
            simpa using hh
        · exact iz g hg
      · exact io g hg

theorem group_lookup (t : Trie α) (g : List α) (hg : g∈groups t) :
    ∃key,lookup key t=g := by
  induction t with
  | empty => simp [groups,groupsAcc] at hg
  | node here zero one iz io =>
      rw [groups_node] at hg
      rcases List.mem_append.mp hg with hg | hg
      · rcases List.mem_append.mp hg with hg | hg
        · split_ifs at hg with hh
          · simp at hg
          · have he : g=here := by simpa using hg
            exact ⟨[],by simpa [lookup] using he.symm⟩
        · obtain ⟨key,hkey⟩ := iz hg
          exact ⟨false::key,hkey⟩
      · obtain ⟨key,hkey⟩ := io hg
        exact ⟨true::key,hkey⟩

theorem build_groups_partition (key : α → List Bool) (xs : List α) :
    ((groups (build key xs)).flatten).Perm xs ∧
    (∀g∈groups (build key xs),g≠[] ∧ ∃k,g=xs.filter (fun x => decide (k=key x))) := by
  refine ⟨by rw [groups_flatten]; exact flatten_build key xs,?_⟩
  intro g hg
  obtain ⟨k,hk⟩ := group_lookup (build key xs) g hg
  exact ⟨groups_nonempty _ g hg,k,by rw [←hk,lookup_build]⟩

theorem build_groups_uniform (key : α → List Bool) (xs : List α)
    (g : List α) (hg : g∈groups (build key xs)) (a b : α) (ha : a∈g) (hb : b∈g) :
    key a=key b := by
  obtain ⟨_,k,hk⟩ := (build_groups_partition key xs).2 g hg
  rw [hk] at ha hb
  have hka := of_decide_eq_true (List.mem_filter.mp ha).2
  have hkb := of_decide_eq_true (List.mem_filter.mp hb).2
  exact hka.symm.trans hkb

theorem groupsWork_build (key : α → List Bool) (xs : List α) :
    groupsWork (build key xs) ≤ 10*keyBits key xs+1 := by
  unfold groupsWork
  exact Nat.add_le_add_right (Nat.mul_le_mul_left 10 (nodes_build key xs)) 1

end BinaryMultiplicity.Trie
