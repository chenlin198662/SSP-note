/-
Copyright (c) 2026 Junye Ji. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Junye Ji
-/
import NormalForms.Research.KannanBachem.Hermite.CoefficientSize
import NormalForms.Euclidean.Int
import NormalForms.Matrix.Hermite.Bezout

/-!
# Bounded Bézout coefficients for the principal-minor kernel

This is the Appendix postprocessing step from Kannan--Bachem: one coefficient
is reduced modulo the larger input, and the other is adjusted so the Bézout
identity is preserved.  The resulting coefficients have polynomial magnitude.
The operation package is kept explicit, so importing this research module does
not replace the core integer `ComputableEuclideanOps` instance.
-/
namespace NormalForms.Research.KannanBachem.Hermite

open NormalForms
open NormalForms.Matrix.Certificates
open NormalForms.Matrix.Elementary
open NormalForms.Matrix.Hermite

namespace Principal

/--
Kannan--Bachem's size-controlled integer Bézout data, projected from the exact
costed sign-magnitude reference implementation.
-/
def boundedIntXGCD (a b : Int) : XGCDResult Int :=
  instComputableEuclideanOpsInt.xgcd a b

@[simp] theorem boundedIntXGCD_gcd (a b : Int) :
    (boundedIntXGCD a b).gcd = (Int.gcd a b : Int) := by
  rfl

theorem boundedIntXGCD_bezout (a b : Int) :
    a * (boundedIntXGCD a b).leftCoeff +
        b * (boundedIntXGCD a b).rightCoeff =
      (boundedIntXGCD a b).gcd := by
  exact instComputableEuclideanOpsInt.xgcd_bezout_spec a b

/-- Explicit operation package used only by the principal-minor backend. -/
@[reducible] def boundedIntEuclideanOps :
    @ComputableEuclideanOps Int Int.euclideanDomain
      constructiveIntNormalizationMonoid :=
  instComputableEuclideanOpsInt

/--
Size-controlled two-row matrix, without installing another global instance.
The formula is stated directly so executable reduction does not unfold an
entire explicit `ComputableEuclideanOps` record at every matrix entry.
-/
def boundedBezoutReductionMatrix (a b : Int) :
    _root_.Matrix (Fin 2) (Fin 2) Int :=
  let data := boundedIntXGCD a b
  if data.gcd = 0 then
    1
  else
    !![data.leftCoeff, data.rightCoeff;
       -(b / data.gcd), a / data.gcd]

/-- Direct executable inverse of `boundedBezoutReductionMatrix`. -/
def boundedBezoutReductionInverseMatrix (a b : Int) :
    _root_.Matrix (Fin 2) (Fin 2) Int :=
  let data := boundedIntXGCD a b
  if data.gcd = 0 then
    1
  else
    !![a / data.gcd, -data.rightCoeff;
       b / data.gcd, data.leftCoeff]

theorem boundedBezoutReductionMatrix_mulVec (a b : Int) :
    _root_.Matrix.mulVec (boundedBezoutReductionMatrix a b) ![a, b] =
      ![(boundedIntXGCD a b).gcd, 0] := by
  let data := boundedIntXGCD a b
  by_cases hg : data.gcd = 0
  · have bothZero : a = 0 ∧ b = 0 :=
      (@ComputableEuclideanOps.xgcd_gcd_eq_zero_iff Int Int.euclideanDomain
        constructiveIntNormalizationMonoid boundedIntEuclideanOps a b).1 hg
    simp [boundedBezoutReductionMatrix, bothZero.1, bothZero.2]
  · rw [boundedBezoutReductionMatrix, if_neg hg]
    ext index
    fin_cases index
    · rw [_root_.Matrix.mulVec, dotProduct,
        NormalForms.Matrix.Constructive.sum_univ_two]
      simpa [data, mul_comm] using boundedIntXGCD_bezout a b
    · suffices equality :
          -(b / data.gcd) * a + (a / data.gcd) * b = 0 by
        rw [_root_.Matrix.mulVec, dotProduct,
          NormalForms.Matrix.Constructive.sum_univ_two]
        simpa [data] using equality
      have gcdDvdLeft : data.gcd ∣ a :=
        @ComputableEuclideanOps.xgcd_gcd_dvd_left Int Int.euclideanDomain
          constructiveIntNormalizationMonoid boundedIntEuclideanOps a b
      have gcdDvdRight : data.gcd ∣ b :=
        @ComputableEuclideanOps.xgcd_gcd_dvd_right Int Int.euclideanDomain
          constructiveIntNormalizationMonoid boundedIntEuclideanOps a b
      have leftExact : data.gcd * (a / data.gcd) = a := by
        rw [mul_comm]
        exact Int.ediv_mul_cancel gcdDvdLeft
      have rightExact : data.gcd * (b / data.gcd) = b := by
        rw [mul_comm]
        exact Int.ediv_mul_cancel gcdDvdRight
      apply mul_left_cancel₀ hg
      rw [mul_zero]
      calc
        data.gcd * (-(b / data.gcd) * a + (a / data.gcd) * b) =
            -((data.gcd * (b / data.gcd)) * a) +
              (data.gcd * (a / data.gcd)) * b := by ring
        _ = -(b * a) + a * b := by
          rw [rightExact, leftExact]
        _ = 0 := by ring

theorem boundedIntXGCD_gcd_normalized (a b : Int) :
    (boundedIntXGCD a b).gcd =
      _root_.normalize (boundedIntXGCD a b).gcd := by
  exact @ComputableEuclideanOps.xgcd_gcd_normalized Int Int.euclideanDomain
    constructiveIntNormalizationMonoid boundedIntEuclideanOps a b

theorem boundedIntXGCD_gcd_eq_zero_iff (a b : Int) :
    (boundedIntXGCD a b).gcd = 0 ↔ a = 0 ∧ b = 0 := by
  exact @ComputableEuclideanOps.xgcd_gcd_eq_zero_iff Int Int.euclideanDomain
    constructiveIntNormalizationMonoid boundedIntEuclideanOps a b

theorem boundedIntXGCD_divIdentity (a b : Int)
    (hg : (boundedIntXGCD a b).gcd ≠ 0) :
    (boundedIntXGCD a b).leftCoeff *
          (a / (boundedIntXGCD a b).gcd) +
        (boundedIntXGCD a b).rightCoeff *
          (b / (boundedIntXGCD a b).gcd) = 1 := by
  let data := boundedIntXGCD a b
  have gcdDvdLeft : data.gcd ∣ a :=
    @ComputableEuclideanOps.xgcd_gcd_dvd_left Int Int.euclideanDomain
      constructiveIntNormalizationMonoid boundedIntEuclideanOps a b
  have gcdDvdRight : data.gcd ∣ b :=
    @ComputableEuclideanOps.xgcd_gcd_dvd_right Int Int.euclideanDomain
      constructiveIntNormalizationMonoid boundedIntEuclideanOps a b
  have leftExact : data.gcd * (a / data.gcd) = a := by
    rw [mul_comm]
    exact Int.ediv_mul_cancel gcdDvdLeft
  have rightExact : data.gcd * (b / data.gcd) = b := by
    rw [mul_comm]
    exact Int.ediv_mul_cancel gcdDvdRight
  apply mul_left_cancel₀ hg
  rw [mul_one]
  calc
    data.gcd *
          (data.leftCoeff * (a / data.gcd) +
            data.rightCoeff * (b / data.gcd)) =
        data.leftCoeff * (data.gcd * (a / data.gcd)) +
          data.rightCoeff * (data.gcd * (b / data.gcd)) := by ring
    _ = data.leftCoeff * a + data.rightCoeff * b := by
      rw [leftExact, rightExact]
    _ = data.gcd := by
      simpa [data, mul_comm] using boundedIntXGCD_bezout a b

theorem boundedBezoutReductionInverseMatrix_mul (a b : Int) :
    boundedBezoutReductionInverseMatrix a b *
        boundedBezoutReductionMatrix a b = 1 := by
  let data := boundedIntXGCD a b
  by_cases hg : data.gcd = 0
  · rw [boundedBezoutReductionInverseMatrix,
      boundedBezoutReductionMatrix, if_pos hg, if_pos hg]
    exact NormalForms.Matrix.Constructive.one_mul 1
  · have identity := boundedIntXGCD_divIdentity a b hg
    rw [boundedIntXGCD_gcd] at identity
    rw [boundedBezoutReductionInverseMatrix,
      boundedBezoutReductionMatrix, if_neg hg, if_neg hg]
    ext row column
    fin_cases row <;> fin_cases column <;>
      rw [_root_.Matrix.mul_apply,
        NormalForms.Matrix.Constructive.sum_univ_two] <;>
      simp <;>
      ring_nf at identity ⊢ <;>
      assumption

theorem boundedBezoutReductionMatrix_mul_inverse (a b : Int) :
    boundedBezoutReductionMatrix a b *
        boundedBezoutReductionInverseMatrix a b = 1 := by
  let data := boundedIntXGCD a b
  by_cases hg : data.gcd = 0
  · rw [boundedBezoutReductionInverseMatrix,
      boundedBezoutReductionMatrix, if_pos hg, if_pos hg]
    exact NormalForms.Matrix.Constructive.one_mul 1
  · have identity := boundedIntXGCD_divIdentity a b hg
    rw [boundedIntXGCD_gcd] at identity
    rw [boundedBezoutReductionInverseMatrix,
      boundedBezoutReductionMatrix, if_neg hg, if_neg hg]
    ext row column
    fin_cases row <;> fin_cases column <;>
      rw [_root_.Matrix.mul_apply,
        NormalForms.Matrix.Constructive.sum_univ_two] <;>
      simp <;>
      ring_nf at identity ⊢ <;>
      assumption

def boundedPairBezoutMatrix {n : Nat} (pivot target : Fin n)
    (a b : Int) : _root_.Matrix (Fin n) (Fin n) Int :=
  twoRowLiftMatrix pivot target (boundedBezoutReductionMatrix a b)

def boundedPairBezoutMatrixInverseCertificate {n : Nat}
    (pivot target : Fin n) (hne : pivot ≠ target) (a b : Int) :
    MatrixInverseCertificate (boundedPairBezoutMatrix pivot target a b) := by
  refine
    { inverse := twoRowLiftMatrix pivot target
        (boundedBezoutReductionInverseMatrix a b)
      left_inv := ?_
      right_inv := ?_ }
  · rw [boundedPairBezoutMatrix,
      twoRowLiftMatrix_mul pivot target hne,
      boundedBezoutReductionInverseMatrix_mul,
      twoRowLiftMatrix_one pivot target hne]
  · rw [boundedPairBezoutMatrix,
      twoRowLiftMatrix_mul pivot target hne,
      boundedBezoutReductionMatrix_mul_inverse,
      twoRowLiftMatrix_one pivot target hne]

end Principal

end NormalForms.Research.KannanBachem.Hermite
