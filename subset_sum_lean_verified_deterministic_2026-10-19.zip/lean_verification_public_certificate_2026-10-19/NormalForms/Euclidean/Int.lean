/-
Copyright (c) 2026 Junye Ji. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Junye Ji
-/
import NormalForms.Euclidean.ComputableOps

/-!
# Constructive Euclidean operations for integers
-/

 section

namespace NormalForms

/-- Constructive classification of integer units without extracting a witness from `IsUnit`. -/
theorem intUnit_eq_one_or_negOne (unit : Intˣ) :
    unit = 1 ∨ unit = -1 := by
  have absoluteValue : Int.natAbs (unit : Int) = 1 :=
    Int.units_natAbs unit
  rcases Int.natAbs_eq (unit : Int) with equality | equality
  · apply Or.inl
    apply Units.ext
    exact equality.trans
      (congrArg (fun value : Nat => (value : Int)) absoluteValue)
  · apply Or.inr
    apply Units.ext
    exact equality.trans
      (congrArg (fun value : Nat => -(value : Int)) absoluteValue)

theorem intNegOneUnit_inv :
    (-1 : Intˣ)⁻¹ = -1 := by
  apply Units.ext
  rfl

/-- Lean 4.19 already exposes the same executable sign normalization. -/
abbrev constructiveIntNormalizationMonoid : NormalizationMonoid Int :=
  Int.normalizationMonoid

attribute [instance 10000] constructiveIntNormalizationMonoid

instance instComputableEuclideanOpsInt :
    @ComputableEuclideanOps Int Int.euclideanDomain
      constructiveIntNormalizationMonoid where
  eqb a b := decide (a = b)
  divMod a b := (a / b, a % b)
  normalize a := a.natAbs
  normUnit a := if 0 ≤ a then 1 else -1
  xgcd a b :=
    { gcd := Int.gcd a b
      leftCoeff := Int.gcdA a b
      rightCoeff := Int.gcdB a b }
  measure := Int.natAbs
  normUnitUnit := NormalizationMonoid.normUnit

  eqb_spec := by
    intro a b
    simp
  divMod_spec := by
    intro a b
    rfl
  remainder_measure_lt := by
    intro a b hb
    exact EuclideanDomain.mod_lt a hb
  normalize_spec := show
      ∀ a,
        (a.natAbs : Int) =
          @normalize Int Int.instCancelCommMonoidWithZero
            constructiveIntNormalizationMonoid a
    from by
      intro a
      change (a.natAbs : Int) =
        a * ((@NormalizationMonoid.normUnit Int
          Int.instCancelCommMonoidWithZero
          constructiveIntNormalizationMonoid a : Intˣ) : Int)
      have hunit :
          @NormalizationMonoid.normUnit Int
              Int.instCancelCommMonoidWithZero
              constructiveIntNormalizationMonoid a =
            if 0 ≤ a then (1 : Intˣ) else -1 :=
        rfl
      rw [hunit]
      by_cases h : 0 ≤ a
      · simp [h, Int.natAbs_of_nonneg h]
      · have hneg : a < 0 := Int.lt_of_not_ge h
        have hnonneg : 0 ≤ -a :=
          Int.neg_nonneg_of_nonpos (Int.le_of_lt hneg)
        have hnatAbs : (a.natAbs : Int) = -a := by
          calc
            (a.natAbs : Int) = ((-a).natAbs : Int) := by
              rw [Int.natAbs_neg]
            _ = -a := Int.natAbs_of_nonneg hnonneg
        simp [h, hnatAbs]
  normalize_idem_spec := by
    intro a
    rw [Int.natAbs_of_nonneg]
    exact Int.natCast_nonneg _
  normUnit_spec := by
    intro a
    have hunit :
        @NormalizationMonoid.normUnit Int
            Int.instCancelCommMonoidWithZero
            constructiveIntNormalizationMonoid a =
          if 0 ≤ a then (1 : Intˣ) else -1 :=
      rfl
    rw [hunit]
    by_cases h : 0 ≤ a <;> simp [h, Units.val_neg, Units.val_one]
  normUnitUnit_coe := by
    intro a
    have hunit :
        @NormalizationMonoid.normUnit Int
            Int.instCancelCommMonoidWithZero
            constructiveIntNormalizationMonoid a =
          if 0 ≤ a then (1 : Intˣ) else -1 :=
      rfl
    rw [hunit]
    by_cases h : 0 ≤ a <;> simp [h, Units.val_neg, Units.val_one]
  xgcd_normalized := by
    intro a b
    change (Int.gcd a b : Int) =
      (Int.gcd a b : Int) *
        ((@NormalizationMonoid.normUnit Int
          Int.instCancelCommMonoidWithZero
          constructiveIntNormalizationMonoid (Int.gcd a b : Int) :
            Intˣ) : Int)
    have hunit :
        @NormalizationMonoid.normUnit Int
            Int.instCancelCommMonoidWithZero
            constructiveIntNormalizationMonoid (Int.gcd a b : Int) =
          if 0 ≤ (Int.gcd a b : Int) then (1 : Intˣ) else -1 :=
      rfl
    rw [hunit]
    have hnonnegative : 0 ≤ (Int.gcd a b : Int) :=
      Int.natCast_nonneg (Int.gcd a b)
    rw [if_pos hnonnegative]
    simp only [Units.val_one, mul_one]
  xgcd_bezout_spec := by
    intro a b
    change a * Int.gcdA a b + b * Int.gcdB a b = (Int.gcd a b : Int)
    exact (Int.gcd_eq_gcd_ab a b).symm
  xgcd_dvd_left := by
    intro a b
    change (Int.gcd a b : Int) ∣ a
    exact Int.gcd_dvd_left
  xgcd_dvd_right := by
    intro a b
    change (Int.gcd a b : Int) ∣ b
    exact Int.gcd_dvd_right
  dvd_xgcd := by
    intro a b d ha hb
    change d ∣ (Int.gcd a b : Int)
    exact Int.dvd_coe_gcd ha hb
  xgcd_measure_lt := by
    intro a b ha hnot
    change Int.gcd a b < a.natAbs
    apply lt_of_le_of_ne (Nat.gcd_le_left b.natAbs (Int.natAbs_pos.mpr ha))
    intro hEq
    apply hnot
    apply Int.natAbs_dvd_natAbs.mp
    apply Nat.gcd_eq_left_iff_dvd.mp
    simpa [Int.gcd_def] using hEq

end NormalForms
