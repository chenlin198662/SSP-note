import Optss.BogolyubovSlack
import Optss.RationalPiApproximation

/-! Finite rational approximations to imaginary exponentials. Pair arithmetic
stores rational real and imaginary parts, with a complex cast used only in
the correctness proof. No real number is inspected by the answer routine. -/
namespace Optss
open scoped BigOperators

def rationalImaginaryPower (t : ℚ) : ℕ → ℚ×ℚ
  | 0 => (1,0)
  | n+1 => let z := rationalImaginaryPower t n; (-t*z.2,t*z.1)

theorem rationalImaginaryPower_cast (t : ℚ) (n : ℕ) :
    rationalComplexValue (rationalImaginaryPower t n)=((t : ℂ)*Complex.I)^n := by
  induction n with
  | zero => simp [rationalImaginaryPower,rationalComplexValue]
  | succ n ih =>
    rw [pow_succ,← ih]
    simp only [rationalImaginaryPower,rationalComplexValue,Rat.cast_neg,Rat.cast_mul]
    ring_nf
    simp

def rationalImaginaryExpPartial (t : ℚ) (n : ℕ) : ℚ×ℚ :=
  (∑ j∈Finset.range n, (rationalImaginaryPower t j).1/j.factorial,
   ∑ j∈Finset.range n, (rationalImaginaryPower t j).2/j.factorial)

theorem rationalImaginaryExpPartial_cast (t : ℚ) (n : ℕ) :
    rationalComplexValue (rationalImaginaryExpPartial t n)=
      ∑ j∈Finset.range n, ((t : ℂ)*Complex.I)^j/j.factorial := by
  unfold rationalImaginaryExpPartial rationalComplexValue
  push_cast
  rw [Finset.sum_mul,← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro j _
  rw [← rationalImaginaryPower_cast]
  unfold rationalComplexValue
  ring

theorem factorial_ge_sixteen_pow (k : ℕ) : 16^k≤(16+k).factorial := by
  calc
    16^k≤17^k := Nat.pow_le_pow_left (by decide) _
    _ ≤ (16 : ℕ).factorial*17^k := Nat.le_mul_of_pos_left _ (Nat.factorial_pos _)
    _ ≤ (16+k).factorial := Nat.factorial_mul_pow_le_factorial

/-- A direct finite Taylor remainder. The displayed degree grows linearly
with the precision parameter. -/
theorem rationalImaginaryExpPartial_error (t : ℚ) (ht : |t|≤8) (k : ℕ) :
    ‖Complex.exp ((t : ℂ)*Complex.I)-
      rationalComplexValue (rationalImaginaryExpPartial t (16+k))‖≤
      2*8^16*(1/2 : ℝ)^k := by
  have htR : |(t : ℝ)|≤8 := by exact_mod_cast ht
  have hn : ‖(t : ℂ)*Complex.I‖≤8 := by
    rw [norm_mul,Complex.norm_I,mul_one,← Complex.ofReal_ratCast,Complex.norm_real,Real.norm_eq_abs]
    exact htR
  have hh : ‖(t : ℂ)*Complex.I‖/((16+k).succ : ℝ)≤1/2 := by
    apply (div_le_iff₀ (by positivity : (0 : ℝ)<(16+k).succ)).mpr
    push_cast
    have hk : (0 : ℝ)≤k := by positivity
    linarith
  rw [rationalImaginaryExpPartial_cast]
  apply (Complex.exp_bound' hh).trans
  have hf : (16 : ℝ)^k≤(16+k).factorial := by exact_mod_cast factorial_ge_sixteen_pow k
  calc
    _ ≤ (8 : ℝ)^(16+k)/(16^k)*2 := by
      gcongr
    _ = _ := by
      rw [pow_add,div_eq_mul_inv,← inv_pow]
      have he : (8 : ℝ)^k*(16⁻¹)^k=(1/2 : ℝ)^k := by rw [← mul_pow]; norm_num
      calc
        _ = 2*8^16*((8 : ℝ)^k*(16⁻¹)^k) := by ring
        _ = _ := by rw [he]

/-- With 66+p Taylor terms, the absolute error is at most 2^(-p). -/
theorem rationalImaginaryExpPartial_precision (t : ℚ) (ht : |t|≤8) (p : ℕ) :
    ‖Complex.exp ((t : ℂ)*Complex.I)-
      rationalComplexValue (rationalImaginaryExpPartial t (66+p))‖≤(1/2 : ℝ)^p := by
  have h := rationalImaginaryExpPartial_error t ht (50+p)
  have hn : 16+(50+p)=66+p := by omega
  rw [hn,pow_add] at h
  have he : (2 : ℝ)*8^16*(1/2)^50=(1/2) := by norm_num
  have hb : 2*(8 : ℝ)^16*((1/2)^50*(1/2)^p)≤(1/2)^p := by
    rw [← mul_assoc,he]
    have hp : (0 : ℝ)≤(1/2)^p := by positivity
    linarith
  exact h.trans hb

end Optss
