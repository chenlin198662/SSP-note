import Optss.FreimanProgressionCovering
import Mathlib.Combinatorics.Additive.PluenneckeRuzsa

/-!
# Quantitative covering from a large difference-set progression

The small-doubling hypothesis discharges the covering-growth premise by the
proved Plünnecke–Ruzsa inequality. A proper progression in 2A-2A of size at
least δ|A| therefore yields a t-proper containing progression with explicit
rank and volume constants depending only on the initial rank, doubling, δ
and t. Construction of the large input progression is a separate step.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {G : Type*} [AddCommGroup G] [DecidableEq G]

theorem smallDoubling_difference_bound (A : Finset G) (hA : A.Nonempty)
    (C : ℚ≥0) (hC : ((A+A).card : ℚ≥0) ≤ C*A.card) (m n : ℕ) :
    ((m • A-n • A).card : ℚ≥0) ≤ C^(m+n)*A.card := by
  have h := Finset.pluennecke_ruzsa_inequality_nsmul_sub_nsmul_add hA A m n
  have hp : (0 : ℚ≥0) < A.card := by exact_mod_cast Finset.card_pos.mpr hA
  have hr : ((A+A).card : ℚ≥0)/A.card ≤ C := (div_le_iff₀ hp).mpr hC
  exact h.trans (mul_le_mul_of_nonneg_right (pow_le_pow_left₀ (by positivity) hr _) (by positivity))

theorem smallDoubling_double_difference_bound (A : Finset G) (hA : A.Nonempty)
    (C : ℚ≥0) (hC : ((A+A).card : ℚ≥0) ≤ C*A.card) :
    (((A+A)-(A+A)).card : ℚ≥0) ≤ C^4*A.card := by
  simpa only [two_nsmul] using smallDoubling_difference_bound A hA C hC 2 2

theorem smallDoubling_add_difference_subset_bound (A P : Finset G) (hA : A.Nonempty)
    (C : ℚ≥0) (hC : ((A+A).card : ℚ≥0) ≤ C*A.card)
    (hP : P ⊆ (A+A)-(A+A)) :
    ((A+P).card : ℚ≥0) ≤ C^5*A.card := by
  have hs : A+P ⊆ (3 • A)-(2 • A) := by
    intro x hx
    obtain ⟨a,ha,p,hp,rfl⟩ := Finset.mem_add.mp hx
    obtain ⟨b,hb,c,hc,rfl⟩ := Finset.mem_sub.mp (hP hp)
    refine Finset.mem_sub.mpr ⟨a+b,?_,c,?_,by abel⟩
    · have hm := Finset.add_mem_add ha hb
      simpa only [show (3:ℕ)=1+2 from rfl,add_nsmul,one_nsmul,two_nsmul] using hm
    · simpa only [two_nsmul] using hc
  exact (Nat.cast_le.mpr (Finset.card_le_card hs)).trans
    (smallDoubling_difference_bound A hA C hC 3 2)

theorem large_difference_subset_covering_growth (A P : Finset G) (hA : A.Nonempty)
    (C δ : ℚ≥0) (hδ : 0<δ) (hC : ((A+A).card : ℚ≥0) ≤ C*A.card)
    (hP : P ⊆ (A+A)-(A+A)) (hlarge : δ*A.card ≤ (P.card : ℚ≥0)) :
    ((A+P).card : ℚ≥0) ≤ (C^5/δ)*P.card := by
  calc
    _ ≤ C^5*A.card := smallDoubling_add_difference_subset_bound A P hA C hC hP
    _ = (C^5/δ)*(δ*A.card) := by field_simp; ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hlarge (by positivity)

/-- Quantitative Freiman covering, with both small-growth premises derived
from the original doubling hypothesis. All progressions in the conclusion
are actual integer coefficient boxes, and properness is on the real t-dilate. -/
theorem freiman_covering_from_large_progression [IsAddTorsionFree G]
    (A : Finset G) (hA : A.Nonempty) (C δ : ℚ≥0) (hδ : 0<δ)
    (hC : ((A+A).card : ℚ≥0) ≤ C*A.card)
    {r : ℕ} (ρ : IntVec r →+ G) (β : Fin r → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox β))
    (hP : integerProgressionValues ρ β ⊆ (A+A)-(A+A))
    (hlarge : δ*A.card ≤ ((integerProgressionValues ρ β).card : ℚ≥0)) (t : ℝ) :
    let K : ℝ := (C^5/δ : ℚ≥0)
    ∃ d ≤ r+⌈K⌉₊, ∃ (ρ' : IntVec d →+ G) (γ : Fin d → ℕ),
      A ⊆ integerProgressionValues ρ' γ ∧
      Set.InjOn ρ' (realDilatedIntegerBox γ t) ∧
      ((integerBudgetBox γ).card : ℚ≥0) ≤
        (properizationVolumeFactor (r+⌈K⌉₊) ⌈t⌉₊*(2^r*3^⌈K⌉₊) : ℕ)*C^4*A.card := by
  dsimp only
  let K : ℝ := (C^5/δ : ℚ≥0)
  have hg := large_difference_subset_covering_growth A (integerProgressionValues ρ β)
    hA C δ hδ hC hP hlarge
  have hg' : ((A+integerProgressionValues ρ β).card : ℝ) ≤
      K*(integerProgressionValues ρ β).card := by
    dsimp only [K]
    exact_mod_cast hg
  obtain ⟨d,hd,ρ',γ,hcont,hproper',hcard⟩ := progression_covering_proper A ρ β K t hg'
  refine ⟨d,hd,ρ',γ,hcont,hproper',?_⟩
  have hc : (integerBudgetBox β).card = (integerProgressionValues ρ β).card :=
    (Finset.card_image_iff.mpr hproper).symm
  have hp : ((integerBudgetBox β).card : ℚ≥0) ≤ C^4*A.card := by
    rw [hc]
    exact (Nat.cast_le.mpr (Finset.card_le_card hP)).trans
      (smallDoubling_double_difference_bound A hA C hC)
  have hc' : ((integerBudgetBox γ).card : ℚ≥0) ≤
      (properizationVolumeFactor (r+⌈K⌉₊) ⌈t⌉₊*(2^r*3^⌈K⌉₊) : ℕ)*
        (integerBudgetBox β).card := by exact_mod_cast hcard
  have hm := mul_le_mul_of_nonneg_left hp
    (show (0:ℚ≥0) ≤ (properizationVolumeFactor (r+⌈K⌉₊) ⌈t⌉₊*(2^r*3^⌈K⌉₊) : ℕ) from by positivity)
  simpa only [mul_assoc] using hc'.trans hm

end
end Optss
