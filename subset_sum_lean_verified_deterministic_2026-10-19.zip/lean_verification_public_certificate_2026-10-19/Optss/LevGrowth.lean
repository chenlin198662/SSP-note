import Optss.LevQuotientFibers
import Mathlib.GroupTheory.Archimedean
import Mathlib.Algebra.GCDMonoid.Finset

/-!
# Lev's 1997 distinct-summand integer growth theorem

The proof combines the fully proved Kneser theorem with actual integer
fibers. It assumes generation in the residue group and endpoint membership,
not a growth or filling conclusion. Source: V. F. Lev, Addendum to
"Structure theorem for multiple addition", J. Number Theory 65 (1997), 96–100.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

/-- Actual reduction of an integer finite set modulo `l`. -/
def levResidues (l : ℕ) : Finset ℤ →+ Finset (ZMod l) :=
  Finset.imageAddMonoidHom (Int.castAddHom (ZMod l))

@[simp] theorem levResidues_apply (l : ℕ) (A : Finset ℤ) :
    levResidues l A = A.image (fun x : ℤ => (x : ZMod l)) := rfl

/-- If saturating the preceding residue sum already yields the final sum,
then generation by the last summand forces the final sum to be the group. -/
theorem full_of_previous_saturation {G : Type*} [AddCommGroup G] [Fintype G] [DecidableEq G]
    (S A : Finset G) (hS : S.Nonempty) (hA : CosetSpanning A)
    (h : S + (S + A).addStab = S + A) : S + A = Finset.univ := by
  apply finiteGroup_full_of_no_growth (S + A) A (hS.add hA.1) hA
  have he : A + (S + A) = S + A := by
    calc
      A + (S + A) = A + (S + (S + A).addStab) := congrArg (A + ·) h.symm
      _ = (S + A) + (S + A).addStab := by rw [add_assoc, add_left_comm A S]
      _ = S + A := Finset.add_addStab _
  rw [he]

private theorem sum_map_natCast_eq {α : Type*} (L : List α) (f : α → ℕ) :
    (L.map (fun a => (f a : ℤ))).sum = ((L.map f).sum : ℤ) := by
  induction L with
  | nil => simp
  | cons a L ih => simp [ih]

private theorem sum_map_add_sub_const {α : Type*} (L : List α) (f g : α → ℤ) (c : ℤ) :
    (L.map (fun a => f a + c - g a)).sum =
      (L.map f).sum + (L.length : ℤ) * c - (L.map g).sum := by
  induction L with
  | nil => simp
  | cons a L ih =>
    simp only [List.map_cons, List.sum_cons, List.length_cons, Nat.cast_add, Nat.cast_one, ih]
    ring

/-- Lev's quantitative growth estimate stated with exact residue-cardinality
parameters. Bounds on individual integer summands are needed only to express
these parameters as the endpoint-corrected cardinalities in the paper. -/
theorem lev_integer_sum_growth (L : List (Finset ℤ)) (A : Finset ℤ) (l : ℕ)
    (hl : 0 < l) (hL : ∀ B ∈ L, B.Nonempty) (hzero : 0 ∈ A) (hlA : (l : ℤ) ∈ A)
    (hgen : AddSubgroup.closure (levResidues l A : Set (ZMod l)) = ⊤) :
    min (l : ℤ) (((L ++ [A]).map (fun B => ((levResidues l B).card : ℤ))).sum - L.length) ≤
      ((L.sum + A).card : ℤ) - L.sum.card := by
  classical
  haveI : NeZero l := ⟨by omega⟩
  let R := levResidues l
  let S := R L.sum
  let T := R (L.sum + A)
  let H := T.addStab
  have hA : A.Nonempty := ⟨0, hzero⟩
  have hLS := nonempty_list_sum L hL
  have hS : S.Nonempty := hLS.image _
  have hT : T.Nonempty := (hLS.add hA).image _
  have hA0 : (0 : ZMod l) ∈ R A := Finset.mem_image.mpr ⟨0, hzero, by simp⟩
  have hAsp : CosetSpanning (R A) := cosetSpanning_of_zero_mem_closure _ hA0 hgen
  have hST : S ⊆ T := by
    rw [show T = S + R A from map_add R _ _]
    intro x hx
    exact Finset.mem_add.mpr ⟨x, hx, 0, hA0, by simp⟩
  have hsat : S + H ⊆ T := by
    calc
      S + H ⊆ T + T.addStab := Finset.add_subset_add_right hST
      _ = T := by rw [Finset.add_addStab]
  by_cases heq : S + H = T
  · have hfull : T = Finset.univ := by
      have hRA : S + R A = T := (map_add R _ _).symm
      rw [← hRA]
      apply full_of_previous_saturation S (R A) hS hAsp
      simpa only [hRA] using heq
    have hg := residue_sum_growth_of_full L.sum A l hl hzero hlA
      (fun c => by change c ∈ T; rw [hfull]; exact Finset.mem_univ c)
    have hgZ : (L.sum.card : ℤ) + l ≤ (L.sum + A).card := by exact_mod_cast hg
    exact (min_le_left _ _).trans (by omega)
  · have hproper : ¬T ⊆ S + H := fun h => heq (Finset.Subset.antisymm hsat h)
    obtain ⟨c, hcT, hcS⟩ := Finset.not_subset.mp hproper
    obtain ⟨x, hx, hxc⟩ := Finset.mem_image.mp hcT
    change (x : ZMod l) = c at hxc
    let C := c +ᵥ H
    have hCT : C ⊆ T := Finset.vadd_finset_addStab_subset hcT
    have hCS : Disjoint C S := by
      apply Finset.disjoint_left.mpr
      intro y hyC hyS
      obtain ⟨h, hh, he⟩ := Finset.mem_vadd_finset.mp hyC
      have hneg : -h ∈ H := by
        rw [← Finset.mem_coe, Finset.coe_addStab hT] at hh ⊢
        exact (AddAction.stabilizer (ZMod l) (T : Set (ZMod l))).neg_mem hh
      apply hcS
      exact Finset.mem_add.mpr ⟨y, hyS, -h, hneg, by rw [← he, vadd_eq_add]; abel⟩
    have hboost := residue_growth_boost L.sum A l hl hzero hlA C hCT hCS
    have hF : L ++ [A] ≠ [] := by simp
    have hFN : ∀ B ∈ L ++ [A], B.Nonempty := by
      intro B hB
      rcases List.mem_append.mp hB with hB | hB
      · exact hL B hB
      · have he := List.mem_singleton.mp hB
        simpa only [he] using hA
    have hfi := integer_list_stabilizer_fiber_card (L ++ [A]) l T hT x (by simpa using hx)
    have hK := kneser_list_saturated_card ((L ++ [A]).map R) (by simp)
      (by intro B hB; obtain ⟨D, hD, rfl⟩ := List.mem_map.mp hB; exact (hFN D hD).image _)
    have hsum : ((L ++ [A]).map R).sum = T := by
      rw [← map_list_sum]
      simp only [List.sum_append, List.sum_singleton]
      rfl
    rw [hsum] at hK
    have hfilter : ((L ++ [A]).sum.filter (fun y => integerStabilizerProjection l T y =
          integerStabilizerProjection l T x)) =
        (L.sum + A).filter (fun y : ℤ => (y : ZMod l) ∈ C) := by
      ext y
      simp only [List.sum_append, List.sum_singleton, Finset.mem_filter]
      change (y ∈ L.sum + A ∧ stabilizerProjection T (y : ZMod l) =
        stabilizerProjection T (x : ZMod l)) ↔ _
      rw [stabilizerProjection_eq_iff T hT, hxc]
    rw [hfilter] at hfi
    have hCcard : C.card = H.card := Finset.card_vadd_finset _ _
    rw [hCcard] at hboost
    simp only [List.map_map, List.length_map, List.length_append, List.length_singleton,
      Nat.add_sub_cancel, Function.comp_def] at hK
    have hKZ : (((L ++ [A]).map (fun B => ((R B + H).card : ℤ))).sum) ≤
        T.card + (L.length : ℤ) * H.card := by
      rw [sum_map_natCast_eq]
      exact_mod_cast hK
    have hsumK : ((L ++ [A]).map (fun B => ((levResidues l B).card : ℤ) + H.card -
          (levResidues l B + H).card)).sum =
        ((L ++ [A]).map (fun B => ((levResidues l B).card : ℤ))).sum +
          ((L.length : ℤ) + 1) * H.card -
          ((L ++ [A]).map (fun B => ((R B + H).card : ℤ))).sum := by
      rw [sum_map_add_sub_const]
      simp only [List.length_append, List.length_singleton, Nat.cast_add, Nat.cast_one]
      rfl
    change ((L ++ [A]).map (fun B => ((levResidues l B).card : ℤ) + H.card -
        (levResidues l B + H).card)).sum - ((L ++ [A]).length : ℤ) + 1 ≤ _ at hfi
    rw [hsumK] at hfi
    simp only [List.length_append, List.length_singleton, Nat.cast_add, Nat.cast_one] at hfi
    have hboostZ : (L.sum.card : ℤ) + T.card +
        ((L.sum + A).filter (fun y : ℤ => (y : ZMod l) ∈ C)).card ≤
          (L.sum + A).card + H.card := by exact_mod_cast hboost
    apply (min_le_right _ _).trans
    nlinarith [hKZ, hfi, hboostZ]

/-- Integer gcd one is the full additive-generation hypothesis. -/
theorem integer_closure_top_of_gcd_one (A : Finset ℤ) (hgcd : A.gcd id = 1) :
    AddSubgroup.closure (A : Set ℤ) = ⊤ := by
  obtain ⟨a, ha⟩ := Int.subgroup_cyclic (AddSubgroup.closure (A : Set ℤ))
  have hd : ∀ x ∈ A, a ∣ x := by
    intro x hx
    apply Int.mem_zmultiples_iff.mp
    rw [AddSubgroup.zmultiples_eq_closure, ← ha]
    exact AddSubgroup.subset_closure hx
  have hd1 : a ∣ (1 : ℤ) := by
    have hdg : a ∣ A.gcd id := Finset.dvd_gcd hd
    simpa only [hgcd] using hdg
  apply top_unique
  intro x _
  rw [ha, ← AddSubgroup.zmultiples_eq_closure, Int.mem_zmultiples_iff]
  exact hd1.trans (one_dvd x)

/-- Gcd one yields generation modulo every modulus, with no coprimality
hypothesis imposed separately on the modulus. -/
theorem residue_generation_of_gcd_one (A : Finset ℤ) (l : ℕ) (hgcd : A.gcd id = 1) :
    AddSubgroup.closure (levResidues l A : Set (ZMod l)) = ⊤ := by
  rw [levResidues_apply, Finset.coe_image]
  change AddSubgroup.closure ((Int.castAddHom (ZMod l)) '' (A : Set ℤ)) = ⊤
  rw [← AddMonoidHom.map_closure, integer_closure_top_of_gcd_one A hgcd]
  exact AddSubgroup.map_top_of_surjective _ ZMod.intCast_surjective

/-- The exact endpoint-corrected cardinality used in Lev's 1997 theorem. -/
def levEffectiveCard (l : ℕ) (A : Finset ℤ) : ℕ :=
  A.card - if 0 ∈ A ∧ (l : ℤ) ∈ A then 1 else 0

/-- The complete normalized main theorem of Lev's 1997 addendum. Every
summand is an actual nonempty subset of `[0,l]`; the last contains both
endpoints and has gcd one. -/
theorem lev1997_growth (L : List (Finset ℤ)) (A : Finset ℤ) (l : ℕ)
    (hl : 0 < l) (hL : ∀ B ∈ L, B.Nonempty)
    (hbox : ∀ B ∈ L ++ [A], B ⊆ Finset.Icc 0 (l : ℤ))
    (hzero : 0 ∈ A) (hlA : (l : ℤ) ∈ A) (hgcd : A.gcd id = 1) :
    (L.sum.card : ℤ) +
      min (l : ℤ) (((L ++ [A]).map (fun B => (levEffectiveCard l B : ℤ))).sum - L.length) ≤
        (L.sum + A).card := by
  have h := lev_integer_sum_growth L A l hl hL hzero hlA
    (residue_generation_of_gcd_one A l hgcd)
  have he : (L ++ [A]).map (fun B => ((levResidues l B).card : ℤ)) =
      (L ++ [A]).map (fun B => (levEffectiveCard l B : ℤ)) := by
    apply List.map_congr_left
    intro B hB
    rw [levResidues_apply, interval_residue_card B l hl (hbox B hB)]
    rfl
  rw [he] at h
  omega

end
end Optss
