import Optss.CommonLatticeFilling

/-!
# Deriving common-box density and filling from actual dense blocks

The original phase volume and actual block-size bound control the new full
lattice coefficient box. Thus the density required by Lemma 2.D is derived
from quarter-density of the blocks, with explicit dimension-only boxing losses.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1200000

def commonBoxCountFactor (d K : ℕ) : ℕ :=
  (latticeBoxingResidueModulus d (latticeReductionDefectBound d))^d*K^d

def commonBoxBlockDensity (d K : ℕ) (C : ℝ) : ℝ :=
  min 1 (1/(4*(commonBoxCountFactor d K : ℝ)*C))

theorem commonBoxBlockDensity_bounds (d K : ℕ) (hK : 1 ≤ K) (C : ℝ) (hC : 0 < C) :
    0 < commonBoxBlockDensity d K C ∧ commonBoxBlockDensity d K C ≤ 1 ∧
      commonBoxBlockDensity d K C ≤ 1/(4*(commonBoxCountFactor d K : ℝ)*C) := by
  have hJ := latticeBoxingResidueModulus_pos d (latticeReductionDefectBound d)
  have hK0 : 0 < K := by omega
  have hfactor : 0 < commonBoxCountFactor d K := by unfold commonBoxCountFactor; positivity
  exact ⟨lt_min zero_lt_one (by positivity), min_le_left _ _, min_le_right _ _⟩

/-- Fixed-factor coordinate-box growth, including every integer endpoint. -/
theorem integerBudgetBox_scaled_card_le {d : ℕ} (w : Fin d → ℕ) (B h K : ℕ)
    (hK : 1 ≤ K) (hB : B ≤ K*h) :
    (integerBudgetBox (fun j => B*w j)).card ≤ K^d*(integerBudgetBox (fun j => h*w j)).card := by
  simp only [integerBudgetBox_card]
  calc
    _ ≤ ∏ j : Fin d, K*(2*(h*w j)+1) := by
      apply Finset.prod_le_prod'
      intro j _
      have hb := Nat.mul_le_mul_right (w j) hB
      nlinarith
    _ = _ := by rw [Finset.prod_mul_distrib]; simp

/-- Exact passage from an integer dilated box to its real geometric dilation. -/
theorem realVector_mem_nat_smul_box {d : ℕ} (w : Fin d → ℕ) (B : ℕ) (hB : 0 < B)
    (x : IntVec d) (hx : InCenteredBox (fun j => B*w j) x) :
    realVector x ∈ (B : ℝ) • realCoefficientBox w := by
  have hBR : (0 : ℝ) < B := by exact_mod_cast hB
  refine ⟨(B : ℝ)⁻¹ • realVector x, ?_, ?_⟩
  · rw [mem_realCoefficientBox]
    intro j
    change |(B : ℝ)⁻¹*(x j : ℝ)| ≤ w j
    rw [abs_mul, abs_of_pos (inv_pos.mpr hBR)]
    apply (inv_mul_le_iff₀ hBR).mpr
    exact_mod_cast hx j
  · change (B : ℝ) • ((B : ℝ)⁻¹ • realVector x) = realVector x
    rw [smul_smul, mul_inv_cancel₀ hBR.ne', one_smul]

/-- Dense block supports in a shared generated lattice fill a translated
basis box. Both the basis of the whole lattice and the new density estimate
are derived from actual surviving labels and the original phase-volume bound. -/
theorem common_box_dense_blocks_filling {ι : Type} {d : ℕ} (hd : 0 < d)
    (v : ι → IntVec d) (available : Finset ι)
    (hfull : labelSpan ℝ (fun i => realVector (v i)) available = ⊤)
    (w : Fin d → ℕ) (hbox : ∀ i ∈ available, InCenteredBox w (v i))
    (h B K M N : ℕ) (hB : 1 ≤ B) (hK : 1 ≤ K) (hBK : B ≤ K*h)
    (C : ℝ) (hC : 0 < C)
    (hvolume : ((integerBudgetBox (fun j => h*w j)).card : ℝ) ≤ C*M)
    (A : ℕ → Finset (IntVec d))
    (hAbox : ∀ i < N, ∀ x ∈ A i, InCenteredBox (fun j => B*w j) x)
    (hdense : ∀ i < N, (M : ℝ)/4 ≤ (A i).card)
    (hzero : ∀ i < N, 0 ∈ A i)
    (hgen : ∀ i < N, AddSubgroup.closure (A i : Set (IntVec d)) = generatedLattice v available)
    (hN : denseBoxSummandThreshold d (commonBoxBlockDensity d K C) ≤ N)
    (hwidth : denseBoxWidthThreshold (commonBoxBlockDensity d K C) ≤ 2*B+1) :
    ∃ (b : Basis (Fin d) ℝ (Fin d → ℝ))
      (hΛ : basisIntegerLattice b = realVector '' (generatedLattice v available : Set (IntVec d)))
      (n : Fin d → ℕ), (∀ j, 1 ≤ n j) ∧
      realCoefficientBox w ⊆ basisCoefficientBox b n ∧
      basisCoefficientBox b n ⊆ denseLatticeBoxingConstant d • realCoefficientBox w ∧
      ((integerBudgetBox (fun j => B*n j)).card : ℝ) ≤ (commonBoxCountFactor d K : ℝ)*C*M ∧
      ∃ t ∈ generatedLattice v available, ∀ z : IntVec d,
        (∀ j, |(z j : ℝ)| ≤ denseBoxDilation d (commonBoxBlockDensity d K C)*N*(B*n j : ℕ)) →
        t+subgroupBasisSynthesisHom (generatedLattice v available) b hΛ z ∈
          ∑ i ∈ Finset.range N, A i := by
  obtain ⟨b, hΛ, n, hn, hinner, houter, hcount⟩ :=
    common_generated_lattice_boxing hd v available hfull w hbox
  let σ := subgroupBasisSynthesisHom (generatedLattice v available) b hΛ
  have hσ : Function.Injective σ := subgroupBasisSynthesisHom_injective _ _ _
  have hσrange : σ.range = generatedLattice v available := subgroupBasisSynthesisHom_range _ _ _
  obtain ⟨hc, hc1, hcd⟩ := commonBoxBlockDensity_bounds d K hK C hC
  have hfactor : 0 < commonBoxCountFactor d K := by
    have hJ := latticeBoxingResidueModulus_pos d (latticeReductionDefectBound d)
    have hK0 : 0 < K := by omega
    unfold commonBoxCountFactor
    positivity
  have hcount' : (integerBudgetBox (fun j => B*n j)).card ≤
      commonBoxCountFactor d K*(integerBudgetBox (fun j => h*w j)).card := by
    apply (hcount B hB).trans
    have hh := Nat.mul_le_mul_left ((latticeBoxingResidueModulus d (latticeReductionDefectBound d))^d)
      (integerBudgetBox_scaled_card_le w B h K hK hBK)
    simpa only [commonBoxCountFactor, mul_assoc] using hh
  have hnewvol : ((integerBudgetBox (fun j => B*n j)).card : ℝ) ≤ (commonBoxCountFactor d K : ℝ)*C*M := by
    have hh := mul_le_mul_of_nonneg_left hvolume (Nat.cast_nonneg (commonBoxCountFactor d K))
    have hcountR : ((integerBudgetBox (fun j => B*n j)).card : ℝ) ≤
        (commonBoxCountFactor d K : ℝ)*(integerBudgetBox (fun j => h*w j)).card := by
      exact_mod_cast hcount'
    exact hcountR.trans (by simpa only [mul_assoc] using hh)
  have hprebox : ∀ i < N, ∀ z : IntVec d, σ z ∈ A i → z ∈ integerBudgetBox (fun j => B*n j) := by
    intro i hi z hz
    have hm := realVector_mem_nat_smul_box w B (by omega) (σ z) (hAbox i hi _ hz)
    have hm' : realVector (σ z) ∈ (B : ℝ) • basisCoefficientBox b n :=
      Set.smul_set_mono hinner hm
    have hb := (mem_smul_basisCoefficientBox_iff b n (B : ℝ) (by exact_mod_cast (show 0 < B by omega)) _).mp hm'
    rw [subgroupBasisSynthesisHom_cast, LinearEquiv.apply_symm_apply] at hb
    apply (mem_integerBudgetBox _ z).mpr
    intro j
    have hh := hb j
    change |(z j : ℝ)| ≤ (B : ℝ)*n j at hh
    dsimp only
    exact_mod_cast hh
  have hdensity : ∀ i < N, commonBoxBlockDensity d K C*(integerBudgetBox (fun j => B*n j)).card ≤ (A i).card := by
    intro i hi
    calc
      _ ≤ commonBoxBlockDensity d K C*((commonBoxCountFactor d K : ℝ)*C*M) :=
        mul_le_mul_of_nonneg_left hnewvol hc.le
      _ ≤ (1/(4*(commonBoxCountFactor d K : ℝ)*C))*((commonBoxCountFactor d K : ℝ)*C*M) :=
        mul_le_mul_of_nonneg_right hcd (by positivity)
      _ = (M : ℝ)/4 := by field_simp; ring
      _ ≤ (A i).card := hdense i hi
  obtain ⟨t, ht, hfill⟩ := common_lattice_dense_family_filling hd σ hσ A N (fun j => B*n j)
    (commonBoxBlockDensity d K C) hc hc1 hN
    (fun j => hwidth.trans (by have hj := Nat.mul_le_mul_left B (hn j); nlinarith))
    hprebox hdensity hzero (fun i hi => (hgen i hi).trans hσrange.symm)
  exact ⟨b, hΛ, n, hn, hinner, houter, hnewvol, t, hσrange ▸ ht, hfill⟩

end
end Optss
