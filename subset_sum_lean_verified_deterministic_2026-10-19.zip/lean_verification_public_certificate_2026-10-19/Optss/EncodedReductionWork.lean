import Optss.EncodedCachedReduction
import Optss.ReductionCostEnvelope
import Optss.EncodedRationalReduction

/-!
# Actual scalar work of the encoded cached evaluator

The recurrences below count precisely the Boolean gate/list charges of the
scalar calls in `EncodedCachedReduction`. They are bounded by a proof-only
operand-width envelope, using normalization and exact semantic agreement.
The executed answer functions contain no scalar representation conversions.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

private theorem get_ofFn_fun {α : Type*} {n : ℕ} (f : Fin n → α) :
    (Vector.ofFn f).get = f := funext (get_ofFn f)

def EncodedRationalCanonical (A : BitRationalMatrixData r d) : Prop :=
  ∀ i j, ((A.get i).get j).WellFormed

theorem EncodedRationalCanonical.positive {A : BitRationalMatrixData r d}
    (h : EncodedRationalCanonical A) : EncodedPositiveDenominators A := fun i j => (h i j).2.2.1

def encodedProductSumWork {ι : Type*} (u v : ι → BitListFraction) : List ι → ℕ
  | [] => 0
  | i::is =>
    bitListFractionMulCost (u i) (v i)+encodedProductSumWork u v is+
      bitListFractionAddCost (bitListFractionMul (u i) (v i)) (encodedProductSum u v is)

theorem encodedProductSumWork_le {ι : Type*} (u v : ι → BitListFraction)
    (hu : ∀ i, (u i).WellFormed) (hv : ∀ i, (v i).WellFormed) (is : List ι) :
    encodedProductSumWork u v is ≤
      (meteredProductSum envelopeReductionPrimitives
        (fun i => bitListFractionValue (u i)) (fun i => bitListFractionValue (v i)) is).2 := by
  induction is with
  | nil => rfl
  | cons i is ih =>
    have hm := (encodedFraction_envelope_bounds (u i) (v i) (hu i) (hv i)).2.2.1
    have ha := (encodedFraction_envelope_bounds (bitListFractionMul (u i) (v i))
      (encodedProductSum u v is)
      (bitListFractionMul_wellFormed _ _ (hu i).2.2.1 (hv i).2.2.1)
      (encodedProductSum_wellFormed _ _ (fun i => (hu i).2.2.1) (fun i => (hv i).2.2.1) is)).1
    rw [bitListFractionMul_correct _ _ (hu i).2.2.1 (hv i).2.2.1,
      encodedProductSum_value _ _ (fun i => (hu i).2.2.1) (fun i => (hv i).2.2.1)] at ha
    rw [encodedProductSumWork, meteredProductSum]
    simp only [envelopeReductionPrimitives, meteredProductSum_value]
    exact Nat.add_le_add (Nat.add_le_add hm ih) ha

def encodedRationalDotWork (u v : Fin d → BitListFraction) : ℕ :=
  encodedProductSumWork u v (List.ofFn id)

theorem encodedRationalDotWork_le (u v : Fin d → BitListFraction)
    (hu : ∀ i, (u i).WellFormed) (hv : ∀ i, (v i).WellFormed) :
    encodedRationalDotWork u v ≤
      (meteredRationalDot envelopeReductionPrimitives
        (fun i => bitListFractionValue (u i)) (fun i => bitListFractionValue (v i))).2 :=
  encodedProductSumWork_le u v hu hv _

def encodedGsCoefficientWork (A T : BitRationalMatrixData r d) (k j : Fin r) : ℕ :=
  let num := encodedRationalDot (T.get j).get (A.get k).get
  let den := encodedRationalDot (T.get j).get (T.get j).get
  encodedRationalDotWork (T.get j).get (A.get k).get+
    encodedRationalDotWork (T.get j).get (T.get j).get+bitListFractionDivCost num den

theorem encodedGsCoefficientWork_le (A T : BitRationalMatrixData r d)
    (hA : EncodedRationalCanonical A) (hT : EncodedRationalCanonical T) (k j : Fin r) :
    encodedGsCoefficientWork A T k j ≤
      (meteredGsCoefficient envelopeReductionPrimitives
        (encodedFractionRows A) (encodedFractionTableValue T) k j).2 := by
  have hn := encodedRationalDotWork_le (T.get j).get (A.get k).get (hT j) (hA k)
  have hd := encodedRationalDotWork_le (T.get j).get (T.get j).get (hT j) (hT j)
  have hdiv := (encodedFraction_envelope_bounds
    (encodedRationalDot (T.get j).get (A.get k).get)
    (encodedRationalDot (T.get j).get (T.get j).get)
    (encodedRationalDot_wellFormed _ _ (hT.positive j) (hA.positive k))
    (encodedRationalDot_wellFormed _ _ (hT.positive j) (hT.positive j))).2.2.2.1
  rw [encodedRationalDot_value _ _ (hT.positive j) (hA.positive k),
    encodedRationalDot_value _ _ (hT.positive j) (hT.positive j)] at hdiv
  unfold encodedGsCoefficientWork meteredGsCoefficient
  simp only [envelopeReductionPrimitives, meteredRationalDot_value,
    encodedFractionTableValue, get_ofFn, get_ofFn_fun]
  exact Nat.add_le_add (Nat.add_le_add hn hd) hdiv

def encodedGSRowWork (A T : BitRationalMatrixData r d) (k : Fin r) : ℕ :=
  let coeff := encodedGSCoefficients A T k
  (∑ i : Fin r, if i < k then encodedGsCoefficientWork A T k i else 0)+
    ∑ l : Fin d,
      let u := fun i : Finset.Iio k => coeff.get i
      let v := fun i : Finset.Iio k => (T.get i).get l
      let is := List.ofFn (lowerFinEquiv k)
      encodedProductSumWork u v is+bitListFractionSubCost ((A.get k).get l) (encodedProductSum u v is)

theorem encodedGSRowWork_le (A T : BitRationalMatrixData r d)
    (hA : EncodedRationalCanonical A) (hT : EncodedRationalCanonical T) (k : Fin r) :
    encodedGSRowWork A T k ≤
      (meteredGSRow envelopeReductionPrimitives
        (encodedFractionRows A) (encodedFractionTableValue T) k).2 := by
  have hcoef (i : Fin r) :
      bitListFractionValue ((encodedGSCoefficients A T k).get i) =
        (if i < k then meteredGsCoefficient envelopeReductionPrimitives
          (encodedFractionRows A) (encodedFractionTableValue T) k i else (0,0)).1 := by
    simp only [encodedGSCoefficients, get_ofFn]
    split_ifs
    · rw [encodedGsCoefficient_value A T hA.positive hT.positive, meteredGsCoefficient_value]
    · exact bitListFractionZero_value
  unfold encodedGSRowWork meteredGSRow
  simp only [get_ofFn, apply_ite Prod.snd]
  apply Nat.add_le_add
  · apply Finset.sum_le_sum
    intro i _
    split_ifs
    · exact encodedGsCoefficientWork_le A T hA hT k i
    · exact le_rfl
  · apply Finset.sum_le_sum
    intro l _
    let u := fun i : Finset.Iio k => (encodedGSCoefficients A T k).get i
    let v := fun i : Finset.Iio k => (T.get i).get l
    let is := List.ofFn (lowerFinEquiv k)
    have hu (i : Finset.Iio k) : (u i).WellFormed :=
      encodedGSCoefficients_wellFormed A T hA.positive hT.positive k i
    have hv (i : Finset.Iio k) : (v i).WellFormed := hT i l
    have hw := encodedProductSumWork_le u v hu hv is
    have hs := (encodedFraction_envelope_bounds ((A.get k).get l)
      (encodedProductSum u v is) (hA k l)
      (encodedProductSum_wellFormed u v (fun i => (hu i).2.2.1) (fun i => (hv i).2.2.1) is)).2.1
    have hvu : (fun i : Finset.Iio k => bitListFractionValue (u i)) =
        (fun i : Finset.Iio k => (if (i:Fin r) < k then meteredGsCoefficient envelopeReductionPrimitives
          (encodedFractionRows A) (encodedFractionTableValue T) k i else (0,0)).1) :=
      funext fun i => hcoef i
    rw [hvu] at hw
    rw [encodedProductSum_value u v (fun i => (hu i).2.2.1) (fun i => (hv i).2.2.1)] at hs
    have hmap : (is.map fun i => bitListFractionValue (u i)*bitListFractionValue (v i)).sum =
        (meteredProductSum envelopeReductionPrimitives
          (fun i : Finset.Iio k => (if (i:Fin r) < k then meteredGsCoefficient envelopeReductionPrimitives
            (encodedFractionRows A) (encodedFractionTableValue T) k i else (0,0)).1)
          (fun i : Finset.Iio k => bitListFractionValue (v i)) is).1 := by
      rw [meteredProductSum_value]
      congr 1
      apply List.map_congr_left
      intro i _
      rw [hcoef]
    rw [hmap] at hs
    simp only [envelopeReductionPrimitives, encodedFractionTableValue, get_ofFn, get_ofFn_fun]
    exact Nat.add_le_add hw hs

def encodedGSTableWork (A : BitRationalMatrixData r d) (n : ℕ) (hn : n ≤ r) : ℕ :=
  match n with
  | 0 => 0
  | n+1 =>
    let T := encodedGSTable A n (by omega)
    encodedGSTableWork A n (by omega)+encodedGSRowWork A T ⟨n,by omega⟩
termination_by n

theorem encodedGSTableWork_le (A : BitRationalMatrixData r d)
    (hA : EncodedRationalCanonical A) (n : ℕ) (hn : n ≤ r) :
    encodedGSTableWork A n hn ≤
      (meteredGSTable envelopeReductionPrimitives (encodedFractionRows A) n hn).2 := by
  induction n with
  | zero => rw [encodedGSTableWork, meteredGSTable]
  | succ n ih =>
    rw [encodedGSTableWork, meteredGSTable]
    have ht : EncodedRationalCanonical (encodedGSTable A n (by omega)) :=
      encodedGSTable_wellFormed A hA.positive n (by omega)
    have hr := encodedGSRowWork_le A (encodedGSTable A n (by omega)) hA ht ⟨n,by omega⟩
    rw [encodedGSTable_value A hA.positive] at hr
    rw [meteredGSTable_value]
    exact Nat.add_le_add (ih (by omega)) hr

def encodedIntegerRowUpdateWork (D : BitIntegerMatrixData r d) (k j : Fin r) (q : BitListInteger) : ℕ :=
  ∑ l : Fin d, bitListIntegerRowCellCost ((D.get k).get l) q ((D.get j).get l)

theorem encodedIntegerRowUpdateWork_le (D : BitIntegerMatrixData r d)
    (hD : EncodedIntegerCanonical D) (k j : Fin r) (q : BitListInteger)
    (hq : BitListCanonical q.digits) :
    encodedIntegerRowUpdateWork D k j q ≤
      (primitiveIntegerRowUpdate envelopeReductionPrimitives
        (materializeIntegerMatrix (bitIntegerMatrixValue D)) k j q.value).2 := by
  simp only [encodedIntegerRowUpdateWork, primitiveIntegerRowUpdate, get_ofFn,
    materializeIntegerMatrix, envelopeReductionPrimitives]
  apply Finset.sum_le_sum
  intro l _
  exact encodedInteger_envelope_bound _ _ _ (hD k l) hq (hD j l)

theorem encodedIntegerRowUpdate_materialized_value (ops : ReductionPrimitives)
    (D : BitIntegerMatrixData r d) (k j : Fin r) (q : BitListInteger) :
    materializeIntegerMatrix (bitIntegerMatrixValue (bitListIntegerRowUpdate D k j q)) =
      (primitiveIntegerRowUpdate ops (materializeIntegerMatrix (bitIntegerMatrixValue D)) k j q.value).1 := by
  rw [primitiveIntegerRowUpdate_value, integerMatrixDataRows_materialize, bitListIntegerRowUpdate_value]

def encodedReduceIntegerRowWork (D : BitIntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) : ℕ :=
  match n with
  | 0 => 0
  | n+1 =>
    let j : Fin r := ⟨n, by omega⟩
    let Q := encodedRationalIntegerRows D
    let T := encodedGSTable Q r le_rfl
    let coefficient := encodedGsCoefficient Q T k j
    let q := encodedRoundInteger coefficient
    let W := bitListIntegerRowUpdate D k j q
    encodedGSTableWork Q r le_rfl+encodedGsCoefficientWork Q T k j+
      bitListFractionRoundCost coefficient+encodedIntegerRowUpdateWork D k j q+
      encodedReduceIntegerRowWork W k n (by omega)
termination_by n

theorem encodedReduceIntegerRowWork_le (D : BitIntegerMatrixData r d)
    (hD : EncodedIntegerCanonical D) (k : Fin r) (n : ℕ) (h : n ≤ k.val) :
    encodedReduceIntegerRowWork D k n h ≤
      (primitiveReduceIntegerRow envelopeReductionPrimitives
        (materializeIntegerMatrix (bitIntegerMatrixValue D)) k n h).2 := by
  induction n generalizing D with
  | zero => rw [encodedReduceIntegerRowWork, primitiveReduceIntegerRow]
  | succ n ih =>
    let j : Fin r := ⟨n,by omega⟩
    let Q := encodedRationalIntegerRows D
    let T := encodedGSTable Q r le_rfl
    let c := encodedGsCoefficient Q T k j
    let q := encodedRoundInteger c
    let W := bitListIntegerRowUpdate D k j q
    have hQ : EncodedRationalCanonical Q := encodedRationalIntegerRows_wellFormed D hD
    have hT : EncodedRationalCanonical T := encodedGSTable_wellFormed Q hQ.positive r le_rfl
    have hq : BitListCanonical q.digits := encodedRoundInteger_canonical c
    have hc : c.WellFormed := encodedGsCoefficient_wellFormed Q T hQ.positive hT.positive k j
    have ht := encodedGSTableWork_le Q hQ r le_rfl
    have hcoef := encodedGsCoefficientWork_le Q T hQ hT k j
    have hr := encodedRound_envelope_bound c hc
    have hu := encodedIntegerRowUpdateWork_le D hD k j q hq
    have hi := ih W (bitListIntegerRowUpdate_canonical D hD k j q) (by omega)
    have hec : bitListFractionValue c = cachedGsCoefficient
        (rationalIntegerRows (bitIntegerMatrixValue D))
        (cachedGSTable (rationalIntegerRows (bitIntegerMatrixValue D)) r le_rfl) k j := by
      rw [encodedGsCoefficient_value Q T hQ.positive hT.positive]
      simp only [T, encodedGSTable_value Q hQ.positive, Q, encodedRationalIntegerRows_value]
    have heq : q.value = round (bitListFractionValue c) := encodedRoundInteger_value c hc.2.2.1
    have hi' := hi
    rw [show W = bitListIntegerRowUpdate D k j q from rfl,
      encodedIntegerRowUpdate_materialized_value, heq, hec] at hi'
    rw [heq, hec] at hu
    rw [hec] at hr
    simp only [T, encodedGSTable_value Q hQ.positive, Q, encodedRationalIntegerRows_value] at hcoef ht
    rw [encodedReduceIntegerRowWork, primitiveReduceIntegerRow]
    simp only [integerMatrixDataRows_materialize, meteredGSTable_value, meteredGsCoefficient_value,
      envelopeReductionPrimitives.round_value]
    exact Nat.add_le_add (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add ht hcoef) hr) hu) hi'

def encodedReduceIntegerAllWork (D : BitIntegerMatrixData r d)
    (n : ℕ) (h : n ≤ r) : ℕ :=
  match n with
  | 0 => 0
  | n+1 =>
    let C := encodedReduceIntegerAll D n (by omega)
    encodedReduceIntegerAllWork D n (by omega)+encodedReduceIntegerRowWork C ⟨n,by omega⟩ n le_rfl
termination_by n

private theorem materialize_rows (D : IntegerMatrixData r d) :
    materializeIntegerMatrix (integerMatrixDataRows D) = D := by
  apply Vector.ext
  intro i hi
  apply Vector.ext
  intro j hj
  change ((materializeIntegerMatrix (integerMatrixDataRows D)).get ⟨i,hi⟩).get ⟨j,hj⟩ = _
  simp only [materializeIntegerMatrix, integerMatrixDataRows, get_ofFn]
  rfl

theorem encodedReduceIntegerAll_materialized_value (ops : ReductionPrimitives)
    (D : BitIntegerMatrixData r d) (n : ℕ) (h : n ≤ r) :
    materializeIntegerMatrix (bitIntegerMatrixValue (encodedReduceIntegerAll D n h)) =
      (primitiveReduceIntegerAll ops (materializeIntegerMatrix (bitIntegerMatrixValue D)) n h).1 := by
  rw [primitiveReduceIntegerAll_value, encodedReduceIntegerAll_value]
  have he := materializedReduceIntegerAll_eq (materializeIntegerMatrix (bitIntegerMatrixValue D)) n h
  rw [integerMatrixDataRows_materialize] at he
  rw [← he, materialize_rows]

theorem encodedReduceIntegerAllWork_le (D : BitIntegerMatrixData r d)
    (hD : EncodedIntegerCanonical D) (n : ℕ) (h : n ≤ r) :
    encodedReduceIntegerAllWork D n h ≤
      (primitiveReduceIntegerAll envelopeReductionPrimitives
        (materializeIntegerMatrix (bitIntegerMatrixValue D)) n h).2 := by
  induction n with
  | zero => rw [encodedReduceIntegerAllWork, primitiveReduceIntegerAll]
  | succ n ih =>
    rw [encodedReduceIntegerAllWork, primitiveReduceIntegerAll]
    have hr := encodedReduceIntegerRowWork_le (encodedReduceIntegerAll D n (by omega))
      (encodedReduceIntegerAll_canonical D hD n (by omega)) ⟨n,by omega⟩ n le_rfl
    rw [encodedReduceIntegerAll_materialized_value] at hr
    exact Nat.add_le_add (ih (by omega)) hr

def encodedLovaszPairWork (A T : BitRationalMatrixData r d) (j k : Fin r) : ℕ :=
  let nk := encodedRationalDot (T.get k).get (T.get k).get
  let nj := encodedRationalDot (T.get j).get (T.get j).get
  let mu := encodedGsCoefficient A T k j
  let square := bitListFractionMul mu mu
  let product := bitListFractionMul square nj
  let total := bitListFractionAdd nk product
  let left := bitListFractionMul encodedFractionFour total
  let right := bitListFractionMul encodedFractionThree nj
  encodedRationalDotWork (T.get k).get (T.get k).get+
    encodedRationalDotWork (T.get j).get (T.get j).get+encodedGsCoefficientWork A T k j+
    bitListFractionMulCost mu mu+bitListFractionMulCost square nj+bitListFractionAddCost nk product+
    bitListFractionMulCost encodedFractionFour total+bitListFractionMulCost encodedFractionThree nj+
    bitListFractionLTCost left right

private theorem three_wellFormed : encodedFractionThree.WellFormed := by
  refine ⟨?_,?_,by decide,?_⟩
  · simpa [encodedFractionThree,bitListTrim] using bitListTrim_canonical [true,true]
  · simpa [encodedFractionThree,bitListTrim] using bitListTrim_canonical [true]
  · norm_num [encodedFractionThree,binaryDigitsValue]

private theorem four_wellFormed : encodedFractionFour.WellFormed := by
  refine ⟨?_,?_,by decide,?_⟩
  · simpa [encodedFractionFour,bitListTrim] using bitListTrim_canonical [false,false,true]
  · simpa [encodedFractionFour,bitListTrim] using bitListTrim_canonical [true]
  · norm_num [encodedFractionFour,binaryDigitsValue]

private theorem three_value : bitListFractionValue encodedFractionThree = 3 := by
  norm_num [encodedFractionThree,bitListFractionValue,signedBitsValue,binaryDigitsValue]
private theorem four_value : bitListFractionValue encodedFractionFour = 4 := by
  norm_num [encodedFractionFour,bitListFractionValue,signedBitsValue,binaryDigitsValue]

set_option maxRecDepth 4096 in
theorem encodedLovaszPairWork_le (A T : BitRationalMatrixData r d)
    (hA : EncodedRationalCanonical A) (hT : EncodedRationalCanonical T) (j k : Fin r) :
    encodedLovaszPairWork A T j k ≤
      (primitiveLovaszPair envelopeReductionPrimitives
        (encodedFractionRows A) (encodedFractionTableValue T) j k).2 := by
  let nk := encodedRationalDot (T.get k).get (T.get k).get
  let nj := encodedRationalDot (T.get j).get (T.get j).get
  let mu := encodedGsCoefficient A T k j
  let square := bitListFractionMul mu mu
  let product := bitListFractionMul square nj
  let total := bitListFractionAdd nk product
  let left := bitListFractionMul encodedFractionFour total
  let right := bitListFractionMul encodedFractionThree nj
  have hnk : nk.WellFormed := encodedRationalDot_wellFormed _ _ (hT.positive k) (hT.positive k)
  have hnj : nj.WellFormed := encodedRationalDot_wellFormed _ _ (hT.positive j) (hT.positive j)
  have hmu : mu.WellFormed := encodedGsCoefficient_wellFormed A T hA.positive hT.positive k j
  have hsq : square.WellFormed := bitListFractionMul_wellFormed _ _ hmu.2.2.1 hmu.2.2.1
  have hpr : product.WellFormed := bitListFractionMul_wellFormed _ _ hsq.2.2.1 hnj.2.2.1
  have htot : total.WellFormed := bitListFractionAdd_wellFormed _ _ hnk.2.2.1 hpr.2.2.1
  have hleft : left.WellFormed := bitListFractionMul_wellFormed _ _ four_wellFormed.2.2.1 htot.2.2.1
  have hright : right.WellFormed := bitListFractionMul_wellFormed _ _ three_wellFormed.2.2.1 hnj.2.2.1
  have hnkw := encodedRationalDotWork_le (T.get k).get (T.get k).get (hT k) (hT k)
  have hnjw := encodedRationalDotWork_le (T.get j).get (T.get j).get (hT j) (hT j)
  have hmuw := encodedGsCoefficientWork_le A T hA hT k j
  have hsqw := (encodedFraction_envelope_bounds mu mu hmu hmu).2.2.1
  have hprw := (encodedFraction_envelope_bounds square nj hsq hnj).2.2.1
  have htotw := (encodedFraction_envelope_bounds nk product hnk hpr).1
  have hleftw := (encodedFraction_envelope_bounds encodedFractionFour total four_wellFormed htot).2.2.1
  have hrightw := (encodedFraction_envelope_bounds encodedFractionThree nj three_wellFormed hnj).2.2.1
  have htestw := (encodedFraction_envelope_bounds left right hleft hright).2.2.2.2
  have heq := Nat.add_le_add (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add
    (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add hnkw hnjw) hmuw) hsqw) hprw) htotw) hleftw) hrightw) htestw
  change encodedLovaszPairWork A T j k ≤ _ at heq
  refine heq.trans_eq ?_
  simp only [primitiveLovaszPair, envelopeReductionPrimitives, meteredRationalDot_value,
    meteredGsCoefficient_value, encodedFractionTableValue, get_ofFn, get_ofFn_fun]
  simp only [left,right,total,product,square,
    bitListFractionMul_correct _ _ four_wellFormed.2.2.1 htot.2.2.1,
    bitListFractionMul_correct _ _ three_wellFormed.2.2.1 hnj.2.2.1,
    bitListFractionAdd_correct _ _ hnk.2.2.1 hpr.2.2.1,
    bitListFractionMul_correct _ _ hsq.2.2.1 hnj.2.2.1,
    bitListFractionMul_correct _ _ hmu.2.2.1 hmu.2.2.1,three_value,four_value]
  simp only [nk,nj,mu,encodedGsCoefficient_value A T hA.positive hT.positive,
    encodedRationalDot_value _ _ (hT.positive k) (hT.positive k),
    encodedRationalDot_value _ _ (hT.positive j) (hT.positive j)]
  rfl

def encodedFailingAdjacentPairsWork (D : BitIntegerMatrixData r d) : ℕ :=
  let Q := encodedRationalIntegerRows D
  let T := encodedGSTable Q r le_rfl
  encodedGSTableWork Q r le_rfl+
    ∑ j : Fin r, ∑ k : Fin r, if k.val=j.val+1 then encodedLovaszPairWork Q T j k else 0

theorem encodedFailingAdjacentPairsWork_le (D : BitIntegerMatrixData r d)
    (hD : EncodedIntegerCanonical D) :
    encodedFailingAdjacentPairsWork D ≤
      (primitiveFailingAdjacentPairs envelopeReductionPrimitives
        (materializeIntegerMatrix (bitIntegerMatrixValue D))).2 := by
  let Q := encodedRationalIntegerRows D
  let T := encodedGSTable Q r le_rfl
  have hQ : EncodedRationalCanonical Q := encodedRationalIntegerRows_wellFormed D hD
  have hT : EncodedRationalCanonical T := encodedGSTable_wellFormed Q hQ.positive r le_rfl
  have ht := encodedGSTableWork_le Q hQ r le_rfl
  have hp (j k : Fin r) := encodedLovaszPairWork_le Q T hQ hT j k
  simp only [T, encodedGSTable_value Q hQ.positive, Q, encodedRationalIntegerRows_value] at ht hp
  unfold encodedFailingAdjacentPairsWork primitiveFailingAdjacentPairs
  simp only [get_ofFn, apply_ite Prod.snd, integerMatrixDataRows_materialize, meteredGSTable_value]
  apply Nat.add_le_add ht
  apply Finset.sum_le_sum
  intro j _
  apply Finset.sum_le_sum
  intro k _
  split_ifs
  · exact hp j k
  · exact le_rfl

/-- Actual scalar work along the same list-fueled encoded answer trace. -/
def encodedReductionFuelWork : List Bool → BitIntegerMatrixData r d → ℕ
  | [], _ => 0
  | _::fuel, D =>
    let C := encodedReduceIntegerAll D r le_rfl
    let tests := encodedFailingAdjacentPairs C
    if h : tests.Nonempty then
      let p := leastPairInFinset tests h
      let W := encodedSwapRows C p.1 p.2
      encodedReduceIntegerAllWork D r le_rfl+encodedFailingAdjacentPairsWork C+
        encodedReductionFuelWork fuel W
    else encodedReduceIntegerAllWork D r le_rfl+encodedFailingAdjacentPairsWork C

theorem encodedReductionFuelWork_le (fuel : List Bool) (D : BitIntegerMatrixData r d)
    (hD : EncodedIntegerCanonical D) :
    encodedReductionFuelWork fuel D ≤
      (primitiveReductionFuel envelopeReductionPrimitives fuel.length
        (materializeIntegerMatrix (bitIntegerMatrixValue D))).work := by
  induction fuel generalizing D with
  | nil => rfl
  | cons b fuel ih =>
    let C := encodedReduceIntegerAll D r le_rfl
    have hC : EncodedIntegerCanonical C := encodedReduceIntegerAll_canonical D hD r le_rfl
    have hs := encodedReduceIntegerAllWork_le D hD r le_rfl
    have ht := encodedFailingAdjacentPairsWork_le C hC
    have heC := encodedReduceIntegerAll_materialized_value envelopeReductionPrimitives D r le_rfl
    have hvC : bitIntegerMatrixValue C = integerMatrixDataRows
        (primitiveReduceIntegerAll envelopeReductionPrimitives
          (materializeIntegerMatrix (bitIntegerMatrixValue D)) r le_rfl).1 := by
      have he := congrArg integerMatrixDataRows heC
      simpa only [integerMatrixDataRows_materialize] using he
    rw [show C = encodedReduceIntegerAll D r le_rfl from rfl, heC] at ht
    rw [encodedReductionFuelWork, List.length_cons, primitiveReductionFuel]
    simp only [encodedFailingAdjacentPairs_value, primitiveFailingAdjacentPairs_value,
      ← hvC]
    split_ifs with h
    · simp only [MeteredLatticeResult.work]
      have hi := ih (encodedSwapRows C (leastPairInFinset _ h).1 (leastPairInFinset _ h).2)
        (encodedSwapRows_canonical C hC _ _)
      rw [encodedSwapRows_value] at hi
      exact Nat.add_le_add (Nat.add_le_add hs ht) hi
    · exact Nat.add_le_add hs ht

/-- Gates and bit-list visits of the actual encoded execution are bounded by
the same input-height polynomial as the proof-only scalar envelope. -/
theorem encodedReductionFuelWork_initial_bound (fuel : List Bool) (D : BitIntegerMatrixData r d)
    (hD : EncodedIntegerCanonical D)
    (hind : LinearIndependent ℝ (fun i j => (bitIntegerMatrixValue D i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |bitIntegerMatrixValue D i j| ≤ (H:ℤ)) :
    encodedReductionFuelWork fuel D ≤
      ((encodedReductionFuel fuel D).swaps+1)*(32*(r+1)^4*(d+1))*
        (65536*(8*(2*(r+d)+10)*(2*r+4)*
          (loopArithmeticBase r d H (gramPotential (bitIntegerMatrixValue D))).size+1)^3) := by
  have hw := PrimitiveWork.primitiveReductionFuel_cubic_initial_work envelopeCubicReductionBackend
    fuel.length (bitIntegerMatrixValue D) hind H hH
  have he := congrArg Prod.snd (encodedReductionFuel_materialized_value fuel D)
  change (encodedReductionFuel fuel D).swaps =
    (materializedReductionFuel fuel.length (materializeIntegerMatrix (bitIntegerMatrixValue D))).2 at he
  rw [← he] at hw
  exact (encodedReductionFuelWork_le fuel D hD).trans hw

/-- Scalar work of the concrete encoded integer reducer, including its
actually selected list-fueled trace. Fuel construction has its own cost. -/
def encodedIntegerReductionWork (D : BitIntegerMatrixData r d) : ℕ :=
  encodedReductionFuelWork (bitMatrixReductionFuel D) D

/-- A polynomial in dimension and input-height bit length bounds every
actual scalar gate and bit-list visit in encoded integer reduction. -/
theorem encodedIntegerReductionWork_input_polynomial (D : BitIntegerMatrixData r d)
    (hD : EncodedIntegerCanonical D)
    (hind : LinearIndependent ℝ (fun i j => (bitIntegerMatrixValue D i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |bitIntegerMatrixValue D i j| ≤ (H:ℤ)) :
    encodedIntegerReductionWork D ≤
      (3*(r*(r+1)+1)*(r.size+d.size+2*H.size+4))*(32*(r+1)^4*(d+1))*
        (65536*(8*(2*(r+d)+10)*(2*r+4)*
          (3*H.size+5*r.size+2*d.size+
            8*(r*(r+1)+1)*(r.size+d.size+2*H.size+4)+12)+1)^3) := by
  have hb := encodedReductionFuelWork_initial_bound (bitMatrixReductionFuel D) D hD hind H hH
  have hs := (executableIntegerReduction (bitIntegerMatrixValue D) hind).swapCount_input_bits
    (bitIntegerMatrixValue D) H hH
  have he := congrArg Prod.snd (encodedIntegerReduction_value D hind)
  change (encodedIntegerReduction D).swaps =
    (executableReductionFuel (gramPotential (bitIntegerMatrixValue D)) (bitIntegerMatrixValue D)).2 at he
  change (executableReductionFuel (gramPotential (bitIntegerMatrixValue D))
    (bitIntegerMatrixValue D)).2+1 ≤ _ at hs
  rw [← he] at hs
  have hbits := globalSweepArithmeticBase_input_bits (bitIntegerMatrixValue D) H hH
  change (loopArithmeticBase r d H (gramPotential (bitIntegerMatrixValue D))).size ≤ _ at hbits
  apply hb.trans
  apply Nat.mul_le_mul
  · exact Nat.mul_le_mul_right _ hs
  · exact Nat.mul_le_mul_left 65536 (Nat.pow_le_pow_left
      (Nat.add_le_add_right (Nat.mul_le_mul_left _ hbits) 1) 3)

end Optss
