import Optss.BohrPhaseDensity

/-! A proper integer-coefficient progression in the actual cyclic Bohr set. -/
namespace Optss
noncomputable section
open scoped BigOperators Pointwise
open Classical
variable {N r : ℕ} [NeZero N]

def phaseCoordinateHom (base : Fin r) : IntVec r →+ ZMod N where
  toFun z := (z base : ZMod N)
  map_zero' := by simp
  map_add' _ _ := by simp

theorem subgroup_cube_points_card (Γ : AddSubgroup (IntVec r))
    (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (hΛ : basisIntegerLattice b=realVector '' (Γ : Set (IntVec r))) (W : Fin r → ℕ) :
    ((integerBudgetBox W).filter fun z => z∈Γ).card=
      (basisLatticePoints b (realCoefficientBox W) (realCoefficientBox_compact W)).card := by
  have he : (((integerBudgetBox W).filter fun z => z∈Γ).image realVector)=
      basisLatticePoints b (realCoefficientBox W) (realCoefficientBox_compact W) := by
    ext x
    simp only [Finset.mem_image,Finset.mem_filter,mem_basisLatticePoints,hΛ,Set.mem_image]
    constructor
    · rintro ⟨z,⟨hz,hΓ⟩,rfl⟩
      refine ⟨?_,z,hΓ,rfl⟩
      rw [mem_realCoefficientBox]
      intro j
      change |(z j : ℝ)|≤(W j : ℝ)
      have hj : |z j|≤(W j : ℤ) := (mem_integerBudgetBox W z).mp hz j
      exact_mod_cast hj
    · rintro ⟨hx,z,hΓ,rfl⟩
      refine ⟨z,⟨?_,hΓ⟩,rfl⟩
      rw [mem_integerBudgetBox]
      intro j
      have hj := (mem_realCoefficientBox W (realVector z)).mp hx j
      change |(z j : ℝ)|≤(W j : ℝ) at hj
      exact_mod_cast hj
  rw [← he,Finset.card_image_of_injective _ realVector_is_injective]

theorem integer_subgroup_inner_cube (hr : 0<r) (Γ : AddSubgroup (IntVec r))
    (period : ℕ) (hperiod : 0<period) (haxes : ∀ j, Pi.single j (period : ℤ)∈Γ)
    (M : ℕ) (hM : 0<M) (C : ℕ) (hC : 0<C)
    (hCJ : latticeBoxingDilation r ((r.factorial : ℝ)*latticeReductionDefectBound r)≤(C : ℝ)) :
    ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
      basisIntegerLattice b=realVector '' (Γ : Set (IntVec r)) ∧
      ∃ m : Fin r → ℕ, basisCoefficientBox b m⊆realCoefficientBox (fun _ => M) ∧
        ((integerBudgetBox (fun _ => M)).filter fun z => z∈Γ).card≤
          (2*C+1)^r*∏ j, (2*m j+1) := by
  obtain ⟨b₀,hΛ₀,hrat₀⟩ := integer_subgroup_rational_basis Γ (fun _ => (period : ℤ))
    (fun _ => by change (0 : ℤ)<period; exact_mod_cast hperiod) haxes
  have hrat : ∀ x∈realBoxVertices (fun _ : Fin r => M), ∀ i, ∃ q : ℚ, (q : ℝ)=b₀.equivFun x i := by
    intro x hx
    apply rational_basis_coordinates b₀ hrat₀ x
    intro i
    obtain ⟨z,hz⟩ := realBoxVertices_integral (fun _ => M) hx
    refine ⟨z i,?_⟩
    simpa only [Rat.cast_intCast] using congrFun hz i
  obtain ⟨b,hΛ,m,hinner,hcard⟩ := rational_polytope_inner_lattice_box hr b₀
    (realBoxVertices (fun _ => M)) (realBoxVertices_span _ (fun _ => hM))
    (fun x hx => realBoxVertices_symmetric _ hx) hrat C hC hCJ
  simp only [convexHull_realBoxVertices] at hinner hcard
  refine ⟨b,hΛ.trans hΛ₀,m,hinner,?_⟩
  rw [subgroup_cube_points_card Γ b₀ hΛ₀]
  exact hcard

theorem integerBudgetBox_zero : integerBudgetBox (fun _ : Fin r => 0)={0} := by
  ext z
  simp only [mem_integerBudgetBox,InBox,Nat.cast_zero,Finset.mem_singleton]
  constructor
  · intro hz
    funext j
    have h := hz j
    have hh := abs_le.mp h
    change z j=0
    omega
  · intro hz
    subst z
    simp

theorem phaseLatticeCube_zero (a : Fin r → ZMod N) (base : Fin r) :
    phaseLatticeCube a base 0={0} := by
  ext z
  simp only [phaseLatticeCube,integerBudgetBox_zero,Finset.mem_filter,Finset.mem_singleton]
  constructor
  · exact And.left
  · intro hz
    subst z
    exact ⟨rfl,(cyclicPhaseLattice a base).zero_mem⟩

/-- Actual proper progression construction for a frequency family including
the residue coordinate. The loss depends only on the number of coordinates. -/
theorem phase_lattice_bohr_progression (a : Fin r → ZMod N) (base : Fin r) (ha : a base=1)
    (S : Finset (ZMod N)) (hS : ∀ k∈S, ∃ j, a j=k)
    (C : ℕ) (hC : 0<C)
    (hCJ : latticeBoxingDilation r ((r.factorial : ℝ)*latticeReductionDefectBound r)≤(C : ℝ)) :
    ∃ ρ : IntVec r →+ ZMod N, ∃ m : Fin r → ℕ,
      Set.InjOn ρ (integerBudgetBox m) ∧
      (∀ z∈integerBudgetBox m, ρ z∈cyclicBohrSet S) ∧
      N≤(16*(2*C+1))^r*∏ j, (2*m j+1) := by
  have hr : 0<r := by have h := base.isLt; omega
  have hdensity := phaseLatticeCube_density a base ha
  by_cases hM : N/16=0
  · refine ⟨0,fun _ => 0,?_,?_,?_⟩
    · intro x hx y hy _
      rw [integerBudgetBox_zero,Finset.mem_coe,Finset.mem_singleton] at hx hy
      exact hx.trans hy.symm
    · intro z _ k _
      simp [AddChar.map_zero_eq_one]
    · rw [hM,phaseLatticeCube_zero,Finset.card_singleton,mul_one] at hdensity
      simp only [mul_zero,zero_add,Finset.prod_const_one,mul_one]
      exact hdensity.trans (Nat.pow_le_pow_left (by omega) r)
  · obtain ⟨b,hΛ,m,hinner,hcard⟩ := integer_subgroup_inner_cube hr (cyclicPhaseLattice a base)
      N (NeZero.pos N) (cyclicPhaseLattice_axes a base) (N/16) (by omega) C hC hCJ
    let σ := subgroupBasisSynthesisHom (cyclicPhaseLattice a base) b hΛ
    let ρ : IntVec r →+ ZMod N := (phaseCoordinateHom base).comp σ
    have hσΓ (z : IntVec r) : σ z∈cyclicPhaseLattice a base := subgroupBasisSynthesis_mem (cyclicPhaseLattice a base) b hΛ z
    have hσbox (z : IntVec r) (hz : z∈integerBudgetBox m) : ∀ j, |σ z j|≤(N/16 : ℕ) := by
      have hx := hinner ((subgroupBasisSynthesisHom_box _ b hΛ m z).mp hz)
      rw [mem_realCoefficientBox] at hx
      intro j
      have hj := hx j
      change |((σ z j : ℤ) : ℝ)|≤(N/16 : ℕ) at hj
      exact (Int.cast_le (R := ℝ)).mp (by
        simpa only [Int.cast_abs,Int.cast_natCast] using hj)
    have hshort : 2*(N/16)<N := by
      have h := Nat.mul_div_le N 16
      omega
    refine ⟨ρ,m,?_,?_,?_⟩
    · intro x hx y hy he
      have he' : (σ x base : ZMod N)=(σ y base : ZMod N) := he
      have hxy := phase_lattice_projection_injective a base (N/16) hshort
        ⟨hσΓ x,hσbox x hx⟩ ⟨hσΓ y,hσbox y hy⟩ he'
      exact subgroupBasisSynthesisHom_injective _ b hΛ hxy
    · intro z hz
      apply phase_lattice_small_box_bohr a base S hS (σ z) (hσΓ z)
      intro j
      have hw := hσbox z hz j
      have hd : (16 : ℤ)*(N/16 : ℕ)≤N := by exact_mod_cast Nat.mul_div_le N 16
      omega
    · change (phaseLatticeCube a base (N/16)).card≤_ at hcard
      calc
        N≤16^r*(phaseLatticeCube a base (N/16)).card := hdensity
        _≤16^r*((2*C+1)^r*∏ j, (2*m j+1)) := Nat.mul_le_mul_left _ hcard
        _=_ := by rw [mul_pow]; ring

end
end Optss
