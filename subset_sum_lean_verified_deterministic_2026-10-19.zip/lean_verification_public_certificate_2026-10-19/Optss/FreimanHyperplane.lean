import Mathlib.LinearAlgebra.Dual.Lemmas
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas
import Mathlib.Tactic

/-!
# Hyperplanes avoiding a specified finite set

The hyperplane choice in Bilu Proposition 5.4 is constructed here by
perturbing linear forms while avoiding a finite list of bad real parameters.
It contains the specified subspace and meets the finite set in exactly the
same points. There is no generic-position hypothesis in the conclusion.
-/

namespace Optss
noncomputable section
open scoped Classical
variable {E : Type*} [AddCommGroup E] [Module ℝ E]

/-- A single form detects every specified point outside a subspace. -/
theorem finite_avoidance_linear_form (L : Submodule ℝ E) (S : Finset E) :
    ∃ f : E →ₗ[ℝ] ℝ, (∀ y ∈ L, f y = 0) ∧
      ∀ y ∈ S, y ∉ L → f y ≠ 0 := by
  induction S using Finset.induction_on with
  | empty => exact ⟨0, by simp, by simp⟩
  | @insert x S hx ih =>
    obtain ⟨f, hfL, hfS⟩ := ih
    by_cases hxL : x ∈ L
    · refine ⟨f, hfL, ?_⟩
      intro y hy hyL
      rcases Finset.mem_insert.mp hy with rfl | hy
      · exact False.elim (hyL hxL)
      · exact hfS y hy hyL
    · obtain ⟨g, hgx, hgL⟩ := L.exists_dual_map_eq_bot_of_nmem hxL inferInstance
      have hgL' : ∀ y ∈ L, g y = 0 := by
        intro y hy
        have hh : g y ∈ L.map g := ⟨y, hy, rfl⟩
        rwa [hgL, Submodule.mem_bot] at hh
      let bad : Finset ℝ := ((insert x S).filter (fun y => g y ≠ 0)).image
        (fun y => -f y / g y)
      obtain ⟨t, ht⟩ := Finset.exists_not_mem bad
      refine ⟨f + t • g, ?_, ?_⟩
      · intro y hy
        simp only [LinearMap.add_apply, LinearMap.smul_apply, smul_eq_mul, hfL y hy,
          hgL' y hy, mul_zero, add_zero]
      · intro y hy hyL
        change f y + t * g y ≠ 0
        by_cases hgy : g y = 0
        · rw [hgy, mul_zero, add_zero]
          rcases Finset.mem_insert.mp hy with rfl | hy
          · exact False.elim (hgx hgy)
          · exact hfS y hy hyL
        · intro he
          apply ht
          have ht' : t = -f y / g y := (eq_div_iff hgy).mpr (by linarith)
          exact Finset.mem_image.mpr ⟨y, Finset.mem_filter.mpr ⟨hy, hgy⟩, ht'.symm⟩

/-- Exact intersection, not merely avoidance of one chosen point. -/
theorem finite_exact_kernel (L : Submodule ℝ E) (S : Finset E) :
    ∃ f : E →ₗ[ℝ] ℝ, L ≤ LinearMap.ker f ∧
      ∀ x ∈ S, f x = 0 ↔ x ∈ L := by
  obtain ⟨f, hfL, hfS⟩ := finite_avoidance_linear_form L S
  refine ⟨f, fun x hx => hfL x hx, ?_⟩
  intro x hx
  exact ⟨fun he => by_contra (fun hn => hfS x hx hn he), fun hxL => hfL x hxL⟩

/-- If the finite set has a point outside the subspace, the chosen form is
nonzero, so its kernel is an actual hyperplane. -/
theorem finite_exact_hyperplane_form (L : Submodule ℝ E) (S : Finset E)
    (houtside : ∃ x ∈ S, x ∉ L) :
    ∃ f : E →ₗ[ℝ] ℝ, f ≠ 0 ∧ L ≤ LinearMap.ker f ∧
      ∀ x ∈ S, f x = 0 ↔ x ∈ L := by
  obtain ⟨f, hfL, hfS⟩ := finite_exact_kernel L S
  refine ⟨f, ?_, hfL, hfS⟩
  intro hf
  obtain ⟨x, hx, hxL⟩ := houtside
  exact hxL ((hfS x hx).mp (by simp [hf]))

/-- The exact codimension of the constructed kernel in finite dimension. -/
theorem finite_exact_hyperplane [FiniteDimensional ℝ E]
    (L : Submodule ℝ E) (S : Finset E) (houtside : ∃ x ∈ S, x ∉ L) :
    ∃ H : Submodule ℝ E, L ≤ H ∧ Module.finrank ℝ H + 1 = Module.finrank ℝ E ∧
      ∀ x ∈ S, x ∈ H ↔ x ∈ L := by
  obtain ⟨f, hf, hfL, hfS⟩ := finite_exact_hyperplane_form L S houtside
  have hnonzero : ∃ x, f x ≠ 0 := by
    by_contra h
    push_neg at h
    exact hf (LinearMap.ext h)
  obtain ⟨x, hx⟩ := hnonzero
  have hsurj : Function.Surjective f := by
    intro y
    refine ⟨(y / f x) • x, ?_⟩
    simp only [map_smul, smul_eq_mul]
    exact div_mul_cancel₀ y hx
  have hdim := f.finrank_range_add_finrank_ker
  rw [LinearMap.range_eq_top.mpr hsurj] at hdim
  simp only [finrank_top, Module.finrank_self] at hdim
  exact ⟨LinearMap.ker f, hfL, by omega, hfS⟩

end
end Optss
