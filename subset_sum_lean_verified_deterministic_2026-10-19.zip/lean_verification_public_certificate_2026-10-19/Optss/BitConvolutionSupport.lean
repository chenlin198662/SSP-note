import Optss.RoundedCyclicConvolution

/-! Pure stored Boolean extraction of exact convolution support. A single
positive power-of-two denominator is shared by all output coordinates. Each
coordinate is rounded by the proved Boolean fraction routine and then tested
for strict positivity by a Boolean ripple comparator. -/
namespace Optss
set_option maxRecDepth 4096

def bitFourierBoolean (b : Bool) : BitFourierInteger :=
  if b then ⟨⟨false,[true]⟩,⟨false,[]⟩⟩ else bitFourierZero

theorem bitFourierBoolean_value (b : Bool) : (bitFourierBoolean b).value=fourierBooleanInteger b := by
  cases b <;> rfl

def listConvolutionExponent (depth : List Bool) (p : ℕ) : List Bool :=
  depth.map (fun _ => false)++(depth++depth++depth).flatMap (fun _ => List.replicate (p+2) false)

def listConvolutionDenominator (depth : List Bool) (p : ℕ) : List Bool :=
  listConvolutionExponent depth p++[true]

theorem listConvolutionDenominator_eq (depth : List Bool) (p : ℕ) :
    listConvolutionDenominator depth p=fourierPowTwoDigits (depth.length+(p+2)*(3*depth.length)) := by
  have hflat (xs : List Bool) : xs.flatMap (fun _ => List.replicate (p+2) false)=
      List.replicate ((p+2)*xs.length) false := by
    induction xs with
    | nil => simp
    | cons b xs ih =>
      simp only [List.flatMap_cons,ih,List.length_cons,mul_add,mul_one]
      rw [← List.replicate_add]
      congr 1
      omega
  unfold listConvolutionDenominator listConvolutionExponent
  rw [fourierPowTwoDigits_eq_replicate,List.map_const',hflat,← List.replicate_add]
  congr 2
  simp only [List.length_append]
  ring

theorem listConvolutionDenominator_value (depth : List Bool) (p : ℕ) :
    binaryDigitsValue (listConvolutionDenominator depth p)=cyclicConvolutionDenominator depth.length p := by
  rw [listConvolutionDenominator_eq,fourierPowTwoDigits_value,pow_add,pow_mul]
  rfl

theorem listConvolutionDenominator_length (depth : List Bool) (p : ℕ) :
    (listConvolutionDenominator depth p).length=depth.length+(p+2)*(3*depth.length)+1 := by
  rw [listConvolutionDenominator_eq,fourierPowTwoDigits_length]

def bitSignedPositive (s : Bool) (digits : List Bool) : Bool := !s && !(bitListLE digits [])

theorem bitSignedPositive_correct (s : Bool) (digits : List Bool) :
    bitSignedPositive s digits=true ↔ 0<signedBitsValue s digits := by
  have hnon : bitListLE digits []=false ↔ 0<binaryDigitsValue digits := by
    simp only [Bool.eq_false_iff,ne_eq,bitListLE_correct,binaryDigitsValue,Nat.not_le]
  cases s <;> simp [bitSignedPositive,hnon,signedBitsValue]

def bitConvolutionPositive (den : List Bool) (z : BitFourierInteger) : Bool :=
  let r := bitListFractionRound ⟨z.re.negative,z.re.digits,den⟩
  bitSignedPositive r.1 r.2

theorem bitConvolutionPositive_correct (den : List Bool) (z : BitFourierInteger)
    (hden : 0<binaryDigitsValue den) :
    bitConvolutionPositive den z=true ↔ 0<round (z.value.re/(binaryDigitsValue den : ℚ)) := by
  rw [bitConvolutionPositive,bitSignedPositive_correct,bitListFractionRound_correct _ hden]
  rfl

def bitConvolutionPositiveWork (den : List Bool) (z : BitFourierInteger) : ℕ :=
  let q : BitListFraction := ⟨z.re.negative,z.re.digits,den⟩
  let r := bitListFractionRound q
  bitListFractionRoundCost q+bitListRippleGates 8 r.2 []+bitListSubVisits r.2 []+4

theorem bitConvolutionPositiveWork_bound (den : List Bool) (z : BitFourierInteger)
    (hden : 0<binaryDigitsValue den) (L : ℕ) (hz : z.Width L) (hd : den.length≤L) :
    bitConvolutionPositiveWork den z≤1048576*(L+1)^3 := by
  let q : BitListFraction := ⟨z.re.negative,z.re.digits,den⟩
  have hw := bitListFractionRoundCost_bound q hden L ⟨hz.1,hd⟩
  have hl := bitListFractionRound_output_le_cost q
  change bitListFractionRoundCost q+bitListRippleGates 8 (bitListFractionRound q).2 []+
    bitListSubVisits (bitListFractionRound q).2 []+4≤_
  rw [bitListRippleGates_eq,bitListSubVisits_eq,List.length_nil,Nat.max_zero]
  have hc : 1≤(L+1)^3 := Nat.one_le_pow _ _ (by omega)
  omega

end Optss
