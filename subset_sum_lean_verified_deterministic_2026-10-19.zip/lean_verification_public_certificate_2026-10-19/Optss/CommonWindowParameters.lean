import Optss.CommonWindowFilling

/-!
# Uniform common-window constants

Finite suprema give one block count, width threshold, and positive filling
scale for every positive rank up to the phase rank bound. No monotonicity in
the dimension of dense filling or lattice-boxing constants is assumed.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1000000

def commonWindowLength (R K : ℕ) (C : ℝ) : ℕ :=
  max 1 ((Finset.range (R+1)).sup (fun d => denseBoxSummandThreshold d (commonBoxBlockDensity d K C)))

def commonWindowWidthThreshold (R K : ℕ) (C : ℝ) : ℕ :=
  max 1 ((Finset.range (R+1)).sup (fun d => denseBoxWidthThreshold (commonBoxBlockDensity d K C)))

def commonWindowInverseScale (R K : ℕ) (C : ℝ) : ℕ :=
  max 1 ((Finset.range (R+1)).sup (fun d => ⌈(commonBoxFilledScale d K C (commonWindowLength R K C))⁻¹⌉₊))

def commonWindowScale (R K : ℕ) (C : ℝ) : ℝ := (commonWindowInverseScale R K C : ℝ)⁻¹

theorem common_window_parameters (R K : ℕ) (hK : 1 ≤ K) (C : ℝ) (hC : 0 < C) :
    0 < commonWindowLength R K C ∧ 0 < commonWindowScale R K C ∧
    ∀ d : ℕ, 0 < d → d ≤ R →
      denseBoxSummandThreshold d (commonBoxBlockDensity d K C) ≤ commonWindowLength R K C ∧
      denseBoxWidthThreshold (commonBoxBlockDensity d K C) ≤ commonWindowWidthThreshold R K C ∧
      commonWindowScale R K C ≤ commonBoxFilledScale d K C (commonWindowLength R K C) := by
  have hL : 0 < commonWindowLength R K C := lt_of_lt_of_le Nat.zero_lt_one (le_max_left _ _)
  have hi : 0 < commonWindowInverseScale R K C := lt_of_lt_of_le Nat.zero_lt_one (le_max_left _ _)
  refine ⟨hL, by unfold commonWindowScale; positivity, ?_⟩
  intro d hd hdR
  have hm : d ∈ Finset.range (R+1) := Finset.mem_range.mpr (by omega)
  have hlength : denseBoxSummandThreshold d (commonBoxBlockDensity d K C) ≤ commonWindowLength R K C :=
    (Finset.le_sup (f := fun d => denseBoxSummandThreshold d (commonBoxBlockDensity d K C)) hm).trans (le_max_right _ _)
  have hwidth : denseBoxWidthThreshold (commonBoxBlockDensity d K C) ≤ commonWindowWidthThreshold R K C :=
    (Finset.le_sup (f := fun d => denseBoxWidthThreshold (commonBoxBlockDensity d K C)) hm).trans (le_max_right _ _)
  have hceil : ⌈(commonBoxFilledScale d K C (commonWindowLength R K C))⁻¹⌉₊ ≤ commonWindowInverseScale R K C :=
    (Finset.le_sup (f := fun d => ⌈(commonBoxFilledScale d K C (commonWindowLength R K C))⁻¹⌉₊) hm).trans (le_max_right _ _)
  have hc := commonBoxFilledScale_pos hd K hK C hC _ hL
  have hbound := (Nat.le_ceil ((commonBoxFilledScale d K C (commonWindowLength R K C))⁻¹)).trans
    (Nat.cast_le.mpr hceil)
  refine ⟨hlength, hwidth, ?_⟩
  exact (inv_le_comm₀ (by exact_mod_cast hi) hc).mpr hbound

/-- The same coordinate model remains valid on any smaller filling dilation. -/
def CommonReserveCoordinateModel.shrink {ι : Type} [DecidableEq ι] {d : ℕ}
    {scalar : ι → ℤ} {available reserve remainder : Finset ι} {h extra : ℕ} {c : ℝ}
    (model : CommonReserveCoordinateModel d scalar available reserve remainder h extra c)
    (c' : ℝ) (hc : c' ≤ c) :
    CommonReserveCoordinateModel d scalar available reserve remainder h extra c' :=
  { model with
    proper := fun x y hx hy he => model.proper x y
      (fun j => (hx j).trans (mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right hc (Nat.cast_nonneg h)) (Nat.cast_nonneg _)))
      (fun j => (hy j).trans (mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right hc (Nat.cast_nonneg h)) (Nat.cast_nonneg _))) he
    filled := by
      obtain ⟨t, ht⟩ := model.filled
      exact ⟨t, fun z hz => ht z (fun j => (hz j).trans (mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right hc (Nat.cast_nonneg h)) (Nat.cast_nonneg _)))⟩ }

end
end Optss
