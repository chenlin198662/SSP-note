import Optss.FreimanLowRankConcentration
import Optss.HyperplaneCounting

/-!
# Bounding the wide coordinates of a dense small-doubling box subset

The generalized concentration theorem produces a large low-dimensional
affine slice. If an axis is not parallel to that slice, deleting that
coordinate is injective on its integer points. This yields the precise
box-counting step of Bilu Proposition 5.7, without assuming generic position.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 1000000
local instance freimanBoxWidthsDecEqRealVec (n : ℕ) : DecidableEq (Fin n → ℝ) := Classical.decEq _
variable {d : ℕ}

theorem exists_axis_outside_of_card_gt_finrank (I : Finset (Fin d))
    (L : Submodule ℝ (Fin d → ℝ)) (hI : Module.finrank ℝ L < I.card) :
    ∃ j ∈ I, Pi.single j (1:ℝ) ∉ L := by
  by_contra h
  push_neg at h
  let v : I → (Fin d → ℝ) := fun j => Pi.single (j:Fin d) 1
  have hv : LinearIndependent ℝ v := by
    simpa only [Function.comp_def, Pi.basisFun_apply] using
      (Pi.basisFun ℝ (Fin d)).linearIndependent.comp (fun j : I => (j:Fin d)) Subtype.val_injective
  have hle : Submodule.span ℝ (Set.range v) ≤ L := by
    apply Submodule.span_le.mpr
    rintro x ⟨j, rfl⟩
    exact h j j.property
  have hh := Submodule.finrank_mono hle
  rw [finrank_span_eq_card hv, Fintype.card_coe] at hh
  omega

/-- Affine translates retain coordinate deletion injectivity. -/
theorem omitCoordinate_injOn_affine (L : Submodule ℝ (Fin d → ℝ))
    (a : Fin d → ℝ) (j : Fin d) (hj : Pi.single j (1:ℝ) ∉ L) :
    Set.InjOn (omitCoordinate j) {x : IntVec d | realVector x-a ∈ L} := by
  intro x hx y hy he
  have hreal := subspace_coordinate_projection_injective L j hj hx hy (fun i hi => by
    have hh := congrFun he ⟨i, hi⟩
    change x i = y i at hh
    change (x i:ℝ)-a i = (y i:ℝ)-a i
    rw [hh])
  have hxy : realVector x = realVector y := sub_left_injective hreal
  funext i
  exact Int.cast_injective (congrFun hxy i)

/-- An affine slice loses the complete interval in any missing axis. -/
theorem integer_affine_card_mul_width_le (L : Submodule ℝ (Fin d → ℝ))
    (a : Fin d → ℝ) (j : Fin d) (hj : Pi.single j (1:ℝ) ∉ L)
    (w : Fin d → ℕ) (T : Finset (IntVec d))
    (hbox : ∀ x ∈ T, InCenteredBox w x) (hplane : ∀ x ∈ T, realVector x-a ∈ L) :
    T.card*(2*w j+1) ≤ ∏ i, (2*w i+1) := by
  have hinj : Set.InjOn (omitCoordinate j) (T : Set (IntVec d)) :=
    (omitCoordinate_injOn_affine L a j hj).mono hplane
  have hmem : T.image (omitCoordinate j) ⊆ omittedIntegerBox w j := by
    intro y hy
    obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hy
    rw [omittedIntegerBox, Fintype.mem_piFinset]
    intro i
    exact Finset.mem_Icc.mpr (abs_le.mp (hbox x hx i))
  have hh := Finset.card_le_card hmem
  rw [Finset.card_image_of_injOn hinj, card_omittedIntegerBox] at hh
  exact (Nat.mul_le_mul_right (2*w j+1) hh).trans_eq (omitted_product_mul_width w j)

/-- A large low-rank affine slice implies that only its rank many
coordinates can exceed the density-adjusted width bound. -/
theorem wide_coordinates_le_affine_rank (S T : Finset (IntVec d))
    (w : Fin d → ℕ) (δ α : ℝ) (hS : S.Nonempty) (hδ : 0 < δ)
    (hTS : T ⊆ S) (hbox : ∀ x ∈ S, InCenteredBox w x)
    (hmass : δ*S.card ≤ T.card) (hvol : (∏ j, (2*w j+1):ℕ) ≤ α*S.card)
    (a : Fin d → ℝ) (L : Submodule ℝ (Fin d → ℝ))
    (hplane : ∀ x ∈ T, realVector x-a ∈ L) :
    (Finset.univ.filter (fun j => α/δ < (2*w j+1:ℕ))).card ≤ Module.finrank ℝ L := by
  by_contra hbad
  obtain ⟨j, hj, hjL⟩ := exists_axis_outside_of_card_gt_finrank
    (Finset.univ.filter (fun j => α/δ < (2*w j+1:ℕ))) L (lt_of_not_ge hbad)
  have hjwidth := (Finset.mem_filter.mp hj).2
  have hcount := integer_affine_card_mul_width_le L a j hjL w T (fun x hx => hbox x (hTS hx)) hplane
  have hc : (T.card:ℝ)*(2*w j+1:ℕ) ≤ (∏ i, (2*w i+1):ℕ) := by exact_mod_cast hcount
  have hwidth : α < (2*w j+1:ℕ)*δ := (div_lt_iff₀ hδ).mp hjwidth
  have hSc : (0:ℝ) < S.card := by exact_mod_cast hS.card_pos
  have hmul := mul_le_mul_of_nonneg_right hmass (show (0:ℝ) ≤ (2*w j+1:ℕ) by positivity)
  nlinarith

/-- Uniform width bound from actual doubling and density. The same `δ`
works for every ambient box dimension. -/
theorem freiman_box_wide_coordinate_bound (r : ℕ) (hr : 0 < r) (ε : ℝ) (hε : 0 < ε) :
    ∃ δ : ℝ, 0 < δ ∧ ∀ (d : ℕ) (w : Fin d → ℕ) (S : Finset (IntVec d)) (α : ℝ),
      S.Nonempty → (∀ x ∈ S, InCenteredBox w x) →
      (∏ j, (2*w j+1):ℕ) ≤ α*S.card →
      ((S+S).card:ℝ) < ((2:ℝ)^r-ε)*S.card →
      (Finset.univ.filter (fun j => α/δ < (2*w j+1:ℕ))).card ≤ r-1 := by
  obtain ⟨δ, hδ, hconc⟩ := freiman_low_rank_concentration_uniform r hr ε hε
  refine ⟨δ, hδ, ?_⟩
  intro d w S α hS hbox hvol hdoub
  have hcast : Function.Injective (realVector (d := d)) := by
    intro x y h
    funext j
    exact Int.cast_injective (congrFun h j)
  let U := S.image realVector
  have hUcard : U.card = S.card := Finset.card_image_of_injective _ hcast
  have hUU : (U+U).card = (S+S).card := by
    rw [show U+U = (S+S).image realVector from (Finset.image_add realVector).symm,
      Finset.card_image_of_injective _ hcast]
  have hUdoub : ((U+U).card:ℝ) < ((2:ℝ)^r-ε)*U.card := by
    simpa only [hUU, hUcard] using hdoub
  obtain ⟨V, hVU, hVmass, hVdim⟩ := hconc d U (hS.image realVector) hUdoub
  let T := S.filter (fun x => realVector x ∈ V)
  have hTS : T ⊆ S := Finset.filter_subset _ _
  have hTimage : T.image realVector = V := by
    ext y
    constructor
    · intro hy
      obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hy
      exact (Finset.mem_filter.mp hx).2
    · intro hy
      obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp (hVU hy)
      exact Finset.mem_image.mpr ⟨x, Finset.mem_filter.mpr ⟨hx, hy⟩, rfl⟩
  have hTV : T.card = V.card := by
    rw [← hTimage, Finset.card_image_of_injective _ hcast]
  have hmass : δ*S.card ≤ T.card := by simpa only [hUcard, hTV] using hVmass
  have hVne : V.Nonempty := by
    have hh : (0:ℝ) < V.card := (mul_pos hδ (by exact_mod_cast (hS.image realVector).card_pos)).trans_le hVmass
    exact Finset.card_pos.mp (by exact_mod_cast hh)
  obtain ⟨a, ha⟩ := hVne
  let L := Submodule.span ℝ ((V-V : Finset (Fin d → ℝ)) : Set (Fin d → ℝ))
  have hplane : ∀ x ∈ T, realVector x-a ∈ L := by
    intro x hx
    exact Submodule.subset_span (Finset.sub_mem_sub (Finset.mem_filter.mp hx).2 ha)
  exact (wide_coordinates_le_affine_rank S T w δ α hS hδ hTS hbox hmass hvol a L hplane).trans hVdim

/-- In particular, a uniformly wide dense box must have the refined rank.
The constant is independent of the original containing progression's rank. -/
theorem freiman_dense_wide_box_rank (r : ℕ) (hr : 0 < r) (ε : ℝ) (hε : 0 < ε) :
    ∃ δ : ℝ, 0 < δ ∧ ∀ (d : ℕ) (w : Fin d → ℕ) (S : Finset (IntVec d)) (α : ℝ),
      S.Nonempty → (∀ x ∈ S, InCenteredBox w x) →
      (∏ j, (2*w j+1):ℕ) ≤ α*S.card →
      ((S+S).card:ℝ) < ((2:ℝ)^r-ε)*S.card →
      (∀ j, α/δ < (2*w j+1:ℕ)) → d ≤ r-1 := by
  obtain ⟨δ, hδ, hc⟩ := freiman_box_wide_coordinate_bound r hr ε hε
  refine ⟨δ, hδ, ?_⟩
  intro d w S α hS hbox hvol hdoub hwide
  have hh := hc d w S α hS hbox hvol hdoub
  simpa only [Finset.filter_true_of_mem (fun j _ => hwide j), Finset.card_univ, Fintype.card_fin] using hh

end
end Optss
