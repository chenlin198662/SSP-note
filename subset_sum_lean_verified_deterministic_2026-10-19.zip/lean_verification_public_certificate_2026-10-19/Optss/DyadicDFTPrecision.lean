import Optss.DyadicBluestein

/-! A concrete logarithmic precision choice for the integer Bluestein DFT.
All error terms include the actual chirp rounding and all three transforms. -/
namespace Optss

theorem real_nat_add_one_le_two_pow (n : ℕ) : (n : ℝ)+1≤2^n := by
  induction n with
  | zero => norm_num
  | succ n ih =>
    rw [pow_succ]
    push_cast
    have hn : (0 : ℝ)≤n := by positivity
    nlinarith

theorem radix_error_factor_le (n : ℕ) : (n : ℝ)*3^n≤8^n := by
  have hn : (n : ℝ)≤2^n := by linarith [real_nat_add_one_le_two_pow n]
  have hp : (3 : ℝ)^n≤4^n := pow_le_pow_left₀ (by norm_num) (by norm_num) n
  calc
    _ ≤ (2 : ℝ)^n*4^n := mul_le_mul hn hp (by positivity) (by positivity)
    _ = _ := by rw [← mul_pow]; norm_num

theorem dyadicConvolutionError_bound (n p : ℕ)
    (hE : (n : ℝ)*3^n*(1/2 : ℝ)^p≤1) :
    dyadicConvolutionError n p≤28*((n : ℝ)*3^n*(1/2 : ℝ)^p)*(2^n : ℕ) := by
  let E : ℝ := (n : ℝ)*3^n*(1/2 : ℝ)^p
  let M : ℝ := (2^n : ℕ)
  have hE₀ : 0≤E := by dsimp [E]; positivity
  have hM : 1≤M := by dsimp [M]; exact_mod_cast (one_le_pow₀ (by decide : 1≤(2 : ℕ)))
  have hM₀ : 0<M := by linarith
  have he₁ : 2*M+E≤3*M := by dsimp [E] at hE₀ ⊢; dsimp [M] at hM; linarith
  have he₂ : (M+E)^2≤4*M^2 := by
    have hh : M+E≤2*M := by dsimp [E]; linarith
    nlinarith [sq_nonneg (M+E),mul_self_le_mul_self (by positivity : 0≤M+E) hh]
  change E*(2*M+E)*4+(E/M)*(M+E)^2*4≤28*E*M
  calc
    _ ≤ E*(3*M)*4+(E/M)*(4*M^2)*4 := by gcongr
    _ = _ := by field_simp; ring

theorem dyadicBluesteinError_bound (n p : ℕ)
    (hE : (n : ℝ)*3^n*(1/2 : ℝ)^p≤1) :
    2*dyadicConvolutionError n p+7*(2^n : ℕ)*(1/2 : ℝ)^p≤
      64*(16 : ℝ)^n*(1/2 : ℝ)^p := by
  have hconv := dyadicConvolutionError_bound n p hE
  have hfactor := radix_error_factor_le n
  have htwo : (2 : ℝ)^n≤16^n := pow_le_pow_left₀ (by norm_num) (by norm_num) n
  have hmul : (8 : ℝ)^n*2^n=16^n := by rw [← mul_pow]; norm_num
  have hp : 0≤(1/2 : ℝ)^p := by positivity
  have he : ((n : ℝ)*3^n*(1/2 : ℝ)^p)*(2^n : ℕ)≤(16 : ℝ)^n*(1/2 : ℝ)^p := by
    push_cast
    calc
      _ ≤ ((8 : ℝ)^n*(1/2 : ℝ)^p)*2^n := by gcongr
      _ = _ := by rw [mul_right_comm,hmul]
  push_cast at hconv
  have ht := mul_le_mul_of_nonneg_right htwo hp
  have hnon : 0≤(16 : ℝ)^n*(1/2 : ℝ)^p := by positivity
  push_cast at he ⊢
  nlinarith

def dyadicDFTPrecision (n : ℕ) : ℕ := 5*n+12

theorem dyadicDFTPrecision_factor (n : ℕ) :
    (n : ℝ)*3^n*(1/2 : ℝ)^(dyadicDFTPrecision n)≤1 := by
  have hpow : (8 : ℝ)^n≤2^(dyadicDFTPrecision n) := by
    have he : (8 : ℝ)^n=2^(3*n) := by rw [pow_mul]; norm_num
    rw [he]
    exact pow_le_pow_right₀ (by norm_num) (by dsimp [dyadicDFTPrecision]; omega)
  rw [one_div_pow,mul_one_div]
  apply (div_le_one (by positivity)).mpr
  exact (radix_error_factor_le n).trans hpow

theorem dyadicDFTPrecision_error (n : ℕ) :
    2*dyadicConvolutionError n (dyadicDFTPrecision n)+
      7*(2^n : ℕ)*(1/2 : ℝ)^(dyadicDFTPrecision n)≤1/(64*(2^n : ℕ)) := by
  apply (dyadicBluesteinError_bound n _ (dyadicDFTPrecision_factor n)).trans
  apply le_of_eq
  unfold dyadicDFTPrecision
  push_cast
  rw [one_div_pow]
  have h16 : (16 : ℝ)^n=2^(4*n) := by rw [pow_mul]; norm_num
  rw [h16]
  have hp : (2 : ℝ)^(5*n+12)=2^(4*n)*2^n*4096 := by
    rw [show 5*n+12=4*n+n+12 by omega,pow_add,pow_add]
    norm_num
  rw [hp]
  field_simp
  ring

theorem canonicalDyadicDFT_certified (N : ℕ) [NeZero N] (f : Vector Bool N) (k : Fin N) :
    let n := bluesteinPadExponent N
    let p := dyadicDFTPrecision n
    ‖fourierIntegerValue ((canonicalDyadicDFT N p f).get k)/
      ((2^n : ℕ)*(dyadicFourierDenominator p : ℂ)^(3*n+3))-
      ZMod.dft (cyclicBooleanInput N f) (k.val : ZMod N)‖≤1/(64*(N : ℝ)) := by
  dsimp only
  apply (canonicalDyadicDFT_error N _ f k).trans
  apply (dyadicDFTPrecision_error (bluesteinPadExponent N)).trans
  have hN : 0<N := NeZero.pos N
  have hNM : N≤2^bluesteinPadExponent N := by have h := (bluesteinPadExponent_bounds N).1; omega
  apply one_div_le_one_div_of_le (by positivity)
  gcongr

end Optss
