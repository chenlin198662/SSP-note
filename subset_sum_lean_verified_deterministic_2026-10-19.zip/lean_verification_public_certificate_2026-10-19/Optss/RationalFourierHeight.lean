import Optss.RationalArithmeticBounds
import Optss.RationalCharacterApproximation
import Optss.FixedPointRadixBounds
import Optss.BinaryRationalCost

/-! Bounds on the actual rational character-preparation intermediates.
Every subset sum is covered, hence every accumulation prefix. Heights may
be exponentially large; their binary lengths have the explicit bounds below. -/
namespace Optss
open scoped BigOperators

theorem RationalSizeBound.pow {q : ℚ} {B : ℕ} (hq : RationalSizeBound q B) (n : ℕ) :
    RationalSizeBound (q^n) (B^n) := by
  simp only [RationalSizeBound,Rat.num_pow,Rat.den_pow,Int.natAbs_pow]
  exact ⟨Nat.pow_le_pow_left hq.1 n,Nat.pow_le_pow_left hq.2 n⟩

theorem RationalSizeBound.natCast (a B : ℕ) (hB : 0<B) (ha : a≤B) :
    RationalSizeBound (a : ℚ) B := by
  simpa only [Int.cast_natCast,Int.natAbs_natCast] using
    RationalSizeBound.intCast (a : ℤ) B hB ha

def arctanTermHeight (B n : ℕ) : ℕ := B^(4*n+1)*(4*n+1)
def arctanPartialHeight (B n : ℕ) : ℕ := (2*arctanTermHeight B n)^(2*n)
def fourierPiHeight (n : ℕ) : ℕ := 8*(arctanPartialHeight 3 n)^2
def fourierPhaseHeight (N p : ℕ) : ℕ := 2*fourierPiHeight (p+2)*N*N
def imaginaryTermHeight (B n : ℕ) : ℕ := B^n*n.factorial
def imaginaryPartialHeight (B n : ℕ) : ℕ := (2*imaginaryTermHeight B n)^n

theorem arctanTermHeight_pos (B n : ℕ) (hB : 0<B) : 0<arctanTermHeight B n := by
  unfold arctanTermHeight
  positivity

theorem rationalArctanTerm_height (x : ℚ) (B n i : ℕ)
    (hx : RationalSizeBound x B) (hi : i<2*n) :
    RationalSizeBound ((-1 : ℚ)^i*x^(2*i+1)/(2*i+1)) (arctanTermHeight B n) := by
  have hs : RationalSizeBound (-1 : ℚ) 1 := by norm_num [RationalSizeBound]
  have hp := (hs.pow i).mul (hx.pow (2*i+1))
  have hd := RationalSizeBound.natCast (2*i+1) (4*n+1) (by omega) (by omega)
  have h := hp.div hd
  simp only [one_pow,one_mul,Nat.cast_add,Nat.cast_mul,Nat.cast_ofNat,Nat.cast_one] at h
  exact h.mono (Nat.mul_le_mul_right _ (Nat.pow_le_pow_right hx.pos (by omega)))

theorem rationalArctanPartialSum_height (x : ℚ) (B n : ℕ) (hx : RationalSizeBound x B)
    (s : Finset ℕ) (hs : s⊆Finset.range (2*n)) :
    RationalSizeBound (∑ i∈s, (-1 : ℚ)^i*x^(2*i+1)/(2*i+1)) (arctanPartialHeight B n) := by
  have hb := arctanTermHeight_pos B n hx.pos
  have h := rational_sum_size s _ _ hb
    (fun i hi => rationalArctanTerm_height x B n i hx (Finset.mem_range.mp (hs hi)))
  exact h.mono (Nat.pow_le_pow_right (by omega) (by simpa only [Finset.card_range] using Finset.card_le_card hs))

theorem rationalPiApproximation_height (n : ℕ) :
    RationalSizeBound (rationalPiApproximation n) (fourierPiHeight n) := by
  have h₂ : RationalSizeBound (1/2 : ℚ) 3 := by norm_num [RationalSizeBound]
  have h₃ : RationalSizeBound (1/3 : ℚ) 3 := by norm_num [RationalSizeBound]
  have ha := rationalArctanPartialSum_height (1/2) 3 n h₂ (Finset.range (2*n)) (by rfl)
  have hb := rationalArctanPartialSum_height (1/3) 3 n h₃ (Finset.range (2*n)) (by rfl)
  have h4 : RationalSizeBound (4 : ℚ) 4 := by norm_num [RationalSizeBound]
  have h := h4.mul (ha.add hb)
  have he : 4*(2*arctanPartialHeight 3 n*arctanPartialHeight 3 n)=fourierPiHeight n := by
    unfold fourierPiHeight
    ring
  rw [he] at h
  exact h

theorem rationalPhaseAngle_height {N : ℕ} [NeZero N] (x : ZMod N) (p : ℕ) :
    RationalSizeBound (rationalPhaseAngle x p) (fourierPhaseHeight N p) := by
  have h2 : RationalSizeBound (2 : ℚ) 2 := by norm_num [RationalSizeBound]
  exact ((h2.mul (rationalPiApproximation_height (p+2))).mul
    (RationalSizeBound.natCast x.val N (NeZero.pos N) x.val_lt.le)).div
      (RationalSizeBound.natCast N N (NeZero.pos N) le_rfl)

theorem rationalImaginaryPower_height (t : ℚ) (B : ℕ) (ht : RationalSizeBound t B) (j : ℕ) :
    RationalSizeBound (rationalImaginaryPower t j).1 (B^j) ∧
      RationalSizeBound (rationalImaginaryPower t j).2 (B^j) := by
  induction j with
  | zero => norm_num [rationalImaginaryPower,RationalSizeBound]
  | succ j ih =>
    simpa only [rationalImaginaryPower,pow_succ'] using ⟨ht.neg.mul ih.2,ht.mul ih.1⟩

theorem rationalImaginaryTerm_height (t : ℚ) (B n j : ℕ) (ht : RationalSizeBound t B) (hj : j<n) :
    RationalSizeBound ((rationalImaginaryPower t j).1/j.factorial) (imaginaryTermHeight B n) ∧
      RationalSizeBound ((rationalImaginaryPower t j).2/j.factorial) (imaginaryTermHeight B n) := by
  have hp := rationalImaginaryPower_height t B ht j
  have hf := RationalSizeBound.natCast j.factorial n.factorial (Nat.factorial_pos n) (Nat.factorial_le hj.le)
  have hpow : B^j*n.factorial≤B^n*n.factorial := Nat.mul_le_mul_right _ (Nat.pow_le_pow_right ht.pos hj.le)
  exact ⟨(hp.1.div hf).mono hpow,(hp.2.div hf).mono hpow⟩

theorem rationalImaginaryPartialSum_height (t : ℚ) (B n : ℕ) (ht : RationalSizeBound t B)
    (s : Finset ℕ) (hs : s⊆Finset.range n) :
    RationalSizeBound (∑ j∈s, (rationalImaginaryPower t j).1/j.factorial) (imaginaryPartialHeight B n) ∧
      RationalSizeBound (∑ j∈s, (rationalImaginaryPower t j).2/j.factorial) (imaginaryPartialHeight B n) := by
  have hb : 0 < imaginaryTermHeight B n := by unfold imaginaryTermHeight; have := ht.pos; positivity
  have hcard : s.card≤n := by simpa only [Finset.card_range] using Finset.card_le_card hs
  have hp : (2*imaginaryTermHeight B n)^s.card ≤ imaginaryPartialHeight B n :=
    Nat.pow_le_pow_right (by omega) hcard
  constructor
  · exact (rational_sum_size s _ _ hb (fun j hj =>
      (rationalImaginaryTerm_height t B n j ht (Finset.mem_range.mp (hs hj))).1)).mono hp
  · exact (rational_sum_size s _ _ hb (fun j hj =>
      (rationalImaginaryTerm_height t B n j ht (Finset.mem_range.mp (hs hj))).2)).mono hp

theorem rationalCharacterApproximation_height {N : ℕ} [NeZero N] (x : ZMod N) (p : ℕ) :
    RationalSizeBound (rationalCharacterApproximation x p).1
      (imaginaryPartialHeight (fourierPhaseHeight N p) (68+p)) ∧
    RationalSizeBound (rationalCharacterApproximation x p).2
      (imaginaryPartialHeight (fourierPhaseHeight N p) (68+p)) :=
  rationalImaginaryPartialSum_height _ _ _ (rationalPhaseAngle_height x p) _ (by rfl)

theorem arctanTermHeight_bits (B n : ℕ) :
    (arctanTermHeight B n).size≤(4*n+1)*B.size+1+(4*n+1).size := by
  exact (nat_mul_size_le _ _).trans (Nat.add_le_add_right (nat_power_size_le _ _) _)

theorem arctanPartialHeight_bits (B n : ℕ) :
    (arctanPartialHeight B n).size≤2*n*((4*n+1)*B.size+(4*n+1).size+3)+1 := by
  have hterm := arctanTermHeight_bits B n
  have htwo : (2 : ℕ).size≤2 := Nat.size_le.mpr (by decide)
  have hb := nat_mul_size_le 2 (arctanTermHeight B n)
  have hbase : (2*arctanTermHeight B n).size≤(4*n+1)*B.size+(4*n+1).size+3 := by omega
  exact (nat_power_size_le _ _).trans (Nat.add_le_add_right (Nat.mul_le_mul_left _ hbase) _)

theorem fourierPiHeight_bits (n : ℕ) :
    (fourierPiHeight n).size≤4*n*((4*n+1)*2+(4*n+1).size+3)+7 := by
  have hh := arctanPartialHeight_bits 3 n
  have hthree : (3 : ℕ).size≤2 := Nat.size_le.mpr (by decide)
  have height : (arctanPartialHeight 3 n).size≤2*n*((4*n+1)*2+(4*n+1).size+3)+1 :=
    hh.trans (by gcongr)
  have h8 : (8 : ℕ).size≤4 := Nat.size_le.mpr (by decide)
  have hp := nat_power_size_le (arctanPartialHeight 3 n) 2
  have hm := nat_mul_size_le 8 ((arctanPartialHeight 3 n)^2)
  unfold fourierPiHeight
  nlinarith

theorem fourierPhaseHeight_bits (N p : ℕ) :
    (fourierPhaseHeight N p).size≤
      4*(p+2)*((4*(p+2)+1)*2+(4*(p+2)+1).size+3)+9+2*N.size := by
  have hpi := fourierPiHeight_bits (p+2)
  have htwo : (2 : ℕ).size≤2 := Nat.size_le.mpr (by decide)
  have h₁ := nat_mul_size_le 2 (fourierPiHeight (p+2))
  have h₂ := nat_mul_size_le (2*fourierPiHeight (p+2)) N
  have h₃ := nat_mul_size_le (2*fourierPiHeight (p+2)*N) N
  unfold fourierPhaseHeight
  omega

theorem imaginaryPartialHeight_bits (B n : ℕ) :
    (imaginaryPartialHeight B n).size≤n*(n*(B.size+n.size)+4)+1 := by
  have hfactorial : n.factorial.size≤n*n.size+1 :=
    (Nat.size_le_size (Nat.factorial_le_pow n)).trans (nat_power_size_le n n)
  have hpower := nat_power_size_le B n
  have hterm := nat_mul_size_le (B^n) n.factorial
  have htwo : (2 : ℕ).size≤2 := Nat.size_le.mpr (by decide)
  have hbase := nat_mul_size_le 2 (imaginaryTermHeight B n)
  have hb : (2*imaginaryTermHeight B n).size≤n*(B.size+n.size)+4 := by
    unfold imaginaryTermHeight at hbase ⊢
    nlinarith
  exact (nat_power_size_le _ _).trans (Nat.add_le_add_right (Nat.mul_le_mul_left n hb) 1)

theorem nat_size_le_value (n : ℕ) : n.size≤n := Nat.size_le.mpr n.lt_two_pow_self

theorem fourierPiHeight_bits_polynomial (n : ℕ) :
    (fourierPiHeight n).size≤64*(n+1)^2 := by
  have h := fourierPiHeight_bits n
  have hs := nat_size_le_value (4*n+1)
  have hm := Nat.mul_le_mul_left (4*n) hs
  nlinarith

def fourierPreparationBits (N p : ℕ) : ℕ := 128*(N.size+p+70)^4

theorem fourierPhaseHeight_bits_polynomial (N p : ℕ) :
    (fourierPhaseHeight N p).size≤68*(N.size+p+70)^2 := by
  have hpi := fourierPiHeight_bits_polynomial (p+2)
  have htwo : (2 : ℕ).size≤2 := Nat.size_le.mpr (by decide)
  have h₁ := nat_mul_size_le 2 (fourierPiHeight (p+2))
  have h₂ := nat_mul_size_le (2*fourierPiHeight (p+2)) N
  have h₃ := nat_mul_size_le (2*fourierPiHeight (p+2)*N) N
  have hs : (fourierPhaseHeight N p).size≤64*(p+3)^2+2+2*N.size := by
    unfold fourierPhaseHeight
    nlinarith
  apply hs.trans
  have h₄ : (p+3)^2≤(N.size+p+70)^2 := Nat.pow_le_pow_left (by omega) 2
  have h₅ : N.size≤N.size+p+70 := by omega
  have h₆ : 1≤N.size+p+70 := by omega
  have h₇ : N.size+p+70≤(N.size+p+70)^2 := by nlinarith
  nlinarith

theorem characterPartialHeight_bits_polynomial (N p : ℕ) :
    (imaginaryPartialHeight (fourierPhaseHeight N p) (68+p)).size≤fourierPreparationBits N p := by
  let L := N.size+p+70
  have hL : 1≤L := by dsimp [L]; omega
  have hK : 68+p≤L := by dsimp [L]; omega
  have hs : (68+p).size≤L := (nat_size_le_value _).trans hK
  have hb := fourierPhaseHeight_bits_polynomial N p
  have hh := imaginaryPartialHeight_bits (fourierPhaseHeight N p) (68+p)
  change (fourierPhaseHeight N p).size≤68*L^2 at hb
  change _≤128*L^4
  calc
    _ ≤ (68+p)*((68+p)*((fourierPhaseHeight N p).size+(68+p).size)+4)+1 := hh
    _ ≤ L*(L*(68*L^2+L)+4)+1 := by gcongr
    _ ≤ 128*L^4 := by
      have h₁ : L≤L^4 := by simpa only [pow_one] using Nat.pow_le_pow_right hL (by decide : 1≤4)
      have h₂ : L^3≤L^4 := Nat.pow_le_pow_right hL (by decide)
      have h₃ : 1≤L^4 := one_le_pow₀ hL
      nlinarith

theorem RationalSizeBound.bitBound {q : ℚ} {B : ℕ} (h : RationalSizeBound q B) :
    RationalBitBound q B.size := ⟨Nat.size_le_size h.1,Nat.size_le_size h.2⟩

theorem rationalCharacterApproximation_bits {N : ℕ} [NeZero N] (x : ZMod N) (p : ℕ) :
    RationalBitBound (rationalCharacterApproximation x p).1 (fourierPreparationBits N p) ∧
      RationalBitBound (rationalCharacterApproximation x p).2 (fourierPreparationBits N p) := by
  have h := rationalCharacterApproximation_height x p
  have hb := characterPartialHeight_bits_polynomial N p
  exact ⟨⟨h.1.bitBound.1.trans hb,h.1.bitBound.2.trans hb⟩,
    ⟨h.2.bitBound.1.trans hb,h.2.bitBound.2.trans hb⟩⟩

/-- The same polynomial bound holds at every summation prefix, not merely
at the final rounded character value. -/
theorem rationalCharacterPartialSum_bits {N : ℕ} [NeZero N] (x : ZMod N) (p : ℕ)
    (s : Finset ℕ) (hs : s⊆Finset.range (68+p)) :
    RationalBitBound (∑ j∈s, (rationalImaginaryPower (rationalPhaseAngle x p) j).1/j.factorial)
      (fourierPreparationBits N p) ∧
    RationalBitBound (∑ j∈s, (rationalImaginaryPower (rationalPhaseAngle x p) j).2/j.factorial)
      (fourierPreparationBits N p) := by
  have h := rationalImaginaryPartialSum_height _ _ _ (rationalPhaseAngle_height x p) s hs
  have hb := characterPartialHeight_bits_polynomial N p
  exact ⟨⟨h.1.bitBound.1.trans hb,h.1.bitBound.2.trans hb⟩,
    ⟨h.2.bitBound.1.trans hb,h.2.bitBound.2.trans hb⟩⟩

end Optss
