import Optss.ComputedBasisWidths

/-!
# Explicit Boolean vertex-address tuple enumeration

Candidate tuples store vertex addresses as actual Boolean words. Every new
head is built by the bounded-index Boolean encoder and every reused tail is
physically copied. Enumeration includes repetitions and has exactly `m^r`
candidates, matching the proved rational maximum-determinant search.
-/
namespace Optss
open scoped BigOperators

abbrev BitVertexTuple (r : ℕ) := BooleanListArray (List Bool) r

theorem booleanListArray_eq_of_data {α : Type*} {n : ℕ} (a b : BooleanListArray α n)
    (h : a.data=b.data) : a=b := by
  cases a; cases b; cases h; rfl

def encodeVertexTuple {m r : ℕ} (t : Fin r → Fin m) : BitVertexTuple r :=
  BooleanListArray.ofFn (fun j => bitUnaryAddress (t j).val)

def bitVertexTupleCons {m r : ℕ} (i : Fin m) (t : BitVertexTuple r) : BitVertexTuple (r+1) :=
  let tail := t.copy bitWordCopy
  ⟨bitUnaryAddress i.val::tail.data,by simp [tail.length_eq]⟩

theorem encodeVertexTuple_cons {m r : ℕ} (i : Fin m) (t : Fin r → Fin m) :
    bitVertexTupleCons i (encodeVertexTuple t)=encodeVertexTuple (Fin.cons i t) := by
  apply booleanListArray_eq_of_data
  simp only [bitVertexTupleCons,BooleanListArray.copy_eq bitWordCopy bitWordCopy_eq,
    encodeVertexTuple,BooleanListArray.ofFn]
  rw [List.ofFn_succ]
  rfl

def bitVertexTuples (m : ℕ) : (r : ℕ) → List (BitVertexTuple r)
  | 0 => [⟨[],rfl⟩]
  | r+1 => (List.finRange m).flatMap fun i =>
      (bitVertexTuples m r).map (bitVertexTupleCons i)

theorem bitVertexTuples_eq (m r : ℕ) :
    bitVertexTuples m r=(vertexIndexTuples m r).map encodeVertexTuple := by
  induction r with
  | zero => simp [bitVertexTuples,vertexIndexTuples,encodeVertexTuple,BooleanListArray.ofFn]
  | succ r ih =>
    simp only [bitVertexTuples,vertexIndexTuples,List.map_flatMap,List.map_map,ih,Function.comp_def]
    congr 1
    funext i
    apply List.map_congr_left
    intro t _
    exact encodeVertexTuple_cons i t

theorem bitVertexTuples_length (m r : ℕ) : (bitVertexTuples m r).length=m^r := by
  rw [bitVertexTuples_eq,List.length_map,vertexIndexTuples_length]

theorem encodeVertexTuple_get {m r : ℕ} (t : Fin r → Fin m) (j : Fin r) :
    (encodeVertexTuple t).toVector.get j=bitUnaryAddress (t j).val := by
  simp [encodeVertexTuple,BooleanListArray.ofFn_toVector,Vector.get]

theorem bitVertexTuples_members {m r : ℕ} {t : BitVertexTuple r} (ht : t∈bitVertexTuples m r) :
    ∃ u : Fin r → Fin m,t=encodeVertexTuple u := by
  rw [bitVertexTuples_eq] at ht
  obtain ⟨u,_,hu⟩ := List.mem_map.mp ht
  exact ⟨u,hu.symm⟩

theorem bitVertexTuples_word_length {m r : ℕ} {t : BitVertexTuple r}
    (ht : t∈bitVertexTuples m r) : ∀ w∈t.data,w.length≤m := by
  obtain ⟨u,rfl⟩ := bitVertexTuples_members ht
  apply ((encodeVertexTuple u).forall_data_iff (fun w => w.length≤m)).mpr
  intro j
  rw [encodeVertexTuple_get]
  exact (bitUnaryAddress_length _).trans (u j).isLt

def bitVertexTupleConsWork {m r : ℕ} (i : Fin m) (t : BitVertexTuple r) : ℕ :=
  bitUnaryAddressWork i.val+t.copyWork bitWordCopyWork+4

def vertexTupleConsBound (r m : ℕ) : ℕ := 16*(m+1)^2+r*(2*m+3)+5

theorem bitVertexTupleConsWork_bound {m r : ℕ} (i : Fin m) (t : BitVertexTuple r)
    (ht : ∀ w∈t.data,w.length≤m) :
    bitVertexTupleConsWork i t≤vertexTupleConsBound r m := by
  have ha := bitUnaryAddressWork_le i.val
  have hc := t.copyWork_le bitWordCopyWork (2*m+1) (by
    intro w hw; rw [bitWordCopyWork_eq]; have h := ht w hw; omega)
  have hp := Nat.pow_le_pow_left (show i.val+1≤m+1 by omega) 2
  unfold bitVertexTupleConsWork vertexTupleConsBound
  nlinarith

/-- Exact trace of index enumeration, recursive enumeration, physical tuple
copying, map/flatMap traversal, and list/tuple constructors. -/
def bitVertexTuplesWork (m : ℕ) : ℕ → ℕ
  | 0 => 3
  | r+1 => listIndexEnumerationWork m+
      ((List.finRange m).map fun i =>
        bitVertexTuplesWork m r+
        ((bitVertexTuples m r).map fun t => bitVertexTupleConsWork i t+4).sum+
        2*(bitVertexTuples m r).length+3).sum+1

def vertexTupleEnumerationBound (m : ℕ) : ℕ → ℕ
  | 0 => 3
  | r+1 => 32*(m+1)^3+
      m*(vertexTupleEnumerationBound m r+m^r*(vertexTupleConsBound r m+6)+3)+1

theorem bitVertexTuplesWork_bound (m r : ℕ) :
    bitVertexTuplesWork m r≤vertexTupleEnumerationBound m r := by
  induction r with
  | zero => rfl
  | succ r ih =>
    have hterms (i : Fin m) :
        ((bitVertexTuples m r).map fun t => bitVertexTupleConsWork i t+4).sum≤
          m^r*(vertexTupleConsBound r m+4) := by
      have h := List.sum_le_card_nsmul ((bitVertexTuples m r).map fun t => bitVertexTupleConsWork i t+4)
        (vertexTupleConsBound r m+4) (by
          intro z hz
          obtain ⟨t,ht,rfl⟩ := List.mem_map.mp hz
          exact Nat.add_le_add_right (bitVertexTupleConsWork_bound i t (bitVertexTuples_word_length ht)) 4)
      simpa only [List.length_map,bitVertexTuples_length,nsmul_eq_mul] using h
    have hs : ((List.finRange m).map fun i =>
        bitVertexTuplesWork m r+
        ((bitVertexTuples m r).map fun t => bitVertexTupleConsWork i t+4).sum+
        2*(bitVertexTuples m r).length+3).sum≤
      m*(vertexTupleEnumerationBound m r+m^r*(vertexTupleConsBound r m+6)+3) := by
      have h := List.sum_le_card_nsmul ((List.finRange m).map fun i =>
        bitVertexTuplesWork m r+
        ((bitVertexTuples m r).map fun t => bitVertexTupleConsWork i t+4).sum+
        2*(bitVertexTuples m r).length+3)
        (vertexTupleEnumerationBound m r+m^r*(vertexTupleConsBound r m+6)+3) (by
          intro z hz
          obtain ⟨i,_,rfl⟩ := List.mem_map.mp hz
          have ht := hterms i
          rw [bitVertexTuples_length]
          nlinarith)
      simpa only [List.length_map,List.length_finRange,nsmul_eq_mul] using h
    have he := listIndexEnumerationWork_le m
    exact Nat.add_le_add_right (Nat.add_le_add he hs) 1

/-- For each fixed rank the address enumeration is a literal polynomial in
vertex count, including all Boolean address copying and construction. -/
noncomputable def vertexTupleEnumerationPolynomial : ℕ → Polynomial ℕ
  | 0 => 3
  | r+1 => 32*(Polynomial.X+1)^3+
      Polynomial.X*(vertexTupleEnumerationPolynomial r+Polynomial.X^r*
        (16*(Polynomial.X+1)^2+Polynomial.C r*(2*Polynomial.X+3)+11)+3)+1

theorem vertexTupleEnumerationPolynomial_eval (m r : ℕ) :
    (vertexTupleEnumerationPolynomial r).eval m=vertexTupleEnumerationBound m r := by
  induction r with
  | zero => simp [vertexTupleEnumerationPolynomial,vertexTupleEnumerationBound]
  | succ r ih =>
    simp only [vertexTupleEnumerationPolynomial,Polynomial.eval_add,Polynomial.eval_mul,
      Polynomial.eval_pow,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat,Polynomial.eval_C,ih,
      vertexTupleEnumerationBound,vertexTupleConsBound]
    ring
end Optss
