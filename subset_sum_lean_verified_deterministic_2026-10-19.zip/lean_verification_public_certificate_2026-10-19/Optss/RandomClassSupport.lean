import Optss.ClippedConvolution
import Optss.ColorProbability

/-!
# Simultaneous retention when combining random size classes

Witnesses are fixed before sampling. Required absolute-budget witnesses survive
all intermediate clipping when each of their class selections occurs. A finite
union bound over targets and classes gives simultaneous completeness; it does
not require independence of the class-failure events. The local one-class
probability bound is a separate input supplied by the color-coding construction.
-/

namespace Optss
open scoped BigOperators Pointwise Classical
noncomputable section
variable {ι Ω : Type*} [Fintype ι] [Fintype Ω] {d g : ℕ}

/-- Class supports combined in a fixed order, clipping after each merge. -/
def randomClassSupport (Δ : Fin d →₀ ℕ)
    (supports : Fin g → Ω → Finset (IntVec d)) (sample : Ω) : Finset (IntVec d) :=
  clippedConvolution {t | InBox (fun j => (Δ j : ℤ)) t}
    (List.ofFn (fun p => supports p sample))

omit [Fintype Ω] in
/-- Local actual-copy witnesses imply soundness after every class merge. -/
theorem randomClassSupport_sound (v : ι → IntVec d) (part : ι → Fin g)
    (Δ : Fin d →₀ ℕ) (supports : Fin g → Ω → Finset (IntVec d))
    (hsound : ∀ p sample t, t ∈ supports p sample →
      ∃ s : Finset ι, s ⊆ Finset.univ.filter (fun i => part i = p) ∧ (∑ i ∈ s, v i) = t)
    (sample : Ω) {t : IntVec d} (ht : t ∈ randomClassSupport Δ supports sample) :
    t ∈ subsetSums v ∧ InBox (fun j => (Δ j : ℤ)) t := by
  have hb : InBox (fun j => (Δ j : ℤ)) t := by
    apply clippedConvolutionFrom_mem_box _ {0} ?_ _ t ht
    intro z hz
    have hz0 : z = 0 := Finset.mem_singleton.mp hz
    subst z
    intro j
    simp
  have hsum := clippedConvolution_subset_sum
    {t | InBox (fun j => (Δ j : ℤ)) t} (List.ofFn (fun p => supports p sample)) ht
  obtain ⟨chosen, hchosen⟩ := Finset.mem_sum_list_ofFn.mp hsum
  have hex (p : Fin g) := hsound p sample (chosen p) (chosen p).property
  choose s hs he using hex
  refine ⟨⟨Finset.univ.biUnion s, ?_⟩, hb⟩
  have hd : (Finset.univ : Finset (Fin g)).toSet.PairwiseDisjoint s := by
    intro p _ q _ hpq
    apply Finset.disjoint_left.mpr
    intro i hip hiq
    exact hpq ((Finset.mem_filter.mp (hs p hip)).2.symm.trans
      (Finset.mem_filter.mp (hs q hiq)).2)
  rw [Finset.sum_biUnion hd]
  simp only [he]
  exact List.sum_ofFn.symm.trans hchosen

omit [Fintype ι] [Fintype Ω] in
/-- The fixed witness survives precisely the deterministic condition needed in
the union-bound argument. Its partial class sums satisfy the clipping budgets. -/
theorem randomClassSupport_retains (v : ι → IntVec d) (part : ι → Fin g)
    (Δ : Fin d →₀ ℕ) (supports : Fin g → Ω → Finset (IntVec d)) (sample : Ω)
    (s : Finset ι) (hbudget : AbsoluteBudget v s (fun j => (Δ j : ℤ)))
    (hlocal : ∀ p, (∑ i ∈ s.filter (fun i => part i = p), v i) ∈ supports p sample) :
    (∑ i ∈ s, v i) ∈ randomClassSupport Δ supports sample := by
  have h := clippedPartitionConvolution_retains v part (fun j => (Δ j : ℤ)) s hbudget
    (fun p => supports p sample) (List.ofFn (fun p : Fin g => p))
    (List.nodup_ofFn.mpr Function.injective_id) (by
      intro p _
      convert hlocal p using 1
      congr 1
      ext i
      simp)
  simp only [List.map_ofFn, Function.comp_def, List.sum_ofFn] at h
  convert h using 1
  symm
  convert Finset.sum_fiberwise s part v using 1
  apply Finset.sum_congr rfl
  intro p _
  apply Finset.sum_congr
  · ext i
    simp
  · intro i _
    rfl

/-- Failure of a prescribed class selection to appear in its local support. -/
def classWitnessFailure (v : ι → IntVec d) (part : ι → Fin g)
    (supports : Fin g → Ω → Finset (IntVec d)) (s : Finset ι) (p : Fin g) : Finset Ω :=
  Finset.univ.filter (fun sample =>
    (∑ i ∈ s.filter (fun i => part i = p), v i) ∉ supports p sample)

/-- Actual failure to retain at least one of the fixed required target values. -/
def simultaneousClassFailure (Δ : Fin d →₀ ℕ)
    (supports : Fin g → Ω → Finset (IntVec d)) (T : Finset (IntVec d)) : Finset Ω :=
  Finset.univ.filter (fun sample => ∃ t ∈ T, t ∉ randomClassSupport Δ supports sample)

omit [Fintype ι] in
/-- Fix one witness for each required target before drawing any randomness.
Simultaneous failure is contained in the union of their local failure events. -/
theorem simultaneousClassFailure_subset (v : ι → IntVec d) (part : ι → Fin g)
    (Δ : Fin d →₀ ℕ) (supports : Fin g → Ω → Finset (IntVec d))
    (T : Finset (IntVec d)) (witness : {t // t ∈ T} → Finset ι)
    (hsum : ∀ t, (∑ i ∈ witness t, v i) = t.val)
    (hbudget : ∀ t, AbsoluteBudget v (witness t) (fun j => (Δ j : ℤ))) :
    simultaneousClassFailure Δ supports T ⊆ Finset.univ.biUnion
      (fun tp : {t // t ∈ T} × Fin g => classWitnessFailure v part supports (witness tp.1) tp.2) := by
  intro sample hsample
  obtain ⟨t, ht, hmiss⟩ := (Finset.mem_filter.mp hsample).2
  have hf : ∃ p, sample ∈ classWitnessFailure v part supports (witness ⟨t,ht⟩) p := by
    apply Classical.byContradiction
    intro hn
    push_neg at hn
    apply hmiss
    have ht' : (∑ i ∈ witness ⟨t,ht⟩, v i) = t := hsum ⟨t,ht⟩
    rw [← ht']
    apply randomClassSupport_retains v part Δ supports sample _ (hbudget ⟨t,ht⟩)
    intro p
    have hp := hn p
    simpa only [classWitnessFailure, Finset.mem_filter, Finset.mem_univ, true_and, not_not] using hp
  obtain ⟨p, hp⟩ := hf
  exact Finset.mem_biUnion.mpr ⟨(⟨t,ht⟩,p), Finset.mem_univ _, hp⟩

omit [Fintype ι] in
/-- The simultaneous union bound is over at most `card(T)*g` fixed
(target,class) pairs. It needs no independence assumption on these events. -/
theorem uniform_simultaneousClassFailure_le (v : ι → IntVec d) (part : ι → Fin g)
    (Δ : Fin d →₀ ℕ) (supports : Fin g → Ω → Finset (IntVec d))
    (T : Finset (IntVec d)) (witness : {t // t ∈ T} → Finset ι)
    (hsum : ∀ t, (∑ i ∈ witness t, v i) = t.val)
    (hbudget : ∀ t, AbsoluteBudget v (witness t) (fun j => (Δ j : ℤ)))
    (ε : ℝ) (hlocal : ∀ t p, uniformProbability (classWitnessFailure v part supports (witness t) p) ≤ ε) :
    uniformProbability (simultaneousClassFailure Δ supports T) ≤ (T.card*g:ℕ)*ε := by
  refine (uniformProbability_mono
    (simultaneousClassFailure_subset v part Δ supports T witness hsum hbudget)).trans ?_
  refine (uniformProbability_biUnion_le _ _).trans ?_
  calc
    _ ≤ ∑ _tp : {t // t ∈ T} × Fin g, ε :=
      Finset.sum_le_sum (fun tp _ => hlocal tp.1 tp.2)
    _ = _ := by simp [Fintype.card_prod]

end
end Optss
