import Optss.BooleanVertexSelectionWork

/-!
# The selected Boolean matrix supplies geometric normalization

The returned matrix is physically gathered from the returned Boolean tuple.
For a full-dimensional symmetric vertex hull its columns give the same
maximum-determinant basis used by the cube-normalization proof. Empty inputs
remain an explicit `none` branch; no spanning or symmetry assumption is used
by the executable routine itself.
-/
namespace Optss
open scoped BigOperators
variable {r m : ℕ}

def bitSelectedVertexMatrix (V : ListBitRationalMatrixData r m) :
    Option (ListBitRationalMatrixData r r) :=
  (bitSelectVertexTuple V).map (bitVertexGather V)

def bitSelectedVertexMatrixWork (V : ListBitRationalMatrixData r m) : ℕ :=
  bitSelectVertexTupleWork V+(match bitSelectVertexTuple V with
    | none => 1
    | some t => bitVertexGatherWork V t+1)

theorem bitSelectVertexTuple_mem (V : ListBitRationalMatrixData r m)
    (t : BitVertexTuple r) (ht : bitSelectVertexTuple V=some t) : t∈bitVertexTuples m r := by
  unfold bitSelectVertexTuple at ht
  cases he : bitMaximumScored (bitScoredVertexTuples V) with
  | none => simp [he] at ht
  | some p =>
    simp only [he,Option.map_some,Option.some.injEq] at ht
    replace ht : p.1=t := Option.some.inj ht
    have hp := bitMaximumScored_mem (bitScoredVertexTuples V) p he
    obtain ⟨u,hu,hup⟩ := List.mem_map.mp hp
    have htu : u=t := by
      rw [←hup] at ht
      simpa only [BooleanListArray.copy_eq bitWordCopy bitWordCopy_eq] using ht
    simpa only [htu] using hu

theorem bitSelectedVertexMatrix_wellFormed (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (A : ListBitRationalMatrixData r r) (hA : bitSelectedVertexMatrix V=some A) :
    ∀ i j,(rectangularListFractionMatrix A i j).WellFormed := by
  unfold bitSelectedVertexMatrix at hA
  cases he : bitSelectVertexTuple V with
  | none => simp [he] at hA
  | some t =>
    simp only [he,Option.map_some,Option.some.injEq] at hA
    replace hA : bitVertexGather V t=A := Option.some.inj hA
    subst A
    exact bitVertexGather_wellFormed V hV (bitSelectVertexTuple_mem V t he)

theorem bitSelectedVertexMatrix_lengths (V : ListBitRationalMatrixData r m) (L : ℕ)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).numerator.length≤L ∧
      (rectangularListFractionMatrix V i j).denominator.length≤L)
    (A : ListBitRationalMatrixData r r) (hA : bitSelectedVertexMatrix V=some A) :
    ∀ i j,(rectangularListFractionMatrix A i j).numerator.length≤L ∧
      (rectangularListFractionMatrix A i j).denominator.length≤L := by
  unfold bitSelectedVertexMatrix at hA
  cases he : bitSelectVertexTuple V with
  | none => simp [he] at hA
  | some t =>
    simp only [he,Option.map_some,Option.some.injEq] at hA
    replace hA : bitVertexGather V t=A := Option.some.inj hA
    subst A
    exact bitVertexGather_lengths V L hV (bitSelectVertexTuple_mem V t he)

theorem bitSelectedVertexMatrix_basis (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hspan : Submodule.span ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))=⊤) :
    ∃ A,bitSelectedVertexMatrix V=some A ∧
      ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
        (∀ i j,((bitListFractionValue (rectangularListFractionMatrix A i j)):ℝ)=b j i) ∧
        (∀ j,b j∈rationalVertexSet (storedRationalVertices V)) ∧
        ∀ v : Fin r → (Fin r → ℝ), (∀ j,v j∈rationalVertexSet (storedRationalVertices V)) →
          |(Pi.basisFun ℝ (Fin r)).det v|≤|(Pi.basisFun ℝ (Fin r)).det b| := by
  obtain ⟨t,ht,b,hbt,hb,hmax⟩ := selectVertexTuple_basis (storedRationalVertices V) hspan
  refine ⟨bitVertexGather V (encodeVertexTuple t),?_,b,?_,hb,hmax⟩
  · simp only [bitSelectedVertexMatrix,bitSelectVertexTuple_eq V hV,ht,Option.map_some]
    rfl
  · intro i j
    rw [bitVertexGather_entry,bitVertexGatherCell_encode,hbt]
    rfl

/-- Both cube containments concern the actual matrix returned by the Boolean
search, with a rational inverse certificate for its basis normalization. -/
theorem bitSelectedVertexMatrix_normalization (hr : 0<r)
    (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hspan : Submodule.span ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))=⊤)
    (hsym : ∀ x∈rationalVertexSet (storedRationalVertices V),-x∈rationalVertexSet (storedRationalVertices V)) :
    ∃ A,bitSelectedVertexMatrix V=some A ∧
      ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
        (∀ i j,((bitListFractionValue (rectangularListFractionMatrix A i j)):ℝ)=b j i) ∧
        {x : EuclideanSpace ℝ (Fin r) | ∀ j,|x j|≤1/(r:ℝ)} ⊆
          basisEuclideanNormalization b '' convexHull ℝ (rationalVertexSet (storedRationalVertices V) : Set _) ∧
        basisEuclideanNormalization b '' convexHull ℝ (rationalVertexSet (storedRationalVertices V) : Set _) ⊆
          {x | ∀ j,|x j|≤1} ∧
        Nonempty (RationalNormalizationData (basisEuclideanNormalization b)) := by
  obtain ⟨t,ht,b,hbt,hi,ho,hcert⟩ := selectVertexTuple_normalization hr (storedRationalVertices V) hspan hsym
  refine ⟨bitVertexGather V (encodeVertexTuple t),?_,b,?_,hi,ho,hcert⟩
  · simp only [bitSelectedVertexMatrix,bitSelectVertexTuple_eq V hV,ht,Option.map_some]
    rfl
  · intro i j
    rw [bitVertexGather_entry,bitVertexGatherCell_encode,hbt]
    rfl

noncomputable def selectedVertexMatrixPolynomial (r : ℕ) : Polynomial ℕ :=
  vertexSelectionPolynomial r+Polynomial.C (matrixProductAllocationWork r r)+
    Polynomial.C (r*r)*vertexGatherPolynomial r+1

theorem vertexGatherPolynomial_eval (r N : ℕ) :
    (vertexGatherPolynomial r).eval N=vertexGatherCellBound r N N := by
  simp only [vertexGatherPolynomial,vertexGatherCellBound,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_pow,Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat]

theorem bitSelectedVertexMatrixWork_polynomial (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) (N : ℕ)
    (hm : m≤N) (hN : listStoredRationalBits V≤N) :
    bitSelectedVertexMatrixWork V≤(selectedVertexMatrixPolynomial r).eval N := by
  have hs := bitSelectVertexTupleWork_polynomial V hV N hm hN
  simp only [selectedVertexMatrixPolynomial,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_C,Polynomial.eval_one,vertexGatherPolynomial_eval]
  unfold bitSelectedVertexMatrixWork
  cases he : bitSelectVertexTuple V with
  | none =>
    simp only [he]
    omega
  | some t =>
    have hg := bitVertexGatherWork_bound V t (bitSelectVertexTuple_mem V t he) N (by
      intro i j
      have h := listStoredRationalBits_cell V i j
      exact ⟨h.1.trans hN,h.2.trans hN⟩)
    have hm' : vertexGatherCellBound r m N≤vertexGatherCellBound r N N := by
      unfold vertexGatherCellBound
      gcongr
    have hgm := hg.trans (Nat.add_le_add_left (Nat.mul_le_mul_left (r*r) hm') _)
    change bitSelectVertexTupleWork V+(bitVertexGatherWork V t+1)≤_
    calc
      _ ≤ (vertexSelectionPolynomial r).eval N+
          (matrixProductAllocationWork r r+r*r*vertexGatherCellBound r N N+1) :=
        Nat.add_le_add hs (Nat.add_le_add_right hgm 1)
      _ = _ := by omega

theorem bitSelectedVertexMatrixWork_input_polynomial (hr : 0<r)
    (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) :
    bitSelectedVertexMatrixWork V≤(selectedVertexMatrixPolynomial r).eval (listStoredRationalBits V) :=
  bitSelectedVertexMatrixWork_polynomial V hV _ (listStoredRationalBits_vertices hr V) le_rfl
end Optss
