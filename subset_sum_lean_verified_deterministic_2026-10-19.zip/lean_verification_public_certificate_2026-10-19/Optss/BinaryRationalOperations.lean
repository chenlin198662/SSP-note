import Optss.BinaryMultiplication
import Optss.BinaryRationalNormalization

/-!
# Exact rational operations through binary arithmetic

Numerator and denominator products use shift-and-add multiplication, and every
result is constructed by the proved binary gcd/division normalizer. The second
component records arithmetic operand-width charges. Signed addition and the
bit-machine interpretation of those charges remain separate refinements.
-/

namespace Optss

def binaryIntMultiplication (a b : ℤ) : ℤ × ℕ :=
  let out := binaryMultiplication a.natAbs b.natAbs
  (a.sign*b.sign*(out.value:ℤ), out.widthWork)

theorem binaryIntMultiplication_correct (a b : ℤ) :
    (binaryIntMultiplication a b).1 = a*b := by
  simp only [binaryIntMultiplication, binaryMultiplication_correct, Nat.cast_mul]
  calc
    _ = (a.sign*(a.natAbs:ℤ))*(b.sign*(b.natAbs:ℤ)) := by ring
    _ = _ := by rw [Int.sign_mul_natAbs, Int.sign_mul_natAbs]

theorem binaryIntMultiplication_widthWork (a b : ℤ) :
    (binaryIntMultiplication a b).2 ≤
      4*b.natAbs.size*(2*a.natAbs.size+b.natAbs.size+2) :=
  binaryMultiplication_widthWork _ _

def binaryRatMul (p q : ℚ) : ℚ × ℕ := by
  let num := binaryIntMultiplication p.num q.num
  let den := binaryMultiplication p.den q.den
  have hd : 0 < den.value := by
    rw [binaryMultiplication_correct]
    exact Nat.mul_pos p.den_pos q.den_pos
  let out := binaryNormalizeFraction num.1 den.value hd
  exact (out.1, num.2+den.widthWork+out.2)

theorem binaryRatMul_correct (p q : ℚ) : (binaryRatMul p q).1 = p*q := by
  unfold binaryRatMul
  rw [binaryNormalizeFraction_correct, binaryIntMultiplication_correct,
    binaryMultiplication_correct, Int.cast_mul, Nat.cast_mul, mul_div_mul_comm,
    Rat.num_div_den, Rat.num_div_den]

def binaryRatAdd (p q : ℚ) : ℚ × ℕ := by
  let left := binaryIntMultiplication p.num q.den
  let right := binaryIntMultiplication p.den q.num
  let den := binaryMultiplication p.den q.den
  have hd : 0 < den.value := by
    rw [binaryMultiplication_correct]
    exact Nat.mul_pos p.den_pos q.den_pos
  let out := binaryNormalizeFraction (left.1+right.1) den.value hd
  exact (out.1, left.2+right.2+den.widthWork+
    max left.1.natAbs.size right.1.natAbs.size+1+out.2)

theorem binaryRatAdd_correct (p q : ℚ) : (binaryRatAdd p q).1 = p+q := by
  unfold binaryRatAdd
  rw [binaryNormalizeFraction_correct, binaryIntMultiplication_correct,
    binaryIntMultiplication_correct, binaryMultiplication_correct]
  push_cast
  have hp : (p.den:ℚ) ≠ 0 := by exact_mod_cast p.den_ne_zero
  have hq : (q.den:ℚ) ≠ 0 := by exact_mod_cast q.den_ne_zero
  conv_rhs => rw [← Rat.num_div_den p, ← Rat.num_div_den q]
  field_simp
  ring

def binaryRatSub (p q : ℚ) : ℚ × ℕ := binaryRatAdd p (-q)

theorem binaryRatSub_correct (p q : ℚ) : (binaryRatSub p q).1 = p-q := by
  rw [binaryRatSub, binaryRatAdd_correct, sub_eq_add_neg]

/-- Rational reciprocal uses the already coprime numerator/denominator pair;
normalization is nevertheless explicit, including the field convention at zero. -/
def binaryRatInv (q : ℚ) : ℚ × ℕ :=
  if h : q.num = 0 then (0,0)
  else binaryNormalizeFraction (q.num.sign*(q.den:ℤ)) q.num.natAbs
    (Int.natAbs_pos.mpr h)

theorem binaryRatInv_correct (q : ℚ) : (binaryRatInv q).1 = q⁻¹ := by
  unfold binaryRatInv
  split_ifs with h
  · have hq : q = 0 := Rat.num_eq_zero.mp h
    simp [hq]
  · rw [binaryNormalizeFraction_correct]
    have habs : (q.num.natAbs:ℚ) ≠ 0 := by
      exact_mod_cast (Int.natAbs_pos.mpr h).ne'
    have hden : (q.den:ℚ) ≠ 0 := by exact_mod_cast q.den_ne_zero
    have hn : (q.num:ℚ) ≠ 0 := by exact_mod_cast h
    have he : (q.num.sign:ℚ)*(q.num:ℚ) = q.num.natAbs := by
      simpa only [Int.cast_mul, Int.cast_natCast] using
        congrArg (fun t : ℤ => (t:ℚ)) (Int.sign_mul_self (i := q.num))
    conv_rhs => rw [← Rat.num_div_den q]
    push_cast
    field_simp
    nlinarith [he]

def binaryRatDiv (p q : ℚ) : ℚ × ℕ :=
  let inv := binaryRatInv q
  let out := binaryRatMul p inv.1
  (out.1, inv.2+out.2)

theorem binaryRatDiv_correct (p q : ℚ) : (binaryRatDiv p q).1 = p/q := by
  simp only [binaryRatDiv, binaryRatMul_correct, binaryRatInv_correct, div_eq_mul_inv]

end Optss
