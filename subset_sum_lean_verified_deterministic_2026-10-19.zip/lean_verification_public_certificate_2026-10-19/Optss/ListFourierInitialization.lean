import Optss.ListBluesteinWork

/-! Build the canonical FFT depth from the actual input list. The magnitude
3N−1 is formed and reduced using Boolean arithmetic; mapping its canonical
digits to false gives a structural recursion-depth list of length clog₂(3N).
The remaining precision is a short structural list, whose length is bounded
metadata rather than a decoded large arithmetic operand. -/
namespace Optss
set_option maxRecDepth 4096

def listFourierDepth (input : List Bool) : List Bool :=
  let ns := listLengthDigits input
  let triple := bitListAdd ns (false::ns)
  (bitListTrim (bitListSub triple [true])).map (fun _ => false)

def listFourierPrecision (depth : List Bool) : List Bool :=
  depth++depth++depth++depth++depth++List.replicate 12 false

def listStructuralDyadicDFT (input : List Bool) : List BitFourierInteger :=
  let depth := listFourierDepth input
  let precision := listFourierPrecision depth
  listBluesteinTransform depth precision.length input

theorem nat_clog_two_eq_size_pred (N : ℕ) (hN : 0 < N) : Nat.clog 2 N=(N-1).size := by
  apply Nat.le_antisymm
  · apply (Nat.le_pow_iff_clog_le (by decide : 1 < 2)).mp
    have h := Nat.lt_size_self (N-1)
    omega
  · apply Nat.size_le.mpr
    have h := Nat.le_pow_clog (by decide : 1 < 2) N
    omega

theorem listFourierDepth_eq (input : List Bool) (hinput : input≠[]) :
    listFourierDepth input=List.replicate (bluesteinPadExponent input.length) false := by
  have hN : 0 < input.length := List.length_pos_iff.mpr hinput
  have hvalue : binaryDigitsValue (bitListTrim (bitListSub
      (bitListAdd (listLengthDigits input) (false::listLengthDigits input)) [true]))=3*input.length-1 := by
    simp only [bitListTrim_value,bitListSub_correct,bitListAdd_correct,listLengthDigits_value,
      binaryDigitsValue,Bool.toNat_false,Bool.toNat_true,mul_zero,add_zero]
    congr 1
    omega
  unfold listFourierDepth
  rw [List.map_const']
  have hlen := (bitListTrim_canonical (bitListSub
    (bitListAdd (listLengthDigits input) (false::listLengthDigits input)) [true])).length
  rw [hvalue] at hlen
  rw [hlen,← nat_clog_two_eq_size_pred _ (by omega : 0 < 3*input.length)]
  rfl

theorem listFourierPrecision_length (depth : List Bool) :
    (listFourierPrecision depth).length=dyadicDFTPrecision depth.length := by
  simp only [listFourierPrecision,List.length_append,List.length_replicate,dyadicDFTPrecision]
  omega

theorem listStructuralDyadicDFT_eq (input : List Bool) (hinput : input≠[]) :
    listStructuralDyadicDFT input=listCanonicalDyadicDFT input := by
  rw [listStructuralDyadicDFT,listFourierPrecision_length,listFourierDepth_eq input hinput]
  simp only [List.length_replicate,listCanonicalDyadicDFT]

/-- Scalar Boolean work plus list traversal/construction. Precision length
uses one bounded-word increment per cell; a bit-level simulation of those
small metadata counters can multiply that portion by their word width. -/
def listFourierInitializationWork (input : List Bool) : ℕ :=
  let ns := listLengthDigits input
  let triple := bitListAdd ns (false::ns)
  let pred := bitListSub triple [true]
  listLengthDigitsWork input+bitListSignedAddCost false false ns (false::ns)+
    bitListRippleGates 8 triple [true]+bitListSubVisits triple [true]+
    bitListTrimVisits pred+2*(bitListTrim pred).length+
    16*(listFourierDepth input).length+64

theorem listFourierInitializationWork_bound (input : List Bool) :
    listFourierInitializationWork input≤256*(input.length+1)*(input.length.size+3)^2 := by
  let s := input.length.size
  have hn : (listLengthDigits input).length=s := listLengthDigits_length input
  have ht : (bitListAdd (listLengthDigits input) (false::listLengthDigits input)).length≤s+2 := by
    have h := bitListTrim_length_le (bitListAddAux false (listLengthDigits input) (false::listLengthDigits input))
    have h := h.trans (bitListAddAux_length _ _ _)
    simp only [List.length_cons,hn] at h
    exact h.trans (by omega)
  have hmax : max (bitListAdd (listLengthDigits input) (false::listLengthDigits input)).length
      [true].length≤s+2 := max_le ht (by simp)
  have hsub := bitListSub_length_le (bitListAdd (listLengthDigits input) (false::listLengthDigits input)) [true]
  have htrim := bitListTrim_length_le (bitListSub
    (bitListAdd (listLengthDigits input) (false::listLengthDigits input)) [true])
  have hdepth : (listFourierDepth input).length≤s+2 := by
    simp only [listFourierDepth,List.length_map]
    omega
  have hlen := listLengthDigitsWork_bound input (s+1) (by omega) (by dsimp [s]; omega)
  have hadd := bitListSignedAddCost_bound false false (listLengthDigits input)
    (false::listLengthDigits input) (s+1) (by omega) (by simpa only [List.length_cons,hn] using Nat.le_refl (s+1))
  unfold listFourierInitializationWork
  dsimp only
  rw [bitListRippleGates_eq,bitListSubVisits_eq,bitListTrimVisits_eq]
  change _≤256*(input.length+1)*(s+3)^2
  have hsquare : s+3≤(s+3)^2 := by nlinarith
  have hmul := Nat.mul_le_mul_left (32*input.length) hsquare
  nlinarith only [hlen,hadd,hmax,hsub,htrim,hdepth,hsquare,hmul]

end Optss
