import Optss.ModelingPart
import Mathlib.Data.ZMod.ValMinAbs
import Mathlib.Combinatorics.Additive.FreimanHom

/-!
# The actual difference-set map used to lift the finite Freiman model

The executed map uses only multiplication in `ZMod q`, its centered integer
representative, and reduction modulo `p`. On a short modeling part it agrees
with the extension to `2T - 2T`. Its injectivity and preservation/reflection of
two-term relations follow from the proved eight-term relation certificate.
-/

namespace Optss
open scoped BigOperators Pointwise

/-- A directly computable extension of the modeling map to differences. -/
def modelingDifferenceMap (p : ℕ) {q : ℕ} (lam : ZMod q) (x : ℤ) : ZMod p :=
  ((lam * (x : ZMod q)).valMinAbs : ZMod p)

/-- The actual four-term difference domain. -/
def modelingDoubleDifference (T : Finset ℤ) : Finset ℤ := (T + T) - (T + T)

private def quadValue {G : Type*} [AddCommGroup G] (a : Fin 4 → G) : G :=
  a 0 + a 1 - a 2 - a 3

private theorem mem_doubleDifference_iff (T : Finset ℤ) (x : ℤ) :
    x ∈ modelingDoubleDifference T ↔
      ∃ a : Fin 4 → ℤ, (∀ i, a i ∈ T) ∧ quadValue a = x := by
  constructor
  · rintro hx
    obtain ⟨u, hu, v, hv, rfl⟩ := Finset.mem_sub.mp hx
    obtain ⟨a, ha, b, hb, rfl⟩ := Finset.mem_add.mp hu
    obtain ⟨c, hc, d, hd, rfl⟩ := Finset.mem_add.mp hv
    refine ⟨![a,b,c,d], ?_, ?_⟩
    · intro i; fin_cases i <;> simpa using (by assumption)
    · simp [quadValue]; abel
  · rintro ⟨a, ha, rfl⟩
    apply Finset.mem_sub.mpr
    refine ⟨a 0 + a 1, Finset.mem_add.mpr ⟨_, ha 0, _, ha 1, rfl⟩,
      a 2 + a 3, Finset.mem_add.mpr ⟨_, ha 2, _, ha 3, rfl⟩, ?_⟩
    dsimp [quadValue]; abel

/-- Centering recovers the genuine difference of residue sums: the short
interval rules out an unobserved multiple of `q`. -/
theorem modelingDifferenceMap_quad (p : ℕ) {q : ℕ} [NeZero q]
    (lam : ZMod q) (L U : ℤ) (hwidth : 8 * (U - L) < q)
    (a : Fin 4 → ℤ)
    (ha : ∀ i, L ≤ modelingResidue lam (a i) ∧ modelingResidue lam (a i) ≤ U) :
    modelingDifferenceMap p lam (a 0 + a 1 - a 2 - a 3) =
      (modelingResidue lam (a 0) : ZMod p) + modelingResidue lam (a 1) -
        modelingResidue lam (a 2) - modelingResidue lam (a 3) := by
  let z := modelingResidue lam (a 0) + modelingResidue lam (a 1) -
    modelingResidue lam (a 2) - modelingResidue lam (a 3)
  have hz : (lam * ((a 0 + a 1 - a 2 - a 3 : ℤ) : ZMod q)).valMinAbs = z := by
    apply (ZMod.valMinAbs_spec _ z).mpr
    constructor
    · simp only [z, Int.cast_add, Int.cast_sub, modelingResidue_congr]
      ring
    · have h0 := ha 0
      have h1 := ha 1
      have h2 := ha 2
      have h3 := ha 3
      change -(q : ℤ) < z * 2 ∧ z * 2 ≤ q
      dsimp [z]
      constructor <;> omega
  unfold modelingDifferenceMap
  rw [hz]
  simp [z]

private theorem quad_pair_relation_iff {p : ℕ} (T : Finset ℤ) (f : ℤ → ZMod p)
    (hmodel : ∀ a b : Fin 8 → ℤ, (∀ i, a i ∈ T) → (∀ i, b i ∈ T) →
      ((∑ i, f (a i)) = (∑ i, f (b i)) ↔ (∑ i, a i) = (∑ i, b i)))
    (a b c d : Fin 4 → ℤ) (ha : ∀ i, a i ∈ T) (hb : ∀ i, b i ∈ T)
    (hc : ∀ i, c i ∈ T) (hd : ∀ i, d i ∈ T) :
    quadValue (f ∘ a) + quadValue (f ∘ b) =
      quadValue (f ∘ c) + quadValue (f ∘ d) ↔
      quadValue a + quadValue b = quadValue c + quadValue d := by
  have hr := hmodel
    ![a 0, a 1, b 0, b 1, c 2, c 3, d 2, d 3]
    ![a 2, a 3, b 2, b 3, c 0, c 1, d 0, d 1]
    (by intro i; fin_cases i <;> simpa using (by first | apply ha | apply hb | apply hc | apply hd))
    (by intro i; fin_cases i <;> simpa using (by first | apply ha | apply hb | apply hc | apply hd))
  simp only [Fin.sum_univ_succ, Fin.sum_univ_zero, Matrix.cons_val_zero,
    Matrix.cons_val_succ, add_zero] at hr
  dsimp only [quadValue, Function.comp_apply]
  constructor
  · intro h
    have he := hr.mp (by linear_combination h)
    linear_combination he
  · intro h
    have he := hr.mpr (by linear_combination h)
    linear_combination he

/-- The centered map preserves and reflects two-term relations on the whole
actual difference domain; no extension map is supplied as a hypothesis. -/
theorem modelingDifferenceMap_add_iff (p : ℕ) {q : ℕ} [NeZero q]
    (T : Finset ℤ) (lam : ZMod q) (L U : ℤ)
    (hinterval : ∀ a ∈ T, L ≤ modelingResidue lam a ∧ modelingResidue lam a ≤ U)
    (hwidth : 8 * (U - L) < q)
    (hmodel : ∀ a b : Fin 8 → ℤ, (∀ i, a i ∈ T) → (∀ i, b i ∈ T) →
      ((∑ i, (modelingResidue lam (a i) : ZMod p)) =
        (∑ i, (modelingResidue lam (b i) : ZMod p)) ↔
        (∑ i, a i) = (∑ i, b i)))
    {w x y z : ℤ} (hw : w ∈ modelingDoubleDifference T)
    (hx : x ∈ modelingDoubleDifference T) (hy : y ∈ modelingDoubleDifference T)
    (hz : z ∈ modelingDoubleDifference T) :
    modelingDifferenceMap p lam w + modelingDifferenceMap p lam x =
      modelingDifferenceMap p lam y + modelingDifferenceMap p lam z ↔ w + x = y + z := by
  obtain ⟨a, ha, rfl⟩ := (mem_doubleDifference_iff T w).mp hw
  obtain ⟨b, hb, rfl⟩ := (mem_doubleDifference_iff T x).mp hx
  obtain ⟨c, hc, rfl⟩ := (mem_doubleDifference_iff T y).mp hy
  obtain ⟨d, hd, rfl⟩ := (mem_doubleDifference_iff T z).mp hz
  have hmap (v : Fin 4 → ℤ) (hv : ∀ i, v i ∈ T) :
      modelingDifferenceMap p lam (quadValue v) =
        quadValue ((fun a => (modelingResidue lam a : ZMod p)) ∘ v) :=
    modelingDifferenceMap_quad p lam L U hwidth v (fun i => hinterval _ (hv i))
  rw [hmap a ha, hmap b hb, hmap c hc, hmap d hd]
  exact quad_pair_relation_iff T _ hmodel a b c d ha hb hc hd

/-- In particular there are no collisions between distinct integer
four-term differences in the extended finite model. -/
theorem modelingDifferenceMap_injOn (p : ℕ) {q : ℕ} [NeZero q]
    (T : Finset ℤ) (lam : ZMod q) (L U : ℤ)
    (hinterval : ∀ a ∈ T, L ≤ modelingResidue lam a ∧ modelingResidue lam a ≤ U)
    (hwidth : 8 * (U - L) < q)
    (hmodel : ∀ a b : Fin 8 → ℤ, (∀ i, a i ∈ T) → (∀ i, b i ∈ T) →
      ((∑ i, (modelingResidue lam (a i) : ZMod p)) =
        (∑ i, (modelingResidue lam (b i) : ZMod p)) ↔
        (∑ i, a i) = (∑ i, b i))) :
    Set.InjOn (modelingDifferenceMap p lam) (modelingDoubleDifference T) := by
  intro x hx y hy he
  apply add_right_cancel (b := x)
  apply (modelingDifferenceMap_add_iff p T lam L U hinterval hwidth hmodel
    hx hx hy hx).mp
  rw [he]

/-- The image is the entire modeled difference domain, not a subcollection. -/
theorem modelingDifferenceMap_image (p : ℕ) {q : ℕ} [NeZero q]
    (T : Finset ℤ) (lam : ZMod q) (L U : ℤ)
    (hinterval : ∀ a ∈ T, L ≤ modelingResidue lam a ∧ modelingResidue lam a ≤ U)
    (hwidth : 8 * (U - L) < q) :
    (modelingDoubleDifference T).image (modelingDifferenceMap p lam) =
      ((T.image fun a => (modelingResidue lam a : ZMod p)) +
        (T.image fun a => (modelingResidue lam a : ZMod p))) -
      ((T.image fun a => (modelingResidue lam a : ZMod p)) +
        (T.image fun a => (modelingResidue lam a : ZMod p))) := by
  let f : ℤ → ZMod p := fun a => modelingResidue lam a
  have hmap (a : Fin 4 → ℤ) (ha : ∀ i, a i ∈ T) :
      modelingDifferenceMap p lam (quadValue a) = quadValue (f ∘ a) :=
    modelingDifferenceMap_quad p lam L U hwidth a (fun i => hinterval _ (ha i))
  ext z
  constructor
  · rintro hz
    obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hz
    obtain ⟨a, ha, rfl⟩ := (mem_doubleDifference_iff T x).mp hx
    rw [hmap a ha]
    apply Finset.mem_sub.mpr
    refine ⟨f (a 0) + f (a 1), ?_, f (a 2) + f (a 3), ?_, ?_⟩
    · exact Finset.mem_add.mpr ⟨_, Finset.mem_image.mpr ⟨_, ha 0, rfl⟩,
        _, Finset.mem_image.mpr ⟨_, ha 1, rfl⟩, rfl⟩
    · exact Finset.mem_add.mpr ⟨_, Finset.mem_image.mpr ⟨_, ha 2, rfl⟩,
        _, Finset.mem_image.mpr ⟨_, ha 3, rfl⟩, rfl⟩
    · dsimp [quadValue, Function.comp_def]; abel
  · rintro hz
    obtain ⟨u, hu, v, hv, rfl⟩ := Finset.mem_sub.mp hz
    obtain ⟨a', ha', b', hb', rfl⟩ := Finset.mem_add.mp hu
    obtain ⟨c', hc', d', hd', rfl⟩ := Finset.mem_add.mp hv
    obtain ⟨a, ha, rfl⟩ := Finset.mem_image.mp ha'
    obtain ⟨b, hb, rfl⟩ := Finset.mem_image.mp hb'
    obtain ⟨c, hc, rfl⟩ := Finset.mem_image.mp hc'
    obtain ⟨d, hd, rfl⟩ := Finset.mem_image.mp hd'
    have hm : ∀ i : Fin 4, (![a,b,c,d] : Fin 4 → ℤ) i ∈ T := by
      intro i; fin_cases i <;> simpa using (by assumption)
    apply Finset.mem_image.mpr
    refine ⟨quadValue ![a,b,c,d],
      (mem_doubleDifference_iff T _).mpr ⟨_, hm, rfl⟩, ?_⟩
    rw [hmap _ hm]
    simp [quadValue, f]; abel

/-- The supplied eight-isomorphism produces a genuine two-isomorphism on
four-term differences. The forward map is the explicit centered residue map. -/
theorem modelingDifferenceMap_freimanIso (p : ℕ) {q : ℕ} [NeZero q]
    (T : Finset ℤ) (lam : ZMod q) (L U : ℤ)
    (hinterval : ∀ a ∈ T, L ≤ modelingResidue lam a ∧ modelingResidue lam a ≤ U)
    (hwidth : 8 * (U - L) < q)
    (hmodel : ∀ a b : Fin 8 → ℤ, (∀ i, a i ∈ T) → (∀ i, b i ∈ T) →
      ((∑ i, (modelingResidue lam (a i) : ZMod p)) =
        (∑ i, (modelingResidue lam (b i) : ZMod p)) ↔
        (∑ i, a i) = (∑ i, b i))) :
    IsAddFreimanIso 2 (modelingDoubleDifference T : Set ℤ)
      ((modelingDoubleDifference T).image (modelingDifferenceMap p lam) : Set (ZMod p))
      (modelingDifferenceMap p lam) := by
  apply isAddFreimanIso_two.mpr
  constructor
  · constructor
    · intro x hx
      exact Finset.mem_image.mpr ⟨x, hx, rfl⟩
    · constructor
      · exact modelingDifferenceMap_injOn p T lam L U hinterval hwidth hmodel
      · intro y hy
        exact Finset.mem_image.mp hy
  · intro a ha b hb c hc d hd
    exact modelingDifferenceMap_add_iff p T lam L U hinterval hwidth hmodel ha hb hc hd

@[simp] theorem modelingDifferenceMap_zero (p : ℕ) {q : ℕ} (lam : ZMod q) :
    modelingDifferenceMap p lam 0 = 0 := by
  simp [modelingDifferenceMap]

end Optss
