import Optss.BasisPacking
import Optss.SignedPotential
import Mathlib.Data.Fintype.BigOperators

/-!
# Integer box points in a proper real subspace

A proper subspace misses some coordinate axis. Deleting that coordinate is
injective on the subspace, so its integer box points are bounded by the product
of the other widths. This proves the rank-protection counting step without
assuming a hyperplane-counting theorem or an integer annihilator.
-/

namespace Optss
open scoped BigOperators Pointwise Classical
noncomputable section

variable {d : ℕ}

/-- The coordinatewise embedding of integer vectors into real vector space. -/
def realVector : IntVec d →+ (Fin d → ℝ) where
  toFun x j := (x j : ℝ)
  map_zero' := by ext j; simp
  map_add' x y := by ext j; simp

/-- A proper subspace cannot contain every standard coordinate axis. -/
theorem exists_coordinate_axis_outside (V : Submodule ℝ (Fin d → ℝ)) (hV : V ≠ ⊤) :
    ∃ j : Fin d, Pi.single j (1:ℝ) ∉ V := by
  by_contra h
  push_neg at h
  apply hV
  apply top_unique
  intro x _
  have heq : x = ∑ j : Fin d, x j • (Pi.single j (1:ℝ) : Fin d → ℝ) := by
    ext i
    simp [Finset.sum_apply, Pi.smul_apply, Pi.single_apply]
  rw [heq]
  exact V.sum_mem (fun j _ => V.smul_mem (x j) (h j))

/-- If one coordinate axis is missing, all the other coordinates uniquely
determine a point in the subspace. -/
theorem subspace_coordinate_projection_injective
    (V : Submodule ℝ (Fin d → ℝ)) (j : Fin d) (hj : Pi.single j (1:ℝ) ∉ V)
    {x y : Fin d → ℝ} (hx : x ∈ V) (hy : y ∈ V)
    (hxy : ∀ i, i ≠ j → x i = y i) : x = y := by
  by_cases hcoord : x j = y j
  · ext i
    by_cases hij : i = j
    · simpa [hij] using hcoord
    · exact hxy i hij
  · have hn : x j - y j ≠ 0 := sub_ne_zero.mpr hcoord
    have heq : x-y = (x j-y j) • (Pi.single j (1:ℝ) : Fin d → ℝ) := by
      ext i
      by_cases hij : i = j
      · subst i; simp
      · simp [Pi.single_eq_of_ne hij, hxy i hij]
    have hm := V.smul_mem ((x j-y j)⁻¹) (V.sub_mem hx hy)
    rw [heq, smul_smul, inv_mul_cancel₀ hn, one_smul] at hm
    exact (hj hm).elim

/-- Delete the chosen coordinate from an integer vector. -/
def omitCoordinate (j : Fin d) (x : IntVec d) : {i : Fin d // i ≠ j} → ℤ := fun i => x i

/-- Integer coordinate deletion inherits the subspace injectivity. -/
theorem omitCoordinate_injOn_subspace (V : Submodule ℝ (Fin d → ℝ))
    (j : Fin d) (hj : Pi.single j (1:ℝ) ∉ V) :
    Set.InjOn (omitCoordinate j) {x : IntVec d | realVector x ∈ V} := by
  intro x hx y hy heq
  have hr := subspace_coordinate_projection_injective V j hj hx hy (fun i hi => by
    have h := congrFun heq ⟨i, hi⟩
    change x i = y i at h
    change (x i : ℝ) = (y i : ℝ)
    exact_mod_cast h)
  ext i
  have h := congrFun hr i
  change (x i : ℝ) = (y i : ℝ) at h
  exact_mod_cast h

/-- Exact integer box after deleting one coordinate. -/
def omittedIntegerBox (w : Fin d → ℕ) (j : Fin d) : Finset ({i : Fin d // i ≠ j} → ℤ) :=
  Fintype.piFinset (fun i => Finset.Icc (-(w i : ℤ)) (w i : ℤ))

theorem card_omittedIntegerBox (w : Fin d → ℕ) (j : Fin d) :
    (omittedIntegerBox w j).card = ∏ i : {i : Fin d // i ≠ j}, (2*w i+1) := by
  rw [omittedIntegerBox, Fintype.card_piFinset]
  apply Finset.prod_congr rfl
  intro i _
  rw [Int.card_Icc]
  omega

/-- Coordinate deletion gives the exact product of the remaining coordinate
widths as an upper bound, including degenerate widths. -/
theorem integer_subspace_card_le_omitted_product
    (V : Submodule ℝ (Fin d → ℝ)) (j : Fin d) (hj : Pi.single j (1:ℝ) ∉ V)
    (w : Fin d → ℕ) (S : Finset (IntVec d))
    (hbox : ∀ x ∈ S, InCenteredBox w x) (hsub : ∀ x ∈ S, realVector x ∈ V) :
    S.card ≤ ∏ i : {i : Fin d // i ≠ j}, (2*w i+1) := by
  have hinj : Set.InjOn (omitCoordinate j) (S : Set (IntVec d)) :=
    (omitCoordinate_injOn_subspace V j hj).mono hsub
  have hmem : S.image (omitCoordinate j) ⊆ omittedIntegerBox w j := by
    intro y hy
    obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hy
    rw [omittedIntegerBox, Fintype.mem_piFinset]
    intro i
    exact Finset.mem_Icc.mpr (abs_le.mp (hbox x hx i))
  have hc := Finset.card_le_card hmem
  rw [Finset.card_image_of_injOn hinj, card_omittedIntegerBox] at hc
  exact hc

/-- The full box product is recovered by restoring the one deleted width. -/
theorem omitted_product_mul_width (w : Fin d → ℕ) (j : Fin d) :
    (∏ i : {i : Fin d // i ≠ j}, (2*w i+1)) * (2*w j+1) = ∏ i, (2*w i+1) := by
  rw [mul_comm]
  exact (Fintype.prod_eq_mul_prod_subtype_ne (fun i => 2*w i+1) j).symm

/-- Losing one coordinate costs at least its minimum width. -/
theorem integer_proper_subspace_card_mul_width_le
    (V : Submodule ℝ (Fin d → ℝ)) (hV : V ≠ ⊤)
    (w : Fin d → ℕ) (s : ℕ) (hw : ∀ j, s ≤ w j)
    (S : Finset (IntVec d)) (hbox : ∀ x ∈ S, InCenteredBox w x)
    (hsub : ∀ x ∈ S, realVector x ∈ V) :
    S.card * (2*s+1) ≤ ∏ i, (2*w i+1) := by
  obtain ⟨j, hj⟩ := exists_coordinate_axis_outside V hV
  have hc := integer_subspace_card_le_omitted_product V j hj w S hbox hsub
  calc
    _ ≤ S.card * (2*w j+1) := Nat.mul_le_mul_left _ (by nlinarith [hw j])
    _ ≤ (∏ i : {i : Fin d // i ≠ j}, (2*w i+1)) * (2*w j+1) :=
      Nat.mul_le_mul_right _ hc
    _ = _ := omitted_product_mul_width w j

/-- The actual finite set of integer box points lying in the real subspace. -/
def integerSubspaceBox (w : Fin d → ℕ) (V : Submodule ℝ (Fin d → ℝ)) : Finset (IntVec d) :=
  (Fintype.piFinset (fun j => Finset.Icc (-(w j : ℤ)) (w j : ℤ))).filter
    (fun x => realVector x ∈ V)

@[simp] theorem mem_integerSubspaceBox (w : Fin d → ℕ) (V : Submodule ℝ (Fin d → ℝ))
    (x : IntVec d) : x ∈ integerSubspaceBox w V ↔ InCenteredBox w x ∧ realVector x ∈ V := by
  simp only [integerSubspaceBox, Finset.mem_filter, Fintype.mem_piFinset, Finset.mem_Icc,
    InCenteredBox, abs_le]

/-- Every proper subspace loses a full active coordinate interval in the dilated
integer box. No rationality condition on the subspace is needed. -/
theorem integerSubspaceBox_card_mul_le (b : Fin d → ℕ) (hb : ∀ j, 1 ≤ b j)
    (s : ℕ) (V : Submodule ℝ (Fin d → ℝ)) (hV : V ≠ ⊤) :
    (integerSubspaceBox (fun j => s*b j) V).card * (2*s+1) ≤ ∏ j, (2*s*b j+1) := by
  have h := integer_proper_subspace_card_mul_width_le V hV (fun j => s*b j) s
    (fun j => by nlinarith [hb j]) (integerSubspaceBox (fun j => s*b j) V)
    (fun x hx => ((mem_integerSubspaceBox _ _ _).mp hx).1)
    (fun x hx => ((mem_integerSubspaceBox _ _ _).mp hx).2)
  simpa only [Nat.mul_assoc] using h

/-- Repeated sums remain in any real subspace containing their support. -/
theorem repeatedSumset_mem_real_subspace (V : Submodule ℝ (Fin d → ℝ))
    (S : Finset (IntVec d)) (hS : ∀ x ∈ S, realVector x ∈ V) (s : ℕ) :
    ∀ x ∈ s • S, realVector x ∈ V := by
  induction s with
  | zero =>
    intro x hx
    have hx0 : x = 0 := by simpa using hx
    subst x
    simp
  | succ s ih =>
    intro x hx
    rw [succ_nsmul] at hx
    obtain ⟨y, hy, z, hz, rfl⟩ := Finset.mem_add.mp hx
    rw [map_add]
    exact V.add_mem (ih y hy) (hS z hz)

/-- Proper-span counting for the actual repeated sumset, allowing all repetitions. -/
theorem proper_subspace_repeatedSumset_card_mul_le
    (V : Submodule ℝ (Fin d → ℝ)) (hV : V ≠ ⊤)
    (b : Fin d → ℕ) (hb : ∀ j, 1 ≤ b j) (S : Finset (IntVec d))
    (hbox : ∀ x ∈ S, InCenteredBox b x) (hsub : ∀ x ∈ S, realVector x ∈ V) (s : ℕ) :
    (s • S).card * (2*s+1) ≤ ∏ j, (2*s*b j+1) := by
  have h := integer_proper_subspace_card_mul_width_le V hV (fun j => s*b j) s
    (fun j => by nlinarith [hb j]) (s • S) (repeatedSumset_in_box b S hbox s)
    (repeatedSumset_mem_real_subspace V S hsub s)
  simpa only [Nat.mul_assoc] using h

/-- The dense-box contradiction used to prove that the initial coordinates have
full real span. The density constant may be an arbitrary real number. -/
theorem subspace_eq_top_of_box_density
    (V : Submodule ℝ (Fin d → ℝ)) (b : Fin d → ℕ) (hb : ∀ j, 1 ≤ b j)
    (s mh : ℕ) (γ : ℝ) (hmh : 0 < mh) (hγ : γ < (2*s+1 : ℕ))
    (hpoints : mh ≤ (integerSubspaceBox (fun j => s*b j) V).card)
    (hvolume : (∏ j, (2*s*b j+1) : ℕ) ≤ γ * mh) : V = ⊤ := by
  by_contra hV
  have hc := (Nat.mul_le_mul_right (2*s+1) hpoints).trans
    (integerSubspaceBox_card_mul_le b hb s V hV)
  have hc' : (mh:ℝ) * (2*s+1:ℕ) ≤ (∏ j, (2*s*b j+1) : ℕ) := by exact_mod_cast hc
  have hm : (0:ℝ) < mh := by exact_mod_cast hmh
  nlinarith

/-- In particular the current support has full span if its repeated-sumset
cardinality controls the containing box volume with constant less than `2s+1`. -/
theorem repeatedSumset_span_eq_top_of_box_density (S : Finset (IntVec d))
    (b : Fin d → ℕ) (hb : ∀ j, 1 ≤ b j) (hbox : ∀ x ∈ S, InCenteredBox b x)
    (s : ℕ) (γ : ℝ) (hγ : γ < (2*s+1:ℕ)) (hpos : 0 < (s • S).card)
    (hvolume : (∏ j, (2*s*b j+1) : ℕ) ≤ γ * (s • S).card) :
    labelSpan ℝ realVector S = ⊤ := by
  apply subspace_eq_top_of_box_density _ b hb s (s • S).card γ hpos hγ _ hvolume
  apply Finset.card_le_card
  intro x hx
  apply (mem_integerSubspaceBox _ _ _).mpr
  refine ⟨repeatedSumset_in_box b S hbox s x hx, ?_⟩
  apply repeatedSumset_mem_real_subspace _ S ?_ s x hx
  intro y hy
  exact Submodule.subset_span ⟨y, hy, rfl⟩

section Labelled
variable {ι : Type*} [DecidableEq ι]

omit [DecidableEq ι] in
/-- The signed support of retained labels lies in their actual real span. -/
theorem signedAlphabet_mem_labelSpan (v : ι → IntVec d) (live : Finset ι) :
    ∀ x ∈ signedAlphabet (fun i : live => v i),
      realVector x ∈ labelSpan ℝ (fun i => realVector (v i)) live := by
  intro x hx
  rcases (mem_signedAlphabet (fun i : live => v i) x).mp hx with rfl | ⟨i, rfl⟩ | ⟨i, rfl⟩
  · simp
  · exact Submodule.subset_span ⟨i, i.property, rfl⟩
  · rw [map_neg]
    exact Submodule.neg_mem _ (Submodule.subset_span ⟨i, i.property, rfl⟩)

omit [DecidableEq ι] in
/-- The rank-deficient label family has the exact repeated signed-support bound. -/
theorem proper_labelSpan_signedPotential_card_mul_le
    (v : ι → IntVec d) (live : Finset ι)
    (hproper : labelSpan ℝ (fun i => realVector (v i)) live ≠ ⊤)
    (b : Fin d → ℕ) (hb : ∀ j, 1 ≤ b j)
    (hbox : ∀ i ∈ live, InCenteredBox b (v i)) (s : ℕ) :
    (s • signedAlphabet (fun i : live => v i)).card * (2*s+1) ≤ ∏ j, (2*s*b j+1) :=
  proper_subspace_repeatedSumset_card_mul_le _ hproper b hb _
    (signedAlphabet_in_box (fun i : live => v i) b (fun i => hbox i i.property))
    (signedAlphabet_mem_labelSpan v live) s

/-- A failed actual basis packing in initially full coordinates has the exact
proper-subspace sumset bound required by the phase restart. -/
theorem packLabelBases_failure_sumset_bound
    (v : ι → IntVec d) (live : Finset ι) (k : ℕ)
    (hfull : labelSpan ℝ (fun i => realVector (v i)) live = ⊤)
    (hshort : (packLabelBases (fun i => realVector (v i))
      (labelSpan ℝ (fun i => realVector (v i)) live) live (k+1)).length < k+1)
    (b : Fin d → ℕ) (hb : ∀ j, 1 ≤ b j)
    (hbox : ∀ i ∈ live, InCenteredBox b (v i)) (s : ℕ) :
    let bs := packLabelBases (fun i => realVector (v i))
      (labelSpan ℝ (fun i => realVector (v i)) live) live (k+1)
    let remaining := live \ packedLabels bs
    (packedLabels bs).card ≤ d*k ∧
    (s • signedAlphabet (fun i : remaining => v i)).card * (2*s+1) ≤
      ∏ j, (2*s*b j+1) := by
  let bs := packLabelBases (fun i => realVector (v i))
    (labelSpan ℝ (fun i => realVector (v i)) live) live (k+1)
  let remaining := live \ packedLabels bs
  obtain ⟨_, _, hcard, hlt, _⟩ := packLabelBases_failure (fun i => realVector (v i)) live k hshort
  change (packedLabels bs).card ≤ Module.finrank ℝ
    (labelSpan ℝ (fun i => realVector (v i)) live) * k at hcard
  change labelSpan ℝ (fun i => realVector (v i)) remaining <
    labelSpan ℝ (fun i => realVector (v i)) live at hlt
  rw [hfull] at hcard hlt
  refine ⟨?_, ?_⟩
  · simpa using hcard
  · exact proper_labelSpan_signedPotential_card_mul_le v remaining (ne_of_lt hlt) b hb
      (fun i hi => hbox i (Finset.mem_sdiff.mp hi).1) s

/-- The exact arithmetic behind the halving restart, with a real volume constant. -/
theorem proper_subspace_count_lt_half (newCount mh s : ℕ) (γ : ℝ) (hmh : 0 < mh)
    (hγ : 2*γ < (2*s+1:ℕ)) (volume : ℕ)
    (hcount : newCount * (2*s+1) ≤ volume) (hvolume : (volume:ℝ) ≤ γ*mh) :
    2*newCount < mh := by
  have hc : (newCount:ℝ) * (2*s+1:ℕ) ≤ volume := by exact_mod_cast hcount
  have hm : (0:ℝ) < mh := by exact_mod_cast hmh
  have hw : (0:ℝ) < (2*s+1:ℕ) := by positivity
  have hstrict : (2:ℝ)*newCount < mh := by nlinarith
  exact_mod_cast hstrict

/-- Combining actual failed packing, box counting, and the proved density
estimate strictly halves the phase potential after deleting at most `d*k` copies. -/
theorem packLabelBases_failure_halves_potential
    (v : ι → IntVec d) (live : Finset ι) (k : ℕ)
    (hfull : labelSpan ℝ (fun i => realVector (v i)) live = ⊤)
    (hshort : (packLabelBases (fun i => realVector (v i))
      (labelSpan ℝ (fun i => realVector (v i)) live) live (k+1)).length < k+1)
    (b : Fin d → ℕ) (hb : ∀ j, 1 ≤ b j)
    (hbox : ∀ i ∈ live, InCenteredBox b (v i)) (s mh : ℕ) (γ : ℝ)
    (hmh : 0 < mh) (hγ : 2*γ < (2*s+1:ℕ))
    (hvolume : (∏ j, (2*s*b j+1) : ℕ) ≤ γ*mh) :
    let bs := packLabelBases (fun i => realVector (v i))
      (labelSpan ℝ (fun i => realVector (v i)) live) live (k+1)
    let remaining := live \ packedLabels bs
    (packedLabels bs).card ≤ d*k ∧
    2*(s • signedAlphabet (fun i : remaining => v i)).card < mh := by
  obtain ⟨hcard, hcount⟩ := packLabelBases_failure_sumset_bound v live k hfull hshort b hb hbox s
  exact ⟨hcard, proper_subspace_count_lt_half _ mh s γ hmh hγ _ hcount hvolume⟩

omit [DecidableEq ι] in
/-- The same density argument proves full rank of the actual labelled vectors,
using their signed repeated support as the phase potential. -/
theorem labelSpan_eq_top_of_signedPotential_density
    (v : ι → IntVec d) (live : Finset ι) (b : Fin d → ℕ) (hb : ∀ j, 1 ≤ b j)
    (hbox : ∀ i ∈ live, InCenteredBox b (v i)) (s : ℕ) (γ : ℝ)
    (hγ : γ < (2*s+1:ℕ))
    (hvolume : (∏ j, (2*s*b j+1) : ℕ) ≤
      γ * (s • signedAlphabet (fun i : live => v i)).card) :
    labelSpan ℝ (fun i => realVector (v i)) live = ⊤ := by
  apply subspace_eq_top_of_box_density _ b hb s _ γ
    (signedPotential_one_le (fun i : live => v i) s) hγ _ hvolume
  apply Finset.card_le_card
  intro x hx
  apply (mem_integerSubspaceBox _ _ _).mpr
  exact ⟨repeatedSumset_in_box b _
    (signedAlphabet_in_box (fun i : live => v i) b (fun i => hbox i i.property)) s x hx,
    repeatedSumset_mem_real_subspace _ _ (signedAlphabet_mem_labelSpan v live) s x hx⟩

/-- Count-version restart: failed packing debits the true multiplicities and
halves the signed-support potential of the resulting live types. -/
theorem packCopyBases_failure_halves_potential [Fintype ι]
    (v : ι → IntVec d) (c : ι → ℕ) (k : ℕ)
    (hfull : liveCountSpan ℝ (fun i => realVector (v i)) c = ⊤)
    (hshort : (packCopyBases (K := ℝ) (fun i => realVector (v i)) c k).length < k+1)
    (b : Fin d → ℕ) (hb : ∀ j, 1 ≤ b j)
    (hbox : ∀ i, 0 < c i → InCenteredBox b (v i)) (s mh : ℕ) (γ : ℝ)
    (hmh : 0 < mh) (hγ : 2*γ < (2*s+1:ℕ))
    (hvolume : (∏ j, (2*s*b j+1) : ℕ) ≤ γ*mh) :
    let bs := packCopyBases (K := ℝ) (fun i => realVector (v i)) c k
    let x := copyDebit c (packedLabels bs)
    let remaining := Finset.univ.filter (fun i => 0 < c i - x i)
    (∑ i, x i) ≤ d*k ∧
    2*(s • signedAlphabet (fun i : remaining => v i)).card < mh := by
  let bs := packCopyBases (K := ℝ) (fun i => realVector (v i)) c k
  let x := copyDebit c (packedLabels bs)
  let remaining := Finset.univ.filter (fun i => 0 < c i - x i)
  obtain ⟨_, _, hcard, hspan, _⟩ := packCopyBases_failure
    (K := ℝ) (fun i => realVector (v i)) c k hshort
  change (∑ i, x i) ≤ Module.finrank ℝ (liveCountSpan ℝ (fun i => realVector (v i)) c) * k at hcard
  change liveCountSpan ℝ (fun i => realVector (v i)) (fun i => c i - x i) <
    liveCountSpan ℝ (fun i => realVector (v i)) c at hspan
  rw [hfull] at hcard hspan
  have hproper : labelSpan ℝ (fun i => realVector (v i)) remaining ≠ ⊤ := ne_of_lt hspan
  have hbox' : ∀ i ∈ remaining, InCenteredBox b (v i) := by
    intro i hi
    have hi' : 0 < c i - x i := (Finset.mem_filter.mp hi).2
    exact hbox i (by omega)
  have hcount := proper_labelSpan_signedPotential_card_mul_le v remaining hproper b hb hbox' s
  refine ⟨?_, proper_subspace_count_lt_half _ mh s γ hmh hγ _ hcount hvolume⟩
  simpa using hcard

end Labelled

end
end Optss
