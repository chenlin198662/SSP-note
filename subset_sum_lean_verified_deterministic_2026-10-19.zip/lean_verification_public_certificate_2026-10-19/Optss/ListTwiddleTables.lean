import Optss.BooleanTwiddleRows

/-! Sequential construction of every twiddle row used by the list FFT.
Both the level schedule and each row's loop are lists; phase counters and
strides are explicit Boolean digits. -/
namespace Optss

def radixListFuel : List Bool → List Bool
  | [] => [false]
  | _::ns => let half := radixListFuel ns; half++half

def radixModulusDigits : List Bool → List Bool
  | [] => [true]
  | _::ns => false::radixModulusDigits ns

theorem radixListFuel_length (depth : List Bool) : (radixListFuel depth).length=2^depth.length := by
  induction depth with
  | nil => simp [radixListFuel]
  | cons b ns ih => simp [radixListFuel,ih,pow_succ]; omega

def radixListFuelWork : List Bool → ℕ
  | [] => 2
  | _::ns => radixListFuelWork ns+2*(radixListFuel ns).length+2

theorem radixListFuelWork_eq (depth : List Bool) : radixListFuelWork depth=2*2^depth.length+2*depth.length := by
  induction depth with
  | nil => rfl
  | cons b ns ih => simp only [radixListFuelWork,radixListFuel_length,List.length_cons,ih,pow_succ]; omega

theorem radixModulusDigits_length (depth : List Bool) : (radixModulusDigits depth).length=depth.length+1 := by
  induction depth <;> simp_all [radixModulusDigits]

theorem radixModulusDigits_value (depth : List Bool) : binaryDigitsValue (radixModulusDigits depth)=2^depth.length := by
  induction depth with
  | nil => simp [radixModulusDigits,binaryDigitsValue]
  | cons b ns ih => simp [radixModulusDigits,binaryDigitsValue,ih,pow_succ,Nat.mul_comm]

theorem fourierListSplit_even_length {α : Type*} (xs : List α) (m : ℕ) (hx : xs.length=2*m) :
    (fourierListSplit xs).1.length=m ∧ (fourierListSplit xs).2.length=m := by
  induction m generalizing xs with
  | zero =>
    have he : xs=[] := List.length_eq_zero_iff.mp (by omega)
    simp [he,fourierListSplit]
  | succ m ih =>
    cases xs with
    | nil => simp only [List.length_nil] at hx; omega
    | cons a ys =>
      cases ys with
      | nil => simp only [List.length_cons,List.length_nil] at hx; omega
      | cons b xs =>
        have hlen : xs.length=2*m := by simp only [List.length_cons] at hx; omega
        have h := ih xs hlen
        simpa only [fourierListSplit,List.length_cons] using
          And.intro (congrArg Nat.succ h.1) (congrArg Nat.succ h.2)

def bitTwiddleRows (ms : List Bool) (p : ℕ) (step : List Bool) :
    List Bool → List Bool → List (List BitFourierInteger)
  | [],_ => []
  | _::depth,fuel => bitCharacterRow ms p step fuel []::
      bitTwiddleRows ms p (false::step) depth (fourierListSplit fuel).1

def bitTwiddleRowsWork (ms : List Bool) (p : ℕ) (step : List Bool) :
    List Bool → List Bool → ℕ
  | [],_ => 1
  | _::depth,fuel => bitCharacterRowWork ms p step fuel []+
      bitTwiddleRowsWork ms p (false::step) depth (fourierListSplit fuel).1+4*fuel.length+5

/-- A mathematical description of the rows; it is not called by the answer. -/
def negativeTwiddleSpecification (ms : List Bool) (p : ℕ) (s : ℕ) : ℕ → List (List BitFourierInteger)
  | 0 => []
  | n+1 => List.ofFn (fun k : Fin (2^(n+1)) => bitNegativeCharacter (s*k.val).bits ms p)::
      negativeTwiddleSpecification ms p (2*s) n

theorem bitTwiddleRows_eq (ms step depth fuel : List Bool) (p : ℕ)
    (hf : fuel.length=2^depth.length) :
    bitTwiddleRows ms p step depth fuel=
      negativeTwiddleSpecification ms p (binaryDigitsValue step) depth.length := by
  induction depth generalizing step fuel with
  | nil => rfl
  | cons b depth ih =>
    have hhalf := (fourierListSplit_even_length fuel (2^depth.length) (by
      rw [hf,List.length_cons,pow_succ]; omega)).1
    rw [bitTwiddleRows,List.length_cons,negativeTwiddleSpecification]
    have hrow := bitCharacterRow_ofFn ms step fuel [] p (by simp [BitListCanonical,binaryDigitsValue])
    rw [hf] at hrow
    simp only [binaryDigitsValue,zero_add,List.length_cons] at hrow
    have hrow' : bitCharacterRow ms p step fuel []=List.ofFn
        (fun k : Fin (2^(depth.length+1)) => bitNegativeCharacter (binaryDigitsValue step*k.val).bits ms p) := by
      simpa only [Nat.mul_comm] using hrow
    rw [hrow',ih (false::step) _ hhalf]
    simp only [binaryDigitsValue,Bool.toNat_false,Nat.zero_add,Nat.add_zero]

theorem bitTwiddleRowsWork_bound {N : ℕ} [NeZero N] (ms step depth fuel : List Bool)
    (hM : binaryDigitsValue ms=N) (p L : ℕ) (hf : fuel.length=2^depth.length)
    (hm : ms.length≤L) (hs : step.length+depth.length≤L)
    (hbound : (2^depth.length*binaryDigitsValue step).size≤L) :
    bitTwiddleRowsWork ms p step depth fuel≤2^(depth.length+1)*
      (320*(L+1)^2+4194304*(N.size+p+72)^2*(characterWorkBits N (p+2)+1)^3+12) := by
  induction depth generalizing step fuel with
  | nil => simp only [bitTwiddleRowsWork,List.length_nil,zero_add,pow_one]; omega
  | cons b depth ih =>
    have hhalf := (fourierListSplit_even_length fuel (2^depth.length) (by
      rw [hf,List.length_cons,pow_succ]; omega)).1
    have hcap : (2^depth.length*binaryDigitsValue (false::step)).size≤L := by
      convert hbound using 1 <;> simp only [binaryDigitsValue,Bool.toNat_false,Nat.zero_add,List.length_cons,pow_succ] <;> congr 1 <;> ring
    have hi := ih (false::step) _ hhalf (by simp only [List.length_cons] at hs ⊢; omega) hcap
    have hrow := bitCharacterRowWork_bound ms step fuel [] hM p L
      (by simp [BitListCanonical,binaryDigitsValue]) hm (by omega)
      (by simpa only [binaryDigitsValue,zero_add,hf] using hbound)
    rw [bitTwiddleRowsWork,hf,List.length_cons]
    rw [hf,List.length_cons] at hrow
    have hp : 0<2^depth.length := Nat.pow_pos (by decide)
    simp only [pow_succ] at hrow hi ⊢
    nlinarith only [hi,hrow,hp]

def listDyadicTwiddleRows (depth : List Bool) (p : ℕ) : List (List BitFourierInteger) :=
  bitTwiddleRows (radixModulusDigits depth) p [true] depth (radixListFuel depth)

def listDyadicTwiddleRowsWork (depth : List Bool) (p : ℕ) : ℕ :=
  bitTwiddleRowsWork (radixModulusDigits depth) p [true] depth (radixListFuel depth)+
    radixListFuelWork depth+2*(depth.length+1)+2

theorem listDyadicTwiddleRowsWork_bound (depth : List Bool) (p : ℕ) :
    listDyadicTwiddleRowsWork depth p≤2^(depth.length+1)*
      (320*(depth.length+3)^2+4194304*((2^depth.length).size+p+72)^2*
        (characterWorkBits (2^depth.length) (p+2)+1)^3+16) := by
  have h := bitTwiddleRowsWork_bound (N:=2^depth.length) _ [true] depth _ (radixModulusDigits_value depth) p
    (depth.length+2) (radixListFuel_length depth)
    (by rw [radixModulusDigits_length]; omega)
    (by simp only [List.length_cons,List.length_nil]; omega)
    (by simp only [binaryDigitsValue,Bool.toNat_true,mul_zero,zero_add,mul_one,Nat.size_pow]; omega)
  have hn : depth.length<2^depth.length := Nat.lt_two_pow_self
  have hfwork := radixListFuelWork_eq depth
  unfold listDyadicTwiddleRowsWork
  rw [pow_succ]
  rw [pow_succ] at h
  nlinarith only [h,hn,hfwork]

end Optss
