import Optss.BooleanLatticeFrontendSpec
import Optss.RationalLatticeReduction

/-!
# Pulling the actual reduced columns back to the original full lattice

The executable step transposes the stored reduced rows and multiplies by
the selected vertex matrix. The proof maps equality of entire rational
integer spans, so a finite-index sublattice cannot be substituted.
-/
namespace Optss
open scoped BigOperators
variable {r : ℕ}

def rationalVectorRealCast (r : ℕ) : (Fin r → ℚ) →ₗ[ℤ] (Fin r → ℝ) where
  toFun x i := (x i:ℝ)
  map_add' x y := by ext i; simp
  map_smul' n x := by ext i; simp

theorem rational_rows_pullback_span (A G R : Matrix (Fin r) (Fin r) ℚ)
    (hA : A.det≠0)
    (hspan : Submodule.span ℤ (Set.range R)=Submodule.span ℤ (Set.range (A⁻¹*G).transpose)) :
    Submodule.span ℤ (Set.range (A*R.transpose).transpose)=Submodule.span ℤ (Set.range G.transpose) := by
  let f : (Fin r → ℚ) →ₗ[ℤ] (Fin r → ℚ) := (Matrix.mulVecLin A).restrictScalars ℤ
  have h := congrArg (Submodule.map f) hspan
  simp only [Submodule.map_span,←Set.range_comp] at h
  have hl : f ∘ R=(A*R.transpose).transpose := by ext i j; rfl
  have hr : f ∘ (A⁻¹*G).transpose=G.transpose := by
    change (A*(A⁻¹*G)).transpose=G.transpose
    rw [←Matrix.mul_assoc,Matrix.mul_nonsing_inv A (isUnit_iff_ne_zero.mpr hA),Matrix.one_mul]
  rw [hl,hr] at h
  exact h

theorem rational_basis_lattice_of_column_span (B G : Matrix (Fin r) (Fin r) ℚ)
    (b : Basis (Fin r) ℝ (Fin r → ℝ)) (hb : ∀ i j,(B i j:ℝ)=b j i)
    (hspan : Submodule.span ℤ (Set.range B.transpose)=Submodule.span ℤ (Set.range G.transpose)) :
    basisIntegerLattice b=(Submodule.span ℤ (Set.range (fun j i => (G i j:ℝ))) : Set (Fin r → ℝ)) := by
  have h := congrArg (Submodule.map (rationalVectorRealCast r)) hspan
  simp only [Submodule.map_span,←Set.range_comp] at h
  have hb' : (rationalVectorRealCast r) ∘ B.transpose=⇑b := by
    ext j i
    exact hb i j
  rw [hb'] at h
  rw [basisIntegerLattice_eq_integerSpan]
  exact congrArg (fun M : Submodule ℤ (Fin r → ℝ) => (M:Set (Fin r → ℝ))) h

theorem basisEuclideanNormalization_symm_coordinates
    (b : Basis (Fin r) ℝ (Fin r → ℝ)) (y : EuclideanSpace ℝ (Fin r)) (i : Fin r) :
    (basisEuclideanNormalization b).symm y i=∑ j,b j i*y j := by
  change b.equivFun.symm (fun j => y j) i=_
  rw [Basis.equivFun_symm_apply]
  simp only [Finset.sum_apply,Pi.smul_apply,smul_eq_mul,mul_comm]

def booleanLatticePullback (A R : ListBitRationalMatrixData r r) : ListBitRationalMatrixData r r :=
  constructedListMatrixMul A (listStoredMatrixTranspose R)

def booleanLatticePullbackWork (A R : ListBitRationalMatrixData r r) : ℕ :=
  listStoredMatrixTransposeWork R+constructedListMatrixMulWork A (listStoredMatrixTranspose R)+1

theorem booleanLatticePullback_value (A R : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hR : ∀ i j,(rectangularListFractionMatrix R i j).WellFormed) :
    storedRationalMatrix (booleanLatticePullback A R)=storedRationalMatrix A*(storedRationalMatrix R).transpose := by
  rw [booleanLatticePullback,storedRationalMatrix_mul A _ hA (listStoredMatrixTranspose_wellFormed R hR),
    storedRationalMatrix_transpose]

/-- The physically constructed output columns are an actual basis of exactly
the original input lattice, and normalize to the actual reduced basis. -/
theorem booleanLatticePullback_basis
    (A R : ListBitRationalMatrixData r r) (G : Matrix (Fin r) (Fin r) ℚ)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hR : ∀ i j,(rectangularListFractionMatrix R i j).WellFormed)
    (a : Basis (Fin r) ℝ (Fin r → ℝ)) (ha : ∀ i j,(storedRationalMatrix A i j:ℝ)=a j i)
    (reduced : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)))
    (hred : ∀ j,reduced j=rationalEuclideanRows (storedRationalMatrix R) j)
    (hspan : Submodule.span ℤ (Set.range (storedRationalMatrix R))=
      Submodule.span ℤ (Set.range ((storedRationalMatrix A)⁻¹*G).transpose)) :
    ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
      (∀ i j,(storedRationalMatrix (booleanLatticePullback A R) i j:ℝ)=b j i) ∧
      b.map (basisEuclideanNormalization a).toLinearEquiv=reduced ∧
      basisIntegerLattice b=(Submodule.span ℤ (Set.range (fun j i => (G i j:ℝ))) : Set (Fin r → ℝ)) := by
  let b := reduced.map (basisEuclideanNormalization a).symm.toLinearEquiv
  have hcolumns : ∀ i j,(storedRationalMatrix (booleanLatticePullback A R) i j:ℝ)=b j i := by
    intro i j
    rw [booleanLatticePullback_value A R hA hR]
    change ((storedRationalMatrix A*(storedRationalMatrix R).transpose) i j:ℝ)=
      (basisEuclideanNormalization a).symm (reduced j) i
    rw [basisEuclideanNormalization_symm_coordinates,hred j]
    simp only [Matrix.mul_apply,Matrix.transpose_apply,Rat.cast_sum,Rat.cast_mul,ha]
    rfl
  refine ⟨b,hcolumns,?_,?_⟩
  · ext j i
    change (basisEuclideanNormalization a) ((basisEuclideanNormalization a).symm (reduced j)) i=reduced j i
    rw [ContinuousLinearEquiv.apply_symm_apply]
  · apply rational_basis_lattice_of_column_span _ G b hcolumns
    rw [booleanLatticePullback_value A R hA hR]
    exact rational_rows_pullback_span _ G _ (rational_basis_inverse a (storedRationalMatrix A) ha).1 hspan
end Optss
