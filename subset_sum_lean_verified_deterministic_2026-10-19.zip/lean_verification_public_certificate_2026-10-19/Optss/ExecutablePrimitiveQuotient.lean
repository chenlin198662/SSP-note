import Optss.ExecutableGcdElimination

/-!
# Constructive primitive quotient from a nonzero integer relation

The quotient and its section are computed by the explicit extended-gcd
coordinate elimination. The kernel is exactly the primitive integer line,
its real extension has exactly the corresponding real kernel, and the
entire lower-dimensional integer lattice is reached.
-/
namespace Optss
variable {d : ℕ}

def executableDirectionSplit (z : Fin (d+1)→ℤ) :
    (Fin (d+1)→ℤ) ≃ₗ[ℤ] (ℤ×(Fin d→ℤ)) :=
  (integerDirectionEquiv z).trans (Fin.consLinearEquiv ℤ (fun _ : Fin (d+1) => ℤ)).symm

def executablePrimitiveDirection (z : Fin (d+1)→ℤ) : Fin (d+1)→ℤ :=
  (executableDirectionSplit z).symm (1,0)

def executableDirectionFactor (z : Fin (d+1)→ℤ) : ℤ := (executableDirectionSplit z z).1

def executableBezout (z : Fin (d+1)→ℤ) : (Fin (d+1)→ℤ) →ₗ[ℤ] ℤ :=
  (LinearMap.fst ℤ ℤ (Fin d→ℤ)).comp (executableDirectionSplit z).toLinearMap

def executablePrimitiveQuotient (z : Fin (d+1)→ℤ) : (Fin (d+1)→ℤ) →ₗ[ℤ] (Fin d→ℤ) :=
  (LinearMap.snd ℤ ℤ (Fin d→ℤ)).comp (executableDirectionSplit z).toLinearMap

def executablePrimitiveLift (z : Fin (d+1)→ℤ) : (Fin d→ℤ) →ₗ[ℤ] (Fin (d+1)→ℤ) :=
  (executableDirectionSplit z).symm.toLinearMap.comp (LinearMap.inr ℤ ℤ (Fin d→ℤ))

@[simp] theorem executableDirectionSplit_primitive (z : Fin (d+1)→ℤ) :
    executableDirectionSplit z (executablePrimitiveDirection z)=(1,0) :=
  (executableDirectionSplit z).apply_symm_apply _

@[simp] theorem executableDirectionSplit_lift (z : Fin (d+1)→ℤ) (y : Fin d→ℤ) :
    executableDirectionSplit z (executablePrimitiveLift z y)=(0,y) :=
  (executableDirectionSplit z).apply_symm_apply _

@[simp] theorem executableBezout_primitive (z : Fin (d+1)→ℤ) :
    executableBezout z (executablePrimitiveDirection z)=1 :=
  congrArg Prod.fst (executableDirectionSplit_primitive z)

@[simp] theorem executablePrimitiveQuotient_primitive (z : Fin (d+1)→ℤ) :
    executablePrimitiveQuotient z (executablePrimitiveDirection z)=0 :=
  congrArg Prod.snd (executableDirectionSplit_primitive z)

@[simp] theorem executablePrimitiveQuotient_lift (z : Fin (d+1)→ℤ) (y : Fin d→ℤ) :
    executablePrimitiveQuotient z (executablePrimitiveLift z y)=y :=
  congrArg Prod.snd (executableDirectionSplit_lift z y)

@[simp] theorem executablePrimitiveQuotient_direction (z : Fin (d+1)→ℤ) :
    executablePrimitiveQuotient z z=0 := by
  funext j
  exact integerDirectionEquiv_tail z j

theorem executablePrimitiveQuotient_surjective (z : Fin (d+1)→ℤ) :
    Function.Surjective (executablePrimitiveQuotient z) :=
  fun y => ⟨executablePrimitiveLift z y,executablePrimitiveQuotient_lift z y⟩

/-- Exact splitting for every integer vector, not just the input relation. -/
theorem executablePrimitiveQuotient_decomposition (z x : Fin (d+1)→ℤ) :
    x=executableBezout z x •executablePrimitiveDirection z+
      executablePrimitiveLift z (executablePrimitiveQuotient z x) := by
  apply (executableDirectionSplit z).injective
  rw [map_add,map_smul,executableDirectionSplit_primitive,executableDirectionSplit_lift]
  apply Prod.ext <;> simp [executableBezout,executablePrimitiveQuotient]

theorem executablePrimitiveDirection_factorization (z : Fin (d+1)→ℤ) :
    z=executableDirectionFactor z •executablePrimitiveDirection z := by
  simpa only [executablePrimitiveQuotient_direction,map_zero,add_zero] using
    executablePrimitiveQuotient_decomposition z z

theorem executableDirectionFactor_ne_zero (z : Fin (d+1)→ℤ) (hz : z≠0) :
    executableDirectionFactor z≠0 := by
  intro h
  have he := executablePrimitiveDirection_factorization z
  rw [h,zero_smul] at he
  exact hz he

theorem executablePrimitiveDirection_ne_zero (z : Fin (d+1)→ℤ) :
    executablePrimitiveDirection z≠0 := by
  intro h
  have he := executableBezout_primitive z
  rw [h,map_zero] at he
  exact zero_ne_one he

theorem executablePrimitiveDirection_abs_le (z : Fin (d+1)→ℤ) (hz : z≠0) (j : Fin (d+1)) :
    |executablePrimitiveDirection z j|≤|z j| := by
  have he := congrFun (executablePrimitiveDirection_factorization z) j
  have hg := Int.one_le_abs (executableDirectionFactor_ne_zero z hz)
  change z j=executableDirectionFactor z*executablePrimitiveDirection z j at he
  rw [he,abs_mul]
  nlinarith [abs_nonneg (executablePrimitiveDirection z j)]

theorem executablePrimitiveQuotient_ker (z : Fin (d+1)→ℤ) :
    LinearMap.ker (executablePrimitiveQuotient z)=Submodule.span ℤ {executablePrimitiveDirection z} := by
  ext x
  rw [LinearMap.mem_ker,Submodule.mem_span_singleton]
  constructor
  · intro hx
    refine ⟨executableBezout z x,?_⟩
    have he := executablePrimitiveQuotient_decomposition z x
    rw [hx,map_zero,add_zero] at he
    exact he.symm
  · rintro ⟨a,rfl⟩
    rw [map_smul,executablePrimitiveQuotient_primitive,smul_zero]

/-- The computed quotient reaches all integer points, hence its actual
integer matrix also gives a surjective real quotient. -/
theorem executablePrimitiveQuotient_real_surjective (z : Fin (d+1)→ℤ) :
    Function.Surjective (integerMapRealExtension (executablePrimitiveQuotient z)) :=
  integerMapRealExtension_surjective _ (executablePrimitiveQuotient_surjective z)

theorem executablePrimitiveQuotient_real_ker (z : Fin (d+1)→ℤ) :
    LinearMap.ker (integerMapRealExtension (executablePrimitiveQuotient z))=
      Submodule.span ℝ {realVector (executablePrimitiveDirection z)} := by
  have hrealnz : realVector (executablePrimitiveDirection z)≠0 := by
    intro he
    apply executablePrimitiveDirection_ne_zero z
    ext i
    have hi := congrFun he i
    change (executablePrimitiveDirection z i:ℝ)=0 at hi
    exact_mod_cast hi
  have hpk : realVector (executablePrimitiveDirection z)∈
      LinearMap.ker (integerMapRealExtension (executablePrimitiveQuotient z)) := by
    rw [LinearMap.mem_ker,integerMapRealExtension_cast,executablePrimitiveQuotient_primitive,map_zero]
  have hle : Submodule.span ℝ {realVector (executablePrimitiveDirection z)}≤
      LinearMap.ker (integerMapRealExtension (executablePrimitiveQuotient z)) :=
    Submodule.span_le.mpr (by simpa using hpk)
  have hrank := (integerMapRealExtension (executablePrimitiveQuotient z)).finrank_range_add_finrank_ker
  rw [LinearMap.range_eq_top.mpr (executablePrimitiveQuotient_real_surjective z)] at hrank
  simp only [finrank_top,Module.finrank_fin_fun] at hrank
  have hker : Module.finrank ℝ (LinearMap.ker (integerMapRealExtension (executablePrimitiveQuotient z)))=1 := by omega
  exact (Submodule.eq_of_le_of_finrank_eq hle (by rw [finrank_span_singleton hrealnz,hker])).symm

def executableDescendedHom {G : Type*} [AddCommGroup G] (z : Fin (d+1)→ℤ)
    (ρ : (Fin (d+1)→ℤ) →+ G) : (Fin d→ℤ) →+ G :=
  ρ.comp (executablePrimitiveLift z).toAddMonoidHom

theorem executableDescendedHom_quotient {G : Type*} [AddCommGroup G] [IsAddTorsionFree G]
    (z : Fin (d+1)→ℤ) (hz : z≠0) (ρ : (Fin (d+1)→ℤ) →+ G) (hρ : ρ z=0)
    (x : Fin (d+1)→ℤ) :
    executableDescendedHom z ρ (executablePrimitiveQuotient z x)=ρ x := by
  have hp := primitive_divisor_mem_add_kernel ρ z (executablePrimitiveDirection z)
    (executableDirectionFactor z) (executableDirectionFactor_ne_zero z hz)
    (executablePrimitiveDirection_factorization z) hρ
  have he := congrArg ρ (executablePrimitiveQuotient_decomposition z x)
  simpa only [map_add,map_zsmul,hp,smul_zero,zero_add] using he.symm
end Optss
