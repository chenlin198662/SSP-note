import Optss.BooleanLatticeFrontendSpec
import Optss.UniformMatrixProductWork

/-!
# One original-input polynomial for normalization followed by LLL

The vertex count is absorbed by the literal framed vertex input size in
positive rank. Every intermediate inverse/product input size is derived from
the original encodings before applying the actual list-reduction work bound.
-/
namespace Optss
open scoped BigOperators
variable {r m : ℕ}

noncomputable def frontendNormalizedLatticeSize (r : ℕ) : Polynomial ℕ :=
  Polynomial.C r+Polynomial.C (r*r)*
    (1+2*Polynomial.C (r+1)*(2*computedBasisIntermediateSize r+2))

noncomputable def frontendFromBasisPolynomial (r : ℕ) : Polynomial ℕ :=
  constructedInversePolynomial r+
    2*uniformMatrixProductPolynomial.comp (computedBasisIntermediateSize r)+
    (matrixTransposePolynomial r r).comp (frontendNormalizedLatticeSize r)+
    listStoredRationalTotalPolynomial.comp (frontendNormalizedLatticeSize r)+6

theorem booleanLatticeFrontendFromBasisWork_polynomial (hr : 0<r)
    (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetA : (storedRationalMatrix A).det≠0) (hdetG : (storedRationalMatrix G).det≠0)
    (N : ℕ) (hN : listStoredRationalBits A+listStoredRationalBits V+listStoredRationalBits G≤N) :
    booleanLatticeFrontendFromBasisWork A V G≤(frontendFromBasisPolynomial r).eval N := by
  let C := constructedListMatrixInverse A
  let M := constructedListMatrixMul C G
  let T := listStoredMatrixTranspose M
  let K := (computedBasisIntermediateSize r).eval N
  have hAn : listStoredRationalBits A≤N := by omega
  have hVn : listStoredRationalBits V≤N := by omega
  have hGn : listStoredRationalBits G≤N := by omega
  have hrN : r≤N := (listStoredRationalBits_rank A).trans hAn
  have hmN : m≤N := (listStoredRationalBits_vertices hr V).trans hVn
  have hNK : N≤K := by
    simp only [K,computedBasisIntermediateSize,Polynomial.eval_add,Polynomial.eval_mul,
      Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat]
    omega
  have hC := constructedListMatrixInverse_wellFormed A hA
  have hCb := constructedListMatrixInverse_bits A hA
  have hCsize : listStoredRationalBits C+N≤K := by
    change listStoredRationalBits (constructedListMatrixInverse A)+N≤_
    simp only [K,computedBasisIntermediateSize,Polynomial.eval_add,Polynomial.eval_mul,
      Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat]
    apply Nat.add_le_add_right (hCb.trans ?_) N
    gcongr
  have hM := constructedListMatrixMul_wellFormed C G hC hG
  have hT := listStoredMatrixTranspose_wellFormed M hM
  have hi := storedRationalRows_independent T (frontend_normalized_lattice_det A G hA hG hdetA hdetG)
  have hCfields : ∀ i j,(rectangularListFractionMatrix C i j).numerator.length≤K ∧
      (rectangularListFractionMatrix C i j).denominator.length≤K := by
    intro i j
    have h := listStoredRationalBits_cell C i j
    exact ⟨h.1.trans (by omega),h.2.trans (by omega)⟩
  have hGfields : ∀ i j,(rectangularListFractionMatrix G i j).numerator.length≤K ∧
      (rectangularListFractionMatrix G i j).denominator.length≤K := by
    intro i j
    have h := listStoredRationalBits_cell G i j
    exact ⟨h.1.trans (hGn.trans hNK),h.2.trans (hGn.trans hNK)⟩
  have hMsize : listStoredRationalBits M≤(frontendNormalizedLatticeSize r).eval N := by
    have h := listStoredRationalBits_le_of_lengths M ((r+1)*(2*K+2))
      (constructedListMatrixMul_lengths C G hC hG K hCfields hGfields)
    simp only [frontendNormalizedLatticeSize,Polynomial.eval_add,Polynomial.eval_mul,
      Polynomial.eval_C,Polynomial.eval_one,Polynomial.eval_ofNat]
    change _≤r+r*r*(1+2*(r+1)*(2*K+2))
    convert h using 1; ring
  have hTsize : listStoredRationalBits T≤(frontendNormalizedLatticeSize r).eval N := by
    rw [listStoredMatrixTranspose_square_bits]
    exact hMsize
  have hwi := (constructedListMatrixInverseWork_input_polynomial A hA).trans
    (natPolynomial_eval_mono (constructedInversePolynomial r) hAn)
  have hwV := constructedListMatrixMulWork_uniform C V hC hV K
    (hrN.trans hNK) (hrN.trans hNK) (hmN.trans hNK) (by omega)
  have hwG := constructedListMatrixMulWork_uniform C G hC hG K
    (hrN.trans hNK) (hrN.trans hNK) (hrN.trans hNK) (by omega)
  have hwt := (listStoredMatrixTransposeWork_input_polynomial M).trans
    (natPolynomial_eval_mono (matrixTransposePolynomial r r) hMsize)
  have hwL := (listStoredRationalTotalWork_input_size T hT hi).trans
    (natPolynomial_eval_mono listStoredRationalTotalPolynomial hTsize)
  change constructedListMatrixInverseWork A+constructedListMatrixMulWork C V+
    constructedListMatrixMulWork C G+listStoredMatrixTransposeWork M+
    listStoredRationalTotalWork T+6≤_
  simp only [frontendFromBasisPolynomial,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_ofNat,Polynomial.eval_comp]
  change _≤(constructedInversePolynomial r).eval N+2*uniformMatrixProductPolynomial.eval K+
    (matrixTransposePolynomial r r).eval ((frontendNormalizedLatticeSize r).eval N)+
    listStoredRationalTotalPolynomial.eval ((frontendNormalizedLatticeSize r).eval N)+6
  omega

noncomputable def selectedVertexMatrixSize (r : ℕ) : Polynomial ℕ :=
  Polynomial.C r+Polynomial.C (r*r)*(1+2*Polynomial.X)

noncomputable def booleanLatticeFrontendPolynomial (r : ℕ) : Polynomial ℕ :=
  selectedVertexMatrixPolynomial r+
    (frontendFromBasisPolynomial r).comp (selectedVertexMatrixSize r+Polynomial.X)+1

/-- Actual Boolean/list normalization plus actual list-stored lattice
reduction has polynomial source work in the two original framed inputs.
The polynomial depends on the fixed rank, not on the number of vertices. -/
theorem booleanLatticeFrontendWork_input_polynomial (hr : 0<r)
    (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetG : (storedRationalMatrix G).det≠0)
    (hspan : Submodule.span ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))=⊤) :
    booleanLatticeFrontendWork V G≤(booleanLatticeFrontendPolynomial r).eval
      (listStoredRationalBits V+listStoredRationalBits G) := by
  let N := listStoredRationalBits V+listStoredRationalBits G
  have hs := bitSelectedVertexMatrixWork_polynomial V hV N
    ((listStoredRationalBits_vertices hr V).trans (by dsimp [N]; omega)) (by dsimp [N]; omega)
  simp only [booleanLatticeFrontendPolynomial,Polynomial.eval_add,Polynomial.eval_comp,
    Polynomial.eval_X,Polynomial.eval_one]
  change _≤(selectedVertexMatrixPolynomial r).eval N+
    (frontendFromBasisPolynomial r).eval ((selectedVertexMatrixSize r).eval N+N)+1
  unfold booleanLatticeFrontendWork
  cases he : bitSelectedVertexMatrix V with
  | none =>
    change bitSelectedVertexMatrixWork V+1≤_
    omega
  | some A =>
    have hA := bitSelectedVertexMatrix_wellFormed V hV A he
    have hdetA := bitSelectedVertexMatrix_det_ne_zero V hV hspan A he
    have hb := bitSelectedVertexMatrix_lengths V N (by
      intro i j
      have h := listStoredRationalBits_cell V i j
      exact ⟨h.1.trans (by dsimp [N]; omega),h.2.trans (by dsimp [N]; omega)⟩) A he
    have hAsize : listStoredRationalBits A≤(selectedVertexMatrixSize r).eval N := by
      simpa only [selectedVertexMatrixSize,Polynomial.eval_add,Polynomial.eval_mul,
        Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat] using
        listStoredRationalBits_le_of_lengths A N hb
    have hw := booleanLatticeFrontendFromBasisWork_polynomial hr A V G hA hV hG hdetA hdetG
      ((selectedVertexMatrixSize r).eval N+N) (by
        rw [Nat.add_assoc]
        change listStoredRationalBits A+N≤(selectedVertexMatrixSize r).eval N+N
        exact Nat.add_le_add_right hAsize N)
    change bitSelectedVertexMatrixWork V+(booleanLatticeFrontendFromBasisWork A V G+1)≤_
    exact (Nat.add_le_add hs (Nat.add_le_add_right hw 1)).trans (by omega)
end Optss
