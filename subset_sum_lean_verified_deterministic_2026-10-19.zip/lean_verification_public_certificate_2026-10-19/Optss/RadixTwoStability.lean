import Optss.RadixTwoTransform

/-! Explicit norm and perturbation bounds for the materialized butterfly
algorithm. These bounds concern its actual recursive output arrays. -/
namespace Optss

theorem radixTwoTransform_norm_bound (T : ℕ → ℕ → ℂ) (n : ℕ)
    (A : Vector ℂ (2^n)) (B C : ℝ) (hB : 0≤B) (hC : 0≤C)
    (hA : ∀ j, ‖A.get j‖≤B) (hT : ∀ l<n, ∀ k, ‖T l k‖≤C) (k : Fin (2^n)) :
    ‖(radixTwoTransform T n A).get k‖≤(1+C)^n*B := by
  induction n with
  | zero => simpa [radixTwoTransform] using hA k
  | succ n ih =>
    have he := ih (radixEvenData n A)
      (fun j => by simpa only [radixEvenData,vector_get_ofFn] using hA (radixEvenIndex n j))
      (fun l hl j => hT l (by omega) j) (radixModIndex n k)
    have ho := ih (radixOddData n A)
      (fun j => by simpa only [radixOddData,vector_get_ofFn] using hA (radixOddIndex n j))
      (fun l hl j => hT l (by omega) j) (radixModIndex n k)
    simp only [radixTwoTransform,vector_get_ofFn]
    calc
      _ ≤ ‖(radixTwoTransform T n (radixEvenData n A)).get (radixModIndex n k)‖+
          ‖T n k.val‖*‖(radixTwoTransform T n (radixOddData n A)).get (radixModIndex n k)‖ :=
        (norm_add_le _ _).trans_eq (by rw [norm_mul])
      _ ≤ (1+C)^n*B+C*((1+C)^n*B) := by gcongr; exact hT n (by omega) k.val
      _ = _ := by rw [pow_succ]; ring

theorem complex_butterfly_error (e e' o o' t s : ℂ) :
    ‖(e+t*o)-(e'+s*o')‖≤‖e-e'‖+‖t‖*‖o-o'‖+‖t-s‖*‖o'‖ := by
  have he : (e+t*o)-(e'+s*o')=(e-e')+t*(o-o')+(t-s)*o' := by ring
  rw [he]
  calc
    _ ≤ ‖(e-e')+t*(o-o')‖+‖(t-s)*o'‖ := norm_add_le _ _
    _ ≤ (‖e-e'‖+‖t*(o-o')‖)+‖(t-s)*o'‖ := add_le_add_right (norm_add_le _ _) _
    _ = _ := by rw [norm_mul,norm_mul]

/-- Twiddle errors amplify by an explicit polynomial in the transform length.
The exponent 3^n is deliberately loose; only logarithmically many additional
precision bits are required. -/
theorem radixTwoTransform_error (T S : ℕ → ℕ → ℂ) (n : ℕ)
    (A : Vector ℂ (2^n)) (B ε : ℝ) (hB : 0≤B) (hε : 0≤ε) (hε₁ : ε≤1)
    (hA : ∀ j, ‖A.get j‖≤B) (hS : ∀ l<n, ∀ k, ‖S l k‖≤1)
    (hTS : ∀ l<n, ∀ k, ‖T l k-S l k‖≤ε) (k : Fin (2^n)) :
    ‖(radixTwoTransform T n A).get k-(radixTwoTransform S n A).get k‖≤
      (n : ℝ)*3^n*ε*B := by
  induction n with
  | zero => simp [radixTwoTransform]
  | succ n ih =>
    have hE (j : Fin (2^n)) : ‖(radixEvenData n A).get j‖≤B := by
      simpa only [radixEvenData,vector_get_ofFn] using hA (radixEvenIndex n j)
    have hO (j : Fin (2^n)) : ‖(radixOddData n A).get j‖≤B := by
      simpa only [radixOddData,vector_get_ofFn] using hA (radixOddIndex n j)
    have hS' : ∀ l<n, ∀ k, ‖S l k‖≤1 := fun l hl k => hS l (by omega) k
    have hTS' : ∀ l<n, ∀ k, ‖T l k-S l k‖≤ε := fun l hl k => hTS l (by omega) k
    have he := ih (radixEvenData n A) hE hS' hTS' (radixModIndex n k)
    have ho := ih (radixOddData n A) hO hS' hTS' (radixModIndex n k)
    have hnorm : ‖(radixTwoTransform S n (radixOddData n A)).get (radixModIndex n k)‖≤
        (2 : ℝ)^n*B := by
      simpa only [show (1 : ℝ)+1=2 by norm_num] using
        radixTwoTransform_norm_bound S n (radixOddData n A) B 1 hB (by norm_num) hO hS' (radixModIndex n k)
    have ht : ‖T n k.val‖≤2 := by
      have h := norm_sub_norm_le (T n k.val) (S n k.val)
      have hh := hTS n (by omega) k.val
      have hs := hS n (by omega) k.val
      linarith
    simp only [radixTwoTransform,vector_get_ofFn]
    apply (complex_butterfly_error _ _ _ _ _ _).trans
    calc
      _ ≤ ((n : ℝ)*3^n*ε*B)+2*((n : ℝ)*3^n*ε*B)+ε*((2 : ℝ)^n*B) := by
        gcongr
        exact hTS n (by omega) k.val
      _ ≤ ((n : ℝ)*3^n*ε*B)+2*((n : ℝ)*3^n*ε*B)+ε*((3 : ℝ)^n*B) := by
        gcongr
        norm_num
      _ = (3*(n : ℝ)+1)*(3^n*ε*B) := by ring
      _ ≤ (3*((n : ℝ)+1))*(3^n*ε*B) :=
        mul_le_mul_of_nonneg_right (by linarith) (by positivity)
      _ = _ := by rw [pow_succ]; push_cast; ring

end Optss
