import Optss.BitListExtendedGcdWork
import Optss.ExecutableGcdElimination

/-!
# Stored Boolean Bézout coordinate updates

The four entries of a two-coordinate unimodular matrix are computed once,
using Boolean extended gcd and exact signed division. Forward and inverse
applications then use only Boolean signed multiplication and addition. The
specification identifies these literal operations with `integerGcdPairEquiv`.
-/
namespace Optss

def bitListIntegerExactQuotient (x : BitListInteger) (ds : List Bool) : BitListInteger :=
  ⟨x.negative,(bitListDivision x.digits ds).quotient⟩

theorem bitListIntegerExactQuotient_value (x : BitListInteger) (ds : List Bool)
    (hd : 0<binaryDigitsValue ds) (hdiv : binaryDigitsValue ds∣binaryDigitsValue x.digits) :
    (bitListIntegerExactQuotient x ds).value=x.value/(binaryDigitsValue ds:ℤ) := by
  have he := (bitListDivision_correct x.digits ds hd).1
  have hid : (binaryDigitsValue ds:ℤ)∣(binaryDigitsValue x.digits:ℤ) := by exact_mod_cast hdiv
  cases hx : x.negative <;>
    simp only [bitListIntegerExactQuotient,BitListInteger.value,signedBitsValue,hx,he,
      Bool.false_eq_true,ite_false,ite_true,Int.natCast_ediv]
  exact (Int.neg_ediv_of_dvd hid).symm

theorem canonical_isEmpty_iff_zero (xs : List Bool) (hc : BitListCanonical xs) :
    xs.isEmpty=true ↔ binaryDigitsValue xs=0 := by
  constructor
  · intro h
    rw [List.isEmpty_iff.mp h]
    rfl
  · intro h
    have he : xs=[] := by
      change xs=(binaryDigitsValue xs).bits at hc
      rw [h] at hc
      simpa only [Nat.zero_bits] using hc
    simp only [he,List.isEmpty_nil]

structure BitListGcdPairMatrix where
  a : BitListInteger
  b : BitListInteger
  c : BitListInteger
  d : BitListInteger
  deriving Repr

def BitListGcdPairMatrix.value (M : BitListGcdPairMatrix) : ℤ×ℤ×ℤ×ℤ :=
  (M.a.value,M.b.value,M.c.value,M.d.value)

def bitListGcdPairMatrix (x y : BitListInteger) : BitListGcdPairMatrix :=
  let out := bitListIntegerXgcd x y
  let gs := bitListTrim out.gcdDigits
  if gs.isEmpty then
    ⟨bitListNonnegativeInteger [true],bitListNonnegativeInteger [],
     bitListNonnegativeInteger [],bitListNonnegativeInteger [true]⟩
  else
    ⟨out.left,out.right,bitListIntegerNeg (bitListIntegerExactQuotient y gs),
      bitListIntegerExactQuotient x gs⟩

theorem bitListGcdPairMatrix_bits (x y : ℤ) :
    (bitListGcdPairMatrix (integerBitRepresentation x) (integerBitRepresentation y)).value=
      if Int.gcd x y=0 then (1,0,0,1) else
        (Int.gcdA x y,Int.gcdB x y,-(y/(Int.gcd x y:ℤ)),x/(Int.gcd x y:ℤ)) := by
  let X := integerBitRepresentation x
  let Y := integerBitRepresentation y
  let out := bitListIntegerXgcd X Y
  let gs := bitListTrim out.gcdDigits
  have he := bitListIntegerXgcd_bits x y
  have hg : binaryDigitsValue gs=Int.gcd x y := by
    change binaryDigitsValue (bitListTrim out.gcdDigits)=_
    rw [bitListTrim_value]
    exact congrArg Prod.fst he
  have hl : out.left.value=Int.gcdA x y := congrArg (fun z : ℕ×ℤ×ℤ => z.2.1) he
  have hr : out.right.value=Int.gcdB x y := congrArg (fun z : ℕ×ℤ×ℤ => z.2.2) he
  have hz : gs.isEmpty=true ↔ Int.gcd x y=0 :=
    (canonical_isEmpty_iff_zero gs (bitListTrim_canonical _)).trans (by rw [hg])
  change (if gs.isEmpty then
    (⟨bitListNonnegativeInteger [true],bitListNonnegativeInteger [],
      bitListNonnegativeInteger [],bitListNonnegativeInteger [true]⟩ : BitListGcdPairMatrix)
    else ⟨out.left,out.right,bitListIntegerNeg (bitListIntegerExactQuotient Y gs),
      bitListIntegerExactQuotient X gs⟩).value=_
  by_cases h0 : Int.gcd x y=0
  · rw [if_pos (hz.mpr h0),if_pos h0]
    rfl
  · rw [if_neg (mt hz.mp h0),if_neg h0]
    have hgp : 0<binaryDigitsValue gs := hg ▸ Nat.pos_of_ne_zero h0
    have hdx : binaryDigitsValue gs∣binaryDigitsValue X.digits := by
      rw [hg]
      change Nat.gcd x.natAbs y.natAbs∣binaryDigitsValue x.natAbs.bits
      rw [binaryDigitsValue_bits]
      exact Nat.gcd_dvd_left _ _
    have hdy : binaryDigitsValue gs∣binaryDigitsValue Y.digits := by
      rw [hg]
      change Nat.gcd x.natAbs y.natAbs∣binaryDigitsValue y.natAbs.bits
      rw [binaryDigitsValue_bits]
      exact Nat.gcd_dvd_right _ _
    change (out.left.value,out.right.value,(bitListIntegerNeg (bitListIntegerExactQuotient Y gs)).value,
      (bitListIntegerExactQuotient X gs).value)=_
    rw [hl,hr,bitListIntegerNeg_value,bitListIntegerExactQuotient_value Y gs hgp hdy,
      bitListIntegerExactQuotient_value X gs hgp hdx,hg,integerBitRepresentation_value,integerBitRepresentation_value]

def bitListGcdPairApply (M : BitListGcdPairMatrix) (u v : BitListInteger) :
    BitListInteger×BitListInteger :=
  (bitListIntegerAdd (bitListIntegerMul M.a u) (bitListIntegerMul M.b v),
   bitListIntegerAdd (bitListIntegerMul M.c u) (bitListIntegerMul M.d v))

def bitListGcdPairInverseApply (M : BitListGcdPairMatrix) (u v : BitListInteger) :
    BitListInteger×BitListInteger :=
  (bitListIntegerSub (bitListIntegerMul M.d u) (bitListIntegerMul M.b v),
   bitListIntegerSub (bitListIntegerMul M.a v) (bitListIntegerMul M.c u))

theorem bitListGcdPairApply_value (M : BitListGcdPairMatrix) (u v : BitListInteger) :
    ((bitListGcdPairApply M u v).1.value,(bitListGcdPairApply M u v).2.value)=
      (M.a.value*u.value+M.b.value*v.value,M.c.value*u.value+M.d.value*v.value) := by
  simp only [bitListGcdPairApply,bitListIntegerAdd_value,bitListIntegerMul_value]

theorem bitListGcdPairInverseApply_value (M : BitListGcdPairMatrix) (u v : BitListInteger) :
    ((bitListGcdPairInverseApply M u v).1.value,(bitListGcdPairInverseApply M u v).2.value)=
      (M.d.value*u.value-M.b.value*v.value,M.a.value*v.value-M.c.value*u.value) := by
  simp only [bitListGcdPairInverseApply,bitListIntegerSub_value,bitListIntegerMul_value]

theorem bitListGcdPairApply_bits (x y : ℤ) (u v : BitListInteger) :
    let M := bitListGcdPairMatrix (integerBitRepresentation x) (integerBitRepresentation y)
    ((bitListGcdPairApply M u v).1.value,(bitListGcdPairApply M u v).2.value)=
      integerGcdPairEquiv x y (u.value,v.value) := by
  dsimp only
  rw [bitListGcdPairApply_value]
  have he := bitListGcdPairMatrix_bits x y
  unfold BitListGcdPairMatrix.value at he
  unfold integerGcdPairEquiv
  split_ifs with hg
  · rw [if_pos hg] at he
    have ha := congrArg Prod.fst he
    have hb := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.1) he
    have hc := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.2.1) he
    have hd := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.2.2) he
    dsimp only at ha hb hc hd
    simp only [ha,hb,hc,hd,one_mul,zero_mul,add_zero,zero_add]
    rfl
  · rw [if_neg hg] at he
    have ha := congrArg Prod.fst he
    have hb := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.1) he
    have hc := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.2.1) he
    have hd := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.2.2) he
    dsimp only at ha hb hc hd
    rw [ha,hb,hc,hd]
    rfl

theorem bitListGcdPairInverseApply_bits (x y : ℤ) (u v : BitListInteger) :
    let M := bitListGcdPairMatrix (integerBitRepresentation x) (integerBitRepresentation y)
    ((bitListGcdPairInverseApply M u v).1.value,(bitListGcdPairInverseApply M u v).2.value)=
      (integerGcdPairEquiv x y).symm (u.value,v.value) := by
  dsimp only
  rw [bitListGcdPairInverseApply_value]
  have he := bitListGcdPairMatrix_bits x y
  unfold BitListGcdPairMatrix.value at he
  unfold integerGcdPairEquiv
  split_ifs with hg
  · rw [if_pos hg] at he
    have ha := congrArg Prod.fst he
    have hb := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.1) he
    have hc := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.2.1) he
    have hd := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.2.2) he
    dsimp only at ha hb hc hd
    simp only [ha,hb,hc,hd,one_mul,zero_mul,sub_zero]
    rfl
  · rw [if_neg hg] at he
    have ha := congrArg Prod.fst he
    have hb := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.1) he
    have hc := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.2.1) he
    have hd := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.2.2) he
    dsimp only at ha hb hc hd
    rw [ha,hb,hc,hd]
    apply Prod.ext
    · rfl
    · dsimp only [LinearEquiv.coe_symm_mk]
      ring
end Optss
