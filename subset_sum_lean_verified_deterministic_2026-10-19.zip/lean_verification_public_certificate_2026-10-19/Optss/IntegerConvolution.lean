import Optss.MultivariateConvolution
import Optss.Truncation

/-!
# Exact signed polynomial convolution by packed natural multiplication

Positive and negative coefficient parts reduce arbitrary integer products to
four natural products. Every part has the original exponent box and magnitude
bound. This connects the packing primitive to the integer coefficient domain
used by the Newton computation; it does not assert a multiplication runtime.
-/

namespace Optss
open scoped BigOperators
noncomputable section

/-- The nonnegative part of each coefficient, without changing exponents. -/
def naturalCoefficients {σ : Type*} (p : MvPolynomial σ ℤ) : MvPolynomial σ ℕ :=
  Finsupp.mapRange Int.toNat (by decide) p

@[simp] theorem coeff_naturalCoefficients {σ : Type*} (p : MvPolynomial σ ℤ)
    (e : σ →₀ ℕ) : (naturalCoefficients p).coeff e = (p.coeff e).toNat := rfl

/-- An integer polynomial is the difference of its two nonnegative parts. -/
theorem polynomial_eq_positive_sub_negative {σ : Type*} (p : MvPolynomial σ ℤ) :
    p = MvPolynomial.map (Nat.castRingHom ℤ) (naturalCoefficients p) -
      MvPolynomial.map (Nat.castRingHom ℤ) (naturalCoefficients (-p)) := by
  ext e
  simp only [MvPolynomial.coeff_sub, MvPolynomial.coeff_map,
    coeff_naturalCoefficients, MvPolynomial.coeff_neg]
  exact (Int.toNat_sub_toNat_neg (p.coeff e)).symm

theorem naturalCoefficients_inBox {d : ℕ} (m : Fin d → ℕ)
    (p : MvPolynomial (Fin d) ℤ) (hp : polynomialInBox m p) :
    polynomialInBox m (naturalCoefficients p) := by
  intro e he
  apply hp e
  apply MvPolynomial.mem_support_iff.mpr
  intro hz
  have hne := MvPolynomial.mem_support_iff.mp he
  simp [hz] at hne

theorem polynomialInBox_neg {d : ℕ} (m : Fin d → ℕ)
    (p : MvPolynomial (Fin d) ℤ) (hp : polynomialInBox m p) :
    polynomialInBox m (-p) := by
  intro e he
  apply hp e
  simpa using he

theorem naturalCoefficients_bound {σ : Type*} (p : MvPolynomial σ ℤ)
    (A : ℕ) (hA : ∀ e, (p.coeff e).natAbs ≤ A) (e : σ →₀ ℕ) :
    (naturalCoefficients p).coeff e ≤ A := by
  have h := Int.toNat_add_toNat_neg_eq_natAbs (p.coeff e)
  have ha := hA e
  simp only [coeff_naturalCoefficients]
  omega

/-- The actual packed integer arithmetic for one nonnegative output coefficient. -/
def packedNaturalCoefficient {d : ℕ} (m n : Fin d → ℕ)
    (p q : MvPolynomial (Fin d) ℕ) (A C : ℕ) (e : Fin d →₀ ℕ) : ℕ :=
  let b := boxVolume (m+n) * (A+1) * (C+1) + 1
  ((flattenPolynomial ℕ (m+n) p).eval b * (flattenPolynomial ℕ (m+n) q).eval b) /
    b ^ boxIndex (m+n) e % b

theorem packedNaturalCoefficient_eq {d : ℕ} (m n : Fin d → ℕ)
    (p q : MvPolynomial (Fin d) ℕ) (hp : polynomialInBox m p)
    (hq : polynomialInBox n q) (A C : ℕ)
    (hA : ∀ e, p.coeff e ≤ A) (hC : ∀ e, q.coeff e ≤ C)
    (e : Fin d →₀ ℕ) (he : ∀ j, e j ≤ m j+n j) :
    packedNaturalCoefficient m n p q A C e = (p*q).coeff e :=
  (multivariate_packed_convolution m n p q hp hq A C hA hC).2.2 e he

/-- Four packed natural multiplications recover every signed output coefficient. -/
def packedIntegerCoefficient {d : ℕ} (m n : Fin d → ℕ)
    (p q : MvPolynomial (Fin d) ℤ) (A C : ℕ) (e : Fin d →₀ ℕ) : ℤ :=
  (packedNaturalCoefficient m n (naturalCoefficients p) (naturalCoefficients q) A C e : ℤ) -
  (packedNaturalCoefficient m n (naturalCoefficients p) (naturalCoefficients (-q)) A C e : ℤ) -
  (packedNaturalCoefficient m n (naturalCoefficients (-p)) (naturalCoefficients q) A C e : ℤ) +
  (packedNaturalCoefficient m n (naturalCoefficients (-p)) (naturalCoefficients (-q)) A C e : ℤ)

/-- No sign or nonnegativity assumption is imposed on the original coefficients. -/
theorem packedIntegerCoefficient_eq {d : ℕ} (m n : Fin d → ℕ)
    (p q : MvPolynomial (Fin d) ℤ) (hp : polynomialInBox m p)
    (hq : polynomialInBox n q) (A C : ℕ)
    (hA : ∀ e, (p.coeff e).natAbs ≤ A) (hC : ∀ e, (q.coeff e).natAbs ≤ C)
    (e : Fin d →₀ ℕ) (he : ∀ j, e j ≤ m j+n j) :
    packedIntegerCoefficient m n p q A C e = (p*q).coeff e := by
  have hAp := naturalCoefficients_bound p A hA
  have hAn := naturalCoefficients_bound (-p) A (by simpa using hA)
  have hCp := naturalCoefficients_bound q C hC
  have hCn := naturalCoefficients_bound (-q) C (by simpa using hC)
  have hpp := naturalCoefficients_inBox m p hp
  have hpn := naturalCoefficients_inBox m (-p) (polynomialInBox_neg m p hp)
  have hqp := naturalCoefficients_inBox n q hq
  have hqn := naturalCoefficients_inBox n (-q) (polynomialInBox_neg n q hq)
  unfold packedIntegerCoefficient
  rw [packedNaturalCoefficient_eq m n _ _ hpp hqp A C hAp hCp e he,
    packedNaturalCoefficient_eq m n _ _ hpp hqn A C hAp hCn e he,
    packedNaturalCoefficient_eq m n _ _ hpn hqp A C hAn hCp e he,
    packedNaturalCoefficient_eq m n _ _ hpn hqn A C hAn hCn e he]
  have hdecomp : p*q =
      MvPolynomial.map (Nat.castRingHom ℤ) (naturalCoefficients p * naturalCoefficients q) -
      MvPolynomial.map (Nat.castRingHom ℤ) (naturalCoefficients p * naturalCoefficients (-q)) -
      MvPolynomial.map (Nat.castRingHom ℤ) (naturalCoefficients (-p) * naturalCoefficients q) +
      MvPolynomial.map (Nat.castRingHom ℤ) (naturalCoefficients (-p) * naturalCoefficients (-q)) := by
    simp only [map_mul]
    calc
      p*q = (MvPolynomial.map (Nat.castRingHom ℤ) (naturalCoefficients p) -
        MvPolynomial.map (Nat.castRingHom ℤ) (naturalCoefficients (-p))) *
        (MvPolynomial.map (Nat.castRingHom ℤ) (naturalCoefficients q) -
        MvPolynomial.map (Nat.castRingHom ℤ) (naturalCoefficients (-q))) :=
          congrArg₂ (· * ·) (polynomial_eq_positive_sub_negative p)
            (polynomial_eq_positive_sub_negative q)
      _ = _ := by ring
  simpa only [MvPolynomial.coeff_add, MvPolynomial.coeff_sub, MvPolynomial.coeff_map] using (congrArg (MvPolynomial.coeff e) hdecomp).symm

/-- Truncation really supplies the exponent support bound used by the encoder. -/
theorem truncatePolynomial_inBox {d : ℕ} {R : Type*} [CommSemiring R]
    (Δ : Fin d →₀ ℕ) (p : MvPolynomial (Fin d) R) :
    polynomialInBox Δ (truncatePolynomial Δ p) := by
  intro e he
  have hne := MvPolynomial.mem_support_iff.mp he
  rw [coeff_truncatePolynomial] at hne
  by_cases h : e ≤ Δ
  · exact h
  · simp [h] at hne

/-- Computing a retained product coefficient by padding, packing and digit
extraction agrees with the original integer product before truncation. -/
theorem packed_truncated_integer_product {d : ℕ} (Δ : Fin d →₀ ℕ)
    (p q : MvPolynomial (Fin d) ℤ) (A C : ℕ)
    (hA : ∀ e, ((truncatePolynomial Δ p).coeff e).natAbs ≤ A)
    (hC : ∀ e, ((truncatePolynomial Δ q).coeff e).natAbs ≤ C)
    (e : Fin d →₀ ℕ) (he : e ≤ Δ) :
    packedIntegerCoefficient Δ Δ (truncatePolynomial Δ p) (truncatePolynomial Δ q) A C e =
      (p*q).coeff e := by
  rw [packedIntegerCoefficient_eq Δ Δ _ _ (truncatePolynomial_inBox Δ p)
    (truncatePolynomial_inBox Δ q) A C hA hC e
    (fun j => (he j).trans (Nat.le_add_right _ _))]
  exact coeff_mul_truncatePolynomial Δ e he p q

end
end Optss
