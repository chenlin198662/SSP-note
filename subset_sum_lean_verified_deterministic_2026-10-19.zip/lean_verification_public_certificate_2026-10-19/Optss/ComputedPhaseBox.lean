import Optss.StoredPhaseInputs
import Optss.PhaseLatticeProgression

/-! The inner-box algorithm applied to the actual full cyclic phase lattice. -/
namespace Optss
open scoped BigOperators
variable {N r : ℕ} [NeZero N]

def computedPhaseBox (a : Fin r→ZMod N) (base : Fin r) (M : ℕ) (cs : List Bool) :
    Option (BooleanLatticeBoxResult r) :=
  booleanInnerLatticeBox (storedCubeVertices r M) (storedPhaseMatrix a base) cs

def computedPhaseBoxReductionWork (a : Fin r→ZMod N) (base : Fin r) (M : ℕ) (cs : List Bool) : ℕ :=
  booleanInnerLatticeBoxWork (storedCubeVertices r M) (storedPhaseMatrix a base) cs

theorem computedPhaseBox_spec (a : Fin r→ZMod N) (base : Fin r) (ha : a base=1)
    (M : ℕ) (hM : 0<M) (cs : List Bool) (hc : 0<binaryDigitsValue cs)
    (hCJ : latticeBoxingDilation r ((r.factorial:ℝ)*sharpLatticeDefectBound r)≤(binaryDigitsValue cs:ℝ)) :
    ∃ box,computedPhaseBox a base M cs=some box ∧
      ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
        (∀ i j,(storedRationalMatrix box.columns i j:ℝ)=b j i) ∧
        basisIntegerLattice b=realVector '' (cyclicPhaseLattice a base : Set (IntVec r)) ∧
        (∀ j,BitListCanonical (box.widths.toVector.get j)) ∧
        basisCoefficientBox b (decodedLatticeBoxWidths box) ⊆ realCoefficientBox (fun _=>M) ∧
        (phaseLatticeCube a base M).card≤
          (2*binaryDigitsValue cs+1)^r*∏ j,(2*decodedLatticeBoxWidths box j+1) ∧
        (∀ i j,(rectangularListFractionMatrix box.columns i j).WellFormed) := by
  classical
  have hr : 0<r := by have h := base.isLt; omega
  obtain ⟨box,hbox,b,hcols,hΛ,hcanon,hinner,hcard,hB⟩ := booleanInnerLatticeBox_spec hr
    (storedCubeVertices r M) (storedPhaseMatrix a base)
    (storedRationalEncoding_wellFormed _) (storedRationalEncoding_wellFormed _)
    (storedPhaseMatrix_nonsingular a base)
    (by rw [storedCubeVertices_vertexSet]; exact fun _ h => realBoxVertices_symmetric _ h)
    (by rw [storedCubeVertices_vertexSet]; exact realBoxVertices_span _ (fun _=>hM)) cs hc hCJ
  have hΛ' : basisIntegerLattice b=realVector '' (cyclicPhaseLattice a base : Set (IntVec r)) := by
    rw [hΛ,storedPhaseMatrix_lattice a base ha,integerSubgroupRealLattice_coe]
  rw [storedCubeVertices_hull] at hinner
  refine ⟨box,hbox,b,hcols,hΛ',hcanon,hinner,?_,hB⟩
  change ((integerBudgetBox (fun _=>M)).filter fun z => z∈cyclicPhaseLattice a base).card≤_
  rw [subgroup_cube_points_card _ b hΛ']
  convert hcard using 1
  congr 1
  ext x
  simp only [mem_basisLatticePoints,storedCubeVertices_hull]

noncomputable def phaseBoxInputSize (r : ℕ) : Polynomial ℕ :=
  Polynomial.C (2*r)+Polynomial.C (r*2^r+r*r)*(1+2*(Polynomial.X+1))

theorem computedPhaseBoxReductionWork_bound (a : Fin r→ZMod N) (base : Fin r)
    (M : ℕ) (hM : 0<M) (hMN : M≤N) (cs : List Bool) (hc : 0<binaryDigitsValue cs) :
    computedPhaseBoxReductionWork a base M cs≤
      ((booleanInnerLatticeBoxPolynomial r cs.length).comp (phaseBoxInputSize r)).eval N.size := by
  have hr : 0<r := by have h := base.isLt; omega
  have hw := booleanInnerLatticeBoxWork_input_polynomial hr
    (storedCubeVertices r M) (storedPhaseMatrix a base)
    (storedRationalEncoding_wellFormed _) (storedRationalEncoding_wellFormed _)
    (storedPhaseMatrix_nonsingular a base)
    (by rw [storedCubeVertices_vertexSet]; exact realBoxVertices_span _ (fun _=>hM)) cs hc
  have hsize : listStoredRationalBits (storedCubeVertices r M)+listStoredRationalBits (storedPhaseMatrix a base)≤
      (phaseBoxInputSize r).eval N.size := by
    have h := Nat.add_le_add (storedCubeVertices_bits (r:=r) M) (storedPhaseMatrix_bits a base)
    have hm := Nat.size_le_size hMN
    simp only [phaseBoxInputSize,Polynomial.eval_add,Polynomial.eval_C,Polynomial.eval_mul,
      Polynomial.eval_one,Polynomial.eval_ofNat,Polynomial.eval_X]
    calc
      _≤r+r*(2^r)*(1+2*(M.size+1))+(r+r*r*(1+2*(N.size+1))) := h
      _≤r+r*(2^r)*(1+2*(N.size+1))+(r+r*r*(1+2*(N.size+1))) := by gcongr
      _=_ := by ring
  rw [Polynomial.eval_comp]
  exact hw.trans (natPolynomial_eval_mono _ hsize)
end Optss
