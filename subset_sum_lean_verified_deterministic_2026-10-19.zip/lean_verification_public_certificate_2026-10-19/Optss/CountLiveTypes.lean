import Optss.CountClippedConvolution

/-!
# Removing zero-capacity types from counted Newton computation

The power sums, stored tables and support polynomials are unchanged when their
index types are restricted to positive capacities. The final construction
therefore drops every type eliminated by correction preprocessing before the
power tables are prepared. No complexity estimate is asserted.
-/

namespace Optss
open scoped BigOperators
noncomputable section

variable {ι σ : Type*} [Fintype ι]

/-- Zero-capacity types contribute nothing to any power sum, including index zero. -/
theorem countPowerSum_live (c : ι → ℕ) (a : ι → MvPolynomial σ ℤ) (l : ℕ) :
    countPowerSum (fun i : {i // c i ≠ 0} => c i) (fun i => a i) l =
      countPowerSum c a l := by
  classical
  unfold countPowerSum
  rw [← Finset.sum_subtype (Finset.univ.filter (fun i => c i ≠ 0)) (by simp)
    (fun i => (c i : MvPolynomial σ ℤ) * a i ^ l)]
  apply Finset.sum_filter_of_ne
  intro i _ h hzero
  exact h (by simp [hzero])

/-- Prepared power tables are equal after physically restricting the type index. -/
theorem countPowerTable_live (Δ : σ →₀ ℕ) (c : ι → ℕ)
    (a : ι → MvPolynomial σ ℤ) (kcap : ℕ) :
    countPowerTable Δ (fun i : {i // c i ≠ 0} => c i) (fun i => a i) kcap =
      countPowerTable Δ c a kcap := by
  unfold countPowerTable
  simp_rw [countPowerSum_live]

theorem monomialPowerTable_live (Δ : σ →₀ ℕ) (c : ι → ℕ)
    (u : ι → σ →₀ ℕ) (kcap : ℕ) :
    monomialPowerTable Δ (fun i : {i // c i ≠ 0} => c i) (fun i => u i) kcap =
      monomialPowerTable Δ c u kcap := by
  rw [monomialPowerTable_eq, monomialPowerTable_eq]
  exact countPowerTable_live Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap

/-- Every stored Newton coefficient remains equal after removing unused types. -/
theorem countNewtonTable_live (Δ : σ →₀ ℕ) (c : ι → ℕ)
    (a : ι → MvPolynomial σ ℤ) (kcap : ℕ) :
    countNewtonTable Δ (fun i : {i // c i ≠ 0} => c i) (fun i => a i) kcap =
      countNewtonTable Δ c a kcap := by
  unfold countNewtonTable
  rw [countPowerTable_live]

/-- The support polynomial is unchanged, without any comparison through copies. -/
theorem countNewtonSupport_live (Δ : σ →₀ ℕ) (c : ι → ℕ)
    (u : ι → σ →₀ ℕ) (kcap : ℕ) :
    countNewtonSupport Δ (fun i : {i // c i ≠ 0} => c i) (fun i => u i) kcap =
      countNewtonSupport Δ c u kcap := by
  unfold countNewtonSupport
  rw [monomialPowerTable_live]

variable {d : ℕ}

/-- Per-orthant Newton arrays prepared only from nonzero capacities. -/
def liveDecodedCountOrthantSupport (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool) : Finset (IntVec d) := by
  classical
  exact (countNewtonSupport Δ
    (fun i : {i : {i // coordinateOrthant (v i) = ε} // c i ≠ 0} => c i.val)
    (fun i => absoluteExponent (v i.val)) kcap).support.image (orthantDecode ε)

theorem liveDecodedCountOrthantSupport_eq (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool) :
    liveDecodedCountOrthantSupport v c Δ kcap ε = decodedCountOrthantSupport v c Δ kcap ε := by
  classical
  unfold liveDecodedCountOrthantSupport decodedCountOrthantSupport
  have h := countNewtonSupport_live Δ
    (fun i : {i // coordinateOrthant (v i) = ε} => c i)
    (fun i => absoluteExponent (v i)) kcap
  exact congrArg (fun p : MvPolynomial (Fin d) ℤ => p.support.image (orthantDecode ε)) h

/-- The counted correction computation, with all zero-capacity types removed
before preparing the local Newton tables and folding the clipped supports. -/
def liveIteratedCountCorrectionSupport (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) : Finset (IntVec d) := by
  classical
  exact clippedConvolution {t | InBox (fun j => (Δ j : ℤ)) t}
    ((orthantOrder d).map (liveDecodedCountOrthantSupport v c Δ kcap))

theorem liveIteratedCountCorrectionSupport_eq (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) :
    liveIteratedCountCorrectionSupport v c Δ kcap = iteratedCountCorrectionSupport v c Δ kcap := by
  classical
  unfold liveIteratedCountCorrectionSupport iteratedCountCorrectionSupport
  congr 1
  apply List.map_congr_left
  intro ε _
  exact liveDecodedCountOrthantSupport_eq v c Δ kcap ε

/-- Full counted correction correctness after capping capacities, dropping dead
types, computing the stored Newton tables, and clipping each successive merge. -/
theorem liveIteratedCountCorrectionSupport_correct (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) :
    let c' := correctionCapacity v c (fun j => (Δ j : ℤ)) kcap
    let S := liveIteratedCountCorrectionSupport v c' Δ kcap
    (∀ t ∈ S, t ∈ countSums v (fun i => (c i : ℤ)) ∧ InBox (fun j => (Δ j : ℤ)) t) ∧
    (∀ x, BoundedCounts (fun i => (c i : ℤ)) x → (∑ i, x i) ≤ kcap →
      CountAbsoluteBudget v x (fun j => (Δ j : ℤ)) → weightedSum v x ∈ S) ∧
    ((orthantOrder d).map (liveDecodedCountOrthantSupport v c' Δ kcap)).length = 2 ^ d := by
  dsimp only
  rw [liveIteratedCountCorrectionSupport_eq]
  obtain ⟨hsound, hcomplete, _⟩ := iteratedCountCorrectionSupport_correct v c Δ kcap
  exact ⟨hsound, hcomplete, by simpa only [List.length_map] using orthantOrder_length d⟩

end
end Optss
