import Optss.DenseBoxFillingResidues
import Mathlib.Algebra.BigOperators.Group.List.Lemmas

/-!
# Dense integer intervals and balanced ordered diameters

The interval-filling lemma is the elementary Lemma 1 of V. F. Lev,
`Consecutive integers in high-multiplicity sumsets` (2010). It is proved
from finite-set cardinality, without assuming a sumset growth theorem.
-/
namespace Optss
open scoped BigOperators Pointwise

/-- If two subsets of integer intervals are sufficiently dense, every point
of the indicated central interval is an actual sum of one element of each set. -/
theorem dense_interval_subset_sum (A B : Finset ℤ) (L₁ L₂ : ℤ)
    (hL₁ : 0 ≤ L₁) (_hL₂ : 0 ≤ L₂)
    (hA : A ⊆ Finset.Icc 0 L₁) (hB : B ⊆ Finset.Icc 0 L₂)
    (hdense : max L₁ L₂ ≤ (A.card : ℤ) + B.card - 2) :
    Finset.Icc (L₁ + L₂ - ((A.card : ℤ) + B.card - 2))
      ((A.card : ℤ) + B.card - 2) ⊆ A + B := by
  intro x hx
  obtain ⟨hxlo, hxhi⟩ := Finset.mem_Icc.mp hx
  by_contra hxsum
  let B' := B.image (fun b => x - b)
  have hdis : Disjoint A B' := by
    apply Finset.disjoint_left.mpr
    intro a ha hb
    obtain ⟨b, hb, hab⟩ := Finset.mem_image.mp hb
    apply hxsum
    apply Finset.mem_add.mpr
    exact ⟨a, ha, b, hb, by omega⟩
  have hBcard : B'.card = B.card :=
    Finset.card_image_of_injective B (fun _ _ h => by omega)
  have hsub : A ∪ B' ⊆ Finset.Icc (min 0 (x - L₂)) (max L₁ x) := by
    intro y hy
    rcases Finset.mem_union.mp hy with hy | hy
    · obtain ⟨hylo, hyhi⟩ := Finset.mem_Icc.mp (hA hy)
      exact Finset.mem_Icc.mpr ⟨le_trans (min_le_left _ _) hylo,
        le_trans hyhi (le_max_left _ _)⟩
    · obtain ⟨b, hb, rfl⟩ := Finset.mem_image.mp hy
      obtain ⟨hblo, hbhi⟩ := Finset.mem_Icc.mp (hB hb)
      exact Finset.mem_Icc.mpr ⟨le_trans (min_le_right _ _) (by omega),
        le_trans (by omega) (le_max_right _ _)⟩
  have hc := Finset.card_le_card hsub
  rw [Finset.card_union_of_disjoint hdis, hBcard, Int.card_Icc] at hc
  have hnonneg : 0 ≤ max L₁ x + 1 - min 0 (x - L₂) := by
    have := le_max_left L₁ x
    have := min_le_left 0 (x - L₂)
    omega
  have hc' : (A.card : ℤ) + B.card ≤ max L₁ x + 1 - min 0 (x - L₂) := by
    have hcZ : (A.card : ℤ) + B.card ≤
        ((max L₁ x + 1 - min 0 (x - L₂)).toNat : ℤ) := by exact_mod_cast hc
    simpa only [Int.toNat_of_nonneg hnonneg] using hcZ
  have h₁ := (max_le_iff.mp hdense).1
  have h₂ := (max_le_iff.mp hdense).2
  simp only [max_def, min_def] at hc'
  split_ifs at hc' <;> omega

/-- Alternating pairs of a decreasing nonnegative sequence have total
excess bounded by the difference of its first and last entries. -/
theorem ordered_diameter_pair_excess (a : ℕ → ℤ) (n : ℕ)
    (ha : ∀ i j, i ≤ j → j ≤ 2 * n → a j ≤ a i) :
    (∑ i ∈ Finset.range n, (a (2 * i) - a (2 * i + 1))) ≤ a 0 - a (2 * n) := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hprev : ∀ i j, i ≤ j → j ≤ 2 * n → a j ≤ a i := by
      intro i j hij hj
      exact ha i j hij (by omega)
    have hs := ih hprev
    have hlast := ha (2 * n + 1) (2 * (n + 1)) (by omega) (by omega)
    rw [Finset.sum_range_succ]
    omega

/-- The two diameter sums in the odd/even split of `2*n+1` ordered
summands differ by at most the maximum allowed diameter. -/
theorem ordered_diameter_split_balance (a : ℕ → ℤ) (n : ℕ) (L : ℤ)
    (ha : ∀ i j, i ≤ j → j ≤ 2 * n → a j ≤ a i)
    (hbound : ∀ i ≤ 2 * n, 0 ≤ a i ∧ a i ≤ L) :
    |(∑ i ∈ Finset.range n, a (2 * i)) -
      ((∑ i ∈ Finset.range n, a (2 * i + 1)) + a (2 * n))| ≤ L := by
  have hpair := ordered_diameter_pair_excess a n ha
  have hnonneg : 0 ≤ ∑ i ∈ Finset.range n, (a (2 * i) - a (2 * i + 1)) := by
    apply Finset.sum_nonneg
    intro i hi
    have hi' := Finset.mem_range.mp hi
    have := ha (2 * i) (2 * i + 1) (by omega) (by omega)
    omega
  rw [Finset.sum_sub_distrib] at hpair hnonneg
  have hfirst := hbound 0 (by omega)
  have hlast := hbound (2 * n) le_rfl
  rw [abs_le]
  omega

/-- The odd/even split really partitions every entry of the diameter list. -/
theorem ordered_diameter_split_sum (a : ℕ → ℤ) (n : ℕ) :
    (∑ i ∈ Finset.range (2 * n + 1), a i) =
      (∑ i ∈ Finset.range n, a (2 * i)) +
      ((∑ i ∈ Finset.range n, a (2 * i + 1)) + a (2 * n)) := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hn : 2 * (n + 1) + 1 = (2 * n + 1) + 1 + 1 := by omega
    rw [hn, Finset.sum_range_succ, Finset.sum_range_succ, ih,
      Finset.sum_range_succ, Finset.sum_range_succ]
    have he : 2 * n + 1 + 1 = 2 * (n + 1) := by omega
    rw [he]
    ring

/-- The first class contains the even indices except the final index. -/
def diameterEvenIndices (n : ℕ) : Finset ℕ :=
  (Finset.range n).image (fun i => 2 * i)

/-- The second class contains all odd indices and the final even index. -/
def diameterOddFinalIndices (n : ℕ) : Finset ℕ :=
  insert (2 * n) ((Finset.range n).image (fun i => 2 * i + 1))

@[simp] theorem diameterEvenIndices_card (n : ℕ) :
    (diameterEvenIndices n).card = n := by
  rw [diameterEvenIndices, Finset.card_image_of_injective _ (fun _ _ h => by omega),
    Finset.card_range]

@[simp] theorem diameterOddFinalIndices_card (n : ℕ) :
    (diameterOddFinalIndices n).card = n + 1 := by
  have hlast : 2 * n ∉ (Finset.range n).image (fun i => 2 * i + 1) := by
    simp only [Finset.mem_image, Finset.mem_range, not_exists, not_and]
    omega
  rw [diameterOddFinalIndices, Finset.card_insert_of_not_mem hlast,
    Finset.card_image_of_injective _ (fun _ _ h => by omega), Finset.card_range]

theorem diameter_split_disjoint (n : ℕ) :
    Disjoint (diameterEvenIndices n) (diameterOddFinalIndices n) := by
  apply Finset.disjoint_left.mpr
  intro i hi hj
  obtain ⟨a, ha, rfl⟩ := Finset.mem_image.mp hi
  have ha' := Finset.mem_range.mp ha
  rcases Finset.mem_insert.mp hj with hj | hj
  · omega
  · obtain ⟨b, _, hab⟩ := Finset.mem_image.mp hj
    omega

theorem diameter_split_union (n : ℕ) :
    diameterEvenIndices n ∪ diameterOddFinalIndices n = Finset.range (2 * n + 1) := by
  ext i
  constructor
  · intro hi
    rcases Finset.mem_union.mp hi with hi | hi
    · obtain ⟨a, ha, rfl⟩ := Finset.mem_image.mp hi
      have := Finset.mem_range.mp ha
      exact Finset.mem_range.mpr (by omega)
    · rcases Finset.mem_insert.mp hi with rfl | hi
      · exact Finset.mem_range.mpr (by omega)
      · obtain ⟨a, ha, rfl⟩ := Finset.mem_image.mp hi
        have := Finset.mem_range.mp ha
        exact Finset.mem_range.mpr (by omega)
  · intro hi
    have hi' := Finset.mem_range.mp hi
    by_cases hlast : i = 2 * n
    · exact Finset.mem_union_right _ (Finset.mem_insert.mpr (Or.inl hlast))
    · have hmod := Nat.mod_two_eq_zero_or_one i
      have hdiv := Nat.mod_add_div i 2
      rcases hmod with hmod | hmod
      · apply Finset.mem_union_left
        exact Finset.mem_image.mpr ⟨i / 2, Finset.mem_range.mpr (by omega), by omega⟩
      · apply Finset.mem_union_right
        apply Finset.mem_insert.mpr
        exact Or.inr (Finset.mem_image.mpr
          ⟨i / 2, Finset.mem_range.mpr (by omega), by omega⟩)

/-- The actual disjoint index classes have the advertised diameter balance. -/
theorem diameter_index_partition_balance (a : ℕ → ℤ) (n : ℕ) (L : ℤ)
    (ha : ∀ i j, i ≤ j → j ≤ 2 * n → a j ≤ a i)
    (hbound : ∀ i ≤ 2 * n, 0 ≤ a i ∧ a i ≤ L) :
    |(∑ i ∈ diameterEvenIndices n, a i) -
      (∑ i ∈ diameterOddFinalIndices n, a i)| ≤ L := by
  have hlast : 2 * n ∉ (Finset.range n).image (fun i => 2 * i + 1) := by
    simp only [Finset.mem_image, Finset.mem_range, not_exists, not_and]
    omega
  rw [diameterEvenIndices, diameterOddFinalIndices, Finset.sum_insert hlast]
  rw [Finset.sum_image (by intro i hi j hj h; omega),
    Finset.sum_image (by intro i hi j hj h; omega)]
  simpa only [add_comm] using ordered_diameter_split_balance a n L ha hbound

end Optss
