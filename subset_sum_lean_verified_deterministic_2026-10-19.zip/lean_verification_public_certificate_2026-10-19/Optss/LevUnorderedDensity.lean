import Optss.LevDensity
import Mathlib.Data.List.Sort
import Mathlib.Data.List.GetD

/-!
# Removing the ordering assumption from Lev's density estimates

The summands are actually merge-sorted by their diameters. Permutation
invariance preserves both the finite Minkowski sum and its total diameter.
-/
namespace Optss
noncomputable section
open scoped BigOperators Pointwise

private theorem lev_range_getD {α : Type*} (L : List α) (d : α) :
    (List.range L.length).map (fun i => L.getD i d) = L := by
  apply List.ext_getElem (by simp)
  intro i hi hj
  simp only [List.getElem_map, List.getElem_range]
  exact List.getD_eq_getElem L d hj

private theorem lev_range_sum_eq_list_sum {M : Type*} [AddCommMonoid M]
    (k : ℕ) (f : ℕ → M) :
    (∑ i ∈ Finset.range k, f i) = ((List.range k).map f).sum := by
  induction k with
  | zero => simp
  | succ k ih => simp [List.range_succ, Finset.sum_range_succ, ih]

/-- An actual ordered enumeration, preserving all summands and both sums. -/
theorem lev_sorted_enumeration (L : List (Finset ℤ × ℕ)) :
    ∃ (A : ℕ → Finset ℤ) (l : ℕ → ℕ),
      (∀ i < L.length, (A i, l i) ∈ L) ∧
      MonotoneOn l (Finset.range L.length) ∧
      levPrefixSum A L.length = (L.map Prod.fst).sum ∧
      (∑ i ∈ Finset.range L.length, (l i : ℤ)) = (L.map (fun p => (p.2 : ℤ))).sum := by
  let r : (Finset ℤ × ℕ) → (Finset ℤ × ℕ) → Prop := fun a b => a.2 ≤ b.2
  letI : IsTrans (Finset ℤ × ℕ) r := ⟨fun _ _ _ => Nat.le_trans⟩
  letI : IsTotal (Finset ℤ × ℕ) r := ⟨fun a b => Nat.le_total a.2 b.2⟩
  letI : IsRefl (Finset ℤ × ℕ) r := ⟨fun _ => le_rfl⟩
  let S := L.mergeSort (fun a b => decide (r a b))
  have hp : S.Perm L := List.mergeSort_perm _ _
  have hlen : S.length = L.length := hp.length_eq
  let p : ℕ → Finset ℤ × ℕ := fun i => S.getD i (∅, 0)
  refine ⟨fun i => (p i).1, fun i => (p i).2, ?_, ?_, ?_, ?_⟩
  · intro i hi
    change p i ∈ L
    apply hp.mem_iff.mp
    dsimp [p]
    rw [List.getD_eq_getElem _ _ (by omega)]
    exact List.getElem_mem _
  · intro i hi j hj hij
    have hi' : i < S.length := by simpa [hlen] using Finset.mem_range.mp hi
    have hj' : j < S.length := by simpa [hlen] using Finset.mem_range.mp hj
    have hs : S.Sorted r := List.sorted_mergeSort' r L
    have hs' := hs.rel_get_of_le (a := ⟨i, hi'⟩) (b := ⟨j, hj'⟩) hij
    change (S.getD i (∅, 0)).2 ≤ (S.getD j (∅, 0)).2
    rw [List.getD_eq_getElem _ _ hi', List.getD_eq_getElem _ _ hj']
    exact hs'
  · unfold levPrefixSum
    have he := congrArg (List.map Prod.fst) (lev_range_getD S (∅, 0))
    simp only [List.map_map, hlen] at he
    change (List.map (Prod.fst ∘ p) (List.range L.length)).sum = _
    rw [he]
    exact (hp.map Prod.fst).sum_eq
  · rw [lev_range_sum_eq_list_sum]
    have he := congrArg (List.map (fun q : Finset ℤ × ℕ => (q.2 : ℤ)))
      (lev_range_getD S (∅, 0))
    simp only [List.map_map, hlen] at he
    change (List.map ((fun q : Finset ℤ × ℕ => (q.2 : ℤ)) ∘ p) (List.range L.length)).sum = _
    rw [he]
    exact (hp.map (fun q => (q.2 : ℤ))).sum_eq

/-- Lev 2010 Proposition 1(ii) for arbitrary input order. -/
theorem lev_list_density_bound (L : List (Finset ℤ × ℕ)) (n : ℕ) (hn : 3 ≤ n)
    (hA : ∀ p ∈ L, LevNormalized p.1 p.2)
    (hcard : ∀ p ∈ L, n ≤ p.1.card)
    (hwidth : ∀ p ∈ L, (p.2 : ℤ) - 1 ≤ (L.length : ℤ) * ((n : ℤ) - 2)) :
    (L.map (fun p => (p.2 : ℤ))).sum + (L.length : ℤ) * ((n : ℤ) - 1) + 2 ≤
      2 * (((L.map Prod.fst).sum).card : ℤ) := by
  obtain ⟨A, l, hm, hl, hsum, hdiam⟩ := lev_sorted_enumeration L
  have h := lev_density_bound A l n L.length hn
    (fun i hi => hA _ (hm i hi)) (fun i hi => hcard _ (hm i hi)) hl
    (fun i hi => hwidth _ (hm i hi))
  simpa only [hsum, hdiam] using h

/-- Lev 2010 Proposition 1(i) for arbitrary input order. -/
theorem lev_list_density_bound_endpoint (L : List (Finset ℤ × ℕ)) (n W : ℕ) (hn : 3 ≤ n)
    (hA : ∀ p ∈ L, LevNormalized p.1 p.2)
    (hcard : ∀ p ∈ L, n ≤ p.1.card)
    (hwidth : ∀ p ∈ L, p.2 ≤ W) (hWn : n - 1 ≤ W)
    (hW : (W : ℤ) - 1 ≤ (L.length + 1 : ℕ) * ((n : ℤ) - 2)) :
    (L.map (fun p => (p.2 : ℤ))).sum +
      (L.length + 1 : ℕ) * ((n : ℤ) - 1) - W + 2 ≤
        2 * (((L.map Prod.fst).sum).card : ℤ) := by
  obtain ⟨A, l, hm, hl, hsum, hdiam⟩ := lev_sorted_enumeration L
  have h := lev_density_bound_endpoint A l n L.length W hn
    (fun i hi => hA _ (hm i hi)) (fun i hi => hcard _ (hm i hi)) hl
    (fun i hi => hwidth _ (hm i hi)) hWn hW
  simpa only [hsum, hdiam] using h

end
end Optss
