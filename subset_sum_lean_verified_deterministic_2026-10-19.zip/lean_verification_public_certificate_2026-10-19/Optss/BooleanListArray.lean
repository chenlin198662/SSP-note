import Optss.BitListStorageControl

/-!
# List arrays with explicit Boolean index control and copying

Finite indices are encoded by structural counting with the verified Boolean
adder. Array reads and updates use Boolean-address scans. A supplied copier
can deep-copy each stored record, allowing the concrete cached evaluator to
avoid an assumption of free native array or pointer operations.
-/

namespace Optss

/-- Deliberately coarse, but polynomial, encoding of a finite structural
index. The answer uses only the verified Boolean increment operation. -/
def bitUnaryAddress : ℕ → List Bool
  | 0 => []
  | n+1 => bitListAdd (bitUnaryAddress n) [true]

theorem bitUnaryAddress_value (n : ℕ) : binaryDigitsValue (bitUnaryAddress n) = n := by
  induction n with
  | zero => rfl
  | succ n ih => rw [bitUnaryAddress, bitListAdd_correct, ih]; rfl

theorem bitUnaryAddress_length (n : ℕ) : (bitUnaryAddress n).length ≤ n+1 := by
  induction n with
  | zero => simp [bitUnaryAddress]
  | succ n ih =>
    change (bitListTrim (bitListAddAux false (bitUnaryAddress n) [true])).length ≤ n+1+1
    have ht := bitListTrim_length_le (bitListAddAux false (bitUnaryAddress n) [true])
    have ha := bitListAddAux_length (bitUnaryAddress n) [true] false
    simp only [List.length_cons,List.length_nil] at ha
    omega

def bitUnaryAddressWork : ℕ → ℕ
  | 0 => 1
  | n+1 =>
    bitUnaryAddressWork n+bitListRippleGates 6 (bitUnaryAddress n) [true]+
      bitListAddVisits (bitUnaryAddress n) [true]+
      bitListTrimVisits (bitListAddAux false (bitUnaryAddress n) [true])+1

theorem bitUnaryAddressWork_le (n : ℕ) : bitUnaryAddressWork n ≤ 16*(n+1)^2 := by
  induction n with
  | zero => norm_num [bitUnaryAddressWork]
  | succ n ih =>
    have hlen := bitUnaryAddress_length n
    have hm : max (bitUnaryAddress n).length [true].length ≤ n+1 := by simp only [List.length_cons,List.length_nil]; omega
    have hv := bitListAdd_total_visits (bitUnaryAddress n) [true]
    rw [bitUnaryAddressWork,bitListRippleGates_eq]
    nlinarith

/-- Generic read that explicitly invokes the stored-record copier. -/
def bitIndexedRead {α : Type*} (copy : α → α) : List Bool → List α → Option α
  | _, [] => none
  | address, x::xs =>
    if (bitListTrim address).isEmpty then some (copy x)
    else bitIndexedRead copy (bitAddressPred address) xs

theorem bitIndexedRead_correct {α : Type*} (copy : α → α)
    (address : List Bool) (xs : List α) :
    bitIndexedRead copy address xs = (xs[binaryDigitsValue address]?).map copy := by
  induction xs generalizing address with
  | nil => simp [bitIndexedRead]
  | cons x xs ih =>
    simp only [bitIndexedRead,List.getElem?_cons,bitAddressZero_iff]
    split_ifs
    · rfl
    · rw [ih,bitAddressPred_value]

/-- Persistent update copies every retained record as well as the replacement.
This intentionally trades efficiency for a simple explicit storage simulation. -/
def bitIndexedWrite {α : Type*} (copy : α → α) : List Bool → α → List α → List α
  | _, _, [] => []
  | address, replacement, x::xs =>
    if (bitListTrim address).isEmpty then copy replacement::xs.map copy
    else copy x::bitIndexedWrite copy (bitAddressPred address) replacement xs

theorem bitIndexedWrite_length {α : Type*} (copy : α → α)
    (address : List Bool) (replacement : α) (xs : List α) :
    (bitIndexedWrite copy address replacement xs).length = xs.length := by
  induction xs generalizing address with
  | nil => rfl
  | cons x xs ih =>
    rw [bitIndexedWrite]
    split_ifs <;> simp only [List.length_cons,List.length_map,ih]

theorem bitIndexedWrite_correct {α : Type*} (copy : α → α) (hc : ∀ x, copy x = x)
    (address : List Bool) (replacement : α) (xs : List α) :
    bitIndexedWrite copy address replacement xs = xs.set (binaryDigitsValue address) replacement := by
  induction xs generalizing address with
  | nil => simp [bitIndexedWrite]
  | cons x xs ih =>
    rw [bitIndexedWrite]
    simp only [bitAddressZero_iff,hc]
    split_ifs with h
    · rw [h,List.set_cons_zero]
      simp only [show copy = id from funext hc,List.map_id_fun,id_eq]
    · have ha : binaryDigitsValue address = (binaryDigitsValue address-1)+1 := by omega
      rw [ih,bitAddressPred_value,ha,List.set_cons_succ]
      congr 2

/-- Fixed-size list-backed array. Its length proof is erased at execution. -/
structure BooleanListArray (α : Type*) (n : ℕ) where
  data : List α
  length_eq : data.length = n
  deriving Repr

namespace BooleanListArray

def ofFn {α : Type*} {n : ℕ} (f : Fin n → α) : BooleanListArray α n :=
  ⟨List.ofFn f,by simp⟩

def replicate {α : Type*} (n : ℕ) (x : α) : BooleanListArray α n :=
  ⟨List.replicate n x,by simp⟩

def read {α : Type*} {n : ℕ} (copy : α → α) (a : BooleanListArray α n) (i : Fin n) : α :=
  let result := bitIndexedRead copy (bitUnaryAddress i.val) a.data
  result.get (by
    simp only [result,bitIndexedRead_correct,bitUnaryAddress_value]
    rw [List.getElem?_eq_getElem (by simpa only [a.length_eq] using i.isLt)]
    rfl)

theorem read_eq {α : Type*} {n : ℕ} (copy : α → α) (a : BooleanListArray α n) (i : Fin n) :
    read copy a i = copy (a.data[i.val]'(by simpa only [a.length_eq] using i.isLt)) := by
  unfold read
  have hi : i.val < a.data.length := by rw [a.length_eq]; exact i.isLt
  simp only [bitIndexedRead_correct,bitUnaryAddress_value,List.getElem?_eq_getElem hi]
  rfl

def write {α : Type*} {n : ℕ} (copy : α → α) (a : BooleanListArray α n) (i : Fin n) (x : α) :
    BooleanListArray α n :=
  ⟨bitIndexedWrite copy (bitUnaryAddress i.val) x a.data,by rw [bitIndexedWrite_length,a.length_eq]⟩

def copy {α : Type*} {n : ℕ} (f : α → α) (a : BooleanListArray α n) : BooleanListArray α n :=
  ⟨a.data.map f,by rw [List.length_map,a.length_eq]⟩

theorem copy_eq {α : Type*} {n : ℕ} (f : α → α) (hf : ∀ x, f x = x) (a : BooleanListArray α n) :
    copy f a = a := by
  cases a
  simp only [copy,show f = id from funext hf,List.map_id_fun,id_eq]

/-- Mathematical projection to the already verified array implementation. -/
def toVector {α : Type*} {n : ℕ} (a : BooleanListArray α n) : Vector α n :=
  Vector.ofFn fun i => a.data[i.val]'(by simpa only [a.length_eq] using i.isLt)

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

theorem read_toVector {α : Type*} {n : ℕ} (f : α → α) (hf : ∀ x, f x = x)
    (a : BooleanListArray α n) (i : Fin n) : read f a i = a.toVector.get i := by
  rw [read_eq,hf]
  simp only [toVector,get_ofFn]

theorem ofFn_toVector {α : Type*} {n : ℕ} (f : Fin n → α) : (ofFn f).toVector = Vector.ofFn f := by
  apply Vector.ext
  intro i hi
  change ((ofFn f).toVector).get ⟨i,hi⟩ = (Vector.ofFn f).get ⟨i,hi⟩
  simp only [toVector,get_ofFn,ofFn,List.getElem_ofFn]

theorem replicate_toVector {α : Type*} (n : ℕ) (x : α) :
    (replicate n x).toVector = Vector.replicate n x := by
  apply Vector.ext
  intro i hi
  change ((replicate n x).toVector).get ⟨i,hi⟩ = (Vector.replicate n x).get ⟨i,hi⟩
  simp [toVector,get_ofFn,replicate,Vector.get]

theorem write_toVector {α : Type*} {n : ℕ} (f : α → α) (hf : ∀ x, f x = x)
    (a : BooleanListArray α n) (i : Fin n) (x : α) :
    (write f a i x).toVector = a.toVector.set i.val x i.isLt := by
  apply Vector.ext
  intro j hj
  change ((write f a i x).toVector).get ⟨j,hj⟩ = (a.toVector.set i.val x i.isLt).get ⟨j,hj⟩
  simp only [toVector,get_ofFn,write,bitIndexedWrite_correct f hf,bitUnaryAddress_value]
  change _ = (a.toVector.set i.val x i.isLt)[j]
  rw [Vector.getElem_set]
  by_cases h : i.val = j
  · subst j
    simp
  · simp [List.getElem_set,h,Ne.symm h,toVector,Vector.getElem_ofFn]

end BooleanListArray

end Optss
