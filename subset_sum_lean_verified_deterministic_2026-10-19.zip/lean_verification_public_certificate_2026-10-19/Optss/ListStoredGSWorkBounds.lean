import Optss.ListStoredAccessBounds
import Optss.ListStoredPayloadBounds

/-! Polynomial storage bounds for the actual list-backed Gram--Schmidt cache.
The input payload premise is propagated by actual cumulative scalar work. -/
namespace Optss
open scoped BigOperators
variable {r d : ℕ}

theorem listFractionMatrixReadWork_bound (A : ListBitRationalMatrixData r d) (B : ℕ)
    (hB : ∀ i j, fractionPayload (((listMatrixVector A).get i).get j) ≤ B) (i : Fin r) (j : Fin d) :
    listMatrixReadWork listCopyFraction listCopyFractionWork A i j ≤
      1024*(r+d+1)^4*(B+2) := by
  have h := listMatrixReadWork_le listCopyFraction listCopyFraction_eq listCopyFractionWork A i j (2*B+3)
    (fun a b => by rw [listCopyFractionWork_eq]; exact Nat.add_le_add_right (Nat.mul_le_mul_left 2 (hB a b)) 3)
  apply (h.trans (listMatrixAccessBound_le _ _ _)).trans_eq
  ring

theorem listStoredGsCoefficientStorageWork_bound (A T : ListBitRationalMatrixData r d)
    (k j : Fin r) (B : ℕ)
    (hA : ∀ i l, fractionPayload (((listMatrixVector A).get i).get l) ≤ B)
    (hT : ∀ i l, fractionPayload (((listMatrixVector T).get i).get l) ≤ B) :
    listStoredGsCoefficientStorageWork A T k j ≤ 8192*(r+d+1)^5*(B+2) := by
  let S := r+d+1
  let V := 1024*S^4*(B+2)
  have hu := listFractionMatrixReadWork_bound T B hT j
  have hv := listFractionMatrixReadWork_bound A B hA k
  have h₁ := listProductStorageWork_le
    (listMatrixReadWork listCopyFraction listCopyFractionWork T j)
    (listMatrixReadWork listCopyFraction listCopyFractionWork A k) (List.ofFn id) V V
    (fun l _ => hu l) (fun l _ => hv l)
  have h₂ := listProductStorageWork_le
    (listMatrixReadWork listCopyFraction listCopyFractionWork T j)
    (listMatrixReadWork listCopyFraction listCopyFractionWork T j) (List.ofFn id) V V
    (fun l _ => hu l) (fun l _ => hu l)
  simp only [List.length_ofFn] at h₁ h₂
  have he := listIndexEnumerationWork_le d
  have hd : d+1 ≤ S := by dsimp [S]; omega
  have hS : 1 ≤ S := by dsimp [S]; omega
  have hp3 : (d+1)^3 ≤ S^5 := (Nat.pow_le_pow_left hd 3).trans (Nat.pow_le_pow_right hS (by omega))
  have hp1 : d ≤ S^5 := (show d ≤ S by omega).trans (by simpa using Nat.pow_le_pow_right hS (by omega : 1≤5))
  have hm : d*V ≤ 1024*S^5*(B+2) := by
    calc
      _ ≤ S*V := Nat.mul_le_mul_right _ (by omega)
      _ = _ := by dsimp [V]; ring
  have hp0 : 1 ≤ S^5 := one_le_pow₀ hS
  unfold listStoredGsCoefficientStorageWork listDotStorageWork
  change _ ≤ 8192*S^5*(B+2)
  nlinarith

theorem listStoredGSCoefficientsStorageWork_bound (A T : ListBitRationalMatrixData r d)
    (k : Fin r) (B : ℕ)
    (hA : ∀ i l, fractionPayload (((listMatrixVector A).get i).get l) ≤ B)
    (hT : ∀ i l, fractionPayload (((listMatrixVector T).get i).get l) ≤ B) :
    listStoredGSCoefficientsStorageWork A T k ≤ 16384*(r+d+1)^6*(B+2) := by
  let S := r+d+1
  have hS : 1 ≤ S := by dsimp [S]; omega
  have hr : r≤S := by dsimp [S]; omega
  have he := listIndexEnumerationWork_le r
  have hp3 : (r+1)^3 ≤ S^6 := (Nat.pow_le_pow_left (by dsimp [S]; omega) 3).trans (Nat.pow_le_pow_right hS (by omega))
  have hsum : (∑ i : Fin r, (bitIndexLTWork i k+
      if bitIndexLT i k then listStoredGsCoefficientStorageWork A T k i else 1)) ≤
      r*(260*S^2+8192*S^5*(B+2)+1) := by
    calc
      _ ≤ ∑ _i : Fin r, (260*S^2+8192*S^5*(B+2)+1) := by
        apply Finset.sum_le_sum
        intro i _
        have hc : listStoredGsCoefficientStorageWork A T k i ≤ 8192*S^5*(B+2) :=
          listStoredGsCoefficientStorageWork_bound A T k i B hA hT
        have hi := bitIndexLTWork_le i k
        have hs : (r+r+1)^2 ≤ 4*S^2 := by
          have hh := Nat.pow_le_pow_left (show r+r+1≤2*S by dsimp [S]; omega) 2
          nlinarith
        split_ifs <;> nlinarith
      _ = _ := by simp
  have hm : r*(260*S^2+8192*S^5*(B+2)+1) ≤
      260*S^3+8192*S^6*(B+2)+S := by
    calc
      _ ≤ S*(260*S^2+8192*S^5*(B+2)+1) := Nat.mul_le_mul_right _ hr
      _ = _ := by ring
  have hp36 : S^3 ≤ S^6 := Nat.pow_le_pow_right hS (by omega)
  have hp16 : S ≤ S^6 := by simpa using Nat.pow_le_pow_right hS (by omega : 1≤6)
  unfold listStoredGSCoefficientsStorageWork
  change _ ≤ 16384*S^6*(B+2)
  nlinarith


theorem listStoredGSRowStorageWork_bound (A T : ListBitRationalMatrixData r d)
    (k : Fin r) (B : ℕ)
    (hA : ∀ i l, fractionPayload (((listMatrixVector A).get i).get l) ≤ B)
    (hT : ∀ i l, fractionPayload (((listMatrixVector T).get i).get l) ≤ B) :
    listStoredGSRowStorageWork A T k ≤ 65536*(r+d+1)^7*
      (B+encodedGSRowWork (listMatrixVector A) (listMatrixVector T) k+2) := by
  let S := r+d+1
  let W := encodedGSRowWork (listMatrixVector A) (listMatrixVector T) k
  let X := B+W+2
  let F := listStorageFactor r d
  let V := F*X
  let coeff := listStoredGSCoefficients A T k
  have hS : 1≤S := by dsimp [S]; omega
  have hr : r≤S := by dsimp [S]; omega
  have hd : d≤S := by dsimp [S]; omega
  have hF : 1≤F := listStorageFactor_pos r d
  have hX : 1≤X := by dsimp [X]; omega
  have hFV : F≤V := by dsimp [V]; nlinarith
  have hV : 1≤V := hF.trans hFV
  have hcoeff (i : Fin r) : fractionPayload (coeff.toVector.get i) ≤ 1+W := by
    have h := encodedGSCoefficients_output_le_work (listMatrixVector A) (listMatrixVector T) k i
    have hs : (∑ j : Fin r, if j<k then encodedGsCoefficientWork (listMatrixVector A) (listMatrixVector T) k j else 0) ≤ W := by
      dsimp only [W,encodedGSRowWork]
      omega
    change fractionPayload ((listStoredGSCoefficients A T k).toVector.get i) ≤ _
    rw [listStoredGSCoefficients_eq]
    exact h.trans (Nat.add_le_add_left hs 1)
  have hcRead (i : Fin r) : coeff.readWork listCopyFractionWork i ≤ V := by
    have h := listFractionArrayReadWork_le (d := d) coeff i (1+W) hcoeff
    exact h.trans (Nat.mul_le_mul_left F (by dsimp [X]; omega))
  have hARead (i : Fin r) (l : Fin d) :
      listMatrixReadWork listCopyFraction listCopyFractionWork A i l ≤ V :=
    (listFractionReadWork_le A i l B hA).trans (Nat.mul_le_mul_left F (by dsimp [X]; omega))
  have hTRead (i : Fin r) (l : Fin d) :
      listMatrixReadWork listCopyFraction listCopyFractionWork T i l ≤ V :=
    (listFractionReadWork_le T i l B hT).trans (Nat.mul_le_mul_left F (by dsimp [X]; omega))
  have he : listIndexEnumerationWork d≤F := listEnumerationWork_factor d (by omega)
  have hek : listIndexEnumerationWork k.val≤F := listEnumerationWork_factor k.val (by omega)
  have hper (l : Fin d) :
      listIndexEnumerationWork k.val+
        listProductStorageWork (fun i : Finset.Iio k => coeff.readWork listCopyFractionWork i)
          (fun i => listMatrixReadWork listCopyFraction listCopyFractionWork T i l)
          (List.ofFn (lowerFinEquiv k))+
        listMatrixReadWork listCopyFraction listCopyFractionWork A k l+3 ≤ 16*S*V := by
    have hp := listProductStorageWork_le
      (fun i : Finset.Iio k => coeff.readWork listCopyFractionWork i)
      (fun i => listMatrixReadWork listCopyFraction listCopyFractionWork T i l)
      (List.ofFn (lowerFinEquiv k)) V V (fun i _ => hcRead i) (fun i _ => hTRead i l)
    simp only [List.length_ofFn] at hp
    have hk : k.val≤S := by have h := k.isLt; omega
    have ha := hARead k l
    have hkm := Nat.mul_le_mul_right (V+V+3) hk
    have hSV : V≤S*V := by nlinarith
    have hSV' : S≤S*V := by nlinarith
    nlinarith
  have hsum : (∑ l : Fin d, (listIndexEnumerationWork k.val+
        listProductStorageWork (fun i : Finset.Iio k => coeff.readWork listCopyFractionWork i)
          (fun i => listMatrixReadWork listCopyFraction listCopyFractionWork T i l)
          (List.ofFn (lowerFinEquiv k))+
        listMatrixReadWork listCopyFraction listCopyFractionWork A k l+3)) ≤ 16*S^2*V := by
    calc
      _ ≤ ∑ _l : Fin d, 16*S*V := Finset.sum_le_sum (fun l _ => hper l)
      _ = d*(16*S*V) := by simp
      _ ≤ S*(16*S*V) := Nat.mul_le_mul_right _ hd
      _ = _ := by ring
  have hc : listStoredGSCoefficientsStorageWork A T k ≤ 8*S^2*V := by
    apply (listStoredGSCoefficientsStorageWork_bound A T k B hA hT).trans
    calc
      _ ≤ 16384*S^6*X := by change 16384*S^6*(B+2)≤_; gcongr; dsimp [X]; omega
      _ = _ := by dsimp [V,F,listStorageFactor,S]; ring
  have hp : V≤S^2*V := by nlinarith [one_le_pow₀ hS (n := 2)]
  have ht : 32*S^2*V≤65536*S^7*X := by
    calc
      _ = 65536*S^6*X := by dsimp [V,F,listStorageFactor,S]; ring
      _ ≤ _ := Nat.mul_le_mul_right X (Nat.mul_le_mul_left 65536 (Nat.pow_le_pow_right hS (by omega)))
  unfold listStoredGSRowStorageWork
  change _≤65536*S^7*X
  apply LE.le.trans (b := 32*S^2*V) ?_ ht
  change listStoredGSCoefficientsStorageWork A T k+listIndexEnumerationWork d+
    (∑ l : Fin d, (listIndexEnumerationWork k.val+
        listProductStorageWork (fun i : Finset.Iio k => coeff.readWork listCopyFractionWork i)
          (fun i => listMatrixReadWork listCopyFraction listCopyFractionWork T i l)
          (List.ofFn (lowerFinEquiv k))+
        listMatrixReadWork listCopyFraction listCopyFractionWork A k l+3)) ≤ _
  nlinarith


set_option maxRecDepth 4096 in
private theorem listStoredGSTableStorageWork_steps (A : ListBitRationalMatrixData r d)
    (n : ℕ) (hn : n≤r) (B : ℕ)
    (hA : ∀ i l, fractionPayload (((listMatrixVector A).get i).get l) ≤ B) :
    listStoredGSTableStorageWork A n hn ≤
      (n+1)*(262144*(r+d+1)^7)*(B+encodedGSTableWork (listMatrixVector A) n hn+2) := by
  let S := r+d+1
  let F := listStorageFactor r d
  let H := 65536*S^7
  have hS : 1≤S := by dsimp [S]; omega
  have hFpos : 1≤F := listStorageFactor_pos r d
  have hF : F≤2048*S^7 := by
    dsimp [F,listStorageFactor]
    exact Nat.mul_le_mul_left _ (Nat.pow_le_pow_right hS (by omega))
  have hFH : F+3≤H := by
    have hp := one_le_pow₀ hS (n := 7)
    dsimp [H]
    omega
  induction n with
  | zero =>
    have her : listIndexEnumerationWork r≤F := listEnumerationWork_factor r (by omega)
    have hed : listIndexEnumerationWork d≤F := listEnumerationWork_factor d (by omega)
    have hr : r≤S := by dsimp [S]; omega
    have hd : d≤S := by dsimp [S]; omega
    have hS2 : S^2≤S^7 := Nat.pow_le_pow_right hS (by omega)
    have hS5 : S^5≤S^7 := Nat.pow_le_pow_right hS (by omega)
    have hrf : r*F≤2048*S^5 := by
      calc
        _ ≤ S*F := Nat.mul_le_mul_right _ hr
        _ = 2048*S^5 := by dsimp [F,listStorageFactor,S]; ring
    have hrd : r*d≤S^2 := by nlinarith
    have hmul := Nat.mul_le_mul_left r hed
    rw [listStoredGSTableStorageWork,encodedGSTableWork]
    change listIndexEnumerationWork r+r*listIndexEnumerationWork d+2*r*d+1≤
      (0+1)*(262144*S^7)*(B+0+2)
    nlinarith
  | succ n ih =>
    let k : Fin r := ⟨n,by omega⟩
    let T := listStoredGSTable A n (by omega)
    let row := listStoredGSRow A T k
    let W := encodedGSTableWork (listMatrixVector A) n (by omega)
    let V := encodedGSRowWork (listMatrixVector A) (listMatrixVector T) k
    let X := B+(W+V)+2
    have hX : 1≤X := by dsimp [X]; omega
    have hT : ∀ i l, fractionPayload (((listMatrixVector T).get i).get l) ≤ 1+W := by
      intro i l
      dsimp only [T]
      rw [listStoredGSTable_eq]
      exact encodedGSTable_output_le_work _ n _ i l
    have hrow : ∀ l, fractionPayload (row.toVector.get l) ≤ V := by
      intro l
      dsimp only [row]
      rw [listStoredGSRow_eq]
      exact encodedGSRow_output_le_work _ _ k l
    have hrowWork := listStoredGSRowStorageWork_bound A T k (B+1+W)
      (fun i l => (hA i l).trans (by omega)) (fun i l => (hT i l).trans (by omega))
    change listStoredGSRowStorageWork A T k≤H*(B+1+W+V+2) at hrowWork
    have hrowW : listStoredGSRowStorageWork A T k≤2*H*X := by
      have hx : B+1+W+V+2≤2*X := by dsimp [X]; omega
      exact hrowWork.trans ((Nat.mul_le_mul_left H hx).trans_eq (by ring))
    have hwrite := listFractionWriteWork_le T k row (B+W+V+1)
      (fun i l => (hT i l).trans (by omega)) (fun l => (hrow l).trans (by omega))
    have hwrite' : listMatrixWriteWork listCopyFractionWork T k row≤H*X := by
      apply hwrite.trans
      change F*(B+W+V+1+1)≤H*X
      have hx : B+W+V+1+1=X := by dsimp [X]; omega
      rw [hx]
      exact Nat.mul_le_mul_right X (by omega)
    have ha : bitUnaryAddressWork n≤F := bitUnaryAddressWork_factor n (by omega)
    have ha' : bitUnaryAddressWork n+3≤H*X := by nlinarith
    have hi := ih (by omega)
    change listStoredGSTableStorageWork A n _≤(n+1)*(262144*S^7)*(B+W+2) at hi
    have heH : 262144*S^7=4*H := by dsimp [H]; ring
    rw [heH] at hi
    have hi' : listStoredGSTableStorageWork A n (by omega)≤(n+1)*(4*H)*X :=
      hi.trans (Nat.mul_le_mul_left _ (by dsimp [X]; omega))
    rw [listStoredGSTableStorageWork,encodedGSTableWork]
    change listStoredGSTableStorageWork A n _+listStoredGSRowStorageWork A T k+
      listMatrixWriteWork listCopyFractionWork T k row+bitUnaryAddressWork n+3≤
      (n+1+1)*(262144*S^7)*(B+(W+encodedGSRowWork (listMatrixVector A)
        (encodedGSTable (listMatrixVector A) n _) k)+2)
    rw [← listStoredGSTable_eq,heH]
    change _≤(n+1+1)*(4*H)*X
    nlinarith

theorem listStoredGSTableStorageWork_bound (A : ListBitRationalMatrixData r d)
    (n : ℕ) (hn : n≤r) (B : ℕ)
    (hA : ∀ i l, fractionPayload (((listMatrixVector A).get i).get l) ≤ B) :
    listStoredGSTableStorageWork A n hn ≤ 262144*(r+d+1)^8*
      (B+encodedGSTableWork (listMatrixVector A) n hn+2) := by
  apply (listStoredGSTableStorageWork_steps A n hn B hA).trans
  calc
    _ ≤ (r+d+1)*(262144*(r+d+1)^7)*(B+encodedGSTableWork (listMatrixVector A) n hn+2) := by gcongr; omega
    _ = _ := by ring

end Optss
