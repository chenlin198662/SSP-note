import Optss.GridAffine
import Mathlib.Algebra.Group.Pointwise.Finset.Basic
import Mathlib.Data.Matrix.Notation

/-!
# Lifting a double difference through an eight-term Freiman model

The model preserves and reflects eight-term relations on the original set.
Consequently its inverse on 2A-2A is well defined and preserves all two-term
relations there. This supplies the local equations needed to lift a GAP.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {G H : Type*} [AddCommGroup G] [AddCommGroup H] [DecidableEq G] [DecidableEq H]

def FreimanEight (A : Finset G) (f : G → H) : Prop :=
  ∀ a b : Fin 8 → G, (∀ i, a i∈A) → (∀ i, b i∈A) →
    ((∑ i, f (a i)) = (∑ i, f (b i)) ↔ (∑ i, a i) = (∑ i, b i))

def fourDifference (u : Fin 4 → G) : G := u 0+u 1-u 2-u 3

theorem mem_doubleDifference_iff (A : Finset G) (x : G) :
    x ∈ (A+A)-(A+A) ↔ ∃ u : Fin 4 → G, (∀ i,u i∈A) ∧ fourDifference u=x := by
  constructor
  · intro hx
    obtain ⟨a,ha,b,hb,rfl⟩ := Finset.mem_sub.mp hx
    obtain ⟨a₀,ha₀,a₁,ha₁,rfl⟩ := Finset.mem_add.mp ha
    obtain ⟨b₀,hb₀,b₁,hb₁,rfl⟩ := Finset.mem_add.mp hb
    refine ⟨![a₀,a₁,b₀,b₁],?_,?_⟩
    · intro i
      fin_cases i <;> simp [ha₀,ha₁,hb₀,hb₁]
    · simp only [fourDifference,Matrix.cons_val_zero,Matrix.cons_val_one,
        Matrix.cons_val_two,Matrix.cons_val_three]
      abel
  · rintro ⟨u,hu,rfl⟩
    refine Finset.mem_sub.mpr ⟨u 0+u 1,Finset.add_mem_add (hu 0) (hu 1),
      u 2+u 3,Finset.add_mem_add (hu 2) (hu 3),?_⟩
    dsimp only [fourDifference]
    abel

omit [AddCommGroup G] in
theorem mem_model_doubleDifference_iff (A : Finset G) (f : G → H) (x : H) :
    x ∈ (A.image f+A.image f)-(A.image f+A.image f) ↔
      ∃ u : Fin 4 → G, (∀ i,u i∈A) ∧ fourDifference (f ∘ u)=x := by
  rw [mem_doubleDifference_iff]
  constructor
  · rintro ⟨v,hv,hval⟩
    have hpre : ∀ i, ∃ a∈A,f a=v i := fun i => Finset.mem_image.mp (hv i)
    choose u hu he using hpre
    refine ⟨u,hu,?_⟩
    have hfun : f ∘ u=v := funext he
    rwa [hfun]
  · rintro ⟨u,hu,hval⟩
    exact ⟨f ∘ u,fun i => Finset.mem_image.mpr ⟨u i,hu i,rfl⟩,hval⟩

theorem FreimanEight.fourDifference_add_iff {A : Finset G} {f : G → H}
    (hf : FreimanEight A f) (u v w z : Fin 4 → G)
    (hu : ∀ i,u i∈A) (hv : ∀ i,v i∈A) (hw : ∀ i,w i∈A) (hz : ∀ i,z i∈A) :
    fourDifference (f ∘ u)+fourDifference (f ∘ v)=
        fourDifference (f ∘ w)+fourDifference (f ∘ z) ↔
      fourDifference u+fourDifference v=fourDifference w+fourDifference z := by
  let a : Fin 8 → G := ![u 0,u 1,v 0,v 1,w 2,w 3,z 2,z 3]
  let b : Fin 8 → G := ![u 2,u 3,v 2,v 3,w 0,w 1,z 0,z 1]
  have ha : ∀ i,a i∈A := by intro i; fin_cases i <;> simp [a,hu,hv,hw,hz]
  have hb : ∀ i,b i∈A := by intro i; fin_cases i <;> simp [b,hu,hv,hw,hz]
  have he := hf a b ha hb
  simp only [a,b,Fin.sum_univ_succ,Fin.sum_univ_zero,Fin.val_zero,
    Matrix.cons_val_zero,Matrix.cons_val_succ,add_zero] at he
  dsimp only [fourDifference,Function.comp_apply]
  constructor
  · intro h
    have h' := he.mp (by
      apply sub_eq_zero.mp
      convert (sub_eq_zero.mpr h) using 1; abel)
    apply sub_eq_zero.mp
    convert (sub_eq_zero.mpr h') using 1; abel
  · intro h
    have h' := he.mpr (by
      apply sub_eq_zero.mp
      convert (sub_eq_zero.mpr h) using 1; abel)
    apply sub_eq_zero.mp
    convert (sub_eq_zero.mpr h') using 1; abel

theorem FreimanEight.fourDifference_eq_iff {A : Finset G} {f : G → H}
    (hf : FreimanEight A f) (u v : Fin 4 → G)
    (hu : ∀ i,u i∈A) (hv : ∀ i,v i∈A) :
    fourDifference (f ∘ u)=fourDifference (f ∘ v) ↔ fourDifference u=fourDifference v := by
  have h := hf.fourDifference_add_iff u u v u hu hu hv hu
  simpa only [add_right_cancel_iff] using h

/-- Choose an original representation of a model double difference. The
following theorem proves independence of the chosen representation. -/
def modelDifferenceLift (A : Finset G) (f : G → H) (x : H) : G :=
  if h : ∃ u : Fin 4 → G, (∀ i,u i∈A) ∧ fourDifference (f ∘ u)=x then
    fourDifference (Classical.choose h)
  else 0

theorem modelDifferenceLift_representation {A : Finset G} {f : G → H}
    (hf : FreimanEight A f) (u : Fin 4 → G) (hu : ∀ i,u i∈A) :
    modelDifferenceLift A f (fourDifference (f ∘ u)) = fourDifference u := by
  have hex : ∃ v : Fin 4 → G, (∀ i,v i∈A) ∧
      fourDifference (f ∘ v)=fourDifference (f ∘ u) := ⟨u,hu,rfl⟩
  rw [modelDifferenceLift,dif_pos hex]
  exact (hf.fourDifference_eq_iff _ u (Classical.choose_spec hex).1 hu).mp
    (Classical.choose_spec hex).2

theorem modelDifferenceLift_mem {A : Finset G} {f : G → H}
    (hf : FreimanEight A f) {x : H}
    (hx : x∈(A.image f+A.image f)-(A.image f+A.image f)) :
    modelDifferenceLift A f x ∈ (A+A)-(A+A) := by
  obtain ⟨u,hu,rfl⟩ := (mem_model_doubleDifference_iff A f x).mp hx
  rw [modelDifferenceLift_representation hf u hu]
  exact (mem_doubleDifference_iff A _).mpr ⟨u,hu,rfl⟩

theorem modelDifferenceLift_injective {A : Finset G} {f : G → H}
    (hf : FreimanEight A f) :
    Set.InjOn (modelDifferenceLift A f)
      ((A.image f+A.image f)-(A.image f+A.image f) : Finset H) := by
  intro x hx y hy he
  obtain ⟨u,hu,rfl⟩ := (mem_model_doubleDifference_iff A f x).mp hx
  obtain ⟨v,hv,rfl⟩ := (mem_model_doubleDifference_iff A f y).mp hy
  rw [modelDifferenceLift_representation hf u hu,modelDifferenceLift_representation hf v hv] at he
  exact (hf.fourDifference_eq_iff u v hu hv).mpr he

theorem modelDifferenceLift_add_iff {A : Finset G} {f : G → H}
    (hf : FreimanEight A f) {x y z w : H}
    (hx : x∈(A.image f+A.image f)-(A.image f+A.image f))
    (hy : y∈(A.image f+A.image f)-(A.image f+A.image f))
    (hz : z∈(A.image f+A.image f)-(A.image f+A.image f))
    (hw : w∈(A.image f+A.image f)-(A.image f+A.image f)) :
    modelDifferenceLift A f x+modelDifferenceLift A f y=
        modelDifferenceLift A f z+modelDifferenceLift A f w ↔ x+y=z+w := by
  obtain ⟨u,hu,rfl⟩ := (mem_model_doubleDifference_iff A f x).mp hx
  obtain ⟨v,hv,rfl⟩ := (mem_model_doubleDifference_iff A f y).mp hy
  obtain ⟨p,hp,rfl⟩ := (mem_model_doubleDifference_iff A f z).mp hz
  obtain ⟨q,hq,rfl⟩ := (mem_model_doubleDifference_iff A f w).mp hw
  rw [modelDifferenceLift_representation hf u hu,modelDifferenceLift_representation hf v hv,
    modelDifferenceLift_representation hf p hp,modelDifferenceLift_representation hf q hq]
  exact (hf.fourDifference_add_iff u v p q hu hv hp hq).symm

theorem modelDifferenceLift_zero {A : Finset G} {f : G → H}
    (hf : FreimanEight A f) (hA : A.Nonempty) : modelDifferenceLift A f 0=0 := by
  obtain ⟨a,ha⟩ := hA
  have h := modelDifferenceLift_representation hf (fun _ => a) (fun _ => ha)
  simpa [fourDifference,Function.comp_def] using h

theorem modelDifferenceLift_image {A : Finset G} {f : G → H}
    (hf : FreimanEight A f) :
    (((A.image f+A.image f)-(A.image f+A.image f)).image (modelDifferenceLift A f)) =
      (A+A)-(A+A) := by
  ext x
  constructor
  · rintro hx
    obtain ⟨y,hy,rfl⟩ := Finset.mem_image.mp hx
    exact modelDifferenceLift_mem hf hy
  · intro hx
    obtain ⟨u,hu,rfl⟩ := (mem_doubleDifference_iff A x).mp hx
    exact Finset.mem_image.mpr ⟨fourDifference (f ∘ u),
      (mem_model_doubleDifference_iff A f _).mpr ⟨u,hu,rfl⟩,
      modelDifferenceLift_representation hf u hu⟩

end
end Optss
