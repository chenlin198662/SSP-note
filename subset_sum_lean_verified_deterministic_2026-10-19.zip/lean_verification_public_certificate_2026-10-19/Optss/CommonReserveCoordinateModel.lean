import Optss.CommonReserveStructure

/-!
# The common reserve in exact integer coordinates

Dense blocks provide a basis of their entire shared lattice. The resulting
coordinate model simultaneously represents the original labels, fills the
reserve box, is proper on that same dilation, and preserves every protected
rank statement for the remainder.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1400000

/-- The mathematical common-GAP data, with actual labelled reserve witnesses. -/
structure CommonReserveCoordinateModel {ι : Type} [DecidableEq ι] (d : ℕ)
    (scalar : ι → ℤ) (available reserve remainder : Finset ι) (h extra : ℕ) (c : ℝ) where
  widths : Fin d → ℕ
  coordinates : ι → IntVec d
  projection : IntVec d →+ ℤ
  positive : ∀ j, 1 ≤ widths j
  represents : ∀ i ∈ available, projection (coordinates i) = scalar i
  boxed : ∀ i ∈ available, InCenteredBox widths (coordinates i)
  reserve_generates : generatedLattice coordinates reserve = ⊤
  remainder_generates : generatedLattice coordinates remainder = ⊤
  rank_protected : ∀ D : Finset ι, D.card ≤ extra →
    labelSpan ℝ (fun i => realVector (coordinates i)) (remainder \ D) = ⊤
  proper : ∀ x y : IntVec d,
    (∀ j, |(x j : ℝ)| ≤ c*h*widths j) →
    (∀ j, |(y j : ℝ)| ≤ c*h*widths j) → projection x = projection y → x = y
  filled : ∃ t : IntVec d, ∀ z : IntVec d,
    (∀ j, |(z j : ℝ)| ≤ c*h*widths j) →
    t+z ∈ labelledSubsetSupport coordinates reserve

/-- Derive every common-coordinate conclusion from dense actual block
supports. Neither the coordinate inverse nor reserve-coordinate witnesses are
additional premises. -/
theorem common_reserve_coordinate_model {ι : Type} [DecidableEq ι] {d : ℕ}
    (hd : 0 < d) (v : ι → IntVec d) (scalar : ι → ℤ)
    (available reserve remainder : Finset ι)
    (hR : reserve ⊆ available) (hT : remainder ⊆ available)
    (hfull : labelSpan ℝ (fun i => realVector (v i)) available = ⊤)
    (w : Fin d → ℕ) (hbox : ∀ i ∈ available, InCenteredBox w (v i))
    (ρ : IntVec d →+ ℤ) (hrepr : ∀ i ∈ available, ρ (v i) = scalar i)
    (h B K M N extra : ℕ) (hh : 1 ≤ h) (hhB : h ≤ B)
    (hK : 1 ≤ K) (hBK : B ≤ K*h)
    (hρ : Set.InjOn ρ (integerBudgetBox (fun j => 20*h*w j)))
    (C : ℝ) (hC : 0 < C)
    (hvolume : ((integerBudgetBox (fun j => h*w j)).card : ℝ) ≤ C*M)
    (A : ℕ → Finset (IntVec d))
    (hAbox : ∀ i < N, ∀ x ∈ A i, InCenteredBox (fun j => B*w j) x)
    (hdense : ∀ i < N, (M : ℝ)/4 ≤ (A i).card)
    (hzero : ∀ i < N, 0 ∈ A i)
    (hgen : ∀ i < N, AddSubgroup.closure (A i : Set (IntVec d)) = generatedLattice v available)
    (hsupport : labelledSubsetSupport v reserve = ∑ i ∈ Finset.range N, A i)
    (hRgen : generatedLattice v reserve = generatedLattice v available)
    (hTgen : generatedLattice v remainder = generatedLattice v available)
    (hprotected : ∀ D : Finset ι, D.card ≤ extra →
      labelSpan ℝ (fun i => realVector (v i)) (remainder \ D) = ⊤)
    (hN0 : 0 < N) (hN : denseBoxSummandThreshold d (commonBoxBlockDensity d K C) ≤ N)
    (hwidth : denseBoxWidthThreshold (commonBoxBlockDensity d K C) ≤ 2*B+1) :
    Nonempty (CommonReserveCoordinateModel d scalar available reserve remainder h extra
      (commonBoxFilledScale d K C N)) := by
  obtain ⟨b, hΛ, n, hn, hinner, houter, _, t, ht, hfill⟩ :=
    common_box_dense_blocks_filling hd v available hfull w hbox h B K M N
      (hh.trans hhB) hK hBK C hC hvolume A hAbox hdense hzero hgen hN hwidth
  let Γ := generatedLattice v available
  let σ := subgroupBasisSynthesisHom Γ b hΛ
  let u : ι → IntVec d := fun i => commonLatticeCoordinate σ (v i)
  let c := commonBoxFilledScale d K C N
  have hσ : Function.Injective σ := subgroupBasisSynthesisHom_injective _ _ _
  have hσrange : σ.range = Γ := subgroupBasisSynthesisHom_range _ _ _
  have hΓ : ∀ i ∈ available, v i ∈ Γ := fun i hi => AddSubgroup.subset_closure ⟨i, hi, rfl⟩
  have hu : ∀ i ∈ available, σ (u i) = v i :=
    fun i hi => commonLatticeCoordinate_represents σ _ (hσrange.symm ▸ hΓ i hi)
  have hc : 0 < c := commonBoxFilledScale_pos hd K hK C hC N hN0
  have hhr : (0 : ℝ) < h := by exact_mod_cast (show 0 < h by omega)
  have hscale : (c*h)*denseLatticeBoxingConstant d ≤ (20*h : ℕ) := by
    have hJ := denseLatticeBoxingConstant_pos hd
    have hcη : c ≤ denseLatticeProperScale d := min_le_left _ _
    have hmul := mul_le_mul_of_nonneg_right hcη (mul_nonneg hhr.le hJ.le)
    have he : denseLatticeProperScale d*((h : ℝ)*denseLatticeBoxingConstant d) = h/4 := by
      unfold denseLatticeProperScale
      field_simp
      ring
    rw [he] at hmul
    push_cast
    nlinarith
  have hproper := common_basis_scalar_proper hd Γ b hΛ n w ρ (20*h) hρ houter
    (c*h) (mul_pos hc hhr) hscale
  refine ⟨{
    widths := n
    coordinates := u
    projection := ρ.comp σ
    positive := hn
    represents := ?_
    boxed := ?_
    reserve_generates := ?_
    remainder_generates := ?_
    rank_protected := ?_
    proper := ?_
    filled := ?_ }⟩
  · intro i hi
    change ρ (σ (u i)) = scalar i
    rw [hu i hi]
    exact hrepr i hi
  · intro i hi
    apply commonLatticeCoordinate_box Γ b hΛ n (v i) (hΓ i hi)
    apply hinner
    rw [mem_realCoefficientBox]
    intro j
    change |(v i j : ℝ)| ≤ (w j : ℝ)
    exact_mod_cast hbox i hi j
  · exact generatedLattice_eq_top_of_full_image σ hσ u v reserve
      (fun i hi => hu i (hR hi)) (hRgen.trans hσrange.symm)
  · exact generatedLattice_eq_top_of_full_image σ hσ u v remainder
      (fun i hi => hu i (hT hi)) (hTgen.trans hσrange.symm)
  · intro D hD
    exact commonLatticeCoordinate_full_rank Γ b hΛ v (remainder \ D)
      (fun i hi => hΓ i (hT (Finset.mem_sdiff.mp hi).1)) (hprotected D hD)
  · intro x y hx hy he
    apply hproper
    · exact (CenteredProgression.mem_coefficientBox _ _ _).mpr (fun j => abs_le.mp (hx j))
    · exact (CenteredProgression.mem_coefficientBox _ _ _).mpr (fun j => abs_le.mp (hy j))
    · exact he
  · have ht' : t ∈ σ.range := hσrange.symm ▸ ht
    obtain ⟨t₀, ht₀⟩ := ht'
    refine ⟨t₀, ?_⟩
    have hf : ∀ z : IntVec d, (∀ j, |(z j : ℝ)| ≤ c*h*n j) →
        σ t₀+σ z ∈ labelledSubsetSupport v reserve := by
      intro z hz
      rw [ht₀, hsupport]
      apply hfill z
      intro j
      have hcγ : c ≤ denseBoxDilation d (commonBoxBlockDensity d K C)*N := min_le_right _ _
      have hγ := denseBoxDilation_pos d _ hd (commonBoxBlockDensity_bounds d K hK C hC).1
      have hhBR : (h : ℝ) ≤ B := by exact_mod_cast hhB
      have hstep := mul_le_mul hcγ hhBR (Nat.cast_nonneg h) (by positivity)
      have hstep' := mul_le_mul_of_nonneg_right hstep (Nat.cast_nonneg (n j))
      push_cast
      exact (hz j).trans (by simpa only [mul_assoc] using hstep')
    exact labelled_filling_pullback σ hσ u v reserve (fun i hi => hu i (hR hi)) t₀
      {z | ∀ j, |(z j : ℝ)| ≤ c*h*n j} hf

end
end Optss
