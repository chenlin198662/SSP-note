import Optss.BitListRationalInput
import Optss.PolynomialReductionFuel

/-!
# Fuel initialized from the actual encoded matrix size

Only input list lengths and dimensions enter the initializer. One sign slot is
counted per matrix entry. The generated Boolean fuel list has an explicit
polynomial length, and its associated reduction run has the full specification.
The proof uses an exponential height only mathematically, never in execution.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

def bitIntegerMatrixSize (A : BitIntegerMatrixData r d) : ℕ :=
  r*d+∑ i : Fin r, ∑ j : Fin d, ((A.get i).get j).digits.length

theorem bitIntegerMatrixSize_cell (A : BitIntegerMatrixData r d) (i : Fin r) (j : Fin d) :
    ((A.get i).get j).digits.length ≤ bitIntegerMatrixSize A := by
  have hr : ((A.get i).get j).digits.length ≤ ∑ k : Fin d, ((A.get i).get k).digits.length :=
    Finset.single_le_sum (f := fun k : Fin d => ((A.get i).get k).digits.length)
      (fun _ _ => Nat.zero_le _) (Finset.mem_univ j)
  have ht : (∑ k : Fin d, ((A.get i).get k).digits.length) ≤
      ∑ k : Fin r, ∑ l : Fin d, ((A.get k).get l).digits.length :=
    Finset.single_le_sum (f := fun k : Fin r => ∑ l : Fin d, ((A.get k).get l).digits.length)
      (fun _ _ => Nat.zero_le _) (Finset.mem_univ i)
  unfold bitIntegerMatrixSize
  omega

theorem bitIntegerMatrix_value_bits (A : BitIntegerMatrixData r d) (i : Fin r) (j : Fin d) :
    (bitIntegerMatrixValue A i j).natAbs.size ≤ bitIntegerMatrixSize A := by
  rw [bitIntegerMatrixValue, BitListInteger.value, signedBitsValue_natAbs]
  exact (Nat.size_le.mpr (binaryDigitsValue_lt_pow _)).trans (bitIntegerMatrixSize_cell A i j)

/-- Concrete fuel: dimensions, input-size scan, and a polynomial-size list. -/
def bitMatrixReductionFuel (A : BitIntegerMatrixData r d) : List Bool :=
  bitLengthReductionFuelList r d (bitIntegerMatrixSize A)

theorem bitMatrixReductionFuel_length (A : BitIntegerMatrixData r d) :
    (bitMatrixReductionFuel A).length =
      3*(r*(r+1)+1)*(r.size+d.size+2*(bitIntegerMatrixSize A+1)+4) := by
  simp only [bitMatrixReductionFuel, bitLengthReductionFuelList_length, bitLengthReductionFuel]

theorem executableReductionFuel_bitMatrixFuel_eq (A : BitIntegerMatrixData r d)
    (hA : LinearIndependent ℝ (fun i j => (bitIntegerMatrixValue A i j:ℝ))) :
    executableReductionFuel (bitMatrixReductionFuel A).length (bitIntegerMatrixValue A) =
      executableReductionFuel (gramPotential (bitIntegerMatrixValue A)) (bitIntegerMatrixValue A) := by
  rw [bitMatrixReductionFuel, bitLengthReductionFuelList_length]
  exact executableReductionFuel_bit_length_eq _ hA _ (bitIntegerMatrix_value_bits A)

/-- The computed fuel initializer, with no separate caller-supplied height or
bit-bound premise, suffices for the full integer reduction guarantee. -/
theorem executableReductionFuel_bitMatrixFuel_spec (A : BitIntegerMatrixData r d)
    (hA : LinearIndependent ℝ (fun i j => (bitIntegerMatrixValue A i j:ℝ))) :
    IntegerReductionSpecification (bitIntegerMatrixValue A)
      (executableReductionFuel (bitMatrixReductionFuel A).length (bitIntegerMatrixValue A)).1
      (executableReductionFuel (bitMatrixReductionFuel A).length (bitIntegerMatrixValue A)).2 := by
  rw [executableReductionFuel_bitMatrixFuel_eq A hA]
  exact executableReductionFuel_spec _ _ hA le_rfl

/-- Clearing rational entries of width at most `L` yields an encoded input
of polynomial total size, including its sign slots. -/
theorem bitListClearRationalInput_size (A : BitRationalMatrixData r d) (L : ℕ)
    (h : ∀ i j, ((A.get i).get j).numerator.length ≤ L ∧
      ((A.get i).get j).denominator.length ≤ L) :
    bitIntegerMatrixSize (bitListClearRationalInput A).2 ≤ r*d*((r*d+1)*L+2) := by
  unfold bitIntegerMatrixSize
  calc
    _ ≤ r*d+∑ _i : Fin r, ∑ _j : Fin d, ((r*d+1)*L+1) := by
      apply Nat.add_le_add_left
      apply Finset.sum_le_sum
      intro i _
      apply Finset.sum_le_sum
      intro j _
      exact bitListClearRationalInput_lengths A L h i j
    _ = _ := by simp; ring

end Optss
