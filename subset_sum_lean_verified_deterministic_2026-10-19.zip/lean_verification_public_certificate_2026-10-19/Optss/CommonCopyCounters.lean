import Optss.CommonGapMultiplicity

/-!
# Exact counters for common reserve partitions

These identities aggregate actual selected copies. They do not expand a
compressed input as a claimed computational operation; they prove the exact
counter semantics used by the structural output theorem.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1000000
variable {ι : Type} [Fintype ι] [DecidableEq ι]

theorem copyDebit_mono (c : ι → ℕ) {S T : Finset (CopyIndex c)} (hST : S ⊆ T) (i : ι) :
    copyDebit c S i ≤ copyDebit c T i := by
  apply Finset.card_le_card
  intro j hj
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hST (Finset.mem_filter.mp hj).2⟩

@[simp] theorem copyDebit_univ (c : ι → ℕ) (i : ι) : copyDebit c Finset.univ i = c i := by
  simp [copyDebit]

theorem copyDebit_pos_iff (c : ι → ℕ) (S : Finset (CopyIndex c)) (i : ι) :
    0 < copyDebit c S i ↔ ∃ j : Fin (c i), Sigma.mk i j ∈ S := by
  simp only [copyDebit, Finset.card_pos, Finset.Nonempty, Finset.mem_filter, Finset.mem_univ, true_and]

/-- A genuine subset deletion subtracts exactly its per-type count. -/
theorem copyDebit_sdiff (c : ι → ℕ) {S T : Finset (CopyIndex c)} (hTS : T ⊆ S) (i : ι) :
    copyDebit c (S \ T) i = copyDebit c S i-copyDebit c T i := by
  unfold copyDebit
  have he : (Finset.univ.filter (fun j : Fin (c i) => Sigma.mk i j ∈ S \ T)) =
      (Finset.univ.filter (fun j : Fin (c i) => Sigma.mk i j ∈ S)) \
      (Finset.univ.filter (fun j : Fin (c i) => Sigma.mk i j ∈ T)) := by
    ext j
    simp
  rw [he, Finset.card_sdiff]
  intro j hj
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hTS (Finset.mem_filter.mp hj).2⟩

/-- The original per-type capacities partition into exceptions, reserve, and
actual remainder with no overdraft. -/
theorem copy_partition_counters (c : ι → ℕ) (available reserve : Finset (CopyIndex c))
    (hR : reserve ⊆ available) :
    let e := copyDebit c (Finset.univ \ available)
    let r := copyDebit c reserve
    (∀ i, e i ≤ c i ∧ r i ≤ c i-e i) ∧
      (∀ i, copyDebit c (available \ reserve) i = c i-e i-r i) ∧
      (∑ i, e i) = (Finset.univ \ available).card ∧ (∑ i, r i) = reserve.card := by
  dsimp only
  have ha : ∀ i, copyDebit c available i = c i-copyDebit c (Finset.univ \ available) i := by
    intro i
    rw [copyDebit_sdiff c (Finset.subset_univ _) i, copyDebit_univ]
    have hb := copyDebit_le_available c available i
    omega
  refine ⟨?_, ?_, copyDebit_sum c _, copyDebit_sum c _⟩
  · intro i
    exact ⟨copyDebit_le_available c _ i, (copyDebit_mono c hR i).trans_eq (ha i)⟩
  · intro i
    rw [copyDebit_sdiff c hR i, ha i]

/-- Summing actual selected copies, when their coordinates agree by type,
returns bounded reserve counts and the same integer coordinate sum. -/
theorem selected_copies_weighted_sum {d : ℕ} (c : ι → ℕ)
    (coordinates : CopyIndex c → IntVec d) (u : ι → IntVec d)
    (reserve selected : Finset (CopyIndex c)) (hselected : selected ⊆ reserve)
    (hu : ∀ q ∈ reserve, coordinates q = u q.1) :
    BoundedCounts (fun i => (copyDebit c reserve i : ℤ)) (copyCount c selected) ∧
      weightedSum u (copyCount c selected) = ∑ q ∈ selected, coordinates q := by
  refine ⟨?_, ?_⟩
  · intro i
    rw [copyDebit_intCast]
    exact ⟨by positivity, Nat.cast_le.mpr (copyDebit_mono c hselected i)⟩
  · rw [← sum_expandedCopy]
    exact Finset.sum_congr rfl (fun q hq => (hu q (hselected hq)).symm)

/-- The span-generating type support is exactly the image of the actual
selected copies, so full integer generation transfers without a rank loss. -/
theorem generatedLattice_copy_types {d : ℕ} (c : ι → ℕ)
    (coordinates : CopyIndex c → IntVec d) (u : ι → IntVec d)
    (S : Finset (CopyIndex c)) (hu : ∀ q ∈ S, coordinates q = u q.1) :
    generatedLattice coordinates S = generatedLattice u (Finset.univ.filter (fun i => 0 < copyDebit c S i)) := by
  unfold generatedLattice
  congr 1
  ext x
  simp only [Set.mem_image, Finset.mem_coe, Finset.mem_filter, Finset.mem_univ, true_and]
  constructor
  · rintro ⟨⟨i, j⟩, hq, rfl⟩
    exact ⟨i, (copyDebit_pos_iff c S i).mpr ⟨j, hq⟩, (hu _ hq).symm⟩
  · rintro ⟨i, hi, rfl⟩
    obtain ⟨j, hj⟩ := (copyDebit_pos_iff c S i).mp hi
    exact ⟨⟨i, j⟩, hj, hu _ hj⟩

end
end Optss
