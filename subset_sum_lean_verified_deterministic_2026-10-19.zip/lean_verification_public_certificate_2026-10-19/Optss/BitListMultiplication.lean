import Optss.BitListArithmetic
import Optss.BinaryMultiplication

/-!
# Multiplication through Boolean ripple addition

The answer computation uses explicit little-endian lists, a one-cell shift,
the verified ripple adder, and canonical trimming. Its recursive result is
computed once and shared. Separate recurrences count the actual full-adder
circuit nodes and list-cell visits of this computation; computing those
mathematical counters is not itself charged as part of the answer algorithm.
-/

namespace Optss

/-- Shift/add multiplication on explicit bit lists. Neither decoding to `Nat`
nor a large-integer arithmetic primitive computes the answer. -/
def bitListMultiplication (xs : List Bool) : List Bool → List Bool
  | [] => []
  | b::bs =>
    let prev := bitListMultiplication xs bs
    let shifted := bitListShift false prev
    let added := if b then bitListAddAux false xs shifted else shifted
    bitListTrim added

theorem bitListMultiplication_correct (xs ys : List Bool) :
    binaryDigitsValue (bitListMultiplication xs ys) = binaryDigitsValue xs*binaryDigitsValue ys := by
  induction ys with
  | nil => simp [bitListMultiplication, binaryDigitsValue]
  | cons b bs ih =>
    rw [bitListMultiplication, bitListTrim_value]
    cases b <;> simp only [Bool.false_eq_true, ↓reduceIte,
      bitListAddAux_correct, bitListShift_value, Bool.toNat_false, add_zero, ih,
      binaryDigitsValue, Bool.toNat_true] <;> ring

/-- Every partial product is in canonical form, including zero products. -/
theorem bitListMultiplication_eq_bits (xs ys : List Bool) :
    bitListMultiplication xs ys = (binaryDigitsValue xs*binaryDigitsValue ys).bits := by
  cases ys with
  | nil => simp [bitListMultiplication, binaryDigitsValue]
  | cons b bs =>
    rw [bitListMultiplication, bitListTrim_eq_bits]
    congr 1
    simpa only [bitListMultiplication, bitListTrim_value] using
      bitListMultiplication_correct xs (b::bs)

theorem bitListMultiplication_length (xs ys : List Bool) :
    (bitListMultiplication xs ys).length = (binaryDigitsValue xs*binaryDigitsValue ys).size := by
  rw [bitListMultiplication_eq_bits, Nat.size_eq_bits_len]

/-- Every partial product fits in the sum of the two input widths, even when
the supplied input lists contain redundant high zeros. -/
theorem bitListMultiplication_length_le (xs ys : List Bool) :
    (bitListMultiplication xs ys).length ≤ xs.length+ys.length := by
  rw [bitListMultiplication_length]
  exact (nat_mul_size_le _ _).trans (Nat.add_le_add
    (Nat.size_le.mpr (binaryDigitsValue_lt_pow xs))
    (Nat.size_le.mpr (binaryDigitsValue_lt_pow ys)))

/-- The stored answer is exactly that of the earlier arithmetic implementation. -/
theorem bitListMultiplication_binaryMultiplication (xs ys : List Bool) :
    binaryDigitsValue (bitListMultiplication xs ys) =
      (binaryMultiplication (binaryDigitsValue xs) (binaryDigitsValue ys)).value := by
  rw [bitListMultiplication_correct, binaryMultiplication_correct]

/-- Gate-node semantics for the conditional ripple additions. The loop and
trimming use structural/Boolean case analysis, counted separately as visits. -/
def bitListMultiplicationGates (xs : List Bool) : List Bool → ℕ
  | [] => 0
  | b::bs =>
    let prev := bitListMultiplication xs bs
    bitListMultiplicationGates xs bs +
      if b then bitListRippleGates (fullAddCircuits.1.gates+fullAddCircuits.2.gates)
        xs (bitListShift false prev) else 0

/-- List-cell traversal semantics. Each loop step reads the multiplier cell
and constructs the shifted low cell, then performs its actual optional adder
and trimming traversals. The terminal empty multiplier is visited once. -/
def bitListMultiplicationVisits (xs : List Bool) : List Bool → ℕ
  | [] => 1
  | b::bs =>
    let prev := bitListMultiplication xs bs
    let shifted := bitListShift false prev
    let added := if b then bitListAddAux false xs shifted else shifted
    bitListMultiplicationVisits xs bs + 2 +
      (if b then bitListAddVisits xs shifted else 0) + bitListTrimVisits added

/-- There is one full-adder circuit per aligned bit, only on multiplier-one
steps. Canonical intermediate products keep the total count quadratic. -/
theorem bitListMultiplicationGates_le (xs ys : List Bool) :
    bitListMultiplicationGates xs ys ≤ 6*ys.length*(xs.length+ys.length+1) := by
  induction ys with
  | nil => simp [bitListMultiplicationGates]
  | cons b bs ih =>
    have hl := bitListMultiplication_length_le xs bs
    have hm : max xs.length ((bitListShift false (bitListMultiplication xs bs)).length) ≤
        xs.length+bs.length+1 := by
      simp only [bitListShift, List.length_cons]
      omega
    cases b <;> simp only [bitListMultiplicationGates, Bool.false_eq_true,
      ↓reduceIte, fullAddCircuits_gates, bitListRippleGates_eq,
      List.length_cons, add_zero] <;> nlinarith

/-- The actual ripple and trimming traversals are bounded by a quadratic in
input bit lengths. No magnitude-sized search appears in the computation. -/
theorem bitListMultiplicationVisits_le (xs ys : List Bool) :
    bitListMultiplicationVisits xs ys ≤ 1+4*ys.length*(xs.length+ys.length+3) := by
  induction ys with
  | nil => simp [bitListMultiplicationVisits]
  | cons b bs ih =>
    have hl := bitListMultiplication_length_le xs bs
    have hm : max xs.length ((bitListShift false (bitListMultiplication xs bs)).length) ≤
        xs.length+bs.length+1 := by
      simp only [bitListShift, List.length_cons]
      omega
    have ha := bitListAddAux_length xs (bitListShift false (bitListMultiplication xs bs)) false
    cases b <;> simp only [bitListMultiplicationVisits, Bool.false_eq_true,
      ↓reduceIte, bitListAddVisits_eq, bitListTrimVisits_eq,
      List.length_cons, add_zero] <;>
      simp only [bitListShift, List.length_cons] at * <;> nlinarith

/-- A conservative combined count of Boolean circuit nodes and list-cell
visits for the explicit multiplication algorithm. -/
theorem bitListMultiplication_total_le (xs ys : List Bool) :
    bitListMultiplicationGates xs ys+bitListMultiplicationVisits xs ys ≤
      1+10*ys.length*(xs.length+ys.length+3) := by
  have hg := bitListMultiplicationGates_le xs ys
  have hv := bitListMultiplicationVisits_le xs ys
  nlinarith

/-- Canonical input encoding yields a quadratic bound in actual magnitude
bits. Input encoding/decoding costs are separate from this list algorithm. -/
theorem bitListMultiplication_bits (m n : ℕ) :
    bitListMultiplication m.bits n.bits = (m*n).bits ∧
      bitListMultiplicationGates m.bits n.bits+bitListMultiplicationVisits m.bits n.bits ≤
        1+10*n.size*(m.size+n.size+3) := by
  constructor
  · simpa only [binaryDigitsValue_bits] using bitListMultiplication_eq_bits m.bits n.bits
  · simpa only [Nat.size_eq_bits_len] using bitListMultiplication_total_le m.bits n.bits

/-- The old multiplication width charge dominates the concrete Boolean-gate
and list-traversal semantics up to a fixed factor of two. This is a refinement
of the charge, not a claim about the time needed to compute the counters. -/
theorem bitListMultiplication_refines_widthWork (m : ℕ) (ys : List Bool) :
    bitListMultiplicationGates m.bits ys+bitListMultiplicationVisits m.bits ys ≤
      2*(binaryMultiplicationDigits m ys).widthWork+1 := by
  induction ys with
  | nil => simp [bitListMultiplicationGates, bitListMultiplicationVisits, binaryMultiplicationDigits]
  | cons b bs ih =>
    have hl : (bitListMultiplication m.bits bs).length =
        (binaryMultiplicationDigits m bs).value.size := by
      rw [bitListMultiplication_length, binaryDigitsValue_bits, binaryMultiplicationDigits_correct]
    have hm : max m.bits.length ((bitListShift false (bitListMultiplication m.bits bs)).length) ≤
        m.size+(binaryMultiplicationDigits m bs).value.size+1 := by
      simp only [bitListShift, List.length_cons, hl, ← Nat.size_eq_bits_len]
      omega
    have ha := bitListAddAux_length m.bits
      (bitListShift false (bitListMultiplication m.bits bs)) false
    cases b <;> simp only [bitListMultiplicationGates, bitListMultiplicationVisits,
      binaryMultiplicationDigits, Bool.false_eq_true, ↓reduceIte,
      fullAddCircuits_gates, bitListRippleGates_eq, bitListAddVisits_eq,
      bitListTrimVisits_eq, add_zero] <;>
      simp only [bitListShift, List.length_cons, hl, ← Nat.size_eq_bits_len] at * <;> omega

/-- Refinement of the public arithmetic multiplication implementation. -/
theorem bitListMultiplication_refines_binaryMultiplication (m n : ℕ) :
    binaryDigitsValue (bitListMultiplication m.bits n.bits) = (binaryMultiplication m n).value ∧
      bitListMultiplicationGates m.bits n.bits+bitListMultiplicationVisits m.bits n.bits ≤
        2*(binaryMultiplication m n).widthWork+1 := by
  constructor
  · simp only [bitListMultiplication_correct, binaryDigitsValue_bits, binaryMultiplication_correct]
  · exact bitListMultiplication_refines_widthWork m n.bits

/-- A convenient uniform quadratic bound when both operands have at most
`L` explicit bits; no canonical-input assumption is needed. -/
theorem bitListMultiplication_uniform_cost (xs ys : List Bool) (L : ℕ)
    (hx : xs.length ≤ L) (hy : ys.length ≤ L) :
    bitListMultiplicationGates xs ys+bitListMultiplicationVisits xs ys ≤ 40*(L+1)^2 := by
  have ht := bitListMultiplication_total_le xs ys
  have hm : 10*ys.length*(xs.length+ys.length+3) ≤ 10*L*(2*L+3) :=
    Nat.mul_le_mul (Nat.mul_le_mul_left 10 hy) (by omega)
  nlinarith

end Optss
