import Optss.IntegerSizeReduction
import Optss.GramSchmidtDeterminant

/-!
# Dimension-only norm bounds for reduced lattice bases

The analytical part is kept separate from the integer reduction construction:
size bounds for actual Gram-Schmidt coefficients and adjacent squared-length
bounds imply an explicit dimension-only comparison of each basis vector with
its orthogonalized vector. No runtime bound is asserted.
-/

namespace Optss
noncomputable section
open scoped BigOperators

/-- A local factor-two growth restriction propagates along all earlier indices.
A coarse exponent equal to the later index suffices for dimension-only bounds. -/
theorem le_pow_two_mul_of_adjacent {r : ℕ} (f : Fin r → ℝ)
    (hf : ∀ i, 0 ≤ f i)
    (hstep : ∀ j k : Fin r, k.val = j.val+1 → f j ≤ 2*f k)
    (j k : Fin r) (hjk : j ≤ k) : f j ≤ (2:ℝ)^k.val * f k := by
  suffices H : ∀ n, ∀ k : Fin r, k.val = n → ∀ j : Fin r, j ≤ k →
      f j ≤ (2:ℝ)^k.val * f k from H k.val k rfl j hjk
  intro n
  induction n with
  | zero =>
    intro k hk j hjk
    have he : j = k := Fin.ext (by change j.val ≤ k.val at hjk; omega)
    simp [he, hk]
  | succ n ih =>
    intro k hk j hjk
    by_cases he : j = k
    · rw [he]
      have hp : (1:ℝ) ≤ 2^k.val := one_le_pow₀ (by norm_num)
      nlinarith [mul_le_mul_of_nonneg_right hp (hf k)]
    · let p : Fin r := ⟨n, by omega⟩
      have hjp : j ≤ p := by
        change j.val ≤ n
        have hjkne : j.val ≠ k.val := fun h => he (Fin.ext h)
        change j.val ≤ k.val at hjk
        omega
      have hprev := ih p rfl j hjp
      have hs := hstep p k (by exact hk)
      calc
        f j ≤ 2^p.val * f p := hprev
        _ ≤ 2^p.val * (2*f k) := mul_le_mul_of_nonneg_left hs (by positivity)
        _ = 2^k.val * f k := by rw [hk, pow_succ]; dsimp [p]; ring

section GramSchmidtBounds
variable {r : ℕ} {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- Squared adjacent Gram-Schmidt bounds give the weaker linear factor two,
which avoids square roots in the final dimension-only constant. -/
theorem gs_norm_adjacent_of_sq (v : Fin r → E)
    (hstep : ∀ j k : Fin r, k.val = j.val+1 →
      ‖gramSchmidt ℝ v j‖^2 ≤ 2*‖gramSchmidt ℝ v k‖^2)
    (j k : Fin r) (hjk : k.val = j.val+1) :
    ‖gramSchmidt ℝ v j‖ ≤ 2*‖gramSchmidt ℝ v k‖ := by
  have h := hstep j k hjk
  nlinarith [norm_nonneg (gramSchmidt ℝ v j), norm_nonneg (gramSchmidt ℝ v k),
    sq_nonneg (‖gramSchmidt ℝ v k‖)]

/-- Every earlier orthogonalized vector has length controlled by the current
one, with a constant depending only on the number of vectors. -/
theorem gs_norm_le_dimension_mul (v : Fin r → E)
    (hstep : ∀ j k : Fin r, k.val = j.val+1 →
      ‖gramSchmidt ℝ v j‖^2 ≤ 2*‖gramSchmidt ℝ v k‖^2)
    (j k : Fin r) (hjk : j ≤ k) :
    ‖gramSchmidt ℝ v j‖ ≤ (2:ℝ)^r * ‖gramSchmidt ℝ v k‖ := by
  have h := le_pow_two_mul_of_adjacent (fun i => ‖gramSchmidt ℝ v i‖)
    (fun i => norm_nonneg _) (gs_norm_adjacent_of_sq v hstep) j k hjk
  exact h.trans (mul_le_mul_of_nonneg_right
    (pow_le_pow_right₀ (by norm_num : (1:ℝ) ≤ 2) (Nat.le_of_lt k.isLt)) (norm_nonneg _))

/-- The actual norm of a size-reduced vector is bounded by the sum of the
norms of its earlier Gram-Schmidt vectors and its own. -/
theorem norm_le_gs_norm_sum (v : Fin r → E)
    (hsize : ∀ k j : Fin r, j < k → |gsCoefficient v k j| ≤ 1/2) (k : Fin r) :
    ‖v k‖ ≤ ‖gramSchmidt ℝ v k‖ + ∑ j ∈ Finset.Iio k, ‖gramSchmidt ℝ v j‖ := by
  have he : v k = gramSchmidt ℝ v k +
      ∑ j ∈ Finset.Iio k, gsCoefficient v k j • gramSchmidt ℝ v j := by
    simpa only [gsCoefficient, RCLike.ofReal_real_eq_id, id_eq] using gramSchmidt_def'' ℝ v k
  rw [he]
  apply (norm_add_le _ _).trans
  apply add_le_add_left
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro j hj
  rw [norm_smul, Real.norm_eq_abs]
  have h := hsize k j (Finset.mem_Iio.mp hj)
  have h1 : |gsCoefficient v k j| ≤ 1 := by linarith
  simpa only [one_mul] using mul_le_mul_of_nonneg_right h1 (norm_nonneg _)

/-- A coarse explicit dimension-only factor for every vector of a reduced
family. Both premises refer to actual Gram-Schmidt data of that same family. -/
theorem norm_le_dimension_mul_gs (v : Fin r → E)
    (hsize : ∀ k j : Fin r, j < k → |gsCoefficient v k j| ≤ 1/2)
    (hstep : ∀ j k : Fin r, k.val = j.val+1 →
      ‖gramSchmidt ℝ v j‖^2 ≤ 2*‖gramSchmidt ℝ v k‖^2) (k : Fin r) :
    ‖v k‖ ≤ ((r:ℝ)*(2:ℝ)^r) * ‖gramSchmidt ℝ v k‖ := by
  let C := (2:ℝ)^r * ‖gramSchmidt ℝ v k‖
  have hC : 0 ≤ C := by dsimp [C]; positivity
  have hself : ‖gramSchmidt ℝ v k‖ ≤ C := gs_norm_le_dimension_mul v hstep k k le_rfl
  have hsum : (∑ j ∈ Finset.Iio k, ‖gramSchmidt ℝ v j‖) ≤ (k.val:ℝ)*C := by
    calc
      _ ≤ ∑ _j ∈ Finset.Iio k, C := Finset.sum_le_sum (fun j hj =>
        gs_norm_le_dimension_mul v hstep j k (Finset.mem_Iio.mp hj).le)
      _ = _ := by simp
  have hk : (k.val:ℝ)+1 ≤ r := by exact_mod_cast k.isLt
  calc
    ‖v k‖ ≤ ‖gramSchmidt ℝ v k‖ + ∑ j ∈ Finset.Iio k, ‖gramSchmidt ℝ v j‖ :=
      norm_le_gs_norm_sum v hsize k
    _ ≤ C + (k.val:ℝ)*C := add_le_add hself hsum
    _ = ((k.val:ℝ)+1)*C := by ring
    _ ≤ (r:ℝ)*C := mul_le_mul_of_nonneg_right hk hC
    _ = _ := by dsimp [C]; ring

/-- Product form of the bound, ready to divide by covolume after the exact
Gram-determinant identity is supplied. The estimate is valid also at rank zero. -/
theorem prod_norm_le_dimension_mul_prod_gs (v : Fin r → E)
    (hsize : ∀ k j : Fin r, j < k → |gsCoefficient v k j| ≤ 1/2)
    (hstep : ∀ j k : Fin r, k.val = j.val+1 →
      ‖gramSchmidt ℝ v j‖^2 ≤ 2*‖gramSchmidt ℝ v k‖^2) :
    (∏ k, ‖v k‖) ≤ ((r:ℝ)*(2:ℝ)^r)^r * ∏ k, ‖gramSchmidt ℝ v k‖ := by
  calc
    _ ≤ ∏ k, (((r:ℝ)*(2:ℝ)^r) * ‖gramSchmidt ℝ v k‖) :=
      Finset.prod_le_prod (fun k _ => norm_nonneg _) (fun k _ => norm_le_dimension_mul_gs v hsize hstep k)
    _ = _ := by rw [Finset.prod_mul_distrib]; simp

end GramSchmidtBounds

section Covolume
variable {r : ℕ}

/-- The Euclidean covolume of an actual basis is the product of its
Gram-Schmidt lengths. This follows from the triangular orthonormal-basis
matrix supplied by mathlib, without a new determinant axiom. -/
theorem abs_euclideanBasisMatrix_det_eq_prod_gs
    (b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r))) :
    |(euclideanBasisMatrix b).det| = ∏ i, ‖gramSchmidt ℝ b i‖ := by
  let hdim := Module.finrank_eq_card_basis b
  let e := gramSchmidtOrthonormalBasis hdim (b : Fin r → EuclideanSpace ℝ (Fin r))
  let e₀ := EuclideanSpace.basisFun (Fin r) ℝ
  have hi (i : Fin r) : @inner ℝ _ _ (e i) (b i) = ‖gramSchmidt ℝ b i‖ := by
    have hn : ‖gramSchmidt ℝ b i‖ ≠ 0 := norm_ne_zero_iff.mpr (gramSchmidt_ne_zero i b.linearIndependent)
    have hnormed : gramSchmidtNormed ℝ b i ≠ 0 := by
      intro hz
      have hu := gramSchmidtNormed_unit_length i b.linearIndependent
      rw [hz, norm_zero] at hu
      norm_num at hu
    have he : e i = (‖gramSchmidt ℝ b i‖⁻¹:ℝ) • gramSchmidt ℝ b i := by
      exact gramSchmidtOrthonormalBasis_apply hdim hnormed
    rw [he, real_inner_smul_left, inner_gramSchmidt_original]
    field_simp
    ring
  have hedet : e.toBasis.det b = ∏ i, ‖gramSchmidt ℝ b i‖ := by
    rw [gramSchmidtOrthonormalBasis_det]
    exact Finset.prod_congr rfl (fun i _ => hi i)
  have hmul : e₀.toBasis.det b = e₀.toBasis.det e.toBasis * e.toBasis.det b := by
    simp only [Basis.det_apply, ← Matrix.det_mul, Basis.toMatrix_mul_toMatrix]
  have hone : |e₀.toBasis.det e.toBasis| = 1 := by
    simpa only [Real.norm_eq_abs, OrthonormalBasis.coe_toBasis] using
      e₀.det_to_matrix_orthonormalBasis e
  have hmat : (euclideanBasisMatrix b).det = e₀.toBasis.det b := by
    change (euclideanBasisMatrix b).det = (e₀.toBasis.toMatrix b).det
    congr 1
  rw [hmat, hmul, abs_mul, hone, one_mul, hedet,
    abs_of_nonneg (Finset.prod_nonneg (fun i _ => norm_nonneg _))]

/-- The explicit defect constant used here is deliberately coarse; it depends
only on dimension and equals one in dimension zero. -/
def latticeReductionDefectBound (r : ℕ) : ℝ := ((r:ℝ)*(2:ℝ)^r)^r

theorem latticeReductionDefectBound_pos (r : ℕ) : 0 < latticeReductionDefectBound r := by
  cases r with
  | zero => norm_num [latticeReductionDefectBound]
  | succ r => unfold latticeReductionDefectBound; positivity

/-- Size reduction and the standard adjacent squared-length consequence imply
an actual dimension-only orthogonality-defect bound. -/
theorem orthogonalityDefect_le_of_reduced
    (b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)))
    (hsize : ∀ k j : Fin r, j < k → |gsCoefficient b k j| ≤ 1/2)
    (hstep : ∀ j k : Fin r, k.val = j.val+1 →
      ‖gramSchmidt ℝ b j‖^2 ≤ 2*‖gramSchmidt ℝ b k‖^2) :
    euclideanOrthogonalityDefect b ≤ latticeReductionDefectBound r := by
  have hdet : 0 < |(euclideanBasisMatrix b).det| :=
    abs_pos.mpr (euclideanBasisMatrix_det_ne_zero b)
  apply (div_le_iff₀ hdet).mpr
  rw [abs_euclideanBasisMatrix_det_eq_prod_gs]
  exact prod_norm_le_dimension_mul_prod_gs b hsize hstep

/-- The scalar implication used after cancellation of the preceding prefix
Gram determinant. It gives the convenient factor two from `|μ|≤1/2`. -/
theorem adjacent_sq_le_twice_of_size (a b μ : ℝ) (ha : 0 ≤ a)
    (hμ : |μ| ≤ 1/2) (h : a ≤ b + μ^2*a) : a ≤ 2*b := by
  have hμsq : μ^2 ≤ (1/4:ℝ) := by nlinarith [sq_abs μ, abs_nonneg μ]
  have hmul := mul_le_mul_of_nonneg_right hμsq ha
  nlinarith

/-- The actual determinant condition from the integer construction implies
the adjacent Gram-Schmidt squared-length bound. Positivity of the preceding
prefix Gram determinant justifies the cancellation, including at the first row. -/
theorem gs_sq_step_of_determinant_reduced {d : ℕ}
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ)))
    (hsize : ∀ k j : Fin r, j < k → |gsCoefficient (euclideanIntegerRows A) k j| ≤ 1/2)
    (hdet : ∀ j k : Fin r, k.val = j.val+1 →
      prefixGramDet A ⟨k.val, by omega⟩ ≤ prefixGramDet (swapRows A j k) ⟨k.val, by omega⟩)
    (j k : Fin r) (hjk : k.val = j.val+1) :
    ‖gramSchmidt ℝ (euclideanIntegerRows A) j‖^2 ≤
      2*‖gramSchmidt ℝ (euclideanIntegerRows A) k‖^2 := by
  have hpos : (0:ℝ) < (prefixGramDet A ⟨j.val, by omega⟩:ℝ) := by
    exact_mod_cast prefixGramDet_pos A hA ⟨j.val, by omega⟩
  have hineq : (prefixGramDet A ⟨k.val, by omega⟩:ℝ) ≤
      (prefixGramDet (swapRows A j k) ⟨k.val, by omega⟩:ℝ) := by
    exact_mod_cast hdet j k hjk
  have hold := prefixGramDet_succ_eq A j
  have he : (⟨j.val+1, by omega⟩ : Fin (r+1)) = ⟨k.val, by omega⟩ := Fin.ext hjk.symm
  rw [he] at hold
  rw [hold, prefixGramDet_swap_adjacent_eq A j k hjk] at hineq
  exact adjacent_sq_le_twice_of_size _ _ _ (sq_nonneg _)
    (hsize k j (by change j.val < k.val; omega)) ((mul_le_mul_left hpos).mp hineq)

/-- A supplied actual real basis with the verified integer rows has bounded
orthogonality defect. No reduced-basis or dual-norm premise remains. -/
theorem integer_determinant_reduced_defect_le
    (A : Matrix (Fin r) (Fin r) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ)))
    (hsize : ∀ k j : Fin r, j < k → |gsCoefficient (euclideanIntegerRows A) k j| ≤ 1/2)
    (hdet : ∀ j k : Fin r, k.val = j.val+1 →
      prefixGramDet A ⟨k.val, by omega⟩ ≤ prefixGramDet (swapRows A j k) ⟨k.val, by omega⟩)
    (b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)))
    (hb : ∀ i, b i = euclideanIntegerRows A i) :
    euclideanOrthogonalityDefect b ≤ latticeReductionDefectBound r := by
  have he : (b : Fin r → EuclideanSpace ℝ (Fin r)) = euclideanIntegerRows A := funext hb
  apply orthogonalityDefect_le_of_reduced b
  · simpa only [he] using hsize
  · simpa only [he] using gs_sq_step_of_determinant_reduced A hA hsize hdet

/-- Existence of a dimension-bounded-defect integer basis of the entire input
lattice, derived from the exact integer potential and explicit size-reduction
sweep. This is a mathematical existence result; no bit-complexity bound is claimed. -/
theorem exists_integer_bounded_defect (A : Matrix (Fin r) (Fin r) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ))) :
    ∃ B : Matrix (Fin r) (Fin r) ℤ,
      Submodule.span ℤ (Set.range B) = Submodule.span ℤ (Set.range A) ∧
      LinearIndependent ℝ (fun i => fun j => (B i j:ℝ)) ∧
      ∀ b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)),
        (∀ i, b i = euclideanIntegerRows B i) →
        euclideanOrthogonalityDefect b ≤ latticeReductionDefectBound r := by
  obtain ⟨B, hspan, hB, hsize, hdet⟩ := exists_integer_determinant_reduced A hA
  exact ⟨B, hspan, hB, integer_determinant_reduced_defect_le B hB hsize hdet⟩

end Covolume

end
end Optss
