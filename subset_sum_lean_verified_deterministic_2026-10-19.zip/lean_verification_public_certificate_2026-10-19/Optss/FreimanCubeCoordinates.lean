import Optss.FreimanCubePartition
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas

/-!
# Coordinates and degeneracy of the actual Freiman cube

A full-dimensional cube is transported by its own basis to the unit cube.
A degenerate cube is contained in the kernel of an actual nonzero linear
form. These are the two geometric cases needed in the finite-depth proof
of Freiman's two-to-the-dimension theorem.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 800000
variable {E : Type*} [AddCommGroup E] [Module ℝ E]

/-- Segment choices are exactly bounded coordinate coefficients. -/
theorem mem_freimanCubeBody_ofFn {n : ℕ} (v : Fin n → E) (x : E) :
    x ∈ freimanCubeBody (List.ofFn v) ↔
      ∃ u : Fin n → ℝ, (∀ j, |u j| ≤ 1) ∧ x = ∑ j, u j • v j := by
  induction n generalizing x with
  | zero => simp [freimanCubeBody]
  | succ n ih =>
    rw [List.ofFn_succ]
    change (∃ t : ℝ, |t| ≤ 1 ∧ ∃ y ∈ freimanCubeBody (List.ofFn (fun i => v i.succ)),
      x = t • v 0 + y) ↔ _
    constructor
    · rintro ⟨t, ht, y, hy, rfl⟩
      obtain ⟨u, hu, rfl⟩ := (ih _ _).mp hy
      refine ⟨Fin.cons t u, ?_, ?_⟩
      · intro j
        refine Fin.cases ht (fun i => ?_) j
        exact hu i
      · simp [Fin.sum_univ_succ]
    · rintro ⟨u, hu, rfl⟩
      refine ⟨u 0, hu 0, ∑ j : Fin n, u j.succ • v j.succ,
        (ih _ _).mpr ⟨fun j => u j.succ, fun j => hu j.succ, rfl⟩, ?_⟩
      exact Fin.sum_univ_succ _

/-- The genuine finite vertex set consists of sign choices. -/
theorem mem_freimanCubeVertices_ofFn {n : ℕ} (v : Fin n → E) (x : E) :
    x ∈ freimanCubeVertices (List.ofFn v) ↔
      ∃ u : Fin n → ℝ, (∀ j, u j = -1 ∨ u j = 1) ∧ x = ∑ j, u j • v j := by
  induction n generalizing x with
  | zero => simp [freimanCubeVertices]
  | succ n ih =>
    rw [List.ofFn_succ, freimanCubeVertices]
    constructor
    · intro hx
      obtain ⟨a, ha, y, hy, rfl⟩ := Finset.mem_add.mp hx
      obtain ⟨u, hu, rfl⟩ := (ih _ _).mp hy
      have ha' : a = -v 0 ∨ a = v 0 := by simpa using ha
      rcases ha' with rfl | rfl
      · refine ⟨Fin.cons (-1) u, ?_, ?_⟩
        · intro j
          exact Fin.cases (Or.inl rfl) (fun i => hu i) j
        · simp [Fin.sum_univ_succ]
      · refine ⟨Fin.cons 1 u, ?_, ?_⟩
        · intro j
          exact Fin.cases (Or.inr rfl) (fun i => hu i) j
        · simp [Fin.sum_univ_succ]
    · rintro ⟨u, hu, rfl⟩
      rw [Fin.sum_univ_succ]
      refine Finset.mem_add.mpr ⟨u 0 • v 0, ?_, _,
        (ih _ _).mpr ⟨fun j => u j.succ, fun j => hu j.succ, rfl⟩, rfl⟩
      rcases hu 0 with h | h <;> simp [h]

theorem mem_freimanCubeBody_basis {n : ℕ} (b : Basis (Fin n) ℝ E) (x : E) :
    x ∈ freimanCubeBody (List.ofFn b) ↔ ∀ j, |b.equivFun x j| ≤ 1 := by
  rw [mem_freimanCubeBody_ofFn]
  constructor
  · rintro ⟨u, hu, hx⟩
    have hxu : x = b.equivFun.symm u := by simpa using hx
    simpa only [hxu, LinearEquiv.apply_symm_apply] using hu
  · intro hx
    exact ⟨b.equivFun x, hx, by simpa using (b.equivFun.symm_apply_apply x).symm⟩

theorem mem_freimanCubeVertices_basis {n : ℕ} (b : Basis (Fin n) ℝ E) (x : E) :
    x ∈ freimanCubeVertices (List.ofFn b) ↔ b.equivFun x ∈ unitCubeVertices n := by
  rw [mem_freimanCubeVertices_ofFn, mem_unitCubeVertices]
  constructor
  · rintro ⟨u, hu, hx⟩
    have hxu : x = b.equivFun.symm u := by simpa using hx
    simpa only [hxu, LinearEquiv.apply_symm_apply] using hu
  · intro hx
    exact ⟨b.equivFun x, hx, by simpa using (b.equivFun.symm_apply_apply x).symm⟩

/-- A cube whose directions fail to span the ambient space lies in an
actual nonzero linear kernel. -/
theorem freimanCubeBody_degenerate {n : ℕ} (v : Fin n → E)
    (hspan : Submodule.span ℝ (Set.range v) ≠ ⊤) :
    ∃ f : E →ₗ[ℝ] ℝ, f ≠ 0 ∧ ∀ x ∈ freimanCubeBody (List.ofFn v), f x = 0 := by
  let L := Submodule.span ℝ (Set.range v)
  obtain ⟨z, hz⟩ : ∃ z : E, z ∉ L := by
    by_contra h
    apply hspan
    apply top_unique
    intro z _
    exact not_not.mp (fun hz => h ⟨z, hz⟩)
  obtain ⟨f, hfz, hfL⟩ := L.exists_dual_map_eq_bot_of_nmem hz inferInstance
  refine ⟨f, fun hf => hfz (by simp [hf]), ?_⟩
  intro x hx
  obtain ⟨u, hu, rfl⟩ := (mem_freimanCubeBody_ofFn v x).mp hx
  rw [map_sum]
  apply Finset.sum_eq_zero
  intro j _
  rw [map_smul]
  have hvj : v j ∈ L := Submodule.subset_span (Set.mem_range_self j)
  have hj : f (v j) ∈ (⊥ : Submodule ℝ ℝ) := hfL ▸ Submodule.mem_map_of_mem hvj
  simp only [Submodule.mem_bot] at hj
  simp [hj]

/-- Uniform bound on actual intersections with affine hyperplanes. -/
def hyperplaneMassBound (S : Finset E) (H : ℕ) : Prop :=
  ∀ (f : E →ₗ[ℝ] ℝ), f ≠ 0 → ∀ t : ℝ, (S.filter (fun x => f x = t)).card ≤ H

def affineCoordinateSet {F : Type*} [AddCommGroup F] [Module ℝ F]
    (e : E ≃ₗ[ℝ] F) (a : E) (S : Finset E) : Finset F :=
  S.image (fun x => e (x-a))

theorem affineCoordinateSet_injective {F : Type*} [AddCommGroup F] [Module ℝ F]
    (e : E ≃ₗ[ℝ] F) (a : E) : Function.Injective (fun x => e (x-a)) :=
  e.injective.comp sub_left_injective

theorem affineCoordinateSet_card {F : Type*} [AddCommGroup F] [Module ℝ F]
    (e : E ≃ₗ[ℝ] F) (a : E) (S : Finset E) :
    (affineCoordinateSet e a S).card = S.card :=
  Finset.card_image_of_injective _ (affineCoordinateSet_injective e a)

theorem affineCoordinateSet_double {F : Type*} [AddCommGroup F] [Module ℝ F]
    (e : E ≃ₗ[ℝ] F) (a : E) (S : Finset E) :
    affineCoordinateSet e a S + affineCoordinateSet e a S = affineCoordinateSet e (a+a) (S+S) := by
  ext z
  constructor
  · intro hz
    obtain ⟨x, hx, y, hy, rfl⟩ := Finset.mem_add.mp hz
    obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp hx
    obtain ⟨v, hv, rfl⟩ := Finset.mem_image.mp hy
    refine Finset.mem_image.mpr ⟨u+v, Finset.add_mem_add hu hv, ?_⟩
    rw [← map_add]
    congr 1
    abel
  · intro hz
    change z ∈ (S+S).image (fun x => e (x-(a+a))) at hz
    obtain ⟨w, hw, rfl⟩ := Finset.mem_image.mp hz
    obtain ⟨u, hu, v, hv, rfl⟩ := Finset.mem_add.mp hw
    refine Finset.mem_add.mpr ⟨e (u-a), Finset.mem_image.mpr ⟨u, hu, rfl⟩,
      e (v-a), Finset.mem_image.mpr ⟨v, hv, rfl⟩, ?_⟩
    rw [← map_add]
    congr 1
    abel

theorem affineCoordinateSet_double_card {F : Type*} [AddCommGroup F] [Module ℝ F]
    (e : E ≃ₗ[ℝ] F) (a : E) (S : Finset E) :
    (affineCoordinateSet e a S + affineCoordinateSet e a S).card = (S+S).card := by
  rw [affineCoordinateSet_double, affineCoordinateSet_card]

theorem hyperplaneMassBound_affineCoordinateSet {F : Type*} [AddCommGroup F] [Module ℝ F]
    (e : E ≃ₗ[ℝ] F) (a : E) (S : Finset E) (H : ℕ) (hH : hyperplaneMassBound S H) :
    hyperplaneMassBound (affineCoordinateSet e a S) H := by
  intro f hf t
  let g : E →ₗ[ℝ] ℝ := f.comp e.toLinearMap
  have hg : g ≠ 0 := by
    intro hg
    apply hf
    ext y
    obtain ⟨x, rfl⟩ := e.surjective y
    exact LinearMap.congr_fun hg x
  have heq : (affineCoordinateSet e a S).filter (fun x => f x = t) =
      ((S.filter (fun x => g x = t+g a)).image (fun x => e (x-a))) := by
    rw [affineCoordinateSet, Finset.filter_image]
    congr 1
    ext x
    simp only [Finset.mem_filter, map_sub, g, LinearMap.comp_apply, LinearEquiv.coe_coe]
    constructor <;> rintro ⟨hx, he⟩ <;> refine ⟨hx, ?_⟩ <;> linarith
  rw [heq, Finset.card_image_of_injective _ (affineCoordinateSet_injective e a)]
  exact hH g hg (t+g a)

theorem hyperplaneMassBound_subset (S T : Finset E) (H : ℕ)
    (hST : T ⊆ S) (hH : hyperplaneMassBound S H) : hyperplaneMassBound T H := by
  intro f hf t
  exact (Finset.card_le_card (Finset.filter_subset_filter _ hST)).trans (hH f hf t)

theorem hyperplaneMassBound_coordinate_faces {n : ℕ} (S : Finset (Fin n → ℝ)) (H : ℕ)
    (hH : hyperplaneMassBound S H) :
    ∀ j, (S.filter (fun x => x j = -1)).card ≤ H ∧
      (S.filter (fun x => x j = 1)).card ≤ H := by
  intro j
  have hf : (LinearMap.proj j : (Fin n → ℝ) →ₗ[ℝ] ℝ) ≠ 0 := by
    intro hh
    have hh' := LinearMap.congr_fun hh (fun _ => 1)
    norm_num at hh'
  exact ⟨hH _ hf (-1), hH _ hf 1⟩

theorem affineCoordinateSet_cube_vertices {n : ℕ} (b : Basis (Fin n) ℝ E)
    (a : E) (S : Finset E)
    (hv : (freimanCubeVertices (List.ofFn b)).image (a+·) ⊆ S) :
    unitCubeVertices n ⊆ affineCoordinateSet b.equivFun a S := by
  letI : DecidableEq (Fin n → ℝ) := Classical.decEq _
  intro u hu
  have hx : b.equivFun.symm u ∈ freimanCubeVertices (List.ofFn b) :=
    (mem_freimanCubeVertices_basis _ _).mpr (by simpa only [LinearEquiv.apply_symm_apply] using hu)
  exact Finset.mem_image.mpr ⟨a+b.equivFun.symm u,
    hv (Finset.mem_image.mpr ⟨_, hx, rfl⟩), by simp only [add_sub_cancel_left, LinearEquiv.apply_symm_apply]⟩

theorem affineCoordinateSet_cube_capture {n : ℕ} (b : Basis (Fin n) ℝ E)
    (a : E) (S : Finset E) :
    unitCubeClosed (affineCoordinateSet b.equivFun a S) =
      affineCoordinateSet b.equivFun a (freimanCubeCapture S ⊥ a (List.ofFn b)) := by
  letI : DecidableEq (Fin n → ℝ) := Classical.decEq _
  rw [unitCubeClosed, affineCoordinateSet, Finset.filter_image]
  congr 1
  ext x
  simp [freimanCubeCapture, mem_freimanCubeBody_basis]

theorem freimanCubeCapture_degenerate_card {n : ℕ} (v : Fin n → E)
    (hspan : Submodule.span ℝ (Set.range v) ≠ ⊤)
    (S : Finset E) (a : E) (H : ℕ) (hH : hyperplaneMassBound S H) :
    (freimanCubeCapture S ⊥ a (List.ofFn v)).card ≤ H := by
  obtain ⟨f, hf, hker⟩ := freimanCubeBody_degenerate v hspan
  apply (Finset.card_le_card (show freimanCubeCapture S ⊥ a (List.ofFn v) ⊆
    S.filter (fun x => f x = f a) from ?_)).trans (hH f hf (f a))
  intro x hx
  obtain ⟨hxS, hxB⟩ := Finset.mem_filter.mp hx
  have hxB' : x-a ∈ freimanCubeBody (List.ofFn v) := by simpa using hxB
  have hz := hker (x-a) hxB'
  rw [map_sub, sub_eq_zero] at hz
  exact Finset.mem_filter.mpr ⟨hxS, hz⟩

omit [AddCommGroup E] [Module ℝ E] in
theorem list_eq_ofFn_of_length (v : List E) (n : ℕ) (hv : v.length = n) :
    ∃ w : Fin n → E, List.ofFn w = v := by
  subst n
  exact ⟨v.get, List.ofFn_get v⟩

local instance freimanCubeCoordinatesDecEqRealVec (n : ℕ) : DecidableEq (Fin n → ℝ) := Classical.decEq _

/-- The cube lemma gives either an actual hyperplane concentration or a
unit-cube partition after a cardinality-preserving affine change of coordinates. -/
theorem freimanCubePartition_alternative (n : ℕ) (hn : 0 < n)
    (S : Finset (Fin n → ℝ)) (hS : S.Nonempty) (τ : ℝ) (hτ : 0 < τ)
    (hdoub : ((S+S).card : ℝ) ≤ τ*S.card) (H : ℕ) (hH : hyperplaneMassBound S H) :
    generalFreimanCubeFraction n τ * S.card ≤ H ∨
    ∃ T : Finset (Fin n → ℝ), T.card = S.card ∧ (T+T).card = (S+S).card ∧
      hyperplaneMassBound T H ∧ unitCubeVertices n ⊆ T ∧
      generalFreimanCubeFraction n τ * S.card ≤ (unitCubeClosed T).card := by
  letI : DecidableEq (Fin n → ℝ) := Classical.decEq _
  have hdim : Module.finrank ℝ (Fin n → ℝ) = n := by simp
  obtain ⟨a, v, hlen, hv, hmass⟩ := freiman_cube_lemma
    (E := Fin n → ℝ) (by simpa only [hdim] using hn) S hS τ hτ hdoub
  rw [hdim] at hlen hmass
  obtain ⟨w, hw⟩ := list_eq_ofFn_of_length v n hlen
  rw [← hw] at hv hmass
  by_cases hspan : Submodule.span ℝ (Set.range w) = ⊤
  · right
    let b : Basis (Fin n) ℝ (Fin n → ℝ) :=
      basisOfTopLeSpanOfCardEqFinrank w hspan.ge (by simp)
    have hb : ⇑b = w := coe_basisOfTopLeSpanOfCardEqFinrank _ _ _
    let T := affineCoordinateSet b.equivFun a S
    refine ⟨T, affineCoordinateSet_card _ _ _, affineCoordinateSet_double_card _ _ _,
      hyperplaneMassBound_affineCoordinateSet _ _ _ _ hH, ?_, ?_⟩
    · apply affineCoordinateSet_cube_vertices
      simpa only [hb] using hv
    · have hc := affineCoordinateSet_cube_capture b a S
      have hcard : (unitCubeClosed T).card = (freimanCubeCapture S ⊥ a (List.ofFn w)).card := by
        rw [show unitCubeClosed T = _ from hc, affineCoordinateSet_card, hb]
      simpa only [hcard] using hmass
  · left
    exact hmass.trans (Nat.cast_le.mpr (freimanCubeCapture_degenerate_card w hspan S a H hH))

end
end Optss
