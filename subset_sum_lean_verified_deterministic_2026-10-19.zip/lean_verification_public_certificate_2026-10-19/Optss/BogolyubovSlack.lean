import Optss.BohrProgression

/-! Fixed-slack Fourier selection using only rational threshold comparisons.
Approximation correctness is an explicit premise here; construction and cost
of the approximations are separate from this perturbation theorem. -/
namespace Optss
open scoped BigOperators Pointwise
variable {N : ℕ} [NeZero N]

/-- Squared-amplitude error budget, in counting-measure normalization. -/
def rationalFourierEnergySlack (A : Finset (ZMod N)) : ℚ :=
  (A.card : ℚ)^3/(16*N)

/-- This selection is computable from rational approximations; it does not
test equality or order of real Fourier amplitudes. -/
def rationalApproximateSpectrum (A : Finset (ZMod N)) (E : ZMod N → ℚ) : Finset (ZMod N) :=
  Finset.univ.filter fun k => 2*rationalFourierEnergySlack A≤E k

theorem rationalFourierEnergySlack_cast (A : Finset (ZMod N)) :
    (rationalFourierEnergySlack A : ℝ)=(A.card : ℝ)^3/(16*N) := by
  simp [rationalFourierEnergySlack]

theorem rationalFourierEnergySlack_pos (A : Finset (ZMod N)) (hA : A.Nonempty) :
    0<rationalFourierEnergySlack A := by
  have hm : (0 : ℚ)<A.card := Nat.cast_pos.mpr (Finset.card_pos.mpr hA)
  have hN : (0 : ℚ)<N := Nat.cast_pos.mpr (NeZero.pos N)
  unfold rationalFourierEnergySlack
  positivity

theorem cyclicBohrSet_antitone {S T : Finset (ZMod N)} (h : S⊆T) :
    cyclicBohrSet T⊆cyclicBohrSet S := fun _ hx k hk => hx k (h hk)

/-- Every frequency above the upper threshold is retained; every retained
frequency exceeds the lower threshold. Intermediate frequencies are harmless. -/
theorem rationalApproximateSpectrum_sandwich (A : Finset (ZMod N)) (E : ZMod N → ℚ)
    (hE : ∀ k, |(E k : ℝ)-cyclicFourierEnergy A k|≤(rationalFourierEnergySlack A : ℝ)) :
    cyclicLargeSpectrum A (4*(rationalFourierEnergySlack A : ℝ))⊆
        rationalApproximateSpectrum A E ∧
      rationalApproximateSpectrum A E⊆
        cyclicLargeSpectrum A (rationalFourierEnergySlack A : ℝ) := by
  constructor
  · intro k hk
    have hk' := (Finset.mem_filter.mp hk).2
    have he := abs_le.mp (hE k)
    have hs : (0 : ℝ)≤rationalFourierEnergySlack A := (abs_nonneg _).trans (hE k)
    apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_univ _,?_⟩
    exact_mod_cast (show 2*(rationalFourierEnergySlack A : ℝ)≤(E k : ℝ) by linarith)
  · intro k hk
    have hk' : 2*(rationalFourierEnergySlack A : ℝ)≤(E k : ℝ) := by
      exact_mod_cast (Finset.mem_filter.mp hk).2
    have he := abs_le.mp (hE k)
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,by linarith⟩

theorem rationalApproximateSpectrum_card (A : Finset (ZMod N)) (hA : A.Nonempty)
    (E : ZMod N → ℚ)
    (hE : ∀ k, |(E k : ℝ)-cyclicFourierEnergy A k|≤(rationalFourierEnergySlack A : ℝ)) :
    ((rationalApproximateSpectrum A E).card : ℝ)≤16*(N : ℝ)^2/(A.card : ℝ)^2 := by
  have hm : (0 : ℝ)<A.card := Nat.cast_pos.mpr (Finset.card_pos.mpr hA)
  have hN : (0 : ℝ)<N := Nat.cast_pos.mpr (NeZero.pos N)
  have hs : (0 : ℝ)<rationalFourierEnergySlack A := by
    exact_mod_cast rationalFourierEnergySlack_pos A hA
  have hc : ((rationalApproximateSpectrum A E).card : ℝ)≤
      (cyclicLargeSpectrum A (rationalFourierEnergySlack A : ℝ)).card :=
    Nat.cast_le.mpr (Finset.card_le_card (rationalApproximateSpectrum_sandwich A E hE).2)
  have hb := (mul_le_mul_of_nonneg_right hc hs.le).trans
    (cyclicLargeSpectrum_card_mul A (rationalFourierEnergySlack A : ℝ))
  have he : ((rationalApproximateSpectrum A E).card*(A.card : ℝ)^2)*(A.card : ℝ)≤
      (16*(N : ℝ)^2)*(A.card : ℝ) := by
    calc
      _ = ((rationalApproximateSpectrum A E).card*(rationalFourierEnergySlack A : ℝ))*(16*N) := by
        rw [rationalFourierEnergySlack_cast]
        field_simp
        ring
      _ ≤ ((N : ℝ)*A.card)*(16*N) := mul_le_mul_of_nonneg_right hb (by positivity)
      _ = _ := by ring
  exact (le_div_iff₀ (sq_pos_of_pos hm)).mpr ((mul_le_mul_right hm).mp he)

theorem rationalApproximateSpectrum_representation_lower
    (A : Finset (ZMod N)) (hA : A.Nonempty) (E : ZMod N → ℚ)
    (hE : ∀ k, |(E k : ℝ)-cyclicFourierEnergy A k|≤(rationalFourierEnergySlack A : ℝ))
    (x : ZMod N) (hx : x∈cyclicBohrSet (rationalApproximateSpectrum A E)) :
    3*(A.card : ℝ)^4/4≤(N : ℝ)*(cyclicQuadrupleCount A x : ℝ) := by
  have hs : (0 : ℝ)<rationalFourierEnergySlack A := by
    exact_mod_cast rationalFourierEnergySlack_pos A hA
  have hN : (N : ℝ)≠0 := by exact_mod_cast NeZero.ne N
  have h := cyclicBohr_representation_lower A (4*(rationalFourierEnergySlack A : ℝ))
    (by positivity) x (cyclicBohrSet_antitone (rationalApproximateSpectrum_sandwich A E hE).1 hx)
  have he : (A.card : ℝ)^4-4*(rationalFourierEnergySlack A : ℝ)*((N : ℝ)*A.card)=
      3*(A.card : ℝ)^4/4 := by
    rw [rationalFourierEnergySlack_cast]
    field_simp
    ring
  rwa [he] at h

theorem rationalApproximateSpectrum_subset_double_difference
    (A : Finset (ZMod N)) (hA : A.Nonempty) (E : ZMod N → ℚ)
    (hE : ∀ k, |(E k : ℝ)-cyclicFourierEnergy A k|≤(rationalFourierEnergySlack A : ℝ)) :
    cyclicBohrSet (rationalApproximateSpectrum A E)⊆(↑((A+A)-(A+A)) : Set (ZMod N)) := by
  intro x hx
  have hm : (0 : ℝ)<A.card := Nat.cast_pos.mpr (Finset.card_pos.mpr hA)
  have hN : (0 : ℝ)<N := Nat.cast_pos.mpr (NeZero.pos N)
  have hp : 0<3*(A.card : ℝ)^4/4 := by positivity
  have h := hp.trans_le (rationalApproximateSpectrum_representation_lower A hA E hE x hx)
  have hc := (mul_pos_iff_of_pos_left hN).mp h
  exact (cyclicQuadrupleCount_pos_iff A x).mp (Nat.cast_pos.mp hc)

/-- The rational comparison output feeds the actual phase-lattice construction
without any further spectral comparison or supplied progression premise. -/
theorem rationalApproximateSpectrum_progression
    (A : Finset (ZMod N)) (hA : A.Nonempty) (E : ZMod N → ℚ)
    (hE : ∀ k, |(E k : ℝ)-cyclicFourierEnergy A k|≤(rationalFourierEnergySlack A : ℝ)) :
    ∃ ρ : IntVec ((rationalApproximateSpectrum A E).card+1) →+ ZMod N,
    ∃ m : Fin ((rationalApproximateSpectrum A E).card+1) → ℕ,
      Set.InjOn ρ (integerBudgetBox m) ∧ integerProgressionValues ρ m⊆(A+A)-(A+A) ∧
      N≤bohrProgressionLoss ((rationalApproximateSpectrum A E).card+1)*
        (integerProgressionValues ρ m).card ∧
      (((rationalApproximateSpectrum A E).card+1 : ℕ) : ℝ)≤
        1+16*(N : ℝ)^2/(A.card : ℝ)^2 := by
  obtain ⟨ρ,m,hproper,hsub,hcard⟩ := bohr_contains_progression (rationalApproximateSpectrum A E)
  refine ⟨ρ,m,hproper,?_,hcard,?_⟩
  · intro x hx
    exact rationalApproximateSpectrum_subset_double_difference A hA E hE (hsub hx)
  · have h := rationalApproximateSpectrum_card A hA E hE
    push_cast
    linarith

/-- Rational real and imaginary components are the stored Fourier data. -/
def rationalComplexValue (z : ℚ×ℚ) : ℂ := (z.1 : ℂ)+(z.2 : ℂ)*Complex.I
def rationalComplexEnergy (z : ℚ×ℚ) : ℚ := z.1^2+z.2^2

theorem rationalComplexEnergy_cast (z : ℚ×ℚ) :
    (rationalComplexEnergy z : ℝ)=Complex.normSq (rationalComplexValue z) := by
  simp [rationalComplexEnergy,rationalComplexValue,Complex.normSq_apply,pow_two]

theorem cyclicIndicator_dft_norm_le (A : Finset (ZMod N)) (k : ZMod N) :
    ‖ZMod.dft (cyclicIndicator A) k‖≤(A.card : ℝ) := by
  rw [ZMod.dft_apply]
  calc
    _ ≤ ∑ j, ‖ZMod.stdAddChar (-(j*k)) • cyclicIndicator A j‖ := norm_sum_le _ _
    _ = ∑ j, ‖cyclicIndicator A j‖ := by simp only [norm_smul,AddChar.norm_apply,one_mul]
    _ = ∑ j, if j∈A then (1 : ℝ) else 0 := by
      apply Finset.sum_congr rfl
      intro j _
      by_cases hj : j∈A <;> simp [cyclicIndicator,cyclicNatIndicator,hj]
    _ = _ := by simp

theorem complex_energy_error_bound (z w : ℂ) (M ε : ℝ) (hM : 0≤M) (hε : 0≤ε)
    (hw : ‖w‖≤M) (hz : ‖z-w‖≤ε) :
    |Complex.normSq z-Complex.normSq w|≤ε*(2*M+ε) := by
  have hd := (abs_norm_sub_norm_le z w).trans hz
  have hzn : ‖z‖≤M+ε := by have h := (abs_le.mp hd).2; linarith
  rw [← Complex.sq_norm,← Complex.sq_norm]
  have he : ‖z‖^2-‖w‖^2=(‖z‖-‖w‖)*(‖z‖+‖w‖) := by ring
  rw [he,abs_mul,abs_of_nonneg (add_nonneg (norm_nonneg _) (norm_nonneg _))]
  exact (mul_le_mul_of_nonneg_right hd (by positivity)).trans
    (mul_le_mul_of_nonneg_left (by linarith : ‖z‖+‖w‖≤2*M+ε) hε)

/-- A certified rational approximation to each complex Fourier coefficient
suffices for the rational squared-amplitude comparison. Required precision
in normalized Fourier coordinates is at most α²/64. -/
theorem rational_fourier_values_energy_error (A : Finset (ZMod N))
    (V : ZMod N → ℚ×ℚ)
    (hV : ∀ k, ‖rationalComplexValue (V k)-ZMod.dft (cyclicIndicator A) k‖≤
      (A.card : ℝ)^2/(64*N)) (k : ZMod N) :
    |(rationalComplexEnergy (V k) : ℝ)-cyclicFourierEnergy A k|≤
      (rationalFourierEnergySlack A : ℝ) := by
  have hN : (0 : ℝ)<N := Nat.cast_pos.mpr (NeZero.pos N)
  have hm : (0 : ℝ)≤A.card := by positivity
  have hmN : (A.card : ℝ)≤N := by
    exact_mod_cast (show A.card≤N by simpa only [ZMod.card] using Finset.card_le_univ A)
  let ε : ℝ := (A.card : ℝ)^2/(64*N)
  have hε : 0≤ε := by dsimp [ε]; positivity
  have hεm : ε≤(A.card : ℝ) := by
    dsimp [ε]
    apply (div_le_iff₀ (by positivity : (0 : ℝ)<64*N)).mpr
    nlinarith
  rw [rationalComplexEnergy_cast]
  change |Complex.normSq (rationalComplexValue (V k))-
    Complex.normSq (ZMod.dft (cyclicIndicator A) k)|≤_
  calc
    _ ≤ ε*(2*(A.card : ℝ)+ε) := complex_energy_error_bound _ _ _ _ hm hε
      (cyclicIndicator_dft_norm_le A k) (hV k)
    _ ≤ ε*(3*(A.card : ℝ)) := mul_le_mul_of_nonneg_left (by linarith) hε
    _ ≤ (rationalFourierEnergySlack A : ℝ) := by
      rw [rationalFourierEnergySlack_cast]
      dsimp [ε]
      have he : (A.card : ℝ)^2/(64*N)*(3*A.card)=
          (3/4)*((A.card : ℝ)^3/(16*N)) := by
        field_simp
        ring
      rw [he]
      have hh : (0 : ℝ)≤(A.card : ℝ)^3/(16*N) := by positivity
      nlinarith

end Optss
