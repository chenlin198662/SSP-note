import Optss.ListBluesteinBounds
import Optss.StoredSpectrumPipeline

/-! Original-input bounds for every word used by spectrum selection. -/
namespace Optss
variable {N : ℕ} [NeZero N]

theorem bluesteinPadExponent_le_size (N : ℕ) : bluesteinPadExponent N≤N.size+2 := by
  apply (Nat.le_pow_iff_clog_le (by decide : 1<2)).mp
  rw [pow_add]
  norm_num
  have h := Nat.lt_size_self N
  omega

def storedSpectrumDataBits (N : ℕ) : ℕ :=
  N.size+listBluesteinOutputBits (bluesteinPadExponent N)
    (dyadicDFTPrecision (bluesteinPadExponent N))+(storedSpectrumDenominator N).length

theorem storedSpectrumDataBits_bound (N : ℕ) :
    storedSpectrumDataBits N≤1000*(N.size+1)^2 := by
  have hn := bluesteinPadExponent_le_size N
  have hn2 := Nat.pow_le_pow_left hn 2
  simp only [storedSpectrumDataBits,listBluesteinOutputBits,dyadicDFTPrecision,
    storedSpectrumDenominator,listBluesteinDenominator_length,List.length_replicate]
  nlinarith

theorem storedResidueList_length_le (xs : List (ZMod N)) (hxs : xs.Nodup) : xs.length≤N := by
  have h := Finset.card_le_univ xs.toFinset
  simpa only [List.toFinset_card_of_nodup hxs,ZMod.card N] using h

theorem storedSpectrumOutput_bounds (xs : List (ZMod N)) :
    (listCanonicalDyadicDFT (storedIndicatorList xs)).length=N ∧
    ∀ z∈listCanonicalDyadicDFT (storedIndicatorList xs),z.Canonical ∧ z.Width (storedSpectrumDataBits N) := by
  have hinput : storedIndicatorList xs≠[] := by
    intro h
    have hlen := storedIndicatorList_length xs
    rw [h] at hlen
    simp only [List.length_nil] at hlen
    exact NeZero.ne N hlen.symm
  constructor
  · have h := congrArg List.length (listCanonicalDyadicDFT_eq N (dyadicIndicatorData xs.toFinset))
    rw [←storedIndicatorList_eq xs] at h
    simpa only [List.length_map,List.length_ofFn] using h
  · have h := listBluesteinTransform_bounds
      (List.replicate (bluesteinPadExponent N) false) (dyadicDFTPrecision (bluesteinPadExponent N))
      (storedIndicatorList xs) hinput
    simp only [List.length_replicate] at h
    unfold listCanonicalDyadicDFT
    rw [storedIndicatorList_length]
    intro z hz
    exact ⟨(h z hz).1,((h z hz).2).mono (by unfold storedSpectrumDataBits; omega)⟩

theorem storedSpectrumOperand_bounds (xs : List (ZMod N)) (hxs : xs.Nodup) :
    (wordBitEncode N).digits.length≤storedSpectrumDataBits N ∧
    (wordBitEncode xs.length).digits.length≤storedSpectrumDataBits N ∧
    (storedSpectrumDenominator N).length≤storedSpectrumDataBits N := by
  have hs := Nat.size_le_size (storedResidueList_length_le xs hxs)
  simp only [wordBitEncode_digits,Nat.size_eq_bits_len,storedSpectrumDataBits]
  omega

end Optss
