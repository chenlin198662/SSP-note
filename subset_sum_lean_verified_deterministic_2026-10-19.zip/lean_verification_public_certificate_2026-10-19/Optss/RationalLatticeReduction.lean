import Optss.RationalVertexNormalization
import Optss.IntegerSizeReduction
import Optss.LatticeBoxingGeometry

/-!
# Pulling integer lattice reduction back through rational normalization

A reduced integer row basis of the entire denominator-cleared lattice is
unscaled and transported back through the same normalization. The resulting
real basis generates exactly the standard integer lattice. Uniform nonzero
scaling cancels from the orthogonality defect. The reduction's numerical
defect estimate is a separate input to this adapter.
-/

namespace Optss
noncomputable section
open scoped BigOperators Classical
variable {r : ℕ}

/-- Basis integer points are precisely the integer submodule spanned by all
basis vectors. This identifies the full lattice rather than a witness sublattice. -/
theorem basisIntegerLattice_eq_integerSpan
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (b : Basis (Fin r) ℝ E) :
    basisIntegerLattice b = (Submodule.span ℤ (Set.range b) : Set E) := by
  ext x
  rw [mem_basisIntegerLattice_iff]
  change (∃ z : Fin r → ℤ, ∑ j, (z j : ℝ) • b j = x) ↔
    x ∈ Submodule.span ℤ (Set.range b)
  rw [Submodule.mem_span_range_iff_exists_fun]
  simp only [Int.cast_smul_eq_zsmul]

/-- The canonical real coordinate basis generates exactly the standard integer lattice. -/
theorem basisIntegerLattice_standard :
    basisIntegerLattice (Pi.basisFun ℝ (Fin r)) = Set.range (@realVector r) := by
  ext x
  change (∀ j, ∃ z : ℤ, x j = (z : ℝ)) ↔ ∃ z : IntVec r, realVector z = x
  constructor
  · intro hx
    choose z hz using hx
    exact ⟨z, funext (fun j => (hz j).symm)⟩
  · rintro ⟨z, rfl⟩
    exact fun j => ⟨z j, rfl⟩

/-- An independent square integer row family is an actual real Euclidean basis. -/
def basisOfEuclideanIntegerRows (B : Matrix (Fin r) (Fin r) ℤ)
    (hB : LinearIndependent ℝ (fun i j => (B i j : ℝ))) :
    Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)) :=
  Basis.mk ((euclideanIntegerRows_independent_iff B).mpr hB)
    (((euclideanIntegerRows_independent_iff B).mpr hB).span_eq_top_of_card_eq_finrank'
      (by simp)).ge

@[simp] theorem basisOfEuclideanIntegerRows_apply (B : Matrix (Fin r) (Fin r) ℤ)
    (hB : LinearIndependent ℝ (fun i j => (B i j : ℝ))) (i : Fin r) :
    basisOfEuclideanIntegerRows B hB i = euclideanIntegerRows B i := by
  simp [basisOfEuclideanIntegerRows]

/-- Uniform nonzero scaling cancels exactly from product of lengths divided by
absolute determinant. This also includes the zero-dimensional basis. -/
theorem euclideanOrthogonalityDefect_uniform_scale
    (b b' : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)))
    (t : ℝ) (ht : t ≠ 0) (hscale : ∀ j, b' j = t • b j) :
    euclideanOrthogonalityDefect b' = euclideanOrthogonalityDefect b := by
  have hm : euclideanBasisMatrix b' = t • euclideanBasisMatrix b := by
    ext i j
    change b' j i = t * b j i
    rw [hscale]
    rfl
  unfold euclideanOrthogonalityDefect
  simp_rw [hscale, norm_smul, Real.norm_eq_abs]
  rw [Finset.prod_mul_distrib, hm, Matrix.det_smul, abs_mul, abs_pow]
  simp only [Finset.prod_const, Finset.card_univ, Fintype.card_fin]
  exact mul_div_mul_left _ _ (pow_ne_zero _ (abs_ne_zero.mpr ht))

/-- Unscale the integer Euclidean basis and pull it through the normalization inverse. -/
def normalizedLatticePullback
    (a : (Fin r → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin r))
    (c : RationalNormalizationData a) : EuclideanSpace ℝ (Fin r) ≃ₗ[ℝ] (Fin r → ℝ) :=
  (LinearEquiv.smulOfNeZero ℝ (EuclideanSpace ℝ (Fin r))
    (c.denominator : ℝ)⁻¹ (inv_ne_zero (by exact_mod_cast c.denominator_pos.ne'))).trans
      a.symm.toLinearEquiv

@[simp] theorem normalizedLatticePullback_apply
    (a : (Fin r → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin r))
    (c : RationalNormalizationData a) (x : EuclideanSpace ℝ (Fin r)) :
    normalizedLatticePullback a c x = a.symm ((c.denominator : ℝ)⁻¹ • x) := rfl

/-- The actual real basis obtained from a reduced basis of the cleared lattice. -/
def pullbackReducedIntegerBasis
    (a : (Fin r → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin r))
    (c : RationalNormalizationData a) (B : Matrix (Fin r) (Fin r) ℤ)
    (hB : LinearIndependent ℝ (fun i j => (B i j : ℝ))) :
    Basis (Fin r) ℝ (Fin r → ℝ) :=
  (basisOfEuclideanIntegerRows B hB).map (normalizedLatticePullback a c)

/-- Under the same normalization, the pulled-back basis is exactly the uniformly
unscaled reduced integer basis. -/
theorem pullbackReducedIntegerBasis_normalized
    (a : (Fin r → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin r))
    (c : RationalNormalizationData a) (B : Matrix (Fin r) (Fin r) ℤ)
    (hB : LinearIndependent ℝ (fun i j => (B i j : ℝ))) (j : Fin r) :
    (pullbackReducedIntegerBasis a c B hB).map a.toLinearEquiv j =
      (c.denominator : ℝ)⁻¹ • basisOfEuclideanIntegerRows B hB j := by
  simp [pullbackReducedIntegerBasis, Basis.map_apply]

/-- No defect is lost when the denominator is removed and the basis is pulled back. -/
theorem pullbackReducedIntegerBasis_defect
    (a : (Fin r → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin r))
    (c : RationalNormalizationData a) (B : Matrix (Fin r) (Fin r) ℤ)
    (hB : LinearIndependent ℝ (fun i j => (B i j : ℝ))) :
    euclideanOrthogonalityDefect ((pullbackReducedIntegerBasis a c B hB).map a.toLinearEquiv) =
      euclideanOrthogonalityDefect (basisOfEuclideanIntegerRows B hB) :=
  euclideanOrthogonalityDefect_uniform_scale _ _ _
    (inv_ne_zero (by exact_mod_cast c.denominator_pos.ne'))
    (pullbackReducedIntegerBasis_normalized a c B hB)

/-- Mapping the full integer-row span back recovers exactly the standard lattice. -/
theorem pullbackReducedIntegerBasis_lattice
    (a : (Fin r → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin r))
    (c : RationalNormalizationData a) (B : Matrix (Fin r) (Fin r) ℤ)
    (hB : LinearIndependent ℝ (fun i j => (B i j : ℝ)))
    (hspan : Submodule.span ℤ (Set.range B) =
      Submodule.span ℤ (Set.range c.integerColumns.transpose)) :
    basisIntegerLattice (pullbackReducedIntegerBasis a c B hB) = Set.range (@realVector r) := by
  let embed : IntVec r →ₗ[ℤ] EuclideanSpace ℝ (Fin r) :=
    (((EuclideanSpace.equiv (Fin r) ℝ).symm.toLinearMap).restrictScalars ℤ).comp
      realVector.toIntLinearMap
  let T : IntVec r →ₗ[ℤ] (Fin r → ℝ) :=
    ((normalizedLatticePullback a c).toLinearMap.restrictScalars ℤ).comp embed
  have hTB : (fun j => T (B j)) = ⇑(pullbackReducedIntegerBasis a c B hB) := by
    funext j
    simp only [pullbackReducedIntegerBasis, Basis.map_apply, basisOfEuclideanIntegerRows_apply]
    rfl
  have hTZ : (fun j => T (c.integerColumns.transpose j)) = ⇑(Pi.basisFun ℝ (Fin r)) := by
    funext j
    have hz : embed (c.integerColumns.transpose j) =
        (c.denominator : ℝ) • a (Pi.single j 1) := by
      ext i
      exact (c.cleared_columns i j).symm
    change normalizedLatticePullback a c (embed (c.integerColumns.transpose j)) = _
    rw [hz, normalizedLatticePullback_apply, smul_smul,
      inv_mul_cancel₀ (show (c.denominator : ℝ) ≠ 0 by exact_mod_cast c.denominator_pos.ne'),
      one_smul, a.symm_apply_apply, Pi.basisFun_apply]
  have hm := congrArg (Submodule.map T) hspan
  simp only [Submodule.map_span, ← Set.range_comp] at hm
  change Submodule.span ℤ (Set.range (fun j => T (B j))) =
    Submodule.span ℤ (Set.range (fun j => T (c.integerColumns.transpose j))) at hm
  rw [hTB, hTZ] at hm
  rw [basisIntegerLattice_eq_integerSpan, hm, ← basisIntegerLattice_eq_integerSpan,
    basisIntegerLattice_standard]

/-- Adapter for the completed integer reduction theorem: its real defect bound
and exact integer span equality give a basis of the complete standard lattice
with the same bound after the original normalization. -/
theorem exists_standard_lattice_basis_of_integer_reduction
    (a : (Fin r → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin r))
    (c : RationalNormalizationData a) (B : Matrix (Fin r) (Fin r) ℤ)
    (hB : LinearIndependent ℝ (fun i j => (B i j : ℝ)))
    (hspan : Submodule.span ℤ (Set.range B) =
      Submodule.span ℤ (Set.range c.integerColumns.transpose))
    (ω : ℝ) (hdefect : euclideanOrthogonalityDefect (basisOfEuclideanIntegerRows B hB) ≤ ω) :
    ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
      basisIntegerLattice b = Set.range (@realVector r) ∧
      euclideanOrthogonalityDefect (b.map a.toLinearEquiv) ≤ ω := by
  refine ⟨pullbackReducedIntegerBasis a c B hB,
    pullbackReducedIntegerBasis_lattice a c B hB hspan, ?_⟩
  rwa [pullbackReducedIntegerBasis_defect]

end
end Optss
