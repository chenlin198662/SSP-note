import Optss.RandomClassSupport

/-!
# Independent finite samples for distinct size classes

Every size class may have its own finite color-coding sample space. A uniform
sample from their dependent function product gives each class exactly its own
uniform distribution. The counting proof below supplies the marginal law and
transports proved local witness-failure bounds into simultaneous clipped support
retention; no independence or marginal-probability premise is postulated.
-/

namespace Optss
noncomputable section
open scoped BigOperators Classical

/-- A coordinate event in the actual dependent finite product sample. -/
def dependentCoordinateEvent {ρ : Type*} {Ω : ρ → Type*} [Fintype ρ]
    [DecidableEq ρ] [∀ i, Fintype (Ω i)] (i : ρ) (A : Finset (Ω i)) : Finset (∀ j, Ω j) :=
  Finset.univ.filter (fun f => f i ∈ A)

@[simp] theorem mem_dependentCoordinateEvent {ρ : Type*} {Ω : ρ → Type*} [Fintype ρ]
    [DecidableEq ρ] [∀ i, Fintype (Ω i)] (i : ρ) (A : Finset (Ω i)) (f : ∀ j, Ω j) :
    f ∈ dependentCoordinateEvent i A ↔ f i ∈ A := by
  simp [dependentCoordinateEvent]

/-- The exact uniform marginal law for arbitrary coordinate-dependent finite
sample spaces. Nonemptiness of every factor is necessary for a probability law. -/
theorem uniformProbability_dependentCoordinateEvent {ρ : Type*} {Ω : ρ → Type*} [Fintype ρ]
    [DecidableEq ρ] [∀ i, Fintype (Ω i)] [∀ i, Nonempty (Ω i)]
    (i : ρ) (A : Finset (Ω i)) :
    uniformProbability (dependentCoordinateEvent i A) = uniformProbability A := by
  let E : ∀ j, Finset (Ω j) := fun j => if h : j=i then h.symm ▸ A else Finset.univ
  have hE : dependentCoordinateEvent i A = Fintype.piFinset E := by
    ext f
    simp only [mem_dependentCoordinateEvent, Fintype.mem_piFinset]
    constructor
    · intro hf j
      by_cases hji : j=i
      · subst j
        simpa [E] using hf
      · simp [E, hji]
    · intro hf
      simpa [E] using hf i
  rw [hE, uniformProbability_pi]
  have hm (j : ρ) : uniformProbability (E j) = if j=i then uniformProbability A else 1 := by
    by_cases hji : j=i
    · subst j
      simp [E]
    · simp [E, hji]
  simp_rw [hm]
  simp

/-- Original local failure event, before embedding the class's random choices
in the product sample shared by all classes. -/
def localClassWitnessFailure {ι : Type*} [Fintype ι] {d g : ℕ}
    {Ω : Fin g → Type*} [∀ p, Fintype (Ω p)]
    (v : ι → IntVec d) (part : ι → Fin g)
    (supports : ∀ p, Ω p → Finset (IntVec d)) (s : Finset ι) (p : Fin g) : Finset (Ω p) :=
  Finset.univ.filter (fun sample =>
    (∑ i ∈ s.filter (fun i => part i = p), v i) ∉ supports p sample)

/-- Each class reads only its own coordinate from the global uniform sample. -/
def independentClassSupports {d g : ℕ} {Ω : Fin g → Type*}
    (supports : ∀ p, Ω p → Finset (IntVec d)) :
    Fin g → (∀ p, Ω p) → Finset (IntVec d) := fun p sample => supports p (sample p)

/-- Actual local failure probability is unchanged inside the global sample. -/
theorem independent_classWitnessFailure_probability {ι : Type*} [Fintype ι] {d g : ℕ}
    {Ω : Fin g → Type*} [∀ p, Fintype (Ω p)] [∀ p, Nonempty (Ω p)]
    (v : ι → IntVec d) (part : ι → Fin g)
    (supports : ∀ p, Ω p → Finset (IntVec d)) (s : Finset ι) (p : Fin g) :
    uniformProbability (classWitnessFailure v part (independentClassSupports supports) s p) =
      uniformProbability (localClassWitnessFailure v part supports s p) := by
  have he : classWitnessFailure v part (independentClassSupports supports) s p =
      dependentCoordinateEvent p (localClassWitnessFailure v part supports s p) := by
    ext sample
    simp [classWitnessFailure, localClassWitnessFailure, dependentCoordinateEvent,
      independentClassSupports]
  rw [he]
  exact uniformProbability_dependentCoordinateEvent _ _

/-- Independently sampled one-class constructions combine into simultaneous
retention of all fixed target witnesses, with the stated product union bound. -/
theorem uniform_independent_simultaneousClassFailure_le {ι : Type*} [Fintype ι] {d g : ℕ}
    {Ω : Fin g → Type*} [∀ p, Fintype (Ω p)] [∀ p, Nonempty (Ω p)]
    (v : ι → IntVec d) (part : ι → Fin g) (Δ : Fin d →₀ ℕ)
    (supports : ∀ p, Ω p → Finset (IntVec d))
    (T : Finset (IntVec d)) (witness : {t // t ∈ T} → Finset ι)
    (hsum : ∀ t, (∑ i ∈ witness t, v i) = t.val)
    (hbudget : ∀ t, AbsoluteBudget v (witness t) (fun j => (Δ j : ℤ)))
    (ε : ℝ)
    (hlocal : ∀ t p, uniformProbability (localClassWitnessFailure v part supports (witness t) p) ≤ ε) :
    uniformProbability (simultaneousClassFailure Δ (independentClassSupports supports) T) ≤
      (T.card*g:ℕ)*ε := by
  apply uniform_simultaneousClassFailure_le v part Δ _ T witness hsum hbudget ε
  intro t p
  rw [independent_classWitnessFailure_probability]
  exact hlocal t p

end
end Optss
