import Optss.DyadicPropernessGrowth

/-!
# Exact floor control for real dyadic coefficient dilations

For a positive floored width, doubling the real radius increases its floor
by at most a factor of three. This explicitly handles the rounding in the
properness-growth argument; it does not identify geometric dilation with
repeated sums when coefficient endpoints are nonintegral.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 1000000
local instance flooredDyadicBoxesDecEqInt : DecidableEq ℤ := Classical.decEq _
variable {d : ℕ}

theorem floor_double_le_triple_floor (x : ℝ) (hx : 0 ≤ x) (hfloor : 1 ≤ ⌊x⌋₊) :
    ⌊2*x⌋₊ ≤ 3*⌊x⌋₊ := by
  have hf : (1:ℝ) ≤ ⌊x⌋₊ := by exact_mod_cast hfloor
  have hh := Nat.lt_floor_add_one x
  have hlt : 2*x < ((3*⌊x⌋₊+1:ℕ):ℝ) := by push_cast; linarith
  have hn := (Nat.floor_lt (by positivity : 0 ≤ 2*x)).mpr hlt
  omega

def flooredProgressionBudget (P : CenteredProgression (Fin d) ℤ) (s : ℝ) : Fin d → ℕ :=
  fun j => ⌊s*P.upperRadius j⌋₊

theorem symmetric_coefficientBox_eq_floor (P : CenteredProgression (Fin d) ℤ)
    (hsym : P.lowerRadius = P.upperRadius) (s : ℝ) (hs : 0 ≤ s) :
    P.coefficientBox s = integerBudgetBox (flooredProgressionBudget P s) := by
  ext z
  rw [P.mem_coefficientBox, mem_integerBudgetBox]
  change (∀ j, -(s*P.lowerRadius j) ≤ (z j:ℝ) ∧ (z j:ℝ) ≤ s*P.upperRadius j) ↔
    ∀ j, |z j| ≤ (⌊s*P.upperRadius j⌋₊:ℤ)
  rw [hsym]
  constructor
  · intro hz j
    rw [Int.natCast_floor_eq_floor (mul_nonneg hs (P.upper_nonneg j)), Int.le_floor]
    simpa only [Int.cast_abs] using (abs_le.mpr (hz j))
  · intro hz j
    have hh := hz j
    rw [Int.natCast_floor_eq_floor (mul_nonneg hs (P.upper_nonneg j)), Int.le_floor] at hh
    exact abs_le.mp (by simpa only [Int.cast_abs] using hh)

theorem symmetric_values_eq_floor (P : CenteredProgression (Fin d) ℤ)
    (hsym : P.lowerRadius = P.upperRadius) (s : ℝ) (hs : 0 ≤ s) :
    P.values s = integerProgressionValues P.map (flooredProgressionBudget P s) := by
  rw [CenteredProgression.values, integerProgressionValues, symmetric_coefficientBox_eq_floor P hsym s hs]

theorem flooredProgressionBudget_double_le (P : CenteredProgression (Fin d) ℤ)
    (s : ℝ) (hs : 0 ≤ s) (hwide : ∀ j, 1 ≤ s*P.upperRadius j) :
    ∀ j, flooredProgressionBudget P (2*s) j ≤ 3*flooredProgressionBudget P s j := by
  intro j
  dsimp only [flooredProgressionBudget]
  rw [mul_assoc]
  exact floor_double_le_triple_floor _ (mul_nonneg hs (P.upper_nonneg j)) ((Nat.one_le_floor_iff _).mpr (hwide j))

/-- The actual doubled geometric box fits in the triple of the earlier
integer box, including all rounding effects. -/
theorem symmetric_double_box_subset_triple_floor (P : CenteredProgression (Fin d) ℤ)
    (hsym : P.lowerRadius = P.upperRadius) (s : ℝ) (hs : 0 ≤ s)
    (hwide : ∀ j, 1 ≤ s*P.upperRadius j) :
    P.coefficientBox (2*s) ⊆ integerBudgetBox (fun j => 3*flooredProgressionBudget P s j) := by
  rw [symmetric_coefficientBox_eq_floor P hsym (2*s) (by positivity)]
  intro z hz
  apply (mem_integerBudgetBox _ z).mpr
  intro j
  exact ((mem_integerBudgetBox _ z).mp hz j).trans
    (Int.ofNat_le.mpr (flooredProgressionBudget_double_le P s hs hwide j))

/-- The verified degree-gap argument upgrades properness at a real scale
to properness at its double, using actual containing and filling sets. -/
theorem symmetric_progression_double_proper_of_dyadic_growth
    (A : Finset ℤ) (hzero : 0 ∈ A) (a b q : ℕ) (hq : 0 < q) (hdq : d ≤ q)
    (hminimal : ∀ p < q, ∀ i, a ≤ i → i ≤ b →
      (3/2:ℝ)*2^p*(dyadicSumset A i).card < (dyadicSumset A (i+1)).card)
    (P : CenteredProgression (Fin d) ℤ) (hsym : P.lowerRadius = P.upperRadius)
    (s : ℝ) (hs : 0 ≤ s) (hwide : ∀ j, 1 ≤ s*P.upperRadius j) (hproper : P.Proper s)
    (u t L : ℕ) (hau : a ≤ u+t) (hwindow : u+t+L ≤ b+1)
    (hcontain : dyadicSumset A u ⊆ P.values s)
    (hfill : ∃ z : ℤ, (P.values s).image (z+·) ⊆ dyadicSumset A (u+t))
    (hlong : 2*(properizationIterationFactor latticeReductionDefectBound 3 d : ℝ)*
      (2:ℝ)^(t*(d-1)) ≤ L) : P.Proper (2*s) := by
  have hbox := symmetric_coefficientBox_eq_floor P hsym s hs
  have hval := symmetric_values_eq_floor P hsym s hs
  have hp : Set.InjOn P.map (integerBudgetBox (flooredProgressionBudget P s)) := by
    rw [← hbox]
    exact hproper
  have hp3 := progression_triple_proper_of_dyadic_growth A hzero a b q hq hdq hminimal
    P.map (flooredProgressionBudget P s) hp u t L hau hwindow
    (hval ▸ hcontain) (hval ▸ hfill) hlong
  exact hp3.mono (symmetric_double_box_subset_triple_floor P hsym s hs hwide)

/-- Iterating the local degree-gap obstruction proves properness throughout
an explicit dyadic range. Containment and filling refer to the actual sets
at each scale; there is no assumed properness beyond the initial scale. -/
theorem dyadic_progression_proper_up_to
    (A : Finset ℤ) (hzero : 0 ∈ A) (a b q : ℕ) (hq : 0 < q) (hdq : d ≤ q)
    (hminimal : ∀ p < q, ∀ i, a ≤ i → i ≤ b →
      (3/2:ℝ)*2^p*(dyadicSumset A i).card < (dyadicSumset A (i+1)).card)
    (P : CenteredProgression (Fin d) ℤ) (hsym : P.lowerRadius = P.upperRadius)
    (s : ℝ) (hs : 0 ≤ s) (hwide : ∀ j, 1 ≤ s*P.upperRadius j) (hproper : P.Proper s)
    (u t L K : ℕ) (hau : a ≤ u+t) (hwindow : u+K+t+L ≤ b+1)
    (hcontain : ∀ k ≤ K, dyadicSumset A (u+k) ⊆ P.values ((2:ℝ)^k*s))
    (hfill : ∀ k ≤ K, ∃ z : ℤ,
      (P.values ((2:ℝ)^k*s)).image (z+·) ⊆ dyadicSumset A (u+k+t))
    (hlong : 2*(properizationIterationFactor latticeReductionDefectBound 3 d : ℝ)*
      (2:ℝ)^(t*(d-1)) ≤ L) :
    ∀ k ≤ K+1, P.Proper ((2:ℝ)^k*s) := by
  intro k
  induction k with
  | zero => intro _; simpa only [pow_zero, one_mul] using hproper
  | succ k ih =>
    intro hk
    have hkK : k ≤ K := by omega
    have hp := ih (by omega)
    have hs' : 0 ≤ (2:ℝ)^k*s := mul_nonneg (by positivity) hs
    have hwide' : ∀ j, 1 ≤ ((2:ℝ)^k*s)*P.upperRadius j := by
      intro j
      have hpow : (1:ℝ) ≤ 2^k := one_le_pow₀ (by norm_num)
      have hh := mul_le_mul_of_nonneg_right hpow (mul_nonneg hs (P.upper_nonneg j))
      nlinarith [hwide j]
    have hnext := symmetric_progression_double_proper_of_dyadic_growth A hzero a b q hq hdq hminimal
      P hsym ((2:ℝ)^k*s) hs' hwide' hp (u+k) t L (by omega) (by omega)
      (hcontain k hkK) (hfill k hkK) hlong
    convert hnext using 1
    rw [pow_succ]
    ring

/-- A case-free endpoint form: even when the selected initial scale is
near the end of the growth window, initial properness covers the result. -/
theorem dyadic_progression_proper_endpoint
    (A : Finset ℤ) (hzero : 0 ∈ A) (a b q : ℕ) (hq : 0 < q) (hdq : d ≤ q)
    (hminimal : ∀ p < q, ∀ i, a ≤ i → i ≤ b →
      (3/2:ℝ)*2^p*(dyadicSumset A i).card < (dyadicSumset A (i+1)).card)
    (P : CenteredProgression (Fin d) ℤ) (hsym : P.lowerRadius = P.upperRadius)
    (s : ℝ) (hs : 0 ≤ s) (hwide : ∀ j, 1 ≤ s*P.upperRadius j) (hproper : P.Proper s)
    (u t L : ℕ) (hau : a ≤ u+t)
    (hcontain : ∀ k, dyadicSumset A (u+k) ⊆ P.values ((2:ℝ)^k*s))
    (hfill : ∀ k, ∃ z : ℤ,
      (P.values ((2:ℝ)^k*s)).image (z+·) ⊆ dyadicSumset A (u+k+t))
    (hlong : 2*(properizationIterationFactor latticeReductionDefectBound 3 d : ℝ)*
      (2:ℝ)^(t*(d-1)) ≤ L) :
    P.Proper (((2:ℝ)^(b+1)/(2:ℝ)^(u+t+L))*s) := by
  let K := b+1-(u+t+L)
  have hpK : P.Proper ((2:ℝ)^K*s) := by
    by_cases hK : K = 0
    · simpa only [hK, pow_zero, one_mul] using hproper
    · obtain ⟨k, hk⟩ := Nat.exists_eq_succ_of_ne_zero hK
      have hwindow : u+k+t+L ≤ b+1 := by dsimp [K] at hk; omega
      have hh := dyadic_progression_proper_up_to A hzero a b q hq hdq hminimal
        P hsym s hs hwide hproper u t L k hau hwindow
        (fun j _ => hcontain j) (fun j _ => hfill j) hlong (k+1) le_rfl
      simpa only [hk] using hh
  apply hpK.mono
  apply mul_le_mul_of_nonneg_right _ hs
  apply (div_le_iff₀ (by positivity : (0:ℝ) < 2^(u+t+L))).mpr
  have hexp : b+1 ≤ K+(u+t+L) := by dsimp [K]; omega
  simpa only [pow_add] using (pow_le_pow_right₀ (by norm_num : (1:ℝ) ≤ 2) hexp)

end
end Optss
