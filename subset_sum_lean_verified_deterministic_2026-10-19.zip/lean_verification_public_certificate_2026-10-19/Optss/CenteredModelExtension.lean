import Optss.ComputedModelingPart
import Optss.FreimanDifferenceLift
import Mathlib.Data.ZMod.ValMinAbs

/-!
# Computable extension of the model to a double difference

The centered representative of n*a modulo q recovers the difference of the
four short-interval residue representatives. Reduction modulo p therefore
agrees exactly with the abstract Freiman extension, including its inverse.
-/
namespace Optss
open scoped Pointwise

def centeredModelExtension (n p q : ℕ) (a : ℤ) : ZMod p :=
  (((n:ZMod q)*(a:ZMod q)).valMinAbs : ℤ)

theorem centeredModelExtension_fourDifference (data : List ℤ) (n p q : ℕ) (hq : 0<q)
    (u : Fin 4→ℤ) (hu : ∀ i, u i∈computedModelingPart data n q) :
    centeredModelExtension n p q (fourDifference u)=
      fourDifference ((fun a => (modelingResidue (n:ZMod q) a : ZMod p)) ∘ u) := by
  letI : NeZero q := ⟨hq.ne'⟩
  let r := modelingResidue (n:ZMod q)
  let z := fourDifference (r ∘ u)
  have h₁ := computedModelingPart_same_interval data n q hq (u 0) (u 2) (hu 0) (hu 2)
  have h₂ := computedModelingPart_same_interval data n q hq (u 1) (u 3) (hu 1) (hu 3)
  have h₃ := computedModelingPart_same_interval data n q hq (u 2) (u 0) (hu 2) (hu 0)
  have h₄ := computedModelingPart_same_interval data n q hq (u 3) (u 1) (hu 3) (hu 1)
  have hz : z*2∈Set.Ioc (-(q:ℤ)) q := by
    dsimp only [z,fourDifference,Function.comp_apply,r]
    constructor <;> nlinarith
  have hcast : (z:ZMod q)=(n:ZMod q)*(fourDifference u:ℤ) := by
    dsimp only [z,fourDifference,Function.comp_apply,r]
    push_cast
    simp only [modelingResidue_congr]
    ring
  have hcenter : ((n:ZMod q)*(fourDifference u:ℤ)).valMinAbs=z :=
    (ZMod.valMinAbs_spec _ z).mpr ⟨hcast.symm,hz⟩
  rw [centeredModelExtension,hcenter]
  dsimp only [z,fourDifference,Function.comp_apply,r]
  push_cast
  rfl

theorem centeredModelExtension_injective (data : List ℤ) (n p q : ℕ) (hq : 0<q)
    (hf : FreimanEight (computedModelingPart data n q).toFinset
      (fun a => (modelingResidue (n:ZMod q) a : ZMod p))) :
    let T := (computedModelingPart data n q).toFinset
    Set.InjOn (centeredModelExtension n p q) ((T+T)-(T+T) : Finset ℤ) := by
  intro T x hx y hy hxy
  obtain ⟨u,hu,rfl⟩ := (mem_doubleDifference_iff T x).mp hx
  obtain ⟨v,hv,rfl⟩ := (mem_doubleDifference_iff T y).mp hy
  rw [centeredModelExtension_fourDifference data n p q hq u
    (fun i => List.mem_toFinset.mp (hu i)),
    centeredModelExtension_fourDifference data n p q hq v
      (fun i => List.mem_toFinset.mp (hv i))] at hxy
  exact (hf.fourDifference_eq_iff u v hu hv).mp hxy

theorem centeredModelExtension_lift (data : List ℤ) (n p q : ℕ) (hq : 0<q)
    (hf : FreimanEight (computedModelingPart data n q).toFinset
      (fun a => (modelingResidue (n:ZMod q) a : ZMod p)))
    (a : ℤ) (ha : a∈((computedModelingPart data n q).toFinset+
      (computedModelingPart data n q).toFinset)-((computedModelingPart data n q).toFinset+
      (computedModelingPart data n q).toFinset)) :
    modelDifferenceLift (computedModelingPart data n q).toFinset
      (fun x => (modelingResidue (n:ZMod q) x : ZMod p))
      (centeredModelExtension n p q a)=a := by
  obtain ⟨u,hu,rfl⟩ := (mem_doubleDifference_iff _ a).mp ha
  rw [centeredModelExtension_fourDifference data n p q hq u
    (fun i => List.mem_toFinset.mp (hu i))]
  exact modelDifferenceLift_representation hf u hu

end Optss
