import Optss.CommonCopyCounters

/-!
# Consistent type coordinates and actual reserve-counter witnesses

Properness on the input box makes equal retained scalar values have equal
coordinates. Thus the labelled common-GAP construction has a single coordinate
per live type, exact exception and reserve counters, and genuine subset
witnesses realizing every filled point.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1400000

theorem CommonReserveCoordinateModel.equal_coordinates {ι : Type} [DecidableEq ι]
    {d : ℕ} {scalar : ι → ℤ} {available reserve remainder : Finset ι} {h extra : ℕ} {c : ℝ}
    (model : CommonReserveCoordinateModel d scalar available reserve remainder h extra c)
    (hscale : 1 ≤ c*h) (i j : ι) (hi : i ∈ available) (hj : j ∈ available)
    (he : scalar i = scalar j) : model.coordinates i = model.coordinates j := by
  apply model.proper
  · intro k
    have hb : |(model.coordinates i k : ℝ)| ≤ model.widths k := by exact_mod_cast model.boxed i hi k
    exact hb.trans (by simpa only [one_mul] using mul_le_mul_of_nonneg_right hscale (Nat.cast_nonneg (model.widths k)))
  · intro k
    have hb : |(model.coordinates j k : ℝ)| ≤ model.widths k := by exact_mod_cast model.boxed j hj k
    exact hb.trans (by simpa only [one_mul] using mul_le_mul_of_nonneg_right hscale (Nat.cast_nonneg (model.widths k)))
  · rw [model.represents i hi, model.represents j hj, he]

variable {ι : Type} [Fintype ι] [DecidableEq ι]

/-- Coordinates of an actual available representative, or zero for a dead type. -/
def commonCopyTypeCoordinates {d : ℕ} (capacity : ι → ℕ)
    (coordinates : CopyIndex capacity → IntVec d) (available : Finset (CopyIndex capacity))
    (i : ι) : IntVec d :=
  if hi : ∃ j : Fin (capacity i), Sigma.mk i j ∈ available then coordinates ⟨i, Classical.choose hi⟩ else 0

/-- Every actual available copy has the same derived per-type coordinates. -/
theorem commonCopyTypeCoordinates_spec {d : ℕ} (capacity : ι → ℕ) (scalar : ι → ℤ)
    {available reserve remainder : Finset (CopyIndex capacity)} {h extra : ℕ} {c : ℝ}
    (model : CommonReserveCoordinateModel d (expandedCopy scalar capacity) available reserve remainder h extra c)
    (hscale : 1 ≤ c*h) :
    ∀ q ∈ available, model.coordinates q = commonCopyTypeCoordinates capacity model.coordinates available q.1 := by
  intro q hq
  have hex : ∃ j : Fin (capacity q.1), Sigma.mk q.1 j ∈ available := ⟨q.2, hq⟩
  rw [commonCopyTypeCoordinates, dif_pos hex]
  exact model.equal_coordinates hscale q _ hq (Classical.choose_spec hex) rfl

/-- Exact type-coordinate witnesses and full-lattice generation for a common
GAP decomposition of all available copies. Every filled point comes with a
subset of the actual selected reserve labels, not just bounded formal counts. -/
theorem CommonGapDecomposition.counted_output {dR h extra Ebound Rbound : ℕ} {c : ℝ}
    (capacity : ι → ℕ) (scalar : ι → ℤ)
    (out : CommonGapDecomposition (expandedCopy scalar capacity) Finset.univ h extra dR Ebound Rbound c)
    (hscale : 1 ≤ c*h) :
    let e := copyDebit capacity (Finset.univ \ out.available)
    let r := copyDebit capacity out.reserve
    ∃ u : ι → IntVec out.rank,
      (∀ q ∈ out.available, out.model.coordinates q = u q.1) ∧
      (∀ i, 0 < capacity i-e i →
        out.model.projection (u i) = scalar i ∧ InCenteredBox out.model.widths (u i)) ∧
      (∀ i, e i ≤ capacity i ∧ r i ≤ capacity i-e i) ∧
      (∑ i, e i) ≤ Ebound ∧ (∑ i, r i) ≤ Rbound ∧
      generatedLattice u (Finset.univ.filter (fun i => 0 < r i)) = ⊤ ∧
      generatedLattice u (Finset.univ.filter (fun i => 0 < capacity i-e i-r i)) = ⊤ ∧
      ∃ t : IntVec out.rank, ∀ z : IntVec out.rank,
        (∀ j, |(z j : ℝ)| ≤ c*h*out.model.widths j) →
        ∃ selected ⊆ out.reserve,
          BoundedCounts (fun i => (r i : ℤ)) (copyCount capacity selected) ∧
          weightedSum u (copyCount capacity selected) = t+z := by
  dsimp only
  let u := commonCopyTypeCoordinates capacity out.model.coordinates out.available
  have hu : ∀ q ∈ out.available, out.model.coordinates q = u q.1 :=
    commonCopyTypeCoordinates_spec capacity scalar out.model hscale
  obtain ⟨hcounter, hrem, he, hr⟩ := copy_partition_counters capacity out.available out.reserve out.reserve_subset
  have ha : ∀ i, copyDebit capacity out.available i = capacity i-copyDebit capacity (Finset.univ \ out.available) i := by
    intro i
    rw [copyDebit_sdiff capacity (Finset.subset_univ _) i, copyDebit_univ]
    have hb := copyDebit_le_available capacity out.available i
    omega
  have hremain : out.remaining ⊆ out.available := by rw [out.remaining_eq]; exact Finset.sdiff_subset
  refine ⟨u, hu, ?_, hcounter, he ▸ out.outlier_bound, hr ▸ out.reserve_bound, ?_, ?_, ?_⟩
  · intro i hi
    have hi' : 0 < copyDebit capacity out.available i := by rw [ha i]; exact hi
    obtain ⟨j, hj⟩ := (copyDebit_pos_iff capacity out.available i).mp hi'
    have heq := hu ⟨i, j⟩ hj
    refine ⟨?_, ?_⟩
    · rw [← heq]
      exact out.model.represents _ hj
    · rw [← heq]
      exact out.model.boxed _ hj
  · rw [← generatedLattice_copy_types capacity out.model.coordinates u out.reserve
      (fun q hq => hu q (out.reserve_subset hq))]
    exact out.model.reserve_generates
  · have hg := generatedLattice_copy_types capacity out.model.coordinates u out.remaining
      (fun q hq => hu q (hremain hq))
    have heq : Finset.univ.filter (fun i => 0 < copyDebit capacity out.remaining i) =
        Finset.univ.filter (fun i => 0 < capacity i-copyDebit capacity (Finset.univ \ out.available) i-copyDebit capacity out.reserve i) := by
      apply Finset.filter_congr
      intro i _
      rw [out.remaining_eq, hrem i]
    rw [heq] at hg
    exact hg.symm.trans out.model.remainder_generates
  · obtain ⟨t, ht⟩ := out.model.filled
    refine ⟨t, fun z hz => ?_⟩
    obtain ⟨selected, hs, hsum⟩ := (mem_labelledSubsetSupport _ _ _).mp (ht z hz)
    obtain ⟨hbounded, heq⟩ := selected_copies_weighted_sum capacity out.model.coordinates u out.reserve selected hs
      (fun q hq => hu q (out.reserve_subset hq))
    exact ⟨selected, hs, hbounded, heq.trans hsum⟩

end
end Optss
