import Optss.ListCyclicConvolution

/-! The three-DFT convolution has a linear-in-length polynomial source-work
bound, with all intermediate widths derived from the stored input digits. -/
namespace Optss
open scoped BigOperators
set_option maxHeartbeats 800000
set_option maxRecDepth 4096

def listDyadicWorkPolynomial (n p b : ℕ) : ℕ :=
  2^(n+1)*(320*(n+3)^2+4194304*(n+p+73)^2*(8192*(n+p+73)^4+1)^3+16)+4*(p+3)+4+
    576*(n+1)*2^n*(n*(p+6)+b+3)^2

def listCyclicConvolutionWork (depth : List Bool) (p : ℕ) (A B : List BitFourierInteger) : ℕ :=
  let FA := listDyadicTransform depth p A
  let FB := listDyadicTransform depth p B
  let P := List.zipWith bitFourierMul FA FB
  let C := listDyadicTransform depth p P
  listDyadicTransformWork depth p A+listDyadicTransformWork depth p B+
    (List.zipWith bitFourierMulWork FA FB).sum+listDyadicTransformWork depth p P+
    4*min FA.length FB.length+2*C.length+8

theorem BitFourierInteger.Width.mono {z : BitFourierInteger} {a b : ℕ}
    (hz : z.Width a) (hab : a≤b) : z.Width b := ⟨hz.1.trans hab,hz.2.trans hab⟩

theorem listCyclicConvolutionWork_bound (depth : List Bool) (p b : ℕ)
    (A B : Vector BitFourierInteger (2^depth.length))
    (hAc : ∀ j, (A.get j).Canonical) (hBc : ∀ j, (B.get j).Canonical)
    (hA : ∀ j, (A.get j).Width b) (hB : ∀ j, (B.get j).Width b) :
    listCyclicConvolutionWork depth p (List.ofFn A.get) (List.ofFn B.get)≤
      3*listDyadicWorkPolynomial depth.length p (2*(depth.length*(p+6)+b+2)+1)+
        512*2^depth.length*(depth.length*(p+6)+b+3)^2+6*2^depth.length+8 := by
  let T := listDyadicTwiddleFunction (radixModulusDigits depth) depth.length p
  let D := listDyadicDenominator p
  let FA := bitFixedPointRadixTwo D T depth.length A
  let FB := bitFixedPointRadixTwo D T depth.length B
  let P := Vector.ofFn (fun j => bitFourierMul (FA.get j) (FB.get j))
  let L := depth.length*(p+6)+b+2
  let W := 2*L+1
  have hwidthA : ∀ j, (FA.get j).Width L := by
    intro j
    apply listDyadicTransform_width depth p b A hAc hA
    rw [listDyadicTransform_storage,List.mem_ofFn]
    exact ⟨j,rfl⟩
  have hwidthB : ∀ j, (FB.get j).Width L := by
    intro j
    apply listDyadicTransform_width depth p b B hBc hB
    rw [listDyadicTransform_storage,List.mem_ofFn]
    exact ⟨j,rfl⟩
  have hPc : ∀ j, (P.get j).Canonical := by
    intro j
    simp only [P,vector_get_ofFn]
    exact bitFourierMul_canonical _ _
  have hPwidth : ∀ j, (P.get j).Width W := by
    intro j
    simp only [P,vector_get_ofFn]
    exact bitFourierMul_width _ _ L (hwidthA j) (hwidthB j)
  have hbW : b≤W := by dsimp [W,L]; omega
  have hwA := listDyadicTransformWork_bits depth p W A hAc (fun j => (hA j).mono hbW)
  have hwB := listDyadicTransformWork_bits depth p W B hBc (fun j => (hB j).mono hbW)
  have hwP := listDyadicTransformWork_bits depth p W P hPc hPwidth
  change _≤listDyadicWorkPolynomial depth.length p W at hwA hwB hwP
  have hmul : (List.zipWith bitFourierMulWork (List.ofFn FA.get) (List.ofFn FB.get)).sum≤
      512*2^depth.length*(L+1)^2 := by
    rw [fourierList_zipWith_ofFn,List.sum_ofFn]
    calc
      _≤∑ _j : Fin (2^depth.length), 512*(L+1)^2 := by
        apply Finset.sum_le_sum
        intro j _
        have h := bitFourierMulWork_bound _ _ L (hwidthA j) (hwidthB j)
        nlinarith only [h]
      _=_ := by simp; ring
  have hpsource : List.zipWith bitFourierMul (List.ofFn FA.get) (List.ofFn FB.get)=List.ofFn P.get := by
    rw [fourierList_zipWith_ofFn]
    apply congrArg List.ofFn
    funext j
    simp only [P,vector_get_ofFn]
  unfold listCyclicConvolutionWork
  dsimp only
  rw [listDyadicTransform_storage depth p A,listDyadicTransform_storage depth p B]
  change listDyadicTransformWork depth p (List.ofFn A.get)+listDyadicTransformWork depth p (List.ofFn B.get)+
    (List.zipWith bitFourierMulWork (List.ofFn FA.get) (List.ofFn FB.get)).sum+
    listDyadicTransformWork depth p (List.zipWith bitFourierMul (List.ofFn FA.get) (List.ofFn FB.get))+
    4*min (List.ofFn FA.get).length (List.ofFn FB.get).length+
    2*(listDyadicTransform depth p (List.zipWith bitFourierMul (List.ofFn FA.get) (List.ofFn FB.get))).length+8≤_
  rw [hpsource,listDyadicTransform_length]
  simp only [List.length_ofFn,min_self]
  change _≤3*listDyadicWorkPolynomial depth.length p W+512*2^depth.length*(L+1)^2+6*2^depth.length+8
  omega

end Optss
