import Optss.CommonGapPhase
import Optss.LongSumsetGreedyProfile

/-!
# Original labels and the actual basis-protection alternative

The finite coordinate model is lifted back to every original label, retaining
multiplicities. The actual basis-packing routine either protects full rank
against all small deletions, or deletes boundedly many labels and strictly
halves the scalar phase potential.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1000000

/-- The coordinate inverse returns the given coefficient vector throughout
the original proper box. -/
theorem phase_coordinate_inverse {d : ℕ} (ρ : IntVec d →+ ℤ) (w : Fin d → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox (fun j => 2*w j)))
    (x : IntVec d) (hx : InCenteredBox w x) :
    integerProgressionCoordinates ρ w (ρ x) = x := by
  have hm : ρ x ∈ integerProgressionValues ρ w :=
    Finset.mem_image.mpr ⟨x, (mem_integerBudgetBox _ _).mpr hx, rfl⟩
  obtain ⟨hb, he⟩ := integerProgressionCoordinates_spec ρ w hm
  exact hproper ((mem_integerBudgetBox _ _).mpr (inBox_double w hb))
    ((mem_integerBudgetBox _ _).mpr (inBox_double w hx)) he

/-- Labels with equal scalar values keep their distinct identities while
acquiring the same uniquely determined coordinates. -/
def phaseLabelCoordinates {ι : Type*} {d : ℕ} (ρ : IntVec d →+ ℤ)
    (w : Fin d → ℕ) (v : ι → ℤ) : ι → IntVec d :=
  fun i => integerProgressionCoordinates ρ w (v i)

/-- Actual labels recover the complete finite model, including zero padding. -/
theorem phase_label_coordinates {ι : Type*} [DecidableEq ι] {d : ℕ}
    (v : ι → ℤ) (live : Finset ι) (ρ : IntVec d →+ ℤ) (w : Fin d → ℕ)
    (U : Finset (IntVec d)) (hzero : 0 ∈ U)
    (hbox : ∀ x ∈ U, InCenteredBox w x)
    (himage : U.image ρ = insert 0 (live.image v))
    (hproper : Set.InjOn ρ (integerBudgetBox (fun j => 2*w j))) :
    let z := phaseLabelCoordinates ρ w v
    (∀ i ∈ live, z i ∈ U ∧ ρ (z i) = v i) ∧ insert 0 (live.image z) = U ∧
      labelSpan ℝ (fun i => realVector (z i)) live = labelSpan ℝ realVector U := by
  let z := phaseLabelCoordinates ρ w v
  have hz : ∀ i ∈ live, z i ∈ U ∧ ρ (z i) = v i := by
    intro i hi
    have hv : v i ∈ U.image ρ := by rw [himage]; exact Finset.mem_insert_of_mem (Finset.mem_image_of_mem v hi)
    obtain ⟨x, hx, he⟩ := Finset.mem_image.mp hv
    have hcoord : z i = x := by
      dsimp only [z, phaseLabelCoordinates]
      rw [← he]
      exact phase_coordinate_inverse ρ w hproper x (hbox x hx)
    exact ⟨hcoord ▸ hx, by rw [hcoord, he]⟩
  have he : insert 0 (live.image z) = U := by
    ext x
    constructor
    · intro hx
      rcases Finset.mem_insert.mp hx with rfl | hx
      · exact hzero
      · obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hx
        exact (hz i hi).1
    · intro hx
      have hm : ρ x ∈ insert 0 (live.image v) := by rw [← himage]; exact Finset.mem_image_of_mem ρ hx
      rcases Finset.mem_insert.mp hm with hm | hm
      · have hcoord := phase_coordinate_inverse ρ w hproper x (hbox x hx)
        rw [hm, integerProgressionCoordinates_zero ρ w hproper] at hcoord
        exact Finset.mem_insert.mpr (Or.inl hcoord.symm)
      · obtain ⟨i, hi, hiv⟩ := Finset.mem_image.mp hm
        apply Finset.mem_insert_of_mem
        refine Finset.mem_image.mpr ⟨i, hi, ?_⟩
        dsimp only [z, phaseLabelCoordinates]
        rw [hiv]
        exact phase_coordinate_inverse ρ w hproper x (hbox x hx)
  refine ⟨hz, he, ?_⟩
  rw [← he]
  simp only [labelSpan, Finset.coe_insert, Finset.coe_image, Set.image_insert_eq,
    Set.image_image, map_zero, Submodule.span_insert_zero]
  rfl

/-- A scalar live support is the homomorphic image of a subset of the actual
signed coordinate support; its repeated cardinality can only be smaller. -/
theorem phase_remaining_card_le_signed {ι : Type*} [DecidableEq ι] {d : ℕ}
    (v : ι → ℤ) (z : ι → IntVec d) (live : Finset ι) (ρ : IntVec d →+ ℤ)
    (hrepr : ∀ i ∈ live, ρ (z i) = v i) (h : ℕ) :
    (h • insert 0 (live.image v)).card ≤ (h • signedAlphabet (fun i : live => z i)).card := by
  have hsub : insert 0 (live.image v) ⊆ (signedAlphabet (fun i : live => z i)).image ρ := by
    intro x hx
    rcases Finset.mem_insert.mp hx with rfl | hx
    · exact Finset.mem_image.mpr ⟨0, zero_mem_signedAlphabet _, map_zero _⟩
    · obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hx
      exact Finset.mem_image.mpr ⟨z i, mem_signedAlphabet_pos (fun i : live => z i) ⟨i, hi⟩, hrepr i hi⟩
  have hsub' := Finset.nsmul_subset_nsmul hsub
    (show (0 : ℤ) ∈ (signedAlphabet (fun i : live => z i)).image ρ from
      Finset.mem_image.mpr ⟨0, zero_mem_signedAlphabet _, map_zero _⟩) (le_refl h)
  apply (Finset.card_le_card hsub').trans
  rw [← Finset.image_nsmul]
  exact Finset.card_image_le

/-- The basis-protection phase is a verified alternative for the actual
recursive packing routine. Failure halves the original scalar potential,
whereas success protects full rank after every allowed deletion. -/
theorem phase_basis_protection {ι : Type*} [DecidableEq ι] {d : ℕ}
    (v : ι → ℤ) (z : ι → IntVec d) (live : Finset ι) (ρ : IntVec d →+ ℤ)
    (hrepr : ∀ i ∈ live, ρ (z i) = v i)
    (w : Fin d → ℕ) (hw : ∀ j, 1 ≤ w j) (hbox : ∀ i ∈ live, InCenteredBox w (z i))
    (hfull : labelSpan ℝ (fun i => realVector (z i)) live = ⊤)
    (h k : ℕ) (C : ℝ) (hC : 2*C < (2*h+1 : ℕ))
    (hvolume : ((integerBudgetBox (fun j => h*w j)).card : ℝ) ≤
      C*(h • insert 0 (live.image v)).card) :
    let bs := packLabelBases (fun i => realVector (z i))
      (labelSpan ℝ (fun i => realVector (z i)) live) live (k+1)
    (bs.length = k+1 ∧ ∀ deleted : Finset ι, deleted.card ≤ k →
      labelSpan ℝ (fun i => realVector (z i)) (live \ deleted) = ⊤) ∨
    (bs.length ≤ k ∧ packedLabels bs ⊆ live ∧ (packedLabels bs).card ≤ d*k ∧
      2*(h • insert 0 ((live \ packedLabels bs).image v)).card <
        (h • insert 0 (live.image v)).card) := by
  let bs := packLabelBases (fun i => realVector (z i))
    (labelSpan ℝ (fun i => realVector (z i)) live) live (k+1)
  have hlen := (packLabelBases_spec (fun i => realVector (z i))
    (labelSpan ℝ (fun i => realVector (z i)) live) live (k+1)).1
  by_cases hsuccess : bs.length = k+1
  · refine Or.inl ⟨hsuccess, ?_⟩
    intro deleted hd
    obtain ⟨_, _, _, _, hs⟩ := packLabelBases_success (K := ℝ)
      (fun i => realVector (z i)) live k hsuccess deleted hd
    exact hs.trans hfull
  · have hshort : bs.length < k+1 := lt_of_le_of_ne hlen hsuccess
    obtain ⟨hsub, _, _, _, _⟩ := packLabelBases_failure (K := ℝ)
      (fun i => realVector (z i)) live k hshort
    have hpos : 0 < (h • insert 0 (live.image v)).card :=
      Finset.card_pos.mpr ⟨0, Finset.zero_mem_nsmul (Finset.mem_insert_self _ _)⟩
    obtain ⟨hsize, hhalf⟩ := packLabelBases_failure_halves_potential z live k hfull hshort w hw hbox h
      (h • insert 0 (live.image v)).card C hpos hC
      (by simpa only [integerBudgetBox_card, mul_assoc] using hvolume)
    have hcompare := phase_remaining_card_le_signed v z (live \ packedLabels bs) ρ
      (fun i hi => hrepr i (Finset.mem_sdiff.mp hi).1) h
    exact Or.inr ⟨Nat.lt_succ_iff.mp hshort, hsub, hsize, (Nat.mul_le_mul_left 2 hcompare).trans_lt hhalf⟩

end
end Optss
