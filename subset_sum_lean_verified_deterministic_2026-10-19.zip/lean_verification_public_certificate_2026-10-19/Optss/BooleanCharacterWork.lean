import Optss.BooleanPhaseWork
import Optss.ScalarOutputWork

/-! Preparation of one Fourier character has a polynomial gate/list bound
in the modulus bit length and requested precision. -/
namespace Optss
set_option maxRecDepth 4096
set_option maxHeartbeats 800000

def characterWorkBits (N p : ℕ) : ℕ := 8192*(N.size+p+70)^4

theorem characterWorkBits_bounds (N p : ℕ) :
    phaseWorkBits N p≤characterWorkBits N p ∧
      taylorWorkBits (fourierPhaseHeight N p) (68+p)≤characterWorkBits N p := by
  let Z := N.size+p+70
  have hZ : 1≤Z := by dsimp [Z]; omega
  have hsquare : Z≤Z^2 := by simpa only [pow_two,one_mul] using Nat.mul_le_mul_right Z hZ
  have hpow : Z^2≤Z^4 := Nat.pow_le_pow_right hZ (by omega)
  have hphase := fourierPhaseHeight_bits_polynomial N p
  have hdegree : (68+p+1)^2≤Z^2 := Nat.pow_le_pow_left (by dsimp [Z]; omega) 2
  have hinside : (fourierPhaseHeight N p).size+(68+p)+3≤70*Z^2 := by
    change (fourierPhaseHeight N p).size≤68*Z^2 at hphase
    have hp : 68+p+3≤2*Z := by dsimp [Z]; omega
    omega
  constructor
  · exact Nat.mul_le_mul_left 8192 hpow
  · change (68+p+1)^2*((fourierPhaseHeight N p).size+(68+p)+3)≤8192*Z^4
    calc
      _≤Z^2*(70*Z^2) := Nat.mul_le_mul hdegree hinside
      _=70*Z^4 := by ring
      _≤8192*Z^4 := by omega

theorem bitRationalCharacterWork_bound {N : ℕ} [NeZero N] (x : ZMod N)
    (X M : FourierFraction) (hX : X.value=(x.val : ℚ)) (hM : M.value=(N : ℚ)) (p : ℕ) :
    bitRationalCharacterWork X M p≤
      1048576*(N.size+p+70)^2*(characterWorkBits N p+1)^3 := by
  let Z := N.size+p+70
  let V := (characterWorkBits N p+1)^3
  have ht : RationalSizeBound (bitFourierPhaseAngle X M p).value (fourierPhaseHeight N p) := by
    rw [bitFourierPhaseAngle_value,hX,hM]
    exact rationalPhaseAngle_height x p
  have hphase := bitFourierPhaseAngleWork_bound x X M hX hM p
  have htaylor := bitImaginaryExpPartialWork_bound (bitFourierPhaseAngle X M p)
    (fourierPhaseHeight N p) (68+p) ht
  have hsmall : (p+3)^2≤Z^2 := Nat.pow_le_pow_left (by dsimp [Z]; omega) 2
  have hbig : (68+p+1)^2≤Z^2 := Nat.pow_le_pow_left (by dsimp [Z]; omega) 2
  have hphase' : bitFourierPhaseAngleWork X M p≤524288*Z^2*V := hphase.trans
    (Nat.mul_le_mul (Nat.mul_le_mul_left _ hsmall)
      (Nat.pow_le_pow_left (Nat.add_le_add_right (characterWorkBits_bounds N p).1 1) 3))
  have htaylor' : bitImaginaryExpPartialWork (bitFourierPhaseAngle X M p) (68+p)≤32768*Z^2*V := htaylor.trans
    (Nat.mul_le_mul (Nat.mul_le_mul_left _ hbig)
      (Nat.pow_le_pow_left (Nat.add_le_add_right (characterWorkBits_bounds N p).2 1) 3))
  have hZ : 0<Z := by dsimp [Z]; omega
  have hV : 0<V := Nat.pow_pos (Nat.succ_pos _)
  have hpos : 0<Z^2*V := Nat.mul_pos (Nat.pow_pos hZ) hV
  change bitFourierPhaseAngleWork X M p+
    bitImaginaryExpPartialWork (bitFourierPhaseAngle X M p) (68+p)+1≤1048576*Z^2*V
  nlinarith only [hphase',htaylor',hpos]

theorem bitFourierRoundedFractionWork_bound (q : FourierFraction) (L : ℕ)
    (hq : RationalBitBound q.value L) :
    bitFourierRoundedFractionWork q≤131074*(L+1)^3 := by
  have h := bitListFractionRoundCost_bound q.val q.property.2.2.1 L (q.width_of_bitBound L hq)
  have hl := bitListFractionRound_output_le_cost q.val
  unfold bitFourierRoundedFractionWork
  rw [bitListTrimVisits_eq]
  have hp : 0<(L+1)^3 := by positivity
  omega


theorem bitDyadicCharacterWork_bound {N : ℕ} [NeZero N] (x : ZMod N)
    (X M : FourierFraction) (hX : X.value=(x.val : ℚ)) (hM : M.value=(N : ℚ)) (p : ℕ) :
    bitDyadicCharacterWork X M p≤
      4194304*(N.size+p+72)^2*(characterWorkBits N (p+2)+1)^3 := by
  let Z := N.size+p+72
  let L := characterWorkBits N (p+2)
  let V := (L+1)^3
  let q := bitRationalCharacter X M (p+2)
  let D := bitFourierDyadicDenominator p
  let H := imaginaryPartialHeight (fourierPhaseHeight N (p+2)) (68+(p+2))
  have heq := bitRationalCharacter_value x X M hX hM (p+2)
  have hre := congrArg Prod.fst heq
  have him := congrArg Prod.snd heq
  dsimp only at hre him
  have hqheight := rationalCharacterApproximation_height x (p+2)
  have hqr : RationalSizeBound q.1.value H := by rw [hre]; exact hqheight.1
  have hqi : RationalSizeBound q.2.value H := by rw [him]; exact hqheight.2
  have hD : RationalSizeBound D.value (dyadicFourierDenominator p) := by
    rw [bitFourierDyadicDenominator_value]
    exact RationalSizeBound.natCast _ _ (dyadicFourierDenominator_pos p) le_rfl
  have hH : H.size≤128*Z^4 := by
    simpa only [fourierPreparationBits,show N.size+(p+2)+70=Z by dsimp [Z]; omega] using
      characterPartialHeight_bits_polynomial N (p+2)
  have hDsize : (dyadicFourierDenominator p).size=p+3 := by
    simp only [dyadicFourierDenominator,Nat.size_pow]
  have hpZ : p+72≤Z := by dsimp [Z]; omega
  have hZ : 1≤Z := by omega
  have hZpow : Z≤Z^4 := by
    simpa only [pow_one] using Nat.pow_le_pow_right hZ (by omega : 1≤4)
  have hL : L=8192*Z^4 := by dsimp only [L,characterWorkBits,Z]; congr 2
  have hHbits : H.size≤L := by rw [hL]; omega
  have hDbits : (dyadicFourierDenominator p).size≤L := by rw [hDsize,hL]; omega
  have hprodBits : (dyadicFourierDenominator p*H).size≤L := by
    have h := nat_mul_size_le (dyadicFourierDenominator p) H
    rw [hDsize] at h
    rw [hL]
    omega
  have hDr := hD.bitBound.mono hDbits
  have hqrBits := hqr.bitBound.mono hHbits
  have hqiBits := hqi.bitBound.mono hHbits
  have hmulr := D.mulWork_bound q.1 L hDr hqrBits
  have hmuli := D.mulWork_bound q.2 L hDr hqiBits
  have hrproduct : RationalBitBound (D.mul q.1).value L := by
    rw [FourierFraction.mul_value]; exact (hD.mul hqr).bitBound.mono hprodBits
  have hiproduct : RationalBitBound (D.mul q.2).value L := by
    rw [FourierFraction.mul_value]; exact (hD.mul hqi).bitBound.mono hprodBits
  have hroundr := bitFourierRoundedFractionWork_bound (D.mul q.1) L hrproduct
  have hroundi := bitFourierRoundedFractionWork_bound (D.mul q.2) L hiproduct
  have hchar := bitRationalCharacterWork_bound x X M hX hM (p+2)
  have hchar' : bitRationalCharacterWork X M (p+2)≤1048576*Z^2*V := by
    simpa only [show N.size+(p+2)+70=Z by dsimp [Z]; omega] using hchar
  have hV : 1≤V := Nat.one_le_pow 3 (L+1) (by omega)
  have hscale : V≤Z^2*V := Nat.le_mul_of_pos_left _ (Nat.pow_pos (by omega))
  have hscaleZ : Z^2≤Z^2*V := Nat.le_mul_of_pos_right _ (by omega)
  have hconst : 2*(p+3)+5≤Z^2*V := by
    have h : 2*(p+3)+5≤Z^2 := by nlinarith only [hpZ]
    exact h.trans hscaleZ
  change bitRationalCharacterWork X M (p+2)+2*(p+3)+4+
    bitListFractionMulCost D.val q.1.val+bitListFractionMulCost D.val q.2.val+
    bitFourierRoundedFractionWork (D.mul q.1)+bitFourierRoundedFractionWork (D.mul q.2)+1≤4194304*Z^2*V
  change _≤2048*V at hmulr hmuli
  change _≤131074*V at hroundr hroundi
  nlinarith only [hchar',hmulr,hmuli,hroundr,hroundi,hscale,hconst]


theorem bitModularDyadicCharacterWork_bound {N : ℕ} [NeZero N] (as ms : List Bool)
    (hM : binaryDigitsValue ms=N) (p : ℕ) :
    bitModularDyadicCharacterWork as ms p≤16*(as.length+1)*(ms.length+1)+2*ms.length+8+
      4194304*(N.size+p+72)^2*(characterWorkBits N (p+2)+1)^3 := by
  have hpos : 0<binaryDigitsValue ms := by rw [hM]; exact NeZero.pos N
  have h := bitDyadicCharacterWork_bound ((binaryDigitsValue as : ℕ) : ZMod N)
    (FourierFraction.ofNatDigits (bitListDivision as ms).remainder) (FourierFraction.ofNatDigits ms)
    (by rw [FourierFraction.ofNatDigits_value,(bitListDivision_correct as ms hpos).2,hM,ZMod.val_natCast])
    (by rw [FourierFraction.ofNatDigits_value,hM]) p
  have hdiv := bitListDivisionBitWork_bound as ms hpos
  have hrem := bitListDivisionDigits_remainder_width as ms hpos
  change (bitListDivision as ms).remainder.length ≤ ms.length at hrem
  unfold bitModularDyadicCharacterWork
  dsimp only
  rw [bitListTrimVisits_eq,bitListTrimVisits_eq]
  omega

end Optss
