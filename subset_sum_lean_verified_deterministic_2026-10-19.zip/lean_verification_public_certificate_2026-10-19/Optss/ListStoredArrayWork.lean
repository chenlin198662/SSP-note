import Optss.BooleanListArrayWork
import Optss.ListStoredReductionLoop

/-!
# Explicit work for nested list-backed matrix access

Scalar copiers physically copy the Boolean payloads. Matrix lookup copies the
selected row and then its selected scalar; row replacement copies all retained
rows. The bounds include the Boolean address construction and traversal work.
-/
namespace Optss
variable {r d : ℕ}

/-- Boolean payload size; sign and record fields cost a constant separately. -/
def fractionPayload (q : BitListFraction) : ℕ := q.numerator.length+q.denominator.length
def integerPayload (z : BitListInteger) : ℕ := z.digits.length

def listCopyFractionWork (q : BitListFraction) : ℕ :=
  bitWordCopyWork q.numerator+bitWordCopyWork q.denominator+1
def listCopyIntegerWork (z : BitListInteger) : ℕ := bitWordCopyWork z.digits+1

theorem listCopyFractionWork_eq (q : BitListFraction) :
    listCopyFractionWork q = 2*fractionPayload q+3 := by
  simp only [listCopyFractionWork,bitWordCopyWork_eq,fractionPayload]
  omega

theorem listCopyIntegerWork_eq (z : BitListInteger) :
    listCopyIntegerWork z = 2*integerPayload z+2 := by
  simp only [listCopyIntegerWork,bitWordCopyWork_eq,integerPayload]

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

namespace BooleanListArray

theorem forall_data_iff {α : Type*} {n : ℕ} (a : BooleanListArray α n) (P : α → Prop) :
    (∀ x ∈ a.data,P x) ↔ ∀ i : Fin n,P (a.toVector.get i) := by
  constructor
  · intro h i
    apply h
    simp only [toVector,get_ofFn]
    exact List.getElem_mem _
  · intro h x hx
    obtain ⟨i,hi,rfl⟩ := List.getElem_of_mem hx
    have hi' : i<n := by simpa only [a.length_eq] using hi
    simpa only [toVector,get_ofFn] using h ⟨i,hi'⟩

end BooleanListArray

/-- Work of the concrete nested lookup, including its deep row copy. -/
def listMatrixReadWork {α : Type*} (copy : α → α) (w : α → ℕ)
    (A : BooleanListArray (BooleanListArray α d) r) (i : Fin r) (j : Fin d) : ℕ :=
  A.readWork (BooleanListArray.copyWork w) i+
    (A.read (BooleanListArray.copy copy) i).readWork w j+1

/-- Work of persistent outer-array row replacement. -/
def listMatrixWriteWork {α : Type*} (w : α → ℕ)
    (A : BooleanListArray (BooleanListArray α d) r) (i : Fin r)
    (row : BooleanListArray α d) : ℕ := A.writeWork (BooleanListArray.copyWork w) i row+1

/-- A common bound for either matrix read or matrix row replacement. -/
def listMatrixAccessBound (r d W : ℕ) : ℕ :=
  64*(r+1)^2*(d*(W+2)+2)+64*(d+1)^2*(W+1)+2

theorem listMatrixReadWork_le {α : Type*} (copy : α → α) (hc : ∀ x,copy x=x) (w : α → ℕ)
    (A : BooleanListArray (BooleanListArray α d) r) (i : Fin r) (j : Fin d) (W : ℕ)
    (hW : ∀ a b,w (((listMatrixVector A).get a).get b) ≤ W) :
    listMatrixReadWork copy w A i j ≤ listMatrixAccessBound r d W := by
  have hrows (row : BooleanListArray α d) (hr : row ∈ A.data) :
      ∀ x ∈ row.data,w x ≤ W := by
    obtain ⟨a,ha,rfl⟩ := List.getElem_of_mem hr
    have ha' : a<r := by simpa only [A.length_eq] using ha
    refine (BooleanListArray.forall_data_iff (A.data[a]) (fun x => w x ≤ W)).mpr ?_
    intro b
    simpa only [listMatrixVector,get_ofFn,BooleanListArray.toVector,get_ofFn] using hW ⟨a,ha'⟩ b
  have houter := A.readWork_le (BooleanListArray.copyWork w) i (d*(W+2)+1)
    (fun row hr => row.copyWork_le w W (hrows row hr))
  have hinner : (A.read (BooleanListArray.copy copy) i).readWork w j ≤ 64*(d+1)^2*(W+1) := by
    apply BooleanListArray.readWork_le
    refine (BooleanListArray.forall_data_iff (A.read (BooleanListArray.copy copy) i)
      (fun x => w x ≤ W)).mpr ?_
    intro b
    rw [BooleanListArray.read_toVector _ (BooleanListArray.copy_eq _ hc)]
    simpa only [listMatrixVector,get_ofFn] using hW i b
  unfold listMatrixReadWork listMatrixAccessBound
  nlinarith

theorem listMatrixWriteWork_le {α : Type*} (w : α → ℕ)
    (A : BooleanListArray (BooleanListArray α d) r) (i : Fin r)
    (row : BooleanListArray α d) (W : ℕ)
    (hW : ∀ a b,w (((listMatrixVector A).get a).get b) ≤ W)
    (hr : ∀ b,w (row.toVector.get b) ≤ W) :
    listMatrixWriteWork w A i row ≤ listMatrixAccessBound r d W := by
  have hrows (v : BooleanListArray α d) (hv : v ∈ A.data) :
      ∀ x ∈ v.data,w x ≤ W := by
    obtain ⟨a,ha,rfl⟩ := List.getElem_of_mem hv
    have ha' : a<r := by simpa only [A.length_eq] using ha
    refine (BooleanListArray.forall_data_iff (A.data[a]) (fun x => w x ≤ W)).mpr ?_
    intro b
    simpa only [listMatrixVector,get_ofFn,BooleanListArray.toVector,get_ofFn] using hW ⟨a,ha'⟩ b
  have hrow := row.copyWork_le w W ((BooleanListArray.forall_data_iff _ _).mpr hr)
  have houter := A.writeWork_le (BooleanListArray.copyWork w) i row (d*(W+2)+1) hrow
    (fun v hv => v.copyWork_le w W (hrows v hv))
  unfold listMatrixWriteWork listMatrixAccessBound
  nlinarith

theorem listMatrixAccessBound_mono (r d : ℕ) {W W' : ℕ} (h : W ≤ W') :
    listMatrixAccessBound r d W ≤ listMatrixAccessBound r d W' := by
  unfold listMatrixAccessBound
  gcongr

theorem listMatrixAccessBound_le (r d W : ℕ) :
    listMatrixAccessBound r d W ≤ 512*(r+d+1)^4*(W+1) := by
  have hr : r+1 ≤ r+d+1 := by omega
  have hd : d+1 ≤ r+d+1 := by omega
  have hd' : d ≤ r+d+1 := by omega
  have hp : 1 ≤ r+d+1 := by omega
  have ha : d*(W+2)+2 ≤ 2*(d+1)*(W+1) := by nlinarith
  have hb : (r+1)^2 ≤ (r+d+1)^2 := Nat.pow_le_pow_left hr 2
  have hc : (d+1)^2 ≤ (r+d+1)^2 := Nat.pow_le_pow_left hd 2
  have hleft : 64*(r+1)^2*(d*(W+2)+2) ≤ 128*(r+d+1)^3*(W+1) := by
    calc
      _ ≤ 64*(r+d+1)^2*(2*(r+d+1)*(W+1)) := by gcongr; exact ha.trans (by gcongr)
      _ = _ := by ring
  have hright : 64*(d+1)^2*(W+1) ≤ 64*(r+d+1)^3*(W+1) := by
    exact Nat.mul_le_mul_right (W+1) (Nat.mul_le_mul_left 64
      (hc.trans (Nat.pow_le_pow_right hp (by decide : (2:ℕ)≤3))))
  have hpow : (r+d+1)^3 ≤ (r+d+1)^4 := Nat.pow_le_pow_right hp (by omega)
  have hpos : 1 ≤ (r+d+1)^3 := one_le_pow₀ hp
  unfold listMatrixAccessBound
  nlinarith

end Optss
