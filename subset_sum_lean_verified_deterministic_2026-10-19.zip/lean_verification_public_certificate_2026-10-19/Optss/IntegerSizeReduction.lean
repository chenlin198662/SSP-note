import Optss.LatticeReduction

/-!
# Size reduction on actual integer matrices

The finite Gram-Schmidt rounding sweep is carried out on integer rows. Its
Euclidean interpretation is exactly the previously verified real sweep, while
every integer prefix Gram determinant is preserved. Applying this sweep to a
minimum-potential basis yields both size reduction and the adjacent determinant
condition in one actual basis of the original full integer lattice.
-/

namespace Optss
noncomputable section
open scoped BigOperators Matrix
variable {r d : ℕ}

/-- Integer rows embedded in Euclidean space with its `ℓ²` norm. -/
def euclideanIntegerRows (A : Matrix (Fin r) (Fin d) ℤ) :
    Fin r → EuclideanSpace ℝ (Fin d) := fun i => (WithLp.equiv 2 _).symm (fun j => (A i j:ℝ))

theorem euclideanIntegerRows_independent_iff (A : Matrix (Fin r) (Fin d) ℤ) :
    LinearIndependent ℝ (euclideanIntegerRows A) ↔
      LinearIndependent ℝ (fun i => fun j => (A i j:ℝ)) := by
  let e := PiLp.continuousLinearEquiv 2 ℝ (fun _ : Fin d => ℝ)
  exact (e.toLinearMap.linearIndependent_iff (v := euclideanIntegerRows A)
    (LinearMap.ker_eq_bot.mpr e.injective)).symm

/-- Integer and Euclidean size reduction are the same operation after casting. -/
theorem euclideanIntegerRows_reduceVector (A : Matrix (Fin r) (Fin d) ℤ)
    (j k : Fin r) (q : ℤ) :
    euclideanIntegerRows (reduceVector A j k q) =
      reduceVector (euclideanIntegerRows A) j k (q:ℝ) := by
  ext i l
  by_cases hi : i = k
  · subst i
    simp [euclideanIntegerRows, reduceVector, PiLp.sub_apply, PiLp.smul_apply]
  · simp [euclideanIntegerRows, reduceVector, hi]

/-- The descending nearest-integer sweep, maintaining integer rows throughout. -/
def roundReduceIntegerRow (A : Matrix (Fin r) (Fin d) ℤ) (k : Fin r)
    (n : ℕ) (h : n ≤ k.val) : Matrix (Fin r) (Fin d) ℤ :=
  match n with
  | 0 => A
  | n+1 =>
    let j : Fin r := ⟨n, by omega⟩
    let q : ℤ := round (gsCoefficient (euclideanIntegerRows A) k j)
    roundReduceIntegerRow (reduceVector A j k q) k n (by omega)
termination_by n

/-- The integer implementation realizes exactly the verified Euclidean sweep. -/
theorem euclideanIntegerRows_roundReduceIntegerRow (A : Matrix (Fin r) (Fin d) ℤ)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) :
    euclideanIntegerRows (roundReduceIntegerRow A k n h) =
      roundReduceRow (euclideanIntegerRows A) k n h := by
  induction n generalizing A with
  | zero => rw [roundReduceIntegerRow, roundReduceRow]
  | succ n ih =>
    rw [roundReduceIntegerRow, roundReduceRow, ih, euclideanIntegerRows_reduceVector]

/-- Every actual prefix Gram determinant is invariant through the complete
integer sweep of one row. -/
theorem prefixGramDet_roundReduceIntegerRow (A : Matrix (Fin r) (Fin d) ℤ)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) (t : Fin (r+1)) :
    prefixGramDet (roundReduceIntegerRow A k n h) t = prefixGramDet A t := by
  induction n generalizing A with
  | zero => rw [roundReduceIntegerRow]
  | succ n ih =>
    rw [roundReduceIntegerRow, ih]
    exact prefixGramDet_reduceVector _ _ k (by change n < k.val; omega) _ t

theorem integerSpan_roundReduceIntegerRow (A : Matrix (Fin r) (Fin d) ℤ)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) :
    Submodule.span ℤ (Set.range (roundReduceIntegerRow A k n h)) =
      Submodule.span ℤ (Set.range A) := by
  induction n generalizing A with
  | zero => rw [roundReduceIntegerRow]
  | succ n ih =>
    rw [roundReduceIntegerRow, ih]
    apply span_reduceVector
    intro he
    have he' := congrArg Fin.val he
    dsimp at he'
    omega

/-- Row-by-row size reduction represented entirely in integer arithmetic,
apart from choosing the nearest integer to a real Gram-Schmidt coefficient. -/
def roundReduceIntegerAll (A : Matrix (Fin r) (Fin d) ℤ)
    (n : ℕ) (h : n ≤ r) : Matrix (Fin r) (Fin d) ℤ :=
  match n with
  | 0 => A
  | n+1 =>
    let B := roundReduceIntegerAll A n (by omega)
    let k : Fin r := ⟨n, by omega⟩
    roundReduceIntegerRow B k n le_rfl
termination_by n

theorem euclideanIntegerRows_roundReduceIntegerAll (A : Matrix (Fin r) (Fin d) ℤ)
    (n : ℕ) (h : n ≤ r) :
    euclideanIntegerRows (roundReduceIntegerAll A n h) =
      roundReduceAll (euclideanIntegerRows A) n h := by
  induction n with
  | zero => rw [roundReduceIntegerAll, roundReduceAll]
  | succ n ih =>
    rw [roundReduceIntegerAll, roundReduceAll,
      euclideanIntegerRows_roundReduceIntegerRow, ih]

theorem prefixGramDet_roundReduceIntegerAll (A : Matrix (Fin r) (Fin d) ℤ)
    (n : ℕ) (h : n ≤ r) (t : Fin (r+1)) :
    prefixGramDet (roundReduceIntegerAll A n h) t = prefixGramDet A t := by
  induction n with
  | zero => rw [roundReduceIntegerAll]
  | succ n ih => rw [roundReduceIntegerAll, prefixGramDet_roundReduceIntegerRow, ih]

theorem gramPotential_roundReduceIntegerAll (A : Matrix (Fin r) (Fin d) ℤ)
    (n : ℕ) (h : n ≤ r) : gramPotential (roundReduceIntegerAll A n h) = gramPotential A := by
  unfold gramPotential
  apply Finset.prod_congr rfl
  intro t _
  rw [prefixGramDet_roundReduceIntegerAll]

theorem integerSpan_roundReduceIntegerAll (A : Matrix (Fin r) (Fin d) ℤ)
    (n : ℕ) (h : n ≤ r) :
    Submodule.span ℤ (Set.range (roundReduceIntegerAll A n h)) =
      Submodule.span ℤ (Set.range A) := by
  induction n with
  | zero => rw [roundReduceIntegerAll]
  | succ n ih => rw [roundReduceIntegerAll, integerSpan_roundReduceIntegerRow, ih]

/-- One actual basis simultaneously satisfies size reduction and the adjacent
prefix determinant test. The usual Gram-Schmidt Lovász formulation and the
orthogonality-defect estimate require the separate Gram determinant identity. -/
theorem exists_integer_determinant_reduced (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ))) :
    ∃ B : Matrix (Fin r) (Fin d) ℤ,
      Submodule.span ℤ (Set.range B) = Submodule.span ℤ (Set.range A) ∧
      LinearIndependent ℝ (fun i => fun j => (B i j:ℝ)) ∧
      (∀ k j : Fin r, j < k → |gsCoefficient (euclideanIntegerRows B) k j| ≤ 1/2) ∧
      (∀ j k : Fin r, k.val = j.val+1 →
        prefixGramDet B ⟨k.val, by omega⟩ ≤
          prefixGramDet (swapRows B j k) ⟨k.val, by omega⟩) := by
  obtain ⟨C, hspanC, hC, hminC⟩ := exists_minimum_gramPotential A hA
  let B := roundReduceIntegerAll C r le_rfl
  have hspan : Submodule.span ℤ (Set.range B) = Submodule.span ℤ (Set.range A) :=
    (integerSpan_roundReduceIntegerAll C r le_rfl).trans hspanC
  obtain ⟨hind, _, _, hsmall⟩ := roundReduceAll_spec (euclideanIntegerRows C)
    ((euclideanIntegerRows_independent_iff C).mpr hC) r le_rfl
  have hB : LinearIndependent ℝ (fun i => fun j => (B i j:ℝ)) := by
    apply (euclideanIntegerRows_independent_iff B).mp
    rw [euclideanIntegerRows_roundReduceIntegerAll]
    exact hind
  refine ⟨B, hspan, hB, ?_, ?_⟩
  · intro k j hjk
    rw [euclideanIntegerRows_roundReduceIntegerAll]
    exact hsmall k j k.isLt hjk
  · apply minimum_gramPotential_adjacent B hB
    intro D hDspan hD
    change gramPotential (roundReduceIntegerAll C r le_rfl) ≤ _
    rw [gramPotential_roundReduceIntegerAll]
    exact hminC D (hDspan.trans hspan) hD

end
end Optss
