import Optss.CommonWindowParameters
import Optss.CommonPhaseLogarithms

/-!
# The genuine common-GAP phase alternative

Actual basis packing is followed by the actual bounded greedy block sequence.
Failure removes boundedly many original labels and strictly halves the
original scalar potential. Success returns the filled, proper common reserve
and protected remainder, with one rank-uniform filling scale.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1800000

/-- A common-GAP decomposition, retaining its original labels and all witnesses. -/
structure CommonGapDecomposition {ι : Type} [DecidableEq ι] (scalar : ι → ℤ)
    (initial : Finset ι) (h extra R Ebound Rbound : ℕ) (c : ℝ) where
  rank : ℕ
  rank_le : rank ≤ R
  available : Finset ι
  reserve : Finset ι
  remaining : Finset ι
  available_subset : available ⊆ initial
  reserve_subset : reserve ⊆ available
  remaining_eq : remaining = available \ reserve
  outlier_bound : (initial \ available).card ≤ Ebound
  reserve_bound : reserve.card ≤ Rbound
  model : CommonReserveCoordinateModel rank scalar available reserve remaining h extra c

/-- Packing and actual greedy selection give the complete phase alternative.
All phase budgets are explicit finite quantities; no no-restart, density,
common-lattice, or final filling hypothesis is an input. -/
theorem actual_common_phase_outcome (η : ℝ) (hη : 0 < η) :
    ∃ a N₀ : ℕ, ∃ c : ℝ, 1 ≤ a ∧ 0 < c ∧
      ∀ (ι : Type) [LinearOrder ι] (scalar : ι → ℤ) (initial : Finset ι) (h : ℕ)
        (model : CommonGapLabelModel scalar initial h) (N R extra : ℕ) (C : ℝ),
        N₀ ≤ N → 1 ≤ N → 1 ≤ h → 0 < model.rank → model.rank ≤ R → 0 < C →
        (N : ℝ)^η ≤ h →
        (∀ i ∈ initial, scalar i ∈ Finset.Icc 0 (N : ℤ)) →
        let M := (h • insert 0 (initial.image scalar)).card
        4 ≤ M → M ≤ h*N+1 →
        ((integerBudgetBox (fun j => h*model.widths j)).card : ℝ) ≤ C*M →
        2*C < (2*h+1 : ℕ) →
        let K := commonPhaseBlockConstant R C c η a
        commonWindowWidthThreshold R K C ≤ 2*h+1 →
        let ℓ := commonWindowLength R K C
        let B := ⌈(latticeSeedCardBound model.rank model.widths : ℝ)+greedyProfileConstant c a η*h⌉₊
        let n := (Nat.log 2 (model.rank.factorial*∏ j, model.widths j)+1)*ℓ
        let k := n*B+extra
        (∃ next ⊆ initial, 2*(h • insert 0 (next.image scalar)).card < M ∧
          (initial \ next).card ≤ max 1 R*k) ∨
        Nonempty (CommonGapDecomposition scalar initial h extra R (max 1 R*k) (ℓ*B)
          (commonWindowScale R K C)) := by
  obtain ⟨a, N₀, c, ha, hc, hselector⟩ := actual_phase_block_selector η hη
  refine ⟨a, N₀, c, ha, hc, ?_⟩
  intro ι _ scalar initial h model N R extra C hN₀ hN hh hd hdR hC hscale hscalar M hM4 hM hvolume hprotect K hwidth ℓ B n k
  have hK : 1 ≤ K := le_max_left _ _
  obtain ⟨hℓ, hcuniform, hparameters⟩ := common_window_parameters R K hK C hC
  have hparameters' := hparameters model.rank hd hdR
  have hBK : max h B ≤ K*h :=
    common_phase_allocated_budget model.widths R h N M hdR hh hN η hη hscale hM C hC.le hvolume c a
  have hpack := phase_basis_protection scalar model.coordinates initial model.projection model.represents
    model.widths model.positive model.boxed model.fullRank h k C hprotect hvolume
  rcases hpack with ⟨hpack, hprotected⟩ | ⟨_, hsub, hsize, hhalf⟩
  · obtain ⟨F, _, hF⟩ := hselector ι scalar initial h model N M hN₀ hN hh hM4 hscale hM hscalar
    have halt := F.restart_or_dense_window scalar h M n ℓ k (Nat.le_add_right _ _)
      hprotected model.widths model.boxed le_rfl hF
    rcases halt with ⟨i, hi, hhalf, hdeleted⟩ | hwindow
    · apply Or.inl
      refine ⟨F.remaining (i+1), F.remaining_subset _, hhalf, hdeleted.trans ?_⟩
      have h1 : n*B ≤ k := Nat.le_add_right _ _
      exact h1.trans (by simpa only [one_mul] using Nat.mul_le_mul_right k (le_max_left 1 R))
    · obtain ⟨b, hb, hE, hR, _, _, _, ⟨coord⟩⟩ := F.dense_window_coordinate_model hd scalar model.projection
        model.represents model.widths model.boxed h M n ℓ k extra K hh hK hBK model.proper C hC hvolume
        le_rfl hprotected le_rfl hℓ hparameters'.1 (hparameters'.2.1.trans hwidth) hwindow
      apply Or.inr
      refine ⟨{
        rank := model.rank
        rank_le := hdR
        available := F.remaining (b*ℓ)
        reserve := F.reserve (b*ℓ) ℓ
        remaining := F.remaining (b*ℓ+ℓ)
        available_subset := F.remaining_subset _
        reserve_subset := F.reserve_subset _ _
        remaining_eq := F.remaining_after_reserve _ _
        outlier_bound := ?_
        reserve_bound := hR
        model := coord.shrink _ hparameters'.2.2 }⟩
      apply hE.trans
      have hn : Nat.log 2 (model.rank.factorial*∏ j, model.widths j)*ℓ*B ≤ n*B :=
        Nat.mul_le_mul_right B (Nat.mul_le_mul_right ℓ (Nat.le_succ _))
      exact hn.trans ((Nat.le_add_right (n*B) extra).trans
        (by simpa only [one_mul] using Nat.mul_le_mul_right k (le_max_left 1 R)))
  · apply Or.inl
    refine ⟨_, Finset.sdiff_subset, hhalf, ?_⟩
    have hs : (initial \ (initial \ packedLabels
        (packLabelBases (fun i => realVector (model.coordinates i))
          (labelSpan ℝ (fun i => realVector (model.coordinates i)) initial) initial (k+1)))).card ≤ model.rank*k := by
      apply (Finset.card_le_card ?_).trans hsize
      intro i hi
      simp only [Finset.mem_sdiff] at hi
      tauto
    exact hs.trans (Nat.mul_le_mul_right k (hdR.trans (le_max_right _ _)))

end
end Optss
