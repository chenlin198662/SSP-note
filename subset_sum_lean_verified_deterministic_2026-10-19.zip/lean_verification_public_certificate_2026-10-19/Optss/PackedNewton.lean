import Optss.IntegerConvolution
import Optss.CountPreparationBounds

/-!
# Packed arithmetic for the actual counted Newton recurrence

The prepared power entries and previously stored Newton coefficients have
explicit exponent and coefficient bounds. Consequently every product
coefficient read by a Newton update is exactly a padded, packed integer
convolution coefficient. The alternating signs are applied after extraction.
This is an arithmetic replacement theorem, not a fast-integer runtime claim.
-/

namespace Optss
open scoped BigOperators
noncomputable section

variable {ι : Type*} [Fintype ι] {d : ℕ}

/-- Monomial power coefficients are nonnegative and at most the total capacity,
even at power index zero when all exponents coincide. -/
theorem countPowerSum_monomial_coeff_bounds (c : ι → ℕ) (u : ι → Fin d →₀ ℕ)
    (l : ℕ) (e : Fin d →₀ ℕ) :
    0 ≤ (countPowerSum c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l).coeff e ∧
      (countPowerSum c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l).coeff e ≤
        (∑ i, c i : ℕ) := by
  classical
  rw [countPowerSum_monomial, MvPolynomial.coeff_sum]
  have hterm (i : ι) :
      0 ≤ (MvPolynomial.monomial (l • u i) (c i : ℤ)).coeff e ∧
        (MvPolynomial.monomial (l • u i) (c i : ℤ)).coeff e ≤ (c i : ℤ) := by
    simp only [MvPolynomial.coeff_monomial]
    split_ifs <;> constructor <;> omega
  refine ⟨Finset.sum_nonneg (fun i _ => (hterm i).1), ?_⟩
  exact (Finset.sum_le_sum (fun i _ => (hterm i).2)).trans_eq (by simp)

/-- Every actual prepared power entry is bounded by `kcap * V`, where the type
count and each capacity satisfy the established preprocessing bounds. -/
theorem countPowerTable_coeff_natAbs_le (Δ : Fin d →₀ ℕ) (c : ι → ℕ)
    (u : ι → Fin d →₀ ℕ) (kcap V l : ℕ)
    (hc : ∀ i, c i ≤ kcap) (hV : Fintype.card ι ≤ V) (hl : l ≤ kcap)
    (e : Fin d →₀ ℕ) :
    (((countPowerTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap).getD l 0).coeff e).natAbs ≤
      kcap * V := by
  classical
  rw [countPowerTable_getD _ _ _ _ _ hl,
    ← countPowerSum_eq_copies c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l,
    coeff_truncatePolynomial]
  split_ifs with he
  · obtain ⟨h0, hbound⟩ := countPowerSum_monomial_coeff_bounds c u l e
    have htotal := capped_total_le c kcap V hc hV
    have hcast : ((∑ i, c i : ℕ) : ℤ) ≤ (kcap * V : ℕ) := by exact_mod_cast htotal
    exact_mod_cast (show ((countPowerSum c
      (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l).coeff e).natAbs ≤ (kcap * V : ℕ) from by
        have h := hbound.trans hcast
        have hcabs : (((countPowerSum c
          (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l).coeff e).natAbs : ℤ) ≤ (kcap * V : ℕ) := by
          rw [Int.natCast_natAbs, abs_of_nonneg h0]
          exact h
        exact_mod_cast hcabs)
  · simp

/-- Prefix-table entries agree with the final stored table, without recomputation
or any assumption about the correct output value. -/
theorem countNewton_prefix_entry (Δ : Fin d →₀ ℕ) (c : ι → ℕ)
    (a : ι → MvPolynomial (Fin d) ℤ) (kcap n j : ℕ) (hn : n ≤ kcap) (hj : j ≤ n) :
    (newtonTable Δ (countPowerTable Δ c a kcap) n).getD j 0 =
      (countNewtonTable Δ c a kcap).getD j 0 := by
  rw [newtonTable_getD Δ (fun p : Σ i, Fin (c i) => a p.1) _ kcap
    (countPowerTable_getD Δ c a kcap) n hn j hj,
    countNewtonTable_getD Δ c a kcap j (hj.trans hn)]

/-- The product in a specific actual Newton update can be computed by the four
packed integer products with explicit bases from the proven coefficient bounds. -/
theorem packed_countNewton_factor (Δ : Fin d →₀ ℕ) (c : ι → ℕ)
    (u : ι → Fin d →₀ ℕ) (kcap V k l : ℕ)
    (hkcap : 0 < kcap) (hVpos : 0 < V)
    (hc : ∀ i, c i ≤ kcap) (hV : Fintype.card ι ≤ V)
    (hk : k ≤ kcap) (hl : l ∈ Finset.Icc 1 k)
    (e : Fin d →₀ ℕ) (he : e ≤ Δ) :
    let powers := countPowerTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap
    let previous := newtonTable Δ powers (k - 1)
    packedIntegerCoefficient Δ Δ (powers.getD l 0) (previous.getD (k-l) 0)
      (kcap * V) ((kcap * V) ^ kcap) e =
      (powers.getD l 0 * previous.getD (k-l) 0).coeff e := by
  dsimp only
  have hl' := Finset.mem_Icc.mp hl
  have hlcap : l ≤ kcap := hl'.2.trans hk
  have hprev : k - l ≤ k - 1 := by omega
  have hncap : k - 1 ≤ kcap := by omega
  apply packedIntegerCoefficient_eq
  · rw [countPowerTable_getD _ _ _ _ _ hlcap]
    exact truncatePolynomial_inBox _ _
  · rw [countNewton_prefix_entry _ _ _ _ _ _ hncap hprev,
      countNewtonTable_getD _ _ _ _ _ (by omega)]
    exact truncatePolynomial_inBox _ _
  · exact countPowerTable_coeff_natAbs_le Δ c u kcap V l hc hV hlcap
  · intro a
    rw [countNewton_prefix_entry _ _ _ _ _ _ hncap hprev]
    obtain ⟨h0, hbound⟩ := countNewtonTable_coeff_bound c u Δ a kcap V (k-l)
      hkcap hVpos hc hV (by omega)
    have hcast : (((countNewtonTable Δ c
      (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap).getD (k-l) 0).coeff a).natAbs ≤
        (kcap * V) ^ kcap := by
      exact_mod_cast (show ((((countNewtonTable Δ c
        (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap).getD (k-l) 0).coeff a).natAbs : ℤ) ≤
          ((kcap * V : ℕ) : ℤ) ^ kcap by
            rw [Int.natCast_natAbs, abs_of_nonneg h0]
            exact hbound)
    exact hcast
  · intro j
    exact (he j).trans (Nat.le_add_right _ _)

/-- Integer arithmetic numerator: each polynomial product coefficient is replaced
by its exact padded packing and digit extraction. -/
def packedCountNewtonNumerator (Δ : Fin d →₀ ℕ) (c : ι → ℕ)
    (u : ι → Fin d →₀ ℕ) (kcap V k : ℕ) (e : Fin d →₀ ℕ) : ℤ :=
  let powers := countPowerTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap
  let previous := newtonTable Δ powers (k - 1)
  ∑ l ∈ Finset.Icc 1 k, (-1 : ℤ) ^ (l - 1) *
    packedIntegerCoefficient Δ Δ (powers.getD l 0) (previous.getD (k-l) 0)
      (kcap * V) ((kcap * V) ^ kcap) e

/-- The packed numerator is exactly the coefficient of the actual truncated
Newton numerator. It includes every alternating sign and every prepared-table lookup. -/
theorem packedCountNewtonNumerator_eq (Δ : Fin d →₀ ℕ) (c : ι → ℕ)
    (u : ι → Fin d →₀ ℕ) (kcap V k : ℕ)
    (hkcap : 0 < kcap) (hVpos : 0 < V)
    (hc : ∀ i, c i ≤ kcap) (hV : Fintype.card ι ≤ V) (hk : k ≤ kcap)
    (e : Fin d →₀ ℕ) (he : e ≤ Δ) :
    let powers := countPowerTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap
    let previous := newtonTable Δ powers (k - 1)
    packedCountNewtonNumerator Δ c u kcap V k e =
      (truncatePolynomial Δ (∑ l ∈ Finset.Icc 1 k,
        (-1 : MvPolynomial (Fin d) ℤ) ^ (l-1) * powers.getD l 0 * previous.getD (k-l) 0)).coeff e := by
  dsimp only
  rw [coeff_truncatePolynomial, if_pos he, MvPolynomial.coeff_sum]
  unfold packedCountNewtonNumerator
  dsimp only
  apply Finset.sum_congr rfl
  intro l hl
  rw [packed_countNewton_factor Δ c u kcap V k l hkcap hVpos hc hV hk hl e he]
  have hsign : (-1 : MvPolynomial (Fin d) ℤ) ^ (l-1) = MvPolynomial.C ((-1 : ℤ) ^ (l-1)) := by simp
  rw [hsign, mul_assoc, MvPolynomial.coeff_C_mul]

/-- The actual stored update uses the packed numerator with the same exact
integer division by its cardinality index. -/
theorem newtonTableStep_coeff_eq_packed (Δ : Fin d →₀ ℕ) (c : ι → ℕ)
    (u : ι → Fin d →₀ ℕ) (kcap V k : ℕ)
    (hkcap : 0 < kcap) (hVpos : 0 < V)
    (hc : ∀ i, c i ≤ kcap) (hV : Fintype.card ι ≤ V) (hk : k ≤ kcap)
    (e : Fin d →₀ ℕ) (he : e ≤ Δ) :
    let powers := countPowerTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap
    (newtonTableStep Δ powers (newtonTable Δ powers (k-1)) k).coeff e =
      packedCountNewtonNumerator Δ c u kcap V k e / (k : ℤ) := by
  dsimp only
  unfold newtonTableStep
  change (truncatePolynomial Δ _).coeff e / (k : ℤ) = _
  rw [← packedCountNewtonNumerator_eq Δ c u kcap V k hkcap hVpos hc hV hk e he]

/-- The packed integer numerator is exactly divisible by the Newton index;
its quotient is the coefficient of the actual stored table entry. -/
theorem packedCountNewtonNumerator_eq_index_mul (Δ : Fin d →₀ ℕ) (c : ι → ℕ)
    (u : ι → Fin d →₀ ℕ) (kcap V k : ℕ)
    (hkcap : 0 < kcap) (hVpos : 0 < V)
    (hc : ∀ i, c i ≤ kcap) (hV : Fintype.card ι ≤ V) (hk : k ≤ kcap)
    (e : Fin d →₀ ℕ) (he : e ≤ Δ) :
    packedCountNewtonNumerator Δ c u kcap V k e = (k : ℤ) *
      ((countNewtonTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap).getD k 0).coeff e := by
  rw [packedCountNewtonNumerator_eq Δ c u kcap V k hkcap hVpos hc hV hk e he]
  let a : ι → MvPolynomial (Fin d) ℤ := fun i => MvPolynomial.monomial (u i) (1 : ℤ)
  have hsum :
      (∑ l ∈ Finset.Icc 1 k, (-1 : MvPolynomial (Fin d) ℤ) ^ (l-1) *
        (countPowerTable Δ c a kcap).getD l 0 *
        (newtonTable Δ (countPowerTable Δ c a kcap) (k-1)).getD (k-l) 0) =
      ∑ l ∈ Finset.Icc 1 k, (-1 : MvPolynomial (Fin d) ℤ) ^ (l-1) *
        truncatePolynomial Δ (powerSum (fun p : Σ i, Fin (c i) => a p.1) l) *
        truncatePolynomial Δ (elementaryCoefficient (fun p : Σ i, Fin (c i) => a p.1) (k-l)) := by
    apply Finset.sum_congr rfl
    intro l hl
    have hli := Finset.mem_Icc.mp hl
    rw [countPowerTable_getD Δ c a kcap l (by omega),
      newtonTable_getD Δ (fun p : Σ i, Fin (c i) => a p.1) _ kcap
        (countPowerTable_getD Δ c a kcap) (k-1) (by omega) (k-l) (by omega)]
  change (truncatePolynomial Δ _).coeff e = _
  rw [hsum, truncated_newton_recurrence, MvPolynomial.coeff_C_mul,
    countNewtonTable_getD _ _ _ _ _ hk]

/-- Exact division of the packed numerator recovers the stored coefficient,
not just its sign or Boolean support. -/
theorem countNewtonTable_coeff_eq_packed (Δ : Fin d →₀ ℕ) (c : ι → ℕ)
    (u : ι → Fin d →₀ ℕ) (kcap V k : ℕ)
    (hkcap : 0 < kcap) (hVpos : 0 < V)
    (hc : ∀ i, c i ≤ kcap) (hV : Fintype.card ι ≤ V) (hk : k ≤ kcap) (hkpos : 0 < k)
    (e : Fin d →₀ ℕ) (he : e ≤ Δ) :
    ((countNewtonTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap).getD k 0).coeff e =
      packedCountNewtonNumerator Δ c u kcap V k e / (k : ℤ) := by
  rw [packedCountNewtonNumerator_eq_index_mul Δ c u kcap V k hkcap hVpos hc hV hk e he]
  exact (Int.mul_ediv_cancel_left _ (by exact_mod_cast Nat.ne_of_gt hkpos)).symm

/-- Specialization to the actual preprocessed live orthant computation. Distinct
input vectors discharge the type-volume hypothesis, and capacity preprocessing
discharges every coefficient-bound premise of the packed update. -/
theorem live_newtonTableStep_coeff_eq_packed (v : ι → IntVec d) (hinj : Function.Injective v)
    (c : ι → ℕ) (Δ e : Fin d →₀ ℕ) (kcap k : ℕ)
    (hkcap : 0 < kcap) (hk : k ≤ kcap) (he : e ≤ Δ) (ε : Fin d → Bool) :
    (newtonTableStep Δ (liveOrthantPowerTable v c Δ kcap ε)
      (newtonTable Δ (liveOrthantPowerTable v c Δ kcap ε) (k-1)) k).coeff e =
      packedCountNewtonNumerator Δ (liveCorrectionCount v c Δ kcap ε)
        (fun i => absoluteExponent (v i.val.val)) kcap (∏ j, (Δ j + 1)) k e / (k : ℤ) := by
  have h := newtonTableStep_coeff_eq_packed Δ (liveCorrectionCount v c Δ kcap ε)
    (fun i => absoluteExponent (v i.val.val)) kcap (∏ j, (Δ j + 1)) k
    hkcap (Finset.prod_pos (fun j _ => Nat.succ_pos _))
    (fun i => (liveCorrectionCount_pos_le v c Δ kcap ε i).2)
    (liveCorrectionOrthant_card_le v hinj c Δ kcap ε) hk e he
  simpa only [liveOrthantPowerTable, monomialPowerTable_eq] using h

end
end Optss
