import Optss.BooleanLatticeBox
import Optss.ComputedBasisFloorWidths
import Optss.ExactThinLatticeWidths

/-!
# Constructing the lattice-point box of a thin rational body

The input body need only span real space. No independent lattice points in
the body are assumed. Actual reduced columns and actual floor widths retain
every lattice point, with the dimension-only dilation needed to shrink the
box into the body in the next step.
-/
namespace Optss
open scoped BigOperators Pointwise
variable {r m : ℕ}

def booleanThinLatticeBoxFinish (V : ListBitRationalMatrixData r m)
    (out : BooleanLatticeFrontendResult r m) : BooleanLatticeBoxResult r :=
  let B := booleanLatticePullback out.selectedColumns out.reducedLatticeRows
  ⟨B,computedBasisFloorWidths B V⟩

def booleanThinLatticeBoxFinishWork (V : ListBitRationalMatrixData r m)
    (out : BooleanLatticeFrontendResult r m) : ℕ :=
  let B := booleanLatticePullback out.selectedColumns out.reducedLatticeRows
  booleanLatticePullbackWork out.selectedColumns out.reducedLatticeRows+computedBasisFloorWidthsWork B V+1

def booleanThinLatticeBox (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r) :
    Option (BooleanLatticeBoxResult r) :=
  (booleanLatticeFrontend V G).map (booleanThinLatticeBoxFinish V)

def booleanThinLatticeBoxWork (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r) : ℕ :=
  booleanLatticeFrontendWork V G+(match booleanLatticeFrontend V G with
    | none => 1
    | some out => booleanThinLatticeBoxFinishWork V out+1)

theorem booleanThinLatticeBox_spec (hr : 0<r)
    (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetG : (storedRationalMatrix G).det≠0)
    (hsym : ∀ y∈rationalVertexSet (storedRationalVertices V),-y∈rationalVertexSet (storedRationalVertices V))
    (hspan : Submodule.span ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))=⊤) :
    ∃ box,booleanThinLatticeBox V G=some box ∧
      ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
        (∀ i j,(storedRationalMatrix box.columns i j:ℝ)=b j i) ∧
        basisIntegerLattice b=(Submodule.span ℤ (Set.range (fun j i => (storedRationalMatrix G i j:ℝ))) : Set _) ∧
        (∀ j,BitListCanonical (box.widths.toVector.get j)) ∧
        (∀ x∈storedVertexHull V,x∈basisIntegerLattice b →
          x∈basisCoefficientBox b (decodedLatticeBoxWidths box)) ∧
        basisCoefficientBox b (decodedLatticeBoxWidths box) ⊆
          latticeBoxingDilation r ((r.factorial:ℝ)*sharpLatticeDefectBound r) • storedVertexHull V ∧
        (storedVertexHull V).Nonempty ∧
        (∀ i j,(rectangularListFractionMatrix box.columns i j).WellFormed) := by
  classical
  let S := rationalVertexSet (storedRationalVertices V)
  let K := convexHull ℝ (S : Set (Fin r → ℝ))
  obtain ⟨A,hselected,a,hacols,hinner,houter,_⟩ := bitSelectedVertexMatrix_normalization hr V hV hspan hsym
  have hA := bitSelectedVertexMatrix_wellFormed V hV A hselected
  have hdetA := (rational_basis_inverse a (storedRationalMatrix A) hacols).1
  let out := booleanLatticeFrontendFromBasis A V G
  have hout : booleanLatticeFrontend V G=some out := by rw [booleanLatticeFrontend,hselected]; rfl
  have hR := (booleanLatticeFrontendFromBasis_wellFormed A V G hA hV hG hdetA hdetG).2.2.2
  obtain ⟨hRspan,reduced,hreduced,hdefect⟩ := booleanLatticeFrontendFromBasis_reduction A V G hA hG hdetA hdetG
  obtain ⟨b,hbcols,hbmap,hbΛ⟩ := booleanLatticePullback_basis A out.reducedLatticeRows (storedRationalMatrix G)
    hA hR a hacols reduced hreduced hRspan
  let B := booleanLatticePullback A out.reducedLatticeRows
  let box := booleanThinLatticeBoxFinish V out
  have hB : ∀ i j,(rectangularListFractionMatrix B i j).WellFormed :=
    constructedListMatrixMul_wellFormed A _ hA (listStoredMatrixTranspose_wellFormed _ hR)
  have hK : IsCompact K := S.finite_toSet.isCompact_convexHull
  obtain ⟨u,_⟩ := exists_vertex_tuple_det_ne_zero (storedRationalVertices V) hspan
  have hm : 0<m := lt_of_le_of_lt (Nat.zero_le _) (u ⟨0,hr⟩).isLt
  have hne : K.Nonempty := ⟨realVertex (storedRationalVertices V) ⟨0,hm⟩,
    subset_convexHull ℝ _ ((mem_rationalVertexSet _ _).mpr ⟨⟨0,hm⟩,rfl⟩)⟩
  have hwidth : decodedLatticeBoxWidths box=basisFloorWidth b K hK hne := by
    funext j
    exact computedBasisFloorWidths_eq_basisFloorWidth b B V hB hV hbcols hm hK hne j
  have hgeo := thin_lattice_boxing_exact_widths_of_normalization hr K hK hne
    (basisEuclideanNormalization a) hinner houter b
    (sharpLatticeDefectBound r) (sharpLatticeDefectBound_pos r)
    (by rw [hbmap]; exact hdefect)
  dsimp only at hgeo
  rw [←hwidth] at hgeo
  refine ⟨box,?_,b,hbcols,hbΛ,?_,hgeo.1,hgeo.2,hne,hB⟩
  · rw [booleanThinLatticeBox,hout]
    rfl
  · intro j
    change BitListCanonical ((computedBasisFloorWidths B V).toVector.get j)
    exact listStoredVertexFloorWidths_canonical _ V (constructedListMatrixInverse_wellFormed B hB) hV j
end Optss
