import Optss.BoundaryGeometry
import Mathlib.MeasureTheory.Constructions.Pi
import Mathlib.MeasureTheory.Integral.Lebesgue.Basic
import Mathlib.Topology.Order.Compact
import Mathlib.Algebra.Group.Pointwise.Set.BigOperators
import Mathlib.Algebra.BigOperators.Pi

/-!
# Volume lost under coordinate erosion

The section bound and its product-measure consequence are the Fubini steps in
(11). Compact convex sections may be empty or degenerate.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators ENNReal
open MeasureTheory MeasureTheory.Measure Set

/-- Eroding a closed interval by `[-a,a]` moves its endpoints inward by `a`.
This identity includes the case in which the erosion is empty. -/
theorem erosion_Icc (l u : ℝ) {a : ℝ} (ha : 0 ≤ a) :
    minkowskiErosion (Icc l u) (Icc (-a) a) = Icc (l+a) (u-a) := by
  ext x
  constructor
  · intro hx
    have hlo := hx (-a) ⟨le_rfl, by linarith⟩
    have hhi := hx a ⟨by linarith, le_rfl⟩
    exact ⟨by linarith [hlo.1], by linarith [hhi.2]⟩
  · intro hx t ht
    exact ⟨by linarith [hx.1, ht.1], by linarith [hx.2, ht.2]⟩

/-- An interval loses at most `2a` of one-dimensional volume under erosion,
even if its length is smaller than `2a`. -/
theorem volume_interval_erosion_loss (l u : ℝ) {a : ℝ} (ha : 0 ≤ a) :
    volume (Icc l u \ minkowskiErosion (Icc l u) (Icc (-a) a)) ≤ ENNReal.ofReal (2*a) := by
  rw [erosion_Icc l u ha]
  have hsub : Icc l u \ Icc (l+a) (u-a) ⊆ Icc l (l+a) ∪ Icc (u-a) u := by
    intro x hx
    have hxlu := hx.1
    by_cases hleft : x ≤ l+a
    · exact Or.inl ⟨hxlu.1, hleft⟩
    · right
      exact ⟨by by_contra h; exact hx.2 ⟨by linarith, by linarith⟩, hxlu.2⟩
  calc
    volume (Icc l u \ Icc (l+a) (u-a)) ≤ volume (Icc l (l+a) ∪ Icc (u-a) u) := measure_mono hsub
    _ ≤ volume (Icc l (l+a)) + volume (Icc (u-a) u) := measure_union_le _ _
    _ = ENNReal.ofReal (2*a) := by
      rw [Real.volume_Icc, Real.volume_Icc]
      have h₁ : l+a-l = a := by ring
      have h₂ : u-(u-a) = a := by ring
      rw [h₁, h₂, ← ENNReal.ofReal_add ha ha]
      congr 1
      ring

/-- Every compact convex real section satisfies the same loss bound. -/
theorem volume_convex_erosion_loss {S : Set ℝ} (hcompact : IsCompact S)
    (hconv : Convex ℝ S) {a : ℝ} (ha : 0 ≤ a) :
    volume (S \ minkowskiErosion S (Icc (-a) a)) ≤ ENNReal.ofReal (2*a) := by
  rcases S.eq_empty_or_nonempty with rfl | hne
  · simp
  · rw [eq_Icc_of_connected_compact (hconv.isConnected hne) hcompact]
    exact volume_interval_erosion_loss _ _ ha

section Product
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- The line segment eroding only the first coordinate of `ℝ × E`. -/
def firstAxisSegment (a : ℝ) : Set (ℝ × E) := (fun t => (t, 0)) '' Icc (-a) a

/-- A section of a set at fixed remaining coordinates. -/
def firstAxisSection (K : Set (ℝ × E)) (y : E) : Set ℝ := {t | (t,y) ∈ K}

omit [NormedSpace ℝ E] in
theorem section_erosion (K : Set (ℝ × E)) (y : E) (a : ℝ) :
    firstAxisSection (minkowskiErosion K (firstAxisSegment a)) y =
      minkowskiErosion (firstAxisSection K y) (Icc (-a) a) := by
  ext t
  constructor
  · intro h u hu
    simpa using h (u,0) ⟨u,hu,rfl⟩
  · intro h v hv
    obtain ⟨u, hu, rfl⟩ := hv
    simpa using h u hu

theorem convex_firstAxisSection {K : Set (ℝ × E)} (hK : Convex ℝ K) (y : E) :
    Convex ℝ (firstAxisSection K y) := by
  intro t ht u hu a b ha hb hab
  have h := hK ht hu ha hb hab
  have he : (a • t + b • u, y) = a • (t,y) + b • (u,y) := by
    ext
    · rfl
    · change y = a • y + b • y
      rw [← add_smul, hab, one_smul]
  change (a • t + b • u, y) ∈ K
  rw [he]
  exact h

omit [NormedSpace ℝ E] in
theorem isCompact_firstAxisSection {K : Set (ℝ × E)} (hK : IsClosed K)
    {B : Set E} {l u : ℝ} (hbound : K ⊆ Icc l u ×ˢ B) (y : E) :
    IsCompact (firstAxisSection K y) := by
  apply isCompact_Icc.of_isClosed_subset
  · exact hK.preimage (continuous_id.prodMk continuous_const)
  · intro t ht
    exact (hbound ht).1

variable [MeasurableSpace E] [BorelSpace E]

/-- Single-coordinate Fubini estimate: a bounded convex body's erosion loss
is at most `2a` times the measure of an enclosing box for the other coordinates. -/
theorem measure_firstAxis_erosion_loss (μ : Measure E) [SigmaFinite μ]
    {K : Set (ℝ × E)} (hclosed : IsClosed K) (hconv : Convex ℝ K)
    {B : Set E} (hB : MeasurableSet B) {l u a : ℝ}
    (hbound : K ⊆ Icc l u ×ˢ B) (ha : 0 ≤ a) :
    (volume.prod μ) (K \ minkowskiErosion K (firstAxisSegment a)) ≤
      ENNReal.ofReal (2*a) * μ B := by
  have hmeas : MeasurableSet (K \ minkowskiErosion K (firstAxisSegment a)) :=
    hclosed.measurableSet.diff (isClosed_erosion hclosed).measurableSet
  rw [Measure.prod_apply_symm hmeas]
  have hfiber : ∀ y, volume ((fun t : ℝ => (t,y)) ⁻¹'
      (K \ minkowskiErosion K (firstAxisSegment a))) ≤
      B.indicator (fun _ => ENNReal.ofReal (2*a)) y := by
    intro y
    by_cases hy : y ∈ B
    · rw [Set.indicator_of_mem hy]
      have he : ((fun t : ℝ => (t,y)) ⁻¹'
          (K \ minkowskiErosion K (firstAxisSegment a))) =
          firstAxisSection K y \ minkowskiErosion (firstAxisSection K y) (Icc (-a) a) := by
        rw [← section_erosion K y a]
        rfl
      rw [he]
      exact volume_convex_erosion_loss (isCompact_firstAxisSection hclosed hbound y)
        (convex_firstAxisSection hconv y) ha
    · rw [Set.indicator_of_not_mem hy]
      have hempty : ((fun t : ℝ => (t,y)) ⁻¹'
          (K \ minkowskiErosion K (firstAxisSegment a))) = ∅ := by
        apply Set.eq_empty_iff_forall_not_mem.mpr
        intro t ht
        exact hy (hbound ht.1).2
      simp [hempty]
  calc
    (∫⁻ y, volume ((fun t : ℝ => (t,y)) ⁻¹'
        (K \ minkowskiErosion K (firstAxisSegment a))) ∂μ) ≤
        ∫⁻ y, B.indicator (fun _ => ENNReal.ofReal (2*a)) y ∂μ := lintegral_mono hfiber
    _ = _ := by rw [lintegral_indicator hB, setLIntegral_const]

end Product

/-- Erosion commutes with an additive coordinate isomorphism. -/
theorem preimage_erosion_addEquiv {G H : Type*} [AddCommGroup G] [AddCommGroup H]
    (e : G ≃+ H) (K C : Set H) :
    e ⁻¹' minkowskiErosion K C = minkowskiErosion (e ⁻¹' K) (e ⁻¹' C) := by
  ext x
  constructor
  · intro hx u hu
    simpa using hx (e u) hu
  · intro hx v hv
    obtain ⟨u, rfl⟩ := e.surjective v
    simpa using hx u hv

/-- A single coordinate segment in a finite-dimensional real coordinate space. -/
def coordinateSegment {d : ℕ} (i : Fin d) (a : ℝ) : Set (Fin d → ℝ) :=
  (fun t => Pi.single i t) '' Icc (-a) a

/-- Separating one coordinate as a linear equivalence, compatible with the
measure-preserving coordinate split in mathlib. -/
def coordinateSplit {n : ℕ} (i : Fin (n+1)) :
    (Fin (n+1) → ℝ) ≃ₗ[ℝ] (ℝ × (Fin n → ℝ)) where
  toEquiv := (Fin.insertNthEquiv (fun _ => ℝ) i).symm
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

@[simp] theorem coordinateSplit_apply {n : ℕ} (i : Fin (n+1)) (v : Fin (n+1) → ℝ) :
    coordinateSplit i v = (v i, fun j => v (i.succAbove j)) := rfl

@[simp] theorem coordinateSplit_single {n : ℕ} (i : Fin (n+1)) (t : ℝ) :
    coordinateSplit i (Pi.single i t) = (t,0) := by
  rw [coordinateSplit_apply]
  ext j <;> simp [Fin.succAbove_ne, Fin.ne_succAbove]

theorem coordinateSplit_preimage_segment {n : ℕ} (i : Fin (n+1)) (a : ℝ) :
    (coordinateSplit i).symm ⁻¹' coordinateSegment i a = firstAxisSegment a := by
  ext p
  constructor
  · rintro ⟨t, ht, he⟩
    have he' := congrArg (coordinateSplit i) he
    simpa using (show p ∈ firstAxisSegment a from
      ⟨t, ht, by simpa using he'⟩)
  · rintro ⟨t, ht, rfl⟩
    refine ⟨t, ht, ?_⟩
    apply (coordinateSplit i).injective
    simp
    rfl

/-- Fubini's exact loss estimate for any selected coordinate. -/
theorem volume_coordinate_erosion_loss {n : ℕ} {K : Set (Fin (n+1) → ℝ)}
    (hclosed : IsClosed K) (hconv : Convex ℝ K) {lo hi : Fin (n+1) → ℝ}
    (hbound : K ⊆ Icc lo hi) (i : Fin (n+1)) {a : ℝ} (ha : 0 ≤ a) :
    volume (K \ minkowskiErosion K (coordinateSegment i a)) ≤
      ENNReal.ofReal (2*a) * ∏ j : Fin n, ENNReal.ofReal (hi (i.succAbove j) - lo (i.succAbove j)) := by
  let e := coordinateSplit i
  let B : Set (Fin n → ℝ) := Icc (fun j => lo (i.succAbove j)) (fun j => hi (i.succAbove j))
  have hsplitclosed : IsClosed (e.symm ⁻¹' K) :=
    hclosed.preimage e.symm.toLinearMap.continuous_of_finiteDimensional
  have hsplitconv : Convex ℝ (e.symm ⁻¹' K) := hconv.linear_preimage e.symm.toLinearMap
  have hsplitbound : e.symm ⁻¹' K ⊆ Icc (lo i) (hi i) ×ˢ B := by
    intro p hp
    have hv := hbound hp
    have hpair : e (e.symm p) = p := e.apply_symm_apply p
    have hfirst := congrArg Prod.fst hpair
    have hrest := congrArg Prod.snd hpair
    change (e.symm p) i = p.1 at hfirst
    change (fun j => (e.symm p) (i.succAbove j)) = p.2 at hrest
    constructor
    · exact ⟨hfirst ▸ hv.1 i, hfirst ▸ hv.2 i⟩
    · constructor <;> intro j
      · have h := hv.1 (i.succAbove j)
        simpa only [congrFun hrest j] using h
      · have h := hv.2 (i.succAbove j)
        simpa only [congrFun hrest j] using h
  have h := measure_firstAxis_erosion_loss (volume : Measure (Fin n → ℝ))
    hsplitclosed hsplitconv measurableSet_Icc hsplitbound ha
  have heq : (e.symm ⁻¹' K \ minkowskiErosion (e.symm ⁻¹' K) (firstAxisSegment a)) =
      e.symm ⁻¹' (K \ minkowskiErosion K (coordinateSegment i a)) := by
    have hpre := preimage_erosion_addEquiv e.symm.toAddEquiv K (coordinateSegment i a)
    change e.symm ⁻¹' minkowskiErosion K (coordinateSegment i a) =
      minkowskiErosion (e.symm ⁻¹' K) (e.symm ⁻¹' coordinateSegment i a) at hpre
    rw [coordinateSplit_preimage_segment] at hpre
    rw [Set.preimage_diff, hpre]
  rw [heq] at h
  have hpres := (volume_preserving_piFinSuccAbove (fun _ : Fin (n+1) => ℝ) i).symm
  have hp := hpres.measure_preimage_equiv (K \ minkowskiErosion K (coordinateSegment i a))
  change volume (e.symm ⁻¹' (K \ minkowskiErosion K (coordinateSegment i a))) = _ at hp
  change volume (e.symm ⁻¹' (K \ minkowskiErosion K (coordinateSegment i a))) ≤ _ at h
  rw [hp] at h
  simpa only [B, Real.volume_Icc_pi] using h


/-- The sum of the coordinate segments is precisely the eroding cube. -/
theorem sum_coordinateSegments {d : ℕ} (a : ℝ) :
    (∑ i : Fin d, coordinateSegment i a) =
      Icc (fun _ : Fin d => -a) (fun _ => a) := by
  ext x
  constructor
  · intro hx
    obtain ⟨g, hg, rfl⟩ := (Set.mem_fintype_sum (fun i : Fin d => coordinateSegment i a) x).mp hx
    choose t ht he using hg
    have heq : g = fun i => Pi.single i (t i) := funext (fun i => (he i).symm)
    rw [heq, Finset.univ_sum_single]
    exact ⟨fun i => (ht i).1, fun i => (ht i).2⟩
  · intro hx
    apply (Set.mem_fintype_sum (fun i : Fin d => coordinateSegment i a) x).mpr
    exact ⟨fun i => Pi.single i (x i), fun i => ⟨x i, ⟨hx.1 i, hx.2 i⟩, rfl⟩,
      Finset.univ_sum_single _⟩

@[simp] theorem erosion_zero {G : Type*} [AddCommGroup G] (K : Set G) :
    minkowskiErosion K (0 : Set G) = K := by
  change minkowskiErosion K {0} = K
  ext x
  simp [minkowskiErosion]

/-- Each coordinate erosion has the same upper bound inside a cube of radius
`R`, independently of where that cube is centered. -/
theorem volume_coordinate_erosion_loss_cube {n : ℕ} {K : Set (Fin (n+1) → ℝ)}
    (hclosed : IsClosed K) (hconv : Convex ℝ K) (c : Fin (n+1) → ℝ) {R a : ℝ}
    (hbound : K ⊆ Icc (fun j => c j-R) (fun j => c j+R))
    (i : Fin (n+1)) (ha : 0 ≤ a) :
    volume (K \ minkowskiErosion K (coordinateSegment i a)) ≤
      ENNReal.ofReal (2*a) * ENNReal.ofReal (2*R)^n := by
  have h := volume_coordinate_erosion_loss hclosed hconv hbound i ha
  have hw : ∀ j : Fin n, (c (i.succAbove j)+R) - (c (i.succAbove j)-R) = 2*R := by
    intro j
    ring
  simpa only [hw, Finset.prod_const, Finset.card_univ, Fintype.card_fin] using h

/-- Summing the exact Fubini losses over successive coordinate erosions.
Intermediate bodies remain closed and convex and stay in the same outer box. -/
theorem volume_erosion_coordinate_sum_le {n : ℕ} (T : Finset (Fin (n+1)))
    {K : Set (Fin (n+1) → ℝ)} (hclosed : IsClosed K) (hconv : Convex ℝ K)
    (c : Fin (n+1) → ℝ) {R a : ℝ}
    (hbound : K ⊆ Icc (fun j => c j-R) (fun j => c j+R)) (ha : 0 ≤ a) :
    volume (K \ minkowskiErosion K (∑ i ∈ T, coordinateSegment i a)) ≤
      T.card • (ENNReal.ofReal (2*a) * ENNReal.ofReal (2*R)^n) := by
  classical
  induction T using Finset.induction_on generalizing K with
  | empty => simp
  | @insert i T hi ih =>
      rw [Finset.sum_insert hi, erosion_add, Finset.card_insert_of_not_mem hi, succ_nsmul]
      let K' := minkowskiErosion K (coordinateSegment i a)
      have hzero : (0 : Fin (n+1) → ℝ) ∈ coordinateSegment i a :=
        ⟨0, ⟨by linarith, ha⟩, by simp⟩
      have hsub : K' ⊆ K := erosion_subset hzero
      have hstep := volume_coordinate_erosion_loss_cube hclosed hconv c hbound i ha
      have htail := ih (isClosed_erosion hclosed) (convex_erosion hconv) (hsub.trans hbound)
      have hsplit : K \ minkowskiErosion K' (∑ j ∈ T, coordinateSegment j a) ⊆
          (K \ K') ∪ (K' \ minkowskiErosion K' (∑ j ∈ T, coordinateSegment j a)) := by
        intro x hx
        by_cases hx' : x ∈ K'
        · exact Or.inr ⟨hx', hx.2⟩
        · exact Or.inl ⟨hx.1, hx'⟩
      calc
        volume (K \ minkowskiErosion K' (∑ j ∈ T, coordinateSegment j a)) ≤
            volume ((K \ K') ∪ (K' \ minkowskiErosion K' (∑ j ∈ T, coordinateSegment j a))) :=
          measure_mono hsplit
        _ ≤ volume (K \ K') + volume (K' \ minkowskiErosion K' (∑ j ∈ T, coordinateSegment j a)) :=
          measure_union_le _ _
        _ ≤ _ := by simpa only [add_comm] using add_le_add hstep htail

/-- Equation (11) in coordinate form, with its exact dimension factor.
The bound holds even when successive erosions empty the body. -/
theorem volume_cube_erosion_shell {n : ℕ} {K : Set (Fin (n+1) → ℝ)}
    (hclosed : IsClosed K) (hconv : Convex ℝ K) (c : Fin (n+1) → ℝ) {R a : ℝ}
    (hbound : K ⊆ Icc (fun j => c j-R) (fun j => c j+R)) (ha : 0 ≤ a) :
    volume (K \ minkowskiErosion K (Icc (fun _ => -a) (fun _ => a))) ≤
      (n+1) • (ENNReal.ofReal (2*a) * ENNReal.ofReal (2*R)^n) := by
  simpa only [sum_coordinateSegments, Finset.card_univ, Fintype.card_fin] using
    volume_erosion_coordinate_sum_le Finset.univ hclosed hconv c hbound ha

/-- The normalized form printed in (11): `d R^(d-1) a vol([-1,1]^d)`.
Here `d=n+1` and `R=1+a_buf` in the paper. -/
theorem volume_cube_erosion_shell_normalized {n : ℕ} {K : Set (Fin (n+1) → ℝ)}
    (hclosed : IsClosed K) (hconv : Convex ℝ K) (c : Fin (n+1) → ℝ) {R a : ℝ}
    (hbound : K ⊆ Icc (fun j => c j-R) (fun j => c j+R)) (hR : 0 ≤ R) (ha : 0 ≤ a) :
    volume (K \ minkowskiErosion K (Icc (fun _ => -a) (fun _ => a))) ≤
      ENNReal.ofReal (((n+1 : ℕ) : ℝ)*R^n*a) *
        volume (Icc (fun _ : Fin (n+1) => (-1 : ℝ)) (fun _ => (1 : ℝ))) := by
  have h := volume_cube_erosion_shell hclosed hconv c hbound ha
  convert h using 1
  rw [Real.volume_Icc_pi]
  simp only [sub_neg_eq_add, one_add_one_eq_two, Finset.prod_const, Finset.card_univ, Fintype.card_fin,
    nsmul_eq_mul]
  rw [← ENNReal.ofReal_pow (by positivity : (0 : ℝ) ≤ 2),
    ← ENNReal.ofReal_mul (by positivity),
    ← ENNReal.ofReal_pow (by positivity : 0 ≤ 2*R),
    ← ENNReal.ofReal_mul (by positivity)]
  rw [← ENNReal.ofReal_natCast, ← ENNReal.ofReal_mul (by positivity)]
  congr 1
  ring


/-- Coordinate segments with separate radii sum to the corresponding box. -/
theorem sum_coordinateSegments_variable {d : ℕ} (r : Fin d → ℝ) :
    (∑ i : Fin d, coordinateSegment i (r i)) = Icc (fun i => -r i) r := by
  ext x
  constructor
  · intro hx
    obtain ⟨g, hg, rfl⟩ := (Set.mem_fintype_sum _ x).mp hx
    choose t ht he using hg
    have heq : g = fun i => Pi.single i (t i) := funext (fun i => (he i).symm)
    rw [heq, Finset.univ_sum_single]
    exact ⟨fun i => (ht i).1, fun i => (ht i).2⟩
  · intro hx
    apply (Set.mem_fintype_sum _ x).mpr
    exact ⟨fun i => Pi.single i (x i), fun i => ⟨x i, ⟨hx.1 i, hx.2 i⟩, rfl⟩,
      Finset.univ_sum_single _⟩

/-- Separate coordinate erosion radii have their corresponding section-loss
sum. This allows direct anisotropic box estimates without a normalization axiom. -/
theorem volume_erosion_coordinate_sum_general {n : ℕ} (T : Finset (Fin (n+1)))
    {K : Set (Fin (n+1) → ℝ)} (hclosed : IsClosed K) (hconv : Convex ℝ K)
    (lo hi r : Fin (n+1) → ℝ) (hbound : K ⊆ Icc lo hi) (hr : ∀ i, 0 ≤ r i) :
    volume (K \ minkowskiErosion K (∑ i ∈ T, coordinateSegment i (r i))) ≤
      ∑ i ∈ T, ENNReal.ofReal (2*r i) *
        ∏ j : Fin n, ENNReal.ofReal (hi (i.succAbove j) - lo (i.succAbove j)) := by
  classical
  induction T using Finset.induction_on generalizing K with
  | empty => simp
  | @insert i T hiT ih =>
      rw [Finset.sum_insert hiT, erosion_add, Finset.sum_insert hiT]
      let K' := minkowskiErosion K (coordinateSegment i (r i))
      have hzero : (0 : Fin (n+1) → ℝ) ∈ coordinateSegment i (r i) :=
        ⟨0, ⟨by linarith [hr i], hr i⟩, by simp⟩
      have hsub : K' ⊆ K := erosion_subset hzero
      have hstep := volume_coordinate_erosion_loss hclosed hconv hbound i (hr i)
      have htail := ih (isClosed_erosion hclosed) (convex_erosion hconv) (hsub.trans hbound)
      have hsplit : K \ minkowskiErosion K' (∑ j ∈ T, coordinateSegment j (r j)) ⊆
          (K \ K') ∪ (K' \ minkowskiErosion K' (∑ j ∈ T, coordinateSegment j (r j))) := by
        intro x hx
        by_cases hx' : x ∈ K'
        · exact Or.inr ⟨hx', hx.2⟩
        · exact Or.inl ⟨hx.1, hx'⟩
      calc
        volume (K \ minkowskiErosion K' (∑ j ∈ T, coordinateSegment j (r j))) ≤
            volume ((K \ K') ∪ (K' \ minkowskiErosion K' (∑ j ∈ T, coordinateSegment j (r j)))) :=
          measure_mono hsplit
        _ ≤ volume (K \ K') + volume (K' \ minkowskiErosion K' (∑ j ∈ T, coordinateSegment j (r j))) :=
          measure_union_le _ _
        _ ≤ _ := add_le_add hstep htail

/-- The full anisotropic version of (11). Nonnegative widths are sufficient;
zero-width boxes and lower-dimensional bodies need no exceptional convention. -/
theorem volume_box_erosion_shell {n : ℕ} {K : Set (Fin (n+1) → ℝ)}
    (hclosed : IsClosed K) (hconv : Convex ℝ K) (c w : Fin (n+1) → ℝ)
    (hw : ∀ i, 0 ≤ w i) {R a : ℝ} (hR : 0 ≤ R) (ha : 0 ≤ a)
    (hbound : K ⊆ Icc (fun i => c i-R*w i) (fun i => c i+R*w i)) :
    volume (K \ minkowskiErosion K (Icc (fun i => -(a*w i)) (fun i => a*w i))) ≤
      ENNReal.ofReal (((n+1 : ℕ) : ℝ)*R^n*a) * volume (Icc (fun i => -w i) w) := by
  have h := volume_erosion_coordinate_sum_general Finset.univ hclosed hconv
    (fun i => c i-R*w i) (fun i => c i+R*w i) (fun i => a*w i) hbound
    (fun i => mul_nonneg ha (hw i))
  rw [sum_coordinateSegments_variable] at h
  have hterm : ∀ i : Fin (n+1),
      ENNReal.ofReal (2*(a*w i)) *
      (∏ j : Fin n, ENNReal.ofReal ((c (i.succAbove j)+R*w (i.succAbove j)) -
        (c (i.succAbove j)-R*w (i.succAbove j)))) =
      ENNReal.ofReal (R^n*a) * volume (Icc (fun i => -w i) w) := by
    intro i
    have hwidth : ∀ j : Fin n,
        (c (i.succAbove j)+R*w (i.succAbove j)) -
        (c (i.succAbove j)-R*w (i.succAbove j)) = (2*R)*w (i.succAbove j) := by
      intro j
      ring
    simp_rw [hwidth]
    rw [← ENNReal.ofReal_prod_of_nonneg (fun j _ =>
      mul_nonneg (mul_nonneg (by norm_num) hR) (hw (i.succAbove j))),
      ← ENNReal.ofReal_mul (mul_nonneg (by norm_num) (mul_nonneg ha (hw i))), Real.volume_Icc_pi]
    have hwidth' : ∀ j, w j - -w j = 2*w j := by intro j; ring
    simp_rw [hwidth']
    rw [← ENNReal.ofReal_prod_of_nonneg (fun j _ => mul_nonneg (by norm_num) (hw j)),
      ← ENNReal.ofReal_mul (by positivity)]
    congr 1
    rw [Finset.prod_mul_distrib, Finset.prod_const, Finset.card_univ, Fintype.card_fin,
      Finset.prod_mul_distrib, Finset.prod_const, Finset.card_univ, Fintype.card_fin,
      Fin.prod_univ_succAbove w i]
    ring
  simp_rw [hterm] at h
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at h
  convert h using 1
  rw [← ENNReal.ofReal_natCast, ← mul_assoc, ← ENNReal.ofReal_mul (by positivity)]
  congr 2
  ring


/-- Geometric scaling of an anisotropic centered box, including scale zero. -/
theorem smul_centered_real_box {ι : Type*} (w : ι → ℝ) (hw : ∀ i, 0 ≤ w i)
    {a : ℝ} (ha : 0 ≤ a) :
    a • Icc (fun i => -w i) w = Icc (fun i => -(a*w i)) (fun i => a*w i) := by
  by_cases ha0 : a = 0
  · subst a
    have hzero : (0 : ι → ℝ) ∈ Icc (fun i => -w i) w :=
      ⟨fun i => neg_nonpos.mpr (hw i), hw⟩
    rw [zero_smul_set ⟨0,hzero⟩]
    simp
    rfl
  · have hapos : 0 < a := lt_of_le_of_ne ha (Ne.symm ha0)
    ext x
    constructor
    · rintro ⟨v, hv, rfl⟩
      constructor <;> intro i
      · have h := mul_le_mul_of_nonneg_left (hv.1 i) ha
        simpa [Pi.smul_apply, smul_eq_mul] using h
      · exact mul_le_mul_of_nonneg_left (hv.2 i) ha
    · intro hx
      refine ⟨fun i => x i / a, ⟨?_, ?_⟩, ?_⟩
      · intro i
        apply (le_div_iff₀ hapos).mpr
        have hlo := hx.1 i
        dsimp only at hlo ⊢
        nlinarith
      · intro i
        apply (div_le_iff₀ hapos).mpr
        have hhi := hx.2 i
        dsimp only at hhi ⊢
        nlinarith
      · ext i
        change a * (x i / a) = x i
        field_simp

/-- The covering-volume consequence (12) with an explicit constant and no
unproved shell-volume premise. For dimension `d=n+1`, the constant is
`12*d*(5R)^(d-1)`, where the paper uses `R=1+a_buf` and `δ=ϑ+η`. -/
theorem exists_normal_box_macbeath_cover {n : ℕ} {K : Set (Fin (n+1) → ℝ)}
    (hclosed : IsClosed K) (hconv : Convex ℝ K) (c w : Fin (n+1) → ℝ)
    (hw : ∀ i, 0 ≤ w i) {R δ : ℝ} (hR : 0 ≤ R) (hδ : 0 < δ)
    (hbound : K ⊆ Icc (fun i => c i-R*w i) (fun i => c i+R*w i))
    (C : Finset (Fin (n+1) → ℝ)) (hC : ∀ x ∈ C, x ∈ K)
    (hnormal : ∀ x ∈ C, ∃ (f : (Fin (n+1) → ℝ) →ₗ[ℝ] ℝ) (H h : ℝ),
      (∀ u ∈ K, f u ≤ H) ∧ 0 < h ∧
      (∃ q ∈ Icc (fun i => -w i) w, f q = h) ∧ H-f x ≤ δ*h) :
    ∃ T : Finset (Fin (n+1) → ℝ), T ⊆ C ∧
      (∀ x ∈ T, ∀ y ∈ T, x ≠ y →
        Disjoint (macbeathRegion K x (1/5)) (macbeathRegion K y (1/5))) ∧
      (∀ x ∈ C, ∃ y ∈ T, macbeathRegion K x (1/5) ⊆ macbeathRegion K y 1) ∧
      (∑ x ∈ T, volume (macbeathCore K x)) ≤
        ENNReal.ofReal (12 * ((n+1 : ℕ) : ℝ) * (5*R)^n * δ) *
          volume (Icc (fun i => -w i) w) := by
  have hcompact : IsCompact K := isCompact_Icc.of_isClosed_subset hclosed hbound
  obtain ⟨T, hTC, hdis, hcover, hvol⟩ := exists_normal_macbeath_cover volume hconv hcompact C hC hδ hnormal
  refine ⟨T, hTC, hdis, hcover, ?_⟩
  have hscale : 0 ≤ (12/5 : ℝ)*δ := by positivity
  have hshell := volume_box_erosion_shell hclosed hconv c w hw hR hscale hbound
  rw [← smul_centered_real_box w hw hscale] at hshell
  have h := hvol.trans (mul_le_mul_left' hshell _)
  simp only [Module.finrank_fintype_fun_eq_card, Fintype.card_fin] at h
  convert h using 1
  rw [← mul_assoc, ← ENNReal.ofReal_mul (by positivity)]
  congr 2
  ring

end
end Optss
