import Optss.Bogolyubov
import Optss.ThinLatticeBoxing
import Optss.IntegerSubgroupBasis
import Optss.GeneratedLatticeBasis
import Mathlib.Combinatorics.Pigeonhole

/-! The full integer phase lattice and the small-coordinate Bohr criterion. -/
namespace Optss
noncomputable section
open scoped BigOperators Pointwise
variable {N r : ℕ} [NeZero N]

def cyclicPhaseLattice (a : Fin r → ZMod N) (base : Fin r) : AddSubgroup (IntVec r) where
  carrier := {z | ∀ j, (z j : ZMod N)=a j*(z base : ZMod N)}
  zero_mem' := by intro j; simp
  add_mem' := by
    intro x y hx hy j
    change ((x j+y j : ℤ) : ZMod N)=a j*((x base+y base : ℤ) : ZMod N)
    rw [Int.cast_add,Int.cast_add,hx j,hy j,mul_add]
  neg_mem' := by
    intro x hx j
    change ((-x j : ℤ) : ZMod N)=a j*((-x base : ℤ) : ZMod N)
    rw [Int.cast_neg,Int.cast_neg,hx j,mul_neg]

theorem cyclicPhaseLattice_axes (a : Fin r → ZMod N) (base j : Fin r) :
    Pi.single j (N : ℤ)∈cyclicPhaseLattice a base := by
  intro k
  simp only [Pi.single_apply]
  split_ifs <;> simp

theorem cyclic_small_integer_phase (z : ℤ) (hz : 16*|z|≤(N : ℤ)) :
    ‖ZMod.stdAddChar (z : ZMod N)-1‖≤1 := by
  have hN : 0<(N : ℝ) := Nat.cast_pos.mpr (NeZero.pos N)
  have hzR : 16*|(z : ℝ)|≤(N : ℝ) := by exact_mod_cast hz
  let t : ℝ := 2*Real.pi*(z : ℝ)/N
  have ht : |t|≤1/2 := by
    have hp := mul_le_mul_of_nonneg_right Real.pi_le_four (abs_nonneg (z : ℝ))
    dsimp [t]
    rw [abs_div,abs_mul,abs_mul,abs_of_nonneg (by positivity : (0 : ℝ)≤2),
      abs_of_nonneg Real.pi_pos.le,abs_of_pos hN]
    apply (div_le_iff₀ hN).mpr
    nlinarith
  have hc : ZMod.stdAddChar (z : ZMod N)=Complex.exp ((t : ℂ)*Complex.I) := by
    rw [ZMod.stdAddChar_coe]
    congr 1
    dsimp [t]
    push_cast
    ring
  rw [hc]
  have hn : ‖(t : ℂ)*Complex.I‖≤1/2 := by simpa [norm_mul] using ht
  have h := Complex.norm_exp_sub_one_le (show ‖(t : ℂ)*Complex.I‖≤1 by linarith)
  linarith

/-- Every small integer phase vector maps into the Bohr neighborhood of the
specified frequency family. -/
theorem phase_lattice_small_box_bohr (a : Fin r → ZMod N) (base : Fin r)
    (S : Finset (ZMod N)) (hS : ∀ k∈S, ∃ j, a j=k)
    (z : IntVec r) (hz : z∈cyclicPhaseLattice a base)
    (hsmall : ∀ j, 16*|z j|≤(N : ℤ)) :
    (z base : ZMod N)∈cyclicBohrSet S := by
  intro k hk
  obtain ⟨j,rfl⟩ := hS k hk
  rw [← hz j]
  exact cyclic_small_integer_phase (z j) (hsmall j)

/-- The modular coordinate embedding is injective on a short integer cube. -/
theorem intCast_injective_short_interval (M : ℕ) (hM : 2*M<N)
    (u v : ℤ) (hu : |u|≤M) (hv : |v|≤M) (he : (u : ZMod N)=(v : ZMod N)) : u=v := by
  have hd : (N : ℤ)∣v-u := (ZMod.intCast_eq_intCast_iff_dvd_sub u v N).mp he
  have hbound : |v-u|<(N : ℤ) := by
    have habs := abs_sub v u
    have hMZ : (2 : ℤ)*M<N := by exact_mod_cast hM
    omega
  have hzero : v-u=0 := Int.eq_zero_of_abs_lt_dvd hd hbound
  omega

theorem phase_lattice_projection_injective (a : Fin r → ZMod N) (base : Fin r)
    (M : ℕ) (hM : 2*M<N) :
    Set.InjOn (fun z : IntVec r => (z base : ZMod N))
      {z | z∈cyclicPhaseLattice a base ∧ ∀ j, |z j|≤(M : ℤ)} := by
  intro u hu v hv huv
  change (u base : ZMod N)=(v base : ZMod N) at huv
  funext j
  have he : (u j : ZMod N)=(v j : ZMod N) := by rw [hu.1 j,hv.1 j,huv]
  exact intCast_injective_short_interval M hM (u j) (v j) (hu.2 j) (hv.2 j) he

end
end Optss
