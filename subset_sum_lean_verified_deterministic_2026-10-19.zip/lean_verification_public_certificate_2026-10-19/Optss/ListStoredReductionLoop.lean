import Optss.ListStoredCachedReduction

/-!
# Explicit list control for the list-stored reduction loop

Pair enumeration and selection are list traversals. All index comparisons use
the verified Boolean-list comparator. The loop consumes Boolean fuel and
records swaps as list constructors. No finite set, vector, rational decoder,
or integer decoder occurs in the executed loop.
-/
namespace Optss
variable {r d : ℕ}

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

def bitPairLE (p q : Fin r × Fin r) : Bool :=
  bitIndexLT p.1 q.1 || (bitIndexEQ p.1 q.1 && bitIndexLE p.2 q.2)

theorem bitPairLE_correct (p q : Fin r × Fin r) :
    bitPairLE p q = true ↔ toLex p ≤ toLex q := by
  simp only [bitPairLE,Bool.or_eq_true,Bool.and_eq_true,bitIndexLT_correct,
    bitIndexEQ_correct,bitIndexLE_correct,Prod.Lex.toLex_le_toLex]
  simp only [Fin.lt_def,Fin.le_def,Fin.ext_iff]

/-- A fold selecting the lexicographic minimum with Boolean comparisons. -/
def bitLeastPair : List (Fin r × Fin r) → Option (Fin r × Fin r)
  | [] => none
  | p::ps => match bitLeastPair ps with
    | none => some p
    | some q => some (if bitPairLE p q then p else q)

theorem bitLeastPair_none (ps : List (Fin r × Fin r)) : bitLeastPair ps = none ↔ ps = [] := by
  cases ps with
  | nil => simp [bitLeastPair]
  | cons p ps => simp only [bitLeastPair]; split <;> simp

theorem bitLeastPair_spec (ps : List (Fin r × Fin r)) (p : Fin r × Fin r)
    (hp : bitLeastPair ps = some p) : p ∈ ps ∧ ∀ q ∈ ps,toLex p ≤ toLex q := by
  induction ps generalizing p with
  | nil => simp [bitLeastPair] at hp
  | cons a ps ih =>
    rw [bitLeastPair] at hp
    cases he : bitLeastPair ps with
    | none =>
      rw [he] at hp
      have hp' : a=p := Option.some.inj hp
      have hempty := (bitLeastPair_none ps).mp he
      subst p; subst ps
      simp
    | some b =>
      rw [he] at hp
      obtain ⟨hb,hmin⟩ := ih b he
      by_cases h : bitPairLE a b = true
      · simp only [h,↓reduceIte,Option.some.injEq] at hp
        subst p
        refine ⟨List.mem_cons_self,?_⟩
        intro q hq
        rcases List.mem_cons.mp hq with hq | hq
        · subst q; exact le_rfl
        · exact (bitPairLE_correct a b).mp h |>.trans (hmin q hq)
      · simp only [h,↓reduceIte,Option.some.injEq] at hp
        subst p
        refine ⟨List.mem_cons_of_mem _ hb,?_⟩
        intro q hq
        rcases List.mem_cons.mp hq with hq | hq
        · subst q
          exact le_of_not_ge (fun hab => h ((bitPairLE_correct a b).mpr hab))
        · exact hmin q hq

theorem bitLeastPair_eq_least (ps : List (Fin r × Fin r)) (h : ps.toFinset.Nonempty) :
    bitLeastPair ps = some (leastPairInFinset ps.toFinset h) := by
  cases he : bitLeastPair ps with
  | none =>
    have he' := (bitLeastPair_none ps).mp he
    subst ps
    simp at h
  | some p =>
    obtain ⟨hp,hmin⟩ := bitLeastPair_spec ps p he
    letI : LinearOrder (Fin r × Fin r) :=
      LinearOrder.lift' (toLex : Fin r × Fin r → Fin r ×ₗ Fin r)
        (fun _ _ h => toLex_inj.mp h)
    have hp' : p ∈ ps.toFinset := List.mem_toFinset.mpr hp
    have hmin' : ∀ q ∈ ps.toFinset,toLex p ≤ toLex q := by
      intro q hq
      exact hmin q (List.mem_toFinset.mp hq)
    have hle : toLex p ≤ toLex (ps.toFinset.min' h) :=
      Finset.le_min' ps.toFinset h p hmin'
    have hge : toLex (ps.toFinset.min' h) ≤ toLex p := Finset.min'_le _ _ hp'
    have heq : p=ps.toFinset.min' h := toLex_inj.mp (le_antisymm hle hge)
    exact congrArg some heq

/-- Build the test list from a single materialized list-backed GS table. -/
def listStoredFailingPairs (D : ListBitIntegerMatrixData r d) : List (Fin r × Fin r) :=
  let Q := listStoredRationalIntegerRows D
  let T := listStoredGSTable Q r le_rfl
  (List.ofFn (id : Fin r → Fin r)).flatMap fun j =>
    (List.ofFn fun k : Fin r => (j,k)).filter fun p =>
      if bitIndexAdjacent p.1 p.2 then listStoredLovaszPair Q T p.1 p.2 else false

theorem listStoredFailingPairs_eq (D : ListBitIntegerMatrixData r d) :
    (listStoredFailingPairs D).toFinset = encodedFailingAdjacentPairs (listMatrixVector D) := by
  ext p
  simp only [List.mem_toFinset,listStoredFailingPairs,List.mem_flatMap,List.mem_filter,
    List.mem_ofFn,Function.id_def,encodedFailingAdjacentPairs,Finset.mem_filter,
    Finset.mem_univ,true_and]
  simp only [get_ofFn]
  simp only [bitIndexAdjacent_correct,listStoredLovaszPair_eq,listStoredGSTable_eq,
    listStoredRationalIntegerRows_eq]
  constructor
  · rintro ⟨j,⟨x,rfl⟩,⟨⟨k,hk⟩,ht⟩⟩
    cases hk
    simpa only [bitIndexAdjacent_correct] using ht
  · intro h
    refine ⟨p.1,⟨p.1,rfl⟩,⟨⟨p.2,by simp⟩,?_⟩⟩
    simpa only [bitIndexAdjacent_correct] using h

/-- Boolean-controlled row permutation, with explicit row and payload copies. -/
def listStoredBooleanSwapRows (D : ListBitIntegerMatrixData r d) (j k : Fin r) :
    ListBitIntegerMatrixData r d :=
  BooleanListArray.ofFn fun i => D.read (BooleanListArray.copy listCopyInteger)
    (if bitIndexEQ i j then k else if bitIndexEQ i k then j else i)

theorem listStoredBooleanSwapRows_eq (D : ListBitIntegerMatrixData r d) (j k : Fin r) :
    listMatrixVector (listStoredBooleanSwapRows D j k) = encodedSwapRows (listMatrixVector D) j k := by
  have he : listStoredBooleanSwapRows D j k = listStoredSwapRows D j k := by
    unfold listStoredBooleanSwapRows listStoredSwapRows
    congr 1
    funext i
    congr 1
    simp only [Equiv.swap_apply_def,bitIndexEQ_correct,Fin.ext_iff]
  rw [he,listStoredSwapRows_eq]

structure ListStoredLatticeResult (r d : ℕ) where
  rows : ListBitIntegerMatrixData r d
  swapTicks : List Bool
  deriving Repr

/-- Actual loop: lists for data, fuel, pair selection, and swap recording. -/
def listStoredReductionFuel : List Bool → ListBitIntegerMatrixData r d → ListStoredLatticeResult r d
  | [],D => ⟨D,[]⟩
  | _::fuel,D =>
    let C := listStoredReduceIntegerAll D r le_rfl
    let pairs := listStoredFailingPairs C
    match bitLeastPair pairs with
    | none => ⟨C,[]⟩
    | some p =>
      let tail := listStoredReductionFuel fuel (listStoredBooleanSwapRows C p.1 p.2)
      ⟨tail.rows,false::tail.swapTicks⟩

theorem listStoredReductionFuel_eq (fuel : List Bool) (D : ListBitIntegerMatrixData r d) :
    (listMatrixVector (listStoredReductionFuel fuel D).rows,
      (listStoredReductionFuel fuel D).swapTicks.length) =
    ((encodedReductionFuel fuel (listMatrixVector D)).rows,
      (encodedReductionFuel fuel (listMatrixVector D)).swaps) := by
  induction fuel generalizing D with
  | nil => rfl
  | cons b fuel ih =>
    rw [listStoredReductionFuel,encodedReductionFuel]
    simp only [← listStoredReduceIntegerAll_eq,← listStoredFailingPairs_eq]
    split_ifs with h
    · rw [bitLeastPair_eq_least _ h]
      simp only [ListStoredLatticeResult.rows,ListStoredLatticeResult.swapTicks,List.length_cons,
        EncodedLatticeResult.rows,EncodedLatticeResult.swaps]
      have he := ih (listStoredBooleanSwapRows (listStoredReduceIntegerAll D r le_rfl)
        (leastPairInFinset _ h).1 (leastPairInFinset _ h).2)
      rw [listStoredBooleanSwapRows_eq] at he
      exact congrArg (fun p : BitIntegerMatrixData r d × ℕ => (p.1,p.2+1)) he
    · have he : bitLeastPair (listStoredFailingPairs (listStoredReduceIntegerAll D r le_rfl)) = none := by
        apply (bitLeastPair_none _).mpr
        apply List.eq_nil_iff_forall_not_mem.mpr
        intro p hp
        exact h ⟨p,List.mem_toFinset.mpr hp⟩
      rw [he]
      rfl

end Optss
