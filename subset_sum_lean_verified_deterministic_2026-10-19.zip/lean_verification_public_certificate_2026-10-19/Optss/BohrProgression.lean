import Optss.PhaseLatticeProgression
import Optss.BohrDensityParameters

/-! An actual proper progression in every cyclic Bohr neighborhood, followed
by the quantitative Bogolyubov progression theorem. All constants depend
only on the number of frequencies. -/
namespace Optss
noncomputable section
open scoped BigOperators Pointwise
open Classical

variable {N : ℕ} [NeZero N]

/-- The distinguished first coordinate records the residue itself. The
remaining coordinates enumerate the actual finite frequency set. -/
def bohrFrequencyFamily (S : Finset (ZMod N)) : Fin (S.card+1) → ZMod N :=
  Fin.cons 1 (fun i => ((S.equivFin).symm i).val)

@[simp] theorem bohrFrequencyFamily_zero (S : Finset (ZMod N)) :
    bohrFrequencyFamily S 0=1 := rfl

theorem bohrFrequencyFamily_covers (S : Finset (ZMod N)) (k : ZMod N) (hk : k∈S) :
    ∃ j, bohrFrequencyFamily S j=k := by
  refine ⟨(S.equivFin ⟨k,hk⟩).succ,?_⟩
  simp [bohrFrequencyFamily]

/-- A proper symmetric progression with at most one extra coordinate beyond
the frequency set, occupying a dimension-dependent fraction of the group. -/
theorem bohr_contains_progression (S : Finset (ZMod N)) :
    ∃ ρ : IntVec (S.card+1) →+ ZMod N, ∃ m : Fin (S.card+1) → ℕ,
      Set.InjOn ρ (integerBudgetBox m) ∧
      (↑(integerProgressionValues ρ m) : Set (ZMod N))⊆cyclicBohrSet S ∧
      N≤bohrProgressionLoss (S.card+1)*(integerProgressionValues ρ m).card := by
  obtain ⟨ρ,m,hproper,hsub,hcard⟩ := phase_lattice_bohr_progression
    (bohrFrequencyFamily S) 0 (bohrFrequencyFamily_zero S) S
    (bohrFrequencyFamily_covers S) (bohrBoxingCeiling (S.card+1))
    (bohrBoxingCeiling_pos _) (bohrBoxingCeiling_bound _)
  refine ⟨ρ,m,hproper,?_,?_⟩
  · intro x hx
    obtain ⟨z,hz,rfl⟩ := Finset.mem_image.mp hx
    exact hsub z hz
  · simpa only [integerProgressionValues,Finset.card_image_of_injOn hproper,
      integerBudgetBox_card,bohrProgressionLoss] using hcard

/-- Quantitative Bogolyubov, with an actual integer-width progression in the
fourfold sum/difference set and no supplied lattice or progression witness. -/
theorem bogolyubov_contains_progression (A : Finset (ZMod N)) (hA : A.Nonempty) :
    ∃ ρ : IntVec ((bogolyubovSpectrum A).card+1) →+ ZMod N,
    ∃ m : Fin ((bogolyubovSpectrum A).card+1) → ℕ,
      Set.InjOn ρ (integerBudgetBox m) ∧
      integerProgressionValues ρ m⊆(A+A)-(A+A) ∧
      N≤bohrProgressionLoss ((bogolyubovSpectrum A).card+1)*
        (integerProgressionValues ρ m).card ∧
      (((bogolyubovSpectrum A).card+1 : ℕ) : ℝ)≤
        1+2*(N : ℝ)^2/(A.card : ℝ)^2 := by
  obtain ⟨ρ,m,hproper,hsub,hcard⟩ := bohr_contains_progression (bogolyubovSpectrum A)
  refine ⟨ρ,m,hproper,?_,hcard,?_⟩
  · intro x hx
    exact bogolyubov_subset_double_difference A hA (hsub hx)
  · have h := bogolyubovSpectrum_card A hA
    push_cast
    linarith

end
end Optss
