import Optss.Basic
import Mathlib.Data.Finset.Powerset
import Mathlib.Algebra.Order.BigOperators.Group.Finset

/-!
# Exact enumeration and coordinate bounds

This file proves the logical small-instance claim of Lemma 2.3: enumerating all
subsets of the copy labels gives exactly the attainable support. It deliberately
does not claim the paper's convolution running time. The absolute-budget lemmas
formalize the hereditary bound used when clipping partial supports in §2.3 and
Appendix A. The final clipping lemma is also used in §8 / Appendix C.
-/

namespace Optss

open scoped BigOperators

section Enumeration

variable {ι G : Type*} [Fintype ι] [AddCommGroup G] [DecidableEq G]

/-- A direct, executable support computation, retaining separate copy labels. -/
def exactSupport (v : ι → G) : Finset G :=
  Finset.univ.powerset.image (fun s : Finset ι => ∑ i ∈ s, v i)

/-- Both soundness and completeness of exhaustive finite enumeration. -/
@[simp] theorem mem_exactSupport (v : ι → G) (t : G) :
    t ∈ exactSupport v ↔ t ∈ subsetSums v := by
  simp [exactSupport, subsetSums]

theorem exactSupport_sound (v : ι → G) {t : G} (h : t ∈ exactSupport v) :
    ∃ s : Finset ι, ∑ i ∈ s, v i = t :=
  (mem_exactSupport v t).mp h

theorem exactSupport_complete (v : ι → G) (s : Finset ι) :
    (∑ i ∈ s, v i) ∈ exactSupport v := by
  rw [mem_exactSupport]
  exact ⟨s, rfl⟩

/-- The support contains at most one entry for each possible subset. -/
theorem exactSupport_card_le (v : ι → G) :
    (exactSupport v).card ≤ 2 ^ Fintype.card ι := by
  calc
    (exactSupport v).card ≤ (Finset.univ : Finset ι).powerset.card := Finset.card_image_le
    _ = 2 ^ Fintype.card ι := by simp

/-- An executable exact decision procedure; it may take exponential time. -/
def solveSubsetSum (v : ι → G) (t : G) : Bool :=
  decide (t ∈ exactSupport v)

@[simp] theorem solveSubsetSum_correct (v : ι → G) (t : G) :
    solveSubsetSum v t = true ↔ t ∈ subsetSums v := by
  simp [solveSubsetSum]

/-- Exhaustive feasibility for an exact, finite collection of allowed targets. -/
def solveTargets (v : ι → G) (T : Finset G) : Bool :=
  decide ((exactSupport v ∩ T).Nonempty)

@[simp] theorem solveTargets_correct (v : ι → G) (T : Finset G) :
    solveTargets v T = true ↔ ∃ t ∈ T, t ∈ subsetSums v := by
  simp only [solveTargets, decide_eq_true_eq]
  change (∃ t, t ∈ exactSupport v ∩ T) ↔ _
  simp only [Finset.mem_inter, mem_exactSupport]
  exact exists_congr (fun _ => and_comm)

end Enumeration

section ReserveAssembly

variable {ι G : Type*} [AddCommGroup G]

/-- Assemble a remainder selection with a correction using disjoint reserve
copies. This is the witness-assembly step, not the geometric rounding step,
of Lemma 3.5. -/
theorem reserve_correction (v : ι → G) {R s : Finset ι} {t : G}
    (hdisj : Disjoint R s)
    (hc : ∃ r : Finset ι, r ⊆ R ∧ (∑ i ∈ r, v i) = t - ∑ i ∈ s, v i) :
    t ∈ subsetSums v := by
  classical
  rcases hc with ⟨r, hr, heq⟩
  refine ⟨r ∪ s, ?_⟩
  rw [Finset.sum_union (hdisj.mono_left hr), heq]
  abel

/-- Filled corrections and rounded remainder selections imply that a whole
region is attainable. The hypotheses explicitly separate the finite reserve
filling certificate from the geometric rounding obligation of Lemma 3.5. -/
theorem reserve_filling_glue (v : ι → G) {R B : Finset ι} (hdisj : Disjoint R B)
    (D K : Set G)
    (hfill : ∀ c ∈ D, ∃ r : Finset ι, r ⊆ R ∧ (∑ i ∈ r, v i) = c)
    (hround : ∀ t ∈ K, ∃ s : Finset ι, s ⊆ B ∧ t - (∑ i ∈ s, v i) ∈ D) :
    K ⊆ subsetSums v := by
  intro t ht
  rcases hround t ht with ⟨s, hs, hc⟩
  exact reserve_correction v (hdisj.mono_right hs) (hfill _ hc)

end ReserveAssembly

section CoordinateBounds

variable {ι : Type*} {d : ℕ}

/-- Membership in a symmetric integer coordinate box. -/
def InBox (p x : IntVec d) : Prop := ∀ j, |x j| ≤ p j

/-- Absolute coordinate contributions of a specified set of input copies. -/
def AbsoluteBudget (v : ι → IntVec d) (s : Finset ι) (Δ : IntVec d) : Prop :=
  ∀ j, (∑ i ∈ s, |v i j|) ≤ Δ j

/-- Every partial selection of a budgeted witness satisfies the same budget. -/
theorem absoluteBudget_mono (v : ι → IntVec d) {s t : Finset ι} {Δ : IntVec d}
    (hst : s ⊆ t) (ht : AbsoluteBudget v t Δ) : AbsoluteBudget v s Δ := by
  intro j
  exact (Finset.sum_le_sum_of_subset_of_nonneg hst
    (fun _ _ _ => abs_nonneg _)).trans (ht j)

/-- Coordinate cancellation can only make the resulting vector smaller. -/
theorem sum_inBox_of_absoluteBudget (v : ι → IntVec d) {s : Finset ι}
    {Δ : IntVec d} (h : AbsoluteBudget v s Δ) :
    InBox Δ (∑ i ∈ s, v i) := by
  intro j
  simp only [Finset.sum_apply]
  exact (Finset.abs_sum_le_sum_abs (fun i => v i j) s).trans (h j)

/-- This is the deterministic reason intermediate clipping preserves a
fixed absolute-budget witness in Appendix A. -/
theorem partial_sum_inBox (v : ι → IntVec d) {s t : Finset ι} {Δ : IntVec d}
    (hst : s ⊆ t) (ht : AbsoluteBudget v t Δ) :
    InBox Δ (∑ i ∈ s, v i) :=
  sum_inBox_of_absoluteBudget v (absoluteBudget_mono v hst ht)

theorem absoluteBudget_of_item_bounds (v : ι → IntVec d) (s : Finset ι)
    {p : IntVec d} (h : ∀ i ∈ s, InBox p (v i)) :
    AbsoluteBudget v s (fun j => (s.card : ℤ) * p j) := by
  intro j
  simpa only [nsmul_eq_mul] using
    (Finset.sum_le_card_nsmul s (fun i => |v i j|) (p j) (fun i hi => h i hi j))

/-- A selection of at most `n` items in `P` lies in the dilated box `n P`. -/
theorem subset_sum_inBox_card (v : ι → IntVec d) (s : Finset ι)
    {p : IntVec d} (h : ∀ i, InBox p (v i)) :
    InBox (fun j => (s.card : ℤ) * p j) (∑ i ∈ s, v i) :=
  sum_inBox_of_absoluteBudget v
    (absoluteBudget_of_item_bounds v s (fun i _ => h i))

variable [Fintype ι]

/-- The full support fits in the coordinatewise sum of item-width bounds. -/
theorem subsetSums_inBox (v : ι → IntVec d) {p : IntVec d}
    (hp : ∀ j, 0 ≤ p j) (h : ∀ i, InBox p (v i))
    {t : IntVec d} (ht : t ∈ subsetSums v) :
    InBox (fun j => (Fintype.card ι : ℤ) * p j) t := by
  rcases ht with ⟨s, rfl⟩
  intro j
  exact (subset_sum_inBox_card v s h j).trans
    (mul_le_mul_of_nonneg_right (by exact_mod_cast s.card_le_univ) (hp j))

/-- The geometric part of the small-instance rule (Lemma 2.3): when at most
`τ` copies remain, every attainable sum lies in the allocated `τ P` shape. -/
theorem small_instance_inBox (v : ι → IntVec d) {p : IntVec d} {τ : ℕ}
    (hn : Fintype.card ι ≤ τ) (hp : ∀ j, 0 ≤ p j) (h : ∀ i, InBox p (v i))
    {t : IntVec d} (ht : t ∈ subsetSums v) :
    InBox (fun j => (τ : ℤ) * p j) t := by
  intro j
  exact (subsetSums_inBox v hp h ht j).trans
    (mul_le_mul_of_nonneg_right (by exact_mod_cast hn) (hp j))

/-- Coordinatewise attainable intervals, used for sound target clipping. -/
def InAttainableIntervals (v : ι → IntVec d) (t : IntVec d) : Prop :=
  ∀ j, (∑ i, min 0 (v i j)) ≤ t j ∧ t j ≤ ∑ i, max 0 (v i j)

theorem subsetSums_inAttainableIntervals (v : ι → IntVec d)
    {t : IntVec d} (ht : t ∈ subsetSums v) : InAttainableIntervals v t := by
  classical
  rcases ht with ⟨s, rfl⟩
  intro j
  simp only [Finset.sum_apply]
  have hlo : (∑ i, min 0 (v i j)) ≤ ∑ i, if i ∈ s then v i j else 0 := by
    apply Finset.sum_le_sum
    intro i _
    split_ifs
    · exact min_le_right _ _
    · exact min_le_left _ _
  have hhi : (∑ i, if i ∈ s then v i j else 0) ≤ ∑ i, max 0 (v i j) := by
    apply Finset.sum_le_sum
    intro i _
    split_ifs
    · exact le_max_right _ _
    · exact le_max_left _ _
  simpa only [Finset.sum_ite_mem, Finset.univ_inter] using And.intro hlo hhi

/-- Removing targets outside these intervals preserves exact feasibility. -/
theorem clip_targets_iff (v : ι → IntVec d) (T : Set (IntVec d)) :
    (∃ t ∈ T, t ∈ subsetSums v) ↔
      ∃ t ∈ T ∩ {t | InAttainableIntervals v t}, t ∈ subsetSums v := by
  constructor
  · rintro ⟨t, ht, hs⟩
    exact ⟨t, ⟨ht, subsetSums_inAttainableIntervals v hs⟩, hs⟩
  · rintro ⟨t, ht, hs⟩
    exact ⟨t, ht.1, hs⟩

end CoordinateBounds

end Optss
