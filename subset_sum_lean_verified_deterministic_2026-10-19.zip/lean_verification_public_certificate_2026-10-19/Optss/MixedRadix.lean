import Optss.Basic
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.Group.Pointwise.Finset.Basic
import Mathlib.Algebra.Order.BigOperators.Ring.Finset

/-!
# Additive mixed-radix encoding

This file proves the elementary encoding step in equation (35) and Lemma 10.4.
Widths are natural numbers, so zero-width coordinates are allowed and the
nonnegativity of all widths is built into the interface. The map is additive on
the whole lattice and injective on its specified centered box. No long-sumset
comparison or asymptotic threshold is assumed or asserted here.
-/

namespace Optss

open scoped BigOperators Pointwise

/-- Membership in an integer box centered at zero. -/
def InCenteredBox {d : ℕ} (m : Fin d → ℕ) (x : IntVec d) : Prop :=
  ∀ i, |x i| ≤ (m i : ℤ)

/-- The first coordinate is the least significant digit, with radix `2m + 1`.
The recursion gives the positional formula used in the manuscript. -/
def mixedRadix : {d : ℕ} → (Fin d → ℕ) → IntVec d → ℤ
  | 0, _, _ => 0
  | _ + 1, m, x => x 0 + (2 * (m 0 : ℤ) + 1) *
      mixedRadix (fun i => m i.succ) (fun i => x i.succ)

@[simp] theorem mixedRadix_zero {d : ℕ} (m : Fin d → ℕ) :
    mixedRadix m 0 = 0 := by
  induction d with
  | zero => rfl
  | succ d ih =>
      have ht := ih (fun i => m i.succ)
      change mixedRadix (fun i => m i.succ) (fun _ => 0) = 0 at ht
      simp only [mixedRadix, Pi.zero_apply, ht, mul_zero, add_zero]

theorem mixedRadix_add {d : ℕ} (m : Fin d → ℕ) (x y : IntVec d) :
    mixedRadix m (x + y) = mixedRadix m x + mixedRadix m y := by
  induction d with
  | zero => simp [mixedRadix]
  | succ d ih =>
      have ht := ih (fun i => m i.succ) (fun i => x i.succ) (fun i => y i.succ)
      change mixedRadix (fun i => m i.succ) (fun i => x i.succ + y i.succ) = _ at ht
      simp only [mixedRadix, Pi.add_apply]
      rw [ht]
      ring

/-- The encoder is a homomorphism before restricting to any box. -/
def mixedRadixHom {d : ℕ} (m : Fin d → ℕ) : IntVec d →+ ℤ where
  toFun := mixedRadix m
  map_zero' := mixedRadix_zero m
  map_add' := mixedRadix_add m

private theorem centered_digit_unique (m : ℕ) (a b u v : ℤ)
    (ha : |a| ≤ (m : ℤ)) (hb : |b| ≤ (m : ℤ))
    (he : a + (2 * (m : ℤ) + 1) * u = b + (2 * (m : ℤ) + 1) * v) :
    a = b ∧ u = v := by
  rcases abs_le.mp ha with ⟨ha₁, ha₂⟩
  rcases abs_le.mp hb with ⟨hb₁, hb₂⟩
  have hm : (0 : ℤ) ≤ m := Int.natCast_nonneg m
  have huv : u = v := by
    by_contra h
    rcases lt_or_gt_of_ne h with h | h
    · have : u + 1 ≤ v := by omega
      nlinarith
    · have : v + 1 ≤ u := by omega
      nlinarith
  exact ⟨by rw [huv] at he; omega, huv⟩

/-- Successive centered digits are uniquely determined by the encoded integer.
In particular radix one, corresponding to a zero-width coordinate, is harmless. -/
theorem mixedRadix_injective_on_box {d : ℕ} (m : Fin d → ℕ)
    {x y : IntVec d} (hx : InCenteredBox m x) (hy : InCenteredBox m y)
    (he : mixedRadix m x = mixedRadix m y) : x = y := by
  induction d with
  | zero => exact Subsingleton.elim _ _
  | succ d ih =>
      obtain ⟨hhead, htail⟩ := centered_digit_unique (m 0) (x 0) (y 0)
        (mixedRadix (fun i => m i.succ) (fun i => x i.succ))
        (mixedRadix (fun i => m i.succ) (fun i => y i.succ)) (hx 0) (hy 0) he
      have ht := ih (fun i => m i.succ) (fun i => hx i.succ)
        (fun i => hy i.succ) htail
      funext i
      refine Fin.cases hhead (fun j => ?_) i
      exact congrFun ht j

/-- Encoding a finite set contained in the box preserves its cardinality. -/
theorem mixedRadix_image_card {d : ℕ} (m : Fin d → ℕ)
    (S : Finset (IntVec d)) (hS : ∀ x ∈ S, InCenteredBox m x) :
    (S.image (mixedRadix m)).card = S.card := by
  classical
  apply Finset.card_image_iff.mpr
  intro x hx y hy he
  exact mixedRadix_injective_on_box m (hS x hx) (hS y hy) he

/-- A telescoping positional bound: enlarging the encoding box by `H` does not
enlarge the original item coordinates. This is the arithmetic behind (35). -/
theorem mixedRadix_scaled_bound {d : ℕ} (H : ℕ) (m : Fin d → ℕ)
    {x : IntVec d} (hx : InCenteredBox m x) :
    2 * (H : ℤ) * |mixedRadix (fun i => H * m i) x| + 1 ≤
      ∏ i, (2 * (H : ℤ) * (m i : ℤ) + 1) := by
  induction d with
  | zero => simp [mixedRadix]
  | succ d ih =>
      have ht := ih (fun i => m i.succ) (fun i => hx i.succ)
      have hH : (0 : ℤ) ≤ H := Int.natCast_nonneg H
      have hm : (0 : ℤ) ≤ m 0 := Int.natCast_nonneg (m 0)
      have hb : 0 ≤ 2 * (H : ℤ) * (m 0 : ℤ) + 1 := by positivity
      have habs := abs_add_le (x 0)
        ((2 * (H : ℤ) * (m 0 : ℤ) + 1) *
          mixedRadix (fun i => H * m i.succ) (fun i => x i.succ))
      rw [abs_mul, abs_of_nonneg hb] at habs
      have hhead := hx 0
      rw [Fin.prod_univ_succ]
      simp only [mixedRadix, Nat.cast_mul, ← mul_assoc]
      nlinarith [mul_nonneg hH (sub_nonneg.mpr habs),
        mul_nonneg hb (sub_nonneg.mpr ht)]

/-- An explicit polynomial scalar item bound with the exponent `d - 1` from
equation (35). Taking `H = 4k` gives the encoding used in Lemma 10.4. -/
theorem mixedRadix_item_bound {d : ℕ} (H : ℕ) (hH : 1 ≤ H)
    (m : Fin d → ℕ) {x : IntVec d} (hx : InCenteredBox m x) :
    |mixedRadix (fun i => H * m i) x| ≤
      (2 * (H : ℤ)) ^ (d - 1) * ∏ i, ((m i : ℤ) + 1) := by
  cases d with
  | zero => simp [mixedRadix]
  | succ d =>
      have hH' : (1 : ℤ) ≤ H := by exact_mod_cast hH
      have hrad : ∏ i, (2 * (H : ℤ) * (m i : ℤ) + 1) ≤
          (2 * (H : ℤ)) ^ (d + 1) * ∏ i, ((m i : ℤ) + 1) := by
        calc
          _ ≤ ∏ i, ((2 * (H : ℤ)) * ((m i : ℤ) + 1)) := by
            apply Finset.prod_le_prod
            · intro i _
              positivity
            · intro i _
              nlinarith
          _ = _ := by rw [Finset.prod_mul_distrib]; simp
      have ht := (mixedRadix_scaled_bound H m hx).trans hrad
      simp only [Nat.add_sub_cancel, pow_succ] at *
      nlinarith

/-- The diameter version of the item bound, valid for any two original items. -/
theorem mixedRadix_diameter_bound {d : ℕ} (H : ℕ) (hH : 1 ≤ H)
    (m : Fin d → ℕ) {x y : IntVec d}
    (hx : InCenteredBox m x) (hy : InCenteredBox m y) :
    |mixedRadix (fun i => H * m i) x - mixedRadix (fun i => H * m i) y| ≤
      2 * ((2 * (H : ℤ)) ^ (d - 1) * ∏ i, ((m i : ℤ) + 1)) := by
  have hx' := mixedRadix_item_bound H hH m hx
  have hy' := mixedRadix_item_bound H hH m hy
  have ht := abs_add_le (mixedRadix (fun i => H * m i) x)
    (-mixedRadix (fun i => H * m i) y)
  rw [abs_neg, ← sub_eq_add_neg] at ht
  linarith

/-- A sum of `n` elements of a box lies in the box with all widths multiplied
by `n`. Here `n • S` is repeated Minkowski addition, allowing repetitions. -/
theorem repeatedSumset_in_box {d : ℕ} (m : Fin d → ℕ)
    (S : Finset (IntVec d)) (hS : ∀ x ∈ S, InCenteredBox m x)
    (n : ℕ) : ∀ x ∈ n • S, InCenteredBox (fun i => n * m i) x := by
  classical
  induction n with
  | zero =>
      intro x hx
      have hx0 : x = 0 := by simpa using hx
      subst x
      simp [InCenteredBox]
  | succ n ih =>
      intro x hx
      rw [succ_nsmul] at hx
      obtain ⟨y, hy, z, hz, rfl⟩ := Finset.mem_add.mp hx
      intro i
      have hyi := ih y hy i
      have hzi := hS z hz i
      simp only [Pi.add_apply]
      calc
        |y i + z i| ≤ |y i| + |z i| := abs_add_le _ _
        _ ≤ (n * m i : ℕ) + (m i : ℤ) := add_le_add hyi hzi
        _ = ((n + 1) * m i : ℕ) := by push_cast; ring

/-- The homomorphism commutes exactly with repeated finite sumsets. -/
theorem mixedRadix_image_repeatedSumset {d : ℕ} (m : Fin d → ℕ)
    (S : Finset (IntVec d)) (n : ℕ) :
    (n • S).image (mixedRadix m) = n • S.image (mixedRadix m) :=
  Finset.image_nsmul (mixedRadixHom m) S n

/-- Use one encoding for every sumset up to length `H`. Their scalar and vector
cardinalities agree exactly, which isolates the reduction step of Lemma 10.4. -/
theorem mixedRadix_repeatedSumset_card {d : ℕ} (m : Fin d → ℕ)
    (S : Finset (IntVec d)) (hS : ∀ x ∈ S, InCenteredBox m x)
    (H n : ℕ) (hn : n ≤ H) :
    (n • S.image (mixedRadix (fun i => H * m i))).card = (n • S).card := by
  rw [← mixedRadix_image_repeatedSumset]
  apply mixedRadix_image_card
  intro x hx i
  exact (repeatedSumset_in_box m S hS n x hx i).trans (by
    exact_mod_cast Nat.mul_le_mul_right (m i) hn)

/-- Translation of a finite scalar sumset preserves its cardinality. This
applies, in particular, to translation by the negative of its minimum. -/
theorem scalar_translate_card (S : Finset ℤ) (a : ℤ) :
    (S.image (fun x => x + a)).card = S.card :=
  Finset.card_image_of_injective _ (add_left_injective a)

/-- Translating the input set translates its `n`-fold sumset by `n` times the
translation, and therefore preserves the repeated-sumset cardinality. -/
theorem scalar_translated_repeatedSumset_card (S : Finset ℤ) (a : ℤ) (n : ℕ) :
    (n • (S + {a})).card = (n • S).card := by
  rw [nsmul_add, Finset.nsmul_singleton, Finset.card_add_singleton]

/-- The complete finite cardinality reduction survives the translation used to
make the scalar set contain zero in Lemma 10.4. -/
theorem mixedRadix_translated_repeatedSumset_card {d : ℕ} (m : Fin d → ℕ)
    (S : Finset (IntVec d)) (hS : ∀ x ∈ S, InCenteredBox m x)
    (H n : ℕ) (hn : n ≤ H) (a : ℤ) :
    (n • (S.image (mixedRadix (fun i => H * m i)) + {a})).card = (n • S).card := by
  rw [scalar_translated_repeatedSumset_card]
  exact mixedRadix_repeatedSumset_card m S hS H n hn

end Optss
