import Optss.DensePeriodSelection

/-!
# Lifting dense integer progressions back into coordinate fibers

Every point on the resulting coordinate progression is a sum of actual
input points. The fixed coordinates are the sum of the chosen fiber
locations; unselected labels are included through the full-family result.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

/-- Sum membership lifts along actual fixed-coordinate fibers. -/
theorem product_fiber_sum_lift {ι G : Type*} [DecidableEq ι] [AddCommGroup G] [DecidableEq G]
    (S : Finset ι) (A : ι → Finset (ℤ × G)) (B : ι → Finset ℤ) (y : ι → G)
    (hB : ∀ i ∈ S, ∀ x ∈ B i, (x, y i) ∈ A i) :
    ∀ x ∈ ∑ i ∈ S, B i, (x, ∑ i ∈ S, y i) ∈ ∑ i ∈ S, A i := by
  induction S using Finset.induction_on with
  | empty => simp
  | @insert i S hi ih =>
    have hrest := ih (fun j hj => hB j (Finset.mem_insert_of_mem hj))
    simp only [Finset.sum_insert hi]
    intro x hx
    obtain ⟨a, ha, b, hb, rfl⟩ := Finset.mem_add.mp hx
    exact Finset.mem_add.mpr ⟨(a, y i), hB i (Finset.mem_insert_self _ _) a ha,
      (b, ∑ j ∈ S, y j), hrest b hb, rfl⟩

/-- A full family of dense subsets of an integer product box has an
actual coordinate progression with a bounded step. -/
theorem dense_product_family_progression {ι G : Type*} [DecidableEq ι]
    [AddCommGroup G] [DecidableEq G]
    (S : Finset ι) (A : ι → Finset (ℤ × G)) (u : ℤ) (N : ℕ) (V : Finset G) (c : ℝ)
    (hc : 0 < c) (hc1 : c ≤ 1) (hN : 4 ≤ c * N) (hV : V.Nonempty)
    (hcount : 20 ≤ c ^ 2 * S.card)
    (hbox : ∀ i ∈ S, A i ⊆ Finset.Icc u (u + N - 1) ×ˢ V)
    (hdense : ∀ i ∈ S, c * N * V.card ≤ (A i).card) :
    ∃ (v t a b : ℤ) (z : G), 0 < v ∧ c * v ≤ 2 ∧
      (Finset.Icc a b).image (fun x => (t + v * x, z)) ⊆ ∑ i ∈ S, A i ∧
      c ^ 2 * S.card * N / 4 ≤ (b - a : ℤ) := by
  have hf : ∀ i : S, ∃ y ∈ V, ∃ (B : Finset ℤ) (v : ℤ),
      (∀ x, x ∈ B ↔ (x, y) ∈ A i.1) ∧ B ⊆ Finset.Icc u (u + N - 1) ∧
      c * N ≤ B.card ∧ 0 < v ∧ c * v ≤ 2 ∧ HasFullIntegerPeriod B v := by
    intro i
    exact dense_product_integer_fiber (A i.1) u N V c hc hN hV (hbox i.1 i.2) (hdense i.1 i.2)
  choose y hy B v hv using hf
  let ys : ι → G := fun i => if hi : i ∈ S then y ⟨i, hi⟩ else 0
  let Bs : ι → Finset ℤ := fun i => if hi : i ∈ S then B ⟨i, hi⟩ else ∅
  have hBs : ∀ i ∈ S, (∀ x, x ∈ Bs i ↔ (x, ys i) ∈ A i) ∧
      Bs i ⊆ Finset.Icc u (u + N - 1) ∧ c * N ≤ (Bs i).card := by
    intro i hi
    have hh := hv ⟨i, hi⟩
    simpa [ys, Bs, hi] using ⟨hh.1, hh.2.1, hh.2.2.1⟩
  obtain ⟨w, t, a, b, hw, hcw, hI, hlong⟩ := dense_integer_family_progression S Bs N c hc hc1 hN hcount
    (fun i hi => (hBs i hi).2.2)
    (fun i hi => ⟨u, (hBs i hi).2.1.trans (Finset.Icc_subset_Icc le_rfl (by omega))⟩)
  refine ⟨w, t, a, b, ∑ i ∈ S, ys i, hw, hcw, ?_, hlong⟩
  intro x hx
  obtain ⟨q, hq, rfl⟩ := Finset.mem_image.mp hx
  apply product_fiber_sum_lift S A Bs ys (fun i hi r hr => (hBs i hi).1 r |>.mp hr)
  exact hI (Finset.mem_image.mpr ⟨q, hq, rfl⟩)

end
end Optss
