import Optss.LatticeReductionBounds
import Optss.ColorPreprocessing

/-!
# A constant-size coefficient search for a short lattice vector

For a basis with bounded orthogonality defect, either a basis vector already
lies in the unit coordinate cube, or every lattice point in that cube has
bounded integral basis coefficients. The bound depends only on dimension
and the supplied defect constant. This is the geometric completeness argument
for finite short-kernel search after lattice reduction.
-/
namespace Optss
open scoped BigOperators
variable {r : ℕ}

def shortVectorCoefficientRadius (r ω : ℕ) : ℕ := r.factorial*ω*r

noncomputable def latticeIntegerSynthesis (b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)))
    (z : Fin r→ℤ) : EuclideanSpace ℝ (Fin r) :=
  ∑ j,(z j:ℝ) •b j

theorem latticeIntegerSynthesis_mem (b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)))
    (z : Fin r→ℤ) : latticeIntegerSynthesis b z∈basisIntegerLattice b :=
  (mem_basisIntegerLattice_iff b _).mpr ⟨z,rfl⟩

theorem latticeIntegerSynthesis_eq_zero_iff (b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)))
    (z : Fin r→ℤ) : latticeIntegerSynthesis b z=0 ↔ z=0 := by
  constructor
  · intro hz
    funext j
    have h := congrArg (fun x => b.repr x j) hz
    simp only [latticeIntegerSynthesis,map_sum,map_smul,Finsupp.finset_sum_apply,
      Finsupp.smul_apply,Basis.repr_self,smul_eq_mul,Finsupp.single_apply,Finset.mul_sum] at h
    have hj : (z j:ℝ)=0 := by simpa using h
    exact_mod_cast hj
  · rintro rfl
    simp [latticeIntegerSynthesis]

theorem bounded_short_vector_coefficients (hr : 0<r)
    (b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r))) (ω : ℕ)
    (hdefect : euclideanOrthogonalityDefect b≤(ω:ℝ))
    (hb : ∀ j,b j∉euclideanCoordinateCube r 1)
    (x : EuclideanSpace ℝ (Fin r)) (hx : x∈euclideanCoordinateCube r 1)
    (hxΛ : x∈basisIntegerLattice b) :
    ∃ z∈integerBudgetBox (fun _ => shortVectorCoefficientRadius r ω),latticeIntegerSynthesis b z=x := by
  obtain ⟨z,hzx⟩ := (mem_basisIntegerLattice_iff b x).mp hxΛ
  refine ⟨z,?_,hzx⟩
  apply (mem_integerBudgetBox _ _).mpr
  intro j
  have hnorm : 1≤‖b j‖ := le_of_lt (lt_of_not_ge (fun h => hb j (mem_cube_of_norm_le h)))
  have hdual := basisDualNormBound_of_orthogonalityDefect b (ω:ℝ) hdefect j x
  have hdiv : ((r.factorial:ℝ)*(ω:ℝ))/‖b j‖≤(r.factorial:ℝ)*(ω:ℝ) :=
    (div_le_iff₀ (lt_of_lt_of_le zero_lt_one hnorm)).mpr (by nlinarith [show (0:ℝ)≤(r.factorial:ℝ)*(ω:ℝ) by positivity])
  have hr1 : (1:ℝ)≤r := by exact_mod_cast hr
  have hsqrt : Real.sqrt (r:ℝ)≤r := by
    have hs := Real.sq_sqrt (Nat.cast_nonneg r : (0:ℝ)≤r)
    have hn := Real.sqrt_nonneg (r:ℝ)
    nlinarith
  have hrepr : b.repr x j=(z j:ℝ) := by
    rw [←hzx]
    simp [Finsupp.single_apply]
  have hbound : |(z j:ℝ)|≤(shortVectorCoefficientRadius r ω:ℝ) := by
    rw [←hrepr]
    calc
      _≤(((r.factorial:ℝ)*(ω:ℝ))/‖b j‖)*‖x‖ := hdual
      _≤((r.factorial:ℝ)*(ω:ℝ))*‖x‖ := mul_le_mul_of_nonneg_right hdiv (norm_nonneg x)
      _≤((r.factorial:ℝ)*(ω:ℝ))*(r:ℝ) := mul_le_mul_of_nonneg_left
        ((norm_le_sqrt_dimension_of_cube hx).trans hsqrt) (by positivity)
      _=(shortVectorCoefficientRadius r ω:ℝ) := by simp [shortVectorCoefficientRadius]
  exact_mod_cast hbound

/-- Completeness of checking the basis vectors and a dimension-only finite
coefficient box. No short-vector existence assumption is placed in the search. -/
theorem exists_short_lattice_vector_iff_bounded_search (hr : 0<r)
    (b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r))) (ω : ℕ)
    (hdefect : euclideanOrthogonalityDefect b≤(ω:ℝ)) :
    (∃ x∈basisIntegerLattice b,x≠0 ∧ x∈euclideanCoordinateCube r 1) ↔
      (∃ j,b j∈euclideanCoordinateCube r 1) ∨
      (∃ z∈integerBudgetBox (fun _ => shortVectorCoefficientRadius r ω),
        z≠0 ∧ latticeIntegerSynthesis b z∈euclideanCoordinateCube r 1) := by
  classical
  constructor
  · rintro ⟨x,hxΛ,hxn,hx⟩
    by_cases hb : ∃ j,b j∈euclideanCoordinateCube r 1
    · exact Or.inl hb
    · have hb' : ∀ j,b j∉euclideanCoordinateCube r 1 := by simpa only [not_exists] using hb
      obtain ⟨z,hz,hzx⟩ := bounded_short_vector_coefficients hr b ω hdefect hb' x hx hxΛ
      refine Or.inr ⟨z,hz,?_,hzx ▸ hx⟩
      intro hz0
      apply hxn
      rw [←hzx,(latticeIntegerSynthesis_eq_zero_iff b z).mpr hz0]
  · rintro (⟨j,hj⟩ | ⟨z,hz,hzn,hzK⟩)
    · refine ⟨b j,?_,b.ne_zero j,hj⟩
      intro i
      refine ⟨if j=i then 1 else 0,?_⟩
      simp [Basis.repr_self,Finsupp.single_apply]
    · exact ⟨latticeIntegerSynthesis b z,latticeIntegerSynthesis_mem b z,
        fun h => hzn ((latticeIntegerSynthesis_eq_zero_iff b z).mp h),hzK⟩

theorem shortVectorCoefficientCandidates_card (r ω : ℕ) :
    (integerBudgetBox (fun _ : Fin r => shortVectorCoefficientRadius r ω)).card=
      (2*shortVectorCoefficientRadius r ω+1)^r := by
  rw [integerBudgetBox_card]
  simp
/-- When the radius is positive the coordinate unit vectors are already
in the same coefficient box, so a single uniform enumeration suffices. -/
theorem exists_short_lattice_vector_iff_coefficient_box (hr : 0<r)
    (b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r))) (ω : ℕ) (hω : 0<ω)
    (hdefect : euclideanOrthogonalityDefect b≤(ω:ℝ)) :
    (∃ x∈basisIntegerLattice b,x≠0 ∧ x∈euclideanCoordinateCube r 1) ↔
      ∃ z∈integerBudgetBox (fun _ => shortVectorCoefficientRadius r ω),
        z≠0 ∧ latticeIntegerSynthesis b z∈euclideanCoordinateCube r 1 := by
  classical
  have hrad : 1≤shortVectorCoefficientRadius r ω := by
    unfold shortVectorCoefficientRadius
    have hfact := Nat.factorial_pos r
    exact Nat.one_le_iff_ne_zero.mpr (by positivity)
  rw [exists_short_lattice_vector_iff_bounded_search hr b ω hdefect]
  constructor
  · rintro (⟨j,hj⟩ | h)
    · have hs : latticeIntegerSynthesis b (Pi.single j (1:ℤ))=b j := by
        simp [latticeIntegerSynthesis,Pi.single_apply]
      refine ⟨Pi.single j 1,?_,?_,hs ▸ hj⟩
      · apply (mem_integerBudgetBox _ _).mpr
        intro i
        by_cases hi : i=j
        · subst i
          simpa using (show (1:ℤ)≤(shortVectorCoefficientRadius r ω:ℤ) by exact_mod_cast hrad)
        · simp [Pi.single_apply,hi,Ne.symm hi]
      · intro hzero
        have h := congrFun hzero j
        simp at h
    · exact h
  · exact Or.inr

end Optss
