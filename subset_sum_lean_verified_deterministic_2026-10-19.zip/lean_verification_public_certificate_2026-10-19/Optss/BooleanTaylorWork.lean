import Optss.BooleanFourierPreparationWork

/-! Polynomial work for the actual two-component Boolean Taylor evaluator.
Operand bounds are derived from the supplied input rational height and
proved finite-sum height bounds, including all accumulator prefixes. -/
namespace Optss

theorem RationalBitBound.mono {q : ℚ} {L K : ℕ} (hq : RationalBitBound q L) (hLK : L≤K) :
    RationalBitBound q K := ⟨hq.1.trans hLK,hq.2.trans hLK⟩

def taylorWorkBits (B n : ℕ) : ℕ := (n+1)^2*(B.size+n+3)
def taylorScalarCharge (B n : ℕ) : ℕ := 2048*(taylorWorkBits B n+1)^3

theorem taylorWorkBits_bounds (B n : ℕ) :
    n*B.size+1≤taylorWorkBits B n ∧ (n+1)^2≤taylorWorkBits B n ∧
      (imaginaryPartialHeight B n).size≤taylorWorkBits B n := by
  have hs := imaginaryPartialHeight_bits B n
  have hn := nat_size_le_value n
  have hsize : n*(n*(B.size+n.size)+4)+1≤taylorWorkBits B n := by
    unfold taylorWorkBits
    have hm := Nat.mul_le_mul_left (n*n) hn
    nlinarith
  refine ⟨?_,?_,hs.trans hsize⟩ <;> unfold taylorWorkBits <;> nlinarith

theorem taylorScalarCharge_large (B n : ℕ) :
    259≤taylorScalarCharge B n ∧ 64*(n+1)^2+3≤taylorScalarCharge B n := by
  have h := (taylorWorkBits_bounds B n).2.1
  unfold taylorScalarCharge
  have hp : 1≤(taylorWorkBits B n+1)^2 := by nlinarith
  constructor <;> nlinarith

theorem rationalImaginaryPower_bits_uniform (t : FourierFraction) (B n : ℕ)
    (ht : RationalSizeBound t.value B) (j : ℕ) (hj : j≤n) :
    RationalBitBound (bitImaginaryPower t j).1.value (taylorWorkBits B n) ∧
      RationalBitBound (bitImaginaryPower t j).2.value (taylorWorkBits B n) := by
  have h := rationalImaginaryPower_height t.value B ht j
  have hs : (B^j).size≤taylorWorkBits B n :=
    (nat_power_size_le B j).trans ((by nlinarith : j*B.size+1≤n*B.size+1).trans (taylorWorkBits_bounds B n).1)
  have hre := congrArg Prod.fst (bitImaginaryPower_value t j)
  have him := congrArg Prod.snd (bitImaginaryPower_value t j)
  dsimp only at hre him
  rw [hre,him]
  exact ⟨h.1.bitBound.mono hs,h.2.bitBound.mono hs⟩

theorem fourierNat_bits_uniform (B n j : ℕ) (hj : j≤n) :
    RationalBitBound (FourierFraction.nat j).value (taylorWorkBits B n) := by
  rw [FourierFraction.nat_value]
  have hb := RationalSizeBound.natCast j (n+1) (by omega) (by omega)
  apply hb.bitBound.mono
  have hs := nat_size_le_value (n+1)
  have h := (taylorWorkBits_bounds B n).2.1
  nlinarith

theorem fourierFactorial_bits_uniform (B n j : ℕ) (hj : j≤n) :
    RationalBitBound (bitFourierFactorial j).value (taylorWorkBits B n) := by
  rw [bitFourierFactorial_value]
  have hb := RationalSizeBound.natCast j.factorial n.factorial (Nat.factorial_pos n) (Nat.factorial_le hj)
  apply hb.bitBound.mono
  have hs := (Nat.size_le_size (Nat.factorial_le_pow n)).trans (nat_power_size_le n n)
  have hn := nat_size_le_value n
  have h := (taylorWorkBits_bounds B n).2.1
  nlinarith

theorem bitFourierFactorialWork_uniform (B n j : ℕ) (hj : j≤n) :
    bitFourierFactorialWork j≤(3*j+1)*taylorScalarCharge B n := by
  induction j with
  | zero =>
    have h := fourierNatFractionWork_bound 1
    have hU := (taylorScalarCharge_large B n).1
    simp only [bitFourierFactorialWork,mul_zero,zero_add,one_mul]
    norm_num at h
    omega
  | succ j ih =>
    have hi := ih (by omega)
    have hnat := fourierNatFractionWork_bound (j+1)
    have hnat' : fourierNatFractionWork (j+1)≤taylorScalarCharge B n := hnat.trans
      ((by gcongr : 64*(j+1+1)^2+3≤64*(n+1)^2+3).trans (taylorScalarCharge_large B n).2)
    have hm := (FourierFraction.nat (j+1)).mulWork_bound (bitFourierFactorial j) (taylorWorkBits B n)
      (fourierNat_bits_uniform B n (j+1) hj) (fourierFactorial_bits_uniform B n j (by omega))
    have hU := (taylorScalarCharge_large B n).1
    change _≤taylorScalarCharge B n at hm
    rw [bitFourierFactorialWork]
    nlinarith

theorem bitImaginaryPowerWork_uniform (t : FourierFraction) (B n : ℕ)
    (ht : RationalSizeBound t.value B) (j : ℕ) (hj : j≤n) :
    bitImaginaryPowerWork t j≤(3*j+2)*taylorScalarCharge B n := by
  have hU := (taylorScalarCharge_large B n).1
  have htbits : RationalBitBound t.value (taylorWorkBits B n) := by
    apply ht.bitBound.mono
    unfold taylorWorkBits
    have hpow : 1≤(n+1)^2 := by nlinarith
    have hmul := Nat.mul_le_mul_right (B.size+n+3) hpow
    nlinarith
  induction j with
  | zero =>
    have h₀ := fourierNatFractionWork_bound 0
    have h₁ := fourierNatFractionWork_bound 1
    simp only [bitImaginaryPowerWork,mul_zero,zero_add]
    norm_num at h₀ h₁
    nlinarith
  | succ j ih =>
    have hi := ih (by omega)
    have hb := rationalImaginaryPower_bits_uniform t B n ht j (by omega)
    have hre := t.neg.mulWork_bound (bitImaginaryPower t j).2 (taylorWorkBits B n)
      (by simpa only [FourierFraction.neg_value] using htbits.neg) hb.2
    have him := t.mulWork_bound (bitImaginaryPower t j).1 (taylorWorkBits B n) htbits hb.1
    change _≤taylorScalarCharge B n at hre him
    rw [bitImaginaryPowerWork]
    nlinarith

theorem bitImaginaryTermWork_uniform (t : FourierFraction) (B n : ℕ)
    (ht : RationalSizeBound t.value B) (imaginary : Bool) (j : ℕ) (hj : j<n) :
    bitImaginaryTermWork t imaginary j≤(6*n+5)*taylorScalarCharge B n := by
  have hp := bitImaginaryPowerWork_uniform t B n ht j hj.le
  have hf := bitFourierFactorialWork_uniform B n j hj.le
  have hb := rationalImaginaryPower_bits_uniform t B n ht j hj.le
  have hd := fourierFactorial_bits_uniform B n j hj.le
  have hU := (taylorScalarCharge_large B n).1
  unfold bitImaginaryTermWork
  cases imaginary <;> simp only [Bool.false_eq_true,↓reduceIte]
  · have hdiv := (bitImaginaryPower t j).1.divWork_bound (bitFourierFactorial j) (taylorWorkBits B n) hb.1 hd
    change _≤taylorScalarCharge B n at hdiv
    nlinarith
  · have hdiv := (bitImaginaryPower t j).2.divWork_bound (bitFourierFactorial j) (taylorWorkBits B n) hb.2 hd
    change _≤taylorScalarCharge B n at hdiv
    nlinarith

theorem bitImaginaryExpPartialWork_bound (t : FourierFraction) (B n : ℕ)
    (ht : RationalSizeBound t.value B) :
    bitImaginaryExpPartialWork t n≤32768*(n+1)^2*(taylorWorkBits B n+1)^3 := by
  let L := taylorWorkBits B n
  let U := taylorScalarCharge B n
  have hU : 259≤U := (taylorScalarCharge_large B n).1
  have hbase : fourierNatFractionWork 0≤U := by
    have h := fourierNatFractionWork_bound 0
    norm_num at h
    omega
  have hpbits : ∀ j<n, RationalBitBound ((bitImaginaryPower t j).1.div (bitFourierFactorial j)).value L ∧
      RationalBitBound ((bitImaginaryPower t j).2.div (bitFourierFactorial j)).value L := by
    intro j hj
    have h := rationalImaginaryTerm_height t.value B n j ht hj
    have hb : (imaginaryTermHeight B n).size≤L := by
      have hf := (Nat.size_le_size (Nat.factorial_le_pow n)).trans (nat_power_size_le n n)
      have hn := nat_size_le_value n
      have hp := nat_power_size_le B n
      have hm := nat_mul_size_le (B^n) n.factorial
      dsimp [L,taylorWorkBits,imaginaryTermHeight]
      nlinarith
    have hre := congrArg Prod.fst (bitImaginaryPower_value t j)
    have him := congrArg Prod.snd (bitImaginaryPower_value t j)
    dsimp only at hre him
    simp only [FourierFraction.div_value,bitFourierFactorial_value,hre,him]
    exact ⟨h.1.bitBound.mono hb,h.2.bitBound.mono hb⟩
  have hsum : ∀ j≤n,
      RationalBitBound (fourierFractionSum (fun i => (bitImaginaryPower t i).1.div (bitFourierFactorial i)) j).value L ∧
      RationalBitBound (fourierFractionSum (fun i => (bitImaginaryPower t i).2.div (bitFourierFactorial i)) j).value L := by
    intro j hj
    have h := rationalImaginaryPartialSum_height t.value B n ht (Finset.range j) (Finset.range_mono hj)
    have hb := (taylorWorkBits_bounds B n).2.2
    have hre i := congrArg Prod.fst (bitImaginaryPower_value t i)
    have him i := congrArg Prod.snd (bitImaginaryPower_value t i)
    dsimp only at hre him
    simp only [fourierFractionSum_value,FourierFraction.div_value,bitFourierFactorial_value,hre,him]
    exact ⟨h.1.bitBound.mono hb,h.2.bitBound.mono hb⟩
  have hre := fourierFractionSumWork_uniform
    (fun j => (bitImaginaryPower t j).1.div (bitFourierFactorial j)) (bitImaginaryTermWork t false)
    n L ((6*n+5)*U) (fun j hj => bitImaginaryTermWork_uniform t B n ht false j hj)
    (fun j hj => (hpbits j hj).1) (fun j hj => (hsum j hj).1)
  have him := fourierFractionSumWork_uniform
    (fun j => (bitImaginaryPower t j).2.div (bitFourierFactorial j)) (bitImaginaryTermWork t true)
    n L ((6*n+5)*U) (fun j hj => bitImaginaryTermWork_uniform t B n ht true j hj)
    (fun j hj => (hpbits j hj).2) (fun j hj => (hsum j hj).2)
  change _≤fourierNatFractionWork 0+n*((6*n+5)*U+U+1) at hre him
  have he : 32768*(n+1)^2*(taylorWorkBits B n+1)^3=16*(n+1)^2*U := by dsimp [U,taylorScalarCharge]; ring
  rw [he,bitImaginaryExpPartialWork]
  nlinarith

end Optss
