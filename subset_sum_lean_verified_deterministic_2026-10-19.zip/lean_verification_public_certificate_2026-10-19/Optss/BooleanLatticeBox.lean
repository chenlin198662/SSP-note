import Optss.BooleanLatticePullback
import Optss.ExactLatticeBoxingWidths
import Optss.PolytopeLatticeBoxing

/-!
# The actual rational-polytope lattice box

The result consists of stored rational columns in the original space and
stored positive integer widths. The widths are computed from those exact
columns and the original vertex list. The specification proves containment
and uniform dilated lattice counting for this returned box.
-/
namespace Optss
open scoped BigOperators Pointwise
variable {r m : ℕ}

noncomputable def storedVertexHull (V : ListBitRationalMatrixData r m) : Set (Fin r → ℝ) :=
  convexHull ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))

theorem storedVertexHull_compact (V : ListBitRationalMatrixData r m) : IsCompact (storedVertexHull V) :=
  (rationalVertexSet (storedRationalVertices V)).finite_toSet.isCompact_convexHull

structure BooleanLatticeBoxResult (r : ℕ) where
  columns : ListBitRationalMatrixData r r
  widths : BooleanListArray (List Bool) r

def decodedLatticeBoxWidths (box : BooleanLatticeBoxResult r) (i : Fin r) : ℕ :=
  binaryDigitsValue (box.widths.toVector.get i)

def booleanLatticeBoxFinish (V : ListBitRationalMatrixData r m) (out : BooleanLatticeFrontendResult r m) :
    BooleanLatticeBoxResult r :=
  let B := booleanLatticePullback out.selectedColumns out.reducedLatticeRows
  ⟨B,computedBasisWidths B V⟩

def booleanLatticeBoxFinishWork (V : ListBitRationalMatrixData r m) (out : BooleanLatticeFrontendResult r m) : ℕ :=
  let B := booleanLatticePullback out.selectedColumns out.reducedLatticeRows
  booleanLatticePullbackWork out.selectedColumns out.reducedLatticeRows+computedBasisWidthsWork B V+1

def booleanLatticeBox (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r) :
    Option (BooleanLatticeBoxResult r) :=
  (booleanLatticeFrontend V G).map (booleanLatticeBoxFinish V)

def booleanLatticeBoxWork (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r) : ℕ :=
  booleanLatticeFrontendWork V G+(match booleanLatticeFrontend V G with
    | none => 1
    | some out => booleanLatticeBoxFinishWork V out+1)

/-- All substantive geometric and lattice hypotheses in Appendix B.1.
Independent points need only be witnesses in the original full input
lattice and body; they are never substituted for its lattice basis. -/
theorem booleanLatticeBox_spec (hr : 0<r)
    (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetG : (storedRationalMatrix G).det≠0)
    (hsym : ∀ y∈rationalVertexSet (storedRationalVertices V),-y∈rationalVertexSet (storedRationalVertices V))
    (x : Fin r → (Fin r → ℝ)) (hind : LinearIndependent ℝ x)
    (hxK : ∀ i,x i∈storedVertexHull V)
    (hxΛ : ∀ i,x i∈Submodule.span ℤ (Set.range (fun j i => (storedRationalMatrix G i j:ℝ)))) :
    ∃ box,booleanLatticeBox V G=some box ∧
      ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
        (∀ i j,(storedRationalMatrix box.columns i j:ℝ)=b j i) ∧
        basisIntegerLattice b=(Submodule.span ℤ (Set.range (fun j i => (storedRationalMatrix G i j:ℝ))) : Set _) ∧
        (∀ j,BitListCanonical (box.widths.toVector.get j)) ∧
        (∀ j,1≤decodedLatticeBoxWidths box j) ∧
        storedVertexHull V ⊆
          basisCoefficientBox b (decodedLatticeBoxWidths box) ∧
        basisCoefficientBox b (decodedLatticeBoxWidths box) ⊆
          latticeBoxingDilation r ((r.factorial:ℝ)*sharpLatticeDefectBound r) •
            storedVertexHull V ∧
        ∀ s : ℝ,(basisLatticePoints b (s • basisCoefficientBox b (decodedLatticeBoxWidths box))
            ((basisCoefficientBox_compact b _).smul s)).card≤
          (latticeBoxingResidueModulus r (sharpLatticeDefectBound r))^r*
            (basisLatticePoints b (s • storedVertexHull V)
              ((storedVertexHull_compact V).smul s)).card := by
  classical
  let S := rationalVertexSet (storedRationalVertices V)
  let K := convexHull ℝ (S : Set (Fin r → ℝ))
  have hspan := vertices_span_of_independent_hull (Pi.basisFun ℝ (Fin r)) S x hind hxK
  obtain ⟨A,hselected,a,hacols,hinner,houter,_⟩ := bitSelectedVertexMatrix_normalization hr V hV hspan hsym
  have hA := bitSelectedVertexMatrix_wellFormed V hV A hselected
  have hdetA := (rational_basis_inverse a (storedRationalMatrix A) hacols).1
  let out := booleanLatticeFrontendFromBasis A V G
  have hout : booleanLatticeFrontend V G=some out := by rw [booleanLatticeFrontend,hselected]; rfl
  have hfields := booleanLatticeFrontendFromBasis_wellFormed A V G hA hV hG hdetA hdetG
  have hR : ∀ i j,(rectangularListFractionMatrix out.reducedLatticeRows i j).WellFormed := hfields.2.2.2
  obtain ⟨hRspan,reduced,hreduced,hdefect⟩ := booleanLatticeFrontendFromBasis_reduction A V G hA hG hdetA hdetG
  obtain ⟨b,hbcols,hbmap,hbΛ⟩ := booleanLatticePullback_basis A out.reducedLatticeRows (storedRationalMatrix G)
    hA hR a hacols reduced hreduced hRspan
  let B := booleanLatticePullback A out.reducedLatticeRows
  let box := booleanLatticeBoxFinish V out
  have hB : ∀ i j,(rectangularListFractionMatrix B i j).WellFormed :=
    constructedListMatrixMul_wellFormed A _ hA (listStoredMatrixTranspose_wellFormed _ hR)
  have hK : IsCompact K := S.finite_toSet.isCompact_convexHull
  have hne : K.Nonempty := ⟨x ⟨0,hr⟩,hxK ⟨0,hr⟩⟩
  obtain ⟨u,_⟩ := exists_vertex_tuple_det_ne_zero (storedRationalVertices V) hspan
  have hm : 0<m := lt_of_le_of_lt (Nat.zero_le _) (u ⟨0,hr⟩).isLt
  have hwidth : decodedLatticeBoxWidths box=basisIntegerWidth b K hK hne := by
    funext j
    exact computedBasisWidths_eq_basisIntegerWidth b B V hB hV hbcols hm hK hne j
  have hgeo := lattice_boxing_exact_widths_of_normalization hr K hK hne (convex_convexHull ℝ _)
    (symmetric_vertex_hull S hsym) (basisEuclideanNormalization a) hinner houter b
    (sharpLatticeDefectBound r) (sharpLatticeDefectBound_pos r)
    (by rw [hbmap]; exact hdefect) x hind hxK (by intro i; rw [hbΛ]; exact hxΛ i)
  dsimp only at hgeo
  rw [←hwidth] at hgeo
  refine ⟨box,?_,b,hbcols,hbΛ,?_,hgeo⟩
  · rw [booleanLatticeBox,hout]
    rfl
  · intro j
    change BitListCanonical ((computedBasisWidths B V).toVector.get j)
    exact listStoredVertexWidths_canonical _ V (constructedListMatrixInverse_wellFormed B hB) hV j
end Optss
