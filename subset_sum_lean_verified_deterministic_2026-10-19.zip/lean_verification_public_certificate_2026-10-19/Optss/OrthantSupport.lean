import Optss.Enumeration

/-!
# Sound recombination of partitioned correction supports

A part contributes a subset of its own labelled items. Recombining the parts
therefore never reuses a label. Every witness with the global cardinality and
absolute-coordinate budgets survives local restrictions and intermediate box
clipping. Arbitrary output need not obey the global cardinality cap.
-/
namespace Optss
open scoped BigOperators Classical
noncomputable section

variable {ι κ : Type*} {d : ℕ} [Fintype ι] [Fintype κ]

/-- A local selection uses only one partition fiber, at most `kcap` labels,
and the prescribed absolute-coordinate budgets. -/
def LocalPartitionSelection (v : ι → IntVec d) (f : ι → κ)
    (Δ : IntVec d) (kcap : ℕ) (p : κ) (s : Finset ι) : Prop :=
  s ⊆ Finset.univ.filter (fun i => f i = p) ∧
    s.card ≤ kcap ∧ AbsoluteBudget v s Δ

/-- The sums obtained by choosing one permitted local selection from each part. -/
def partitionSupport (v : ι → IntVec d) (f : ι → κ)
    (Δ : IntVec d) (kcap : ℕ) : Set (IntVec d) :=
  {t | ∃ s : κ → Finset ι, (∀ p, LocalPartitionSelection v f Δ kcap p (s p)) ∧
    (∑ p, ∑ i ∈ s p, v i) = t}

/-- The support after clipping the recombined vectors to the output box. -/
def clippedPartitionSupport (v : ι → IntVec d) (f : ι → κ)
    (Δ : IntVec d) (kcap : ℕ) : Set (IntVec d) :=
  partitionSupport v f Δ kcap ∩ {t | InBox Δ t}

/-- Selections from distinct partition fibers are disjoint on actual item labels. -/
theorem partition_selections_disjoint (f : ι → κ) (s : κ → Finset ι)
    (hs : ∀ p, s p ⊆ Finset.univ.filter (fun i => f i = p)) :
    (Finset.univ : Finset κ).toSet.PairwiseDisjoint s := by
  intro p _ q _ hpq
  apply Finset.disjoint_left.2
  intro i hip hiq
  have hfp := (Finset.mem_filter.mp (hs p hip)).2
  have hfq := (Finset.mem_filter.mp (hs q hiq)).2
  exact hpq (hfp.symm.trans hfq)

/-- Every produced sum is a genuine subset sum of the original labelled items. -/
theorem partitionSupport_sound (v : ι → IntVec d) (f : ι → κ)
    (Δ : IntVec d) (kcap : ℕ) : partitionSupport v f Δ kcap ⊆ subsetSums v := by
  rintro t ⟨s, hs, hsum⟩
  refine ⟨Finset.univ.biUnion s, ?_⟩
  exact (Finset.sum_biUnion (partition_selections_disjoint f s (fun p => (hs p).1))).trans hsum

/-- Clipped outputs satisfy both required soundness conditions. -/
theorem clippedPartitionSupport_sound (v : ι → IntVec d) (f : ι → κ)
    (Δ : IntVec d) (kcap : ℕ) :
    clippedPartitionSupport v f Δ kcap ⊆ subsetSums v ∩ {t | InBox Δ t} := by
  rintro t ⟨ht, hbox⟩
  exact ⟨partitionSupport_sound v f Δ kcap ht, hbox⟩

omit [Fintype κ] in
/-- Restricting a required witness to any partition part meets all local budgets. -/
theorem witness_partition_local (v : ι → IntVec d) (f : ι → κ)
    {s : Finset ι} {Δ : IntVec d} {kcap : ℕ}
    (hcard : s.card ≤ kcap) (hbudget : AbsoluteBudget v s Δ) (p : κ) :
    LocalPartitionSelection v f Δ kcap p (s.filter (fun i => f i = p)) := by
  refine ⟨?_, (Finset.card_filter_le _ _).trans hcard,
    absoluteBudget_mono v (Finset.filter_subset _ _) hbudget⟩
  intro i hi
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, (Finset.mem_filter.mp hi).2⟩

/-- Every required global witness occurs in the recombined support. -/
theorem partitionSupport_complete (v : ι → IntVec d) (f : ι → κ)
    {s : Finset ι} {Δ : IntVec d} {kcap : ℕ}
    (hcard : s.card ≤ kcap) (hbudget : AbsoluteBudget v s Δ) :
    (∑ i ∈ s, v i) ∈ partitionSupport v f Δ kcap := by
  exact ⟨fun p => s.filter (fun i => f i = p),
    witness_partition_local v f hcard hbudget, Finset.sum_fiberwise s f v⟩

/-- Final box clipping retains every witness covered by the stated budgets. -/
theorem clippedPartitionSupport_complete (v : ι → IntVec d) (f : ι → κ)
    {s : Finset ι} {Δ : IntVec d} {kcap : ℕ}
    (hcard : s.card ≤ kcap) (hbudget : AbsoluteBudget v s Δ) :
    (∑ i ∈ s, v i) ∈ clippedPartitionSupport v f Δ kcap :=
  ⟨partitionSupport_complete v f hcard hbudget, sum_inBox_of_absoluteBudget v hbudget⟩

omit [Fintype ι] [Fintype κ] in
/-- Every partial combination of the pieces of a required witness lies in the
box. Consequently clipping after any sequence of distinct parts cannot lose it. -/
theorem witness_partition_partial_inBox (v : ι → IntVec d) (f : ι → κ)
    {s : Finset ι} {Δ : IntVec d} (hbudget : AbsoluteBudget v s Δ) (P : Finset κ) :
    InBox Δ (∑ p ∈ P, ∑ i ∈ s.filter (fun i => f i = p), v i) := by
  rw [Finset.sum_fiberwise_eq_sum_filter s P f v]
  exact partial_sum_inBox v (Finset.filter_subset _ _) hbudget

/-- The nonnegative sign is used for zero coordinates, as in Lemma 10.1. -/
def coordinateOrthant (x : IntVec d) : Fin d → Bool := fun j => decide (0 ≤ x j)

omit [Fintype ι] in
/-- In one coordinate orthant, taking absolute values commutes with subset sum. -/
theorem abs_sum_eq_sum_abs_of_orthant (v : ι → IntVec d) (s : Finset ι)
    (p : Fin d → Bool) (hs : ∀ i ∈ s, coordinateOrthant (v i) = p) (j : Fin d) :
    |(∑ i ∈ s, v i) j| = ∑ i ∈ s, |v i j| := by
  simp only [Finset.sum_apply]
  by_cases hp : p j = true
  · have hnonneg : ∀ i ∈ s, 0 ≤ v i j := by
      intro i hi
      have h := congrFun (hs i hi) j
      simpa [coordinateOrthant, hp] using h
    rw [abs_of_nonneg (Finset.sum_nonneg hnonneg)]
    apply Finset.sum_congr rfl
    intro i hi
    exact (abs_of_nonneg (hnonneg i hi)).symm
  · have hnonpos : ∀ i ∈ s, v i j ≤ 0 := by
      intro i hi
      have h := congrFun (hs i hi) j
      have hn : ¬ 0 ≤ v i j := by
        intro hnonneg
        have he : p j = true := by simpa [coordinateOrthant, hnonneg] using h.symm
        exact hp he
      omega
    rw [abs_of_nonpos (Finset.sum_nonpos hnonpos), ← Finset.sum_neg_distrib]
    apply Finset.sum_congr rfl
    intro i hi
    exact (abs_of_nonpos (hnonpos i hi)).symm

omit [Fintype ι] in
/-- For a selection in a single orthant, its absolute budget is exactly the box
bound on its signed sum. This links local nonnegative support to restored signs. -/
theorem absoluteBudget_iff_inBox_of_orthant (v : ι → IntVec d) (s : Finset ι)
    (p : Fin d → Bool) (hs : ∀ i ∈ s, coordinateOrthant (v i) = p) (Δ : IntVec d) :
    AbsoluteBudget v s Δ ↔ InBox Δ (∑ i ∈ s, v i) := by
  unfold AbsoluteBudget InBox
  simp only [abs_sum_eq_sum_abs_of_orthant v s p hs]

end
end Optss
