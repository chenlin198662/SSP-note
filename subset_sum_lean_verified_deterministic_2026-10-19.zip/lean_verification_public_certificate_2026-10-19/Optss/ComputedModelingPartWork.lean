import Optss.ComputedModelingPart

/-!
# Source word work of the eight-part selection

The score is the length of a freshly computed residue-filtered list. The
counter follows both score evaluations in each comparison, so repeated
filtering is explicitly charged. There are exactly eight comparisons.
-/
namespace Optss

def chooseMaxScoreWork {α : Type} (score cost : α→ℕ) (best : α) : List α→ℕ
  | [] => 1
  | x::xs => cost best+cost x+4+
    chooseMaxScoreWork score cost (if score best≤score x then x else best) xs

theorem chooseMaxScoreWork_bound {α : Type} (score cost : α→ℕ) (best : α)
    (xs : List α) (W : ℕ) (hW : ∀ x, cost x≤W) :
    chooseMaxScoreWork score cost best xs≤(2*W+4)*xs.length+1 := by
  induction xs generalizing best with
  | nil => simp [chooseMaxScoreWork]
  | cons x xs ih =>
    have hh := ih (if score best≤score x then x else best)
    simp only [chooseMaxScoreWork,List.length_cons]
    nlinarith [hW best,hW x]

/-- Residue arithmetic, predicate, filter output cell, and length traversal. -/
def computedModelingPartScoreWork (data : List ℤ) : ℕ := 12*(data.length+1)

def computedModelingPartWork (data : List ℤ) (n q : ℕ) : ℕ :=
  chooseMaxScoreWork (fun j => (computedModelingPartAt data n q j).length)
    (fun _ => computedModelingPartScoreWork data) 0 (List.finRange 8)+
    computedModelingPartScoreWork data+32

theorem computedModelingPartWork_bound (data : List ℤ) (n q : ℕ) :
    computedModelingPartWork data n q≤512*(data.length+1) := by
  have h := chooseMaxScoreWork_bound
    (fun j => (computedModelingPartAt data n q j).length)
    (fun _ => computedModelingPartScoreWork data) 0 (List.finRange 8)
    (computedModelingPartScoreWork data) (fun _ => le_rfl)
  simp only [List.length_finRange,computedModelingPartScoreWork] at h
  unfold computedModelingPartWork computedModelingPartScoreWork
  omega

end Optss
