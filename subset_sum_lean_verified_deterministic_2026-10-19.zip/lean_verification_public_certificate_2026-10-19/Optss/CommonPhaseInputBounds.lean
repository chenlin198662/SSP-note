import Optss.CommonPhaseIteration

/-!
# Positive labelled inputs and small common-GAP phases

A nonempty positive input forces positive coordinate rank and a scalar
potential of at least `h+1`. Thus every nonempty large-scale phase meets the
greedy routine's nondegeneracy requirements; the empty phase is handled
explicitly by the zero-dimensional common lattice.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1000000

variable {ι : Type} [DecidableEq ι]

theorem labelled_scalar_potential_bound (scalar : ι → ℤ) (s : Finset ι) (h N : ℕ)
    (hbox : ∀ i ∈ s, scalar i ∈ Finset.Icc 0 (N : ℤ)) :
    (h • insert 0 (s.image scalar)).card ≤ h*N+1 := by
  apply integer_repeated_sumset_card_le
  intro x hx
  rcases Finset.mem_insert.mp hx with rfl | hx
  · simp
  · obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hx
    exact hbox i hi

theorem labelled_positive_potential_lower (scalar : ι → ℤ) (s : Finset ι)
    (hs : s.Nonempty) (hpositive : ∀ i ∈ s, 0 < scalar i) (h : ℕ) :
    h+1 ≤ (h • insert 0 (s.image scalar)).card := by
  obtain ⟨i, hi⟩ := hs
  by_contra hn
  have hz := multiples_in_thin_finset (h • insert 0 (s.image scalar)) h (scalar i)
    (by omega) (fun n hnh => Finset.nsmul_subset_nsmul_right (Finset.mem_insert_self _ _) hnh
      (Finset.nsmul_mem_nsmul (Finset.mem_insert_of_mem (Finset.mem_image_of_mem scalar hi))))
  have hp := hpositive i hi
  omega

theorem CommonGapLabelModel.rank_pos {scalar : ι → ℤ} {s : Finset ι} {h : ℕ}
    (model : CommonGapLabelModel scalar s h) (hs : s.Nonempty)
    (hpositive : ∀ i ∈ s, 0 < scalar i) : 0 < model.rank := by
  obtain ⟨i, hi⟩ := hs
  by_contra hd
  have hd0 : model.rank = 0 := by omega
  have he : model.coordinates i = 0 := by
    ext j
    exact Fin.elim0 (Fin.cast hd0 j)
  have hr := model.represents i hi
  rw [he, map_zero] at hr
  have hp := hpositive i hi
  omega

/-- The exact empty-input common decomposition, including its rank-zero
lattice generation and the actual singleton zero support. -/
def emptyCommonGapDecomposition (scalar : ι → ℤ) (h extra R Ebound Rbound : ℕ) (c : ℝ) :
    CommonGapDecomposition scalar ∅ h extra R Ebound Rbound c := by
  let u : ι → IntVec 0 := fun _ => 0
  have hgen : generatedLattice u ∅ = ⊤ := by
    apply top_unique
    intro x _
    have he : x = 0 := Subsingleton.elim _ _
    rw [he]
    exact AddSubgroup.zero_mem _
  refine {
    rank := 0
    rank_le := Nat.zero_le _
    available := ∅
    reserve := ∅
    remaining := ∅
    available_subset := Finset.Subset.rfl
    reserve_subset := Finset.Subset.rfl
    remaining_eq := by simp
    outlier_bound := by simp
    reserve_bound := by simp
    model := {
      widths := fun j => Fin.elim0 j
      coordinates := u
      projection := 0
      positive := fun j => Fin.elim0 j
      represents := by simp
      boxed := by simp
      reserve_generates := hgen
      remainder_generates := hgen
      rank_protected := ?_
      proper := fun x y _ _ _ => Subsingleton.elim x y
      filled := ?_ } }
  · intro D _
    apply top_unique
    intro x _
    have he : x = 0 := Subsingleton.elim _ _
    rw [he]
    exact Submodule.zero_mem _
  · refine ⟨0, fun z _ => ?_⟩
    have he : z = 0 := Subsingleton.elim _ _
    rw [he, add_zero]
    exact zero_mem_labelledSubsetSupport u ∅

end
end Optss
