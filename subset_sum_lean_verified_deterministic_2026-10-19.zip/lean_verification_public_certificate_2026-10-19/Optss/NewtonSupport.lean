import Optss.Truncation

/-!
# Integer Newton coefficients count actual subset witnesses

The recursively computed, truncated Newton coefficients in §10.1 are integer
counts of fixed-cardinality selections of distinct copy labels. In particular,
their positivity is equivalent to an available-copy witness with the exact
cardinality and coordinate budget. This establishes support correctness,
without asserting a convolution algorithm or a running-time bound.
-/

namespace Optss

open scoped BigOperators

noncomputable section

variable {ι σ : Type*} [Fintype ι]

/-- The finite family of labelled `k`-subsets producing exactly exponent `e`. -/
def fixedCardinalityWitnesses (u : ι → σ →₀ ℕ) (k : ℕ) (e : σ →₀ ℕ) :
    Finset (Finset ι) := by
  classical
  exact ((Finset.univ : Finset ι).powersetCard k).filter
    (fun s => (∑ i ∈ s, u i) = e)

theorem mem_fixedCardinalityWitnesses (u : ι → σ →₀ ℕ) (k : ℕ) (e : σ →₀ ℕ)
    (s : Finset ι) :
    s ∈ fixedCardinalityWitnesses u k e ↔
      s.card = k ∧ (∑ i ∈ s, u i) = e := by
  classical
  simp [fixedCardinalityWitnesses]

/-- Every elementary term is the monomial of the sum of its selected exponents.
This identity holds over the integers used by the actual Newton recurrence. -/
theorem elementaryCoefficient_monomial_expand (u : ι → σ →₀ ℕ) (k : ℕ) :
    elementaryCoefficient (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) k =
      ∑ s ∈ (Finset.univ : Finset ι).powersetCard k,
        MvPolynomial.monomial (∑ i ∈ s, u i) (1 : ℤ) := by
  classical
  unfold elementaryCoefficient
  apply Finset.sum_congr rfl
  intro s _
  exact (MvPolynomial.monomial_sum_one s u).symm

/-- Integer coefficients count labelled subset witnesses, including repeated
exponent vectors at different labels. There is no cancellation in this count. -/
theorem elementaryCoefficient_monomial_coeff (u : ι → σ →₀ ℕ) (k : ℕ)
    (e : σ →₀ ℕ) :
    MvPolynomial.coeff e
        (elementaryCoefficient (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) k) =
      ((fixedCardinalityWitnesses u k e).card : ℤ) := by
  classical
  rw [elementaryCoefficient_monomial_expand, MvPolynomial.coeff_sum]
  simp [fixedCardinalityWitnesses]

theorem elementaryCoefficient_monomial_coeff_nonneg (u : ι → σ →₀ ℕ)
    (k : ℕ) (e : σ →₀ ℕ) :
    0 ≤ MvPolynomial.coeff e
      (elementaryCoefficient (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) k) := by
  rw [elementaryCoefficient_monomial_coeff]
  exact Int.natCast_nonneg _

/-- Positivity of an untruncated elementary coefficient records the exact
number of selected labelled copies, as well as their exponent sum. -/
theorem elementaryCoefficient_monomial_coeff_pos_iff (u : ι → σ →₀ ℕ)
    (k : ℕ) (e : σ →₀ ℕ) :
    0 < MvPolynomial.coeff e
        (elementaryCoefficient (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) k) ↔
      ∃ s : Finset ι, s.card = k ∧ (∑ i ∈ s, u i) = e := by
  rw [elementaryCoefficient_monomial_coeff]
  have hcast : (0 : ℤ) < (fixedCardinalityWitnesses u k e).card ↔
      0 < (fixedCardinalityWitnesses u k e).card := by omega
  rw [hcast, Finset.card_pos]
  simp only [Finset.Nonempty, mem_fixedCardinalityWitnesses]

/-- An exact count formula for the output of the recursive integer Newton
computation. Outside the coordinate budget the computed coefficient is zero. -/
theorem newtonTruncatedCoefficient_monomial_coeff (u : ι → σ →₀ ℕ)
    (Δ e : σ →₀ ℕ) (k : ℕ) :
    MvPolynomial.coeff e
        (newtonTruncatedCoefficient Δ (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) k) =
      if e ≤ Δ then ((fixedCardinalityWitnesses u k e).card : ℤ) else 0 := by
  classical
  rw [newtonTruncatedCoefficient_eq, coeff_truncatePolynomial,
    elementaryCoefficient_monomial_coeff]

theorem newtonTruncatedCoefficient_monomial_coeff_nonneg (u : ι → σ →₀ ℕ)
    (Δ e : σ →₀ ℕ) (k : ℕ) :
    0 ≤ MvPolynomial.coeff e
      (newtonTruncatedCoefficient Δ (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) k) := by
  classical
  rw [newtonTruncatedCoefficient_monomial_coeff]
  split_ifs <;> positivity

/-- Full support correctness of the recursive truncated Newton computation:
positive coefficients are precisely the bounded, fixed-cardinality witnesses. -/
theorem newtonTruncatedCoefficient_monomial_coeff_pos_iff (u : ι → σ →₀ ℕ)
    (Δ e : σ →₀ ℕ) (k : ℕ) :
    0 < MvPolynomial.coeff e
        (newtonTruncatedCoefficient Δ (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) k) ↔
      e ≤ Δ ∧ ∃ s : Finset ι, s.card = k ∧ (∑ i ∈ s, u i) = e := by
  classical
  rw [newtonTruncatedCoefficient_eq, coeff_truncatePolynomial]
  split_ifs with he
  · simp only [he, true_and, elementaryCoefficient_monomial_coeff_pos_iff]
  · simp only [he, false_and, lt_self_iff_false]

/-- Exact zero testing is over the integers: a computed zero means there is no
bounded witness, with no possibility of cancellation modulo a prime. -/
theorem newtonTruncatedCoefficient_monomial_coeff_eq_zero_iff (u : ι → σ →₀ ℕ)
    (Δ e : σ →₀ ℕ) (k : ℕ) :
    MvPolynomial.coeff e
        (newtonTruncatedCoefficient Δ (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) k) = 0 ↔
      ¬(e ≤ Δ ∧ ∃ s : Finset ι, s.card = k ∧ (∑ i ∈ s, u i) = e) := by
  rw [← newtonTruncatedCoefficient_monomial_coeff_pos_iff]
  have hnonneg := newtonTruncatedCoefficient_monomial_coeff_nonneg u Δ e k
  omega

/-- Multiplicity specialization: a type with capacity `c i` has exactly that
many copy labels, and each selected label appears at most once in the witness. -/
theorem newtonTruncatedCoefficient_copies_coeff_pos_iff (c : ι → ℕ)
    (u : ι → σ →₀ ℕ) (Δ e : σ →₀ ℕ) (k : ℕ) :
    0 < MvPolynomial.coeff e
        (newtonTruncatedCoefficient Δ
          (fun p : Σ i, Fin (c i) => MvPolynomial.monomial (u p.1) (1 : ℤ)) k) ↔
      e ≤ Δ ∧ ∃ s : Finset (Σ i, Fin (c i)),
        s.card = k ∧ (∑ p ∈ s, u p.1) = e :=
  newtonTruncatedCoefficient_monomial_coeff_pos_iff (fun p : Σ i, Fin (c i) => u p.1) Δ e k

/-- The polynomial computed by keeping Newton coefficients of cardinalities
zero through `kcap`, as in one nonnegative orthant computation of §10.1. -/
def newtonTruncatedSupport (u : ι → σ →₀ ℕ) (Δ : σ →₀ ℕ) (kcap : ℕ) :
    MvPolynomial σ ℤ :=
  ∑ k ∈ Finset.range (kcap + 1),
    newtonTruncatedCoefficient Δ (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) k

theorem newtonTruncatedSupport_coeff_nonneg (u : ι → σ →₀ ℕ)
    (Δ e : σ →₀ ℕ) (kcap : ℕ) :
    0 ≤ MvPolynomial.coeff e (newtonTruncatedSupport u Δ kcap) := by
  rw [newtonTruncatedSupport, MvPolynomial.coeff_sum]
  exact Finset.sum_nonneg (fun k _ => newtonTruncatedCoefficient_monomial_coeff_nonneg u Δ e k)

/-- Summing the computed Newton coefficients loses no witnesses through
cancellation: its support is exactly the selections using at most `kcap`
distinct available labels and meeting the coordinate budget. -/
theorem newtonTruncatedSupport_coeff_pos_iff (u : ι → σ →₀ ℕ)
    (Δ e : σ →₀ ℕ) (kcap : ℕ) :
    0 < MvPolynomial.coeff e (newtonTruncatedSupport u Δ kcap) ↔
      e ≤ Δ ∧ ∃ s : Finset ι, s.card ≤ kcap ∧ (∑ i ∈ s, u i) = e := by
  classical
  rw [newtonTruncatedSupport, MvPolynomial.coeff_sum]
  have hpos :
      (0 < ∑ k ∈ Finset.range (kcap + 1), MvPolynomial.coeff e
        (newtonTruncatedCoefficient Δ (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) k)) ↔
      ∃ k ∈ Finset.range (kcap + 1), 0 < MvPolynomial.coeff e
        (newtonTruncatedCoefficient Δ (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) k) := by
    constructor
    · intro h
      by_contra hn
      push_neg at hn
      exact not_lt_of_ge (Finset.sum_nonpos hn) h
    · exact Finset.sum_pos'
        (fun k _ => newtonTruncatedCoefficient_monomial_coeff_nonneg u Δ e k)
  rw [hpos]
  constructor
  · rintro ⟨k, hk, hcoeff⟩
    obtain ⟨he, s, hcard, hsum⟩ :=
      (newtonTruncatedCoefficient_monomial_coeff_pos_iff u Δ e k).mp hcoeff
    exact ⟨he, s, by have := Finset.mem_range.mp hk; omega, hsum⟩
  · rintro ⟨he, s, hcard, hsum⟩
    refine ⟨s.card, Finset.mem_range.mpr (by omega), ?_⟩
    exact (newtonTruncatedCoefficient_monomial_coeff_pos_iff u Δ e s.card).mpr
      ⟨he, s, rfl, hsum⟩

/-- Zero testing for the entire cardinality-capped computation is exact over
the integers. -/
theorem newtonTruncatedSupport_coeff_eq_zero_iff (u : ι → σ →₀ ℕ)
    (Δ e : σ →₀ ℕ) (kcap : ℕ) :
    MvPolynomial.coeff e (newtonTruncatedSupport u Δ kcap) = 0 ↔
      ¬(e ≤ Δ ∧ ∃ s : Finset ι, s.card ≤ kcap ∧ (∑ i ∈ s, u i) = e) := by
  rw [← newtonTruncatedSupport_coeff_pos_iff]
  have hnonneg := newtonTruncatedSupport_coeff_nonneg u Δ e kcap
  omega

/-- The cardinality-capped support theorem with the finite copies supplied by
each input multiplicity. -/
theorem newtonTruncatedSupport_copies_coeff_pos_iff (c : ι → ℕ)
    (u : ι → σ →₀ ℕ) (Δ e : σ →₀ ℕ) (kcap : ℕ) :
    0 < MvPolynomial.coeff e
        (newtonTruncatedSupport (fun p : Σ i, Fin (c i) => u p.1) Δ kcap) ↔
      e ≤ Δ ∧ ∃ s : Finset (Σ i, Fin (c i)),
        s.card ≤ kcap ∧ (∑ p ∈ s, u p.1) = e :=
  newtonTruncatedSupport_coeff_pos_iff (fun p : Σ i, Fin (c i) => u p.1) Δ e kcap

end

end Optss
