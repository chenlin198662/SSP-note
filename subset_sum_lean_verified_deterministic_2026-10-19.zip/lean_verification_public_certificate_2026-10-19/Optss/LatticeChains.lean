import Optss.BasisPacking
import Optss.HyperplaneCounting
import Mathlib.GroupTheory.Index
import Mathlib.Data.Nat.Log
import Mathlib.LinearAlgebra.FreeModule.Finite.CardQuotient
import Mathlib.LinearAlgebra.FreeModule.Int
import Mathlib.LinearAlgebra.Matrix.AbsoluteValue

/-!
# Exact lattice-index accounting

Strict finite-index inclusions produce an integral relative index at least two.
The resulting finite-chain bounds apply to lattice seed additions and to the
remaining lattices between greedy blocks. Full real rank and coordinate bounds
supply the finite-index and determinant ceiling from the actual input family.
No HNF or other algorithmic running-time claim is made.
-/

namespace Optss
open scoped BigOperators Classical
noncomputable section

section Index
variable {G : Type*} [AddCommGroup G]

/-- A strict finite-index sublattice has at least twice the ambient lattice's
index. The factor two is derived from the genuine relative index. -/
theorem strict_lattice_index_doubles (H K : AddSubgroup G) (hHK : H < K)
    (hfinite : H.index ≠ 0) : 2*K.index ≤ H.index := by
  have htower := AddSubgroup.relindex_mul_index hHK.le
  have hrel0 : H.relindex K ≠ 0 := by
    intro hzero
    apply hfinite
    rw [← htower, hzero, zero_mul]
  have hrel1 : H.relindex K ≠ 1 := by
    intro hone
    exact hHK.not_le (AddSubgroup.relindex_eq_one.mp hone)
  have hrel : 2 ≤ H.relindex K := by omega
  calc
    _ ≤ H.relindex K * K.index := Nat.mul_le_mul_right _ hrel
    _ = _ := htower

/-- The actual number of strict changes in a finite sequence of lattices. -/
def latticeChanges (L : ℕ → AddSubgroup G) (n : ℕ) : ℕ :=
  ((Finset.range n).filter (fun i => L (i+1) ≠ L i)).card

@[simp] theorem latticeChanges_zero (L : ℕ → AddSubgroup G) : latticeChanges L 0 = 0 := by
  simp [latticeChanges]

theorem latticeChanges_succ (L : ℕ → AddSubgroup G) (n : ℕ) :
    latticeChanges L (n+1) = latticeChanges L n + if L (n+1) = L n then 0 else 1 := by
  by_cases h : L (n+1) = L n <;> simp [latticeChanges, Finset.range_add_one, Finset.filter_insert, h]

/-- Exact multiplication of the index for a descending finite chain. -/
theorem descending_lattice_index_growth (L : ℕ → AddSubgroup G) (n : ℕ)
    (hstep : ∀ i < n, L (i+1) ≤ L i)
    (hfinite : ∀ i ≤ n, (L i).index ≠ 0) :
    2^(latticeChanges L n) * (L 0).index ≤ (L n).index := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hprev := ih (fun i hi => hstep i (by omega)) (fun i hi => hfinite i (by omega))
    rw [latticeChanges_succ]
    by_cases heq : L (n+1) = L n
    · simpa only [heq, ↓reduceIte, add_zero] using hprev
    · simp only [heq, ↓reduceIte, pow_succ]
      have hdouble := strict_lattice_index_doubles (L (n+1)) (L n)
        (lt_of_le_of_ne (hstep n (by omega)) heq) (hfinite (n+1) (by omega))
      nlinarith

/-- With a positive initial index, a determinant/index ceiling bounds the total
number of strict descending lattice changes. -/
theorem descending_lattice_changes_le_log (L : ℕ → AddSubgroup G) (n B : ℕ)
    (hstep : ∀ i < n, L (i+1) ≤ L i)
    (hfinite : ∀ i ≤ n, (L i).index ≠ 0) (hbound : (L n).index ≤ B) :
    latticeChanges L n ≤ Nat.log 2 B := by
  apply Nat.le_log_of_pow_le (by omega)
  have h := descending_lattice_index_growth L n hstep hfinite
  have hstart : 1 ≤ (L 0).index := Nat.one_le_iff_ne_zero.mpr (hfinite 0 (by omega))
  have hbase : 2^(latticeChanges L n) ≤ 2^(latticeChanges L n) * (L 0).index := by
    simpa using Nat.mul_le_mul_left (2^(latticeChanges L n)) hstart
  exact hbase.trans (h.trans hbound)

/-- Exact index reduction along a chain of seed additions. -/
theorem ascending_lattice_index_decay (L : ℕ → AddSubgroup G) (n : ℕ)
    (hstep : ∀ i < n, L i ≤ L (i+1))
    (hfinite : ∀ i ≤ n, (L i).index ≠ 0) :
    2^(latticeChanges L n) * (L n).index ≤ (L 0).index := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hprev := ih (fun i hi => hstep i (by omega)) (fun i hi => hfinite i (by omega))
    rw [latticeChanges_succ]
    by_cases heq : L (n+1) = L n
    · simpa only [heq, ↓reduceIte, add_zero] using hprev
    · simp only [heq, ↓reduceIte, pow_succ]
      have hdouble := strict_lattice_index_doubles (L n) (L (n+1))
        (lt_of_le_of_ne (hstep n (by omega)) (Ne.symm heq)) (hfinite n (by omega))
      have hm := Nat.mul_le_mul_left (2^(latticeChanges L n)) hdouble
      nlinarith

/-- At most `log₂(initial index)` strict enlargements are available to a lattice
seed construction. -/
theorem ascending_lattice_changes_le_log (L : ℕ → AddSubgroup G) (n : ℕ)
    (hstep : ∀ i < n, L i ≤ L (i+1))
    (hfinite : ∀ i ≤ n, (L i).index ≠ 0) :
    latticeChanges L n ≤ Nat.log 2 (L 0).index := by
  apply Nat.le_log_of_pow_le (by omega)
  have h := ascending_lattice_index_decay L n hstep hfinite
  have hlast : 1 ≤ (L n).index := Nat.one_le_iff_ne_zero.mpr (hfinite n le_rfl)
  have hbase : 2^(latticeChanges L n) ≤ 2^(latticeChanges L n) * (L n).index := by
    simpa using Nat.mul_le_mul_left (2^(latticeChanges L n)) hlast
  exact hbase.trans h

end Index

section Unchanged
variable {α : Type*}

/-- Partitioning into `C+1` consecutive chunks forces an unchanged chunk when
there are at most `C` changed transitions. Endpoints are included correctly:
`ℓ` unchanged blocks contain `ℓ+1` identical boundary states. -/
theorem exists_consecutive_unchanged (f : ℕ → α) (n C ℓ : ℕ)
    (hcount : ((Finset.range n).filter (fun i => f (i+1) ≠ f i)).card ≤ C)
    (hlength : (C+1)*ℓ ≤ n) :
    ∃ block ≤ C, ∀ t < ℓ, f (block*ℓ+t+1) = f (block*ℓ+t) := by
  by_contra hnone
  have hbad : ∀ block : Fin (C+1), ∃ t : Fin ℓ,
      f (block.val*ℓ+t.val+1) ≠ f (block.val*ℓ+t.val) := by
    intro block
    have hn : ¬∀ t < ℓ, f (block.val*ℓ+t+1) = f (block.val*ℓ+t) := by
      intro h
      exact hnone ⟨block.val, by omega, h⟩
    push_neg at hn
    obtain ⟨t, ht, hchange⟩ := hn
    exact ⟨⟨t, ht⟩, hchange⟩
  choose bad hbad using hbad
  let changes := (Finset.range n).filter (fun i => f (i+1) ≠ f i)
  have hmem (i : Fin (C+1)) : i.val*ℓ+(bad i).val ∈ changes := by
    apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_range.mpr ?_, hbad i⟩
    have hi := Nat.mul_le_mul_right ℓ (show i.val+1 ≤ C+1 by omega)
    have ht := (bad i).isLt
    nlinarith
  let inject : Fin (C+1) → changes := fun i => ⟨i.val*ℓ+(bad i).val, hmem i⟩
  have hinj : Function.Injective inject := by
    intro i j heq
    have he : i.val*ℓ+(bad i).val = j.val*ℓ+(bad j).val := congrArg Subtype.val heq
    apply Fin.ext
    by_contra hne
    rcases lt_or_gt_of_ne hne with hij | hji
    · have hm := Nat.mul_le_mul_right ℓ (Nat.succ_le_of_lt hij)
      have ht := (bad i).isLt
      nlinarith
    · have hm := Nat.mul_le_mul_right ℓ (Nat.succ_le_of_lt hji)
      have ht := (bad j).isLt
      nlinarith
  have hcard := Fintype.card_le_of_injective inject hinj
  have hc : C+1 ≤ changes.card := by simpa only [Fintype.card_fin, Fintype.card_coe] using hcard
  dsimp only [changes] at hc
  omega

/-- Successive unchanged boundary pairs make every boundary in the selected run
identical to its initial boundary. -/
theorem eq_of_consecutive_unchanged (f : ℕ → α) (a ℓ : ℕ)
    (h : ∀ t < ℓ, f (a+t+1) = f (a+t)) :
    ∀ t ≤ ℓ, f (a+t) = f a := by
  intro t ht
  induction t with
  | zero => simp
  | succ t ih =>
    exact (h t (by omega)).trans (ih (by omega))

end Unchanged

/-- A determinant ceiling provides an explicit number of blocks sufficient to
find `ℓ` consecutive blocks with one common starting and ending lattice. -/
theorem descending_lattice_common_run {G : Type*} [AddCommGroup G]
    (L : ℕ → AddSubgroup G) (n B ℓ : ℕ)
    (hstep : ∀ i < n, L (i+1) ≤ L i)
    (hfinite : ∀ i ≤ n, (L i).index ≠ 0) (hbound : (L n).index ≤ B)
    (hlength : (Nat.log 2 B + 1)*ℓ ≤ n) :
    ∃ block ≤ Nat.log 2 B, ∀ t ≤ ℓ, L (block*ℓ+t) = L (block*ℓ) := by
  obtain ⟨block, hb, heq⟩ := exists_consecutive_unchanged L n (Nat.log 2 B) ℓ
    (descending_lattice_changes_le_log L n B hstep hfinite hbound) hlength
  exact ⟨block, hb, eq_of_consecutive_unchanged L (block*ℓ) ℓ heq⟩

section Seed
variable {ι G : Type*} [DecidableEq ι] [AddCommGroup G]

/-- The actual integer-generated lattice of selected labelled input vectors. -/
def generatedLattice (v : ι → G) (s : Finset ι) : AddSubgroup G :=
  AddSubgroup.closure (v '' (s : Set ι))

omit [DecidableEq ι] in
theorem generatedLattice_mono (v : ι → G) {s t : Finset ι} (h : s ⊆ t) :
    generatedLattice v s ≤ generatedLattice v t := AddSubgroup.closure_mono (Set.image_mono h)

omit [DecidableEq ι] in
/-- If the current seed does not generate the target lattice, an actual available
label lies outside its generated lattice. -/
theorem exists_label_outside_generated (v : ι → G) (b s : Finset ι) (hbs : b ⊆ s)
    (hne : generatedLattice v b ≠ generatedLattice v s) :
    ∃ i ∈ s, v i ∉ generatedLattice v b := by
  by_contra h
  push_neg at h
  apply hne
  apply le_antisymm (generatedLattice_mono v hbs)
  apply (AddSubgroup.closure_le _).mpr
  rintro _ ⟨i, hi, rfl⟩
  exact h i hi

/-- Adding an available vector outside the current lattice strictly enlarges it. -/
theorem generatedLattice_insert_strict (v : ι → G) (b : Finset ι) (i : ι)
    (hi : v i ∉ generatedLattice v b) : generatedLattice v b < generatedLattice v (insert i b) := by
  apply lt_of_le_of_ne (generatedLattice_mono v (Finset.subset_insert _ _))
  intro heq
  apply hi
  rw [heq]
  exact AddSubgroup.subset_closure ⟨i, Finset.mem_insert_self _ _, rfl⟩

/-- Finite greedy extension constructs a spanning seed. Every added label pays
for a genuine factor-two index reduction, so the complete multiplicative estimate
is part of the constructed witness. -/
theorem exists_latticeSeed_index_bound (v : ι → G) (s b : Finset ι) (hbs : b ⊆ s)
    (hfinite : (generatedLattice v b).index ≠ 0) :
    ∃ seed : Finset ι, b ⊆ seed ∧ seed ⊆ s ∧
      generatedLattice v seed = generatedLattice v s ∧
      2^(seed.card-b.card) * (generatedLattice v seed).index ≤ (generatedLattice v b).index := by
  induction hsize : (s \ b).card using Nat.strong_induction_on generalizing b with
  | h n ih =>
    by_cases heq : generatedLattice v b = generatedLattice v s
    · exact ⟨b, Finset.Subset.refl _, hbs, heq, by simp⟩
    · obtain ⟨i, his, hi⟩ := exists_label_outside_generated v b s hbs heq
      have hib : i ∉ b := fun hib => hi (AddSubgroup.subset_closure ⟨i, hib, rfl⟩)
      have hinsert : insert i b ⊆ s := Finset.insert_subset his hbs
      have hstrict := generatedLattice_insert_strict v b i hi
      have hfinite' : (generatedLattice v (insert i b)).index ≠ 0 :=
        ne_zero_of_dvd_ne_zero hfinite (AddSubgroup.index_dvd_of_le hstrict.le)
      have hsmaller : (s \ insert i b).card < n := by
        rw [← hsize]
        apply Finset.card_lt_card
        refine ⟨?_, ?_⟩
        · intro j hj
          have hjs := Finset.mem_sdiff.mp hj
          exact Finset.mem_sdiff.mpr ⟨hjs.1, fun hjb => hjs.2 (Finset.mem_insert_of_mem hjb)⟩
        intro hback
        have := hback (Finset.mem_sdiff.mpr ⟨his, hib⟩)
        simp at this
      obtain ⟨seed, hseed, hseeds, hspan, hindex⟩ :=
        ih (s \ insert i b).card hsmaller (insert i b) hinsert hfinite' rfl
      refine ⟨seed, (Finset.subset_insert _ _).trans hseed, hseeds, hspan, ?_⟩
      have hcard := Finset.card_le_card hseed
      rw [Finset.card_insert_of_not_mem hib] at hcard hindex
      have hpow : seed.card-b.card = (seed.card-(b.card+1))+1 := by omega
      rw [hpow, pow_succ]
      have hdouble := strict_lattice_index_doubles _ _ hstrict hfinite
      have hm := Nat.mul_le_mul_left 2 hindex
      nlinarith

/-- The constructed seed uses at most logarithmically many labels beyond the
initial full-rank seed. No label outside the available finite input is introduced. -/
theorem exists_latticeSeed (v : ι → G) (s b : Finset ι) (hbs : b ⊆ s)
    (hfinite : (generatedLattice v b).index ≠ 0) :
    ∃ seed : Finset ι, b ⊆ seed ∧ seed ⊆ s ∧
      generatedLattice v seed = generatedLattice v s ∧
      seed.card ≤ b.card + Nat.log 2 (generatedLattice v b).index := by
  obtain ⟨seed, hseed, hseeds, hspan, hindex⟩ := exists_latticeSeed_index_bound v s b hbs hfinite
  have hfin : (generatedLattice v seed).index ≠ 0 :=
    ne_zero_of_dvd_ne_zero hfinite (AddSubgroup.index_dvd_of_le (generatedLattice_mono v hseed))
  have hpos : 1 ≤ (generatedLattice v seed).index := Nat.one_le_iff_ne_zero.mpr hfin
  have hbase : 2^(seed.card-b.card) ≤ (generatedLattice v b).index := by
    have hle := Nat.mul_le_mul_left (2^(seed.card-b.card)) hpos
    simp only [mul_one] at hle
    exact hle.trans hindex
  have hlog := Nat.le_log_of_pow_le (by omega : 1 < 2) hbase
  have hcard := Finset.card_le_card hseed
  exact ⟨seed, hseed, hseeds, hspan, by omega⟩

end Seed

section Determinant

/-- Coordinate-dependent determinant estimate from the Leibniz formula. -/
theorem abs_det_le_factorial_prod {n : Type*} [Fintype n] [DecidableEq n]
    (A : Matrix n n ℤ) (w : n → ℤ) (hw : ∀ i j, |A i j| ≤ w j) :
    |A.det| ≤ (Fintype.card n).factorial * ∏ j, w j := by
  let abv : AbsoluteValue ℤ ℤ := AbsoluteValue.abs
  calc
    |A.det| = abv (∑ σ : Equiv.Perm n, Equiv.Perm.sign σ • ∏ i, A (σ i) i) :=
      congrArg abv (Matrix.det_apply A)
    _ ≤ ∑ σ : Equiv.Perm n, abv (Equiv.Perm.sign σ • ∏ i, A (σ i) i) := abv.sum_le _ _
    _ = ∑ σ : Equiv.Perm n, ∏ i, |A (σ i) i| := by
      apply Finset.sum_congr rfl
      intro σ _
      rw [abv.map_units_int_smul, abv.map_prod]
      rfl
    _ ≤ ∑ _σ : Equiv.Perm n, ∏ i, w i := by
      apply Finset.sum_le_sum
      intro σ _
      exact Finset.prod_le_prod (fun i _ => abs_nonneg _) (fun i _ => hw _ _)
    _ = _ := by simp [Fintype.card_perm, nsmul_eq_mul]

/-- An actual full-size integer basis makes the lattice index finite. -/
theorem lattice_index_ne_zero_of_basis {d : ℕ} (L : AddSubgroup (IntVec d))
    (bL : Basis (Fin d) ℤ L) : L.index ≠ 0 :=
  Int.addSubgroup_index_ne_zero_iff.mpr ⟨bL.equivFun.toAddEquiv⟩

/-- The determinant bound for a lattice with an actual integer basis inside a
coordinate box. This is a derived index bound, not a separate volume assumption. -/
theorem lattice_index_le_factorial_product {d : ℕ} (L : AddSubgroup (IntVec d))
    (bL : Basis (Fin d) ℤ L) (w : Fin d → ℕ)
    (hbox : ∀ i j, |(bL i : IntVec d) j| ≤ (w j : ℤ)) :
    L.index ≤ d.factorial * ∏ j, w j := by
  let A := (Pi.basisFun ℤ (Fin d)).toMatrix (fun i => (bL i : IntVec d))
  have hbound : |A.transpose.det| ≤ (d.factorial : ℤ) * ∏ j, (w j : ℤ) := by
    simpa only [Fintype.card_fin] using abs_det_le_factorial_prod A.transpose
      (fun j => (w j : ℤ)) (fun i j => by
        simpa only [A, Matrix.transpose_apply, Basis.toMatrix_apply, Pi.basisFun_repr] using hbox i j)
  rw [Matrix.det_transpose] at hbound
  have heq : L.index = A.det.natAbs := by
    simpa only [Basis.det_apply, A] using AddSubgroup.index_eq_natAbs_det (Pi.basisFun ℤ (Fin d)) L bL
  have hi : (L.index : ℤ) ≤ ((d.factorial * ∏ j, w j : ℕ) : ℤ) := by
    rw [heq, Int.natCast_natAbs]
    simpa only [Nat.cast_mul, Nat.cast_prod] using hbound
  exact_mod_cast hi

/-- Containing a full-rank box-bounded independent sublattice is enough for the
same index ceiling, even when the enclosing lattice has a different basis. -/
theorem lattice_index_le_of_containing_basis {d : ℕ} (L P : AddSubgroup (IntVec d))
    (hLP : L ≤ P) (bL : Basis (Fin d) ℤ L) (w : Fin d → ℕ)
    (hbox : ∀ i j, |(bL i : IntVec d) j| ≤ (w j : ℤ)) :
    P.index ≠ 0 ∧ P.index ≤ d.factorial * ∏ j, w j := by
  have hfin := lattice_index_ne_zero_of_basis L bL
  have hdvd := AddSubgroup.index_dvd_of_le hLP
  exact ⟨ne_zero_of_dvd_ne_zero hfin hdvd,
    (Nat.le_of_dvd (Nat.pos_of_ne_zero hfin) hdvd).trans
      (lattice_index_le_factorial_product L bL w hbox)⟩

/-- A full independent integer input family itself supplies the lattice basis
needed by the exact index/determinant bound. -/
theorem independent_family_lattice_index {d : ℕ} (u : Fin d → IntVec d)
    (hind : LinearIndependent ℤ u) (w : Fin d → ℕ)
    (hbox : ∀ i j, |u i j| ≤ (w j : ℤ)) :
    (AddSubgroup.closure (Set.range u)).index ≠ 0 ∧
    (AddSubgroup.closure (Set.range u)).index ≤ d.factorial * ∏ j, w j := by
  let M := Submodule.span ℤ (Set.range u)
  let bM : Basis (Fin d) ℤ M := Basis.span hind
  have heq : M.toAddSubgroup = AddSubgroup.closure (Set.range u) :=
    Submodule.span_int_eq_addSubgroup_closure _
  rw [← heq]
  exact ⟨lattice_index_ne_zero_of_basis M.toAddSubgroup bM,
    lattice_index_le_factorial_product M.toAddSubgroup bM w (fun i j => by
      change |(((Basis.span hind) i : Submodule.span ℤ (Set.range u)) : IntVec d) j| ≤ (w j : ℤ)
      rw [Basis.span_apply]
      exact hbox i j)⟩

/-- Real independence of the integer vectors is sufficient for the same bound. -/
theorem real_independent_family_lattice_index {d : ℕ} (u : Fin d → IntVec d)
    (hind : LinearIndependent ℝ (fun i => realVector (u i))) (w : Fin d → ℕ)
    (hbox : ∀ i j, |u i j| ≤ (w j : ℤ)) :
    (AddSubgroup.closure (Set.range u)).index ≠ 0 ∧
    (AddSubgroup.closure (Set.range u)).index ≤ d.factorial * ∏ j, w j := by
  have hz : LinearIndependent ℤ u :=
    LinearIndependent.of_comp realVector.toIntLinearMap (hind.restrict_scalars' ℤ)
  exact independent_family_lattice_index u hz w hbox

end Determinant

/-- A box-bounded full-rank subfamily yields a completely numerical seed bound,
including the initial basis labels and all later lattice-enlarging additions. -/
theorem exists_small_latticeSeed_of_real_independent_family
    {ι : Type*} [DecidableEq ι] {d : ℕ} (v : ι → IntVec d) (available : Finset ι)
    (labels : Fin d → ι) (hlabels : ∀ j, labels j ∈ available)
    (hind : LinearIndependent ℝ (fun j => realVector (v (labels j))))
    (w : Fin d → ℕ) (hbox : ∀ i ∈ available, InCenteredBox w (v i)) :
    ∃ seed : Finset ι, seed ⊆ available ∧ generatedLattice v seed = generatedLattice v available ∧
      seed.card ≤ d + Nat.log 2 (d.factorial * ∏ j, w j) := by
  let b := Finset.univ.image labels
  have hbs : b ⊆ available := by
    intro i hi
    obtain ⟨j, _, rfl⟩ := Finset.mem_image.mp hi
    exact hlabels j
  have heq : generatedLattice v b = AddSubgroup.closure (Set.range (fun j => v (labels j))) := by
    unfold generatedLattice
    congr 1
    ext x
    simp only [b, Set.mem_image, Finset.mem_coe, Finset.mem_image, Finset.mem_univ, true_and,
      Set.mem_range]
    aesop
  have hindex := real_independent_family_lattice_index (fun j => v (labels j)) hind w
    (fun i j => hbox (labels i) (hlabels i) j)
  rw [← heq] at hindex
  obtain ⟨seed, _, hseed, hspan, hcard⟩ := exists_latticeSeed v available b hbs hindex.1
  have hbcard : b.card ≤ d := by
    simpa only [b, Finset.card_univ, Fintype.card_fin] using (Finset.card_image_le (s := Finset.univ) (f := labels))
  have hlog := Nat.log_mono_right (b := 2) hindex.2
  exact ⟨seed, hseed, hspan, by omega⟩

/-- A full real span selects exactly `d` independent original labels. -/
theorem exists_full_rank_labels {ι : Type*} {d : ℕ}
    (v : ι → IntVec d) (available : Finset ι)
    (hfull : labelSpan ℝ (fun i => realVector (v i)) available = ⊤) :
    ∃ labels : Fin d → ι, (∀ j, labels j ∈ available) ∧
      LinearIndependent ℝ (fun j => realVector (v (labels j))) := by
  let u : available → (Fin d → ℝ) := fun i => realVector (v i)
  have hrange : Set.range u = (fun i => realVector (v i)) '' (available : Set ι) := by
    ext x; simp [u]
  have hrank : inputSpanRank ℝ u = d := by
    unfold inputSpanRank
    rw [hrange]
    change Module.finrank ℝ (labelSpan ℝ (fun i => realVector (v i)) available) = d
    rw [hfull]
    simp
  obtain ⟨labels, _, hli⟩ := exists_independent_items_of_span_rank (K := ℝ) u
  let e : Fin d ≃ Fin (inputSpanRank ℝ u) := finCongr hrank.symm
  refine ⟨fun j => labels (e j), fun j => (labels (e j)).property, ?_⟩
  exact hli.comp e e.injective


/-- Full real rank in the original box gives the finite-index and determinant
ceiling for the actual generated lattice, without a supplied lattice basis. -/
theorem generatedLattice_index_of_full_real_span {ι : Type*} {d : ℕ}
    (v : ι → IntVec d) (available : Finset ι)
    (hfull : labelSpan ℝ (fun i => realVector (v i)) available = ⊤)
    (w : Fin d → ℕ) (hbox : ∀ i ∈ available, InCenteredBox w (v i)) :
    (generatedLattice v available).index ≠ 0 ∧
      (generatedLattice v available).index ≤ d.factorial * ∏ j, w j := by
  obtain ⟨labels, hlabels, hli⟩ := exists_full_rank_labels v available hfull
  have hindex := real_independent_family_lattice_index (fun j => v (labels j)) hli w
    (fun i j => hbox (labels i) (hlabels i) j)
  have hle : AddSubgroup.closure (Set.range (fun j => v (labels j))) ≤ generatedLattice v available := by
    apply AddSubgroup.closure_mono
    rintro _ ⟨j, rfl⟩
    exact ⟨labels j, hlabels j, rfl⟩
  have hdvd := AddSubgroup.index_dvd_of_le hle
  exact ⟨ne_zero_of_dvd_ne_zero hindex.1 hdvd,
    (Nat.le_of_dvd (Nat.pos_of_ne_zero hindex.1) hdvd).trans hindex.2⟩

/-- The actual finite input produces a lattice-generating seed of at most
`d + log₂(d!∏b_j)` labels under full real rank and the coordinate bounds. -/
theorem exists_small_latticeSeed_of_full_real_span
    {ι : Type*} [DecidableEq ι] {d : ℕ} (v : ι → IntVec d) (available : Finset ι)
    (hfull : labelSpan ℝ (fun i => realVector (v i)) available = ⊤)
    (w : Fin d → ℕ) (hbox : ∀ i ∈ available, InCenteredBox w (v i)) :
    ∃ seed : Finset ι, seed ⊆ available ∧ generatedLattice v seed = generatedLattice v available ∧
      seed.card ≤ d + Nat.log 2 (d.factorial * ∏ j, w j) := by
  obtain ⟨labels, hlabels, hli⟩ := exists_full_rank_labels v available hfull
  exact exists_small_latticeSeed_of_real_independent_family v available labels hlabels hli w hbox

/-- Repeated block deletions in a fixed box, with protected full rank, eventually
produce consecutive blocks sharing one actual generated lattice. Every finite
index and determinant bound in this theorem is derived from those input vectors. -/
theorem remaining_lattices_common_run
    {ι : Type*} {d : ℕ} (v : ι → IntVec d) (remaining : ℕ → Finset ι) (n ℓ : ℕ)
    (hstep : ∀ i < n, remaining (i+1) ⊆ remaining i)
    (hfull : ∀ i ≤ n, labelSpan ℝ (fun j => realVector (v j)) (remaining i) = ⊤)
    (w : Fin d → ℕ) (hbox : ∀ i ≤ n, ∀ j ∈ remaining i, InCenteredBox w (v j))
    (hlength : (Nat.log 2 (d.factorial * ∏ j, w j)+1)*ℓ ≤ n) :
    ∃ block ≤ Nat.log 2 (d.factorial * ∏ j, w j), ∀ t ≤ ℓ,
      generatedLattice v (remaining (block*ℓ+t)) = generatedLattice v (remaining (block*ℓ)) := by
  have hindices : ∀ i ≤ n, (generatedLattice v (remaining i)).index ≠ 0 ∧
      (generatedLattice v (remaining i)).index ≤ d.factorial * ∏ j, w j := by
    intro i hi
    exact generatedLattice_index_of_full_real_span v (remaining i) (hfull i hi) w (hbox i hi)
  exact descending_lattice_common_run (fun i => generatedLattice v (remaining i)) n
    (d.factorial * ∏ j, w j) ℓ
    (fun i hi => generatedLattice_mono v (hstep i hi))
    (fun i hi => (hindices i hi).1) (hindices n le_rfl).2 hlength

end
end Optss
