import Optss.DenseBoxAllocation

/-!
# Explicit constants for dense-box filling

The period cutoff is `ceil(2/c)`, and the residue reserve has its `d`th
power many labels. Axis blocks have size `floor(N/(2d))`. The thresholds
below guarantee their required density count and leave a fixed positive
linear fraction of every coordinate width after residue correction.
-/
namespace Optss
noncomputable section
open scoped BigOperators

/-- Period cutoff, reserve size, and a valid dilation constant. -/
def denseBoxPeriodCutoff (c : ℝ) : ℕ := ⌈2 / c⌉₊
def denseBoxReserveSize (d : ℕ) (c : ℝ) : ℕ := denseBoxPeriodCutoff c ^ d
def denseBoxDilation (d : ℕ) (c : ℝ) : ℝ := c ^ 2 / (64 * d)

/-- Explicit integer lower thresholds; they depend only on density and rank. -/
def denseBoxSummandThreshold (d : ℕ) (c : ℝ) : ℕ :=
  ⌈max (2 * (d : ℝ)) (max (2 * (denseBoxReserveSize d c : ℝ))
    (128 * d * ((denseBoxReserveSize d c : ℝ) + 1) / c ^ 2))⌉₊
def denseBoxWidthThreshold (c : ℝ) : ℕ := ⌈4 / c⌉₊

theorem denseBoxDilation_pos (d : ℕ) (c : ℝ) (hd : 0 < d) (hc : 0 < c) :
    0 < denseBoxDilation d c := by unfold denseBoxDilation; positivity

theorem denseBoxPeriodCutoff_bound (c : ℝ) (hc : 0 < c) :
    2 ≤ c * denseBoxPeriodCutoff c := by
  have h := Nat.le_ceil (2 / c)
  have hh := (div_le_iff₀ hc).mp h
  simpa only [mul_comm] using hh

theorem denseBoxWidthThreshold_spec (c : ℝ) (hc : 0 < c) (W : ℕ)
    (hW : denseBoxWidthThreshold c ≤ W) : 0 < W ∧ 4 ≤ c * W := by
  have hh : 4 / c ≤ (W : ℝ) := (Nat.le_ceil (4 / c)).trans (by exact_mod_cast hW)
  have hcW : 4 ≤ c * W := by simpa only [mul_comm] using (div_le_iff₀ hc).mp hh
  refine ⟨?_, hcW⟩
  by_contra hn
  have hz : W = 0 := by omega
  norm_num [hz] at hcW

/-- Every sufficiently large actual label count admits the explicit
allocation, with enough residual width for the stated positive dilation. -/
theorem denseBoxSummandThreshold_spec (d : ℕ) (c : ℝ) (N : ℕ)
    (hd : 0 < d) (hc : 0 < c) (hN : denseBoxSummandThreshold d c ≤ N) :
    let q := N / (2 * d)
    let M := denseBoxReserveSize d c
    d * q + M ≤ N ∧ 20 ≤ c ^ 2 * q ∧
      denseBoxDilation d c * N ≤ c ^ 2 * q / 4 - 2 * M := by
  let M := denseBoxReserveSize d c
  let q := N / (2 * d)
  have hNR : (denseBoxSummandThreshold d c : ℝ) ≤ N := by exact_mod_cast hN
  have hceil : max (2 * (d : ℝ)) (max (2 * (M : ℝ))
      (128 * d * ((M : ℝ) + 1) / c ^ 2)) ≤ N :=
    (Nat.le_ceil _).trans hNR
  have hNd : 2 * d ≤ N := by have := (le_max_left _ _).trans hceil; exact_mod_cast this
  have hNM : 2 * M ≤ N := by
    have hh : 2 * (M : ℝ) ≤ N := (le_max_left _ _).trans ((le_max_right _ _).trans hceil)
    exact_mod_cast hh
  have hc2 : 0 < c ^ 2 := sq_pos_of_pos hc
  have hlarge : 128 * (d : ℝ) * ((M : ℝ) + 1) ≤ c ^ 2 * N := by
    have hh := (le_max_right _ _).trans ((le_max_right _ _).trans hceil)
    have h := (div_le_iff₀ hc2).mp hh
    nlinarith
  have hdR : (0 : ℝ) < d := by exact_mod_cast hd
  have hqN : (N : ℝ) ≤ 4 * d * q := by exact_mod_cast filling_block_lower_bound d N hd hNd
  have hqC := mul_le_mul_of_nonneg_left hqN hc2.le
  have hqbig : 32 * ((M : ℝ) + 1) ≤ c ^ 2 * q := by
    apply (mul_le_mul_left (show 0 < 4 * (d : ℝ) by positivity)).mp
    nlinarith
  refine ⟨filling_allocation_count d N M hd hNM, ?_, ?_⟩
  · have hM : (0 : ℝ) ≤ M := by positivity
    nlinarith
  · change c ^ 2 / (64 * (d : ℝ)) * N ≤ c ^ 2 * q / 4 - 2 * M
    apply (mul_le_mul_right (show 0 < 64 * (d : ℝ) by positivity)).mp
    have hne : (64 * (d : ℝ)) ≠ 0 := by positivity
    field_simp [hne]
    nlinarith

end
end Optss
