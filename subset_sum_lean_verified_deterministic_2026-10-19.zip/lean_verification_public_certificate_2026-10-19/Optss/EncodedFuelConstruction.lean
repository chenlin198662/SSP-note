import Optss.EncodedReductionWork

/-!
# Fuel built structurally from stored matrix cells

The answer initializer only traverses arrays/lists, constructs list cells and
repeats lists. It performs no natural-number size, product, power or magnitude
calculation. A row marker, an entry/sign marker and each stored magnitude bit
supply tokens. Nine copies of the token-list cube suffice for reduction.

Work counts list constructor/branch visits and array slots copied into lists.
Instrumentation arithmetic and the implementation of array traversal are not
claimed to be machine instructions; scalar magnitude arithmetic is absent.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

/-- Structural append, with the right list retained by reference. -/
def fuelListAppend : List Bool → List Bool → List Bool
  | [], ys => ys
  | b::bs, ys => b::fuelListAppend bs ys

@[simp] theorem fuelListAppend_length (xs ys : List Bool) :
    (fuelListAppend xs ys).length = xs.length+ys.length := by
  induction xs with
  | nil => simp [fuelListAppend]
  | cons b bs ih => simp [fuelListAppend,ih]; omega

/-- One outer-list constructor selects one copy of the shared inner list. -/
def fuelListRepeat {α : Type*} : List α → List Bool → List Bool
  | [], _ => []
  | _::xs, ys => fuelListAppend ys (fuelListRepeat xs ys)

@[simp] theorem fuelListRepeat_length {α : Type*} (xs : List α) (ys : List Bool) :
    (fuelListRepeat xs ys).length = xs.length*ys.length := by
  induction xs with
  | nil => simp [fuelListRepeat]
  | cons x xs ih => simp [fuelListRepeat,ih]; ring

/-- Build entry/sign tokens and copy the actual magnitude bits, keeping the
continuation shared. The Boolean values of fuel tokens are immaterial. -/
def fuelEntriesInto : List BitListInteger → List Bool → List Bool
  | [], tail => tail
  | z::zs, tail => false::fuelListAppend z.digits (fuelEntriesInto zs tail)

def fuelRowsInto {d : ℕ} : List (Vector BitListInteger d) → List Bool → List Bool
  | [], tail => tail
  | row::rows, tail =>
    let cells := row.toList
    false::fuelEntriesInto cells (fuelRowsInto rows tail)

/-- Initialization uses only the actual matrix rows and digit lists. -/
def encodedFuelTokens (D : BitIntegerMatrixData r d) : List Bool :=
  fuelRowsInto D.toList [false,false,false]

def encodedStructuralFuel (D : BitIntegerMatrixData r d) : List Bool :=
  let tokens := encodedFuelTokens D
  let square := fuelListRepeat tokens tokens
  let cube := fuelListRepeat tokens square
  fuelListRepeat [false,false,false,false,false,false,false,false,false] cube

theorem fuelEntriesInto_length (xs : List BitListInteger) (tail : List Bool) :
    (fuelEntriesInto xs tail).length = xs.length+(xs.map fun z => z.digits.length).sum+tail.length := by
  induction xs with
  | nil => simp [fuelEntriesInto]
  | cons z zs ih => simp [fuelEntriesInto,ih]; omega

theorem fuelRowsInto_length (xs : List (Vector BitListInteger d)) (tail : List Bool) :
    (fuelRowsInto xs tail).length =
      xs.length*(d+1)+(xs.map fun row => (row.toList.map fun z => z.digits.length).sum).sum+tail.length := by
  induction xs with
  | nil => simp [fuelRowsInto]
  | cons row rows ih =>
    simp [fuelRowsInto,fuelEntriesInto_length,ih,Vector.length_toList]
    ring

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

private theorem vector_toList_eq_ofFn {α : Type*} {n : ℕ} (v : Vector α n) :
    v.toList = List.ofFn v.get := by
  have h : Vector.ofFn v.get = v := by
    apply Vector.ext
    intro i hi
    change (Vector.ofFn v.get).get ⟨i,hi⟩ = v.get ⟨i,hi⟩
    exact get_ofFn _ _
  exact (congrArg (fun x : Vector α n => x.toList) h.symm).trans Vector.toList_ofFn

theorem encodedFuelTokens_length (D : BitIntegerMatrixData r d) :
    (encodedFuelTokens D).length = r+bitIntegerMatrixSize D+3 := by
  rw [encodedFuelTokens,fuelRowsInto_length]
  simp only [Vector.length_toList,List.length_cons,List.length_nil,
    vector_toList_eq_ofFn,List.map_ofFn,List.sum_ofFn,List.length_ofFn,Function.comp_apply,bitIntegerMatrixSize]
  ring

theorem encodedStructuralFuel_length (D : BitIntegerMatrixData r d) :
    (encodedStructuralFuel D).length = 9*(r+bitIntegerMatrixSize D+3)^3 := by
  simp only [encodedStructuralFuel,fuelListRepeat_length,List.length_cons,List.length_nil,
    encodedFuelTokens_length]
  ring

/-- One visit and one new cell per copied element, plus the terminal test. -/
def fuelListAppendWork : List Bool → ℕ
  | [] => 1
  | _::xs => fuelListAppendWork xs+2

theorem fuelListAppendWork_eq (xs : List Bool) :
    fuelListAppendWork xs = 2*xs.length+1 := by
  induction xs with
  | nil => rfl
  | cons b xs ih => simp only [fuelListAppendWork,ih,List.length_cons]; omega

def fuelListRepeatWork {α : Type*} : List α → List Bool → ℕ
  | [], _ => 1
  | _::xs, ys => fuelListRepeatWork xs ys+fuelListAppendWork ys+1

theorem fuelListRepeatWork_eq {α : Type*} (xs : List α) (ys : List Bool) :
    fuelListRepeatWork xs ys = xs.length*(2*ys.length+2)+1 := by
  induction xs with
  | nil => simp [fuelListRepeatWork]
  | cons x xs ih => simp [fuelListRepeatWork,ih,fuelListAppendWork_eq]; ring

/-- Entry tests, sign-token construction, digit field access and append work. -/
def fuelEntriesIntoWork : List BitListInteger → ℕ
  | [] => 1
  | z::zs => fuelEntriesIntoWork zs+fuelListAppendWork z.digits+3

theorem fuelEntriesIntoWork_eq (xs : List BitListInteger) :
    fuelEntriesIntoWork xs = 2*(xs.map fun z => z.digits.length).sum+4*xs.length+1 := by
  induction xs with
  | nil => simp [fuelEntriesIntoWork]
  | cons z zs ih => simp [fuelEntriesIntoWork,ih,fuelListAppendWork_eq]; ring

/-- Array-to-list copying is charged two operations per slot and a terminal
visit; the remaining three units cover row access, test and row marker. -/
def fuelRowsIntoWork {d : ℕ} : List (Vector BitListInteger d) → ℕ
  | [] => 1
  | row::rows => fuelRowsIntoWork rows+fuelEntriesIntoWork row.toList+2*d+4

theorem fuelRowsIntoWork_eq (xs : List (Vector BitListInteger d)) :
    fuelRowsIntoWork xs =
      2*(xs.map fun row => (row.toList.map fun z => z.digits.length).sum).sum+
        (6*d+5)*xs.length+1 := by
  induction xs with
  | nil => simp [fuelRowsIntoWork]
  | cons row rows ih =>
    simp [fuelRowsIntoWork,ih,fuelEntriesIntoWork_eq,Vector.length_toList]
    ring

/-- Includes the outer array-to-list conversion and the three initial tokens. -/
def encodedFuelTokensWork (D : BitIntegerMatrixData r d) : ℕ :=
  fuelRowsIntoWork D.toList+2*r+4

theorem encodedFuelTokensWork_bound (D : BitIntegerMatrixData r d) :
    encodedFuelTokensWork D ≤ 7*(r+bitIntegerMatrixSize D+3) := by
  simp only [encodedFuelTokensWork,fuelRowsIntoWork_eq,Vector.length_toList,
    vector_toList_eq_ofFn,List.map_ofFn,List.sum_ofFn,List.length_ofFn,Function.comp_apply,bitIntegerMatrixSize]
  ring_nf
  omega

/-- Constructor/visit work of the entire actual list initializer, including
the nine constant selector tokens. -/
def encodedStructuralFuelWork (D : BitIntegerMatrixData r d) : ℕ :=
  let tokens := encodedFuelTokens D
  let square := fuelListRepeat tokens tokens
  let cube := fuelListRepeat tokens square
  encodedFuelTokensWork D+fuelListRepeatWork tokens tokens+fuelListRepeatWork tokens square+
    fuelListRepeatWork [false,false,false,false,false,false,false,false,false] cube+9

theorem encodedStructuralFuelWork_bound (D : BitIntegerMatrixData r d) :
    encodedStructuralFuelWork D ≤ 64*(r+bitIntegerMatrixSize D+3)^3 := by
  let B := r+bitIntegerMatrixSize D+3
  have hb : 1 ≤ B := by dsimp [B]; omega
  have h₂ : B^2 ≤ B^3 := Nat.pow_le_pow_right hb (by omega : 2 ≤ 3)
  have h₁ : B ≤ B^3 := by simpa using Nat.pow_le_pow_right hb (by omega : 1 ≤ 3)
  have h₀ : 1 ≤ B^3 := one_le_pow₀ hb
  have ht := encodedFuelTokensWork_bound D
  change encodedFuelTokensWork D ≤ 7*B at ht
  simp only [encodedStructuralFuelWork,fuelListRepeatWork_eq,fuelListRepeat_length,
    encodedFuelTokens_length,List.length_cons,List.length_nil]
  change encodedFuelTokensWork D+B*(2*B+2)+1+(B*(2*(B*B)+2)+1)+
    ((0+1+1+1+1+1+1+1+1+1)*(2*(B*(B*B))+2)+1)+9 ≤ 64*B^3
  nlinarith

/-- With at least one stored row, the stored sign slots already cover the
column dimension, so no dimension-to-bit conversion is needed. -/
theorem encodedStructuralFuel_dominates (D : BitIntegerMatrixData r d) (hr : 0 < r) :
    (bitMatrixReductionFuel D).length ≤ (encodedStructuralFuel D).length := by
  let S := bitIntegerMatrixSize D
  let B := r+S+3
  have hrd : r*d ≤ S := by dsimp [S,bitIntegerMatrixSize]; omega
  have hd : d ≤ S := (show d ≤ r*d by nlinarith).trans hrd
  have hsr : r.size ≤ r := Nat.size_le.mpr Nat.lt_two_pow_self
  have hsd : d.size ≤ d := Nat.size_le.mpr Nat.lt_two_pow_self
  have hf₁ : r*(r+1)+1 ≤ B^2 := by dsimp [B]; nlinarith
  have hf₂ : r.size+d.size+2*(S+1)+4 ≤ 3*B := by dsimp [B]; omega
  rw [bitMatrixReductionFuel_length,encodedStructuralFuel_length]
  change 3*(r*(r+1)+1)*(r.size+d.size+2*(S+1)+4) ≤ 9*B^3
  calc
    _ ≤ 3*B^2*(3*B) := Nat.mul_le_mul (Nat.mul_le_mul_left _ hf₁) hf₂
    _ = _ := by ring

/-- Literal encoded output and scalar-work stability after a stopped trace.
This is stronger than equality of decoded mathematical matrices. -/
theorem encodedReductionTrace_stable_of_stopped (fuel other : List Bool)
    (D : BitIntegerMatrixData r d)
    (hf : (encodedReductionFuel fuel D).swaps < fuel.length)
    (ho : (encodedReductionFuel fuel D).swaps < other.length) :
    encodedReductionFuel fuel D = encodedReductionFuel other D ∧
      encodedReductionFuelWork fuel D = encodedReductionFuelWork other D := by
  induction fuel generalizing D other with
  | nil => simp at hf
  | cons b fuel ih =>
    cases other with
    | nil => simp at ho
    | cons c other =>
      let C := encodedReduceIntegerAll D r le_rfl
      let tests := encodedFailingAdjacentPairs C
      by_cases hbad : tests.Nonempty
      · let p := leastPairInFinset tests hbad
        let W := encodedSwapRows C p.1 p.2
        have hs : encodedReductionFuel (b::fuel) D =
            ⟨(encodedReductionFuel fuel W).rows,(encodedReductionFuel fuel W).swaps+1⟩ := by
          simp only [encodedReductionFuel,show encodedReduceIntegerAll D r le_rfl = C from rfl,
            show encodedFailingAdjacentPairs C = tests from rfl,dif_pos hbad,p,W]
        rw [hs] at hf ho
        have hh := ih other W (by simpa using Nat.lt_of_succ_lt_succ hf)
          (by simpa using Nat.lt_of_succ_lt_succ ho)
        constructor
        · simp only [encodedReductionFuel,show encodedReduceIntegerAll D r le_rfl = C from rfl,
            show encodedFailingAdjacentPairs C = tests from rfl,dif_pos hbad]
          exact congrArg (fun out : EncodedLatticeResult r d => (⟨out.rows,out.swaps+1⟩ : EncodedLatticeResult r d)) hh.1
        · simp only [encodedReductionFuelWork,show encodedReduceIntegerAll D r le_rfl = C from rfl,
            show encodedFailingAdjacentPairs C = tests from rfl,dif_pos hbad]
          rw [show encodedSwapRows C (leastPairInFinset tests hbad).1
            (leastPairInFinset tests hbad).2 = W from rfl,hh.2]
      · constructor
        · simp only [encodedReductionFuel,show encodedReduceIntegerAll D r le_rfl = C from rfl,
            show encodedFailingAdjacentPairs C = tests from rfl,dif_neg hbad]
        · simp only [encodedReductionFuelWork,show encodedReduceIntegerAll D r le_rfl = C from rfl,
            show encodedFailingAdjacentPairs C = tests from rfl,dif_neg hbad]

theorem encodedReductionFuel_zero_rows (fuel : List Bool) (D : BitIntegerMatrixData 0 d) :
    encodedReductionFuel fuel D = ⟨D,0⟩ := by
  cases fuel with
  | nil => rfl
  | cons b fuel =>
    have he : encodedFailingAdjacentPairs D = ∅ := by
      apply Finset.eq_empty_of_forall_not_mem
      intro p
      exact Fin.elim0 p.1
    simp only [encodedReductionFuel,encodedReduceIntegerAll,he,Finset.not_nonempty_empty,↓reduceDIte]

theorem encodedReductionFuelWork_zero_rows (fuel : List Bool) (D : BitIntegerMatrixData 0 d)
    (hf : fuel ≠ []) : encodedReductionFuelWork fuel D = encodedFailingAdjacentPairsWork D := by
  cases fuel with
  | nil => exact False.elim (hf rfl)
  | cons b fuel =>
    have he : encodedFailingAdjacentPairs D = ∅ := by
      apply Finset.eq_empty_of_forall_not_mem
      intro p
      exact Fin.elim0 p.1
    simp only [encodedReductionFuelWork,encodedReduceIntegerAll,encodedReduceIntegerAllWork,he,
      Finset.not_nonempty_empty,↓reduceDIte,zero_add]

theorem encodedIntegerReduction_swaps_lt_fuel (D : BitIntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (bitIntegerMatrixValue D i j:ℝ))) :
    (encodedIntegerReduction D).swaps < (bitMatrixReductionFuel D).length := by
  let S := bitIntegerMatrixSize D
  have hH : ∀ i j, |bitIntegerMatrixValue D i j| ≤ (2^S:ℕ) := by
    intro i j
    rw [← Int.natCast_natAbs]
    exact Int.ofNat_le.mpr (Nat.size_le.mp (bitIntegerMatrix_value_bits D i j)).le
  have hb := (executableIntegerReduction (bitIntegerMatrixValue D) hD).swapCount_input_bits
    (bitIntegerMatrixValue D) (2^S) hH
  change (executableReductionFuel (gramPotential (bitIntegerMatrixValue D)) (bitIntegerMatrixValue D)).2+1 ≤ _ at hb
  have he := congrArg Prod.snd (encodedIntegerReduction_value D hD)
  change (encodedIntegerReduction D).swaps = _ at he
  rw [← he,Nat.size_pow] at hb
  rw [bitMatrixReductionFuel_length]
  exact Nat.lt_of_succ_le hb

/-- The final encoded integer routine obtains fuel by structural list scans
and repetition, with no numerical fuel arithmetic. -/
def structuralEncodedIntegerReduction (D : BitIntegerMatrixData r d) : EncodedLatticeResult r d :=
  encodedReductionFuel (encodedStructuralFuel D) D

theorem structuralEncodedIntegerReduction_eq (D : BitIntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (bitIntegerMatrixValue D i j:ℝ))) :
    structuralEncodedIntegerReduction D = encodedIntegerReduction D := by
  by_cases hr : r = 0
  · subst r
    rw [structuralEncodedIntegerReduction,encodedIntegerReduction,
      encodedReductionFuel_zero_rows,encodedReductionFuel_zero_rows]
  · have hf := encodedIntegerReduction_swaps_lt_fuel D hD
    have ho := hf.trans_le (encodedStructuralFuel_dominates D (by omega))
    exact (encodedReductionTrace_stable_of_stopped _ _ D hf ho).1.symm

theorem structuralEncodedIntegerReduction_canonical (D : BitIntegerMatrixData r d)
    (hD : EncodedIntegerCanonical D) :
    EncodedIntegerCanonical (structuralEncodedIntegerReduction D).rows :=
  encodedReductionFuel_canonical _ D hD

theorem structuralEncodedIntegerReductionWork_eq (D : BitIntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (bitIntegerMatrixValue D i j:ℝ))) :
    encodedReductionFuelWork (encodedStructuralFuel D) D = encodedIntegerReductionWork D := by
  by_cases hr : r = 0
  · subst r
    have hnew : encodedStructuralFuel D ≠ [] := by
      intro he
      have hl := encodedStructuralFuel_length D
      rw [he] at hl
      have hp : 0 < (bitIntegerMatrixSize D+3)^3 := Nat.pow_pos (by omega)
      simp only [List.length_nil,zero_add] at hl
      omega
    have hold : bitMatrixReductionFuel D ≠ [] := by
      intro he
      have hf := encodedIntegerReduction_swaps_lt_fuel D hD
      rw [he] at hf
      simp at hf
    rw [encodedIntegerReductionWork,encodedReductionFuelWork_zero_rows _ _ hnew,
      encodedReductionFuelWork_zero_rows _ _ hold]
  · have hf := encodedIntegerReduction_swaps_lt_fuel D hD
    have ho := hf.trans_le (encodedStructuralFuel_dominates D (by omega))
    exact (encodedReductionTrace_stable_of_stopped _ _ D hf ho).2.symm

theorem structuralEncodedIntegerReduction_spec (D : BitIntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (bitIntegerMatrixValue D i j:ℝ))) :
    IntegerReductionSpecification (bitIntegerMatrixValue D)
      (bitIntegerMatrixValue (structuralEncodedIntegerReduction D).rows)
      (structuralEncodedIntegerReduction D).swaps := by
  rw [structuralEncodedIntegerReduction_eq D hD]
  exact encodedIntegerReduction_spec D hD

end Optss
