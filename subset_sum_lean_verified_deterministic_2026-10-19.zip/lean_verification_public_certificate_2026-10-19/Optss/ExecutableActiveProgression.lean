import Optss.ExecutableProperizationIteration

/-!
# Actual filtering of zero-width GAP coordinates

The output indices come from a computable list filter. The proof-only extension
of coefficient vectors establishes exact equality of values and coefficient
volume. No choice of an ordering is made by the executed construction.
-/
namespace Optss
open scoped BigOperators
variable {d : ℕ}

def positiveIndexList (β : Fin d→ℕ) : List (Fin d) :=
  (List.finRange d).filter (fun j => 0<β j)

@[simp] theorem mem_positiveIndexList (β : Fin d→ℕ) (j : Fin d) :
    j∈positiveIndexList β ↔ 0<β j := by simp [positiveIndexList]

theorem positiveIndexList_nodup (β : Fin d→ℕ) : (positiveIndexList β).Nodup :=
  (List.nodup_finRange d).filter _

theorem positiveIndexList_length_le (β : Fin d→ℕ) : (positiveIndexList β).length≤d := by
  simpa [positiveIndexList] using List.length_filter_le (fun j : Fin d => decide (0<β j)) (List.finRange d)

def positiveListIndex (β : Fin d→ℕ) : Fin (positiveIndexList β).length→Fin d :=
  (positiveIndexList β).get

theorem positiveListIndex_injective (β : Fin d→ℕ) : Function.Injective (positiveListIndex β) :=
  List.nodup_iff_injective_get.mp (positiveIndexList_nodup β)

theorem positiveListIndex_pos (β : Fin d→ℕ) (j : Fin (positiveIndexList β).length) :
    0<β (positiveListIndex β j) :=
  (mem_positiveIndexList _ _).mp (List.get_mem _ _)

theorem positiveListIndex_range (β : Fin d→ℕ) :
    Finset.univ.image (positiveListIndex β)=Finset.univ.filter (fun j => 0<β j) := by
  ext j
  simp only [Finset.mem_image,Finset.mem_univ,true_and,Finset.mem_filter]
  exact (List.mem_iff_get).symm.trans (mem_positiveIndexList β j)

theorem sum_positiveListIndex (β : Fin d→ℕ) (f : Fin d→ℤ)
    (hzero : ∀ j,β j=0→f j=0) :
    ∑ j,f (positiveListIndex β j)=∑ j,f j := by
  classical
  rw [←Finset.sum_image (fun i _ j _ h => positiveListIndex_injective β h),positiveListIndex_range]
  apply Finset.sum_subset (Finset.filter_subset _ _)
  intro j hj hnj
  apply hzero
  simpa only [Finset.mem_filter,Finset.mem_univ,true_and,not_lt,Nat.le_zero] using hnj

theorem prod_positiveListIndex (β : Fin d→ℕ) (f : Fin d→ℕ)
    (hzero : ∀ j,β j=0→f j=1) :
    ∏ j,f (positiveListIndex β j)=∏ j,f j := by
  classical
  rw [←Finset.prod_image (fun i _ j _ h => positiveListIndex_injective β h),positiveListIndex_range]
  apply Finset.prod_subset (Finset.filter_subset _ _)
  intro j hj hnj
  apply hzero
  simpa only [Finset.mem_filter,Finset.mem_univ,true_and,not_lt,Nat.le_zero] using hnj

def executablePositiveGAP (a : Fin d→ℤ) (β : Fin d→ℕ) : ExecutableIntegerGAP :=
  ⟨(positiveIndexList β).length,a ∘positiveListIndex β,β ∘positiveListIndex β⟩

theorem executablePositiveGAP_widths_pos (a : Fin d→ℤ) (β : Fin d→ℕ)
    (j : Fin (executablePositiveGAP a β).rank) :
    0<(executablePositiveGAP a β).widths j := positiveListIndex_pos β j

theorem executablePositiveGAP_card (a : Fin d→ℤ) (β : Fin d→ℕ) :
    (integerBudgetBox (executablePositiveGAP a β).widths).card=(integerBudgetBox β).card := by
  rw [integerBudgetBox_card,integerBudgetBox_card]
  exact prod_positiveListIndex β (fun j => 2*β j+1) (by intro j hj; simp [hj])

theorem executablePositiveGAP_values (a : Fin d→ℤ) (β : Fin d→ℕ) :
    executableGAPValues (executablePositiveGAP a β)=
      integerProgressionValues (progressionLinearEncoding a).toAddMonoidHom β := by
  classical
  have hinj := positiveListIndex_injective β
  ext y
  constructor
  · intro hy
    obtain ⟨x,hx,hxy⟩ := Finset.mem_image.mp hy
    let z : Fin d→ℤ := Function.extend (positiveListIndex β) x (fun _ => 0)
    have hzget : ∀ j,z (positiveListIndex β j)=x j := fun j => hinj.extend_apply x _ j
    have hzzero : ∀ j,β j=0→z j=0 := by
      intro j hj
      apply Function.extend_apply'
      rintro ⟨k,rfl⟩
      have hp := positiveListIndex_pos β k
      omega
    have hzbox : z∈integerBudgetBox β := by
      rw [mem_integerBudgetBox]
      intro j
      by_cases hj : 0<β j
      · obtain ⟨k,hk⟩ := List.mem_iff_get.mp ((mem_positiveIndexList β j).mpr hj)
        change positiveListIndex β k=j at hk
        rw [←hk,hzget]
        exact (mem_integerBudgetBox _ _).mp hx k
      · rw [hzzero j (Nat.eq_zero_of_not_pos hj)]
        simp
    refine Finset.mem_image.mpr ⟨z,hzbox,?_⟩
    change (∑ j,a j*z j)=y
    rw [←sum_positiveListIndex β (fun j => a j*z j) (by intro j hj; dsimp only; rw [hzzero j hj,mul_zero])]
    simpa only [hzget] using hxy
  · intro hy
    obtain ⟨x,hx,hxy⟩ := Finset.mem_image.mp hy
    let z : Fin (positiveIndexList β).length→ℤ := x ∘positiveListIndex β
    have hzbox : z∈integerBudgetBox (executablePositiveGAP a β).widths := by
      rw [mem_integerBudgetBox]
      intro j
      exact (mem_integerBudgetBox _ _).mp hx (positiveListIndex β j)
    refine Finset.mem_image.mpr ⟨z,hzbox,?_⟩
    change (∑ j,a (positiveListIndex β j)*x (positiveListIndex β j))=y
    rw [sum_positiveListIndex β (fun j => a j*x j)]
    · exact hxy
    · intro j hj
      have hxj := (mem_integerBudgetBox β x).mp hx j
      simp only [hj,Int.natCast_zero,abs_nonpos_iff] at hxj
      rw [hxj,mul_zero]

/-- The complete answer for arbitrary widths, including an all-zero box. -/
def properizeIntegerGAP (t : ℕ) (a : Fin d→ℤ) (β : Fin d→ℕ) : ExecutableIntegerGAP :=
  let g := executablePositiveGAP a β
  properizePositiveGAP t g.rank g.generators g.widths

theorem properizeIntegerGAP_spec (t : ℕ) (ht : 0<t) (a : Fin d→ℤ) (β : Fin d→ℕ) :
    (properizeIntegerGAP t a β).rank≤d ∧
    (∀ j,0<(properizeIntegerGAP t a β).widths j) ∧
    Set.InjOn (progressionLinearEncoding (properizeIntegerGAP t a β).generators)
      (integerBudgetBox (fun j => t*(properizeIntegerGAP t a β).widths j)) ∧
    integerProgressionValues (progressionLinearEncoding a).toAddMonoidHom β ⊆
      executableGAPValues (properizeIntegerGAP t a β) ∧
    (integerBudgetBox (properizeIntegerGAP t a β).widths).card≤
      (properizationIterationFactor sharpLatticeDefectBound t d)^d*(integerBudgetBox β).card := by
  have hlen := positiveIndexList_length_le β
  obtain ⟨hr,hpos,hproper,hsub,hcard⟩ := properizePositiveGAP_spec t ht d
    (executablePositiveGAP a β).rank hlen
    (executablePositiveGAP a β).generators (executablePositiveGAP a β).widths
    (executablePositiveGAP_widths_pos a β)
  refine ⟨hr.trans hlen,hpos,hproper,?_,?_⟩
  · rw [←executablePositiveGAP_values a β]
    exact hsub
  · apply hcard.trans
    rw [executablePositiveGAP_card]
    exact Nat.mul_le_mul_right _ (pow_le_pow_right₀
      (properizationIterationFactor_pos sharpLatticeDefectBound t d) hlen)
end Optss
