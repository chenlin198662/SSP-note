import Optss.Progression
import Mathlib.Data.Nat.Log

/-!
# A small-doubling scale in a long integer sumset

This proves the initial dyadic scale-selection step in Conlon--Fox--Pham,
Lemma 2.22, from actual interval containment. The polynomial-scale version
has an explicit constant depending only on an integer polynomial exponent.
It makes no density assumption and does not assume any growth consequence.

Source: https://www.its.caltech.edu/~dconlon/subset_sums_highdim.pdf,
Lemma 2.22 (proof, pp. 14--15). The containing-progression and Bilu
structure theorems remain separate mathematical obligations.
-/
namespace Optss
open scoped Pointwise

/-- An interval bounds every actual repeated sum, including the empty sum. -/
theorem integer_repeated_sumset_subset_interval (A : Finset ℤ) (N : ℕ)
    (hA : A ⊆ Finset.Icc 0 (N : ℤ)) (s : ℕ) :
    s • A ⊆ Finset.Icc 0 ((s * N : ℕ) : ℤ) := by
  induction s with
  | zero =>
      intro x hx
      have hx0 : x = 0 := by simpa using hx
      subst x
      simp
  | succ s ih =>
      rw [succ_nsmul]
      intro x hx
      obtain ⟨a, ha, b, hb, rfl⟩ := Finset.mem_add.mp hx
      have ha' := Finset.mem_Icc.mp (ih ha)
      have hb' := Finset.mem_Icc.mp (hA hb)
      apply Finset.mem_Icc.mpr
      push_cast at *
      constructor <;> nlinarith

/-- The cardinality upper bound used to rule out sustained rapid growth. -/
theorem integer_repeated_sumset_card_le (A : Finset ℤ) (N : ℕ)
    (hA : A ⊆ Finset.Icc 0 (N : ℤ)) (s : ℕ) :
    (s • A).card ≤ s * N + 1 := by
  have h := Finset.card_le_card (integer_repeated_sumset_subset_interval A N hA s)
  rw [Int.card_Icc] at h
  omega

/-- A zero-containing set has nonempty repeated sumsets at every scale. -/
theorem zero_mem_integer_repeated_sumset (A : Finset ℤ) (hA : 0 ∈ A) (s : ℕ) :
    0 ∈ s • A := by
  induction s with
  | zero => simp
  | succ s ih =>
      rw [succ_nsmul]
      simpa using Finset.add_mem_add ih hA

private theorem strict_step_product_bound (f : ℕ → ℕ) (K a L : ℕ) (_hK : 0 < K)
    (hstep : ∀ i, a ≤ i → i < a + L → K * f i < f (i + 1)) :
    K ^ L * f a ≤ f (a + L) ∧
      (0 < L → K ^ L * f a < f (a + L)) := by
  induction L with
  | zero => simp
  | succ L ih =>
      obtain ⟨hle, _⟩ := ih (fun i hi hi' => hstep i hi (by omega))
      have hlast := hstep (a + L) (by omega) (by omega)
      have hmul := Nat.mul_le_mul_left K hle
      have hlt : K ^ (L + 1) * f a < f (a + (L + 1)) := by
        simpa only [pow_succ, Nat.add_assoc, mul_assoc, mul_left_comm, mul_comm]
          using hmul.trans_lt hlast
      exact ⟨hlt.le, fun _ => hlt⟩

/-- Some actual adjacent ratio is at most the geometric mean bound. -/
theorem exists_small_step_of_power_bound (f : ℕ → ℕ) (K a L : ℕ)
    (hK : 0 < K) (hL : 0 < L) (hend : f (a + L) ≤ K ^ L * f a) :
    ∃ i, a ≤ i ∧ i < a + L ∧ f (i + 1) ≤ K * f i := by
  by_contra h
  push_neg at h
  have hstep : ∀ i, a ≤ i → i < a + L → K * f i < f (i + 1) := by
    intro i hi hi'
    exact h i hi hi'
  have hb := (strict_step_product_bound f K a L hK hstep).2 hL
  omega

/-- Dyadic sumsets are the real finite sumsets used in the source argument. -/
def dyadicSumset (A : Finset ℤ) (j : ℕ) : Finset ℤ := (2 ^ j) • A

@[simp] theorem dyadicSumset_succ (A : Finset ℤ) (j : ℕ) :
    dyadicSumset A (j + 1) = dyadicSumset A j + dyadicSumset A j := by
  simp only [dyadicSumset, pow_succ, mul_nsmul, two_nsmul]

/-- A bounded integer input has an actual small-doubling scale. The explicit
condition compares the ambient width with the length of the search window. -/
theorem exists_dyadic_small_doubling (A : Finset ℤ) (N a L r : ℕ)
    (hA : A ⊆ Finset.Icc 0 (N : ℤ)) (hzero : 0 ∈ A)
    (hL : 0 < L) (ha : a ≤ L) (hN : N + 1 ≤ 2 ^ (r * L)) :
    ∃ j, a ≤ j ∧ j < a + L ∧
      (dyadicSumset A j + dyadicSumset A j).card ≤
        2 ^ (r + 2) * (dyadicSumset A j).card := by
  have hend : (dyadicSumset A (a + L)).card ≤ (2 ^ (r + 2)) ^ L := by
    have hcard := integer_repeated_sumset_card_le A N hA (2 ^ (a + L))
    have hp : 1 ≤ 2 ^ (a + L) := Nat.one_le_pow _ _ (by decide)
    calc
      (dyadicSumset A (a + L)).card ≤ 2 ^ (a + L) * N + 1 := hcard
      _ ≤ 2 ^ (a + L) * (N + 1) := by nlinarith
      _ ≤ 2 ^ (a + L) * 2 ^ (r * L) := Nat.mul_le_mul_left _ hN
      _ = 2 ^ (a + L + r * L) := (pow_add _ _ _).symm
      _ ≤ 2 ^ ((r + 2) * L) := Nat.pow_le_pow_right (by decide) (by nlinarith)
      _ = (2 ^ (r + 2)) ^ L := pow_mul _ _ _
  have hpos : 1 ≤ (dyadicSumset A a).card :=
    Finset.card_pos.mpr ⟨0, zero_mem_integer_repeated_sumset A hzero _⟩
  obtain ⟨j, hj, hj', hg⟩ := exists_small_step_of_power_bound
    (fun j => (dyadicSumset A j).card) (2 ^ (r + 2)) a L
    (by positivity) hL (hend.trans (by nlinarith))
  exact ⟨j, hj, hj', by simpa only [dyadicSumset_succ] using hg⟩

/-- At polynomial summation scale, the doubling constant is independent of
both the input cardinality and the ambient interval. The search begins at
any prescribed fixed dyadic scale `a`, and its doubled output stays below `h`. -/
theorem exists_polynomial_scale_small_doubling (A : Finset ℤ) (N h b a : ℕ)
    (hA : A ⊆ Finset.Icc 0 (N : ℤ)) (hzero : 0 ∈ A)
    (hpoly : N + 1 ≤ h ^ b) (hlarge : 2 ^ (2 * max 1 a) ≤ h) :
    ∃ j, a ≤ j ∧ 2 ^ (j + 1) ≤ h ∧
      (dyadicSumset A j + dyadicSumset A j).card ≤
        2 ^ (4 * b + 2) * (dyadicSumset A j).card := by
  let L := Nat.log 2 h / 2
  have hh : h ≠ 0 := by have := Nat.two_pow_pos (2 * max 1 a); omega
  have hlog : 2 * max 1 a ≤ Nat.log 2 h := Nat.le_log_of_pow_le (by decide) hlarge
  have hL : 1 ≤ L := by dsimp [L]; omega
  have ha : a ≤ L := by dsimp [L]; omega
  have hlogL : Nat.log 2 h + 1 ≤ 4 * L := by dsimp [L] at *; omega
  have hN : N + 1 ≤ 2 ^ ((4 * b) * L) := by
    calc
      N + 1 ≤ h ^ b := hpoly
      _ ≤ (2 ^ (Nat.log 2 h + 1)) ^ b :=
        Nat.pow_le_pow_left (Nat.lt_pow_succ_log_self (by decide) h).le _
      _ = 2 ^ ((Nat.log 2 h + 1) * b) := (pow_mul _ _ _).symm
      _ ≤ 2 ^ ((4 * b) * L) := Nat.pow_le_pow_right (by decide) (by nlinarith)
  obtain ⟨j, haj, hj, hd⟩ := exists_dyadic_small_doubling A N a L (4*b)
    hA hzero (by omega) ha hN
  refine ⟨j, haj, ?_, hd⟩
  apply Nat.pow_le_of_le_log hh
  dsimp [L] at *
  omega

/-- Explicit integer exponent converting the paper's real power assumption
into the polynomial ambient bound needed above. -/
noncomputable def longSumsetExponent (α : ℝ) : ℕ := ⌈2 / α⌉₊

theorem longSumsetExponent_bound (α : ℝ) (hα : 0 < α) :
    2 ≤ α * longSumsetExponent α := by
  have h := mul_le_mul_of_nonneg_left (Nat.le_ceil (2 / α)) hα.le
  rw [mul_div_cancel₀ _ hα.ne'] at h
  exact h

/-- No density lower bound is needed in the exponent conversion. -/
theorem longSumset_polynomial_ambient (α : ℝ) (hα : 0 < α) (N h : ℕ)
    (hN : 2 ≤ N) (hscale : (N : ℝ) ^ α ≤ h) :
    N + 1 ≤ h ^ longSumsetExponent α := by
  have hN0 : (0 : ℝ) ≤ N := by positivity
  have hN1 : (1 : ℝ) ≤ N := by exact_mod_cast (by omega : 1 ≤ N)
  have hexp := longSumsetExponent_bound α hα
  have hpow := Real.rpow_le_rpow_of_exponent_le hN1 hexp
  rw [Real.rpow_mul hN0, Real.rpow_natCast] at hpow
  have hmono := pow_le_pow_left₀ (Real.rpow_nonneg hN0 α) hscale (longSumsetExponent α)
  have hNcard : (N + 1 : ℝ) ≤ (N : ℝ) ^ (2 : ℝ) := by
    rw [Real.rpow_two]
    have hN2 : (2 : ℝ) ≤ N := by exact_mod_cast hN
    nlinarith
  have hout := hNcard.trans (hpow.trans hmono)
  exact_mod_cast hout

/-- The small-doubling consequence of a real polynomial summation scale,
with a fully explicit constant and a concrete summation threshold. This is
only the scale-selection stage of Theorem 2.A, not GAP existence. -/
theorem exists_real_power_scale_small_doubling (α : ℝ) (hα : 0 < α)
    (A : Finset ℤ) (N h a : ℕ) (hN : 2 ≤ N)
    (hA : A ⊆ Finset.Icc 0 (N : ℤ)) (hzero : 0 ∈ A)
    (hscale : (N : ℝ) ^ α ≤ h) (hlarge : 2 ^ (2 * max 1 a) ≤ h) :
    ∃ j, a ≤ j ∧ 2 ^ (j + 1) ≤ h ∧
      (dyadicSumset A j + dyadicSumset A j).card ≤
        2 ^ (4 * longSumsetExponent α + 2) * (dyadicSumset A j).card :=
  exists_polynomial_scale_small_doubling A N h (longSumsetExponent α) a hA hzero
    (longSumset_polynomial_ambient α hα N h hN hscale) hlarge

/-- The sufficiently-large-ambient formulation: every fixed positive real
power admits a uniformly bounded doubling factor at some dyadic scale in
the prescribed range. No progression or growth profile is an input. -/
theorem exists_uniform_polynomial_doubling_factor (α : ℝ) (hα : 0 < α) (a : ℕ) :
    ∃ K N₀ : ℕ, 0 < K ∧ ∀ (N h : ℕ) (A : Finset ℤ),
      N₀ ≤ N → A ⊆ Finset.Icc 0 (N : ℤ) → 0 ∈ A → (N : ℝ) ^ α ≤ h →
      ∃ j, a ≤ j ∧ 2 ^ (j + 1) ≤ h ∧
        (dyadicSumset A j + dyadicSumset A j).card ≤ K * (dyadicSumset A j).card := by
  let H : ℕ := 2 ^ (2 * max 1 a)
  let N₀ : ℕ := max 2 ⌈(H : ℝ) ^ α⁻¹⌉₊
  refine ⟨2 ^ (4 * longSumsetExponent α + 2), N₀, by positivity, ?_⟩
  intro N h A hN hA hzero hscale
  have hN2 : 2 ≤ N := (le_max_left _ _).trans hN
  have hroot : (H : ℝ) ^ α⁻¹ ≤ N := by
    calc
      (H : ℝ) ^ α⁻¹ ≤ (⌈(H : ℝ) ^ α⁻¹⌉₊ : ℝ) := Nat.le_ceil _
      _ ≤ (N₀ : ℝ) := by exact_mod_cast (le_max_right 2 ⌈(H : ℝ) ^ α⁻¹⌉₊)
      _ ≤ N := by exact_mod_cast hN
  have hH : (H : ℝ) ≤ (N : ℝ) ^ α := by
    have hp := Real.rpow_le_rpow (Real.rpow_nonneg (by positivity) α⁻¹) hroot hα.le
    rwa [Real.rpow_inv_rpow (by positivity) hα.ne'] at hp
  have hlarge : H ≤ h := by exact_mod_cast hH.trans hscale
  exact exists_real_power_scale_small_doubling α hα A N h a hN2 hA hzero hscale hlarge

end Optss
