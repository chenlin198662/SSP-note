import Optss.RationalFourierHeight
import Optss.BooleanFourierArithmetic
import Optss.BitListRationalOrderRound

/-! Character preparation using stored Boolean fractions throughout.
Well-formedness certificates erase at compilation; no rational encoding or
decoding is called by the answer routines. Small Taylor indices are encoded
by a counted unary succession, while the modulus and phase index arrive as
already stored fractions. -/
namespace Optss
open scoped BigOperators

def fourierUnaryDigits : ℕ → List Bool
  | 0 => []
  | n+1 => bitListAdd (fourierUnaryDigits n) [true]

theorem fourierUnaryDigits_value (n : ℕ) : binaryDigitsValue (fourierUnaryDigits n)=n := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [fourierUnaryDigits,bitListAdd_correct,ih,binaryDigitsValue,
      Bool.toNat_true,mul_zero,add_zero]

theorem fourierUnaryDigits_canonical (n : ℕ) : BitListCanonical (fourierUnaryDigits n) := by
  cases n with
  | zero => simp [BitListCanonical,fourierUnaryDigits,binaryDigitsValue]
  | succ n => exact bitListTrim_canonical _

abbrev FourierFraction := {q : BitListFraction // q.WellFormed}

def FourierFraction.value (q : FourierFraction) : ℚ := bitListFractionValue q.val

def FourierFraction.nat (n : ℕ) : FourierFraction :=
  ⟨⟨false,fourierUnaryDigits n,[true]⟩,by
    refine ⟨fourierUnaryDigits_canonical n,?_,?_,?_⟩
    · norm_num [BitListCanonical,binaryDigitsValue]
    · norm_num [binaryDigitsValue]
    · simpa only [binaryDigitsValue,Bool.toNat_true,mul_zero,add_zero] using Nat.coprime_one_right _⟩

def FourierFraction.neg (q : FourierFraction) : FourierFraction :=
  ⟨bitListFractionNeg q.val,bitListFractionNeg_wellFormed q.val q.property⟩
def FourierFraction.add (q r : FourierFraction) : FourierFraction :=
  ⟨bitListFractionAdd q.val r.val,bitListFractionAdd_wellFormed _ _ q.property.2.2.1 r.property.2.2.1⟩
def FourierFraction.mul (q r : FourierFraction) : FourierFraction :=
  ⟨bitListFractionMul q.val r.val,bitListFractionMul_wellFormed _ _ q.property.2.2.1 r.property.2.2.1⟩
def FourierFraction.div (q r : FourierFraction) : FourierFraction :=
  ⟨bitListFractionDiv q.val r.val,bitListFractionDiv_wellFormed _ _ q.property.2.2.1⟩

@[simp] theorem FourierFraction.nat_value (n : ℕ) : (FourierFraction.nat n).value=n := by
  simp only [FourierFraction.nat,FourierFraction.value,bitListFractionValue,signedBitsValue,
    Bool.false_eq_true,↓reduceIte,binaryDigitsValue,Bool.toNat_true,mul_zero,add_zero,zero_add,
    fourierUnaryDigits_value,Nat.cast_one,div_one,Int.cast_natCast]

@[simp] theorem FourierFraction.neg_value (q : FourierFraction) : q.neg.value = -q.value :=
  bitListFractionNeg_correct _
@[simp] theorem FourierFraction.add_value (q r : FourierFraction) : (q.add r).value=q.value+r.value :=
  bitListFractionAdd_correct _ _ q.property.2.2.1 r.property.2.2.1
@[simp] theorem FourierFraction.mul_value (q r : FourierFraction) : (q.mul r).value=q.value*r.value :=
  bitListFractionMul_correct _ _ q.property.2.2.1 r.property.2.2.1
@[simp] theorem FourierFraction.div_value (q r : FourierFraction) : (q.div r).value=q.value/r.value :=
  bitListFractionDiv_correct _ _ q.property.2.2.1 r.property.2.2.1

def FourierFraction.pow (q : FourierFraction) : ℕ → FourierFraction
  | 0 => FourierFraction.nat 1
  | n+1 => (q.pow n).mul q

@[simp] theorem FourierFraction.pow_value (q : FourierFraction) (n : ℕ) :
    (q.pow n).value=q.value^n := by
  induction n with
  | zero => simp [FourierFraction.pow]
  | succ n ih => simp only [FourierFraction.pow,FourierFraction.mul_value,ih,pow_succ]

def fourierFractionSum (f : ℕ → FourierFraction) : ℕ → FourierFraction
  | 0 => FourierFraction.nat 0
  | n+1 => (fourierFractionSum f n).add (f n)

@[simp] theorem fourierFractionSum_value (f : ℕ → FourierFraction) (n : ℕ) :
    (fourierFractionSum f n).value=∑ j∈Finset.range n, (f j).value := by
  induction n with
  | zero => simp [fourierFractionSum]
  | succ n ih => simp only [fourierFractionSum,FourierFraction.add_value,ih,Finset.sum_range_succ]

def bitArctanTerm (x : FourierFraction) (i : ℕ) : FourierFraction :=
  (((FourierFraction.nat 1).neg.pow i).mul (x.pow (2*i+1))).div (FourierFraction.nat (2*i+1))

def bitArctanPartial (x : FourierFraction) (n : ℕ) : FourierFraction :=
  fourierFractionSum (bitArctanTerm x) (2*n)

theorem bitArctanTerm_value (x : FourierFraction) (i : ℕ) :
    (bitArctanTerm x i).value=(-1 : ℚ)^i*x.value^(2*i+1)/(2*i+1) := by
  simp [bitArctanTerm]

theorem bitArctanPartial_value (x : FourierFraction) (n : ℕ) :
    (bitArctanPartial x n).value=rationalArctanPartial x.value n := by
  simp only [bitArctanPartial,fourierFractionSum_value,bitArctanTerm_value,rationalArctanPartial]

def bitPiApproximation (n : ℕ) : FourierFraction :=
  (FourierFraction.nat 4).mul
    ((bitArctanPartial ((FourierFraction.nat 1).div (FourierFraction.nat 2)) n).add
      (bitArctanPartial ((FourierFraction.nat 1).div (FourierFraction.nat 3)) n))

theorem bitPiApproximation_value (n : ℕ) : (bitPiApproximation n).value=rationalPiApproximation n := by
  simp [bitPiApproximation,bitArctanPartial_value,rationalPiApproximation]

def bitFourierPhaseAngle (X M : FourierFraction) (p : ℕ) : FourierFraction :=
  ((((FourierFraction.nat 2).mul (bitPiApproximation (p+2))).mul X).div M)

theorem bitFourierPhaseAngle_value (X M : FourierFraction) (p : ℕ) :
    (bitFourierPhaseAngle X M p).value=2*rationalPiApproximation (p+2)*X.value/M.value := by
  simp [bitFourierPhaseAngle,bitPiApproximation_value]

def bitImaginaryPower (t : FourierFraction) : ℕ → FourierFraction×FourierFraction
  | 0 => (FourierFraction.nat 1,FourierFraction.nat 0)
  | n+1 => let z := bitImaginaryPower t n; (t.neg.mul z.2,t.mul z.1)

theorem bitImaginaryPower_value (t : FourierFraction) (n : ℕ) :
    ((bitImaginaryPower t n).1.value,(bitImaginaryPower t n).2.value)=rationalImaginaryPower t.value n := by
  induction n with
  | zero => simp [bitImaginaryPower,rationalImaginaryPower]
  | succ n ih =>
    have hre := congrArg Prod.fst ih
    have him := congrArg Prod.snd ih
    dsimp only at hre him
    simp only [bitImaginaryPower,FourierFraction.mul_value,FourierFraction.neg_value,
      hre,him,rationalImaginaryPower]

def bitFourierFactorial : ℕ → FourierFraction
  | 0 => FourierFraction.nat 1
  | n+1 => (FourierFraction.nat (n+1)).mul (bitFourierFactorial n)

@[simp] theorem bitFourierFactorial_value (n : ℕ) : (bitFourierFactorial n).value=n.factorial := by
  induction n with
  | zero => simp [bitFourierFactorial]
  | succ n ih => simp only [bitFourierFactorial,FourierFraction.mul_value,FourierFraction.nat_value,ih,
      Nat.factorial_succ,Nat.cast_mul]

def bitImaginaryExpPartial (t : FourierFraction) (n : ℕ) : FourierFraction×FourierFraction :=
  (fourierFractionSum (fun j => (bitImaginaryPower t j).1.div (bitFourierFactorial j)) n,
   fourierFractionSum (fun j => (bitImaginaryPower t j).2.div (bitFourierFactorial j)) n)

theorem bitImaginaryExpPartial_value (t : FourierFraction) (n : ℕ) :
    ((bitImaginaryExpPartial t n).1.value,(bitImaginaryExpPartial t n).2.value)=
      rationalImaginaryExpPartial t.value n := by
  have hre j := congrArg Prod.fst (bitImaginaryPower_value t j)
  have him j := congrArg Prod.snd (bitImaginaryPower_value t j)
  dsimp only at hre him
  simp only [bitImaginaryExpPartial,fourierFractionSum_value,FourierFraction.div_value,
    bitFourierFactorial_value,hre,him,rationalImaginaryExpPartial]

def bitRationalCharacter (X M : FourierFraction) (p : ℕ) : FourierFraction×FourierFraction :=
  let t := bitFourierPhaseAngle X M p
  bitImaginaryExpPartial t (68+p)

theorem bitRationalCharacter_value {N : ℕ} [NeZero N] (x : ZMod N) (X M : FourierFraction)
    (hX : X.value=(x.val : ℚ)) (hM : M.value=(N : ℚ)) (p : ℕ) :
    ((bitRationalCharacter X M p).1.value,(bitRationalCharacter X M p).2.value)=
      rationalCharacterApproximation x p := by
  simp only [bitRationalCharacter,bitImaginaryExpPartial_value,bitFourierPhaseAngle_value,hX,hM,
    rationalCharacterApproximation,rationalPhaseAngle]

def bitFourierRoundedFraction (q : FourierFraction) : BitListInteger :=
  let r := bitListFractionRound q.val
  ⟨r.1,bitListTrim r.2⟩

theorem bitFourierRoundedFraction_value (q : FourierFraction) :
    (bitFourierRoundedFraction q).value=round q.value := by
  change signedBitsValue (bitListFractionRound q.val).1 (bitListTrim (bitListFractionRound q.val).2)=_
  have he : signedBitsValue (bitListFractionRound q.val).1 (bitListTrim (bitListFractionRound q.val).2)=
      signedBitsValue (bitListFractionRound q.val).1 (bitListFractionRound q.val).2 := by
    simp only [signedBitsValue,bitListTrim_value]
  rw [he]
  exact bitListFractionRound_correct _ q.property.2.2.1

theorem bitFourierRoundedFraction_canonical (q : FourierFraction) :
    BitListCanonical (bitFourierRoundedFraction q).digits := bitListTrim_canonical _

end Optss
