import Optss.EncodedScalarBounds
import Optss.PrimitiveCachedArithmeticWork

/-!
# Proof-only scalar envelopes for encoded execution

This module defines a numerical upper-bound model, not another implementation.
Its charges depend only on decoded operand bit widths. Direct Boolean-list
charges lie below them for canonical inputs, including either sign of zero.
Thus existing actual-state height theorems can bound encoded execution without
assuming that representation conversion is free.
-/

namespace Optss

def rationalOperandWidth (q : ℚ) : ℕ := max q.num.natAbs.size q.den.size

def rationalPairEnvelope (p q : ℚ) : ℕ :=
  65536*(max (rationalOperandWidth p) (rationalOperandWidth q)+1)^3

def rationalUnaryEnvelope (p : ℚ) : ℕ := 65536*(rationalOperandWidth p+1)^3

def integerCellEnvelope (u c v : ℤ) : ℕ :=
  65536*(max u.natAbs.size (max c.natAbs.size v.natAbs.size)+1)^3

theorem rationalOperandWidth_bound (q : ℚ) : RationalBitBound q (rationalOperandWidth q) :=
  ⟨le_max_left _ _, le_max_right _ _⟩

theorem rationalOperandWidth_le {q : ℚ} {L : ℕ} (h : RationalBitBound q L) :
    rationalOperandWidth q ≤ L := max_le h.1 h.2

theorem rationalPairEnvelope_bound (p q : ℚ) (L : ℕ)
    (hp : RationalBitBound p L) (hq : RationalBitBound q L) :
    rationalPairEnvelope p q ≤ 65536*(L+1)^3 := by
  apply Nat.mul_le_mul_left
  apply Nat.pow_le_pow_left
  exact Nat.add_le_add_right (max_le (rationalOperandWidth_le hp) (rationalOperandWidth_le hq)) 1

theorem rationalUnaryEnvelope_bound (p : ℚ) (L : ℕ) (hp : RationalBitBound p L) :
    rationalUnaryEnvelope p ≤ 65536*(L+1)^3 := by
  exact Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (Nat.add_le_add_right (rationalOperandWidth_le hp) 1) _)

theorem integerCellEnvelope_bound (u c v : ℤ) (L : ℕ)
    (hu : u.natAbs.size ≤ L) (hc : c.natAbs.size ≤ L) (hv : v.natAbs.size ≤ L) :
    integerCellEnvelope u c v ≤ 65536*(L+1)^3 := by
  exact Nat.mul_le_mul_left _
    (Nat.pow_le_pow_left (Nat.add_le_add_right (max_le hu (max_le hc hv)) 1) _)

/-- A proof-only upper-bound evaluator; its arithmetic answers specify values
and are not the encoded answer routines. -/
def envelopeReductionPrimitives : ReductionPrimitives where
  add p q := (p+q,rationalPairEnvelope p q)
  sub p q := (p-q,rationalPairEnvelope p q)
  mul p q := (p*q,rationalPairEnvelope p q)
  div p q := (p/q,rationalPairEnvelope p q)
  lt p q := (decide (p<q),rationalPairEnvelope p q)
  round p := (round p,rationalUnaryEnvelope p)
  rowCell u c v := (u-c*v,integerCellEnvelope u c v)
  add_value _ _ := rfl
  sub_value _ _ := rfl
  mul_value _ _ := rfl
  div_value _ _ := rfl
  lt_value _ _ := rfl
  round_value _ := rfl
  rowCell_value _ _ _ := rfl

def envelopeCubicReductionBackend : CubicReductionBackend where
  primitives := envelopeReductionPrimitives
  constant := 65536
  positive := by decide
  rational_charge p q L hp hq := by
    have h := rationalPairEnvelope_bound p q L hp hq
    exact ⟨h,h,h,h⟩
  round_charge := rationalUnaryEnvelope_bound
  lt_charge := rationalPairEnvelope_bound
  rowCell_charge := integerCellEnvelope_bound

/-- Physical gate/list costs bounded from the normalized stored operands. -/
theorem encodedFraction_envelope_bounds (p q : BitListFraction)
    (hp : p.WellFormed) (hq : q.WellFormed) :
    bitListFractionAddCost p q ≤ rationalPairEnvelope (bitListFractionValue p) (bitListFractionValue q) ∧
    bitListFractionSubCost p q ≤ rationalPairEnvelope (bitListFractionValue p) (bitListFractionValue q) ∧
    bitListFractionMulCost p q ≤ rationalPairEnvelope (bitListFractionValue p) (bitListFractionValue q) ∧
    bitListFractionDivCost p q ≤ rationalPairEnvelope (bitListFractionValue p) (bitListFractionValue q) ∧
    bitListFractionLTCost p q ≤ rationalPairEnvelope (bitListFractionValue p) (bitListFractionValue q) := by
  let L := max (rationalOperandWidth (bitListFractionValue p)) (rationalOperandWidth (bitListFractionValue q))
  have hpbit : RationalBitBound (bitListFractionValue p) L := by
    have h := rationalOperandWidth_bound (bitListFractionValue p)
    exact ⟨h.1.trans (le_max_left _ _),h.2.trans (le_max_left _ _)⟩
  have hqbit : RationalBitBound (bitListFractionValue q) L := by
    have h := rationalOperandWidth_bound (bitListFractionValue q)
    exact ⟨h.1.trans (le_max_right _ _),h.2.trans (le_max_right _ _)⟩
  have h := encodedFraction_scalar_bounds p q hp hq L hpbit hqbit
  exact ⟨h.1,h.2.1,h.2.2.1,h.2.2.2.1,h.2.2.2.2.1⟩

theorem encodedRound_envelope_bound (p : BitListFraction) (hp : p.WellFormed) :
    bitListFractionRoundCost p ≤ rationalUnaryEnvelope (bitListFractionValue p) := by
  have h := encodedFraction_scalar_bounds p p hp hp (rationalOperandWidth (bitListFractionValue p))
    (rationalOperandWidth_bound _) (rationalOperandWidth_bound _)
  exact h.2.2.2.2.2

theorem encodedInteger_envelope_bound (u c v : BitListInteger)
    (hu : BitListCanonical u.digits) (hc : BitListCanonical c.digits)
    (hv : BitListCanonical v.digits) :
    bitListIntegerRowCellCost u c v ≤ integerCellEnvelope u.value c.value v.value := by
  apply encodedInteger_rowCell_bound u c v hu hc hv
  · exact le_max_left _ _
  · exact (le_max_left _ _).trans (le_max_right _ _)
  · exact (le_max_right _ _).trans (le_max_right _ _)

end Optss
