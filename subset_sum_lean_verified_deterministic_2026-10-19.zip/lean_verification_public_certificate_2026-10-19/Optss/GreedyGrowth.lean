import Mathlib.Algebra.Group.Pointwise.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Data.Finset.Lattice.Fold
import Mathlib.Tactic

/-!
# Greedy growth (Lemma 2.E)

A complete counting proof in an arbitrary additive commutative group. Repeated
sumsets allow repetitions; no available-copy or torsion-free assumption is used.
-/

namespace Optss
open scoped BigOperators Pointwise

variable {G : Type*} [AddCommGroup G] [DecidableEq G]

/-- The points newly obtained by translating a finite set. -/
def translationIncrement (S : Finset G) (a : G) : ℕ :=
  ((S.image (fun x => x + a)) \ S).card

@[simp] theorem translationIncrement_zero (S : Finset G) :
    translationIncrement S 0 = 0 := by
  simp [translationIncrement]

/-- Translation increments are subadditive. -/
theorem translationIncrement_add_le (S : Finset G) (a b : G) :
    translationIncrement S (a + b) ≤
      translationIncrement S a + translationIncrement S b := by
  let A := (S.image (fun x => x + a)) \ S
  let B := (S.image (fun x => x + b)) \ S
  have hsub : (S.image (fun x => x + (a + b))) \ S ⊆
      A.image (fun x => x + b) ∪ B := by
    intro x hx
    obtain ⟨hx, hnot⟩ := Finset.mem_sdiff.mp hx
    obtain ⟨s, hs, rfl⟩ := Finset.mem_image.mp hx
    by_cases hsa : s + a ∈ S
    · apply Finset.mem_union_right
      exact Finset.mem_sdiff.mpr ⟨Finset.mem_image.mpr
        ⟨s + a, hsa, add_assoc s a b⟩, hnot⟩
    · apply Finset.mem_union_left
      exact Finset.mem_image.mpr ⟨s + a,
        Finset.mem_sdiff.mpr ⟨Finset.mem_image.mpr ⟨s, hs, rfl⟩, hsa⟩,
        add_assoc s a b⟩
  calc
    translationIncrement S (a + b) ≤ (A.image (fun x => x + b) ∪ B).card :=
      Finset.card_le_card hsub
    _ ≤ (A.image (fun x => x + b)).card + B.card := Finset.card_union_le _ _
    _ = translationIncrement S a + translationIncrement S b := by
      rw [Finset.card_image_of_injective A (fun _ _ h => add_right_cancel h)]
      rfl

/-- Translating by a repeated sum incurs at most the sum of the one-step bounds. -/
theorem translationIncrement_nsmul_le (S U : Finset G) (M : ℕ)
    (hM : ∀ u ∈ U, translationIncrement S u ≤ M) :
    ∀ (k : ℕ) (a : G), a ∈ k • U → translationIncrement S a ≤ k * M := by
  intro k
  induction k with
  | zero =>
    intro a ha
    have : a = 0 := by simpa using ha
    subst a
    simp
  | succ k ih =>
    intro a ha
    rw [succ_nsmul] at ha
    obtain ⟨x, hx, u, hu, rfl⟩ := Finset.mem_add.mp ha
    calc
      translationIncrement S (x + u) ≤ translationIncrement S x +
          translationIncrement S u := translationIncrement_add_le S x u
      _ ≤ k * M + M := Nat.add_le_add (ih x hx) (hM u hu)
      _ = (k + 1) * M := by ring

/-- Survivors of a translation, indexed by their original point. -/
def translationOverlap (S : Finset G) (a : G) : ℕ :=
  (S.filter (fun x => x + a ∈ S)).card

theorem translationIncrement_add_overlap (S : Finset G) (a : G) :
    translationIncrement S a + translationOverlap S a = S.card := by
  have heq : (S.image (fun x => x + a)) ∩ S =
      (S.filter (fun x => x + a ∈ S)).image (fun x => x + a) := by
    ext x
    simp only [Finset.mem_inter, Finset.mem_image, Finset.mem_filter]
    constructor
    · rintro ⟨⟨y, hy, rfl⟩, hya⟩
      exact ⟨y, ⟨hy, hya⟩, rfl⟩
    · rintro ⟨y, ⟨hy, hya⟩, rfl⟩
      exact ⟨⟨y, hy, rfl⟩, hya⟩
  have h := Finset.card_sdiff_add_card_inter (S.image (fun x => x + a)) S
  rw [heq, Finset.card_image_of_injective _ (fun _ _ h => add_right_cancel h),
    Finset.card_image_of_injective _ (fun _ _ h => add_right_cancel h)] at h
  exact h

/-- There are at most `|S|²` representations of arbitrary translations as
 differences of two elements of `S`. -/
theorem sum_translationOverlap_le (S A : Finset G) :
    ∑ a ∈ A, translationOverlap S a ≤ S.card * S.card := by
  have hswap : ∑ a ∈ A, translationOverlap S a =
      ∑ s ∈ S, (A.filter (fun a => s + a ∈ S)).card := by
    simp only [translationOverlap, Finset.card_eq_sum_ones, Finset.sum_filter]
    exact Finset.sum_comm
  rw [hswap]
  calc
    ∑ s ∈ S, (A.filter (fun a => s + a ∈ S)).card ≤ ∑ _s ∈ S, S.card := by
      apply Finset.sum_le_sum
      intro s _
      have hsub : (A.filter (fun a => s + a ∈ S)).image (fun a => s + a) ⊆ S := by
        intro x hx
        obtain ⟨a, ha, rfl⟩ := Finset.mem_image.mp hx
        exact (Finset.mem_filter.mp ha).2
      have h := Finset.card_le_card hsub
      rwa [Finset.card_image_of_injective _ (fun _ _ h => add_left_cancel h)] at h
    _ = S.card * S.card := by simp

/-- A set of at least `2|S|` translations contains one adding at least `|S|/2`
new points. This is the double-counting step of Lemma 2.E. -/
theorem exists_large_translationIncrement (S A : Finset G) (hS : S.Nonempty)
    (hA : 2 * S.card ≤ A.card) :
    ∃ a ∈ A, S.card ≤ 2 * translationIncrement S a := by
  by_contra h
  push_neg at h
  have hs : 0 < S.card := Finset.card_pos.mpr hS
  have ha : A.Nonempty := Finset.card_pos.mp (by omega)
  have hover : ∀ a ∈ A, S.card < 2 * translationOverlap S a := by
    intro a ha
    have hid := translationIncrement_add_overlap S a
    have hlt := h a ha
    omega
  have hsum : A.card * S.card < 2 * ∑ a ∈ A, translationOverlap S a := by
    calc
      A.card * S.card = ∑ _a ∈ A, S.card := by simp
      _ < ∑ a ∈ A, 2 * translationOverlap S a :=
        Finset.sum_lt_sum_of_nonempty ha hover
      _ = 2 * ∑ a ∈ A, translationOverlap S a := by rw [Finset.mul_sum]
  have hbound := sum_translationOverlap_le S A
  nlinarith

/-- **Lemma 2.E (greedy growth), also equation (57).** If the `k`-fold
sumset of `U` has at least twice as many elements as `S`, some available
value adds at least `|S|/(2k)` new sums. The integral inequality avoids
rounding conventions for division. -/
theorem greedy_growth (S U : Finset G) (hS : S.Nonempty) (hU : U.Nonempty)
    (k : ℕ) (_hk : 1 ≤ k) (hgrowth : 2 * S.card ≤ (k • U).card) :
    ∃ u ∈ U, S.card ≤ 2 * k * ((S + {u}) \ S).card := by
  obtain ⟨u, hu, hmax⟩ := U.exists_mem_eq_sup hU (translationIncrement S)
  obtain ⟨a, ha, hlarge⟩ := exists_large_translationIncrement S (k • U) hS hgrowth
  have hsmall := translationIncrement_nsmul_le S U
    (U.sup (translationIncrement S)) (fun x hx => Finset.le_sup hx) k a ha
  have hinc : S + {u} = S.image (fun x => x + u) := by
    ext x
    simp only [Finset.mem_add, Finset.mem_singleton, Finset.mem_image]
    aesop
  refine ⟨u, hu, ?_⟩
  rw [hinc]
  change S.card ≤ 2 * k * translationIncrement S u
  rw [hmax] at hsmall
  nlinarith

/-- The real-valued form printed in Lemma 2.E. -/
theorem greedy_growth_div (S U : Finset G) (hS : S.Nonempty) (hU : U.Nonempty)
    (k : ℕ) (hk : 1 ≤ k) (hgrowth : 2 * S.card ≤ (k • U).card) :
    ∃ u ∈ U, (S.card : ℝ) / (2 * (k : ℝ)) ≤ (((S + {u}) \ S).card : ℝ) := by
  obtain ⟨u, hu, hg⟩ := greedy_growth S U hS hU k hk hgrowth
  refine ⟨u, hu, (div_le_iff₀ ?_).mpr ?_⟩
  · have : (0 : ℝ) < k := by exact_mod_cast (show 0 < k by omega)
    positivity
  · have hcast : (S.card : ℝ) ≤ 2 * (k : ℝ) * (((S + {u}) \ S).card : ℝ) := by
      exact_mod_cast hg
    nlinarith

end Optss
