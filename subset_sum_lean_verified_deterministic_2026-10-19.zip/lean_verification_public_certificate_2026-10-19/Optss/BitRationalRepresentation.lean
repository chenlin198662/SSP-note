import Optss.BitListRationalNormalization
import Optss.BinaryRationalCost

/-!
# Exact representation bridge for signed binary fractions

A well-formed fraction stores canonical magnitude lists, a positive denominator
and coprime fields. It converts directly to Lean's rational structure without
calling rational normalization. The inverse representation exposes precisely
the reduced numerator and denominator bit lengths used in the cost bounds.
Encoding/decoding costs remain separate from these value/length equalities.
-/

namespace Optss

theorem signedBitsValue_natAbs (negative : Bool) (digits : List Bool) :
    (signedBitsValue negative digits).natAbs = binaryDigitsValue digits := by
  cases negative <;> simp [signedBitsValue]

def BitListFraction.WellFormed (q : BitListFraction) : Prop :=
  BitListCanonical q.numerator ∧ BitListCanonical q.denominator ∧
    0 < binaryDigitsValue q.denominator ∧
    (binaryDigitsValue q.numerator).Coprime (binaryDigitsValue q.denominator)

theorem bitListNormalizeFraction_wellFormed (negative : Bool) (ns ds : List Bool)
    (hd : 0 < binaryDigitsValue ds) :
    (bitListNormalizeFraction negative ns ds).WellFormed :=
  bitListNormalizeFraction_reduced negative ns ds hd

/-- Reconstruct from already coprime fields; no gcd/normalizer is called. -/
def BitListFraction.toRat (q : BitListFraction) (hq : q.WellFormed) : ℚ :=
  Rat.mk' (signedBitsValue q.negative q.numerator) (binaryDigitsValue q.denominator)
    hq.2.2.1.ne' (by rw [signedBitsValue_natAbs]; exact hq.2.2.2)

theorem BitListFraction.toRat_value (q : BitListFraction) (hq : q.WellFormed) :
    q.toRat hq = bitListFractionValue q := by
  change q.toRat hq = ((q.toRat hq).num:ℚ)/((q.toRat hq).den:ℚ)
  exact (Rat.num_div_den _).symm

def rationalBitRepresentation (q : ℚ) : BitListFraction :=
  ⟨decide (q.num < 0), q.num.natAbs.bits, q.den.bits⟩

theorem rationalBitRepresentation_signed (q : ℚ) :
    signedBitsValue (rationalBitRepresentation q).negative
      (rationalBitRepresentation q).numerator = q.num := by
  simp only [rationalBitRepresentation, signedBitsValue, binaryDigitsValue_bits]
  by_cases hn : q.num < 0
  · simp [hn, Int.natCast_natAbs, abs_of_neg hn]
  · simp [hn, Int.natCast_natAbs, abs_of_nonneg (le_of_not_gt hn)]

theorem rationalBitRepresentation_wellFormed (q : ℚ) : (rationalBitRepresentation q).WellFormed := by
  simp only [BitListFraction.WellFormed, rationalBitRepresentation, BitListCanonical,
    binaryDigitsValue_bits]
  exact ⟨True.intro,True.intro,q.den_pos,q.reduced⟩

theorem rationalBitRepresentation_value (q : ℚ) :
    bitListFractionValue (rationalBitRepresentation q) = q := by
  unfold bitListFractionValue
  rw [rationalBitRepresentation_signed]
  change (q.num:ℚ)/(binaryDigitsValue q.den.bits:ℚ) = q
  rw [binaryDigitsValue_bits, Rat.num_div_den]

theorem rationalBitRepresentation_toRat (q : ℚ) :
    (rationalBitRepresentation q).toRat (rationalBitRepresentation_wellFormed q) = q := by
  rw [BitListFraction.toRat_value, rationalBitRepresentation_value]

/-- Sign storage uses one Boolean; these equalities concern magnitude bits. -/
theorem rationalBitRepresentation_lengths (q : ℚ) :
    (rationalBitRepresentation q).numerator.length = q.num.natAbs.size ∧
    (rationalBitRepresentation q).denominator.length = q.den.size := by
  simp only [rationalBitRepresentation, Nat.size_eq_bits_len, and_self]

theorem rationalBitRepresentation_bound (q : ℚ) (L : ℕ) :
    RationalBitBound q L ↔
      (rationalBitRepresentation q).numerator.length ≤ L ∧
      (rationalBitRepresentation q).denominator.length ≤ L := by
  rw [(rationalBitRepresentation_lengths q).1, (rationalBitRepresentation_lengths q).2]
  rfl

theorem BitListFraction.toRat_bits (q : BitListFraction) (hq : q.WellFormed) (L : ℕ) :
    RationalBitBound (q.toRat hq) L ↔ q.numerator.length ≤ L ∧ q.denominator.length ≤ L := by
  unfold RationalBitBound
  change (signedBitsValue q.negative q.numerator).natAbs.size ≤ L ∧
    (binaryDigitsValue q.denominator).size ≤ L ↔ _
  rw [signedBitsValue_natAbs, ← hq.1.length, ← hq.2.1.length]

end Optss
