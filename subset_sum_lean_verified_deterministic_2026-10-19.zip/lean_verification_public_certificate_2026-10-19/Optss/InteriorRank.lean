import Optss.HyperplaneCounting
import Mathlib.LinearAlgebra.Prod

/-!
# Genuine dimension increase in the interior child

A functional nonzero on the kernel of a surjective old-coordinate map creates
one new independent coordinate. A surviving spanning family remains spanning
after the appended map and arbitrary item sign choices. Integral coordinates
then force every enclosing width to be at least the supplied thickness.
The geometric interior oracle and its correctness are separate obligations.
-/

namespace Optss
open scoped BigOperators Classical
noncomputable section

section Append
variable {E H : Type*} [AddCommGroup E] [Module ℝ E] [AddCommGroup H] [Module ℝ H]

/-- The exact linear-algebra reason that the appended coordinate is genuine. -/
theorem appended_map_surjective (F : E →ₗ[ℝ] H) (ψ : E →ₗ[ℝ] ℝ)
    (hF : Function.Surjective F) (hψ : ∃ z ∈ LinearMap.ker F, ψ z ≠ 0) :
    Function.Surjective (F.prod ψ) := by
  obtain ⟨z, hz, hψz⟩ := hψ
  have hFz : F z = 0 := LinearMap.mem_ker.mp hz
  rintro ⟨y, t⟩
  obtain ⟨x, hFx⟩ := hF y
  refine ⟨x + ((t-ψ x)/ψ z) • z, ?_⟩
  apply Prod.ext
  · simp [LinearMap.prod_apply, hFx, hFz]
  · simp only [LinearMap.prod_apply, Prod.snd, map_add, map_smul, smul_eq_mul]
    field_simp [hψz]

/-- Surjective linear maps carry the actual span of labelled inputs onto the
whole codomain. -/
theorem labelSpan_image_eq_top {ι : Type*} (u : ι → E) (live : Finset ι)
    (G : E →ₗ[ℝ] H) (hG : Function.Surjective G)
    (hspan : labelSpan ℝ u live = ⊤) : labelSpan ℝ (fun i => G (u i)) live = ⊤ := by
  have himage : (fun i => G (u i)) '' (live : Set ι) = G '' (u '' (live : Set ι)) := by
    rw [Set.image_image]
  unfold labelSpan
  rw [himage, Submodule.span_image, ← labelSpan, hspan, Submodule.map_top,
    LinearMap.range_eq_top.mpr hG]

/-- Independent sign choices preserve the actual span of a finite input family. -/
theorem labelSpan_signed {ι : Type*} (u : ι → E) (live : Finset ι) (positive : ι → Bool) :
    labelSpan ℝ (fun i => if positive i then u i else -u i) live = labelSpan ℝ u live := by
  apply le_antisymm
  · apply Submodule.span_le.mpr
    rintro _ ⟨i, hi, rfl⟩
    have hm : u i ∈ labelSpan ℝ u live := Submodule.subset_span ⟨i, hi, rfl⟩
    dsimp only
    split_ifs
    · exact hm
    · exact Submodule.neg_mem _ hm
  · apply Submodule.span_le.mpr
    rintro _ ⟨i, hi, rfl⟩
    have hm : (if positive i then u i else -u i) ∈
        labelSpan ℝ (fun i => if positive i then u i else -u i) live :=
      Submodule.subset_span ⟨i, hi, rfl⟩
    cases hp : positive i
    · simpa only [hp, Bool.false_eq_true, ↓reduceIte, neg_neg] using Submodule.neg_mem _ hm
    · simpa only [hp, ↓reduceIte] using hm

end Append

section Dimension
variable {ι E : Type*} [AddCommGroup E] [Module ℝ E] {d : ℕ}

/-- The appended map has rank exactly `d+1`. -/
theorem appended_map_finrank (F : E →ₗ[ℝ] (Fin d → ℝ)) (ψ : E →ₗ[ℝ] ℝ)
    (hF : Function.Surjective F) (hψ : ∃ z ∈ LinearMap.ker F, ψ z ≠ 0) :
    Module.finrank ℝ (LinearMap.range (F.prod ψ)) = d+1 := by
  rw [LinearMap.range_eq_top.mpr (appended_map_surjective F ψ hF hψ)]
  simp [Module.finrank_prod]

/-- Full spanning inputs, with arbitrary signs, have genuine appended span. -/
theorem appended_signed_labelSpan_eq_top (u : ι → E) (live : Finset ι) (positive : ι → Bool)
    (F : E →ₗ[ℝ] (Fin d → ℝ)) (ψ : E →ₗ[ℝ] ℝ)
    (hF : Function.Surjective F) (hψ : ∃ z ∈ LinearMap.ker F, ψ z ≠ 0)
    (hspan : labelSpan ℝ u live = ⊤) :
    labelSpan ℝ (fun i => if positive i then (F.prod ψ) (u i) else -(F.prod ψ) (u i)) live = ⊤ := by
  rw [labelSpan_signed]
  exact labelSpan_image_eq_top u live _ (appended_map_surjective F ψ hF hψ) hspan

/-- Restricting to the actual finite surviving labels computes the same span rank. -/
theorem inputSpanRank_restrict_eq {G : Type*} [AddCommGroup G] [Module ℝ G]
    (v : ι → G) (live : Finset ι) :
    inputSpanRank ℝ (fun i : live => v i) = Module.finrank ℝ (labelSpan ℝ v live) := by
  unfold inputSpanRank labelSpan
  have hrange : Set.range (fun i : live => v i) = v '' (live : Set ι) := by
    ext x
    simp
  rw [hrange]

/-- The actual rank of the signed appended input family is `d+1`, including when
equal-valued inputs carry different labels. -/
theorem appended_signed_inputSpanRank (u : ι → E) (live : Finset ι) (positive : ι → Bool)
    (F : E →ₗ[ℝ] (Fin d → ℝ)) (ψ : E →ₗ[ℝ] ℝ)
    (hF : Function.Surjective F) (hψ : ∃ z ∈ LinearMap.ker F, ψ z ≠ 0)
    (hspan : labelSpan ℝ u live = ⊤) :
    inputSpanRank ℝ (fun i : live =>
      if positive i then (F.prod ψ) (u i) else -(F.prod ψ) (u i)) = d+1 := by
  rw [inputSpanRank_restrict_eq
    (fun i => if positive i then (F.prod ψ) (u i) else -(F.prod ψ) (u i)) live,
    appended_signed_labelSpan_eq_top u live positive F ψ hF hψ hspan]
  simp [Module.finrank_prod]

end Dimension

section Robust
variable {ι E : Type*} [DecidableEq ι] [AddCommGroup E] [Module ℝ E] {d : ℕ}

/-- The packed-basis certificate discharges the surviving-span premise after
arbitrary allowed label deletions, so the signed appended child has actual rank `d+1`. -/
theorem appended_rank_after_label_deletions (u : ι → E) (live deleted : Finset ι)
    (positive : ι → Bool) (k : ℕ)
    (hspan : labelSpan ℝ u live = ⊤)
    (hpacking : (packLabelBases u (labelSpan ℝ u live) live (k+1)).length = k+1)
    (hdeleted : deleted.card ≤ k)
    (F : E →ₗ[ℝ] (Fin d → ℝ)) (ψ : E →ₗ[ℝ] ℝ)
    (hF : Function.Surjective F) (hψ : ∃ z ∈ LinearMap.ker F, ψ z ≠ 0) :
    inputSpanRank ℝ (fun i : ↥(live \ deleted) =>
      if positive i then (F.prod ψ) (u i) else -(F.prod ψ) (u i)) = d+1 := by
  obtain ⟨_, _, _, _, hremaining⟩ := packLabelBases_success u live k hpacking deleted hdeleted
  apply appended_signed_inputSpanRank u (live \ deleted) positive F ψ hF hψ
  exact hremaining.trans hspan

/-- The same rank increase holds for live types after a bounded counter debit;
large surviving multiplicities do not replace or weaken the spanning argument. -/
theorem appended_rank_after_counter_deletions [Fintype ι]
    (u : ι → E) (c x : ι → ℕ) (positive : ι → Bool) (k : ℕ)
    (hspan : liveCountSpan ℝ u c = ⊤)
    (hpacking : (packCopyBases (K := ℝ) u c k).length = k+1)
    (hx : ∀ i, x i ≤ c i) (hdeleted : ∑ i, x i ≤ k)
    (F : E →ₗ[ℝ] (Fin d → ℝ)) (ψ : E →ₗ[ℝ] ℝ)
    (hF : Function.Surjective F) (hψ : ∃ z ∈ LinearMap.ker F, ψ z ≠ 0) :
    inputSpanRank ℝ (fun i : (Finset.univ.filter (fun i => 0 < c i - x i)) =>
      if positive i then (F.prod ψ) (u i) else -(F.prod ψ) (u i)) = d+1 := by
  have hremaining := packCopyBases_success_counters u c x k hpacking hx hdeleted
  apply appended_signed_inputSpanRank u _ positive F ψ hF hψ
  exact hremaining.trans hspan

end Robust

section Widths
variable {ι : Type*} {n : ℕ}

/-- Actual full rank forces a nonzero integer item coordinate in every axis. -/
theorem full_span_has_nonzero_coordinate (v : ι → IntVec n) (live : Finset ι)
    (hfull : labelSpan ℝ (fun i => realVector (v i)) live = ⊤) (j : Fin n) :
    ∃ i ∈ live, v i j ≠ 0 := by
  by_contra hnone
  push_neg at hnone
  have hle : labelSpan ℝ (fun i => realVector (v i)) live ≤
      LinearMap.ker (LinearMap.proj j : (Fin n → ℝ) →ₗ[ℝ] ℝ) := by
    apply Submodule.span_le.mpr
    rintro _ ⟨i, hi, rfl⟩
    apply LinearMap.mem_ker.mpr
    change (v i j : ℝ) = 0
    simp [hnone i hi]
  have hm : (Pi.single j (1:ℝ) : Fin n → ℝ) ∈
      labelSpan ℝ (fun i => realVector (v i)) live := by rw [hfull]; trivial
  have hz := LinearMap.mem_ker.mp (hle hm)
  simp at hz

/-- A full actual span rank is equivalent to full span in these finite coordinates. -/
theorem full_rank_integer_labelSpan (v : ι → IntVec n) (live : Finset ι)
    (hrank : inputSpanRank ℝ (fun i : live => realVector (v i)) = n) :
    labelSpan ℝ (fun i => realVector (v i)) live = ⊤ := by
  apply Submodule.eq_of_le_of_finrank_eq le_top
  rw [inputSpanRank_restrict_eq (fun i => realVector (v i)) live] at hrank
  simpa using hrank

/-- Every coordinate width is at least the integral thickness. The chosen item
may depend on the coordinate and its actual scale may exceed the required thickness. -/
theorem integer_width_ge_thickness (v : ι → IntVec n) (live : Finset ι)
    (hfull : labelSpan ℝ (fun i => realVector (v i)) live = ⊤)
    (τ : ι → ℕ) (h : ℕ) (N : Fin n → ℕ)
    (hτ : ∀ i ∈ live, h ≤ τ i)
    (hbox : ∀ i ∈ live, ∀ j, |(τ i : ℤ) * v i j| ≤ (N j : ℤ)) :
    ∀ j, h ≤ N j := by
  intro j
  obtain ⟨i, hi, hnz⟩ := full_span_has_nonzero_coordinate v live hfull j
  have hone := Int.one_le_abs hnz
  have hbound := hbox i hi j
  rw [abs_mul, abs_of_nonneg (Int.natCast_nonneg _)] at hbound
  have ht : (h:ℤ) ≤ τ i := by exact_mod_cast hτ i hi
  have hresult : (h:ℤ) ≤ N j := by nlinarith [Int.natCast_nonneg (τ i)]
  exact_mod_cast hresult

/-- The box has at least one full thickness interval in every genuine dimension. -/
theorem integer_box_volume_ge_thickness (v : ι → IntVec n) (live : Finset ι)
    (hfull : labelSpan ℝ (fun i => realVector (v i)) live = ⊤)
    (τ : ι → ℕ) (h : ℕ) (N : Fin n → ℕ)
    (hτ : ∀ i ∈ live, h ≤ τ i)
    (hbox : ∀ i ∈ live, ∀ j, |(τ i : ℤ) * v i j| ≤ (N j : ℤ)) :
    (2*h+1)^n ≤ ∏ j, (2*N j+1) := by
  have hwidth := integer_width_ge_thickness v live hfull τ h N hτ hbox
  calc
    _ = ∏ _j : Fin n, (2*h+1) := by simp
    _ ≤ _ := Finset.prod_le_prod (fun _ _ => Nat.zero_le _) (fun j _ => by nlinarith [hwidth j])

/-- The final width and volume bound requires only the actual span rank; the
nonzero coordinates are derived, not supplied as extra hypotheses. -/
theorem integer_widths_and_volume_of_full_rank (v : ι → IntVec n) (live : Finset ι)
    (hrank : inputSpanRank ℝ (fun i : live => realVector (v i)) = n)
    (τ : ι → ℕ) (h : ℕ) (N : Fin n → ℕ)
    (hτ : ∀ i ∈ live, h ≤ τ i)
    (hbox : ∀ i ∈ live, ∀ j, |(τ i : ℤ) * v i j| ≤ (N j : ℤ)) :
    (∀ j, h ≤ N j) ∧ (2*h+1)^n ≤ ∏ j, (2*N j+1) := by
  have hfull := full_rank_integer_labelSpan v live hrank
  exact ⟨integer_width_ge_thickness v live hfull τ h N hτ hbox,
    integer_box_volume_ge_thickness v live hfull τ h N hτ hbox⟩

end Widths

section RealWidths
variable {ι : Type*} {n : ℕ}

/-- Real enclosing widths obey the same lower bound before integer rounding. -/
theorem real_widths_and_volume_ge_thickness (v : ι → IntVec n) (live : Finset ι)
    (hfull : labelSpan ℝ (fun i => realVector (v i)) live = ⊤)
    (τ : ι → ℝ) (h : ℝ) (hh : 0 ≤ h) (N : Fin n → ℝ)
    (hτ : ∀ i ∈ live, h ≤ τ i)
    (hbox : ∀ i ∈ live, ∀ j, |τ i * (v i j : ℝ)| ≤ N j) :
    (∀ j, h ≤ N j) ∧ (2*h+1)^n ≤ ∏ j, (2*N j+1) := by
  have hwidth : ∀ j, h ≤ N j := by
    intro j
    obtain ⟨i, hi, hnz⟩ := full_span_has_nonzero_coordinate v live hfull j
    have hone : (1:ℝ) ≤ |(v i j : ℝ)| := by exact_mod_cast Int.one_le_abs hnz
    have hbound := hbox i hi j
    have ht : 0 ≤ τ i := hh.trans (hτ i hi)
    rw [abs_mul, abs_of_nonneg ht] at hbound
    nlinarith [hτ i hi]
  refine ⟨hwidth, ?_⟩
  calc
    _ = ∏ _j : Fin n, (2*h+1) := by simp
    _ ≤ _ := Finset.prod_le_prod (fun _ _ => by linarith) (fun j _ => by linarith [hwidth j])

end RealWidths

section ChildCoordinates
variable {ι E : Type*} [AddCommGroup E] [Module ℝ E] {d : ℕ}

/-- Correct integer coordinates in any chosen real linear coordinate isomorphism
inherit the full span of the genuine appended child. -/
theorem appended_integer_coordinates_full_span
    (u : ι → E) (live : Finset ι) (positive : ι → Bool)
    (F : E →ₗ[ℝ] (Fin d → ℝ)) (ψ : E →ₗ[ℝ] ℝ)
    (hF : Function.Surjective F) (hψ : ∃ z ∈ LinearMap.ker F, ψ z ≠ 0)
    (hspan : labelSpan ℝ u live = ⊤)
    (e : ((Fin d → ℝ) × ℝ) ≃ₗ[ℝ] (Fin (d+1) → ℝ)) (child : ι → IntVec (d+1))
    (hcoordinates : ∀ i ∈ live, realVector (child i) =
      e (if positive i then (F.prod ψ) (u i) else -(F.prod ψ) (u i))) :
    labelSpan ℝ (fun i => realVector (child i)) live = ⊤ := by
  have hfull := appended_signed_labelSpan_eq_top u live positive F ψ hF hψ hspan
  have himage := labelSpan_image_eq_top
    (fun i => if positive i then (F.prod ψ) (u i) else -(F.prod ψ) (u i)) live
    e.toLinearMap e.surjective hfull
  have heq : (fun i => realVector (child i)) '' (live : Set ι) =
      (fun i => e (if positive i then (F.prod ψ) (u i) else -(F.prod ψ) (u i))) ''
        (live : Set ι) := by
    ext y
    constructor
    · rintro ⟨i, hi, rfl⟩
      exact ⟨i, hi, (hcoordinates i hi).symm⟩
    · rintro ⟨i, hi, rfl⟩
      exact ⟨i, hi, hcoordinates i hi⟩
  simpa only [labelSpan, heq] using himage

/-- The appended child has one thickness interval in each of its `d+1` integer
coordinates. Nonzero coordinates follow from surjectivity and the surviving span. -/
theorem appended_integer_widths_and_volume
    (u : ι → E) (live : Finset ι) (positive : ι → Bool)
    (F : E →ₗ[ℝ] (Fin d → ℝ)) (ψ : E →ₗ[ℝ] ℝ)
    (hF : Function.Surjective F) (hψ : ∃ z ∈ LinearMap.ker F, ψ z ≠ 0)
    (hspan : labelSpan ℝ u live = ⊤)
    (e : ((Fin d → ℝ) × ℝ) ≃ₗ[ℝ] (Fin (d+1) → ℝ)) (child : ι → IntVec (d+1))
    (hcoordinates : ∀ i ∈ live, realVector (child i) =
      e (if positive i then (F.prod ψ) (u i) else -(F.prod ψ) (u i)))
    (τ : ι → ℕ) (h : ℕ) (N : Fin (d+1) → ℕ)
    (hτ : ∀ i ∈ live, h ≤ τ i)
    (hbox : ∀ i ∈ live, ∀ j, |(τ i : ℤ) * child i j| ≤ (N j : ℤ)) :
    (∀ j, h ≤ N j) ∧ (2*h+1)^(d+1) ≤ ∏ j, (2*N j+1) := by
  have hfull := appended_integer_coordinates_full_span u live positive F ψ hF hψ hspan e child hcoordinates
  exact ⟨integer_width_ge_thickness child live hfull τ h N hτ hbox,
    integer_box_volume_ge_thickness child live hfull τ h N hτ hbox⟩

/-- The same appended-child conclusion for the real enclosing widths before
rounding to an integer target box. -/
theorem appended_real_widths_and_volume
    (u : ι → E) (live : Finset ι) (positive : ι → Bool)
    (F : E →ₗ[ℝ] (Fin d → ℝ)) (ψ : E →ₗ[ℝ] ℝ)
    (hF : Function.Surjective F) (hψ : ∃ z ∈ LinearMap.ker F, ψ z ≠ 0)
    (hspan : labelSpan ℝ u live = ⊤)
    (e : ((Fin d → ℝ) × ℝ) ≃ₗ[ℝ] (Fin (d+1) → ℝ)) (child : ι → IntVec (d+1))
    (hcoordinates : ∀ i ∈ live, realVector (child i) =
      e (if positive i then (F.prod ψ) (u i) else -(F.prod ψ) (u i)))
    (τ : ι → ℝ) (h : ℝ) (hh : 0 ≤ h) (N : Fin (d+1) → ℝ)
    (hτ : ∀ i ∈ live, h ≤ τ i)
    (hbox : ∀ i ∈ live, ∀ j, |τ i * (child i j : ℝ)| ≤ N j) :
    (∀ j, h ≤ N j) ∧ (2*h+1)^(d+1) ≤ ∏ j, (2*N j+1) :=
  real_widths_and_volume_ge_thickness child live
    (appended_integer_coordinates_full_span u live positive F ψ hF hψ hspan e child hcoordinates)
    τ h hh N hτ hbox

end ChildCoordinates

end
end Optss
