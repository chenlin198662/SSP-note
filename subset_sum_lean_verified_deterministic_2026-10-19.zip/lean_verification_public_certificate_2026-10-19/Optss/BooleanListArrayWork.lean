import Optss.BooleanListArray

/-!
# Concrete traversal and copying work of list arrays

The work semantics counts Boolean address control, structural-index encoding,
list traversal/allocation, and the supplied cost of physically copying records.
Skipped records are scanned as well. Thus no constant-time array access or
free payload copying is built into these bounds.
-/
namespace Optss

/-- Traversal and allocation for mapping an explicit record copier. -/
def bitRecordCopiesWork {α : Type*} (copyWork : α → ℕ) : List α → ℕ
  | [] => 1
  | x::xs => copyWork x+bitRecordCopiesWork copyWork xs+2

theorem bitRecordCopiesWork_le {α : Type*} (copyWork : α → ℕ) (xs : List α) (W : ℕ)
    (hw : ∀ x ∈ xs,copyWork x ≤ W) : bitRecordCopiesWork copyWork xs ≤ xs.length*(W+2)+1 := by
  induction xs with
  | nil => simp [bitRecordCopiesWork]
  | cons x xs ih =>
    have hx := hw x List.mem_cons_self
    have ht := ih (fun y hy => hw y (List.mem_cons_of_mem _ hy))
    simp only [bitRecordCopiesWork,List.length_cons]
    nlinarith

/-- Scanning cost may conservatively use the full copier cost of a record. -/
def bitIndexedReadWork {α : Type*} (copyWork : α → ℕ) : List Bool → List α → ℕ
  | _,[] => 1
  | address,x::xs =>
    bitListTrimVisits address+copyWork x+2+
      if (bitListTrim address).isEmpty then copyWork x
      else bitAddressPredWork address+bitIndexedReadWork copyWork (bitAddressPred address) xs

def bitIndexedWriteWork {α : Type*} (copyWork : α → ℕ) : List Bool → α → List α → ℕ
  | _,_,[] => 1
  | address,replacement,x::xs =>
    bitListTrimVisits address+copyWork x+3+
      if (bitListTrim address).isEmpty then copyWork replacement+bitRecordCopiesWork copyWork xs
      else bitAddressPredWork address+bitIndexedWriteWork copyWork (bitAddressPred address) replacement xs

theorem bitIndexedReadWork_le {α : Type*} (copyWork : α → ℕ) (address : List Bool)
    (xs : List α) (L W : ℕ) (hL : 1 ≤ L) (ha : address.length ≤ L)
    (hw : ∀ x ∈ xs,copyWork x ≤ W) :
    bitIndexedReadWork copyWork address xs ≤ xs.length*(12*(L+1)+2*W)+1 := by
  induction xs generalizing address with
  | nil => simp [bitIndexedReadWork]
  | cons x xs ih =>
    have hx := hw x List.mem_cons_self
    have hp := bitAddressPredWork_le address L hL ha
    have ht := ih (bitAddressPred address) (bitAddressPred_length address L hL ha)
      (fun y hy => hw y (List.mem_cons_of_mem _ hy))
    rw [bitIndexedReadWork]
    split_ifs <;> simp only [bitListTrimVisits_eq,List.length_cons] <;> nlinarith

theorem bitIndexedWriteWork_le {α : Type*} (copyWork : α → ℕ) (address : List Bool)
    (replacement : α) (xs : List α) (L W : ℕ) (hL : 1 ≤ L) (ha : address.length ≤ L)
    (hr : copyWork replacement ≤ W) (hw : ∀ x ∈ xs,copyWork x ≤ W) :
    bitIndexedWriteWork copyWork address replacement xs ≤ xs.length*(12*(L+1)+2*W)+1 := by
  induction xs generalizing address with
  | nil => simp [bitIndexedWriteWork]
  | cons x xs ih =>
    have hx := hw x List.mem_cons_self
    have hp := bitAddressPredWork_le address L hL ha
    have hs := bitRecordCopiesWork_le copyWork xs W (fun y hy => hw y (List.mem_cons_of_mem _ hy))
    have ht := ih (bitAddressPred address) (bitAddressPred_length address L hL ha)
      (fun y hy => hw y (List.mem_cons_of_mem _ hy))
    rw [bitIndexedWriteWork]
    split_ifs <;> simp only [bitListTrimVisits_eq,List.length_cons] <;> nlinarith

namespace BooleanListArray

def readWork {α : Type*} {n : ℕ} (copyWork : α → ℕ) (a : BooleanListArray α n) (i : Fin n) : ℕ :=
  bitUnaryAddressWork i.val+bitIndexedReadWork copyWork (bitUnaryAddress i.val) a.data+1

def writeWork {α : Type*} {n : ℕ} (copyWork : α → ℕ) (a : BooleanListArray α n)
    (i : Fin n) (x : α) : ℕ :=
  bitUnaryAddressWork i.val+bitIndexedWriteWork copyWork (bitUnaryAddress i.val) x a.data+1

def copyWork {α : Type*} {n : ℕ} (w : α → ℕ) (a : BooleanListArray α n) : ℕ :=
  bitRecordCopiesWork w a.data

theorem readWork_le {α : Type*} {n : ℕ} (w : α → ℕ) (a : BooleanListArray α n)
    (i : Fin n) (W : ℕ) (hw : ∀ x ∈ a.data,w x ≤ W) :
    readWork w a i ≤ 64*(n+1)^2*(W+1) := by
  have ha := bitUnaryAddress_length i.val
  have hi := i.isLt
  have hs := bitIndexedReadWork_le w (bitUnaryAddress i.val) a.data (n+1) W
    (by omega) (by omega) hw
  rw [a.length_eq] at hs
  have hc := bitUnaryAddressWork_le i.val
  have hsq : (i.val+1)^2 ≤ (n+1)^2 := Nat.pow_le_pow_left (by omega) 2
  unfold readWork
  have hn : n ≤ (n+1)^2 := by nlinarith
  have hn' : n*(n+2) ≤ 2*(n+1)^2 := by nlinarith
  nlinarith

theorem writeWork_le {α : Type*} {n : ℕ} (w : α → ℕ) (a : BooleanListArray α n)
    (i : Fin n) (x : α) (W : ℕ) (hx : w x ≤ W) (hw : ∀ y ∈ a.data,w y ≤ W) :
    writeWork w a i x ≤ 64*(n+1)^2*(W+1) := by
  have ha := bitUnaryAddress_length i.val
  have hi := i.isLt
  have hs := bitIndexedWriteWork_le w (bitUnaryAddress i.val) x a.data (n+1) W
    (by omega) (by omega) hx hw
  rw [a.length_eq] at hs
  have hc := bitUnaryAddressWork_le i.val
  have hsq : (i.val+1)^2 ≤ (n+1)^2 := Nat.pow_le_pow_left (by omega) 2
  unfold writeWork
  have hn : n ≤ (n+1)^2 := by nlinarith
  have hn' : n*(n+2) ≤ 2*(n+1)^2 := by nlinarith
  nlinarith

theorem copyWork_le {α : Type*} {n : ℕ} (w : α → ℕ) (a : BooleanListArray α n)
    (W : ℕ) (hw : ∀ x ∈ a.data,w x ≤ W) : copyWork w a ≤ n*(W+2)+1 := by
  simpa only [copyWork,a.length_eq] using bitRecordCopiesWork_le w a.data W hw

end BooleanListArray
end Optss
