import Mathlib.Algebra.Group.Hom.Basic
import Mathlib.Tactic

/-!
# Logical preservation of short additive relations

These are the algebraic invariant-preservation arguments inside Lemmas 6.3,
9.8 and 10.5. They do not prove the rank bounds, properness scales, existence
of the paper's GAPs, termination, or any complexity claim.

A witness is a list of signed labels, of length at most `k`. Repeated labels
are allowed: the repeated sumsets used in the invariant are analytical objects,
not selections subject to input multiplicity bounds. Omitting terms represents
the zero terms of the paper's repeated sumset.
-/

namespace Optss

variable {ι κ G H K C : Type*}
variable [AddCommGroup G] [AddCommGroup H] [AddCommGroup K] [AddCommGroup C]

/-- `true` selects a vector and `false` selects its negative. -/
def signedSum (v : ι → G) : List (Bool × ι) → G
  | [] => 0
  | (positive, i) :: w => (if positive then v i else -v i) + signedSum v w

/-- Both implications are needed: a representation must neither lose old
relations nor introduce new ones. The label sets are shared. -/
def PreservesSignedSums (k : ℕ) (original : ι → G) (current : ι → H) : Prop :=
  ∀ a b : List (Bool × ι), a.length ≤ k → b.length ≤ k →
    (signedSum current a = signedSum current b ↔
      signedSum original a = signedSum original b)

theorem preservesSignedSums_identity (k : ℕ) (v : ι → G) :
    PreservesSignedSums k v v := by
  intro a b ha hb
  rfl

/-- Replace the labels of a signed expression without changing its signs. -/
def relabelWitness (f : κ → ι) (w : List (Bool × κ)) : List (Bool × ι) :=
  w.map (fun x => (x.1, f x.2))

@[simp] theorem relabelWitness_length (f : κ → ι) (w : List (Bool × κ)) :
    (relabelWitness f w).length = w.length := by
  simp [relabelWitness]

theorem signedSum_relabel (v : ι → G) (f : κ → ι) (w : List (Bool × κ)) :
    signedSum v (relabelWitness f w) = signedSum (fun i => v (f i)) w := by
  induction w with
  | nil => rfl
  | cons x w ih =>
      rcases x with ⟨positive, i⟩
      simp [relabelWitness, signedSum] at ih ⊢
      exact ih

/-- Restriction to a surviving label set preserves the invariant. The more
general relabelling statement also allows repeated representations of labels. -/
theorem PreservesSignedSums.relabel {k : ℕ} {original : ι → G} {current : ι → H}
    (h : PreservesSignedSums k original current) (f : κ → ι) :
    PreservesSignedSums k (fun i => original (f i)) (fun i => current (f i)) := by
  intro a b ha hb
  have he := h (relabelWitness f a) (relabelWitness f b)
    (by simpa using ha) (by simpa using hb)
  simpa only [signedSum_relabel] using he

theorem PreservesSignedSums.restrict {k : ℕ} {original : ι → G} {current : ι → H}
    (h : PreservesSignedSums k original current) (survives : ι → Prop) :
    PreservesSignedSums k
      (fun i : {i // survives i} => original i.val)
      (fun i : {i // survives i} => current i.val) :=
  h.relabel Subtype.val

/-- Flip each chosen label whose orientation is `true`. -/
def reorient (v : ι → G) (orientation : ι → Bool) : ι → G :=
  fun i => if orientation i then -v i else v i

def reorientWitness (orientation : ι → Bool) (w : List (Bool × ι)) :
    List (Bool × ι) :=
  w.map (fun x => (if orientation x.2 then !x.1 else x.1, x.2))

@[simp] theorem reorientWitness_length (orientation : ι → Bool)
    (w : List (Bool × ι)) : (reorientWitness orientation w).length = w.length := by
  simp [reorientWitness]

theorem signedSum_reorient (v : ι → G) (orientation : ι → Bool)
    (w : List (Bool × ι)) :
    signedSum (reorient v orientation) w =
      signedSum v (reorientWitness orientation w) := by
  induction w with
  | nil => rfl
  | cons x w ih =>
      rcases x with ⟨positive, i⟩
      cases ho : orientation i <;> cases positive <;>
        simp_all [signedSum, reorient, reorientWitness]

/-- Original labels and their current representatives are reoriented together. -/
theorem PreservesSignedSums.reorient {k : ℕ} {original : ι → G} {current : ι → H}
    (h : PreservesSignedSums k original current) (orientation : ι → Bool) :
    PreservesSignedSums k (Optss.reorient original orientation)
      (Optss.reorient current orientation) := by
  intro a b ha hb
  rw [signedSum_reorient, signedSum_reorient, signedSum_reorient, signedSum_reorient]
  exact h _ _ (by simpa using ha) (by simpa using hb)

theorem signedSum_addHom (f : H →+ K) (v : ι → H) (w : List (Bool × ι)) :
    signedSum (fun i => f (v i)) w = f (signedSum v w) := by
  induction w with
  | nil => simp [signedSum]
  | cons x w ih =>
      rcases x with ⟨positive, i⟩
      cases positive <;> simp_all [signedSum]

/-- Injective additive coordinate changes preserve all equalities in either
direction. In particular, this applies to injective linear coordinate maps. -/
theorem PreservesSignedSums.map {k : ℕ} {original : ι → G} {current : ι → H}
    (h : PreservesSignedSums k original current) (f : H →+ K)
    (hf : Function.Injective f) :
    PreservesSignedSums k original (fun i => f (current i)) := by
  intro a b ha hb
  rw [signedSum_addHom, signedSum_addHom]
  exact hf.eq_iff.trans (h a b ha hb)

/-- A projection need only be injective on the sums that can occur. This is the
form needed when free coordinates are selected from the actual survivor span. -/
theorem PreservesSignedSums.map_injOn {k : ℕ} {original : ι → G} {current : ι → H}
    (h : PreservesSignedSums k original current) (f : H →+ K) (domain : Set H)
    (hf : Set.InjOn f domain)
    (hmem : ∀ w : List (Bool × ι), w.length ≤ k → signedSum current w ∈ domain) :
    PreservesSignedSums k original (fun i => f (current i)) := by
  intro a b ha hb
  rw [signedSum_addHom, signedSum_addHom]
  constructor
  · intro he
    exact (h a b ha hb).mp (hf (hmem a ha) (hmem b hb) he)
  · intro he
    exact congrArg f ((h a b ha hb).mpr he)

theorem signedSum_pair (v : ι → H) (u : ι → K) (w : List (Bool × ι)) :
    signedSum (fun i => (v i, u i)) w = (signedSum v w, signedSum u w) := by
  induction w with
  | nil => rfl
  | cons x w ih =>
      rcases x with ⟨positive, i⟩
      cases positive <;> simp_all [signedSum]

/-- Appending a coordinate is safe when it respects the existing
short equalities. This lemma does not assert that the new coordinate raises rank. -/
theorem PreservesSignedSums.append {k : ℕ} {original : ι → G} {current : ι → H}
    (h : PreservesSignedSums k original current) (extra : ι → K)
    (hcompat : ∀ a b : List (Bool × ι), a.length ≤ k → b.length ≤ k →
      signedSum current a = signedSum current b →
        signedSum extra a = signedSum extra b) :
    PreservesSignedSums k original (fun i => (current i, extra i)) := by
  intro a b ha hb
  rw [signedSum_pair, signedSum_pair]
  constructor
  · intro he
    exact (h a b ha hb).mp (congrArg Prod.fst he)
  · intro he
    have hc := (h a b ha hb).mpr he
    exact Prod.ext hc (hcompat a b ha hb hc)

/-- The injectivity part of GAP properness, with all necessary containment
hypotheses explicit. The set `box` must contain both coefficient sums being
compared; the paper's scale estimates are not proved here. -/
theorem signedSum_eq_of_proper_projection (k : ℕ)
    (coefficients : ι → C) (current : ι → H) (projection : C →+ H)
    (box : Set C) (hproper : Set.InjOn projection box)
    (hrep : ∀ i, projection (coefficients i) = current i)
    (hbox : ∀ w : List (Bool × ι), w.length ≤ k → signedSum coefficients w ∈ box)
    (a b : List (Bool × ι)) (ha : a.length ≤ k) (hb : b.length ≤ k)
    (he : signedSum current a = signedSum current b) :
    signedSum coefficients a = signedSum coefficients b := by
  apply hproper (hbox a ha) (hbox b hb)
  have hfun : (fun i => projection (coefficients i)) = current := funext hrep
  rw [← signedSum_addHom, ← signedSum_addHom, hfun]
  exact he

/-- A proper coefficient representation supplies the compatibility needed by
`append`; any additive functional of those coordinates can be added safely. -/
theorem PreservesSignedSums.append_of_proper {k : ℕ}
    {original : ι → G} {current : ι → H}
    (h : PreservesSignedSums k original current)
    (coefficients : ι → C) (projection : C →+ H) (box : Set C)
    (hproper : Set.InjOn projection box)
    (hrep : ∀ i, projection (coefficients i) = current i)
    (hbox : ∀ w : List (Bool × ι), w.length ≤ k → signedSum coefficients w ∈ box)
    (newCoordinate : C →+ K) :
    PreservesSignedSums k original
      (fun i => (current i, newCoordinate (coefficients i))) := by
  apply h.append
  intro a b ha hb he
  rw [signedSum_addHom, signedSum_addHom]
  exact congrArg newCoordinate
    (signedSum_eq_of_proper_projection k coefficients current projection box
      hproper hrep hbox a b ha hb he)

end Optss
