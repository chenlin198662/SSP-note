import Optss.Copies
import Optss.BoundedCorrections

/-!
# Safe counted preprocessing for bounded corrections

Discarding over-budget types and capping multiplicities preserves every witness
required by Lemma 10.1. Copy expansion in the proof connects these count budgets
to the labelled support guarantee; it is not an implementation requirement.
-/

namespace Optss
open scoped BigOperators
noncomputable section
variable {ι : Type*} [Fintype ι] {d : ℕ}

/-- Absolute coordinate budgets for nonnegative integer counts. -/
def CountAbsoluteBudget (v : ι → IntVec d) (x : ι → ℤ) (Δ : IntVec d) : Prop :=
  ∀ j, (∑ i, x i * |v i j|) ≤ Δ j

/-- Drop unusable types and cap the remaining multiplicities at the copy budget. -/
def correctionCapacity (v : ι → IntVec d) (c : ι → ℕ) (Δ : IntVec d)
    (kcap : ℕ) : ι → ℕ := by
  classical
  exact fun i => if InBox Δ (v i) then min (c i) kcap else 0

omit [Fintype ι] in
theorem correctionCapacity_le (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : IntVec d) (kcap : ℕ) (i : ι) :
    correctionCapacity v c Δ kcap i ≤ c i ∧ correctionCapacity v c Δ kcap i ≤ kcap := by
  classical
  unfold correctionCapacity
  split_ifs
  · exact ⟨min_le_left _ _, min_le_right _ _⟩
  · omega

/-- A required witness cannot select a copy whose absolute coordinate already
exceeds a budget; each count is also at most the total selected-copy count. -/
theorem required_counts_bounded_correctionCapacity (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : IntVec d) (kcap : ℕ) (x : ι → ℤ)
    (hx : BoundedCounts (fun i => (c i : ℤ)) x)
    (hcard : (∑ i, x i) ≤ kcap) (hbudget : CountAbsoluteBudget v x Δ) :
    BoundedCounts (fun i => (correctionCapacity v c Δ kcap i : ℤ)) x := by
  classical
  intro i
  have hxi := hx i
  have hxcap : x i ≤ kcap := (Finset.single_le_sum
    (fun j _ => (hx j).1) (Finset.mem_univ i)).trans hcard
  refine ⟨hxi.1, ?_⟩
  unfold correctionCapacity
  dsimp only
  split_ifs with hbox
  · rw [Nat.cast_min]
    exact le_min hxi.2 hxcap
  · have hz : x i = 0 := by
      apply Classical.byContradiction
      intro hi
      have hi1 : 1 ≤ x i := by have hnonneg := hxi.1; omega
      apply hbox
      intro j
      have hterm : x i * |v i j| ≤ Δ j :=
        (Finset.single_le_sum (fun k _ => mul_nonneg (hx k).1 (abs_nonneg (v k j)))
          (Finset.mem_univ i)).trans (hbudget j)
      nlinarith [abs_nonneg (v i j)]
    simp [hz]

/-- Any retained selection remains feasible for the original capacities. -/
theorem correctionCapacity_countSums_subset (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : IntVec d) (kcap : ℕ) :
    countSums v (fun i => (correctionCapacity v c Δ kcap i : ℤ)) ⊆
      countSums v (fun i => (c i : ℤ)) := by
  apply countSums_mono
  intro i
  exact_mod_cast (correctionCapacity_le v c Δ kcap i).1

/-- Counting selected copies gives their exact cardinality. -/
theorem copyCount_cardinality (c : ι → ℕ) (s : Finset (CopyIndex c)) :
    (∑ i, copyCount c s i) = (s.card : ℤ) := by
  have h := sum_expandedCopy (fun _ : ι => (1 : ℤ)) c s
  simpa [expandedCopy, weightedSum] using h.symm

/-- Count budgets and budgets of the corresponding labelled selection agree. -/
theorem copyCount_absoluteBudget (v : ι → IntVec d) (c : ι → ℕ)
    (s : Finset (CopyIndex c)) (Δ : IntVec d) :
    CountAbsoluteBudget v (copyCount c s) Δ ↔ AbsoluteBudget (expandedCopy v c) s Δ := by
  have h (j : Fin d) := sum_expandedCopy (fun i => |v i j|) c s
  simp only [expandedCopy, weightedSum, smul_eq_mul] at h
  constructor <;> intro hb j
  · change (∑ p ∈ s, |v p.1 j|) ≤ Δ j
    rw [h j]
    exact hb j
  · rw [← h j]
    exact hb j

/-- Every required counted witness is realized by a copy selection with exactly
the same size, vector sum and absolute-coordinate budgets. -/
theorem exists_budgeted_copy_selection (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : IntVec d) (kcap : ℕ) (x : ι → ℤ)
    (hx : BoundedCounts (fun i => (c i : ℤ)) x)
    (hcard : (∑ i, x i) ≤ kcap) (hbudget : CountAbsoluteBudget v x Δ) :
    ∃ s : Finset (CopyIndex c), s.card ≤ kcap ∧
      AbsoluteBudget (expandedCopy v c) s Δ ∧ (∑ p ∈ s, expandedCopy v c p) = weightedSum v x := by
  obtain ⟨s, hs⟩ := exists_copy_selection c x hx
  refine ⟨s, ?_, ?_, ?_⟩
  · have hsize := copyCount_cardinality c s
    rw [hs] at hsize
    exact_mod_cast (hsize ▸ hcard)
  · exact (copyCount_absoluteBudget v c s Δ).mp (by rw [hs]; exact hbudget)
  · rw [sum_expandedCopy, hs]

/-- The complete mathematical support guarantee with the manuscript's counted
input and counted witness budgets, after safe preprocessing. The support
specification uses finite copy labels; direct-count table equivalence is proved
separately and a fast convolution implementation remains to be supplied. -/
theorem preprocessed_correctionSupport_correct (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) :
    let c' := correctionCapacity v c (fun j => (Δ j : ℤ)) kcap
    let S := finiteBoundedCorrectionSupport (expandedCopy v c') Δ kcap
    (∀ t ∈ S, t ∈ countSums v (fun i => (c i : ℤ)) ∧ InBox (fun j => (Δ j : ℤ)) t) ∧
    (∀ x, BoundedCounts (fun i => (c i : ℤ)) x → (∑ i, x i) ≤ kcap →
      CountAbsoluteBudget v x (fun j => (Δ j : ℤ)) → weightedSum v x ∈ S) := by
  dsimp only
  let c' := correctionCapacity v c (fun j => (Δ j : ℤ)) kcap
  have hsupport := finiteBoundedCorrectionSupport_correct (expandedCopy v c') Δ kcap
  constructor
  · intro t ht
    obtain ⟨hfeas, hbox⟩ := hsupport.1 t ht
    exact ⟨correctionCapacity_countSums_subset v c _ kcap
      ((countSums_iff_expanded_subsetSums v c' t).mpr hfeas), hbox⟩
  · intro x hx hcard hbudget
    have hx' := required_counts_bounded_correctionCapacity v c _ kcap x hx hcard hbudget
    obtain ⟨s, hs, hb, hsum⟩ := exists_budgeted_copy_selection v c' _ kcap x hx' hcard hbudget
    rw [← hsum]
    exact hsupport.2 s hs hb

end
end Optss
