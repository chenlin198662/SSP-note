import Optss.AbsoluteEncoding
import Optss.OrthantSupport

/-!
# Correctness of signed Newton correction supports

Compute cardinality-capped, absolute-coordinate-budgeted integer Newton support
separately on each orthant, restore its signs, recombine the disjoint label
families, and clip to the target box. The resulting support is sound and
contains every witness required by Lemma 10.1. This gives the mathematical
support construction; it does not prove the claimed optimized representation,
coefficient-size, convolution, or running-time bounds.
-/

namespace Optss
open scoped BigOperators Classical
noncomputable section

variable {ι : Type*} [Fintype ι] {d : ℕ}

theorem inOrthant_coordinateOrthant (x : IntVec d) :
    InOrthant (coordinateOrthant x) x := by
  intro j
  by_cases h : 0 ≤ x j
  · simp [coordinateOrthant, h]
  · simp [coordinateOrthant, h]
    omega

/-- Polynomial support on one fiber, expressed in the original copy labels. -/
theorem local_orthant_polynomial_iff (v : ι → IntVec d) (Δ : Fin d →₀ ℕ)
    (kcap : ℕ) (ε : Fin d → Bool) (t : IntVec d) :
    (∃ e : Fin d →₀ ℕ,
      0 < MvPolynomial.coeff e
        (newtonTruncatedSupport
          (fun i : {i // coordinateOrthant (v i) = ε} => absoluteExponent (v i)) Δ kcap) ∧
      orthantDecode ε e = t) ↔
    ∃ s : Finset ι,
      LocalPartitionSelection v (fun i => coordinateOrthant (v i))
        (fun j => (Δ j : ℤ)) kcap ε s ∧ (∑ i ∈ s, v i) = t := by
  classical
  have hv : ∀ i : {i // coordinateOrthant (v i) = ε}, InOrthant ε (v i) := by
    intro i
    simpa only [i.property] using inOrthant_coordinateOrthant (v i)
  rw [orthant_newtonSupport_iff ε (fun i : {i // coordinateOrthant (v i) = ε} => v i)
    hv Δ kcap t]
  constructor
  · rintro ⟨s, hcard, hbudget, hsum⟩
    refine ⟨s.map (Function.Embedding.subtype _), ⟨?_, ?_, ?_⟩, ?_⟩
    · intro i hi
      obtain ⟨a, _, rfl⟩ := Finset.mem_map.mp hi
      simpa only [Finset.mem_filter, Finset.mem_univ, true_and] using a.property
    · simpa using hcard
    · intro j
      simpa only [Finset.sum_map, Function.Embedding.coe_subtype] using hbudget j
    · simpa only [Finset.sum_map, Function.Embedding.coe_subtype] using hsum
  · rintro ⟨s, hs, hsum⟩
    have hf : ∀ i ∈ s, coordinateOrthant (v i) = ε := by
      intro i hi
      have hmem := hs.1 hi
      simpa only [Finset.mem_filter, Finset.mem_univ, true_and] using hmem
    refine ⟨s.subtype (fun i => coordinateOrthant (v i) = ε), ?_, ?_, ?_⟩
    · rw [Finset.card_subtype, Finset.filter_true_of_mem hf]
      exact hs.2.1
    · intro j
      change (∑ i ∈ s.subtype (fun i => coordinateOrthant (v i) = ε), |v i j|) ≤ _
      rw [Finset.sum_subtype_of_mem (fun i => |v i j|) hf]
      exact hs.2.2 j
    · simpa only [Finset.sum_subtype_of_mem _ hf] using hsum

/-- The sum of decoded positive-coefficient supports across all orthants. -/
def orthantPolynomialSupport (v : ι → IntVec d) (Δ : Fin d →₀ ℕ)
    (kcap : ℕ) : Set (IntVec d) :=
  {t | ∃ e : (Fin d → Bool) → Fin d →₀ ℕ,
    (∀ ε, 0 < MvPolynomial.coeff (e ε)
      (newtonTruncatedSupport
        (fun i : {i // coordinateOrthant (v i) = ε} => absoluteExponent (v i)) Δ kcap)) ∧
    (∑ ε, orthantDecode ε (e ε)) = t}

/-- The polynomial construction has precisely the already-verified disjoint
partition semantics, not just an abstract rounding or support assumption. -/
theorem orthantPolynomialSupport_eq_partitionSupport (v : ι → IntVec d)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) :
    orthantPolynomialSupport v Δ kcap =
      partitionSupport v (fun i => coordinateOrthant (v i))
        (fun j => (Δ j : ℤ)) kcap := by
  ext t
  constructor
  · rintro ⟨e, he, hsum⟩
    have hex : ∀ ε, ∃ s : Finset ι,
        LocalPartitionSelection v (fun i => coordinateOrthant (v i))
          (fun j => (Δ j : ℤ)) kcap ε s ∧
        (∑ i ∈ s, v i) = orthantDecode ε (e ε) := by
      intro ε
      exact (local_orthant_polynomial_iff v Δ kcap ε _).mp ⟨e ε, he ε, rfl⟩
    choose s hs hdecode using hex
    refine ⟨s, hs, ?_⟩
    simpa only [hdecode] using hsum
  · rintro ⟨s, hs, hsum⟩
    have hex : ∀ ε, ∃ e : Fin d →₀ ℕ,
        0 < MvPolynomial.coeff e
          (newtonTruncatedSupport
            (fun i : {i // coordinateOrthant (v i) = ε} => absoluteExponent (v i)) Δ kcap) ∧
        orthantDecode ε e = ∑ i ∈ s ε, v i := by
      intro ε
      exact (local_orthant_polynomial_iff v Δ kcap ε _).mpr ⟨s ε, hs ε, rfl⟩
    choose e he hdecode using hex
    refine ⟨e, he, ?_⟩
    simpa only [hdecode] using hsum

/-- Signed correction support after restoring signs and clipping to the box. -/
def boundedCorrectionSupport (v : ι → IntVec d) (Δ : Fin d →₀ ℕ)
    (kcap : ℕ) : Set (IntVec d) :=
  orthantPolynomialSupport v Δ kcap ∩ {t | InBox (fun j => (Δ j : ℤ)) t}

/-- Every reported correction is a genuine subset sum inside the output box. -/
theorem boundedCorrectionSupport_sound (v : ι → IntVec d) (Δ : Fin d →₀ ℕ)
    (kcap : ℕ) : boundedCorrectionSupport v Δ kcap ⊆
      subsetSums v ∩ {t | InBox (fun j => (Δ j : ℤ)) t} := by
  rw [boundedCorrectionSupport, orthantPolynomialSupport_eq_partitionSupport]
  exact clippedPartitionSupport_sound v _ _ kcap

/-- Every globally cardinality-capped, absolute-budgeted witness occurs in the
actual Newton-derived support. Extra outputs are permitted only when sound. -/
theorem boundedCorrectionSupport_complete (v : ι → IntVec d) (Δ : Fin d →₀ ℕ)
    (kcap : ℕ) (s : Finset ι) (hcard : s.card ≤ kcap)
    (hbudget : AbsoluteBudget v s (fun j => (Δ j : ℤ))) :
    (∑ i ∈ s, v i) ∈ boundedCorrectionSupport v Δ kcap := by
  rw [boundedCorrectionSupport, orthantPolynomialSupport_eq_partitionSupport]
  exact clippedPartitionSupport_complete v _ hcard hbudget

/-- A finite representation formed directly from the computed polynomial
supports. This Cartesian-product representation is not a fast convolution
implementation and makes no complexity claim. -/
def finiteBoundedCorrectionSupport (v : ι → IntVec d) (Δ : Fin d →₀ ℕ)
    (kcap : ℕ) : Finset (IntVec d) :=
  ((Fintype.piFinset (fun ε : Fin d → Bool =>
    (newtonTruncatedSupport
      (fun i : {i // coordinateOrthant (v i) = ε} => absoluteExponent (v i)) Δ kcap).support)).image
        (fun e => ∑ ε, orthantDecode ε (e ε))).filter
          (fun t => InBox (fun j => (Δ j : ℤ)) t)

/-- The finite polynomial-support representation has exactly the verified
signed correction semantics. -/
theorem mem_finiteBoundedCorrectionSupport (v : ι → IntVec d)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (t : IntVec d) :
    t ∈ finiteBoundedCorrectionSupport v Δ kcap ↔
      t ∈ boundedCorrectionSupport v Δ kcap := by
  classical
  have hcoeff (ε : Fin d → Bool) (e : Fin d →₀ ℕ) :
      e ∈ (newtonTruncatedSupport
        (fun i : {i // coordinateOrthant (v i) = ε} => absoluteExponent (v i)) Δ kcap).support ↔
      0 < MvPolynomial.coeff e (newtonTruncatedSupport
        (fun i : {i // coordinateOrthant (v i) = ε} => absoluteExponent (v i)) Δ kcap) := by
    rw [MvPolynomial.mem_support_iff]
    have h := newtonTruncatedSupport_coeff_nonneg
      (fun i : {i // coordinateOrthant (v i) = ε} => absoluteExponent (v i)) Δ e kcap
    omega
  simp only [finiteBoundedCorrectionSupport, Finset.mem_filter, Finset.mem_image,
    Fintype.mem_piFinset, hcoeff, boundedCorrectionSupport, Set.mem_inter_iff,
    orthantPolynomialSupport, Set.mem_setOf_eq]

/-- Both correctness directions of the finite Newton correction support,
the mathematical support guarantee of Lemma 10.1. -/
theorem finiteBoundedCorrectionSupport_correct (v : ι → IntVec d)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) :
    (∀ t ∈ finiteBoundedCorrectionSupport v Δ kcap,
      t ∈ subsetSums v ∧ InBox (fun j => (Δ j : ℤ)) t) ∧
    (∀ s : Finset ι, s.card ≤ kcap → AbsoluteBudget v s (fun j => (Δ j : ℤ)) →
      (∑ i ∈ s, v i) ∈ finiteBoundedCorrectionSupport v Δ kcap) := by
  constructor
  · intro t ht
    exact boundedCorrectionSupport_sound v Δ kcap
      ((mem_finiteBoundedCorrectionSupport v Δ kcap t).mp ht)
  · intro s hcard hbudget
    exact (mem_finiteBoundedCorrectionSupport v Δ kcap _).mpr
      (boundedCorrectionSupport_complete v Δ kcap s hcard hbudget)

end
end Optss
