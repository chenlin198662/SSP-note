import Optss.ColorProbability

/-!
# Conditioning and union bounds in explicit finite uniform spaces

These formulas are derived from finite event cardinalities and apply to the
actual independently sampled hash/color functions used by color coding. In
particular, a conditional guarantee on all good first-stage outcomes combines
with the first-stage failure probability without assuming unconditional
independence of the success events themselves.
-/

namespace Optss
open scoped BigOperators
noncomputable section

variable {Ω Ξ : Type*} [Fintype Ω] [Fintype Ξ]

theorem uniformProbability_le_one [Nonempty Ω] (A : Finset Ω) : uniformProbability A ≤ 1 := by
  have hpos : (0:ℝ) < Fintype.card Ω := by exact_mod_cast Fintype.card_pos
  apply (div_le_iff₀ hpos).mpr
  simpa using (show (A.card : ℝ) ≤ Fintype.card Ω by exact_mod_cast Finset.card_le_univ A)

theorem uniformProbability_compl [DecidableEq Ω] [Nonempty Ω] (A : Finset Ω) :
    uniformProbability Aᶜ = 1 - uniformProbability A := by
  classical
  have hne : (Fintype.card Ω : ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
  simp only [uniformProbability, Finset.card_compl, Nat.cast_sub (Finset.card_le_univ A)]
  field_simp

/-- An event whose second-stage criterion depends on the first outcome. -/
def jointUniformEvent (F : Ω → Finset Ξ) : Finset (Ω × Ξ) := by
  classical
  exact Finset.univ.biUnion (fun x => {x} ×ˢ F x)

omit [Fintype Ξ] in
@[simp] theorem mem_jointUniformEvent (F : Ω → Finset Ξ) (x : Ω) (y : Ξ) :
    (x,y) ∈ jointUniformEvent F ↔ y ∈ F x := by
  classical
  simp [jointUniformEvent]

/-- Uniform sampling of the pair averages the actual fiber probabilities. -/
theorem uniformProbability_joint (F : Ω → Finset Ξ) :
    uniformProbability (jointUniformEvent F) =
      (∑ x, uniformProbability (F x)) / Fintype.card Ω := by
  classical
  have hcard : (jointUniformEvent F).card = ∑ x, (F x).card := by
    unfold jointUniformEvent
    rw [Finset.card_biUnion]
    · simp
    · intro a _ b _ hab
      apply Finset.disjoint_left.mpr
      intro z ha hb
      have ha' := Finset.mem_product.mp ha
      have hb' := Finset.mem_product.mp hb
      exact hab ((Finset.mem_singleton.mp ha'.1).symm.trans (Finset.mem_singleton.mp hb'.1))
  simp only [uniformProbability, hcard, Fintype.card_prod, Nat.cast_mul, Nat.cast_sum]
  rw [← Finset.sum_div]
  ring

/-- Two-stage failure bound: exceptional first-stage outcomes cost at most
`Pr(bad)`, and every other conditional fiber costs at most `ε`. -/
theorem uniformProbability_joint_le [Nonempty Ω] [Nonempty Ξ]
    (F : Ω → Finset Ξ) (bad : Finset Ω) (ε : ℝ) (hε : 0 ≤ ε)
    (hgood : ∀ x ∉ bad, uniformProbability (F x) ≤ ε) :
    uniformProbability (jointUniformEvent F) ≤ uniformProbability bad + ε := by
  classical
  have hpos : (0:ℝ) < Fintype.card Ω := by exact_mod_cast Fintype.card_pos
  rw [uniformProbability_joint]
  have hsum : (∑ x, uniformProbability (F x)) ≤
      ∑ x : Ω, ((if x ∈ bad then (1:ℝ) else 0) + ε) := by
    apply Finset.sum_le_sum
    intro x _
    by_cases hx : x ∈ bad
    · simp only [if_pos hx]
      exact (uniformProbability_le_one (F x)).trans (by linarith)
    · simpa only [if_neg hx, zero_add] using hgood x hx
  have hsum' : (∑ x, uniformProbability (F x)) ≤ (bad.card : ℝ) + Fintype.card Ω * ε := by
    simpa [Finset.sum_add_distrib] using hsum
  calc
    (∑ x, uniformProbability (F x)) / Fintype.card Ω ≤
        ((bad.card : ℝ) + Fintype.card Ω * ε) / Fintype.card Ω :=
      div_le_div_of_nonneg_right hsum' hpos.le
    _ = uniformProbability bad + ε := by
      unfold uniformProbability
      rw [add_div, mul_div_cancel_left₀ _ (ne_of_gt hpos)]

end
end Optss
