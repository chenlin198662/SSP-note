import Optss.NewtonSupport
import Optss.Enumeration

/-!
# Signed orthants and nonnegative polynomial exponents

The integer Newton computation works with nonnegative exponent vectors. In a
fixed orthant, decoding their coordinatewise absolute values recovers the
original signed vector sums. This file connects the actual polynomial support
to the absolute-budget witnesses used by the partition recombination proof.
-/

namespace Optss
open scoped BigOperators
noncomputable section

variable {ι : Type*} {d : ℕ}

/-- Nonnegative exponents recording the absolute coordinates of an item. -/
def absoluteExponent (v : IntVec d) : Fin d →₀ ℕ :=
  Finsupp.equivFunOnFinite.symm (fun j => (v j).natAbs)

@[simp] theorem absoluteExponent_apply (v : IntVec d) (j : Fin d) :
    absoluteExponent v j = (v j).natAbs := rfl

/-- A true sign bit denotes the nonnegative half-axis. Zero belongs to both. -/
def InOrthant (ε : Fin d → Bool) (v : IntVec d) : Prop :=
  ∀ j, if ε j then 0 ≤ v j else v j ≤ 0

def orthantDecode (ε : Fin d → Bool) (e : Fin d →₀ ℕ) : IntVec d :=
  fun j => if ε j then (e j : ℤ) else -(e j : ℤ)

theorem orthantDecode_absoluteExponent (ε : Fin d → Bool) (v : IntVec d)
    (hv : InOrthant ε v) : orthantDecode ε (absoluteExponent v) = v := by
  funext j
  have hj := hv j
  cases hε : ε j <;>
    simp only [hε, Bool.false_eq_true, if_false, if_true] at hj ⊢
  · simp only [orthantDecode, hε, Bool.false_eq_true, if_false, absoluteExponent_apply,
      Int.natCast_natAbs, abs_of_nonpos hj, neg_neg]
  · simpa only [orthantDecode, hε, if_true,
      absoluteExponent_apply, Int.natCast_natAbs] using abs_of_nonneg hj

/-- Orthant decoding commutes with finite sums of nonnegative exponent vectors. -/
theorem orthantDecode_sum (ε : Fin d → Bool) (s : Finset ι)
    (u : ι → Fin d →₀ ℕ) :
    orthantDecode ε (∑ i ∈ s, u i) = ∑ i ∈ s, orthantDecode ε (u i) := by
  funext j
  simp only [orthantDecode, Finset.sum_apply, Finsupp.finset_sum_apply]
  cases ε j <;> simp

theorem orthantDecode_absolute_sum (ε : Fin d → Bool) (v : ι → IntVec d)
    (hv : ∀ i, InOrthant ε (v i)) (s : Finset ι) :
    orthantDecode ε (∑ i ∈ s, absoluteExponent (v i)) = ∑ i ∈ s, v i := by
  rw [orthantDecode_sum]
  apply Finset.sum_congr rfl
  intro i _
  exact orthantDecode_absoluteExponent ε (v i) (hv i)

/-- The exponent box is exactly the sum-of-absolute-values budget, with no
loss from coordinate cancellation. -/
theorem absoluteExponent_sum_le_iff (v : ι → IntVec d) (s : Finset ι)
    (Δ : Fin d →₀ ℕ) :
    (∑ i ∈ s, absoluteExponent (v i)) ≤ Δ ↔
      AbsoluteBudget v s (fun j => (Δ j : ℤ)) := by
  constructor
  · intro h j
    have hj := h j
    simp only [Finsupp.finset_sum_apply, absoluteExponent_apply] at hj
    have hcast : (∑ i ∈ s, ((v i j).natAbs : ℤ)) ≤ (Δ j : ℤ) := by exact_mod_cast hj
    simpa only [Int.natCast_natAbs] using hcast
  · intro h j
    have hj := h j
    simp only [Finsupp.finset_sum_apply, absoluteExponent_apply]
    have hcast : (∑ i ∈ s, ((v i j).natAbs : ℤ)) ≤ (Δ j : ℤ) := by
      simpa only [Int.natCast_natAbs] using hj
    exact_mod_cast hcast

/-- Actual integer-Newton support in one orthant is exactly the set of signed
subset sums admitting an available-copy witness within both budgets. -/
theorem orthant_newtonSupport_iff [Fintype ι] (ε : Fin d → Bool)
    (v : ι → IntVec d) (hv : ∀ i, InOrthant ε (v i))
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (t : IntVec d) :
    (∃ e : Fin d →₀ ℕ,
      0 < MvPolynomial.coeff e
        (newtonTruncatedSupport (fun i => absoluteExponent (v i)) Δ kcap) ∧
      orthantDecode ε e = t) ↔
    ∃ s : Finset ι, s.card ≤ kcap ∧
      AbsoluteBudget v s (fun j => (Δ j : ℤ)) ∧ (∑ i ∈ s, v i) = t := by
  constructor
  · rintro ⟨e, he, ht⟩
    obtain ⟨hΔ, s, hs, hsum⟩ :=
      (newtonTruncatedSupport_coeff_pos_iff _ Δ e kcap).mp he
    refine ⟨s, hs, (absoluteExponent_sum_le_iff v s Δ).mp (hsum ▸ hΔ), ?_⟩
    rw [← orthantDecode_absolute_sum ε v hv s, hsum, ht]
  · rintro ⟨s, hs, hΔ, ht⟩
    refine ⟨∑ i ∈ s, absoluteExponent (v i), ?_, ?_⟩
    · exact (newtonTruncatedSupport_coeff_pos_iff _ Δ _ kcap).mpr
        ⟨(absoluteExponent_sum_le_iff v s Δ).mpr hΔ, s, hs, rfl⟩
    · rw [orthantDecode_absolute_sum ε v hv s, ht]

end
end Optss
