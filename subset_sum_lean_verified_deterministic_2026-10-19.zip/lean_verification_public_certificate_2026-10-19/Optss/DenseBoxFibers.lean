import Optss.DenseIntegerProgressions
import Mathlib.Combinatorics.Pigeonhole

/-!
# Actual dense fibers and their bounded periods

The fiber and its period are constructed from a finite set. Pigeonhole
counting preserves the original density; primitive gcd normalization
then bounds its positive full period. These are the coordinate-fiber
inputs to the dense-box filling argument.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

/-- A dense subset of a product has an actual fiber at least as dense
as the entire subset. -/
theorem dense_product_fiber {α β : Type*} [DecidableEq α] [DecidableEq β]
    (A : Finset (α × β)) (U : Finset α) (V : Finset β) (c : ℝ)
    (hbox : A ⊆ U ×ˢ V) (hV : V.Nonempty)
    (hdense : c * U.card * V.card ≤ A.card) :
    ∃ y ∈ V, ∃ B : Finset α, B ⊆ U ∧
      (∀ x, x ∈ B ↔ (x, y) ∈ A) ∧ c * U.card ≤ B.card := by
  obtain ⟨y, hy, hsize⟩ := Finset.exists_le_card_fiber_of_nsmul_le_card_of_maps_to
    (s := A) (t := V) (f := Prod.snd) (b := c * U.card)
    (fun a ha => (Finset.mem_product.mp (hbox ha)).2) hV
    (by simpa [nsmul_eq_mul, mul_comm, mul_left_comm] using hdense)
  let F := A.filter (fun p => p.2 = y)
  let B := F.image Prod.fst
  have hcard : B.card = F.card := by
    apply Finset.card_image_iff.mpr
    intro x hx z hz he
    exact Prod.ext he ((Finset.mem_filter.mp hx).2.trans (Finset.mem_filter.mp hz).2.symm)
  refine ⟨y, hy, B, ?_, ?_, ?_⟩
  · intro x hx
    obtain ⟨p, hp, rfl⟩ := Finset.mem_image.mp hx
    exact (Finset.mem_product.mp (hbox (Finset.mem_filter.mp hp).1)).1
  · intro x
    constructor
    · intro hx
      obtain ⟨p, hp, hpx⟩ := Finset.mem_image.mp hx
      have hpy := (Finset.mem_filter.mp hp).2
      have he : p = (x, y) := Prod.ext hpx hpy
      simpa only [he] using (Finset.mem_filter.mp hp).1
    · intro hx
      exact Finset.mem_image.mpr ⟨(x, y), Finset.mem_filter.mpr ⟨hx, rfl⟩, rfl⟩
  · rw [hcard]
    exact hsize

/-- A primitive affine image spans its specified integer coset. -/
theorem primitive_affine_full_period (A B : Finset ℤ) (a v : ℤ) (l : ℕ)
    (hv : 0 < v) (hB : LevNormalized B l)
    (he : A = B.image (fun x => a + v * x)) : HasFullIntegerPeriod A v := by
  constructor
  · refine ⟨a, ?_⟩
    intro x hx
    rw [he] at hx
    obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
    exact ⟨y, by ring⟩
  · intro w hw hperiod
    have hdiv := integer_period_dvd_primitive A B a v (v * w) l hv hB he hperiod
    have hle := Int.le_of_dvd hv hdiv
    nlinarith

/-- Density forces a bounded positive full period. We retain the stronger
bound `c*v ≤ 2`; the source only needs its weaker `4/c` variant after
halving the density. -/
theorem dense_integer_full_period (A : Finset ℤ) (u : ℤ) (N : ℕ) (c : ℝ)
    (_hc : 0 < c) (hN : 4 ≤ c * N)
    (hcard : c * N ≤ A.card) (hbox : A ⊆ Finset.Icc u (u + N)) :
    ∃ v : ℤ, 0 < v ∧ c * v ≤ 2 ∧ HasFullIntegerPeriod A v := by
  have hAc : 2 ≤ A.card := by
    have h : (2 : ℝ) ≤ A.card := by linarith
    exact_mod_cast h
  obtain ⟨a, v, l, B, hv, hB, hBc, he, hwidth, hper⟩ := integer_fiber_period_bound A u N hAc hbox
  refine ⟨v, hv, ?_, primitive_affine_full_period A B a v l hv hB he⟩
  have hvR : (0 : ℝ) < v := by exact_mod_cast hv
  have hperR : (v : ℝ) * ((A.card : ℝ) - 1) ≤ N := by exact_mod_cast hper
  have hNpos : (0 : ℝ) < N := by
    by_contra hh
    have hz : (N : ℝ) = 0 := le_antisymm (le_of_not_gt hh) (by positivity)
    rw [hz, mul_zero] at hN
    norm_num at hN
  apply (mul_le_mul_left hNpos).mp
  nlinarith [mul_nonneg hvR.le (show 0 ≤ 2 * ((A.card : ℝ) - 1) - c * N by linarith)]

/-- A coordinate fiber selected by density has a bounded full period,
and every retained fiber value still names a point in the original set. -/
theorem dense_product_integer_fiber {β : Type*} [DecidableEq β]
    (A : Finset (ℤ × β)) (u : ℤ) (N : ℕ) (V : Finset β) (c : ℝ)
    (hc : 0 < c) (hN : 4 ≤ c * N) (hV : V.Nonempty)
    (hbox : A ⊆ Finset.Icc u (u + N - 1) ×ˢ V)
    (hdense : c * N * V.card ≤ A.card) :
    ∃ y ∈ V, ∃ (B : Finset ℤ) (v : ℤ),
      (∀ x, x ∈ B ↔ (x, y) ∈ A) ∧ B ⊆ Finset.Icc u (u + N - 1) ∧
      c * N ≤ B.card ∧ 0 < v ∧ c * v ≤ 2 ∧ HasFullIntegerPeriod B v := by
  have hNc : (Finset.Icc u (u + N - 1)).card = N := by rw [Int.card_Icc]; omega
  obtain ⟨y, hy, B, hB, hm, hcard⟩ := dense_product_fiber A (Finset.Icc u (u + N - 1)) V c hbox hV
    (by simpa only [hNc] using hdense)
  rw [hNc] at hcard
  obtain ⟨v, hv, hcv, hp⟩ := dense_integer_full_period B u N c hc hN hcard
    (hB.trans (Finset.Icc_subset_Icc le_rfl (by omega)))
  exact ⟨y, hy, B, v, hm, hB, hcard, hv, hcv, hp⟩

end
end Optss
