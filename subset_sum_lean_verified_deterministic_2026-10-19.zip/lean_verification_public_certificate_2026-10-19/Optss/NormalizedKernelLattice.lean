import Optss.ShortKernelCongruence
import Optss.RationalGramSchmidt
import Optss.LatticeBoxingGeometry

/-!
# Rational normalization of the actual short-kernel lattice

Positive coordinate widths turn the searched integer box into the unit
coordinate cube. The matrix below is the computed full congruence-lattice
basis with each coordinate divided by its own width; its rows are genuinely
independent and its integer span is exactly the normalized lattice.
-/
namespace Optss
open scoped BigOperators
variable {d : ℕ}

def normalizedKernelMap (a : Fin d→ℤ) (β : Fin d→ℕ) :
    (Fin d→ℤ) →ₗ[ℤ] (Fin d→ℚ) where
  toFun z i := (congruenceLatticeMap a (shortKernelModulus a β) z i:ℚ)/(β i:ℚ)
  map_add' x y := by ext i; simp [add_div]
  map_smul' n x := by
    ext i
    change ((congruenceLatticeMap a (shortKernelModulus a β) (n •x) i:ℤ):ℚ)/(β i:ℚ)=
      n •((congruenceLatticeMap a (shortKernelModulus a β) x i:ℚ)/(β i:ℚ))
    rw [map_smul]
    simp [Pi.smul_apply,smul_eq_mul,mul_div_assoc]

def normalizedKernelRows (a : Fin d→ℤ) (β : Fin d→ℕ) : Matrix (Fin d) (Fin d) ℚ :=
  fun j => normalizedKernelMap a β (Pi.single j 1)

theorem integer_linear_basis_sum {E : Type*} [AddCommGroup E]
    (f : (Fin d→ℤ) →ₗ[ℤ] E) (z : Fin d→ℤ) :
    (∑ j,z j •f (Pi.single j 1))=f z := by
  have hz : (∑ j,z j •(Pi.single j (1:ℤ) : Fin d→ℤ))=z := by
    ext i
    simp [Finset.sum_apply,Pi.single_apply]
  calc
    _=f (∑ j,z j •(Pi.single j (1:ℤ) : Fin d→ℤ)) := by simp only [map_sum,map_zsmul]
    _=f z := congrArg f hz

theorem normalizedKernelRows_mem_span (a : Fin d→ℤ) (β : Fin d→ℕ) (u : Fin d→ℚ) :
    u∈Submodule.span ℤ (Set.range (normalizedKernelRows a β)) ↔ ∃ z,normalizedKernelMap a β z=u := by
  rw [Submodule.mem_span_range_iff_exists_fun]
  simp only [normalizedKernelRows,integer_linear_basis_sum]

noncomputable def positiveWidthRealEquiv (β : Fin d→ℕ) (hβ : ∀ i,0<β i) :
    (Fin d→ℝ) ≃ₗ[ℝ] (Fin d→ℝ) where
  toFun x i := x i/(β i:ℝ)
  invFun x i := (β i:ℝ)*x i
  left_inv x := by
    ext i
    have hn : (β i:ℝ)≠0 := by exact_mod_cast (ne_of_gt (hβ i))
    simp [hn,div_eq_mul_inv,mul_left_comm,mul_assoc]
  right_inv x := by
    ext i
    have hn : (β i:ℝ)≠0 := by exact_mod_cast (ne_of_gt (hβ i))
    simp [hn]
  map_add' x y := by ext i; simp [add_div]
  map_smul' a x := by ext i; simp [mul_div_assoc]

theorem normalizedKernelRows_independent (a : Fin d→ℤ) (β : Fin d→ℕ) (hβ : ∀ i,0<β i) :
    LinearIndependent ℝ (fun j i => (normalizedKernelRows a β j i:ℝ)) := by
  let f := integerMapRealExtension (congruenceLatticeMap a (shortKernelModulus a β))
  have hsurj : Function.Surjective f := congruenceLatticeMap_real_surjective a _ (ne_of_gt (shortKernelModulus_pos a β))
  have hinj : Function.Injective f := LinearMap.injective_iff_surjective.mpr hsurj
  let e := positiveWidthRealEquiv β hβ
  have hind := (Pi.basisFun ℝ (Fin d)).linearIndependent.map' (e.toLinearMap.comp f)
    (LinearMap.ker_eq_bot.mpr (e.injective.comp hinj))
  have he : (fun j i => (normalizedKernelRows a β j i:ℝ))=
      (e.toLinearMap.comp f) ∘(Pi.basisFun ℝ (Fin d)) := by
    funext j i
    simp [e,f,positiveWidthRealEquiv,normalizedKernelRows,normalizedKernelMap,
      integerMapRealExtension,Pi.single_apply]
  rw [he]
  exact hind

theorem rationalEuclideanVector_injective : Function.Injective (@rationalEuclideanVector d) := by
  intro x y h
  ext i
  have hi := congrArg (fun v : EuclideanSpace ℝ (Fin d) => v i) h
  change (x i:ℝ)=(y i:ℝ) at hi
  exact_mod_cast hi

theorem rational_basis_mem_integer_lattice (B : Matrix (Fin d) (Fin d) ℚ)
    (b : Basis (Fin d) ℝ (EuclideanSpace ℝ (Fin d)))
    (hb : ∀ j,b j=rationalEuclideanRows B j) (u : Fin d→ℚ) :
    rationalEuclideanVector u∈basisIntegerLattice b ↔ u∈Submodule.span ℤ (Set.range B) := by
  rw [mem_basisIntegerLattice_iff,Submodule.mem_span_range_iff_exists_fun]
  have he (z : Fin d→ℤ) : (∑ j,(z j:ℝ) •b j)=rationalEuclideanVector (∑ j,z j •B j) := by
    rw [map_sum]
    apply Finset.sum_congr rfl
    intro j _
    rw [map_zsmul,hb]
    simp only [rationalEuclideanRows,zsmul_eq_mul]
    ext i
    simp [rationalEuclideanVector,PiLp.smul_apply]
  simp_rw [he]
  exact exists_congr (fun z => rationalEuclideanVector_injective.eq_iff)

theorem normalizedKernelMap_cube_iff (a : Fin d→ℤ) (β : Fin d→ℕ) (hβ : ∀ i,0<β i)
    (z : Fin d→ℤ) :
    rationalEuclideanVector (normalizedKernelMap a β z)∈euclideanCoordinateCube d 1 ↔
      congruenceLatticeMap a (shortKernelModulus a β) z∈integerBudgetBox β := by
  rw [mem_integerBudgetBox]
  constructor
  · intro h i
    have hi := h i
    change |(normalizedKernelMap a β z i:ℝ)|≤1 at hi
    dsimp only [normalizedKernelMap,LinearMap.coe_mk,AddHom.coe_mk] at hi
    have hb : (0:ℝ)<β i := by exact_mod_cast hβ i
    rw [Rat.cast_div,Rat.cast_intCast,Rat.cast_natCast,abs_div,abs_of_pos hb,
      div_le_iff₀ hb,one_mul] at hi
    exact_mod_cast hi
  · intro h i
    change |(normalizedKernelMap a β z i:ℝ)|≤1
    dsimp only [normalizedKernelMap,LinearMap.coe_mk,AddHom.coe_mk]
    have hb : (0:ℝ)<β i := by exact_mod_cast hβ i
    rw [Rat.cast_div,Rat.cast_intCast,Rat.cast_natCast,abs_div,abs_of_pos hb,
      div_le_iff₀ hb,one_mul]
    exact_mod_cast h i
end Optss
