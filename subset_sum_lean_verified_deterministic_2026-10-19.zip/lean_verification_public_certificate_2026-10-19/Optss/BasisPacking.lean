import Optss.RankDimension
import Optss.Copies
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas

/-!
# Packing bases from available labelled copies

A finite independent spanning subfamily is constructed by induction over the
available labels. Repeated selection either packs all requested bases or stops
because the actual remaining labels no longer span the initial space. Only the
complete bases are charged as deletions. A successful packing survives arbitrary
small deletions, including deletions that are not uniform within a type.
-/

namespace Optss
open scoped BigOperators Classical
noncomputable section

variable {ι K E : Type*} [DecidableEq ι] [DivisionRing K] [AddCommGroup E] [Module K E]

/-- Span of a specified collection of available labels. -/
def labelSpan (K : Type*) [DivisionRing K] {ι E : Type*} [AddCommGroup E] [Module K E]
    (v : ι → E) (s : Finset ι) : Submodule K E := Submodule.span K (v '' (s : Set ι))

omit [DecidableEq ι] in
theorem labelSpan_mono (v : ι → E) {s t : Finset ι} (hst : s ⊆ t) :
    labelSpan K v s ≤ labelSpan K v t :=
  Submodule.span_mono (Set.image_mono hst)

instance labelSpan_finite (v : ι → E) (s : Finset ι) : FiniteDimensional K (labelSpan K v s) :=
  FiniteDimensional.span_of_finite K (s.finite_toSet.image v)

/-- A label basis preserves the labels of equal-valued but distinct copies. -/
def LabelBasis (v : ι → E) (W : Submodule K E) (b : Finset ι) : Prop :=
  LinearIndepOn K v (b : Set ι) ∧ labelSpan K v b = W

/-- Finite greedy extension constructs an independent spanning subset of the
available labels. This includes empty spans and repeated vector values. -/
theorem exists_labelBasis (v : ι → E) (s : Finset ι) :
    ∃ b : Finset ι, b ⊆ s ∧ LabelBasis v (labelSpan K v s) b := by
  induction s using Finset.induction_on with
  | empty => exact ⟨∅, by simp, by simp [LabelBasis, LinearIndepOn]⟩
  | @insert i s hi ih =>
    obtain ⟨b, hbs, hind, hspan⟩ := ih
    by_cases hm : v i ∈ labelSpan K v b
    · refine ⟨b, hbs.trans (Finset.subset_insert _ _), hind, ?_⟩
      have hm' : v i ∈ labelSpan K v s := hspan ▸ hm
      change v i ∈ Submodule.span K (v '' (s : Set ι)) at hm'
      simpa only [labelSpan, Finset.coe_insert, Set.image_insert_eq,
        Submodule.span_insert_eq_span hm'] using hspan
    · have hib : i ∉ b := fun hib => hi (hbs hib)
      refine ⟨insert i b, Finset.insert_subset_insert _ hbs, ?_, ?_⟩
      · rw [Finset.coe_insert, linearIndepOn_insert (by simpa using hib)]
        exact ⟨hind, hm⟩
      · simp only [labelSpan, Finset.coe_insert, Set.image_insert_eq, Submodule.span_insert]
        exact congrArg (fun W : Submodule K E => (K ∙ v i) ⊔ W) hspan

/-- One concrete choice of the finite greedy spanning subfamily. -/
def selectedLabelBasis (v : ι → E) (s : Finset ι) : Finset ι :=
  Classical.choose (exists_labelBasis (K := K) v s)

theorem selectedLabelBasis_spec (v : ι → E) (s : Finset ι) :
    selectedLabelBasis (K := K) v s ⊆ s ∧
      LabelBasis v (labelSpan K v s) (selectedLabelBasis (K := K) v s) :=
  Classical.choose_spec (exists_labelBasis (K := K) v s)

omit [DecidableEq ι] in
/-- Every selected label basis has exactly the dimension of its span. -/
theorem LabelBasis.card_eq (v : ι → E) (W : Submodule K E) (b : Finset ι)
    (hb : LabelBasis v W b) : b.card = Module.finrank K W := by
  rw [← hb.2]
  have hrange : Set.range (fun i : (b : Set ι) => v i) = v '' (b : Set ι) := by
    ext x; simp
  have hcard := finrank_span_eq_card hb.1
  rw [hrange] at hcard
  simpa only [Finset.coe_sort_coe, Fintype.card_coe, labelSpan] using hcard.symm

/-- Union of the labels in complete packed bases. -/
def packedLabels : List (Finset ι) → Finset ι
  | [] => ∅
  | b :: bs => b ∪ packedLabels bs

/-- Actual bounded recursion: select a full basis while the remaining span is
unchanged, debit its labels, and stop as soon as a basis cannot be completed. -/
def packLabelBases (v : ι → E) (W : Submodule K E) (s : Finset ι) : ℕ → List (Finset ι)
  | 0 => []
  | n+1 => if labelSpan K v s = W then
      let b := selectedLabelBasis (K := K) v s
      b :: packLabelBases v W (s \ b) n
    else []

@[simp] theorem mem_packedLabels (i : ι) (bs : List (Finset ι)) :
    i ∈ packedLabels bs ↔ ∃ b ∈ bs, i ∈ b := by
  induction bs with
  | nil => simp [packedLabels]
  | cons b bs ih => simp [packedLabels, ih, or_and_right, exists_or]

theorem packedLabels_subset (bs : List (Finset ι)) (s : Finset ι)
    (h : ∀ b ∈ bs, b ⊆ s) : packedLabels bs ⊆ s := by
  intro i hi
  obtain ⟨b, hb, hib⟩ := (mem_packedLabels i bs).mp hi
  exact h b hb hib

/-- The recursion packs disjoint full bases, and any early stop witnesses that
the remaining labels fail to span. The partial unsuccessful basis is not removed. -/
theorem packLabelBases_spec (v : ι → E) (W : Submodule K E) (s : Finset ι) (n : ℕ) :
    let bs := packLabelBases v W s n
    bs.length ≤ n ∧
    (∀ b ∈ bs, b ⊆ s ∧ LabelBasis v W b) ∧
    bs.Pairwise Disjoint ∧
    (bs.length < n → labelSpan K v (s \ packedLabels bs) ≠ W) := by
  induction n generalizing s with
  | zero => simp [packLabelBases]
  | succ n ih =>
    by_cases hs : labelSpan K v s = W
    · let b := selectedLabelBasis (K := K) v s
      have hb : b ⊆ s ∧ LabelBasis v W b := by
        simpa only [b, hs] using selectedLabelBasis_spec (K := K) v s
      obtain ⟨hlen, hmem, hpair, hstop⟩ := ih (s \ b)
      simp only [packLabelBases, if_pos hs]
      change (b :: packLabelBases v W (s \ b) n).length ≤ n+1 ∧ _
      refine ⟨by simpa using Nat.add_le_add_right hlen 1, ?_, ?_, ?_⟩
      · intro a ha
        rcases List.mem_cons.mp ha with rfl | ha
        · exact hb
        · exact ⟨(hmem a ha).1.trans Finset.sdiff_subset, (hmem a ha).2⟩
      · rw [List.pairwise_cons]
        refine ⟨?_, hpair⟩
        intro a ha
        apply Finset.disjoint_left.mpr
        intro i hib hia
        exact (Finset.mem_sdiff.mp ((hmem a ha).1 hia)).2 hib
      · intro hshort
        have hshort' : (packLabelBases v W (s \ b) n).length < n := by
          simpa only [List.length_cons, Nat.add_lt_add_iff_right] using hshort
        have heq : s \ packedLabels (b :: packLabelBases v W (s \ b) n) =
            (s \ b) \ packedLabels (packLabelBases v W (s \ b) n) := by
          ext i; simp [packedLabels, and_assoc, and_left_comm]
        rw [heq]
        exact hstop hshort'
    · simp [packLabelBases, hs, packedLabels]


/-- The disjoint bases consume exactly rank times the number of complete bases. -/
theorem packedLabels_card (v : ι → E) (W : Submodule K E) (bs : List (Finset ι))
    (hb : ∀ b ∈ bs, LabelBasis v W b) (hdis : bs.Pairwise Disjoint) :
    (packedLabels bs).card = Module.finrank K W * bs.length := by
  induction bs with
  | nil => simp [packedLabels]
  | cons b bs ih =>
    have hpair := List.pairwise_cons.mp hdis
    have hds : Disjoint b (packedLabels bs) := by
      apply Finset.disjoint_left.mpr
      intro i hib hi
      obtain ⟨a, ha, hia⟩ := (mem_packedLabels i bs).mp hi
      exact Finset.disjoint_left.mp (hpair.1 a ha) hib hia
    rw [packedLabels, Finset.card_union_of_disjoint hds,
      LabelBasis.card_eq v W b (hb b (by simp)),
      ih (fun a ha => hb a (by simp [ha])) hpair.2, List.length_cons]
    ring

/-- Pigeonhole principle for disjoint certificates: fewer removed labels than
certificates leaves at least one certificate entirely untouched. -/
theorem exists_packed_disjoint (bs : List (Finset ι)) (deleted : Finset ι)
    (hdis : bs.Pairwise Disjoint) (hcard : deleted.card < bs.length) :
    ∃ b ∈ bs, Disjoint b deleted := by
  induction bs generalizing deleted with
  | nil => simp at hcard
  | cons b bs ih =>
    by_cases hb : Disjoint b deleted
    · exact ⟨b, by simp, hb⟩
    · obtain ⟨i, hib, hid⟩ := Finset.not_disjoint_iff.mp hb
      have hpair := List.pairwise_cons.mp hdis
      have hsmall : (deleted.erase i).card < bs.length := by
        rw [Finset.card_erase_of_mem hid]
        have hpos : 0 < deleted.card := Finset.card_pos.mpr ⟨i, hid⟩
        simp only [List.length_cons] at hcard
        omega
      obtain ⟨a, ha, had⟩ := ih (deleted.erase i) hpair.2 hsmall
      refine ⟨a, by simp [ha], Finset.disjoint_left.mpr ?_⟩
      intro j hja hjd
      by_cases hji : j = i
      · subst j
        exact Finset.disjoint_left.mp (hpair.1 a ha) hib hja
      · exact Finset.disjoint_left.mp had hja (Finset.mem_erase.mpr ⟨hji, hjd⟩)

/-- Successful packing protects the whole original span against every deletion
of at most `k` labels: one of the actual packed bases remains intact. -/
theorem packLabelBases_success (v : ι → E) (s : Finset ι) (k : ℕ)
    (hfull : (packLabelBases v (labelSpan K v s) s (k+1)).length = k+1)
    (deleted : Finset ι) (hdeleted : deleted.card ≤ k) :
    ∃ b ∈ packLabelBases v (labelSpan K v s) s (k+1),
      b ⊆ s \ deleted ∧ LabelBasis v (labelSpan K v s) b ∧
      labelSpan K v (s \ deleted) = labelSpan K v s := by
  obtain ⟨_, hmem, hdis, _⟩ := packLabelBases_spec v (labelSpan K v s) s (k+1)
  obtain ⟨b, hb, hbd⟩ := exists_packed_disjoint _ deleted hdis (by omega)
  have hbs : b ⊆ s \ deleted := by
    intro i hi
    exact Finset.mem_sdiff.mpr ⟨(hmem b hb).1 hi, Finset.disjoint_left.mp hbd hi⟩
  refine ⟨b, hb, hbs, (hmem b hb).2, le_antisymm ?_ ?_⟩
  · exact labelSpan_mono v Finset.sdiff_subset
  · rw [← (hmem b hb).2.2]
    exact labelSpan_mono v hbs

/-- Failure deletes just the completed bases. Their actual label union has at
most `rank * k` elements, and the span and finrank of the remainder strictly fall. -/
theorem packLabelBases_failure (v : ι → E) (s : Finset ι) (k : ℕ)
    (hshort : (packLabelBases v (labelSpan K v s) s (k+1)).length < k+1) :
    let bs := packLabelBases v (labelSpan K v s) s (k+1)
    packedLabels bs ⊆ s ∧
    (packedLabels bs).card = Module.finrank K (labelSpan K v s) * bs.length ∧
    (packedLabels bs).card ≤ Module.finrank K (labelSpan K v s) * k ∧
    labelSpan K v (s \ packedLabels bs) < labelSpan K v s ∧
    Module.finrank K (labelSpan K v (s \ packedLabels bs)) <
      Module.finrank K (labelSpan K v s) := by
  obtain ⟨_, hmem, hdis, hstop⟩ := packLabelBases_spec v (labelSpan K v s) s (k+1)
  have hcard := packedLabels_card v (labelSpan K v s) _ (fun b hb => (hmem b hb).2) hdis
  have hlt : labelSpan K v (s \ packedLabels (packLabelBases v (labelSpan K v s) s (k+1))) <
      labelSpan K v s :=
    lt_of_le_of_ne (labelSpan_mono v Finset.sdiff_subset) (hstop hshort)
  refine ⟨packedLabels_subset _ _ (fun b hb => (hmem b hb).1), hcard, ?_, hlt,
    Submodule.finrank_lt_finrank_of_lt hlt⟩
  rw [hcard]
  exact Nat.mul_le_mul_left _ (by omega)

/-- The full basis-packing alternative is a theorem of the recursively defined
construction, with no assumed packing or rank-drop certificate. -/
theorem packLabelBases_alternative (v : ι → E) (s : Finset ι) (k : ℕ) :
    let bs := packLabelBases v (labelSpan K v s) s (k+1)
    (bs.length = k+1 ∧ ∀ deleted : Finset ι, deleted.card ≤ k →
      ∃ b ∈ bs, b ⊆ s \ deleted ∧ LabelBasis v (labelSpan K v s) b ∧
        labelSpan K v (s \ deleted) = labelSpan K v s) ∨
    (bs.length ≤ k ∧ packedLabels bs ⊆ s ∧
      (packedLabels bs).card = Module.finrank K (labelSpan K v s) * bs.length ∧
      (packedLabels bs).card ≤ Module.finrank K (labelSpan K v s) * k ∧
      labelSpan K v (s \ packedLabels bs) < labelSpan K v s ∧
      Module.finrank K (labelSpan K v (s \ packedLabels bs)) <
        Module.finrank K (labelSpan K v s)) := by
  have hlen := (packLabelBases_spec v (labelSpan K v s) s (k+1)).1
  by_cases hfull : (packLabelBases v (labelSpan K v s) s (k+1)).length = k+1
  · exact Or.inl ⟨hfull, fun deleted hd => packLabelBases_success v s k hfull deleted hd⟩
  · have hshort : (packLabelBases v (labelSpan K v s) s (k+1)).length < k+1 := by omega
    exact Or.inr ⟨by omega, packLabelBases_failure v s k hshort⟩

section Counts
variable [Fintype ι]

/-- Actual natural counter decrement of a deletion of available labelled copies. -/
def copyDebit (c : ι → ℕ) (deleted : Finset (CopyIndex c)) (i : ι) : ℕ :=
  (Finset.univ.filter (fun j : Fin (c i) => Sigma.mk i j ∈ deleted)).card

omit [Fintype ι] in
theorem copyDebit_le_available (c : ι → ℕ) (deleted : Finset (CopyIndex c)) (i : ι) :
    copyDebit c deleted i ≤ c i := by
  simpa [copyDebit] using
    (Finset.univ.filter (fun j : Fin (c i) => Sigma.mk i j ∈ deleted)).card_le_univ

omit [Fintype ι] in
theorem copyDebit_intCast (c : ι → ℕ) (deleted : Finset (CopyIndex c)) (i : ι) :
    copyCount c deleted i = (copyDebit c deleted i : ℤ) := by
  unfold copyCount copyDebit
  congr 2
  ext j
  simp

/-- The counters debit exactly the number of deleted copies. -/
theorem copyDebit_sum (c : ι → ℕ) (deleted : Finset (CopyIndex c)) :
    ∑ i, copyDebit c deleted i = deleted.card := by
  have h := sum_expandedCopy (fun _ : ι => (1 : ℤ)) c deleted
  have h' : (deleted.card : ℤ) = ∑ i, (copyDebit c deleted i : ℤ) := by
    simpa only [expandedCopy, Finset.sum_const, nsmul_eq_mul, mul_one,
      weightedSum, smul_eq_mul, copyDebit_intCast] using h
  exact_mod_cast h'.symm

omit [Fintype ι] in
/-- A residual type is live exactly when an undeleted original copy exists. -/
theorem copyDebit_lt_iff_remaining (c : ι → ℕ) (deleted : Finset (CopyIndex c)) (i : ι) :
    copyDebit c deleted i < c i ↔ ∃ j : Fin (c i), Sigma.mk i j ∉ deleted := by
  have hpartition := Finset.filter_card_add_filter_neg_card_eq_card
    (s := Finset.univ) (fun j : Fin (c i) => Sigma.mk i j ∈ deleted)
  have hsum : copyDebit c deleted i +
      (Finset.univ.filter (fun j : Fin (c i) => Sigma.mk i j ∉ deleted)).card = c i := by
    simpa only [copyDebit, Finset.card_univ, Fintype.card_fin] using hpartition
  have heq : (Finset.univ.filter (fun j : Fin (c i) => Sigma.mk i j ∉ deleted)).card > 0 ↔
      ∃ j : Fin (c i), Sigma.mk i j ∉ deleted := by
    simp only [Finset.card_pos, Finset.Nonempty, Finset.mem_filter, Finset.mem_univ, true_and]
  constructor
  · intro hlt
    apply heq.mp
    omega
  · intro hex
    have hp := heq.mpr hex
    omega

/-- Span of types that have a genuinely available positive multiplicity. -/
def liveCountSpan (K : Type*) [DivisionRing K] {ι E : Type*} [Fintype ι]
    [AddCommGroup E] [Module K E] (v : ι → E) (c : ι → ℕ) : Submodule K E :=
  labelSpan K v (Finset.univ.filter (fun i => 0 < c i))

/-- Copy deletion and counter decrement give exactly the same surviving span. -/
theorem labelSpan_after_copy_deletion (v : ι → E) (c : ι → ℕ)
    (deleted : Finset (CopyIndex c)) :
    labelSpan K (expandedCopy v c) (Finset.univ \ deleted) =
      liveCountSpan K v (fun i => c i - copyDebit c deleted i) := by
  unfold labelSpan liveCountSpan
  congr 1
  ext x
  simp only [Set.mem_image, Finset.mem_coe, Finset.mem_sdiff, Finset.mem_univ,
    true_and, Finset.mem_filter, Nat.sub_pos_iff_lt, copyDebit_lt_iff_remaining, expandedCopy]
  constructor
  · rintro ⟨⟨i, j⟩, hj, rfl⟩
    exact ⟨i, ⟨j, hj⟩, rfl⟩
  · rintro ⟨i, ⟨j, hj⟩, rfl⟩
    exact ⟨⟨i, j⟩, hj, rfl⟩

theorem labelSpan_all_copies (v : ι → E) (c : ι → ℕ) :
    labelSpan K (expandedCopy v c) Finset.univ = liveCountSpan K v c := by
  simpa [copyDebit] using labelSpan_after_copy_deletion (K := K) v c ∅

omit [Fintype ι] in
/-- An independent basis never selects two copies of the same type. -/
theorem LabelBasis.copyDebit_le_one (v : ι → E) (c : ι → ℕ) (W : Submodule K E)
    (b : Finset (CopyIndex c)) (hb : LabelBasis (expandedCopy v c) W b) (i : ι) :
    copyDebit c b i ≤ 1 := by
  apply Finset.card_le_one.mpr
  intro a ha b' hb'
  have hae : Sigma.mk i a ∈ b := (Finset.mem_filter.mp ha).2
  have hbe : Sigma.mk i b' ∈ b := (Finset.mem_filter.mp hb').2
  have heq := hb.1.injOn hae hbe (show expandedCopy v c ⟨i,a⟩ = expandedCopy v c ⟨i,b'⟩ from rfl)
  simpa using heq

omit [Fintype ι] in
theorem copyDebit_union_le (c : ι → ℕ) (a b : Finset (CopyIndex c)) (i : ι) :
    copyDebit c (a ∪ b) i ≤ copyDebit c a i + copyDebit c b i := by
  simpa only [copyDebit, Finset.mem_union, Finset.filter_or] using
    Finset.card_union_le (Finset.univ.filter (fun j : Fin (c i) => Sigma.mk i j ∈ a))
      (Finset.univ.filter (fun j : Fin (c i) => Sigma.mk i j ∈ b))

omit [Fintype ι] in
/-- Per-type temporary debits are bounded by the number of packed bases. -/
theorem packed_copyDebit_le_length (v : ι → E) (c : ι → ℕ) (W : Submodule K E)
    (bs : List (Finset (CopyIndex c))) (hb : ∀ b ∈ bs, LabelBasis (expandedCopy v c) W b)
    (i : ι) : copyDebit c (packedLabels bs) i ≤ bs.length := by
  induction bs with
  | nil => simp [packedLabels, copyDebit]
  | cons b bs ih =>
    have hfirst := LabelBasis.copyDebit_le_one v c W b (hb b (by simp)) i
    have htail := ih (fun a ha => hb a (by simp [ha]))
    exact (copyDebit_union_le c b (packedLabels bs) i).trans
      (by simpa only [List.length_cons, Nat.add_comm] using Nat.add_le_add hfirst htail)

/-- Every feasible natural counter decrement is realized by actual available copies. -/
theorem exists_copyDebit (c x : ι → ℕ) (hx : ∀ i, x i ≤ c i) :
    ∃ deleted : Finset (CopyIndex c), copyDebit c deleted = x ∧ deleted.card = ∑ i, x i := by
  obtain ⟨deleted, hd⟩ := exists_copy_selection c (fun i => (x i : ℤ)) (by
    intro i
    exact ⟨by positivity, Nat.cast_le.mpr (hx i)⟩)
  have heq : copyDebit c deleted = x := by
    funext i
    have hi := congrFun hd i
    rw [copyDebit_intCast] at hi
    exact_mod_cast hi
  exact ⟨deleted, heq, by rw [← copyDebit_sum, heq]⟩

/-- Proof-level packing on genuinely available copies; the copy indices are
bounded by the original multiplicity counters. -/
def packCopyBases (v : ι → E) (c : ι → ℕ) (k : ℕ) : List (Finset (CopyIndex c)) :=
  packLabelBases (expandedCopy v c)
    (labelSpan K (expandedCopy v c) Finset.univ) Finset.univ (k+1)

/-- Successful copy packing protects against arbitrary copy deletions. -/
theorem packCopyBases_success (v : ι → E) (c : ι → ℕ) (k : ℕ)
    (hfull : (packCopyBases (K := K) v c k).length = k+1)
    (deleted : Finset (CopyIndex c)) (hdeleted : deleted.card ≤ k) :
    (∃ b ∈ packCopyBases (K := K) v c k,
      b ⊆ Finset.univ \ deleted ∧ LabelBasis (expandedCopy v c) (liveCountSpan K v c) b) ∧
    liveCountSpan K v (fun i => c i - copyDebit c deleted i) = liveCountSpan K v c := by
  obtain ⟨b, hb, hbd, hbasis, hspan⟩ := packLabelBases_success
    (expandedCopy v c) Finset.univ k hfull deleted hdeleted
  rw [labelSpan_all_copies] at hbasis
  rw [labelSpan_after_copy_deletion, labelSpan_all_copies] at hspan
  exact ⟨⟨b, hb, hbd, hbasis⟩, hspan⟩

/-- Successful packing also protects every feasible counter decrement of total
size at most `k`; no choice of how copies were removed affects the conclusion. -/
theorem packCopyBases_success_counters (v : ι → E) (c x : ι → ℕ) (k : ℕ)
    (hfull : (packCopyBases (K := K) v c k).length = k+1)
    (hx : ∀ i, x i ≤ c i) (hsum : ∑ i, x i ≤ k) :
    liveCountSpan K v (fun i => c i - x i) = liveCountSpan K v c := by
  obtain ⟨deleted, hd, hcard⟩ := exists_copyDebit c x hx
  have h := (packCopyBases_success v c k hfull deleted (hcard ▸ hsum)).2
  simpa only [hd] using h

/-- Failure transports the exact complete-basis union to actual counters.
Each type loses at most one copy per completed basis; the total debit is exactly
rank times their number, and the live span strictly drops. -/
theorem packCopyBases_failure (v : ι → E) (c : ι → ℕ) (k : ℕ)
    (hshort : (packCopyBases (K := K) v c k).length < k+1) :
    let bs := packCopyBases (K := K) v c k
    let x := copyDebit c (packedLabels bs)
    (∀ i, x i ≤ c i ∧ x i ≤ bs.length ∧ x i ≤ k) ∧
    (∑ i, x i) = Module.finrank K (liveCountSpan K v c) * bs.length ∧
    (∑ i, x i) ≤ Module.finrank K (liveCountSpan K v c) * k ∧
    liveCountSpan K v (fun i => c i - x i) < liveCountSpan K v c ∧
    Module.finrank K (liveCountSpan K v (fun i => c i - x i)) <
      Module.finrank K (liveCountSpan K v c) := by
  let bs := packCopyBases (K := K) v c k
  have hmem : ∀ b ∈ bs, LabelBasis (expandedCopy v c) (liveCountSpan K v c) b := by
    intro b hb
    have h := (packLabelBases_spec (expandedCopy v c)
      (labelSpan K (expandedCopy v c) Finset.univ) Finset.univ (k+1)).2.1 b hb
    simpa only [labelSpan_all_copies] using h.2
  obtain ⟨_, hcard, hbound, hspan, hrank⟩ := packLabelBases_failure
    (expandedCopy v c) Finset.univ k hshort
  change (packedLabels bs).card =
    Module.finrank K (labelSpan K (expandedCopy v c) Finset.univ) * bs.length at hcard
  change (packedLabels bs).card ≤
    Module.finrank K (labelSpan K (expandedCopy v c) Finset.univ) * k at hbound
  change labelSpan K (expandedCopy v c) (Finset.univ \ packedLabels bs) <
    labelSpan K (expandedCopy v c) Finset.univ at hspan
  change Module.finrank K (labelSpan K (expandedCopy v c) (Finset.univ \ packedLabels bs)) <
    Module.finrank K (labelSpan K (expandedCopy v c) Finset.univ) at hrank
  rw [labelSpan_all_copies] at hcard hbound
  rw [labelSpan_after_copy_deletion, labelSpan_all_copies] at hspan hrank
  have hlen : bs.length ≤ k := by change bs.length < k+1 at hshort; omega
  refine ⟨?_, ?_, ?_, hspan, hrank⟩
  · intro i
    have hi := packed_copyDebit_le_length v c (liveCountSpan K v c) bs hmem i
    exact ⟨copyDebit_le_available c _ i, hi, hi.trans hlen⟩
  · rw [copyDebit_sum]
    exact hcard
  · rw [copyDebit_sum]
    exact hbound

end Counts

end
end Optss
