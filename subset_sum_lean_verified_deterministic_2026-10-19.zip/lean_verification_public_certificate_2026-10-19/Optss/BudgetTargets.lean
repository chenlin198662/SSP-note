import Optss.ColorPreprocessing
import Optss.ConfiguredClassSupport

/-!
# All required signed-budget targets, fixed before sampling

The required target set is defined by the original absolute-budget witnesses.
It is finite, contains zero, and has at most the exact number of integer points
in the output box. Choosing its witnesses uses no random sample. The actual
configured class construction then retains all of it with the requested
failure allowance. No probability hypothesis about an opaque oracle is used.
-/

namespace Optss
open scoped BigOperators Classical
noncomputable section
variable {ι : Type*} [Fintype ι] {d : ℕ}

def requiredBudgetSums (v : ι → IntVec d) (Δ : Fin d → ℕ) : Finset (IntVec d) :=
  (Finset.univ.powerset.filter (fun s => AbsoluteBudget v s (fun j => (Δ j : ℤ)))).image
    (fun s => ∑ i ∈ s, v i)

@[simp] theorem mem_requiredBudgetSums (v : ι → IntVec d) (Δ : Fin d → ℕ) (t : IntVec d) :
    t ∈ requiredBudgetSums v Δ ↔
      ∃ s : Finset ι, AbsoluteBudget v s (fun j => (Δ j : ℤ)) ∧ (∑ i ∈ s, v i) = t := by
  simp [requiredBudgetSums]

theorem zero_mem_requiredBudgetSums (v : ι → IntVec d) (Δ : Fin d → ℕ) :
    0 ∈ requiredBudgetSums v Δ := by
  apply (mem_requiredBudgetSums v Δ 0).mpr
  exact ⟨∅, by intro j; simp, by simp⟩

theorem requiredBudgetSums_subset_box (v : ι → IntVec d) (Δ : Fin d → ℕ) :
    requiredBudgetSums v Δ ⊆ integerBudgetBox Δ := by
  intro t ht
  obtain ⟨s, hs, rfl⟩ := (mem_requiredBudgetSums v Δ t).mp ht
  exact (mem_integerBudgetBox Δ _).mpr (sum_inBox_of_absoluteBudget v hs)

theorem requiredBudgetSums_card_le (v : ι → IntVec d) (Δ : Fin d → ℕ) :
    (requiredBudgetSums v Δ).card ≤ ∏ j, (2*Δ j+1) := by
  simpa only [integerBudgetBox_card] using Finset.card_le_card (requiredBudgetSums_subset_box v Δ)

def budgetTargetWitness (v : ι → IntVec d) (Δ : Fin d → ℕ)
    (t : {t // t ∈ requiredBudgetSums v Δ}) : Finset ι :=
  Classical.choose ((mem_requiredBudgetSums v Δ t.val).mp t.property)

theorem budgetTargetWitness_budget (v : ι → IntVec d) (Δ : Fin d → ℕ)
    (t : {t // t ∈ requiredBudgetSums v Δ}) :
    AbsoluteBudget v (budgetTargetWitness v Δ t) (fun j => (Δ j : ℤ)) :=
  (Classical.choose_spec ((mem_requiredBudgetSums v Δ t.val).mp t.property)).1

theorem budgetTargetWitness_sum (v : ι → IntVec d) (Δ : Fin d → ℕ)
    (t : {t // t ∈ requiredBudgetSums v Δ}) :
    (∑ i ∈ budgetTargetWitness v Δ t, v i) = t.val :=
  (Classical.choose_spec ((mem_requiredBudgetSums v Δ t.val).mp t.property)).2

/-- The single-class failure allowance pays for every possible integer output
and every class, including when many potential outputs have no witness. -/
def signedBudgetFailureAllowance (Δ : Fin d → ℕ) (g : ℕ) (ξ : ℝ) : ℝ :=
  ξ / ((g : ℝ) * ∏ j, (2*(Δ j : ℝ)+1))

theorem signedBudgetFailureAllowance_pos (Δ : Fin d → ℕ) {g : ℕ} (hg : 0 < g)
    {ξ : ℝ} (hξ : 0 < ξ) : 0 < signedBudgetFailureAllowance Δ g ξ := by
  unfold signedBudgetFailureAllowance
  positivity

theorem signedBudgetFailureAllowance_lt_one (Δ : Fin d → ℕ) {g : ℕ} (hg : 0 < g)
    {ξ : ℝ} (hξ : ξ < 1) : signedBudgetFailureAllowance Δ g ξ < 1 := by
  have hq : (1 : ℝ) ≤ ∏ j, (2*(Δ j : ℝ)+1) := by
    have hnat : 1 ≤ ∏ j, (2*Δ j+1) := Finset.one_le_prod' (fun j _ => by omega)
    exact_mod_cast hnat
  have hg' : (1 : ℝ) ≤ g := by exact_mod_cast hg
  have hd : (1 : ℝ) ≤ (g : ℝ) * ∏ j, (2*(Δ j : ℝ)+1) := by nlinarith
  exact (div_lt_one (lt_of_lt_of_le zero_lt_one hd)).mpr (hξ.trans_le hd)

/-- Actual missing-output probability for the configured construction, with
the dyadic witness quotas supplied as deterministic hypotheses. -/
theorem configuredSignedClassSupport_all_budgets_failure {g : ℕ} (hg : 0 < g)
    (v : ι → IntVec d) (part : ι → Fin g) (Δ : Fin d →₀ ℕ) (k : Fin g → ℕ)
    (hcard : ∀ s : Finset ι, AbsoluteBudget v s (fun j => (Δ j : ℤ)) →
      ∀ p, (s.filter (fun i => part i=p)).card ≤ k p)
    (ξ : ℝ) (hξ : 0 < ξ) (hξ1 : ξ < 1) :
    let V := boxVolume Δ
    let ζ := signedBudgetFailureAllowance Δ g ξ
    uniformProbability (Finset.univ.filter
      (fun sample : ∀ p, ConfiguredClassSample (classLabels part p) (k p) V ζ =>
        ¬requiredBudgetSums v Δ ⊆ configuredSignedClassSupport v part Δ k V ζ sample)) ≤ ξ := by
  dsimp only
  let ζ := signedBudgetFailureAllowance Δ g ξ
  have hζ := signedBudgetFailureAllowance_pos Δ hg hξ
  have hζ1 := signedBudgetFailureAllowance_lt_one Δ hg hξ1
  have h := uniform_configuredSignedClassSupport_failure_le v part Δ k (boxVolume Δ)
    (boxVolume_pos Δ) ζ hζ hζ1 (requiredBudgetSums v Δ) (budgetTargetWitness v Δ)
    (budgetTargetWitness_sum v Δ) (budgetTargetWitness_budget v Δ)
    (fun t p => hcard _ (budgetTargetWitness_budget v Δ t) p)
  have he : Finset.univ.filter
      (fun sample : ∀ p, ConfiguredClassSample (classLabels part p) (k p) (boxVolume Δ) ζ =>
        ¬requiredBudgetSums v Δ ⊆ configuredSignedClassSupport v part Δ k (boxVolume Δ) ζ sample) =
      Finset.univ.filter (fun sample => ∃ t ∈ requiredBudgetSums v Δ,
        t ∉ configuredSignedClassSupport v part Δ k (boxVolume Δ) ζ sample) := by
    ext sample
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.subset_iff]
    push_neg
    rfl
  rw [he]
  refine h.trans ?_
  have hcount : ((requiredBudgetSums v Δ).card : ℝ) ≤ ∏ j, (2*(Δ j : ℝ)+1) := by
    exact_mod_cast requiredBudgetSums_card_le v Δ
  have hpos : (0 : ℝ) < (g : ℝ) * ∏ j, (2*(Δ j : ℝ)+1) := by positivity
  unfold ζ signedBudgetFailureAllowance
  rw [Nat.cast_mul, ← mul_div_assoc]
  apply (div_le_iff₀ hpos).mpr
  nlinarith [mul_le_mul_of_nonneg_right hcount (show (0 : ℝ) ≤ g by positivity)]

end
end Optss
