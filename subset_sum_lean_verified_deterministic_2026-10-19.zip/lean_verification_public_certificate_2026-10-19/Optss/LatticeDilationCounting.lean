import Optss.HyperplaneCounting
import Optss.ConvexGeometry
import Optss.ColorPreprocessing
import Mathlib.Data.ZMod.Basic
import Mathlib.Analysis.NormedSpace.Pointwise

/-!
# Uniform lattice-point doubling by residue classes

This is the residue-class argument in Appendix B.1. It is valid at every
positive dilation, including below the shortest lattice vector. Working in
integer coordinates loses no full-lattice basis information. Each residue class
injects into the smaller convex symmetric body by `(x-x₀)/p`.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {d : ℕ}

def integerResidue (p : ℕ) (x : IntVec d) : Fin d → ZMod p := fun j => (x j : ZMod p)

def residueDifference (p : ℕ) (base x : IntVec d) : IntVec d :=
  fun j => (x j-base j)/(p : ℤ)

theorem residueDifference_mul (p : ℕ) (base x : IntVec d)
    (hres : integerResidue p x = integerResidue p base) (j : Fin d) :
    (p : ℤ)*residueDifference p base x j = x j-base j := by
  have hd : (p : ℤ) ∣ x j-base j :=
    (ZMod.intCast_eq_intCast_iff_dvd_sub (base j) (x j) p).mp (congrFun hres j).symm
  exact (mul_comm _ _).trans (Int.ediv_mul_cancel hd)

theorem residueDifference_injective (p : ℕ) (base : IntVec d) :
    Set.InjOn (residueDifference p base) {x | integerResidue p x = integerResidue p base} := by
  intro x hx y hy he
  ext j
  have h := congrArg (fun z : IntVec d => (p : ℤ)*z j) he
  dsimp only at h
  rw [residueDifference_mul p base x hx j, residueDifference_mul p base y hy j] at h
  omega

theorem realVector_residueDifference (p : ℕ) (hp : 0 < p) (base x : IntVec d)
    (hres : integerResidue p x = integerResidue p base) :
    realVector (residueDifference p base x) = (1/(p : ℝ)) • (realVector x-realVector base) := by
  ext j
  have h := residueDifference_mul p base x hres j
  have he : (p : ℝ)*(residueDifference p base x j : ℝ) = (x j : ℝ)-(base j : ℝ) := by
    exact_mod_cast h
  change (residueDifference p base x j : ℝ) = (1/(p : ℝ))*((x j : ℝ)-(base j : ℝ))
  have hp' : (p : ℝ) ≠ 0 := by positivity
  field_simp
  nlinarith

/-- The difference quotient lies in the original body whenever `p≥2c`. -/
theorem residueDifference_mem_convex (K : Set (Fin d → ℝ)) (hK : Convex ℝ K)
    (hsym : ∀ x ∈ K, -x ∈ K) (c : ℝ) (hc : 0 ≤ c) (p : ℕ) (hp : 0 < p)
    (hcp : 2*c ≤ p) (base x : IntVec d)
    (hb : realVector base ∈ c • K) (hx : realVector x ∈ c • K)
    (hres : integerResidue p x = integerResidue p base) :
    realVector (residueDifference p base x) ∈ K := by
  obtain ⟨u, hu, heu⟩ := hx
  obtain ⟨v, hv, hev⟩ := hb
  have hzero := zero_mem_of_convex_symmetric hK ⟨u,hu⟩ hsym
  have hmid : (1/2 : ℝ) • u + (1/2 : ℝ) • (-v) ∈ K :=
    hK hu (hsym v hv) (by norm_num) (by norm_num) (by norm_num)
  have hscale : 0 ≤ 2*c/(p : ℝ) ∧ 2*c/(p : ℝ) ≤ 1 :=
    ⟨by positivity, (div_le_one (by positivity)).mpr hcp⟩
  have h := hK.smul_mem_of_zero_mem hzero hmid hscale
  rw [realVector_residueDifference p hp base x hres, ← heu, ← hev]
  convert h using 1
  ext j
  simp only [Pi.smul_apply, Pi.add_apply, Pi.sub_apply, Pi.neg_apply, smul_eq_mul]
  ring

/-- A finite residue fiber has no more points than the smaller-body lattice
set, with the base point chosen from the actual fiber. -/
theorem residue_fiber_card_le (K : Set (Fin d → ℝ)) (hK : Convex ℝ K)
    (hsym : ∀ x ∈ K, -x ∈ K) (c : ℝ) (hc : 0 ≤ c) (p : ℕ) (hp : 0 < p)
    (hcp : 2*c ≤ p) (S T : Finset (IntVec d))
    (hS : ∀ x ∈ S, realVector x ∈ c • K)
    (hT : ∀ x : IntVec d, realVector x ∈ K → x ∈ T) (r : Fin d → ZMod p) :
    (S.filter (fun x => integerResidue p x=r)).card ≤ T.card := by
  let F := S.filter (fun x => integerResidue p x=r)
  by_cases hF : F.Nonempty
  · obtain ⟨base, hb⟩ := hF
    have hbase := Finset.mem_filter.mp hb
    have hsub : F.image (residueDifference p base) ⊆ T := by
      intro y hy
      obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hy
      have hxx := Finset.mem_filter.mp hx
      exact hT _ (residueDifference_mem_convex K hK hsym c hc p hp hcp base x
        (hS base hbase.1) (hS x hxx.1) (hxx.2.trans hbase.2.symm))
    have hinj : Set.InjOn (residueDifference p base) F := by
      intro x hx y hy he
      exact residueDifference_injective p base
        ((Finset.mem_filter.mp hx).2.trans hbase.2.symm)
        ((Finset.mem_filter.mp hy).2.trans hbase.2.symm) he
    exact (Finset.card_image_iff.mpr hinj).symm.trans_le (Finset.card_le_card hsub)
  · change F.card ≤ T.card
    rw [Finset.not_nonempty_iff_eq_empty.mp hF, Finset.card_empty]
    exact Nat.zero_le _

/-- Exact dimension-dependent lattice-point bound for every convex symmetric
body and fixed dilation, without a lower bound on its coordinate widths. -/
theorem lattice_dilation_card_le (K : Set (Fin d → ℝ)) (hK : Convex ℝ K)
    (hsym : ∀ x ∈ K, -x ∈ K) (c : ℝ) (hc : 0 ≤ c) (p : ℕ) (hp : 0 < p)
    (hcp : 2*c ≤ p) (S T : Finset (IntVec d))
    (hS : ∀ x ∈ S, realVector x ∈ c • K)
    (hT : ∀ x : IntVec d, realVector x ∈ K → x ∈ T) :
    S.card ≤ p^d*T.card := by
  letI : NeZero p := ⟨Nat.ne_of_gt hp⟩
  have hcard : S.card = ∑ r : Fin d → ZMod p, (S.filter (fun x => integerResidue p x=r)).card := by
    exact Finset.card_eq_sum_card_fiberwise (s := S) (t := Finset.univ)
      (f := integerResidue p) (fun _ _ => Finset.mem_univ _)
  rw [hcard]
  calc
    _ ≤ ∑ _r : Fin d → ZMod p, T.card := Finset.sum_le_sum (fun r _ =>
      residue_fiber_card_le K hK hsym c hc p hp hcp S T hS hT r)
    _ = p^d*T.card := by simp [Fintype.card_pi, ZMod.card]

/-- Bounded real bodies have finitely many integer points, proved by enclosing
them in an explicit finite coordinate box. -/
theorem integerPoints_finite (K : Set (Fin d → ℝ)) (hb : Bornology.IsBounded K) :
    (realVector ⁻¹' K).Finite := by
  obtain ⟨R, hR⟩ := hb.exists_norm_le
  apply (integerBudgetBox (fun _ : Fin d => ⌈R⌉₊)).finite_toSet.subset
  intro x hx
  apply (mem_integerBudgetBox _ x).mpr
  intro j
  have h : |(x j : ℝ)| ≤ (⌈R⌉₊ : ℝ) := by
    calc
      _ = ‖realVector x j‖ := by simp [realVector]
      _ ≤ ‖realVector x‖ := norm_le_pi_norm _ j
      _ ≤ R := hR _ hx
      _ ≤ (⌈R⌉₊ : ℝ) := Nat.le_ceil _
  exact_mod_cast h

def integerPoints (K : Set (Fin d → ℝ)) (hb : Bornology.IsBounded K) : Finset (IntVec d) :=
  (integerPoints_finite K hb).toFinset

@[simp] theorem mem_integerPoints (K : Set (Fin d → ℝ)) (hb : Bornology.IsBounded K)
    (x : IntVec d) : x ∈ integerPoints K hb ↔ realVector x ∈ K :=
  Set.Finite.mem_toFinset _

/-- Cardinalities here count the entire bounded bodies' integer points, not
merely arbitrary finite subsets supplied as hypotheses. -/
theorem integerPoints_dilation_card (K : Set (Fin d → ℝ)) (hK : Convex ℝ K)
    (hb : Bornology.IsBounded K) (hsym : ∀ x ∈ K, -x ∈ K)
    (c : ℝ) (hc : 0 ≤ c) (p : ℕ) (hp : 0 < p) (hcp : 2*c ≤ p) :
    (integerPoints (c • K) (hb.smul₀ c)).card ≤ p^d*(integerPoints K hb).card :=
  lattice_dilation_card_le K hK hsym c hc p hp hcp _ _
    (fun x hx => (mem_integerPoints _ _ x).mp hx) (fun x hx => (mem_integerPoints _ _ x).mpr hx)

/-- Appendix B.1's counting conclusion is uniform in the external dilation
`a`. Neither a minimum width nor a minimum positive lattice-point radius is
required. The containing box can be any bounded set `C⊆cK`. -/
theorem integerPoints_enclosing_uniform (K C : Set (Fin d → ℝ)) (hK : Convex ℝ K)
    (hbK : Bornology.IsBounded K) (hbC : Bornology.IsBounded C)
    (hsym : ∀ x ∈ K, -x ∈ K) (c : ℝ) (hc : 0 ≤ c) (hC : C ⊆ c • K)
    (p : ℕ) (hp : 0 < p) (hcp : 2*c ≤ p) (a : ℝ) :
    (integerPoints (a • C) (hbC.smul₀ a)).card ≤
      p^d*(integerPoints (a • K) (hbK.smul₀ a)).card := by
  have hsymA : ∀ x ∈ a • K, -x ∈ a • K := by
    rintro x ⟨y, hy, rfl⟩
    exact ⟨-y, hsym y hy, by simp⟩
  apply lattice_dilation_card_le (a • K) (hK.smul a) hsymA c hc p hp hcp
  · intro x hx
    obtain ⟨y, hy, he⟩ := (mem_integerPoints _ _ x).mp hx
    obtain ⟨z, hz, rfl⟩ := hC hy
    refine ⟨a • z, ⟨z, hz, rfl⟩, ?_⟩
    simpa only [smul_smul, mul_comm c a] using he
  · intro x hx
    exact (mem_integerPoints _ _ x).mpr hx

end
end Optss
