import Mathlib.Data.Array.Defs
import Mathlib.Tactic

/-!
# A materialized inverse table for an injective bounded address map

The routine stores original values at their computed addresses. Overwriting
is safe even with repeated inputs: injectivity on the actual input set forces
every write at an address to contain the same original value.
-/
namespace Optss

def fillInverseTable {α : Type} (key : α→ℕ) (table : Array (Option α)) : List α→Array (Option α)
  | [] => table
  | x::xs => fillInverseTable key (table.setIfInBounds (key x) (some x)) xs

@[simp] theorem fillInverseTable_size {α : Type} (key : α→ℕ) (table : Array (Option α)) (xs : List α) :
    (fillInverseTable key table xs).size=table.size := by
  induction xs generalizing table with
  | nil => rfl
  | cons x xs ih => simp [fillInverseTable,ih]

theorem fillInverseTable_preserves {α : Type} (key : α→ℕ) (table : Array (Option α))
    (xs : List α) (n : ℕ) (a : α) (hn : table[n]?=some (some a))
    (hcompat : ∀ x∈xs, key x=n → x=a) :
    (fillInverseTable key table xs)[n]?=some (some a) := by
  induction xs generalizing table with
  | nil => exact hn
  | cons x xs ih =>
    apply ih
    · by_cases hx : key x=n
      · have hxa := hcompat x (by simp) hx
        have hlt := (Array.getElem?_eq_some_iff.mp hn).choose
        rw [hx,hxa]
        exact Array.getElem?_setIfInBounds_self_of_lt hlt
      · simpa only [Array.getElem?_setIfInBounds_ne hx] using hn
    · intro y hy
      exact hcompat y (by simp [hy])

theorem fillInverseTable_complete {α : Type} (key : α→ℕ) (table : Array (Option α))
    (xs : List α) (a : α) (ha : a∈xs) (hbound : key a<table.size)
    (hcompat : ∀ x∈xs, key x=key a → x=a) :
    (fillInverseTable key table xs)[key a]?=some (some a) := by
  induction xs generalizing table with
  | nil => simp at ha
  | cons x xs ih =>
    rw [fillInverseTable]
    rcases List.mem_cons.mp ha with rfl | ha
    · exact fillInverseTable_preserves key _ xs (key a) a
        (Array.getElem?_setIfInBounds_self_of_lt hbound)
        (fun y hy => hcompat y (by simp [hy]))
    · apply ih _ ha
      · simpa only [Array.size_setIfInBounds] using hbound
      · exact fun y hy => hcompat y (by simp [hy])

theorem fillInverseTable_sound {α : Type} (key : α→ℕ) (table : Array (Option α))
    (xs : List α) (n : ℕ) (a : α)
    (h : (fillInverseTable key table xs)[n]?=some (some a)) :
    table[n]?=some (some a) ∨ (a∈xs ∧ key a=n) := by
  induction xs generalizing table with
  | nil => exact Or.inl h
  | cons x xs ih =>
    rcases ih _ h with h | ⟨ha,hkey⟩
    · rw [Array.getElem?_setIfInBounds] at h
      by_cases hx : key x=n
      · simp only [hx,if_pos] at h
        split_ifs at h with hn
        · have he : x=a := by simpa only [Option.some.injEq] using h
          exact Or.inr ⟨by simp [he],by simpa only [he] using hx⟩
      · exact Or.inl (by simpa only [hx,if_false] using h)
    · exact Or.inr ⟨by simp [ha],hkey⟩

def arrayInverseTable {α : Type} (key : α→ℕ) (N : ℕ) (xs : List α) : Array (Option α) :=
  fillInverseTable key (Array.replicate N none) xs

theorem arrayInverseTable_correct {α : Type} (key : α→ℕ) (N : ℕ) (xs : List α)
    (hbound : ∀ a∈xs, key a<N) (hinj : ∀ a∈xs, ∀ b∈xs, key a=key b → a=b)
    (n : ℕ) (a : α) :
    (arrayInverseTable key N xs)[n]?=some (some a) ↔ a∈xs ∧ key a=n := by
  constructor
  · intro h
    rcases fillInverseTable_sound key (Array.replicate N none) xs n a h with h | h
    · simp only [Array.getElem?_replicate] at h
      split_ifs at h <;> simp at h
    · exact h
  · rintro ⟨ha,rfl⟩
    apply fillInverseTable_complete key _ xs a ha
    · simpa only [Array.size_replicate] using hbound a ha
    · exact fun x hx hkey => hinj x hx a ha hkey

/-- Initialization and exactly one computed address/write per input cell. -/
def arrayInverseTableWordWork {α : Type} (keyWork : α→ℕ) (N : ℕ) (xs : List α) : ℕ :=
  2*(N+1)+(xs.map (fun x => keyWork x+4)).sum

theorem arrayInverseTableWordWork_bound {α : Type} (keyWork : α→ℕ) (N : ℕ)
    (xs : List α) (W : ℕ) (hW : ∀ x∈xs, keyWork x≤W) :
    arrayInverseTableWordWork keyWork N xs≤2*(N+1)+(W+4)*xs.length := by
  unfold arrayInverseTableWordWork
  induction xs with
  | nil => simp
  | cons x xs ih =>
    have hx := hW x (by simp)
    have hh := ih (fun y hy => hW y (by simp [hy]))
    simp only [List.map_cons,List.sum_cons,List.length_cons]
    nlinarith

end Optss
