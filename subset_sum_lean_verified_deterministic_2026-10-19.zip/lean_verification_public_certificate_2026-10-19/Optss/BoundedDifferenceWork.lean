import Optss.BoundedDifferenceList

/-! Original-input source-work bounds for the complete bounded difference-list
construction. Boolean scalar operations and sequential list events are counted
by their proved traces; residue-array addresses and centered integer outputs
use bounded-word source operations. Pointer encodings and allocation are not
part of this model. -/
namespace Optss
set_option maxRecDepth 4096
set_option maxHeartbeats 800000

def computedIntegerDifferenceListWork (depth steps : List Bool) (input : List ℤ) : ℕ :=
  let modulus := 2^depth.length
  let residues := input.map (fun z : ℤ => (z : ZMod modulus))
  let flags := storedIndicatorList residues
  4*input.length+storedIndicatorWordWork residues+
    listBooleanDifferenceWork depth steps flags+32*(2^depth.length+1)

theorem computedIntegerDifferenceListWork_bound (depth steps : List Bool) (input : List ℤ) :
    computedIntegerDifferenceListWork depth steps input≤
      (steps.length+1)*(2^depth.length*listBooleanConvolutionWorkFactor depth.length+2)+
        42*2^depth.length+43+9*input.length := by
  let residues := input.map (fun z : ℤ => (z : ZMod (2^depth.length)))
  have hi := storedIndicatorWordWork_bound residues
  have hd := listBooleanDifferenceWork_bound depth steps (storedIndicatorList residues)
    (storedIndicatorList_length residues)
  have hr : residues.length=input.length := List.length_map _
  change 4*input.length+storedIndicatorWordWork residues+
    listBooleanDifferenceWork depth steps (storedIndicatorList residues)+32*(2^depth.length+1)≤_
  rw [hr] at hi
  omega

/-- The ambient unary list is constructed once. Charging the full verified
Fourier initializer also bounds its depth-only prefix, and the remaining
append/map passes have linear length cost. -/
def integerDifferenceDepthWork (steps : List Bool) (U : ℕ) : ℕ :=
  let ambient := List.replicate (U+1) false
  2*(U+1)+1+listFourierInitializationWork ambient+
    4*steps.length+4*(listFourierDepth ambient).length+8

def boundedIntegerDifferenceListWork (steps : List Bool) (U : ℕ) (input : List ℤ) : ℕ :=
  integerDifferenceDepthWork steps U+computedIntegerDifferenceListWork (integerDifferenceDepth steps U) steps input

theorem integerDifferenceDepthWork_bound (steps : List Bool) (U : ℕ) :
    integerDifferenceDepthWork steps U≤512*(U+2)*((U+1).size+steps.length+4)^2 := by
  have hi := listFourierInitializationWork_bound (List.replicate (U+1) false)
  simp only [List.length_replicate] at hi
  have hbase : (listFourierDepth (List.replicate (U+1) false)).length≤(U+1).size+2 := by
    have h := integerDifferenceDepth_length_bound steps U
    simp only [integerDifferenceDepth,List.length_append,List.length_cons,List.length_map] at h
    omega
  have hsq := Nat.pow_le_pow_left (by omega : (U+1).size+3≤(U+1).size+steps.length+4) 2
  have hip := Nat.mul_le_mul_left (256*(U+2)) hsq
  have hlin : (U+1).size+steps.length+4≤((U+1).size+steps.length+4)^2 := by nlinarith
  have hmul := Nat.mul_le_mul_left (U+2) hlin
  change 2*(U+1)+1+listFourierInitializationWork (List.replicate (U+1) false)+
    4*steps.length+4*(listFourierDepth (List.replicate (U+1) false)).length+8≤_
  nlinarith only [hi,hbase,hip,hlin,hmul]

def boundedDifferenceWorkFactor (s t : ℕ) : ℕ :=
  1024*(s+t+4)^2+12*2^t*(t+1)*listBooleanConvolutionWorkFactor (s+t+3)+
    2*(t+1)+504*2^t+52

theorem boundedIntegerDifferenceListWork_bound (steps : List Bool) (U : ℕ) (input : List ℤ) :
    boundedIntegerDifferenceListWork steps U input≤
      (U+input.length+1)*boundedDifferenceWorkFactor (U+1).size steps.length := by
  let t := steps.length
  let s := (U+1).size
  let n := (integerDifferenceDepth steps U).length
  let B := U+input.length+1
  have hb : U+1≤B := by dsimp [B]; omega
  have hN : 1≤B := by dsimp [B]; omega
  have hlen : input.length≤B := by dsimp [B]; omega
  have hn : n≤s+t+3 := integerDifferenceDepth_length_bound steps U
  have hM : 2^n≤12*2^t*(U+1) := (integerDifferenceDepth_modulus steps U).2.le
  have hfactor := listBooleanConvolutionWorkFactor_mono hn
  have hi := integerDifferenceDepthWork_bound steps U
  have hd := computedIntegerDifferenceListWork_bound (integerDifferenceDepth steps U) steps input
  have himul : 512*(U+2)*(s+t+4)^2≤B*(1024*(s+t+4)^2) := by
    have hh := Nat.mul_le_mul_right ((s+t+4)^2) (by omega : 512*(U+2)≤1024*B)
    simpa only [Nat.mul_assoc,Nat.mul_left_comm] using hh
  have hM' : 2^n≤12*2^t*B := hM.trans (Nat.mul_le_mul_left _ hb)
  have hfft : (t+1)*(2^n*listBooleanConvolutionWorkFactor n+2)≤
      (t+1)*((12*2^t*B)*listBooleanConvolutionWorkFactor (s+t+3)+2) := by gcongr
  change integerDifferenceDepthWork steps U+computedIntegerDifferenceListWork (integerDifferenceDepth steps U) steps input≤_
  change _≤B*boundedDifferenceWorkFactor s t
  change integerDifferenceDepthWork steps U≤512*(U+2)*(s+t+4)^2 at hi
  change computedIntegerDifferenceListWork (integerDifferenceDepth steps U) steps input≤
    (t+1)*(2^n*listBooleanConvolutionWorkFactor n+2)+42*2^n+43+9*input.length at hd
  have hsmall : 2*(t+1)+43+9*input.length≤B*(2*(t+1)+52) := by nlinarith only [hN,hlen]
  unfold boundedDifferenceWorkFactor
  generalize listBooleanConvolutionWorkFactor n = X at *
  generalize listBooleanConvolutionWorkFactor (s+t+3) = Y at *
  generalize (s+t+4)^2 = Z at *
  nlinarith only [hi,hd,himul,hfft,hM',hsmall]

end Optss
