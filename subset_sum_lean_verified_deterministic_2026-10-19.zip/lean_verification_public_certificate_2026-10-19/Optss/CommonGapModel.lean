import Optss.CommonGapProtection

/-!
# A uniform common-GAP phase model on the original labels

This packages the proved finite-set construction with its actual labelled
coordinate inverse. Every later surviving subset uses the same original scalar
values and the same proper coordinate map.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1000000

/-- Actual coordinate data for one phase, preserving all original labels. -/
structure CommonGapLabelModel {ι : Type} (v : ι → ℤ) (live : Finset ι) (h : ℕ) where
  rank : ℕ
  widths : Fin rank → ℕ
  projection : IntVec rank →+ ℤ
  coordinates : ι → IntVec rank
  positive : ∀ j, 1 ≤ widths j
  represents : ∀ i ∈ live, projection (coordinates i) = v i
  boxed : ∀ i ∈ live, InCenteredBox widths (coordinates i)
  fullRank : labelSpan ℝ (fun i => realVector (coordinates i)) live = ⊤
  proper : Set.InjOn projection (integerBudgetBox (fun j => 20*h*widths j))

/-- Unconditional existence of phase coordinates and the phase density bound.
The constants and both size cutoffs depend only on the ambient exponent. -/
theorem common_gap_label_model (η : ℝ) (hη : 0 < η) :
    ∃ N₀ H₀ R : ℕ, ∃ C : ℝ, ∀ (ι : Type) [DecidableEq ι]
      (v : ι → ℤ) (live : Finset ι) (N h : ℕ),
      N₀ ≤ N → H₀ ≤ h → (N : ℝ)^η ≤ h →
      (∀ i ∈ live, v i ∈ Finset.Icc 0 (N : ℤ)) →
      ∃ model : CommonGapLabelModel v live h, model.rank ≤ R ∧
        ((integerBudgetBox (fun j => h*model.widths j)).card : ℝ) ≤
          C*(h • insert 0 (live.image v)).card := by
  obtain ⟨N₀, H₀, R, C, hcoords⟩ := common_gap_phase_coordinates η hη
  refine ⟨N₀, max H₀ 1, R, C, ?_⟩
  intro ι _ v live N h hN hh hscale hscalar
  let X := insert 0 (live.image v)
  have hX : X ⊆ Finset.Icc 0 (N : ℤ) := by
    intro x hx
    rcases Finset.mem_insert.mp hx with rfl | hx
    · simp
    · obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hx
      exact hscalar i hi
  obtain ⟨d, hd, ρ, w, U, hw, hz, hU, himage, hproper, _, hfull, hvolume⟩ :=
    hcoords N h X hN ((le_max_left _ _).trans hh) hX (Finset.mem_insert_self _ _) hscale
  have hh1 : 1 ≤ h := (le_max_right _ _).trans hh
  have hp2 : Set.InjOn ρ (integerBudgetBox (fun j => 2*w j)) := by
    apply hproper.mono
    intro x hx
    apply (mem_integerBudgetBox _ x).mpr
    intro j
    exact ((mem_integerBudgetBox _ x).mp hx j).trans (by
      dsimp only
      exact_mod_cast (Nat.mul_le_mul_right (w j) (show 2 ≤ 20*h by omega)))
  obtain ⟨hzlab, _, hspan⟩ := phase_label_coordinates v live ρ w U hz hU himage hp2
  refine ⟨{ rank := d, widths := w, projection := ρ, coordinates := phaseLabelCoordinates ρ w v
            positive := hw, represents := fun i hi => (hzlab i hi).2
            boxed := fun i hi => hU _ (hzlab i hi).1
            fullRank := hspan.trans hfull, proper := hproper }, hd, hvolume⟩

namespace CommonGapLabelModel
variable {ι : Type} [DecidableEq ι] {v : ι → ℤ} {live : Finset ι} {h : ℕ}

/-- The original scalar support of every surviving subset has exactly its
coordinate cardinality, simultaneously at every scale through `20*h`. -/
theorem remaining_card (model : CommonGapLabelModel v live h) (remaining : Finset ι)
    (hremaining : remaining ⊆ live) (k : ℕ) (hk : k ≤ 20*h) :
    (k • insert 0 (remaining.image model.coordinates)).card =
      (k • insert 0 (remaining.image v)).card := by
  let U := insert 0 (remaining.image model.coordinates)
  have hzero : (0 : IntVec model.rank) ∈ U := Finset.mem_insert_self _ _
  have hbox : ∀ x ∈ U, InCenteredBox model.widths x := by
    intro x hx
    rcases Finset.mem_insert.mp hx with rfl | hx
    · simp [InCenteredBox, InBox]
    · obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hx
      exact model.boxed i (hremaining hi)
  have hproper : Set.InjOn model.projection (k • U : Finset (IntVec model.rank)) := by
    apply model.proper.mono
    intro x hx
    apply (mem_integerBudgetBox _ x).mpr
    intro j
    exact (repeatedSumset_in_box model.widths U hbox k x hx j).trans
      (by dsimp only; exact_mod_cast Nat.mul_le_mul_right (model.widths j) hk)
  have himage : U.image model.projection = insert 0 (remaining.image v) := by
    simp only [U, Finset.image_insert, map_zero, Finset.image_image]
    congr 1
    apply Finset.image_congr
    intro i hi
    exact model.represents i (hremaining hi)
  have he := Finset.card_image_of_injOn hproper
  rw [Finset.image_nsmul, himage] at he
  exact he.symm

/-- Every restarted phase continues to measure the fixed original scalar
quantity; the coordinate and scalar tests agree exactly. -/
theorem restart_iff (model : CommonGapLabelModel v live h) (remaining : Finset ι)
    (hremaining : remaining ⊆ live) (M : ℕ) :
    2*(h • insert 0 (remaining.image model.coordinates)).card < M ↔
      2*(h • insert 0 (remaining.image v)).card < M := by
  rw [model.remaining_card remaining hremaining h (by omega)]

/-- The phase density also controls the determinant quantity in the exact
small-lattice-seed bound. -/
theorem determinant_volume_le (model : CommonGapLabelModel v live h) (hh : 1 ≤ h)
    (C : ℝ) (hvolume : ((integerBudgetBox (fun j => h*model.widths j)).card : ℝ) ≤
      C*(h • insert 0 (live.image v)).card) :
    (model.rank.factorial*∏ j, model.widths j : ℕ) ≤
      (model.rank.factorial : ℝ)*C*(h • insert 0 (live.image v)).card := by
  have hp : (∏ j, model.widths j) ≤ (integerBudgetBox (fun j => h*model.widths j)).card := by
    rw [integerBudgetBox_card]
    apply Finset.prod_le_prod (fun j _ => Nat.zero_le _)
    intro j _
    have hw := Nat.mul_le_mul_right (model.widths j) hh
    simpa only [one_mul] using hw.trans (show h*model.widths j ≤ 2*(h*model.widths j)+1 by omega)
  have hpR : (∏ j, model.widths j : ℕ) ≤ C*(h • insert 0 (live.image v)).card :=
    (Nat.cast_le.mpr hp).trans hvolume
  have hm := mul_le_mul_of_nonneg_left hpR (Nat.cast_nonneg model.rank.factorial)
  simpa only [Nat.cast_mul, mul_assoc] using hm

end CommonGapLabelModel
end
end Optss
