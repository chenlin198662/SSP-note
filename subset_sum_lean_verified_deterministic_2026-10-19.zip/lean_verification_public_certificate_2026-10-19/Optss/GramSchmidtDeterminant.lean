import Optss.IntegerSizeReduction

/-!
# Exact Gram determinants and adjacent Gram–Schmidt swaps

The determinants are those of the actual integer prefix matrices. Their
factorization and swap formulas connect the integer reduction potential to
the Euclidean Gram–Schmidt lengths without assuming any reduction theorem.
-/
namespace Optss
noncomputable section
open scoped BigOperators Matrix

section GeneralGram
variable {n : ℕ} {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- Gram matrix in a real inner product space. -/
def realGram (v : Fin n → E) : Matrix (Fin n) (Fin n) ℝ :=
  fun i j => @inner ℝ E _ (v i) (v j)

theorem realGram_linearCombination (v : Fin n → E) (L : Matrix (Fin n) (Fin n) ℝ) :
    realGram (fun i => ∑ j, L i j • v j) = L * realGram v * L.transpose := by
  ext i j
  simp only [realGram, Matrix.mul_apply, Matrix.transpose_apply, sum_inner, inner_sum,
    inner_smul_left, inner_smul_right, conj_trivial, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro k _
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro l _
  ring

/-- Any unit lower triangular expansion in orthogonal vectors has Gram
 determinant equal to the product of their squared norms. -/
theorem realGram_det_of_orthogonal_expansion (v g : Fin n → E)
    (L : Matrix (Fin n) (Fin n) ℝ)
    (hexp : ∀ i, v i = ∑ j, L i j • g j)
    (horth : ∀ i j, i ≠ j → @inner ℝ E _ (g i) (g j) = 0)
    (htri : ∀ i j, i < j → L i j = 0) (hdiag : ∀ i, L i i = 1) :
    (realGram v).det = ∏ i, ‖g i‖ ^ 2 := by
  have he : v = fun i => ∑ j, L i j • g j := funext hexp
  have hg : realGram g = Matrix.diagonal (fun i => ‖g i‖ ^ 2) := by
    ext i j
    by_cases hij : i = j
    · subst j
      simp [realGram, real_inner_self_eq_norm_sq]
    · simp [realGram, Matrix.diagonal, hij, horth i j hij]
  have hdet : L.det = 1 := by
    rw [← Matrix.det_transpose, Matrix.det_of_upperTriangular (show L.transpose.BlockTriangular id from
      fun i j hij => htri j i hij)]
    simp [Matrix.transpose_apply, hdiag]
  rw [he, realGram_linearCombination, Matrix.det_mul, Matrix.det_mul, Matrix.det_transpose,
    hdet, hg, Matrix.det_diagonal, one_mul, mul_one]

end GeneralGram

section PrefixGram
variable {r : ℕ} {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- Unit lower triangular Gram–Schmidt coordinate matrix on a prefix. -/
def gsPrefixCoefficients (v : Fin r → E) (t : Fin (r+1)) :
    Matrix (Fin t.val) (Fin t.val) ℝ := fun i j =>
  if j < i then gsCoefficient v (i.castLE (Nat.le_of_lt_succ t.isLt))
    (j.castLE (Nat.le_of_lt_succ t.isLt)) else if j = i then 1 else 0

/-- Restricting the full Gram–Schmidt expansion to a prefix loses no term. -/
theorem gsPrefix_expansion (v : Fin r → E) (t : Fin (r+1)) (i : Fin t.val) :
    v (i.castLE (Nat.le_of_lt_succ t.isLt)) =
      ∑ j : Fin t.val, gsPrefixCoefficients v t i j •
        gramSchmidt ℝ v (j.castLE (Nat.le_of_lt_succ t.isLt)) := by
  let e : Fin t.val → Fin r := fun j => j.castLE (Nat.le_of_lt_succ t.isLt)
  have hs : ∑ j ∈ Finset.Iio (e i), gsCoefficient v (e i) j • gramSchmidt ℝ v j =
      ∑ j ∈ Finset.Iio i, gsCoefficient v (e i) (e j) • gramSchmidt ℝ v (e j) := by
    symm
    apply Finset.sum_bij (fun j _ => e j)
    · intro j hj
      apply Finset.mem_Iio.mpr
      change j.val < i.val
      have ht : j < i := Finset.mem_Iio.mp hj
      exact ht
    · intro j _ k _ he
      exact Fin.ext (congrArg (fun z : Fin r => z.val) he)
    · intro j hj
      have hji := Finset.mem_Iio.mp hj
      refine ⟨⟨j.val, lt_trans hji i.isLt⟩, Finset.mem_Iio.mpr hji, ?_⟩
      rfl
    · intro j _
      rfl
  rw [gramSchmidt_def'' ℝ v (e i)]
  change gramSchmidt ℝ v (e i) +
    ∑ j ∈ Finset.Iio (e i), gsCoefficient v (e i) j • gramSchmidt ℝ v j = _
  rw [hs]
  have hfilter : Finset.univ.filter (fun j : Fin t.val => j < i) = Finset.Iio i := by
    ext j; simp
  have hf2 : (Finset.univ.filter (fun j : Fin t.val => ¬j < i)).filter (fun j => j = i) = {i} := by
    ext j
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_singleton]
    exact ⟨fun h => h.2, fun h => ⟨by subst j; exact lt_irrefl _, h⟩⟩
  simp only [gsPrefixCoefficients, ite_smul, zero_smul, one_smul, Finset.sum_ite]
  rw [hfilter, hf2]
  simp only [Finset.sum_singleton, Finset.sum_const_zero, add_zero]
  exact add_comm _ _

theorem realGram_prefix_det_eq_prod (v : Fin r → E) (t : Fin (r+1)) :
    (realGram (fun i : Fin t.val => v (i.castLE (Nat.le_of_lt_succ t.isLt)))).det =
      ∏ i : Fin t.val, ‖gramSchmidt ℝ v (i.castLE (Nat.le_of_lt_succ t.isLt))‖ ^ 2 := by
  apply realGram_det_of_orthogonal_expansion _ _ (gsPrefixCoefficients v t)
  · exact gsPrefix_expansion v t
  · intro i j hij
    apply gramSchmidt_orthogonal ℝ v
    intro he
    apply hij
    apply Fin.ext
    exact congrArg (fun z : Fin r => z.val) he
  · intro i j hij
    simp [gsPrefixCoefficients, not_lt_of_ge hij.le, ne_of_gt hij]
  · intro i
    simp [gsPrefixCoefficients]

/-- Gram–Schmidt vectors strictly before the first swapped position are unchanged. -/
theorem gramSchmidt_swap_before (v : Fin r → E) (j k i : Fin r)
    (hjk : j < k) (hij : i < j) :
    gramSchmidt ℝ (v ∘ Equiv.swap j k) i = gramSchmidt ℝ v i := by
  apply gramSchmidt_congr_initial
  intro l hli
  have hlj : l ≠ j := ne_of_lt (hli.trans_lt hij)
  have hlk : l ≠ k := ne_of_lt (hli.trans_lt (hij.trans hjk))
  simp [Equiv.swap_apply_of_ne_of_ne hlj hlk]

/-- At the first swapped position the new orthogonal vector is the old next
orthogonal vector plus its component along the old current one. -/
theorem gramSchmidt_swap_adjacent (v : Fin r → E) (j k : Fin r)
    (hjk : k.val = j.val + 1) :
    gramSchmidt ℝ (v ∘ Equiv.swap j k) j =
      gramSchmidt ℝ v k + gsCoefficient v k j • gramSchmidt ℝ v j := by
  have hjk' : j < k := by change j.val < k.val; omega
  have hI : Finset.Iio k = insert j (Finset.Iio j) := by
    ext i
    simp only [Finset.mem_Iio, Finset.mem_insert]
    constructor
    · intro hi
      by_cases he : i = j
      · exact Or.inl he
      · right
        change i.val < j.val
        have hne : i.val ≠ j.val := fun h => he (Fin.ext h)
        change i.val < k.val at hi
        omega
    · rintro (rfl | hi)
      · exact hjk'
      · exact hi.trans hjk'
  have hnew := gramSchmidt_def'' ℝ (v ∘ Equiv.swap j k) j
  have hold := gramSchmidt_def'' ℝ v k
  change (v ∘ Equiv.swap j k) j = gramSchmidt ℝ (v ∘ Equiv.swap j k) j +
    ∑ i ∈ Finset.Iio j, gsCoefficient (v ∘ Equiv.swap j k) j i •
      gramSchmidt ℝ (v ∘ Equiv.swap j k) i at hnew
  change v k = gramSchmidt ℝ v k +
    ∑ i ∈ Finset.Iio k, gsCoefficient v k i • gramSchmidt ℝ v i at hold
  simp only [Function.comp_apply, Equiv.swap_apply_left] at hnew
  have hsum : ∑ i ∈ Finset.Iio j, gsCoefficient (v ∘ Equiv.swap j k) j i •
      gramSchmidt ℝ (v ∘ Equiv.swap j k) i =
      ∑ i ∈ Finset.Iio j, gsCoefficient v k i • gramSchmidt ℝ v i := by
    apply Finset.sum_congr rfl
    intro i hi
    have hgs := gramSchmidt_swap_before v j k i hjk' (Finset.mem_Iio.mp hi)
    simp [gsCoefficient, hgs]
  rw [hsum] at hnew
  rw [hI, Finset.sum_insert (by simp)] at hold
  apply add_right_cancel (b := ∑ i ∈ Finset.Iio j, gsCoefficient v k i • gramSchmidt ℝ v i)
  rw [← hnew, hold]
  exact (add_assoc _ _ _).symm

theorem gramSchmidt_swap_adjacent_norm_sq (v : Fin r → E) (j k : Fin r)
    (hjk : k.val = j.val + 1) :
    ‖gramSchmidt ℝ (v ∘ Equiv.swap j k) j‖ ^ 2 =
      ‖gramSchmidt ℝ v k‖ ^ 2 + (gsCoefficient v k j) ^ 2 * ‖gramSchmidt ℝ v j‖ ^ 2 := by
  rw [gramSchmidt_swap_adjacent v j k hjk, norm_add_sq_real, inner_smul_right,
    gramSchmidt_orthogonal ℝ v (show k ≠ j by intro he; have := congrArg Fin.val he; omega)]
  simp only [mul_zero, add_zero, norm_smul, Real.norm_eq_abs, mul_pow, sq_abs]

end PrefixGram

section IntegerGramSchmidt
variable {r d : ℕ}

/-- Exact integer prefix covolume equals the product of the squared norms
of the actual full-family Gram–Schmidt vectors in that prefix. -/
theorem prefixGramDet_eq_prod_gsNormSq (A : Matrix (Fin r) (Fin d) ℤ) (t : Fin (r+1)) :
    (prefixGramDet A t : ℝ) = ∏ i : Fin t.val,
      ‖gramSchmidt ℝ (euclideanIntegerRows A) (i.castLE (Nat.le_of_lt_succ t.isLt))‖ ^ 2 := by
  have he : (integerGram (prefixRows A t)).map (Int.castRingHom ℝ) =
      realGram (fun i : Fin t.val => euclideanIntegerRows A (i.castLE (Nat.le_of_lt_succ t.isLt))) := by
    ext i j
    simp [integerGram, Matrix.mul_apply, realGram, PiLp.inner_apply,
      euclideanIntegerRows, prefixRows, mul_comm]
  unfold prefixGramDet
  rw [Int.cast_det]
  change ((integerGram (prefixRows A t)).map (Int.castRingHom ℝ)).det = _
  rw [he, realGram_prefix_det_eq_prod]

/-- Consecutive integer prefix determinants differ by the next squared
Gram–Schmidt norm. No independence is needed for this identity. -/
theorem prefixGramDet_succ_eq (A : Matrix (Fin r) (Fin d) ℤ) (j : Fin r) :
    (prefixGramDet A ⟨j.val + 1, by omega⟩ : ℝ) =
      (prefixGramDet A ⟨j.val, by omega⟩ : ℝ) *
        ‖gramSchmidt ℝ (euclideanIntegerRows A) j‖ ^ 2 := by
  rw [prefixGramDet_eq_prod_gsNormSq, prefixGramDet_eq_prod_gsNormSq,
    Fin.prod_univ_castSucc]
  rfl

/-- Swapping integer rows agrees exactly with permuting their Euclidean images. -/
theorem euclideanIntegerRows_swapRows (A : Matrix (Fin r) (Fin d) ℤ) (j k : Fin r) :
    euclideanIntegerRows (swapRows A j k) = euclideanIntegerRows A ∘ Equiv.swap j k := rfl

/-- The one changed prefix determinant under an adjacent swap, factored using
the original Gram–Schmidt lengths and coefficient. -/
theorem prefixGramDet_swap_adjacent_eq (A : Matrix (Fin r) (Fin d) ℤ)
    (j k : Fin r) (hjk : k.val = j.val + 1) :
    (prefixGramDet (swapRows A j k) ⟨k.val, by omega⟩ : ℝ) =
      (prefixGramDet A ⟨j.val, by omega⟩ : ℝ) *
        (‖gramSchmidt ℝ (euclideanIntegerRows A) k‖ ^ 2 +
          (gsCoefficient (euclideanIntegerRows A) k j) ^ 2 *
            ‖gramSchmidt ℝ (euclideanIntegerRows A) j‖ ^ 2) := by
  have he : (⟨k.val, by omega⟩ : Fin (r+1)) = ⟨j.val + 1, by omega⟩ := Fin.ext hjk
  rw [he, prefixGramDet_succ_eq,
    prefixGramDet_swap_adjacent_of_ne A j k hjk ⟨j.val, by omega⟩ (by dsimp; omega),
    euclideanIntegerRows_swapRows, gramSchmidt_swap_adjacent_norm_sq _ j k hjk]

/-- The exact quotient form of the adjacent Lovász test. Independence ensures
that the preceding integer prefix determinant is nonzero for cancellation. -/
theorem prefixGramDet_swap_adjacent_ratio (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun l => (A i l : ℝ)))
    (j k : Fin r) (hjk : k.val = j.val + 1) :
    (prefixGramDet (swapRows A j k) ⟨k.val, by omega⟩ : ℝ) /
        (prefixGramDet A ⟨k.val, by omega⟩ : ℝ) =
      (‖gramSchmidt ℝ (euclideanIntegerRows A) k‖ ^ 2 +
        (gsCoefficient (euclideanIntegerRows A) k j) ^ 2 *
          ‖gramSchmidt ℝ (euclideanIntegerRows A) j‖ ^ 2) /
        ‖gramSchmidt ℝ (euclideanIntegerRows A) j‖ ^ 2 := by
  rw [prefixGramDet_swap_adjacent_eq A j k hjk]
  have he : (⟨k.val, by omega⟩ : Fin (r+1)) = ⟨j.val + 1, by omega⟩ := Fin.ext hjk
  rw [he, prefixGramDet_succ_eq]
  apply mul_div_mul_left
  have hp := prefixGramDet_pos A hA ⟨j.val, by omega⟩
  exact_mod_cast ne_of_gt hp

end IntegerGramSchmidt
end
end Optss
