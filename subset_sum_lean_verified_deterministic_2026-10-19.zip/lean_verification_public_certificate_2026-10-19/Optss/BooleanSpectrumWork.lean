import Optss.BooleanSpectrumEnergy

/-! Actual gate/list charges for the integer spectrum threshold and tests. -/
namespace Optss

def bitFourierEnergyWork (z : BitFourierInteger) : ℕ :=
  bitListProductWork z.re.digits z.re.digits+bitListProductWork z.im.digits z.im.digits+
    bitListSignedAddCost false false (bitListMultiplication z.re.digits z.re.digits)
      (bitListMultiplication z.im.digits z.im.digits)+4

def bitSpectrumThresholdWork (ms qs : List Bool) : ℕ :=
  let m2 := bitListMultiplication ms ms
  let m3 := bitListMultiplication m2 ms
  let q2 := bitListMultiplication qs qs
  bitListProductWork ms ms+bitListProductWork m2 ms+bitListProductWork qs qs+
    bitListProductWork m3 q2+5

def bitSpectrumKeepWork (scale threshold : List Bool) (z : BitFourierInteger) : ℕ :=
  bitFourierEnergyWork z+bitListProductWork scale (bitFourierEnergy z)+
    bitListLEWork threshold (bitListMultiplication scale (bitFourierEnergy z))+4

theorem bitFourierEnergy_length (z : BitFourierInteger) (L : ℕ) (hz : z.Width L) :
    (bitFourierEnergy z).length≤2*L+1 := by
  have hr := bitListMultiplication_length_le z.re.digits z.re.digits
  have hi := bitListMultiplication_length_le z.im.digits z.im.digits
  have hh := bitListAddAux_length (bitListMultiplication z.re.digits z.re.digits)
    (bitListMultiplication z.im.digits z.im.digits) false
  unfold bitFourierEnergy bitListAdd
  exact (bitListTrim_length_le _).trans (hh.trans (by have h₁ := hz.1; have h₂ := hz.2; omega))

theorem bitSpectrumThreshold_length (ms qs : List Bool) (L : ℕ)
    (hm : ms.length≤L) (hq : qs.length≤L) : (bitSpectrumThreshold ms qs).length≤5*L := by
  have hm2 := bitListMultiplication_length_le ms ms
  have hm3 := bitListMultiplication_length_le (bitListMultiplication ms ms) ms
  have hq2 := bitListMultiplication_length_le qs qs
  exact (bitListMultiplication_length_le _ _).trans (by omega)

theorem bitFourierEnergyWork_bound (z : BitFourierInteger) (L : ℕ) (hz : z.Width L) :
    bitFourierEnergyWork z≤200*(L+1)^2 := by
  have hr := bitListMultiplication_uniform_cost z.re.digits z.re.digits L hz.1 hz.1
  have hi := bitListMultiplication_uniform_cost z.im.digits z.im.digits L hz.2 hz.2
  have hrl := (bitListMultiplication_length_le z.re.digits z.re.digits).trans
    (show z.re.digits.length+z.re.digits.length≤2*L by have h := hz.1; omega)
  have hil := (bitListMultiplication_length_le z.im.digits z.im.digits).trans
    (show z.im.digits.length+z.im.digits.length≤2*L by have h := hz.2; omega)
  have ha := bitListSignedAddCost_bound false false _ _ (2*L) hrl hil
  unfold bitFourierEnergyWork bitListProductWork
  nlinarith

theorem bitSpectrumThresholdWork_bound (ms qs : List Bool) (L : ℕ)
    (hm : ms.length≤L) (hq : qs.length≤L) : bitSpectrumThresholdWork ms qs≤1500*(L+1)^2 := by
  have hm2 : (bitListMultiplication ms ms).length≤2*L :=
    (bitListMultiplication_length_le ms ms).trans (by omega)
  have hm3 : (bitListMultiplication (bitListMultiplication ms ms) ms).length≤3*L :=
    (bitListMultiplication_length_le _ _).trans (by omega)
  have hq2 : (bitListMultiplication qs qs).length≤2*L :=
    (bitListMultiplication_length_le qs qs).trans (by omega)
  have hw1 := bitListMultiplication_uniform_cost ms ms L hm hm
  have hw2 := bitListMultiplication_uniform_cost (bitListMultiplication ms ms) ms (2*L) hm2 (by omega)
  have hw3 := bitListMultiplication_uniform_cost qs qs L hq hq
  have hw4 := bitListMultiplication_uniform_cost _ _ (3*L) hm3 (hq2.trans (by omega))
  unfold bitSpectrumThresholdWork bitListProductWork
  nlinarith

theorem bitSpectrumKeepWork_bound (ns ms qs : List Bool) (z : BitFourierInteger) (L : ℕ)
    (hn : ns.length≤L) (hm : ms.length≤L) (hq : qs.length≤L) (hz : z.Width L) :
    bitSpectrumKeepWork (bitSpectrumScale ns) (bitSpectrumThreshold ms qs) z≤2000*(L+1)^2 := by
  have he := bitFourierEnergy_length z L hz
  have ht := bitSpectrumThreshold_length ms qs L hm hq
  have hs : (bitSpectrumScale ns).length≤L+3 := by simpa only [bitSpectrumScale,List.length_cons] using Nat.add_le_add_right hn 3
  have hp := bitListMultiplication_length_le (bitSpectrumScale ns) (bitFourierEnergy z)
  have hw1 := bitFourierEnergyWork_bound z L hz
  have hw2 := bitListMultiplication_uniform_cost (bitSpectrumScale ns) (bitFourierEnergy z) (2*L+3)
    (hs.trans (by omega)) (he.trans (by omega))
  have hw3 := bitListLEWork_le (bitSpectrumThreshold ms qs)
    (bitListMultiplication (bitSpectrumScale ns) (bitFourierEnergy z)) (5*L+4)
    (ht.trans (by omega)) (hp.trans (by omega))
  unfold bitSpectrumKeepWork bitListProductWork
  nlinarith
end Optss
