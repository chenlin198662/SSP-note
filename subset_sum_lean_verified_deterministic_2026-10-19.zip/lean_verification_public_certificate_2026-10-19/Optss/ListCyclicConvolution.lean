import Optss.ListDyadicTransform
import Optss.FixedPointConvolution

/-! Three stored-list DFTs and pointwise Boolean multiplication compute the
same fixed-point cyclic convolution as the certified array reference. -/
namespace Optss

def listCyclicReflect {α : Type*} : List α → List α
  | [] => []
  | a::xs => a::xs.reverse

theorem listCyclicReflect_length {α : Type*} (xs : List α) :
    (listCyclicReflect xs).length=xs.length := by
  cases xs <;> simp [listCyclicReflect]

theorem listCyclicReflect_map {α β : Type*} (f : α → β) (xs : List α) :
    (listCyclicReflect xs).map f=listCyclicReflect (xs.map f) := by
  cases xs <;> simp [listCyclicReflect]

theorem listCyclicReflect_ofFn_succ {α : Type*} (m : ℕ) (f : Fin (m+1) → α) :
    listCyclicReflect (List.ofFn f)=List.ofFn
      (fun k : Fin (m+1) => f ⟨(-(k.val : ZMod (m+1))).val,ZMod.val_lt _⟩) := by
  apply List.ext_getElem
  · simp only [listCyclicReflect_length,List.length_ofFn]
  · intro i hi hi'
    have hil : i< m+1 := by simpa only [List.length_ofFn] using hi'
    cases i with
    | zero => simp [List.ofFn_succ,listCyclicReflect,List.getElem_ofFn]
    | succ i =>
      have hi : i< m := by omega
      have he : ((i+1 : ℕ) : ZMod (m+1))≠0 := by
        intro hz
        have hv := congrArg ZMod.val hz
        simp only [ZMod.val_natCast,Nat.mod_eq_of_lt hil,ZMod.val_zero] at hv
        omega
      simp only [List.ofFn_succ,listCyclicReflect,List.getElem_cons_succ,List.getElem_reverse,List.getElem_ofFn]
      congr 1
      apply Fin.ext
      simp only [Fin.val_succ,Fin.val_mk,List.length_ofFn,ZMod.neg_val,he,↓reduceIte,ZMod.val_natCast,
        Nat.mod_eq_of_lt hil]
      omega

theorem listCyclicReflect_ofFn {α : Type*} (n : ℕ) (A : Vector α (2^n)) :
    listCyclicReflect (List.ofFn A.get)=List.ofFn
      (fun k : Fin (2^n) => A.get (cyclicArrayIndex n (-(k.val : ZMod (2^n))))) := by
  have hp : 0<2^n := Nat.pow_pos (by decide)
  obtain ⟨m,hm⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hp)
  have h := listCyclicReflect_ofFn_succ m (fun j => A.get (Fin.cast hm.symm j))
  apply List.ext_getElem?
  intro i
  have he := congrArg (fun xs => xs[i]?) h
  simp only [List.getElem?_ofFn] at he ⊢
  have hleft : List.ofFn (fun j : Fin (m+1) => A.get (Fin.cast hm.symm j))=List.ofFn A.get := by
    apply List.ext_getElem?
    intro j
    simp only [List.getElem?_ofFn]
    by_cases hj : j<2^n
    · have hj' : j< m+1 := by omega
      simp only [hj,hj',↓reduceDIte,Fin.cast_mk]
    · have hj' : ¬j< m+1 := by omega
      simp only [hj,hj',↓reduceDIte]
  rw [hleft] at he
  by_cases hi : i<2^n
  · have hi' : i< m+1 := by omega
    simp only [hi,hi',↓reduceDIte] at he ⊢
    rw [he]
    congr 2
    apply Fin.ext
    dsimp only [Fin.coe_cast,cyclicArrayIndex]
    simp only [ZMod.neg_val',ZMod.val_natCast]
    rw [hm]
  · have hi' : ¬i< m+1 := by omega
    simpa only [hi,hi',↓reduceDIte] using he

def listCyclicConvolution (depth : List Bool) (p : ℕ) (A B : List BitFourierInteger) : List BitFourierInteger :=
  let FA := listDyadicTransform depth p A
  let FB := listDyadicTransform depth p B
  let P := List.zipWith bitFourierMul FA FB
  listCyclicReflect (listDyadicTransform depth p P)


theorem storedDyadicArray_value (depth : List Bool) (p : ℕ)
    (A : Vector BitFourierInteger (2^depth.length)) :
    bitFourierVectorValue (bitFixedPointRadixTwo (listDyadicDenominator p)
      (listDyadicTwiddleFunction (radixModulusDigits depth) depth.length p) depth.length A)=
        dyadicRadixDFT depth.length p (bitFourierVectorValue A) := by
  have h := bitFixedPointRadixTwo_value (listDyadicDenominator p)
    (listDyadicTwiddleFunction (radixModulusDigits depth) depth.length p) depth.length A
  simpa only [listDyadicDenominator_value,listDyadicTwiddleFunction_value,dyadicRadixDFT] using h

theorem listCyclicConvolution_eq (depth : List Bool) (p : ℕ)
    (A B : Vector BitFourierInteger (2^depth.length)) :
    (listCyclicConvolution depth p (List.ofFn A.get) (List.ofFn B.get)).map BitFourierInteger.value=
      List.ofFn (dyadicCyclicConvolution depth.length p (bitFourierVectorValue A) (bitFourierVectorValue B)).get := by
  let T := listDyadicTwiddleFunction (radixModulusDigits depth) depth.length p
  let D := listDyadicDenominator p
  let FA := bitFixedPointRadixTwo D T depth.length A
  let FB := bitFixedPointRadixTwo D T depth.length B
  let P := Vector.ofFn (fun j => bitFourierMul (FA.get j) (FB.get j))
  have ha := storedDyadicArray_value depth p A
  have hb := storedDyadicArray_value depth p B
  have hp : bitFourierVectorValue P=Vector.ofFn (fun j =>
      (dyadicRadixDFT depth.length p (bitFourierVectorValue A)).get j*
      (dyadicRadixDFT depth.length p (bitFourierVectorValue B)).get j) := by
    apply Vector.ext
    intro i hi
    have hae := congrArg (fun V => V.get ⟨i,hi⟩) ha
    have hbe := congrArg (fun V => V.get ⟨i,hi⟩) hb
    simp only [bitFourierVectorValue,vector_get_ofFn] at hae hbe
    change (Vector.ofFn _).get ⟨i,hi⟩=(Vector.ofFn _).get ⟨i,hi⟩
    simp only [bitFourierVectorValue,vector_get_ofFn,P,bitFourierMul_value]
    exact congrArg₂ (·*·) hae hbe
  have hpsource : List.zipWith bitFourierMul (List.ofFn FA.get) (List.ofFn FB.get)=List.ofFn P.get := by
    rw [fourierList_zipWith_ofFn]
    apply congrArg List.ofFn
    funext j
    simp only [P,vector_get_ofFn]
  rw [listCyclicConvolution,listDyadicTransform_storage,listDyadicTransform_storage]
  change (listCyclicReflect (listDyadicTransform depth p
    (List.zipWith bitFourierMul (List.ofFn FA.get) (List.ofFn FB.get)))).map BitFourierInteger.value=_
  rw [hpsource,listCyclicReflect_map,listDyadicTransform_eq,hp,listCyclicReflect_ofFn]
  apply congrArg List.ofFn
  funext k
  simp only [dyadicCyclicConvolution,fixedPointCyclicConvolution,dyadicRadixDFT,vector_get_ofFn]

end Optss
