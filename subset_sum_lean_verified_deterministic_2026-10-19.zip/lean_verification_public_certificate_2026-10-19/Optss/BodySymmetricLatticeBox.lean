import Optss.BooleanVertexSymmetrization
import Optss.LatticeBoxOutputSize

/-!
# Lemma 3.A with symmetry of the polytope itself

The executable wrapper first copies the vertex list and its negative. For
an origin-symmetric input body this preserves its convex hull, regardless
of whether the supplied generating list was already closed under negation.
The output basis, positive integer widths, uniform lattice count, work, and
literal output-description bit bound refer to this same returned result.
-/
namespace Optss
open scoped Pointwise
variable {r m : ℕ}

def bodySymmetricLatticeBox (V : ListBitRationalMatrixData r m)
    (G : ListBitRationalMatrixData r r) : Option (BooleanLatticeBoxResult r) :=
  booleanLatticeBox (symmetricStoredVertices V) G

def bodySymmetricLatticeBoxWork (V : ListBitRationalMatrixData r m)
    (G : ListBitRationalMatrixData r r) : ℕ :=
  symmetricStoredVerticesWork V+booleanLatticeBoxWork (symmetricStoredVertices V) G+1

noncomputable def bodySymmetricLatticeBoxPolynomial (r : ℕ) : Polynomial ℕ :=
  vertexSymmetrizationPolynomial+(booleanLatticeBoxPolynomial r).comp (2*Polynomial.X)+1

noncomputable def bodySymmetricLatticeBoxOutputSize (r : ℕ) : Polynomial ℕ :=
  (booleanLatticeBoxOutputSize r).comp (2*Polynomial.X)

theorem symmetricStoredVertices_span (V : ListBitRationalMatrixData r m)
    (hspan : Submodule.span ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))=⊤) :
    Submodule.span ℝ (rationalVertexSet (storedRationalVertices (symmetricStoredVertices V)) : Set (Fin r → ℝ))=⊤ := by
  apply top_unique
  rw [←hspan]
  apply Submodule.span_mono
  intro x hx
  exact (mem_symmetricVertexSet V x).mpr (Or.inl hx)

theorem bodySymmetricLatticeBoxWork_input_polynomial (hr : 0<r)
    (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetG : (storedRationalMatrix G).det≠0)
    (hspan : Submodule.span ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))=⊤) :
    bodySymmetricLatticeBoxWork V G≤(bodySymmetricLatticeBoxPolynomial r).eval
      (listStoredRationalBits V+listStoredRationalBits G) := by
  have hs := symmetricStoredVerticesWork_input_polynomial hr V
  have hb := booleanLatticeBoxWork_input_polynomial hr (symmetricStoredVertices V) G
    (symmetricStoredVertices_wellFormed V hV) hG hdetG (symmetricStoredVertices_span V hspan)
  have hsize := symmetricStoredVertices_bits V
  have hn : listStoredRationalBits (symmetricStoredVertices V)+listStoredRationalBits G≤
      2*(listStoredRationalBits V+listStoredRationalBits G) := by omega
  have hs' := hs.trans (natPolynomial_eval_mono vertexSymmetrizationPolynomial (Nat.le_add_right (listStoredRationalBits V) (listStoredRationalBits G)))
  have hb' := hb.trans (natPolynomial_eval_mono (booleanLatticeBoxPolynomial r) hn)
  simpa only [bodySymmetricLatticeBoxWork,bodySymmetricLatticeBoxPolynomial,
    Polynomial.eval_add,Polynomial.eval_comp,Polynomial.eval_mul,Polynomial.eval_ofNat,
    Polynomial.eval_X,Polynomial.eval_one] using Nat.add_le_add_right (Nat.add_le_add hs' hb') 1

theorem bodySymmetricLatticeBox_output_bits
    (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetG : (storedRationalMatrix G).det≠0)
    (hspan : Submodule.span ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))=⊤)
    (box : BooleanLatticeBoxResult r) (hbox : bodySymmetricLatticeBox V G=some box) :
    latticeBoxOutputBits box≤(bodySymmetricLatticeBoxOutputSize r).eval
      (listStoredRationalBits V+listStoredRationalBits G) := by
  have hb := booleanLatticeBox_output_bits (symmetricStoredVertices V) G
    (symmetricStoredVertices_wellFormed V hV) hG hdetG (symmetricStoredVertices_span V hspan) box hbox
  have hsize := symmetricStoredVertices_bits V
  have hn : listStoredRationalBits (symmetricStoredVertices V)+listStoredRationalBits G≤
      2*(listStoredRationalBits V+listStoredRationalBits G) := by omega
  simpa only [bodySymmetricLatticeBoxOutputSize,Polynomial.eval_comp,Polynomial.eval_mul,
    Polynomial.eval_ofNat,Polynomial.eval_X] using hb.trans (natPolynomial_eval_mono (booleanLatticeBoxOutputSize r) hn)

/-- The literal geometric hypotheses of Lemma 3.A, with a concrete Boolean
and list-storage implementation and explicit fixed-rank input/output polynomials. -/
theorem bodySymmetricLatticeBox_spec (hr : 0<r)
    (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetG : (storedRationalMatrix G).det≠0)
    (hsym : ∀ y∈storedVertexHull V,-y∈storedVertexHull V)
    (x : Fin r → (Fin r → ℝ)) (hind : LinearIndependent ℝ x)
    (hxK : ∀ i,x i∈storedVertexHull V)
    (hxΛ : ∀ i,x i∈Submodule.span ℤ (Set.range (fun j i => (storedRationalMatrix G i j:ℝ)))) :
    bodySymmetricLatticeBoxWork V G≤(bodySymmetricLatticeBoxPolynomial r).eval
      (listStoredRationalBits V+listStoredRationalBits G) ∧
    ∃ box,bodySymmetricLatticeBox V G=some box ∧
      latticeBoxOutputBits box≤(bodySymmetricLatticeBoxOutputSize r).eval
        (listStoredRationalBits V+listStoredRationalBits G) ∧
      ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
        (∀ i j,(storedRationalMatrix box.columns i j:ℝ)=b j i) ∧
        basisIntegerLattice b=(Submodule.span ℤ (Set.range (fun j i => (storedRationalMatrix G i j:ℝ))) : Set _) ∧
        (∀ j,BitListCanonical (box.widths.toVector.get j)) ∧
        (∀ j,1≤decodedLatticeBoxWidths box j) ∧
        storedVertexHull V ⊆basisCoefficientBox b (decodedLatticeBoxWidths box) ∧
        basisCoefficientBox b (decodedLatticeBoxWidths box) ⊆
          latticeBoxingDilation r ((r.factorial:ℝ)*sharpLatticeDefectBound r) •storedVertexHull V ∧
        ∀ s : ℝ,(basisLatticePoints b (s •basisCoefficientBox b (decodedLatticeBoxWidths box))
            ((basisCoefficientBox_compact b _).smul s)).card≤
          (latticeBoxingResidueModulus r (sharpLatticeDefectBound r))^r*
            (basisLatticePoints b (s •storedVertexHull V) ((storedVertexHull_compact V).smul s)).card := by
  have hspan := vertices_span_of_independent_hull (Pi.basisFun ℝ (Fin r))
    (rationalVertexSet (storedRationalVertices V)) x hind hxK
  have hwork := bodySymmetricLatticeBoxWork_input_polynomial hr V G hV hG hdetG hspan
  have heq := symmetricStoredVertices_hull V hsym
  obtain ⟨box,hbox,b,hcols,hΛ,hcan,hpos,hinner,houter,hcount⟩ := booleanLatticeBox_spec hr
    (symmetricStoredVertices V) G (symmetricStoredVertices_wellFormed V hV) hG hdetG
    (symmetricStoredVertices_closed_neg V) x hind (by simpa only [heq] using hxK) hxΛ
  refine ⟨hwork,box,hbox,bodySymmetricLatticeBox_output_bits V G hV hG hdetG hspan box hbox,
    b,hcols,hΛ,hcan,hpos,?_,?_,?_⟩
  · simpa only [heq] using hinner
  · simpa only [heq] using houter
  · intro s
    simpa only [heq] using hcount s
end Optss
