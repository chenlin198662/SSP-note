import Optss.BitListDivision
import Optss.BinaryGcd

/-!
# Euclidean gcd on Boolean lists

Each recursive step performs two verified Boolean-list divisions. A separate
bit-list fuel loses one cell after the two remainders; the first operand's
canonical bit list supplies sufficient fuel by the proved halving argument.
Only emptiness tests choose branches of the answer computation.
-/

namespace Optss

/-- Canonical little-endian representation; zero is exactly the empty list. -/
def BitListCanonical (xs : List Bool) : Prop := xs = (binaryDigitsValue xs).bits

theorem bitListTrim_canonical (xs : List Bool) : BitListCanonical (bitListTrim xs) := by
  exact (bitListTrim_eq_bits xs).trans (congrArg Nat.bits (bitListTrim_value xs).symm)

theorem BitListCanonical.length {xs : List Bool} (hx : BitListCanonical xs) :
    xs.length = (binaryDigitsValue xs).size := by
  rw [show xs = (binaryDigitsValue xs).bits from hx, ← Nat.size_eq_bits_len, binaryDigitsValue_bits]

theorem BitListCanonical.pos_of_not_empty {xs : List Bool} (hx : BitListCanonical xs)
    (hne : xs.isEmpty ≠ true) : 0 < binaryDigitsValue xs := by
  by_contra h
  have hz : binaryDigitsValue xs = 0 := by omega
  have he : xs = [] := by simpa [BitListCanonical, hz] using hx
  simp [he] at hne

/-- Two-division Euclidean recursion with explicit list fuel. Fuel values are
irrelevant: only its tail is used, so no natural subtraction controls recursion. -/
def bitListGcdFuel : List Bool → List Bool → List Bool → List Bool
  | [], _, bs => bs
  | _::fuel, as, bs =>
    if as.isEmpty then bs else
      let first := bitListDivision bs as
      if first.remainder.isEmpty then as else
        let second := bitListDivision as first.remainder
        bitListGcdFuel fuel second.remainder first.remainder

/-- The public routine trims inputs and uses the first canonical operand as
its explicit fuel. All answer arithmetic is performed by Boolean-list division. -/
def bitListGcd (xs ys : List Bool) : List Bool :=
  let as := bitListTrim xs
  let bs := bitListTrim ys
  bitListGcdFuel as as bs

/-- Exact canonical gcd with enough list fuel. The two-step remainder lemma
proves that each recursion decreases the required fuel length. -/
theorem bitListGcdFuel_correct (fuel as bs : List Bool)
    (ha : BitListCanonical as) (hb : BitListCanonical bs) (hf : as.length ≤ fuel.length) :
    bitListGcdFuel fuel as bs = (Nat.gcd (binaryDigitsValue as) (binaryDigitsValue bs)).bits := by
  induction fuel generalizing as bs with
  | nil =>
    have he : as = [] := List.length_eq_zero_iff.mp (by simpa using hf)
    subst as
    simpa only [bitListGcdFuel, binaryDigitsValue, Nat.gcd_zero_left] using hb
  | cons b fuel ih =>
    rw [bitListGcdFuel]
    dsimp only
    split_ifs with haz hrz
    · have he : as = [] := List.isEmpty_iff.mp haz
      subst as
      simpa only [binaryDigitsValue, Nat.gcd_zero_left] using hb
    · have hap := ha.pos_of_not_empty haz
      have he := (bitListDivision_correct bs as hap).2
      have hr0 : binaryDigitsValue (bitListDivision bs as).remainder = 0 := by
        rw [List.isEmpty_iff.mp hrz]
        rfl
      have hm : binaryDigitsValue bs % binaryDigitsValue as = 0 := by omega
      have hg : Nat.gcd (binaryDigitsValue as) (binaryDigitsValue bs) = binaryDigitsValue as := by
        rw [Nat.gcd_rec, hm, Nat.gcd_zero_left]
      rw [hg]
      exact ha
    · let rs := (bitListDivision bs as).remainder
      let ss := (bitListDivision as rs).remainder
      have hap := ha.pos_of_not_empty haz
      have hre : binaryDigitsValue rs = binaryDigitsValue bs % binaryDigitsValue as :=
        (bitListDivision_correct bs as hap).2
      have hrc : BitListCanonical rs := by
        change rs = (binaryDigitsValue rs).bits
        rw [hre]
        exact (bitListDivision_encodings bs as hap).2
      have hrp : 0 < binaryDigitsValue rs := hrc.pos_of_not_empty hrz
      have hral : binaryDigitsValue rs < binaryDigitsValue as := hre ▸ Nat.mod_lt _ hap
      have hse : binaryDigitsValue ss = binaryDigitsValue as % binaryDigitsValue rs :=
        (bitListDivision_correct as rs hrp).2
      have hsc : BitListCanonical ss := by
        change ss = (binaryDigitsValue ss).bits
        rw [hse]
        exact (bitListDivision_encodings as rs hrp).2
      have hsize := remainder_bits_lt (binaryDigitsValue as) (binaryDigitsValue rs) hrp hral
      have hsf : ss.length ≤ fuel.length := by
        rw [hsc.length, hse]
        rw [ha.length, List.length_cons] at hf
        omega
      change bitListGcdFuel fuel ss rs = _
      rw [ih ss rs hsc hrc hsf]
      congr 1
      rw [Nat.gcd_rec (binaryDigitsValue as) (binaryDigitsValue bs), ← hre,
        Nat.gcd_rec (binaryDigitsValue rs) (binaryDigitsValue as), ← hse]

theorem bitListGcd_eq_bits (xs ys : List Bool) :
    bitListGcd xs ys = (Nat.gcd (binaryDigitsValue xs) (binaryDigitsValue ys)).bits := by
  unfold bitListGcd
  rw [bitListGcdFuel_correct _ _ _ (bitListTrim_canonical _) (bitListTrim_canonical _) le_rfl,
    bitListTrim_value, bitListTrim_value]

theorem bitListGcd_correct (xs ys : List Bool) :
    binaryDigitsValue (bitListGcd xs ys) = Nat.gcd (binaryDigitsValue xs) (binaryDigitsValue ys) := by
  rw [bitListGcd_eq_bits, binaryDigitsValue_bits]

theorem bitListGcd_canonical (xs ys : List Bool) : BitListCanonical (bitListGcd xs ys) := by
  change bitListGcd xs ys = (binaryDigitsValue (bitListGcd xs ys)).bits
  rw [bitListGcd_correct, bitListGcd_eq_bits]

/-- Sum of the already verified division circuit and traversal counts,
including public quotient trimming. -/
def bitListDivisionCost (ns ds : List Bool) : ℕ :=
  bitListDivisionGates ds ns + bitListDivisionVisits ds ns +
    bitListTrimVisits (bitListDivisionDigits ds ns).quotient

theorem bitListDivisionCost_bound (ns ds : List Bool) (hd : 0 < binaryDigitsValue ds) :
    bitListDivisionCost ns ds ≤ ns.length*(10*ds.length+15)+2 := by
  have hg := bitListDivisionGates_bound ns ds hd
  have hv := bitListDivisionVisits_bound ns ds hd
  unfold bitListDivisionCost
  nlinarith

theorem bitListDivisionCost_uniform (ns ds : List Bool) (hd : 0 < binaryDigitsValue ds)
    (L : ℕ) (hn : ns.length ≤ L) (hds : ds.length ≤ L) :
    bitListDivisionCost ns ds ≤ 25*(L+1)^2 := by
  have hb := bitListDivisionCost_bound ns ds hd
  have hm : ns.length*(10*ds.length+15) ≤ L*(10*L+15) :=
    Nat.mul_le_mul hn (by omega)
  nlinarith

/-- Cost semantics for the answer recursion, summing the actual Boolean-list
division costs and the control-cell tests. Evaluation of this specification
counter is not part of the uninstrumented answer algorithm. -/
def bitListGcdFuelCost : List Bool → List Bool → List Bool → ℕ
  | [], _, _ => 1
  | _::fuel, as, bs =>
    if as.isEmpty then 2 else
      let first := bitListDivision bs as
      if first.remainder.isEmpty then 3+bitListDivisionCost bs as else
        let second := bitListDivision as first.remainder
        3+bitListDivisionCost bs as+bitListDivisionCost as first.remainder+
          bitListGcdFuelCost fuel second.remainder first.remainder

/-- All recursive operands retain the original common bit bound, giving a
quadratic charge per fuel cell and a cubic bound with canonical initial fuel. -/
theorem bitListGcdFuelCost_bound (fuel as bs : List Bool)
    (ha : BitListCanonical as) (hb : BitListCanonical bs)
    (L : ℕ) (hal : as.length ≤ L) (hbl : bs.length ≤ L) :
    bitListGcdFuelCost fuel as bs ≤ 1+53*fuel.length*(L+1)^2 := by
  induction fuel generalizing as bs with
  | nil => simp [bitListGcdFuelCost]
  | cons b fuel ih =>
    rw [bitListGcdFuelCost]
    dsimp only
    split_ifs with haz hrz
    · simp only [List.length_cons]
      nlinarith [show 1 ≤ (L+1)^2 by nlinarith]
    · have hap := ha.pos_of_not_empty haz
      have hc := bitListDivisionCost_uniform bs as hap L hbl hal
      simp only [List.length_cons]
      nlinarith [show 1 ≤ (L+1)^2 by nlinarith]
    · let rs := (bitListDivision bs as).remainder
      let ss := (bitListDivision as rs).remainder
      have hap := ha.pos_of_not_empty haz
      have hre : binaryDigitsValue rs = binaryDigitsValue bs % binaryDigitsValue as :=
        (bitListDivision_correct bs as hap).2
      have hrc : BitListCanonical rs := by
        change rs = (binaryDigitsValue rs).bits
        rw [hre]
        exact (bitListDivision_encodings bs as hap).2
      have hrp : 0 < binaryDigitsValue rs := hrc.pos_of_not_empty hrz
      have hse : binaryDigitsValue ss = binaryDigitsValue as % binaryDigitsValue rs :=
        (bitListDivision_correct as rs hrp).2
      have hsc : BitListCanonical ss := by
        change ss = (binaryDigitsValue ss).bits
        rw [hse]
        exact (bitListDivision_encodings as rs hrp).2
      have hrl : rs.length ≤ L := by
        rw [hrc.length, hre]
        exact (Nat.size_le_size (Nat.mod_lt _ hap).le).trans (ha.length ▸ hal)
      have hsl : ss.length ≤ L := by
        rw [hsc.length, hse]
        exact (Nat.size_le_size (Nat.mod_lt _ hrp).le).trans (hrc.length ▸ hrl)
      have hi := ih ss rs hsc hrc hsl hrl
      have hc1 := bitListDivisionCost_uniform bs as hap L hbl hal
      have hc2 := bitListDivisionCost_uniform as rs hrp L hal hrl
      change 3+bitListDivisionCost bs as+bitListDivisionCost as rs+
        bitListGcdFuelCost fuel ss rs ≤ _
      simp only [List.length_cons]
      nlinarith [show 1 ≤ (L+1)^2 by nlinarith]

/-- Public gcd cost includes the two initial canonicalization traversals. -/
def bitListGcdCost (xs ys : List Bool) : ℕ :=
  bitListTrimVisits xs+bitListTrimVisits ys+
    bitListGcdFuelCost (bitListTrim xs) (bitListTrim xs) (bitListTrim ys)

theorem bitListGcdCost_bound (xs ys : List Bool) (L : ℕ)
    (hx : xs.length ≤ L) (hy : ys.length ≤ L) :
    bitListGcdCost xs ys ≤ 56*(L+1)^3 := by
  have hxt := (bitListTrim_length_le xs).trans hx
  have hyt := (bitListTrim_length_le ys).trans hy
  have hc := bitListGcdFuelCost_bound (bitListTrim xs) (bitListTrim xs) (bitListTrim ys)
    (bitListTrim_canonical _) (bitListTrim_canonical _) L hxt hyt
  have hm := Nat.mul_le_mul_right ((L+1)^2) (Nat.mul_le_mul_left 53 hxt)
  unfold bitListGcdCost
  rw [bitListTrimVisits_eq, bitListTrimVisits_eq]
  nlinarith [show 1 ≤ (L+1)^2 by nlinarith]

/-- Canonical encodings give the actual gcd together with a cubic bound in
input magnitude bits; input encoding itself is separate. -/
theorem bitListGcd_bits (a b : ℕ) :
    bitListGcd a.bits b.bits = (a.gcd b).bits ∧
      bitListGcdCost a.bits b.bits ≤ 56*(max a.size b.size+1)^3 := by
  constructor
  · simpa only [binaryDigitsValue_bits] using bitListGcd_eq_bits a.bits b.bits
  · apply bitListGcdCost_bound
    · simpa only [Nat.size_eq_bits_len] using le_max_left a.size b.size
    · simpa only [Nat.size_eq_bits_len] using le_max_right a.size b.size

/-- Canonical division operands allow reuse of the concrete refinement of the
older binary-division width charge. -/
theorem bitListDivisionCost_refines (ns ds : List Bool)
    (hn : BitListCanonical ns) (hdc : BitListCanonical ds) (hd : 0 < binaryDigitsValue ds) :
    bitListDivisionCost ns ds ≤
      2*(binaryLongDivision (binaryDigitsValue ns) (binaryDigitsValue ds)).widthWork+2 := by
  have h := bitListDivision_refines_widthWork (binaryDigitsValue ns) (binaryDigitsValue ds) hd
  change bitListDivisionCost (binaryDigitsValue ns).bits (binaryDigitsValue ds).bits ≤ _ at h
  simpa only [← (show ns = (binaryDigitsValue ns).bits from hn),
    ← (show ds = (binaryDigitsValue ds).bits from hdc)] using h

theorem bitListDivision_remainder_canonical (ns ds : List Bool)
    (hd : 0 < binaryDigitsValue ds) : BitListCanonical (bitListDivision ns ds).remainder := by
  change (bitListDivision ns ds).remainder = (binaryDigitsValue (bitListDivision ns ds).remainder).bits
  rw [(bitListDivision_correct ns ds hd).2]
  exact (bitListDivision_encodings ns ds hd).2

/-- The exact Boolean gcd recursion refines the older gcd width charge with
a factor of two and at most seven additional control/terminal visits per fuel
cell. This connects the two cost analyses without assuming a bit-cost oracle. -/
theorem bitListGcdFuelCost_refines_widthWork (fuel as bs : List Bool)
    (ha : BitListCanonical as) (hb : BitListCanonical bs) :
    bitListGcdFuelCost fuel as bs ≤
      2*(binaryGcdFuel fuel.length (binaryDigitsValue as) (binaryDigitsValue bs)).widthWork+
        7*fuel.length+1 := by
  induction fuel generalizing as bs with
  | nil => simp [bitListGcdFuelCost, binaryGcdFuel]
  | cons b fuel ih =>
    rw [bitListGcdFuelCost]
    dsimp only
    split_ifs with haz hrz
    · have he : as = [] := List.isEmpty_iff.mp haz
      simp [he, binaryDigitsValue, binaryGcdFuel]
      omega
    · have hap := ha.pos_of_not_empty haz
      have hv := (bitListDivision_correct bs as hap).2
      have hz : binaryDigitsValue (bitListDivision bs as).remainder = 0 := by
        rw [List.isEmpty_iff.mp hrz]; rfl
      have hm : (binaryLongDivision (binaryDigitsValue bs) (binaryDigitsValue as)).remainder = 0 := by
        rw [(binaryLongDivision_correct _ _ hap).2]
        omega
      have hc := bitListDivisionCost_refines bs as hb ha hap
      simp only [List.length_cons, binaryGcdFuel, ne_of_gt hap, ↓reduceIte, hm] 
      omega
    · let rs := (bitListDivision bs as).remainder
      let ss := (bitListDivision as rs).remainder
      have hap := ha.pos_of_not_empty haz
      have hrc : BitListCanonical rs := bitListDivision_remainder_canonical bs as hap
      have hrp := hrc.pos_of_not_empty hrz
      have hsc : BitListCanonical ss := bitListDivision_remainder_canonical as rs hrp
      have hre : binaryDigitsValue rs =
          (binaryLongDivision (binaryDigitsValue bs) (binaryDigitsValue as)).remainder :=
        (bitListDivision_correct bs as hap).2.trans (binaryLongDivision_correct _ _ hap).2.symm
      have hse : binaryDigitsValue ss =
          (binaryLongDivision (binaryDigitsValue as) (binaryDigitsValue rs)).remainder :=
        (bitListDivision_correct as rs hrp).2.trans (binaryLongDivision_correct _ _ hrp).2.symm
      have hrn : (binaryLongDivision (binaryDigitsValue bs) (binaryDigitsValue as)).remainder ≠ 0 := by
        rw [← hre]
        exact ne_of_gt hrp
      have hc1 := bitListDivisionCost_refines bs as hb ha hap
      have hc2 := bitListDivisionCost_refines as rs ha hrc hrp
      have hi := ih ss rs hsc hrc
      rw [hse, hre] at hi
      rw [hre] at hc2
      change 3+bitListDivisionCost bs as+bitListDivisionCost as rs+bitListGcdFuelCost fuel ss rs ≤ _
      simp only [List.length_cons, binaryGcdFuel, ne_of_gt hap, hrn, ↓reduceIte]
      omega

/-- Including initial trims, Boolean gcd refines the public arithmetic gcd
charge with only linear additional input/fuel overhead. -/
theorem bitListGcdCost_refines_binaryGcd (a b : ℕ) :
    bitListGcdCost a.bits b.bits ≤ 2*(binaryGcd a b).widthWork+8*a.size+b.size+3 := by
  have ha : BitListCanonical a.bits := by simp [BitListCanonical, binaryDigitsValue_bits]
  have hb : BitListCanonical b.bits := by simp [BitListCanonical, binaryDigitsValue_bits]
  have h := bitListGcdFuelCost_refines_widthWork a.bits a.bits b.bits ha hb
  have hta : bitListTrim a.bits = a.bits := by rw [bitListTrim_eq_bits, binaryDigitsValue_bits]
  have htb : bitListTrim b.bits = b.bits := by rw [bitListTrim_eq_bits, binaryDigitsValue_bits]
  unfold bitListGcdCost
  rw [hta, htb, bitListTrimVisits_eq, bitListTrimVisits_eq]
  simp only [binaryDigitsValue_bits] at h
  simp only [Nat.size_eq_bits_len] at h ⊢
  change bitListGcdFuelCost a.bits a.bits b.bits ≤ 2*(binaryGcd a b).widthWork+7*a.size+1 at h
  omega

end Optss
