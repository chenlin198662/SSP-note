import Optss.ListStoredRationalMatrix

/-!
# Constructing the finite determinant expressions with counted control

This builder returns both the actual expression and its construction charge.
Minor-column decisions use the concrete Boolean bounded-index comparison.
Charges count generated expression/list records, structural index enumeration,
and copied bounded indices; the latter receive a conservative linear charge
in their dimension. This is the same source-operation convention used by the
list-array evaluator, not a statement about a particular compiled allocator.
The bounds are dimension constants and do not depend on scalar input heights.
-/
namespace Optss
open scoped BigOperators

/-- Boolean implementation of the column-skipping map in a matrix minor. -/
def bitFinSkip {n : ℕ} (j : Fin (n+1)) (k : Fin n) : Fin (n+1) :=
  if bitIndexLE j k.castSucc then k.succ else k.castSucc

theorem bitFinSkip_eq {n : ℕ} (j : Fin (n+1)) (k : Fin n) : bitFinSkip j k=j.succAbove k := by
  unfold bitFinSkip
  split_ifs with h
  · exact (Fin.succAbove_of_le_castSucc j k ((bitIndexLE_correct j k.castSucc).mp h)).symm
  · have hk : k.castSucc<j := by
      have hh : ¬j.val≤k.castSucc.val := by simpa only [bitIndexLE_correct] using h
      exact Nat.lt_of_not_ge hh
    exact (Fin.succAbove_of_castSucc_lt j k hk).symm

def bitFinSkipWork {n : ℕ} (j : Fin (n+1)) (k : Fin n) : ℕ :=
  bitIndexLEWork j k.castSucc+2*(n+2)+1

/-- Uniform charge for forming both indices and querying a minor-cell getter. -/
def minorIndexWorkBound (n : ℕ) : ℕ := 64*(2*n+3)^2+4*(n+2)+8

theorem bitFinSkipWork_le {n : ℕ} (j : Fin (n+1)) (k : Fin n) :
    bitFinSkipWork j k+2*(n+2)+3≤minorIndexWorkBound n := by
  have h := bitIndexLEWork_le j k.castSucc
  simp only [bitFinSkipWork,minorIndexWorkBound]
  have he : n+1+(n+1)+1=2*n+3 := by omega
  rw [he] at h
  omega

namespace RationalExpression
variable {ι : Type*}

/-- The sum constructor traverses the actual list of already-built terms. -/
def buildSum : List (RationalExpression ι × ℕ) → RationalExpression ι × ℕ
  | [] => (.zero,1)
  | p::ps =>
      let tail := buildSum ps
      (.binary .add p.1 tail.1,p.2+tail.2+3)

theorem buildSum_value (ps : List (RationalExpression ι × ℕ)) :
    (buildSum ps).1=sum (ps.map Prod.fst) := by
  induction ps <;> simp_all [buildSum,sum]

theorem buildSum_work (ps : List (RationalExpression ι × ℕ)) :
    (buildSum ps).2=1+(ps.map (fun p => p.2+3)).sum := by
  induction ps <;> simp_all [buildSum]
  omega

/-- A source-level builder with an instrumented finite cell getter. All
concrete getters below have their construction charge proved explicitly. -/
def buildDeterminant : (n : ℕ) →
    Matrix (Fin n) (Fin n) (RationalExpression ι × ℕ) → RationalExpression ι × ℕ
  | 0,_ => (.one,1)
  | n+1,A =>
      let terms := List.ofFn fun j : Fin (n+1) =>
        let entry := A 0 j
        let minor := buildDeterminant n (fun i k =>
          let cell := A i.succ (bitFinSkip j k)
          (cell.1,cell.2+bitFinSkipWork j k+2*(n+2)+3))
        (.binary .mul (sign j.val) (.binary .mul entry.1 minor.1),
          entry.2+(j.val+1)+minor.2+2)
      let result := buildSum terms
      (result.1,listIndexEnumerationWork (n+1)+result.2+2)

theorem buildDeterminant_value (n : ℕ)
    (A : Matrix (Fin n) (Fin n) (RationalExpression ι × ℕ)) :
    (buildDeterminant n A).1=determinant n (fun i j => (A i j).1) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [buildDeterminant,buildSum_value,List.map_ofFn,determinant,Function.comp_apply,ih]
    congr 1
    apply congrArg List.ofFn
    funext j
    simp only [Function.comp_apply,bitFinSkip_eq]
    rfl

/-- Fixed-dimension construction bound, including all nested minor-index work. -/
def determinantBuildBound : ℕ → ℕ → ℕ
  | 0,_ => 1
  | n+1,W => 32*(n+2)^3+
      (n+1)*(W+n+determinantBuildBound n (W+minorIndexWorkBound n)+6)+3

theorem buildDeterminant_work_le (n W : ℕ)
    (A : Matrix (Fin n) (Fin n) (RationalExpression ι × ℕ))
    (hA : ∀ i j,(A i j).2≤W) :
    (buildDeterminant n A).2≤determinantBuildBound n W := by
  induction n generalizing W with
  | zero => rfl
  | succ n ih =>
    simp only [buildDeterminant,buildSum_work,List.map_ofFn,List.sum_ofFn,Function.comp_apply]
    unfold determinantBuildBound
    have he := listIndexEnumerationWork_le (n+1)
    have hs : (∑ j : Fin (n+1),
        ((A 0 j).2+(j.val+1)+
          (buildDeterminant n (fun i k =>
            ((A i.succ (bitFinSkip j k)).1,
             (A i.succ (bitFinSkip j k)).2+bitFinSkipWork j k+2*(n+2)+3))).2+2+3))≤
        (n+1)*(W+n+determinantBuildBound n (W+minorIndexWorkBound n)+6) := by
      calc
        _ ≤ ∑ _j : Fin (n+1),(W+n+determinantBuildBound n (W+minorIndexWorkBound n)+6) := by
          apply Finset.sum_le_sum
          intro j _
          have hsub := ih (W+minorIndexWorkBound n)
            (fun i k => ((A i.succ (bitFinSkip j k)).1,
              (A i.succ (bitFinSkip j k)).2+bitFinSkipWork j k+2*(n+2)+3))
            (by
              intro i k
              have ha := hA i.succ (bitFinSkip j k)
              have hk := bitFinSkipWork_le j k
              dsimp only
              omega)
          have ha := hA 0 j
          have hj := j.isLt
          omega
        _ = _ := by simp
    have heen : n+1+1=n+2 := by omega
    rw [heen] at he
    omega
end RationalExpression

/-- Creation of a literal input-address expression, including its copied indices. -/
def matrixInputExpression {r : ℕ} (i j : Fin r) : RationalExpression (Fin r × Fin r) × ℕ :=
  (.input (i,j),4*(r+1)+1)

/-- Both equality tests are actual Boolean index operations. -/
def matrixCofactorInputExpression {r : ℕ} (i j k l : Fin r) :
    RationalExpression (Fin r × Fin r) × ℕ :=
  let row := bitIndexEQ k j
  let col := bitIndexEQ l i
  (if row then if col then .one else .zero else .input (k,l),
    bitIndexEQWork k j+bitIndexEQWork l i+4*(r+1)+3)

def cofactorInputBuildBound (r : ℕ) : ℕ := 258*(2*r+1)^2+4*(r+1)+3

theorem matrixCofactorInputExpression_value {r : ℕ} (i j k l : Fin r) :
    (matrixCofactorInputExpression i j k l).1=
      (if k=j then if l=i then .one else .zero else .input (k,l) : RationalExpression (Fin r × Fin r)) := by
  simp only [matrixCofactorInputExpression,bitIndexEQ_correct,Fin.val_inj]

theorem matrixCofactorInputExpression_work_le {r : ℕ} (i j k l : Fin r) :
    (matrixCofactorInputExpression i j k l).2≤cofactorInputBuildBound r := by
  have hk := bitIndexEQWork_le k j
  have hl := bitIndexEQWork_le l i
  simp only [matrixCofactorInputExpression,cofactorInputBuildBound]
  have he : r+r+1=2*r+1 := by omega
  rw [he] at hk hl
  omega

def buildMatrixDeterminantExpression (r : ℕ) : RationalExpression (Fin r × Fin r) × ℕ :=
  RationalExpression.buildDeterminant r matrixInputExpression

def buildMatrixInverseExpression (r : ℕ) (i j : Fin r) : RationalExpression (Fin r × Fin r) × ℕ :=
  let numerator := RationalExpression.buildDeterminant r (matrixCofactorInputExpression i j)
  let denominator := buildMatrixDeterminantExpression r
  (.binary .div numerator.1 denominator.1,numerator.2+denominator.2+1)

theorem buildMatrixDeterminantExpression_value (r : ℕ) :
    (buildMatrixDeterminantExpression r).1=rationalMatrixDeterminantExpression r := by
  rw [buildMatrixDeterminantExpression,RationalExpression.buildDeterminant_value]
  rfl

theorem buildMatrixInverseExpression_value (r : ℕ) (i j : Fin r) :
    (buildMatrixInverseExpression r i j).1=rationalMatrixInverseExpression r i j := by
  simp only [buildMatrixInverseExpression,RationalExpression.buildDeterminant_value,
    matrixCofactorInputExpression_value,buildMatrixDeterminantExpression_value,
    rationalMatrixInverseExpression]

theorem buildMatrixDeterminantExpression_work_le (r : ℕ) :
    (buildMatrixDeterminantExpression r).2≤RationalExpression.determinantBuildBound r (4*(r+1)+1) :=
  RationalExpression.buildDeterminant_work_le r _ _ (fun _ _ => le_rfl)

theorem buildMatrixInverseExpression_work_le (r : ℕ) (i j : Fin r) :
    (buildMatrixInverseExpression r i j).2≤
      RationalExpression.determinantBuildBound r (cofactorInputBuildBound r)+
      RationalExpression.determinantBuildBound r (4*(r+1)+1)+1 := by
  have hn := RationalExpression.buildDeterminant_work_le r (cofactorInputBuildBound r)
    (matrixCofactorInputExpression i j) (matrixCofactorInputExpression_work_le i j)
  have hd := buildMatrixDeterminantExpression_work_le r
  exact Nat.add_le_add_right (Nat.add_le_add hn hd) 1
end Optss
