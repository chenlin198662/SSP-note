import Optss.ComputedBasisWidths

/-!
# Transposing rational matrices through physical list reads

Each output cell is obtained from the Boolean addressed matrix reader and
copied into a materialized output list. This connects the column convention
for geometric bases with the row convention of the reduction routine.
-/
namespace Optss
open scoped BigOperators
variable {r d : ℕ}

def listStoredMatrixTranspose (A : ListBitRationalMatrixData r d) : ListBitRationalMatrixData d r :=
  BooleanListArray.ofFn fun j => BooleanListArray.ofFn fun i => listMatrixRead listCopyFraction A i j

def listStoredMatrixTransposeWork (A : ListBitRationalMatrixData r d) : ℕ :=
  matrixProductAllocationWork d r+∑ j : Fin d,∑ i : Fin r,listMatrixReadWork listCopyFraction listCopyFractionWork A i j

theorem listStoredMatrixTranspose_entry (A : ListBitRationalMatrixData r d) (j : Fin d) (i : Fin r) :
    rectangularListFractionMatrix (listStoredMatrixTranspose A) j i=rectangularListFractionMatrix A i j := by
  simp only [rectangularListFractionMatrix,listStoredMatrixTranspose,listMatrixVector_ofFn,
    BooleanListArray.ofFn_toVector]
  simp [Vector.get,listMatrixRead_eq listCopyFraction listCopyFraction_eq]

theorem listStoredMatrixTranspose_wellFormed (A : ListBitRationalMatrixData r d)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed) :
    ∀ i j,(rectangularListFractionMatrix (listStoredMatrixTranspose A) i j).WellFormed := by
  intro i j
  rw [listStoredMatrixTranspose_entry]
  exact hA j i

theorem listStoredMatrixTranspose_square_bits (A : ListBitRationalMatrixData r r) :
    listStoredRationalBits (listStoredMatrixTranspose A)=listStoredRationalBits A := by
  rw [listStoredRationalBits_eq,listStoredRationalBits_eq]
  unfold bitRationalMatrixSize
  apply congrArg (fun n : ℕ => r+(r*r+n))
  change (∑ i : Fin r,∑ j : Fin r,
    ((rectangularListFractionMatrix (listStoredMatrixTranspose A) i j).numerator.length+
      (rectangularListFractionMatrix (listStoredMatrixTranspose A) i j).denominator.length))=
    (∑ i : Fin r,∑ j : Fin r,
    ((rectangularListFractionMatrix A i j).numerator.length+
      (rectangularListFractionMatrix A i j).denominator.length))
  simp only [listStoredMatrixTranspose_entry]
  rw [Finset.sum_comm]

theorem listStoredMatrixTransposeWork_bound (A : ListBitRationalMatrixData r d) (L : ℕ)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).numerator.length≤L ∧
      (rectangularListFractionMatrix A i j).denominator.length≤L) :
    listStoredMatrixTransposeWork A≤matrixProductAllocationWork d r+
      d*r*listStorageFactor r d*(2*L+1) := by
  unfold listStoredMatrixTransposeWork
  apply Nat.add_le_add_left
  calc
    _ ≤ ∑ _j : Fin d,∑ _i : Fin r,listStorageFactor r d*(2*L+1) := by
      apply Finset.sum_le_sum
      intro j _
      apply Finset.sum_le_sum
      intro i _
      apply listFractionReadWork_le A i j (2*L)
      intro k l
      have h := hA k l
      unfold fractionPayload
      change (rectangularListFractionMatrix A k l).numerator.length+
        (rectangularListFractionMatrix A k l).denominator.length≤_
      omega
    _ = _ := by simp; ring

noncomputable def matrixTransposePolynomial (r d : ℕ) : Polynomial ℕ :=
  Polynomial.C (matrixProductAllocationWork d r)+Polynomial.C (d*r*listStorageFactor r d)*(2*Polynomial.X+1)

theorem listStoredMatrixTransposeWork_input_polynomial (A : ListBitRationalMatrixData r d) :
    listStoredMatrixTransposeWork A≤(matrixTransposePolynomial r d).eval (listStoredRationalBits A) := by
  simpa only [matrixTransposePolynomial,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat] using
    listStoredMatrixTransposeWork_bound A (listStoredRationalBits A) (listStoredRationalBits_cell A)
end Optss
