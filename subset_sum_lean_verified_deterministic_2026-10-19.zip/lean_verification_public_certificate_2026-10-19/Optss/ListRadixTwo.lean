import Optss.BooleanRadixTwo

/-! A radix-two answer routine using only sequential list splitting,
concatenation and zipped butterflies. Native array access occurs solely in
the specification theorem, not in the answer definition. -/
namespace Optss

/-- Read each input cell once and split the two parity classes. -/
def fourierListSplit {α : Type*} : List α → List α × List α
  | [] => ([],[])
  | [a] => ([a],[])
  | a::b::xs =>
    let p := fourierListSplit xs
    (a::p.1,b::p.2)

theorem fourierListSplit_get {α : Type*} (xs : List α) (i : ℕ) :
    (fourierListSplit xs).1[i]?=xs[2*i]? ∧
      (fourierListSplit xs).2[i]?=xs[2*i+1]? := by
  match xs with
  | [] => simp [fourierListSplit]
  | [a] => cases i <;> simp [fourierListSplit,Nat.mul_add]
  | a::b::xs =>
    cases i with
    | zero => simp [fourierListSplit]
    | succ i =>
      have h := fourierListSplit_get xs i
      simpa only [fourierListSplit,Nat.mul_add,Nat.mul_one,Nat.add_assoc,
        List.getElem?_cons_succ] using h
termination_by xs.length

theorem fourierListSplit_ofFn {α : Type*} (n : ℕ) (A : Vector α (2^(n+1))) :
    fourierListSplit (List.ofFn A.get)=
      (List.ofFn (radixEvenData n A).get,List.ofFn (radixOddData n A).get) := by
  apply Prod.ext
  · apply List.ext_getElem?
    intro i
    rw [(fourierListSplit_get _ i).1]
    simp only [List.getElem?_ofFn]
    by_cases h : i<2^n
    · have h2 : 2*i<2^(n+1) := by rw [pow_succ]; omega
      simp only [h,h2,↓reduceDIte,radixEvenData,vector_get_ofFn,radixEvenIndex]
    · have h2 : ¬2*i<2^(n+1) := by rw [pow_succ]; omega
      simp only [h,h2,↓reduceDIte]
  · apply List.ext_getElem?
    intro i
    rw [(fourierListSplit_get _ i).2]
    simp only [List.getElem?_ofFn]
    by_cases h : i<2^n
    · have h2 : 2*i+1<2^(n+1) := by rw [pow_succ]; omega
      simp only [h,h2,↓reduceDIte,radixOddData,vector_get_ofFn,radixOddIndex]
    · have h2 : ¬2*i+1<2^(n+1) := by rw [pow_succ]; omega
      simp only [h,h2,↓reduceDIte]

theorem fourierList_double_ofFn {α : Type*} (n : ℕ) (A : Vector α (2^n)) :
    List.ofFn A.get++List.ofFn A.get=List.ofFn (fun k : Fin (2^(n+1)) => A.get (radixModIndex n k)) := by
  have h := List.ofFn_fin_repeat A.get 2
  simp only [List.replicate_succ,List.replicate_zero,List.flatten_cons,List.flatten_nil,
    List.append_nil] at h
  rw [← h]
  apply List.ext_getElem?
  intro i
  simp only [List.getElem?_ofFn]
  have hpow : 2*(2^n)=2^(n+1) := by rw [pow_succ]; omega
  by_cases hi : i<2^(n+1)
  · have hi' : i<2*2^n := by omega
    simp only [hi,hi',↓reduceDIte,Fin.repeat,Fin.modNat,radixModIndex]
  · have hi' : ¬i<2*2^n := by omega
    simp only [hi,hi',↓reduceDIte]

theorem fourierList_zipWith_ofFn {α β γ : Type*} {m : ℕ}
    (f : α → β → γ) (a : Fin m → α) (b : Fin m → β) :
    List.zipWith f (List.ofFn a) (List.ofFn b)=List.ofFn (fun j => f (a j) (b j)) := by
  apply List.ext_getElem?
  intro i
  simp only [List.getElem?_zipWith,List.getElem?_ofFn]
  by_cases hi : i < m <;> simp [hi]

/-- The stored twiddle rows are consumed from the largest level downward. -/
def radixTwiddleLists (T : ℕ → ℕ → BitFourierInteger) : ℕ → List (List BitFourierInteger)
  | 0 => []
  | n+1 => List.ofFn (fun k : Fin (2^(n+1)) => T n k.val)::radixTwiddleLists T n

def listBitRadixTwo (D : BitListInteger) :
    List (List BitFourierInteger) → List BitFourierInteger → List BitFourierInteger
  | [],A => A
  | t::ts,A =>
    let p := fourierListSplit A
    let E := listBitRadixTwo D ts p.1
    let O := listBitRadixTwo D ts p.2
    List.zipWith (fun eo w => bitFourierButterfly D eo.1 w eo.2)
      (List.zip (E++E) (O++O)) t

theorem listBitRadixTwo_eq (D : BitListInteger) (T : ℕ → ℕ → BitFourierInteger)
    (n : ℕ) (A : Vector BitFourierInteger (2^n)) :
    listBitRadixTwo D (radixTwiddleLists T n) (List.ofFn A.get)=
      List.ofFn (bitFixedPointRadixTwo D T n A).get := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [radixTwiddleLists,listBitRadixTwo,fourierListSplit_ofFn]
    dsimp only
    rw [ih,ih,fourierList_double_ofFn,fourierList_double_ofFn]
    change List.zipWith _ (List.zipWith Prod.mk _ _) _=_
    rw [fourierList_zipWith_ofFn,fourierList_zipWith_ofFn]
    apply congrArg List.ofFn
    funext k
    simp only [bitFixedPointRadixTwo,vector_get_ofFn]

end Optss
