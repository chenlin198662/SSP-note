import Optss.ExecutableVertexWidths
import Optss.ConstructedMatrixWork

/-!
# Boolean maximum and ceiling scans for finite vertex widths

The maximum scan compares actual normalized Boolean-list fractions and copies
absolute-value payloads. Natural ceiling uses signed Boolean floor of the
negation and returns a canonical natural bit word. Value and work proofs
cover empty scans, zero, negative rationals, and either stored sign of zero.
-/
namespace Optss

/-- Absolute value, with explicit copies of both magnitude fields. -/
def bitFractionAbs (p : BitListFraction) : BitListFraction :=
  let q := listCopyFraction p
  ⟨false,q.numerator,q.denominator⟩

def bitFractionAbsWork (p : BitListFraction) : ℕ := listCopyFractionWork p+1

theorem bitFractionAbs_wellFormed (p : BitListFraction) (hp : p.WellFormed) :
    (bitFractionAbs p).WellFormed := by
  simpa only [bitFractionAbs,listCopyFraction_eq,BitListFraction.WellFormed] using hp

theorem bitFractionAbs_value (p : BitListFraction) :
    bitListFractionValue (bitFractionAbs p)=|bitListFractionValue p| := by
  simp only [bitFractionAbs,listCopyFraction_eq,bitListFractionValue,signedBitsValue,
    Bool.false_eq_true,↓reduceIte]
  rw [abs_div]
  split_ifs <;> simp

def booleanAbsoluteMaximum : List BitListFraction → BitListFraction
  | [] => bitListFractionZero
  | p::ps =>
      let value := bitFractionAbs p
      let tail := booleanAbsoluteMaximum ps
      if bitListFractionLE value tail then tail else value

def booleanAbsoluteMaximumWork : List BitListFraction → ℕ
  | [] => 3
  | p::ps =>
      let value := bitFractionAbs p
      let tail := booleanAbsoluteMaximum ps
      bitFractionAbsWork p+booleanAbsoluteMaximumWork ps+bitListFractionLECost value tail+4

theorem booleanAbsoluteMaximum_wellFormed (ps : List BitListFraction)
    (hp : ∀ p∈ps,p.WellFormed) : (booleanAbsoluteMaximum ps).WellFormed := by
  induction ps with
  | nil => exact bitListFractionZero_wellFormed
  | cons p ps ih =>
    have hv := bitFractionAbs_wellFormed p (hp p (List.mem_cons_self))
    have ht := ih (fun q hq => hp q (List.mem_cons_of_mem _ hq))
    simp only [booleanAbsoluteMaximum]
    split_ifs <;> assumption

theorem booleanAbsoluteMaximum_value (ps : List BitListFraction)
    (hp : ∀ p∈ps,p.WellFormed) :
    bitListFractionValue (booleanAbsoluteMaximum ps)=
      rationalMaximum (ps.map fun p => |bitListFractionValue p|) := by
  induction ps with
  | nil => exact bitListFractionZero_value
  | cons p ps ih =>
    have hp' := hp p (List.mem_cons_self)
    have htail := fun q hq => hp q (List.mem_cons_of_mem p hq)
    have hv := bitFractionAbs_wellFormed p hp'
    have ht := booleanAbsoluteMaximum_wellFormed ps htail
    have he := bitListFractionLE_correct _ _ hv.2.2.1 ht.2.2.1
    simp only [booleanAbsoluteMaximum,List.map_cons,rationalMaximum]
    split_ifs with hc
    · have hc' := he.mp hc
      rw [bitFractionAbs_value,ih htail] at hc'
      rw [ih htail,max_eq_right hc']
    · have hc' : bitListFractionValue (booleanAbsoluteMaximum ps)≤
          bitListFractionValue (bitFractionAbs p) := le_of_not_ge (fun hh => hc (he.mpr hh))
      rw [bitFractionAbs_value,ih htail] at hc'
      rw [bitFractionAbs_value,max_eq_left hc']

theorem booleanAbsoluteMaximum_lengths (ps : List BitListFraction) (L : ℕ) (hL : 0<L)
    (hbits : ∀ p∈ps,p.numerator.length≤L ∧ p.denominator.length≤L) :
    (booleanAbsoluteMaximum ps).numerator.length≤L ∧
      (booleanAbsoluteMaximum ps).denominator.length≤L := by
  induction ps with
  | nil => simpa [booleanAbsoluteMaximum,bitListFractionZero] using hL
  | cons p ps ih =>
    have hp := hbits p (List.mem_cons_self)
    have ht := ih (fun q hq => hbits q (List.mem_cons_of_mem _ hq))
    simp only [booleanAbsoluteMaximum]
    split_ifs
    · exact ht
    · simpa only [bitFractionAbs,listCopyFraction_eq] using hp

theorem booleanAbsoluteMaximumWork_bound (ps : List BitListFraction) (L : ℕ) (hL : 0<L)
    (hbits : ∀ p∈ps,p.numerator.length≤L ∧ p.denominator.length≤L) :
    booleanAbsoluteMaximumWork ps≤(ps.length+1)*512*(L+1)^2 := by
  induction ps with
  | nil => simp only [booleanAbsoluteMaximumWork,List.length_nil]; nlinarith
  | cons p ps ih =>
    have hp := hbits p (List.mem_cons_self)
    have hb := fun q hq => hbits q (List.mem_cons_of_mem p hq)
    have ht := booleanAbsoluteMaximum_lengths ps L hL hb
    have ha : (bitFractionAbs p).numerator.length≤L ∧ (bitFractionAbs p).denominator.length≤L := by
      simpa only [bitFractionAbs,listCopyFraction_eq] using hp
    have hc := bitListFractionLECost_bound _ _ L ha ht
    have hw := ih hb
    simp only [booleanAbsoluteMaximumWork,bitFractionAbsWork,listCopyFractionWork_eq,
      fractionPayload,List.length_cons]
    nlinarith

/-- Natural ceiling is the nonnegative magnitude of minus floor of minus the input. -/
def bitFractionNatCeil (p : BitListFraction) : List Bool :=
  let out := bitListFractionFloor (bitListFractionNeg (listCopyFraction p))
  if out.1 then bitWordCopy out.2 else []

def bitFractionNatCeilWork (p : BitListFraction) : ℕ :=
  let q := bitListFractionNeg (listCopyFraction p)
  let out := bitListFractionFloor q
  listCopyFractionWork p+bitListFractionFloorCost q+
    (if out.1 then bitWordCopyWork out.2 else 1)+3

theorem bitFractionNatCeil_value (p : BitListFraction)
    (hp : 0<binaryDigitsValue p.denominator) :
    binaryDigitsValue (bitFractionNatCeil p)=⌈bitListFractionValue p⌉₊ := by
  have hn : 0<binaryDigitsValue (bitListFractionNeg (listCopyFraction p)).denominator := by
    simpa [listCopyFraction_eq,bitListFractionNeg] using hp
  have hf := bitListFractionFloor_correct (bitListFractionNeg (listCopyFraction p)) hn
  rw [bitListFractionNeg_correct,listCopyFraction_eq,Int.floor_neg] at hf
  have hc : ⌈bitListFractionValue p⌉=
      -signedBitsValue (bitListFractionFloor (bitListFractionNeg p)).1
        (bitListFractionFloor (bitListFractionNeg p)).2 := by omega
  rw [← Int.ceil_toNat,hc]
  simp only [bitFractionNatCeil,listCopyFraction_eq]
  split_ifs with hs <;> simp [signedBitsValue,hs,bitWordCopy_eq,binaryDigitsValue]

theorem bitListFractionFloor_canonical (p : BitListFraction)
    (hp : 0<binaryDigitsValue p.denominator) : BitListCanonical (bitListFractionFloor p).2 := by
  have hq : BitListCanonical (bitListDivision p.numerator p.denominator).quotient := by
    rw [(bitListDivision_encodings _ _ hp).1]
    simp [BitListCanonical,binaryDigitsValue_bits]
  unfold bitListFractionFloor
  dsimp only
  split_ifs <;> try exact hq
  exact bitListTrim_canonical _

theorem bitFractionNatCeil_canonical (p : BitListFraction)
    (hp : 0<binaryDigitsValue p.denominator) : BitListCanonical (bitFractionNatCeil p) := by
  have hn : 0<binaryDigitsValue (bitListFractionNeg (listCopyFraction p)).denominator := by
    simpa [listCopyFraction_eq,bitListFractionNeg] using hp
  unfold bitFractionNatCeil
  dsimp only
  split_ifs
  · rw [bitWordCopy_eq]
    exact bitListFractionFloor_canonical _ hn
  · simp [BitListCanonical,binaryDigitsValue]

theorem bitFractionNatCeil_length (p : BitListFraction) (hp : p.WellFormed) :
    (bitFractionNatCeil p).length≤p.numerator.length := by
  have hval : (bitListFractionValue p).num.natAbs.size=p.numerator.length := by
    rw [← p.toRat_value hp]
    change (signedBitsValue p.negative p.numerator).natAbs.size=p.numerator.length
    rw [signedBitsValue_natAbs]
    exact hp.1.length.symm
  rw [(bitFractionNatCeil_canonical p hp.2.2.1).length,bitFractionNatCeil_value p hp.2.2.1]
  exact (Nat.size_le_size (rationalNatCeil_le_num _)).trans_eq hval

theorem bitListFractionFloor_length (p : BitListFraction) :
    (bitListFractionFloor p).2.length≤p.numerator.length+2 := by
  have hq := bitListDivision_quotient_length_le p.numerator p.denominator
  have ha := bitListAddAux_length (bitListDivision p.numerator p.denominator).quotient [true] false
  simp only [List.length_cons,List.length_nil] at ha
  unfold bitListFractionFloor
  dsimp only
  split_ifs
  · exact hq.trans (by omega)
  · change (bitListTrim (bitListAddAux false _ _)).length≤_
    exact (bitListTrim_length_le _).trans (ha.trans (by omega))
  · exact hq.trans (by omega)

theorem bitFractionNatCeilWork_bound (p : BitListFraction)
    (hp : 0<binaryDigitsValue p.denominator) (L : ℕ)
    (hbits : p.numerator.length≤L ∧ p.denominator.length≤L) :
    bitFractionNatCeilWork p≤128*(L+1)^2 := by
  have hn : 0<binaryDigitsValue (bitListFractionNeg (listCopyFraction p)).denominator := by
    simpa [listCopyFraction_eq,bitListFractionNeg] using hp
  have hb : (bitListFractionNeg (listCopyFraction p)).numerator.length≤L ∧
      (bitListFractionNeg (listCopyFraction p)).denominator.length≤L := by
    simpa [listCopyFraction_eq,bitListFractionNeg] using hbits
  have hf := bitListFractionFloorCost_bound _ hn L hb
  have hl := (bitListFractionFloor_length (bitListFractionNeg (listCopyFraction p))).trans
    (Nat.add_le_add_right hb.1 2)
  unfold bitFractionNatCeilWork
  dsimp only
  split_ifs <;> simp only [listCopyFractionWork_eq,fractionPayload,bitWordCopyWork_eq] <;> nlinarith
/-- The actual finite scan-and-ceiling backend for one coefficient width. -/
def booleanVertexWidth (ps : List BitListFraction) : List Bool :=
  bitFractionNatCeil (booleanAbsoluteMaximum ps)

def booleanVertexWidthWork (ps : List BitListFraction) : ℕ :=
  booleanAbsoluteMaximumWork ps+bitFractionNatCeilWork (booleanAbsoluteMaximum ps)+1

theorem booleanVertexWidth_value (ps : List BitListFraction)
    (hp : ∀ p∈ps,p.WellFormed) :
    binaryDigitsValue (booleanVertexWidth ps)=
      ⌈rationalMaximum (ps.map fun p => |bitListFractionValue p|)⌉₊ := by
  rw [booleanVertexWidth,bitFractionNatCeil_value _
    (booleanAbsoluteMaximum_wellFormed ps hp).2.2.1,booleanAbsoluteMaximum_value ps hp]

theorem booleanVertexWidth_canonical (ps : List BitListFraction)
    (hp : ∀ p∈ps,p.WellFormed) : BitListCanonical (booleanVertexWidth ps) :=
  bitFractionNatCeil_canonical _ (booleanAbsoluteMaximum_wellFormed ps hp).2.2.1

theorem booleanVertexWidth_length (ps : List BitListFraction)
    (hp : ∀ p∈ps,p.WellFormed) (L : ℕ) (hL : 0<L)
    (hbits : ∀ p∈ps,p.numerator.length≤L ∧ p.denominator.length≤L) :
    (booleanVertexWidth ps).length≤L :=
  (bitFractionNatCeil_length _ (booleanAbsoluteMaximum_wellFormed ps hp)).trans
    (booleanAbsoluteMaximum_lengths ps L hL hbits).1

theorem booleanVertexWidthWork_bound (ps : List BitListFraction)
    (hp : ∀ p∈ps,p.WellFormed) (L : ℕ) (hL : 0<L)
    (hbits : ∀ p∈ps,p.numerator.length≤L ∧ p.denominator.length≤L) :
    booleanVertexWidthWork ps≤(ps.length+2)*1024*(L+1)^2 := by
  have hm := booleanAbsoluteMaximumWork_bound ps L hL hbits
  have hc := bitFractionNatCeilWork_bound _ (booleanAbsoluteMaximum_wellFormed ps hp).2.2.1
    L (booleanAbsoluteMaximum_lengths ps L hL hbits)
  unfold booleanVertexWidthWork
  nlinarith

/-- Exact bridge for a row of actual rational-coordinate evaluations. -/
theorem booleanVertexWidth_coordinate_value {r m : ℕ}
    (M : Matrix (Fin r) (Fin r) ℚ) (V : Fin m → Fin r → ℚ)
    (C : Fin m → BitListFraction) (hC : ∀ i,(C i).WellFormed) (j : Fin r)
    (hvalue : ∀ i,bitListFractionValue (C i)=(M.mulVec (V i)) j) :
    binaryDigitsValue (booleanVertexWidth (List.ofFn C))=rationalVertexWidth M V j := by
  rw [booleanVertexWidth_value _ (by
    intro q hq; obtain ⟨i,rfl⟩ := List.mem_ofFn.mp hq; exact hC i)]
  simp only [List.map_ofFn,Function.comp_def,hvalue,rationalVertexWidth,rationalVertexRadius]

end Optss
