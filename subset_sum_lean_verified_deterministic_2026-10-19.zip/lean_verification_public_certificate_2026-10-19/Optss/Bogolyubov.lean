import Optss.CyclicConvolutionSupport

/-!
# Finite cyclic Bogolyubov lemma

For nonempty A in ZMod N, an explicit Bohr neighborhood of at most
2(N/|A|)^2 frequencies lies in (A+A)-(A+A). The proof uses the natural
representation count and counting-measure Fourier normalization.
-/
namespace Optss
noncomputable section
open scoped BigOperators Pointwise
variable {N : ℕ} [NeZero N]

def cyclicFourierEnergy (A : Finset (ZMod N)) (k : ZMod N) : ℝ :=
  Complex.normSq (ZMod.dft (cyclicIndicator A) k)

def cyclicLargeSpectrum (A : Finset (ZMod N)) (q : ℝ) : Finset (ZMod N) :=
  Finset.univ.filter fun k => q≤cyclicFourierEnergy A k

/-- The finite set of frequencies is retained as an explicit parameter for
later lattice-coordinate extraction. -/
def cyclicBohrSet (S : Finset (ZMod N)) : Set (ZMod N) :=
  {x | ∀ k∈S, ‖ZMod.stdAddChar (k*x)-1‖≤1}

theorem cyclicFourierEnergy_nonneg (A : Finset (ZMod N)) (k : ZMod N) :
    0≤cyclicFourierEnergy A k := Complex.normSq_nonneg _

theorem cyclicFourierEnergy_zero (A : Finset (ZMod N)) :
    cyclicFourierEnergy A 0 = (A.card : ℝ)^2 := by
  simp only [cyclicFourierEnergy,cyclicIndicator_dft_zero,Complex.normSq_natCast,pow_two]

theorem cyclicFourierEnergy_sum (A : Finset (ZMod N)) :
    ∑ k, cyclicFourierEnergy A k = (N : ℝ)*A.card := cyclicIndicator_parseval A

theorem cyclicQuadrupleCount_fourier_re (A : Finset (ZMod N)) (x : ZMod N) :
    (N : ℝ)*(cyclicQuadrupleCount A x : ℝ) =
      ∑ k, (ZMod.stdAddChar (k*x)).re * cyclicFourierEnergy A k ^ 2 := by
  have h := congrArg Complex.re (cyclicQuadrupleCount_fourier A x)
  simpa only [← Complex.ofReal_pow,Complex.re_sum,Complex.mul_re,
    Complex.natCast_re,Complex.natCast_im,Complex.ofReal_re,Complex.ofReal_im,
    mul_zero,sub_zero,cyclicFourierEnergy] using h

theorem cyclicLargeSpectrum_card_mul (A : Finset (ZMod N)) (q : ℝ) :
    (cyclicLargeSpectrum A q).card*q ≤ (N : ℝ)*A.card := by
  have h₁ : (cyclicLargeSpectrum A q).card*q ≤ ∑ k∈cyclicLargeSpectrum A q, cyclicFourierEnergy A k := by
    calc
      _ = ∑ _k∈cyclicLargeSpectrum A q, q := by simp
      _ ≤ _ := Finset.sum_le_sum (fun k hk => (Finset.mem_filter.mp hk).2)
  have h₂ : (∑ k∈cyclicLargeSpectrum A q, cyclicFourierEnergy A k) ≤ ∑ k, cyclicFourierEnergy A k :=
    Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) (fun k _ _ => cyclicFourierEnergy_nonneg A k)
  rw [← cyclicFourierEnergy_sum]
  exact h₁.trans h₂

theorem cyclicBohrSet_re_nonneg (S : Finset (ZMod N)) (x : ZMod N)
    (hx : x∈cyclicBohrSet S) (k : ZMod N) (hk : k∈S) :
    0≤(ZMod.stdAddChar (k*x)).re := by
  have h := Complex.re_le_norm (1-ZMod.stdAddChar (k*x))
  have hnorm : ‖1-ZMod.stdAddChar (k*x)‖≤1 := by rw [norm_sub_rev]; exact hx k hk
  simp only [Complex.sub_re,Complex.one_re] at h
  linarith

theorem cyclicCharacter_re_lower (x : ZMod N) : -1≤(ZMod.stdAddChar x).re := by
  have h := Complex.abs_re_le_norm (ZMod.stdAddChar x)
  rw [AddChar.norm_apply] at h
  exact (abs_le.mp h).1

/-- The zero frequency gives |A|^4; all small frequencies together lose at
most q N |A|, while the Bohr condition makes large-frequency terms nonnegative. -/
theorem cyclicBohr_representation_lower (A : Finset (ZMod N)) (q : ℝ) (hq : 0≤q)
    (x : ZMod N) (hx : x∈cyclicBohrSet (cyclicLargeSpectrum A q)) :
    (A.card : ℝ)^4-q*(N*A.card) ≤ (N : ℝ)*(cyclicQuadrupleCount A x : ℝ) := by
  have hp (k : ZMod N) : (if k=0 then (A.card : ℝ)^4 else 0)-q*cyclicFourierEnergy A k ≤
      (ZMod.stdAddChar (k*x)).re*cyclicFourierEnergy A k^2 := by
    have he := cyclicFourierEnergy_nonneg A k
    by_cases hk : k=0
    · subst k
      simp only [ite_true,zero_mul,AddChar.map_zero_eq_one,Complex.one_re,one_mul,cyclicFourierEnergy_zero]
      nlinarith [sq_nonneg (A.card : ℝ)]
    · simp only [hk,↓reduceIte,zero_sub]
      by_cases hs : k∈cyclicLargeSpectrum A q
      · have hc := cyclicBohrSet_re_nonneg _ x hx k hs
        have hterm := mul_nonneg hc (sq_nonneg (cyclicFourierEnergy A k))
        nlinarith
      · have heq : cyclicFourierEnergy A k<q := by simpa [cyclicLargeSpectrum] using hs
        have hc := cyclicCharacter_re_lower (k*x)
        have hm := mul_le_mul_of_nonneg_right hc (sq_nonneg (cyclicFourierEnergy A k))
        nlinarith
  have hsum := Finset.sum_le_sum (fun k (_ : k∈(Finset.univ : Finset (ZMod N))) => hp k)
  rw [← cyclicQuadrupleCount_fourier_re] at hsum
  simpa only [Finset.sum_sub_distrib,Finset.sum_ite_eq',Finset.mem_univ,↓reduceIte,
    ← Finset.mul_sum,cyclicFourierEnergy_sum] using hsum

def bogolyubovThreshold (A : Finset (ZMod N)) : ℝ := (A.card : ℝ)^3/(2*N)
def bogolyubovSpectrum (A : Finset (ZMod N)) : Finset (ZMod N) :=
  cyclicLargeSpectrum A (bogolyubovThreshold A)


theorem bogolyubovThreshold_pos (A : Finset (ZMod N)) (hA : A.Nonempty) :
    0<bogolyubovThreshold A := by
  have hm : 0<(A.card : ℝ) := Nat.cast_pos.mpr (Finset.card_pos.mpr hA)
  have hN : 0<(N : ℝ) := Nat.cast_pos.mpr (NeZero.pos N)
  unfold bogolyubovThreshold
  positivity

theorem bogolyubovSpectrum_card (A : Finset (ZMod N)) (hA : A.Nonempty) :
    ((bogolyubovSpectrum A).card : ℝ) ≤ 2*(N : ℝ)^2/(A.card : ℝ)^2 := by
  have hm : 0<(A.card : ℝ) := Nat.cast_pos.mpr (Finset.card_pos.mpr hA)
  have hN : 0<(N : ℝ) := Nat.cast_pos.mpr (NeZero.pos N)
  have hn : (N : ℝ)≠0 := ne_of_gt hN
  have h := cyclicLargeSpectrum_card_mul A (bogolyubovThreshold A)
  change (bogolyubovSpectrum A).card*bogolyubovThreshold A ≤ (N : ℝ)*A.card at h
  have h₂ : ((bogolyubovSpectrum A).card*(A.card : ℝ)^2)*(A.card : ℝ) ≤
      (2*(N : ℝ)^2)*(A.card : ℝ) := by
    calc
      _ = ((bogolyubovSpectrum A).card*bogolyubovThreshold A)*(2*(N : ℝ)) := by
        unfold bogolyubovThreshold
        field_simp
        ring
      _ ≤ ((N : ℝ)*A.card)*(2*N) := mul_le_mul_of_nonneg_right h (by positivity)
      _ = _ := by ring
  exact (le_div_iff₀ (sq_pos_of_pos hm)).mpr ((mul_le_mul_right hm).mp h₂)

/-- A quantitative version retaining a positive number of representations. -/
theorem bogolyubov_representation_lower (A : Finset (ZMod N)) (hA : A.Nonempty)
    (x : ZMod N) (hx : x∈cyclicBohrSet (bogolyubovSpectrum A)) :
    (A.card : ℝ)^4/2 ≤ (N : ℝ)*(cyclicQuadrupleCount A x : ℝ) := by
  have hN : 0<(N : ℝ) := Nat.cast_pos.mpr (NeZero.pos N)
  have hn : (N : ℝ)≠0 := ne_of_gt hN
  have h := cyclicBohr_representation_lower A (bogolyubovThreshold A)
    (bogolyubovThreshold_pos A hA).le x hx
  have he : (A.card : ℝ)^4-bogolyubovThreshold A*((N : ℝ)*A.card) = (A.card : ℝ)^4/2 := by
    unfold bogolyubovThreshold
    field_simp
    ring
  rwa [he] at h

/-- The finite cyclic Bogolyubov lemma, with an actual explicit spectrum. -/
theorem bogolyubov_subset_double_difference (A : Finset (ZMod N)) (hA : A.Nonempty) :
    cyclicBohrSet (bogolyubovSpectrum A) ⊆ (↑((A+A)-(A+A)) : Set (ZMod N)) := by
  intro x hx
  have hm : 0<(A.card : ℝ) := Nat.cast_pos.mpr (Finset.card_pos.mpr hA)
  have hN : 0<(N : ℝ) := Nat.cast_pos.mpr (NeZero.pos N)
  have hc : 0<(cyclicQuadrupleCount A x : ℝ) := by
    have h := bogolyubov_representation_lower A hA x hx
    have hp : 0<(A.card : ℝ)^4/2 := by positivity
    exact (mul_pos_iff_of_pos_left hN).mp (hp.trans_le h)
  exact (cyclicQuadrupleCount_pos_iff A x).mp (Nat.cast_pos.mp hc)

/-- An existential presentation, retaining the spectrum itself for subsequent
Bohr-to-lattice/progression arguments. -/
theorem finite_cyclic_bogolyubov (A : Finset (ZMod N)) (hA : A.Nonempty) :
    ∃ S : Finset (ZMod N), (S.card : ℝ) ≤ 2*(N : ℝ)^2/(A.card : ℝ)^2 ∧
      cyclicBohrSet S ⊆ (↑((A+A)-(A+A)) : Set (ZMod N)) :=
  ⟨bogolyubovSpectrum A,bogolyubovSpectrum_card A hA,bogolyubov_subset_double_difference A hA⟩

end
end Optss
