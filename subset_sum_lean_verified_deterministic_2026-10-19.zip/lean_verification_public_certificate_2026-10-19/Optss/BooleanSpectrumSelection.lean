import Optss.BooleanSpectrumWork
import Optss.ComputedSpectrumProgression

/-!
# Sequential spectrum selection on actual stored Fourier outputs

The scale and threshold are cached once. Indices and outputs are zipped and
filtered in sequential list passes, avoiding repeated indexed list reads.
The charge includes scalar Boolean work, list scans/constructors, and bounded
index word operations. Pointer encodings and compiler allocation are separate.
-/
namespace Optss
variable {N : ℕ} [NeZero N]

def bitSpectrumSelect (ns ms qs : List Bool) (values : List BitFourierInteger) : List (ZMod N) :=
  let scale := bitSpectrumScale ns
  let threshold := bitSpectrumThreshold ms qs
  (((List.finRange N).zip values).filter (fun pair => bitSpectrumKeep scale threshold pair.2)).map
    (fun pair => (pair.1.val:ZMod N))

def bitSpectrumSelectWork (N : ℕ) (ns ms qs : List Bool) (values : List BitFourierInteger) : ℕ :=
  let scale := bitSpectrumScale ns
  let threshold := bitSpectrumThreshold ms qs
  bitSpectrumThresholdWork ms qs+4+20*(N+values.length+1)+
    (values.map (bitSpectrumKeepWork scale threshold)).sum

theorem zip_finRange_ofFn {α : Type*} (f : Fin N→α) :
    (List.finRange N).zip (List.ofFn f)=(List.finRange N).map (fun i => (i,f i)) := by
  apply List.ext_getElem
  · simp
  · intro i hi hj
    simp

theorem bitSpectrumSelect_ofFn (ns ms qs : List Bool) (values : Fin N→BitFourierInteger) :
    bitSpectrumSelect ns ms qs (List.ofFn values)=
      ((List.finRange N).filter (fun k => bitSpectrumKeep (bitSpectrumScale ns)
        (bitSpectrumThreshold ms qs) (values k))).map (fun k => (k.val:ZMod N)) := by
  rw [bitSpectrumSelect,zip_finRange_ofFn,List.filter_map,List.map_map]
  rfl

theorem bitSpectrumSelect_eq (A : Finset (ZMod N)) (ns ms qs : List Bool)
    (hn : binaryDigitsValue ns=N) (hm : binaryDigitsValue ms=A.card)
    (hQ : binaryDigitsValue qs=dyadicDFTOutputDenominator N)
    (values : Fin N→BitFourierInteger)
    (hv : ∀ k,(values k).value=(canonicalDyadicDFT N
      (dyadicDFTPrecision (bluesteinPadExponent N)) (dyadicIndicatorData A)).get k) :
    bitSpectrumSelect ns ms qs (List.ofFn values)=dyadicSpectrumList A := by
  have hq : 0<binaryDigitsValue qs := by
    rw [hQ]
    unfold dyadicDFTOutputDenominator dyadicFourierDenominator
    positivity
  rw [bitSpectrumSelect_ofFn,dyadicSpectrumList]
  congr 1
  apply List.filter_congr
  intro k hk
  apply Bool.eq_iff_iff.mpr
  rw [bitSpectrumKeep_correct A ns ms qs hn hm hq,decide_eq_true_eq]
  rw [hv k,hQ]
  simp only [dyadicRationalDFT,vector_get_ofFn]

theorem bitSpectrumSelectWork_bound (ns ms qs : List Bool) (values : List BitFourierInteger)
    (hvalues : values.length=N) (L : ℕ) (hn : ns.length≤L) (hm : ms.length≤L) (hq : qs.length≤L)
    (hv : ∀ z∈values,z.Width L) :
    bitSpectrumSelectWork N ns ms qs values≤2100*(N+1)*(L+1)^2 := by
  have ht := bitSpectrumThresholdWork_bound ms qs L hm hq
  have hs := List.sum_le_card_nsmul
    (values.map (bitSpectrumKeepWork (bitSpectrumScale ns) (bitSpectrumThreshold ms qs)))
    (2000*(L+1)^2) (by
      intro w hw
      obtain ⟨z,hz,rfl⟩ := List.mem_map.mp hw
      exact bitSpectrumKeepWork_bound ns ms qs z L hn hm hq (hv z hz))
  simp only [List.length_map,hvalues,nsmul_eq_mul] at hs
  unfold bitSpectrumSelectWork
  rw [hvalues]
  nlinarith [show 1≤(L+1)^2 by nlinarith]

/-- List-valued transform implementations need only expose their exact
decoded output sequence; no additional pointwise approximation is assumed. -/
theorem bitSpectrumSelect_eq_of_values (A : Finset (ZMod N)) (ns ms qs : List Bool)
    (hn : binaryDigitsValue ns=N) (hm : binaryDigitsValue ms=A.card)
    (hQ : binaryDigitsValue qs=dyadicDFTOutputDenominator N)
    (values : List BitFourierInteger)
    (hv : values.map BitFourierInteger.value=List.ofFn
      (canonicalDyadicDFT N (dyadicDFTPrecision (bluesteinPadExponent N)) (dyadicIndicatorData A)).get) :
    bitSpectrumSelect ns ms qs values=dyadicSpectrumList A := by
  have hlen : values.length=N := by have h := congrArg List.length hv; simpa using h
  let V : BooleanListArray BitFourierInteger N := ⟨values,hlen⟩
  have hlist : values=List.ofFn V.toVector.get := booleanListArray_data_eq_ofFn V
  have hfn : (fun k => (V.toVector.get k).value)=
      (canonicalDyadicDFT N (dyadicDFTPrecision (bluesteinPadExponent N)) (dyadicIndicatorData A)).get := by
    apply List.ofFn_injective
    simpa only [hlist,List.map_ofFn,Function.comp_def] using hv
  rw [hlist]
  exact bitSpectrumSelect_eq A ns ms qs hn hm hQ V.toVector.get (congrFun hfn)
end Optss
