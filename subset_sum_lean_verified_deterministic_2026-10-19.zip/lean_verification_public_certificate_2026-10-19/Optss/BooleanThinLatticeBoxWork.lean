import Optss.BooleanThinLatticeBox
import Optss.BooleanLatticeBoxWork
import Optss.UniformFloorWidthWork

/-! Original-input polynomial work for the zero-allowing lattice-point box. -/
namespace Optss
variable {r m : ℕ}

theorem booleanThinLatticeBoxFinishWork_fromBasis (hr : 0<r)
    (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetA : (storedRationalMatrix A).det≠0) (hdetG : (storedRationalMatrix G).det≠0)
    (N : ℕ) (hN : listStoredRationalBits A+listStoredRationalBits V+listStoredRationalBits G≤N) :
    booleanThinLatticeBoxFinishWork V (booleanLatticeFrontendFromBasis A V G)≤(latticeBoxFinishPolynomial r).eval N := by
  let out := booleanLatticeFrontendFromBasis A V G
  let R := out.reducedLatticeRows
  let B := booleanLatticePullback A R
  let K := (latticePullbackInputSize r).eval N
  have hAn : listStoredRationalBits A≤N := by omega
  have hVn : listStoredRationalBits V≤N := by omega
  have hrN : r≤N := (listStoredRationalBits_rank A).trans hAn
  have hNK : N≤K := by simp only [K,latticePullbackInputSize,Polynomial.eval_add,Polynomial.eval_X]; omega
  have hR := (booleanLatticeFrontendFromBasis_wellFormed A V G hA hV hG hdetA hdetG).2.2.2
  have hRsize : listStoredRationalBits R≤(frontendReducedRowsSize r).eval N :=
    booleanLatticeFrontendFromBasis_reduced_bits A V G hA hG hdetA hdetG N (by omega)
  have hT := listStoredMatrixTranspose_wellFormed R hR
  have hTbits : listStoredRationalBits (listStoredMatrixTranspose R)=listStoredRationalBits R :=
    listStoredMatrixTranspose_square_bits R
  have hcombined : listStoredRationalBits A+listStoredRationalBits (listStoredMatrixTranspose R)≤K := by
    rw [hTbits]
    simp only [K,latticePullbackInputSize,Polynomial.eval_add,Polynomial.eval_X]
    exact Nat.add_le_add hAn hRsize
  have hB := constructedListMatrixMul_wellFormed A _ hA hT
  have hfieldsA : ∀ i j,(rectangularListFractionMatrix A i j).numerator.length≤K ∧
      (rectangularListFractionMatrix A i j).denominator.length≤K := by
    intro i j
    have h := listStoredRationalBits_cell A i j
    exact ⟨h.1.trans (hAn.trans hNK),h.2.trans (hAn.trans hNK)⟩
  have hfieldsT : ∀ i j,(rectangularListFractionMatrix (listStoredMatrixTranspose R) i j).numerator.length≤K ∧
      (rectangularListFractionMatrix (listStoredMatrixTranspose R) i j).denominator.length≤K := by
    intro i j
    have h := listStoredRationalBits_cell (listStoredMatrixTranspose R) i j
    exact ⟨h.1.trans (by omega),h.2.trans (by omega)⟩
  have hBsize : listStoredRationalBits B≤(latticePullbackOutputSize r).eval N := by
    have h := listStoredRationalBits_le_of_lengths B ((r+1)*(2*K+2))
      (constructedListMatrixMul_lengths A _ hA hT K hfieldsA hfieldsT)
    simp only [latticePullbackOutputSize,Polynomial.eval_add,Polynomial.eval_mul,
      Polynomial.eval_C,Polynomial.eval_one,Polynomial.eval_ofNat]
    change _≤r+r*r*(1+2*(r+1)*(2*K+2))
    convert h using 1; ring
  have hwt := (listStoredMatrixTransposeWork_input_polynomial R).trans
    (natPolynomial_eval_mono (matrixTransposePolynomial r r) hRsize)
  have hwp := constructedListMatrixMulWork_uniform A _ hA hT K
    (hrN.trans hNK) (hrN.trans hNK) (hrN.trans hNK) hcombined
  have hww := computedBasisFloorWidthsWork_fixed_rank hr B V hB hV
    ((latticePullbackOutputSize r).eval N+N) (Nat.add_le_add hBsize hVn)
  change listStoredMatrixTransposeWork R+constructedListMatrixMulWork A (listStoredMatrixTranspose R)+1+
    computedBasisFloorWidthsWork B V+1≤_
  simp only [latticeBoxFinishPolynomial,Polynomial.eval_add,Polynomial.eval_comp,
    Polynomial.eval_ofNat,Polynomial.eval_X]
  change _≤(matrixTransposePolynomial r r).eval ((frontendReducedRowsSize r).eval N)+
    uniformMatrixProductPolynomial.eval K+
    (fixedRankBasisWidthsPolynomial r).eval ((latticePullbackOutputSize r).eval N+N)+2
  omega

/-- Complete source-operation cost, with no supplied array, arithmetic,
intermediate-height, or lattice-reduction cost assumptions. -/
theorem booleanThinLatticeBoxWork_input_polynomial (hr : 0<r)
    (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetG : (storedRationalMatrix G).det≠0)
    (hspan : Submodule.span ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))=⊤) :
    booleanThinLatticeBoxWork V G≤(booleanLatticeBoxPolynomial r).eval
      (listStoredRationalBits V+listStoredRationalBits G) := by
  let N := listStoredRationalBits V+listStoredRationalBits G
  have hf := booleanLatticeFrontendWork_input_polynomial hr V G hV hG hdetG hspan
  change booleanLatticeFrontendWork V G≤(booleanLatticeFrontendPolynomial r).eval N at hf
  simp only [booleanLatticeBoxPolynomial,Polynomial.eval_add,Polynomial.eval_comp,
    Polynomial.eval_X,Polynomial.eval_one]
  change _≤(booleanLatticeFrontendPolynomial r).eval N+
    (latticeBoxFinishPolynomial r).eval ((selectedVertexMatrixSize r).eval N+N)+1
  unfold booleanThinLatticeBoxWork
  cases he : bitSelectedVertexMatrix V with
  | none =>
    have hout : booleanLatticeFrontend V G=none := by rw [booleanLatticeFrontend,he]; rfl
    rw [hout]
    change booleanLatticeFrontendWork V G+1≤_
    omega
  | some A =>
    have hout : booleanLatticeFrontend V G=some (booleanLatticeFrontendFromBasis A V G) := by
      rw [booleanLatticeFrontend,he]; rfl
    have hA := bitSelectedVertexMatrix_wellFormed V hV A he
    have hdetA := bitSelectedVertexMatrix_det_ne_zero V hV hspan A he
    have hb := bitSelectedVertexMatrix_lengths V N (by
      intro i j
      have h := listStoredRationalBits_cell V i j
      exact ⟨h.1.trans (by dsimp [N]; omega),h.2.trans (by dsimp [N]; omega)⟩) A he
    have hAsize : listStoredRationalBits A≤(selectedVertexMatrixSize r).eval N := by
      simpa only [selectedVertexMatrixSize,Polynomial.eval_add,Polynomial.eval_mul,
        Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat] using
        listStoredRationalBits_le_of_lengths A N hb
    have hw := booleanThinLatticeBoxFinishWork_fromBasis hr A V G hA hV hG hdetA hdetG
      ((selectedVertexMatrixSize r).eval N+N) (by
        rw [Nat.add_assoc]
        change listStoredRationalBits A+N≤(selectedVertexMatrixSize r).eval N+N
        exact Nat.add_le_add_right hAsize N)
    rw [hout]
    change booleanLatticeFrontendWork V G+(booleanThinLatticeBoxFinishWork V (booleanLatticeFrontendFromBasis A V G)+1)≤_
    exact (Nat.add_le_add hf (Nat.add_le_add_right hw 1)).trans (by omega)
end Optss
