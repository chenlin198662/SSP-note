import Optss.BooleanLatticeBoxWork

/-!
# Automatic symmetry of the stored generating vertex list

The routine appends a physically copied negative of every input vertex.
Symmetry of the convex body, rather than symmetry of the chosen generating
list, proves that this leaves the body unchanged.
-/
namespace Optss
open scoped BigOperators
variable {r m : ℕ}

def copyNegativeFraction (q : BitListFraction) : BitListFraction :=
  bitListFractionNeg (listCopyFraction q)

def symmetricVertexRow (row : BooleanListArray BitListFraction m) : BooleanListArray BitListFraction (m+m) :=
  ⟨row.data.map listCopyFraction++row.data.map copyNegativeFraction,by simp [row.length_eq]⟩

def symmetricVertexRowWork (row : BooleanListArray BitListFraction m) : ℕ :=
  (row.data.map listCopyFractionWork).sum+
    (row.data.map fun q => listCopyFractionWork q+1).sum+5*m+3

def symmetricStoredVertices (V : ListBitRationalMatrixData r m) : ListBitRationalMatrixData r (m+m) :=
  ⟨V.data.map symmetricVertexRow,by simp [V.length_eq]⟩

def symmetricStoredVerticesWork (V : ListBitRationalMatrixData r m) : ℕ :=
  2*r+1+(V.data.map symmetricVertexRowWork).sum

private theorem sym_get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i=f i := by
  change (Vector.ofFn f)[i.val]=f i
  simp

theorem symmetricVertexRow_eq (row : BooleanListArray BitListFraction m) :
    symmetricVertexRow row=BooleanListArray.ofFn
      (Fin.append (fun j => listCopyFraction (row.toVector.get j))
        (fun j => copyNegativeFraction (row.toVector.get j))) := by
  apply booleanListArray_eq_of_data
  change row.data.map listCopyFraction++row.data.map copyNegativeFraction=_
  rw [show row.data=List.ofFn row.toVector.get from booleanListArray_data_eq_ofFn row]
  simp only [BooleanListArray.ofFn,List.ofFn_fin_append,List.map_ofFn,Function.comp_def]

theorem symmetricStoredVertices_entry (V : ListBitRationalMatrixData r m) (i : Fin r) (j : Fin (m+m)) :
    rectangularListFractionMatrix (symmetricStoredVertices V) i j=
      Fin.append (fun k => rectangularListFractionMatrix V i k)
        (fun k => bitListFractionNeg (rectangularListFractionMatrix V i k)) j := by
  have he : symmetricStoredVertices V=BooleanListArray.ofFn (fun i => symmetricVertexRow (V.toVector.get i)) := by
    apply booleanListArray_eq_of_data
    change V.data.map symmetricVertexRow=List.ofFn _
    rw [booleanListArray_data_eq_ofFn V,List.map_ofFn]
    rfl
  rw [he]
  simp only [rectangularListFractionMatrix,listMatrixVector_ofFn,BooleanListArray.ofFn_toVector,sym_get_ofFn]
  rw [symmetricVertexRow_eq]
  simp only [BooleanListArray.ofFn_toVector,sym_get_ofFn,listCopyFraction_eq,copyNegativeFraction]
  refine Fin.addCases (fun k => ?_) (fun k => ?_) j
  · simp only [Fin.append_left]
    exact (rectangularListFractionMatrix_row V i k).symm
  · simp only [Fin.append_right]
    exact congrArg bitListFractionNeg (rectangularListFractionMatrix_row V i k).symm

theorem symmetricStoredVertices_wellFormed (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) :
    ∀ i j,(rectangularListFractionMatrix (symmetricStoredVertices V) i j).WellFormed := by
  intro i j
  rw [symmetricStoredVertices_entry]
  refine Fin.addCases (fun k => ?_) (fun k => ?_) j
  · simpa only [Fin.append_left] using hV i k
  · simpa only [Fin.append_right] using bitListFractionNeg_wellFormed _ (hV i k)

theorem realVertex_symmetric_left (V : ListBitRationalMatrixData r m) (j : Fin m) :
    realVertex (storedRationalVertices (symmetricStoredVertices V)) (Fin.castAdd m j)=
      realVertex (storedRationalVertices V) j := by
  ext i
  simp only [realVertex,storedRationalVertices,symmetricStoredVertices_entry,Fin.append_left]

theorem realVertex_symmetric_right (V : ListBitRationalMatrixData r m) (j : Fin m) :
    realVertex (storedRationalVertices (symmetricStoredVertices V)) (Fin.natAdd m j)=
      -realVertex (storedRationalVertices V) j := by
  ext i
  simp only [realVertex,storedRationalVertices,symmetricStoredVertices_entry,Fin.append_right,
    bitListFractionNeg_correct,Pi.neg_apply,Rat.cast_neg]

theorem mem_symmetricVertexSet (V : ListBitRationalMatrixData r m) (x : Fin r → ℝ) :
    x∈rationalVertexSet (storedRationalVertices (symmetricStoredVertices V)) ↔
      x∈rationalVertexSet (storedRationalVertices V) ∨ -x∈rationalVertexSet (storedRationalVertices V) := by
  classical
  constructor
  · intro hx
    obtain ⟨j,hj⟩ := (mem_rationalVertexSet _ x).mp hx
    revert hj
    refine Fin.addCases (fun k => ?_) (fun k => ?_) j
    · intro hk
      rw [realVertex_symmetric_left] at hk
      exact Or.inl ((mem_rationalVertexSet _ x).mpr ⟨k,hk⟩)
    · intro hk
      rw [realVertex_symmetric_right] at hk
      right
      apply (mem_rationalVertexSet _ (-x)).mpr
      refine ⟨k,?_⟩
      rw [←hk,neg_neg]
  · rintro (hx | hx)
    · obtain ⟨j,hj⟩ := (mem_rationalVertexSet _ x).mp hx
      exact (mem_rationalVertexSet _ x).mpr ⟨Fin.castAdd m j,(realVertex_symmetric_left V j).trans hj⟩
    · obtain ⟨j,hj⟩ := (mem_rationalVertexSet _ (-x)).mp hx
      apply (mem_rationalVertexSet _ x).mpr
      refine ⟨Fin.natAdd m j,?_⟩
      rw [realVertex_symmetric_right,hj,neg_neg]

theorem symmetricStoredVertices_closed_neg (V : ListBitRationalMatrixData r m) :
    ∀ x∈rationalVertexSet (storedRationalVertices (symmetricStoredVertices V)),
      -x∈rationalVertexSet (storedRationalVertices (symmetricStoredVertices V)) := by
  intro x hx
  rw [mem_symmetricVertexSet] at hx ⊢
  simpa only [neg_neg] using hx.symm

theorem symmetricStoredVertices_hull (V : ListBitRationalMatrixData r m)
    (hsym : ∀ x∈storedVertexHull V,-x∈storedVertexHull V) :
    storedVertexHull (symmetricStoredVertices V)=storedVertexHull V := by
  apply Set.Subset.antisymm
  · apply convexHull_min _ (convex_convexHull ℝ _)
    intro x hx
    rcases (mem_symmetricVertexSet V x).mp hx with hx | hx
    · exact subset_convexHull ℝ _ hx
    · simpa only [neg_neg] using hsym (-x) (subset_convexHull ℝ _ hx)
  · apply convexHull_mono
    intro x hx
    exact (mem_symmetricVertexSet V x).mpr (Or.inl hx)

theorem symmetricStoredVertices_bits (V : ListBitRationalMatrixData r m) :
    listStoredRationalBits (symmetricStoredVertices V)+r=2*listStoredRationalBits V := by
  have hs : (∑ i : Fin r,∑ j : Fin (m+m),
      ((rectangularListFractionMatrix (symmetricStoredVertices V) i j).numerator.length+
       (rectangularListFractionMatrix (symmetricStoredVertices V) i j).denominator.length))=
      2*(∑ i : Fin r,∑ j : Fin m,
      ((rectangularListFractionMatrix V i j).numerator.length+
       (rectangularListFractionMatrix V i j).denominator.length)) := by
    simp only [Fin.sum_univ_add,symmetricStoredVertices_entry,Fin.append_left,Fin.append_right,
      bitListFractionNeg,Finset.sum_add_distrib]
    omega
  simp only [listStoredRationalBits_eq,bitRationalMatrixSize]
  change (r+(r*(m+m)+(∑ i : Fin r,∑ j : Fin (m+m),
      ((rectangularListFractionMatrix (symmetricStoredVertices V) i j).numerator.length+
       (rectangularListFractionMatrix (symmetricStoredVertices V) i j).denominator.length))))+r=_
  rw [hs]
  change r+(r*(m+m)+2*(∑ i : Fin r,∑ j : Fin m,
      ((rectangularListFractionMatrix V i j).numerator.length+
       (rectangularListFractionMatrix V i j).denominator.length)))+r=
    2*(r+(r*m+(∑ i : Fin r,∑ j : Fin m,
      ((rectangularListFractionMatrix V i j).numerator.length+
       (rectangularListFractionMatrix V i j).denominator.length))))
  ring

theorem symmetricVertexRowWork_bound (row : BooleanListArray BitListFraction m) (L : ℕ)
    (h : ∀ q∈row.data,q.numerator.length≤L ∧ q.denominator.length≤L) :
    symmetricVertexRowWork row≤m*(8*L+12)+3 := by
  have hc : ∀ q∈row.data,listCopyFractionWork q≤4*L+3 := by
    intro q hq
    have hb := h q hq
    rw [listCopyFractionWork_eq,fractionPayload]
    omega
  have h₁ := List.sum_le_card_nsmul (row.data.map listCopyFractionWork) (4*L+3) (by
    intro z hz; obtain ⟨q,hq,rfl⟩ := List.mem_map.mp hz; exact hc q hq)
  have h₂ := List.sum_le_card_nsmul (row.data.map fun q => listCopyFractionWork q+1) (4*L+4) (by
    intro z hz; obtain ⟨q,hq,rfl⟩ := List.mem_map.mp hz; have hh := hc q hq; omega)
  simp only [List.length_map,row.length_eq,nsmul_eq_mul] at h₁ h₂
  unfold symmetricVertexRowWork
  nlinarith

theorem symmetricStoredVerticesWork_bound (V : ListBitRationalMatrixData r m) (L : ℕ)
    (h : ∀ i j,(rectangularListFractionMatrix V i j).numerator.length≤L ∧
      (rectangularListFractionMatrix V i j).denominator.length≤L) :
    symmetricStoredVerticesWork V≤r*m*(8*L+12)+5*r+1 := by
  have hr := (matrixRows_forall V (fun q => q.numerator.length≤L ∧ q.denominator.length≤L)).mpr h
  have hs := List.sum_le_card_nsmul (V.data.map symmetricVertexRowWork) (m*(8*L+12)+3) (by
    intro z hz
    obtain ⟨row,hrow,rfl⟩ := List.mem_map.mp hz
    exact symmetricVertexRowWork_bound row L (hr row hrow))
  simp only [List.length_map,V.length_eq,nsmul_eq_mul] at hs
  unfold symmetricStoredVerticesWork
  nlinarith

noncomputable def vertexSymmetrizationPolynomial : Polynomial ℕ :=
  Polynomial.X*Polynomial.X*(8*Polynomial.X+12)+5*Polynomial.X+1

theorem symmetricStoredVerticesWork_input_polynomial (hr : 0<r) (V : ListBitRationalMatrixData r m) :
    symmetricStoredVerticesWork V≤vertexSymmetrizationPolynomial.eval (listStoredRationalBits V) := by
  have h := symmetricStoredVerticesWork_bound V (listStoredRationalBits V) (listStoredRationalBits_cell V)
  have hrN := listStoredRationalBits_rank V
  have hmN := listStoredRationalBits_vertices hr V
  apply h.trans
  simp only [vertexSymmetrizationPolynomial,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat]
  gcongr
end Optss
