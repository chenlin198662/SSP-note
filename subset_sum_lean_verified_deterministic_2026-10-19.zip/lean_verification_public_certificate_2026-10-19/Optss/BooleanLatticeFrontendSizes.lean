import Optss.BooleanLatticeFrontendWork
import Optss.ListReductionOutputSize

/-! # Physical intermediate sizes for the final lattice-box construction -/
namespace Optss
variable {r m : ℕ}

theorem frontendNormalizedLattice_bits
    (A G : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (N : ℕ) (hN : listStoredRationalBits A+listStoredRationalBits G≤N) :
    listStoredRationalBits (constructedListMatrixMul (constructedListMatrixInverse A) G)≤
      (frontendNormalizedLatticeSize r).eval N := by
  let C := constructedListMatrixInverse A
  let K := (computedBasisIntermediateSize r).eval N
  have hAn : listStoredRationalBits A≤N := by omega
  have hGn : listStoredRationalBits G≤N := by omega
  have hNK : N≤K := by
    simp only [K,computedBasisIntermediateSize,Polynomial.eval_add,Polynomial.eval_mul,
      Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat]
    omega
  have hCb := constructedListMatrixInverse_bits A hA
  have hCsize : listStoredRationalBits C+N≤K := by
    change listStoredRationalBits (constructedListMatrixInverse A)+N≤_
    simp only [K,computedBasisIntermediateSize,Polynomial.eval_add,Polynomial.eval_mul,
      Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat]
    apply Nat.add_le_add_right (hCb.trans ?_) N
    gcongr
  have hCfields : ∀ i j,(rectangularListFractionMatrix C i j).numerator.length≤K ∧
      (rectangularListFractionMatrix C i j).denominator.length≤K := by
    intro i j
    have h := listStoredRationalBits_cell C i j
    exact ⟨h.1.trans (by omega),h.2.trans (by omega)⟩
  have hGfields : ∀ i j,(rectangularListFractionMatrix G i j).numerator.length≤K ∧
      (rectangularListFractionMatrix G i j).denominator.length≤K := by
    intro i j
    have h := listStoredRationalBits_cell G i j
    exact ⟨h.1.trans (hGn.trans hNK),h.2.trans (hGn.trans hNK)⟩
  have h := listStoredRationalBits_le_of_lengths (constructedListMatrixMul C G) ((r+1)*(2*K+2))
    (constructedListMatrixMul_lengths C G (constructedListMatrixInverse_wellFormed A hA) hG K hCfields hGfields)
  simp only [frontendNormalizedLatticeSize,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_C,Polynomial.eval_one,Polynomial.eval_ofNat]
  change _≤r+r*r*(1+2*(r+1)*(2*K+2))
  convert h using 1; ring

noncomputable def frontendReducedRowsSize (r : ℕ) : Polynomial ℕ :=
  (listReductionOutputSizePolynomial r r).comp (frontendNormalizedLatticeSize r)

theorem booleanLatticeFrontendFromBasis_reduced_bits
    (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetA : (storedRationalMatrix A).det≠0) (hdetG : (storedRationalMatrix G).det≠0)
    (N : ℕ) (hN : listStoredRationalBits A+listStoredRationalBits G≤N) :
    listStoredRationalBits (booleanLatticeFrontendFromBasis A V G).reducedLatticeRows≤
      (frontendReducedRowsSize r).eval N := by
  let C := constructedListMatrixInverse A
  let M := constructedListMatrixMul C G
  let T := listStoredMatrixTranspose M
  have hT := listStoredMatrixTranspose_wellFormed M
    (constructedListMatrixMul_wellFormed C G (constructedListMatrixInverse_wellFormed A hA) hG)
  have hi := storedRationalRows_independent T (frontend_normalized_lattice_det A G hA hG hdetA hdetG)
  have hs : listStoredRationalBits T≤(frontendNormalizedLatticeSize r).eval N := by
    rw [listStoredMatrixTranspose_square_bits]
    exact frontendNormalizedLattice_bits A G hA hG N hN
  rw [frontendReducedRowsSize,Polynomial.eval_comp]
  exact (listStoredRationalReduction_bits T hT hi).trans
    (natPolynomial_eval_mono (listReductionOutputSizePolynomial r r) hs)
end Optss
