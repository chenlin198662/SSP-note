import Optss.BoundedDifferenceWork

/-! Fixed natural-coefficient polynomials certifying the source-work bound
for each constant repeated-sum schedule. -/
namespace Optss
set_option maxRecDepth 4096

noncomputable def supportConvolutionWorkPolynomial : Polynomial ℕ :=
  let n := Polynomial.X
  let p := 5*n+12
  let b := 2*(n*(p+6)+3)+1
  let fft := 2*(320*(n+3)^2+4194304*(n+p+73)^2*(8192*(n+p+73)^4+1)^3+16)+
    4*(p+3)+4+576*(n+1)*(n*(p+6)+b+3)^2
  3*fft+512*(n*(p+6)+4)^2+14+1048576*(3*n*(p+6)+10)^3+64*(n+1)*(p+3)+72

theorem supportConvolutionWorkPolynomial_eval (n : ℕ) :
    supportConvolutionWorkPolynomial.eval n=listBooleanConvolutionWorkFactor n := by
  simp only [supportConvolutionWorkPolynomial,listBooleanConvolutionWorkFactor,listSupportFFTWorkFactor,
    dyadicDFTPrecision,Polynomial.eval_add,Polynomial.eval_mul,Polynomial.eval_pow,
    Polynomial.eval_X,Polynomial.eval_ofNat,Polynomial.eval_one]

noncomputable def boundedDifferenceWorkPolynomial (t : ℕ) : Polynomial ℕ :=
  1024*(Polynomial.X+Polynomial.C t+4)^2+
    Polynomial.C (12*2^t*(t+1))*(supportConvolutionWorkPolynomial.comp (Polynomial.X+Polynomial.C (t+3)))+
    Polynomial.C (2*(t+1)+504*2^t+52)

theorem boundedDifferenceWorkPolynomial_eval (s t : ℕ) :
    (boundedDifferenceWorkPolynomial t).eval s=boundedDifferenceWorkFactor s t := by
  simp only [boundedDifferenceWorkPolynomial,boundedDifferenceWorkFactor,
    Polynomial.eval_add,Polynomial.eval_mul,Polynomial.eval_pow,Polynomial.eval_X,
    Polynomial.eval_C,Polynomial.eval_ofNat,Polynomial.eval_comp,supportConvolutionWorkPolynomial_eval]
  simp only [Nat.add_assoc]

theorem boundedIntegerDifferenceListWork_polynomial (steps : List Bool) (U : ℕ) (input : List ℤ) :
    boundedIntegerDifferenceListWork steps U input≤
      (U+input.length+1)*(boundedDifferenceWorkPolynomial steps.length).eval (U+1).size := by
  rw [boundedDifferenceWorkPolynomial_eval]
  exact boundedIntegerDifferenceListWork_bound steps U input

/-- Complete bounded-input contract: exact distinct differences and the
original-input source-work polynomial in one statement. -/
theorem boundedIntegerDifferenceList_verified (steps : List Bool) (U : ℕ) (input : List ℤ)
    (hinput : ∀ z∈input, |z|≤(U : ℤ)) :
    (boundedIntegerDifferenceList steps U input).toFinset=modelingDifferences input.toFinset (2^steps.length) ∧
    (boundedIntegerDifferenceList steps U input).Nodup ∧
    boundedIntegerDifferenceListWork steps U input≤
      (U+input.length+1)*(boundedDifferenceWorkPolynomial steps.length).eval (U+1).size :=
  ⟨boundedIntegerDifferenceList_eq steps U input hinput,
    boundedIntegerDifferenceList_nodup steps U input,
    boundedIntegerDifferenceListWork_polynomial steps U input⟩

end Optss
