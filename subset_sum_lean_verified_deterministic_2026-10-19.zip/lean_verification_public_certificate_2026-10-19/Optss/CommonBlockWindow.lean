import Optss.ActualPhaseBlockSelector

/-!
# A restart or a dense window in one actual lattice

The output is an alternative of the finite block iteration itself. No common
lattice, collection of dense supports, or no-restart condition is assumed.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1000000

variable {ι : Type} [DecidableEq ι] {d : ℕ} {v : ι → IntVec d}
  {initial : Finset ι} {B : ℕ}

/-- Consecutive actual blocks with exact supports, density, and one full lattice. -/
def DenseCommonBlockWindow (F : BoundedBlockSelector v initial B)
    (w : Fin d → ℕ) (ℓ M : ℕ) : Prop :=
  ∃ b ≤ Nat.log 2 (d.factorial*∏ j, w j),
    (∀ t ≤ ℓ, generatedLattice v (F.remaining (b*ℓ+t)) = generatedLattice v (F.remaining (b*ℓ))) ∧
    (∀ t < ℓ, 0 ∈ (F.block (b*ℓ+t)).sums ∧ (M : ℝ)/4 ≤ (F.block (b*ℓ+t)).sums.card ∧
      AddSubgroup.closure ((F.block (b*ℓ+t)).sums : Set (IntVec d)) = generatedLattice v (F.remaining (b*ℓ)) ∧
      (F.block (b*ℓ+t)).sums = labelledSubsetSupport v (F.block (b*ℓ+t)).chosen) ∧
    (∀ i < ℓ, ∀ j < ℓ, i ≠ j → Disjoint (F.block (b*ℓ+i)).chosen (F.block (b*ℓ+j)).chosen) ∧
    (initial \ F.remaining (b*ℓ)).card ≤ b*ℓ*B

/-- Either an actual finite prefix strictly halves the scalar potential, or
the same finite sequence supplies the consecutive dense common-lattice window. -/
theorem BoundedBlockSelector.restart_or_dense_window
    (F : BoundedBlockSelector v initial B) (scalar : ι → ℤ) (h M n ℓ k : ℕ)
    (hbudget : n*B ≤ k)
    (hprotected : ∀ deleted : Finset ι, deleted.card ≤ k →
      labelSpan ℝ (fun i => realVector (v i)) (initial \ deleted) = ⊤)
    (w : Fin d → ℕ) (hbox : ∀ i ∈ initial, InCenteredBox w (v i))
    (hlength : (Nat.log 2 (d.factorial*∏ j, w j)+1)*ℓ ≤ n)
    (hselector : ∀ s ⊆ initial, labelSpan ℝ (fun i => realVector (v i)) s = ⊤ →
      0 ∈ (F.select s).sums ∧
      AddSubgroup.closure ((F.select s).sums : Set (IntVec d)) = generatedLattice v s ∧
      (2*(h • insert 0 ((F.select s).remaining.image scalar)).card < M ∨
        (M : ℝ)/4 ≤ (F.select s).sums.card)) :
    (∃ i < n, 2*(h • insert 0 ((F.remaining (i+1)).image scalar)).card < M ∧
      (initial \ F.remaining (i+1)).card ≤ n*B) ∨ DenseCommonBlockWindow F w ℓ M := by
  have hfull := F.remaining_full_rank n k hbudget hprotected
  have hgood : ∀ i < n, 0 ∈ (F.block i).sums ∧
      AddSubgroup.closure ((F.block i).sums : Set (IntVec d)) = generatedLattice v (F.remaining i) ∧
      (2*(h • insert 0 ((F.remaining (i+1)).image scalar)).card < M ∨
        (M : ℝ)/4 ≤ (F.block i).sums.card) := by
    intro i hi
    exact hselector _ (F.remaining_subset i) (hfull i hi.le)
  by_cases hr : ∃ i < n, 2*(h • insert 0 ((F.remaining (i+1)).image scalar)).card < M
  · obtain ⟨i, hi, hr⟩ := hr
    exact Or.inl ⟨i, hi, hr, (F.deleted_card_le (i+1)).trans
      (Nat.mul_le_mul_right B (Nat.succ_le_of_lt hi))⟩
  · obtain ⟨b, hb, hlat, hgen, hsums, hdis, hsize⟩ := F.common_lattice_window n ℓ k hbudget hprotected
      w hbox hlength (fun i hi => (hgood i hi).2.1)
    refine Or.inr ⟨b, hb, hlat, ?_, hdis, hsize⟩
    intro t ht
    have hbound := (Nat.mul_le_mul_right ℓ (Nat.add_le_add_right hb 1)).trans hlength
    have hit : b*ℓ+t < n := by
      calc
        _ < b*ℓ+ℓ := Nat.add_lt_add_left ht _
        _ = (b+1)*ℓ := by ring
        _ ≤ n := hbound
    refine ⟨(hgood _ hit).1, ?_, hgen t ht, hsums t ht⟩
    exact (hgood _ hit).2.2.resolve_left (fun H => hr ⟨_, hit, H⟩)

/-- Uniform actual greedy selectors therefore yield the required phase
alternative from a genuine labelled phase model and a successful basis-packing
certificate. The no-restart and common-lattice conclusions are outputs. -/
theorem actual_phase_common_lattice_window (η : ℝ) (hη : 0 < η) :
    ∃ a N₀ : ℕ, ∃ c : ℝ, 1 ≤ a ∧ 0 < c ∧
      ∀ (ι : Type) [LinearOrder ι] (scalar : ι → ℤ) (initial : Finset ι) (h : ℕ)
        (model : CommonGapLabelModel scalar initial h) (N M n ℓ k : ℕ),
        N₀ ≤ N → 1 ≤ N → 1 ≤ h → 4 ≤ M → (N : ℝ)^η ≤ h → M ≤ h*N+1 →
        (∀ i ∈ initial, scalar i ∈ Finset.Icc 0 (N : ℤ)) →
        let B := ⌈(latticeSeedCardBound model.rank model.widths : ℝ)+greedyProfileConstant c a η*h⌉₊
        n*B ≤ k →
        (packLabelBases (fun i => realVector (model.coordinates i))
          (labelSpan ℝ (fun i => realVector (model.coordinates i)) initial) initial (k+1)).length = k+1 →
        (Nat.log 2 (model.rank.factorial*∏ j, model.widths j)+1)*ℓ ≤ n →
        ∃ F : BoundedBlockSelector model.coordinates initial B,
          F.select = actualPhaseBlock model c a M ∧
          ((∃ i < n, 2*(h • insert 0 ((F.remaining (i+1)).image scalar)).card < M ∧
            (initial \ F.remaining (i+1)).card ≤ n*B) ∨ DenseCommonBlockWindow F model.widths ℓ M) := by
  obtain ⟨a, N₀, c, ha, hc, hselector⟩ := actual_phase_block_selector η hη
  refine ⟨a, N₀, c, ha, hc, ?_⟩
  intro ι _ scalar initial h model N M n ℓ k hN₀ hN hh hM4 hscale hM hscalar B hbudget hpack hlength
  obtain ⟨F, hF, hgood⟩ := hselector ι scalar initial h model N M hN₀ hN hh hM4 hscale hM hscalar
  refine ⟨F, hF, F.restart_or_dense_window scalar h M n ℓ k hbudget ?_ model.widths model.boxed hlength hgood⟩
  intro deleted hd
  obtain ⟨_, _, _, _, hs⟩ := packLabelBases_success (K := ℝ)
    (fun i => realVector (model.coordinates i)) initial k hpack deleted hd
  exact hs.trans model.fullRank

end
end Optss
