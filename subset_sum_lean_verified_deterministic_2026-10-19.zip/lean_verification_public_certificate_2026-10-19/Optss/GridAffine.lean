import Optss.Basic
import Mathlib.Algebra.BigOperators.Pi

/-!
# Affine functions on finite integer grids

The local equation below includes both mixed parallelograms and, when the two
indices coincide, the three-point second-difference equation. It implies an
integer affine formula on the entire box, including boxes with zero widths.
-/

namespace Optss

open scoped BigOperators

variable {ι G : Type*} [Fintype ι] [DecidableEq ι] [AddCommGroup G]

/-- Increment one natural coordinate by one. -/
def gridStep (x : ι → ℕ) (i : ι) : ι → ℕ := x + Pi.single i 1

omit [Fintype ι] in
@[simp] theorem gridStep_apply_same (x : ι → ℕ) (i : ι) :
    gridStep x i i = x i + 1 := by simp [gridStep]

omit [Fintype ι] in
@[simp] theorem gridStep_apply_ne (x : ι → ℕ) {i j : ι} (h : j ≠ i) :
    gridStep x i j = x j := by simp [gridStep, Pi.single_eq_of_ne h]

omit [Fintype ι] in
theorem gridStep_comm (x : ι → ℕ) (i j : ι) :
    gridStep (gridStep x i) j = gridStep (gridStep x j) i := by
  funext k
  simp only [gridStep, Pi.add_apply]
  omega

/-- Coordinatewise induction, with no restriction on the number of coordinates. -/
theorem natPi_grid_induction (P : (ι → ℕ) → Prop) (hzero : P 0)
    (hstep : ∀ x i, P x → P (gridStep x i)) (x : ι → ℕ) : P x := by
  suffices ∀ n x, (∑ i, x i) = n → P x from this _ x rfl
  intro n
  induction n using Nat.strong_induction_on with
  | h n ih =>
      intro x hsum
      by_cases hx : x = 0
      · simpa [hx] using hzero
      · have hex : ∃ j, x j ≠ 0 := by
          by_contra h
          push_neg at h
          exact hx (funext h)
        obtain ⟨j, hj⟩ := hex
        let y := Function.update x j (x j - 1)
        have hy : gridStep y j = x := by
          funext k
          by_cases hk : k = j
          · subst k
            simp [y]
            omega
          · simp [gridStep_apply_ne _ hk, y, hk]
        have hlt : (∑ i, y i) < n := by
          rw [← hsum]
          apply Finset.sum_lt_sum
          · intro i _
            by_cases hi : i = j
            · subst i; simp [y]
            · simp [y, hi]
          · refine ⟨j, Finset.mem_univ _, ?_⟩
            simp only [y, Function.update_self]
            omega
        rw [← hy]
        exact hstep y j (ih _ hlt y rfl)

/-- All local mixed and pure second differences vanish inside the finite box. -/
def GridSecondDifferences (f : (ι → ℕ) → G) (m : ι → ℕ) : Prop :=
  ∀ x i j, gridStep (gridStep x i) j ≤ m →
    f x + f (gridStep (gridStep x i) j) = f (gridStep x i) + f (gridStep x j)

/-- The slope in a coordinate is constant wherever that coordinate can advance. -/
theorem grid_difference_constant (f : (ι → ℕ) → G) (m : ι → ℕ)
    (hlocal : GridSecondDifferences f m) (i : ι) (x : ι → ℕ)
    (hx : gridStep x i ≤ m) :
    f (gridStep x i) - f x = f (gridStep 0 i) - f 0 := by
  have h := natPi_grid_induction
    (fun x => gridStep x i ≤ m →
      f (gridStep x i) - f x = f (gridStep 0 i) - f 0)
    (by intro _; rfl) (fun x j ih hbound => ?_) x
  · exact h hx
  · have hb : gridStep (gridStep x i) j ≤ m := by
      rw [gridStep_comm]
      exact hbound
    have hxbound : gridStep x i ≤ m := by
      intro k
      exact (Nat.le_add_right _ _).trans (hb k)
    have he := hlocal x i j hb
    rw [gridStep_comm x i j] at he
    have hh := ih hxbound
    calc
      f (gridStep (gridStep x j) i) - f (gridStep x j) =
          f (gridStep x i) - f x :=
        sub_eq_sub_iff_add_eq_add.mpr (by simpa [add_comm] using he)
      _ = _ := hh

/-- The affine formula follows from the local equations; no affine extension is
assumed. Zero-width coordinates contribute zero to every point of the box. -/
theorem grid_affine_formula (f : (ι → ℕ) → G) (m : ι → ℕ)
    (hlocal : GridSecondDifferences f m) (x : ι → ℕ) (hx : x ≤ m) :
    f x = f 0 + ∑ i, x i • (f (gridStep 0 i) - f 0) := by
  let a : ι → G := fun i => f (gridStep 0 i) - f 0
  have h := natPi_grid_induction
    (fun x => x ≤ m → f x = f 0 + ∑ i, x i • a i)
    (by intro _; simp) (fun x j ih hbound => ?_) x
  · exact h hx
  · have hxbound : x ≤ m := by
      intro k
      exact (Nat.le_add_right _ _).trans (hbound k)
    have he := grid_difference_constant f m hlocal j x hbound
    have hs : (∑ i, gridStep x j i • a i) = (∑ i, x i • a i) + a j := by
      simp only [gridStep, Pi.add_apply, add_nsmul, Finset.sum_add_distrib]
      congr 1
      simp [Pi.single_apply, ite_smul]
    rw [hs]
    calc
      f (gridStep x j) = f x + a j := by
        exact sub_eq_iff_eq_add.mp he |>.trans (add_comm _ _)
      _ = f 0 + ((∑ i, x i • a i) + a j) := by rw [ih hxbound]; abel

/-- The integer linear part determined by the neighboring lattice values. -/
def gridLinearPart (a : ι → G) : (ι → ℤ) →+ G where
  toFun x := ∑ i, x i • a i
  map_zero' := by simp
  map_add' x y := by simp [add_zsmul, Finset.sum_add_distrib]

@[simp] theorem gridLinearPart_single (a : ι → G) (i : ι) :
    gridLinearPart a (Pi.single i 1) = a i := by
  simp [gridLinearPart, Pi.single_apply, ite_smul]

/-- The same formula expressed through an integer homomorphism. -/
theorem grid_affine_integer_formula (f : (ι → ℕ) → G) (m : ι → ℕ)
    (hlocal : GridSecondDifferences f m) (x : ι → ℕ) (hx : x ≤ m) :
    f x = f 0 + gridLinearPart (fun i => f (gridStep 0 i) - f 0)
      (fun i => (x i : ℤ)) := by
  simpa [gridLinearPart] using grid_affine_formula f m hlocal x hx

end Optss
