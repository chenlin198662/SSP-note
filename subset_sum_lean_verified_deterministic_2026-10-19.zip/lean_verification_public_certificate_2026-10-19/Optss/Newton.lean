import Mathlib.RingTheory.MvPolynomial.Symmetric.NewtonIdentities
import Mathlib.Algebra.Polynomial.BigOperators
import Mathlib.Tactic

/-!
# Newton recurrence for labelled copies

This is the algebraic core of Lemma 10.1, equation (74). It works in an
arbitrary commutative ring, so the inputs can in particular be monomials or
their images in a truncated polynomial ring. Indices label individual copies:
equal values of different copies are permitted throughout.

The support algorithm, its coefficient-size estimates, and its running time
are not formalized by this file.
-/

namespace Optss

open scoped BigOperators

noncomputable section

variable {ι R : Type*} [Fintype ι] [CommRing R]

/-- Degree `k` elementary coefficient: choose `k` distinct labelled copies. -/
def elementaryCoefficient (a : ι → R) (k : ℕ) : R :=
  ∑ s ∈ (Finset.univ : Finset ι).powersetCard k, ∏ i ∈ s, a i

/-- Power sum, with one summand per copy rather than per distinct value. -/
def powerSum (a : ι → R) (k : ℕ) : R := ∑ i, a i ^ k

/-- The generating polynomial in the cardinality variable. -/
def selectionPolynomial (a : ι → R) : Polynomial R :=
  ∏ i, (1 + Polynomial.C (a i) * Polynomial.X)

/-- Its degree-`k` coefficient sums precisely the products over `k` distinct
copy labels, connecting the finite-subset definition to the paper's `F_k`. -/
theorem selectionPolynomial_coeff (a : ι → R) (k : ℕ) :
    (selectionPolynomial a).coeff k = elementaryCoefficient a k := by
  classical
  have hprod (s : Finset ι) :
      (∏ i ∈ s, Polynomial.C (a i) * Polynomial.X) =
        Polynomial.C (∏ i ∈ s, a i) * Polynomial.X ^ s.card := by
    rw [Finset.prod_mul_distrib]
    simp only [← map_prod, Finset.prod_const]
  unfold selectionPolynomial
  rw [Finset.prod_one_add, Polynomial.finset_sum_coeff]
  simp_rw [hprod, Polynomial.coeff_C_mul_X_pow]
  simp [elementaryCoefficient, Finset.powersetCard_eq_filter, Finset.sum_filter, eq_comm]

@[simp] theorem elementaryCoefficient_zero (a : ι → R) :
    elementaryCoefficient a 0 = 1 := by
  simp [elementaryCoefficient]

/-- Evaluation transfers the universal elementary symmetric polynomial. -/
theorem eval_esymm_eq_elementaryCoefficient (a : ι → R) (k : ℕ) :
    MvPolynomial.eval a (MvPolynomial.esymm ι R k) = elementaryCoefficient a k := by
  classical
  simp [MvPolynomial.esymm, elementaryCoefficient]

/-- Evaluation transfers the universal power-sum polynomial. -/
theorem eval_psum_eq_powerSum (a : ι → R) (k : ℕ) :
    MvPolynomial.eval a (MvPolynomial.psum ι R k) = powerSum a k := by
  simp [MvPolynomial.psum, powerSum]

/-- A direct evaluation of mathlib's general Newton identity. -/
theorem newton_antidiagonal (a : ι → R) (k : ℕ) :
    (k : R) * elementaryCoefficient a k = (-1 : R) ^ (k + 1) *
      ∑ p ∈ (Finset.antidiagonal k).filter (fun p => p.1 < k),
        (-1 : R) ^ p.1 * elementaryCoefficient a p.1 * powerSum a p.2 := by
  classical
  have h := congrArg (MvPolynomial.eval a) (MvPolynomial.mul_esymm_eq_sum ι R k)
  simpa [eval_esymm_eq_elementaryCoefficient, eval_psum_eq_powerSum] using h

private theorem newton_sign {i j k : ℕ} (hij : i + j = k) (hj : 0 < j) :
    (-1 : R) ^ (k + 1) * (-1 : R) ^ i = (-1 : R) ^ (j - 1) := by
  rw [← pow_add]
  have he : k + 1 + i = (j - 1) + 2 * (i + 1) := by omega
  rw [he, pow_add, pow_mul]
  simp

/-- Equation (74), in the manuscript's indexing:
`k F_k = sum_{l=1}^k (-1)^(l-1) P_l F_(k-l)`.
It remains true with repeated monomials and in a quotient ring. -/
theorem newton_recurrence (a : ι → R) (k : ℕ) :
    (k : R) * elementaryCoefficient a k =
      ∑ l ∈ Finset.Icc 1 k,
        (-1 : R) ^ (l - 1) * powerSum a l * elementaryCoefficient a (k - l) := by
  classical
  rw [newton_antidiagonal, Finset.mul_sum]
  refine Finset.sum_bij (fun p _ => p.2) ?_ ?_ ?_ ?_
  · intro p hp
    rcases Finset.mem_filter.mp hp with ⟨hp, hlt⟩
    have he := Finset.mem_antidiagonal.mp hp
    simp only [Finset.mem_Icc]
    omega
  · intro p hp q hq hpq
    change p.2 = q.2 at hpq
    have hep := Finset.mem_antidiagonal.mp (Finset.mem_filter.mp hp).1
    have heq := Finset.mem_antidiagonal.mp (Finset.mem_filter.mp hq).1
    apply Prod.ext
    · omega
    · exact hpq
  · intro l hl
    have hl' := Finset.mem_Icc.mp hl
    refine ⟨(k - l, l), ?_, rfl⟩
    simp only [Finset.mem_filter, Finset.mem_antidiagonal]
    constructor <;> omega
  · intro p hp
    rcases Finset.mem_filter.mp hp with ⟨hp, hlt⟩
    have he := Finset.mem_antidiagonal.mp hp
    have hp2 : 0 < p.2 := by omega
    have hsub : k - p.2 = p.1 := by omega
    rw [hsub]
    calc
      _ = ((-1 : R) ^ (k + 1) * (-1 : R) ^ p.1) *
          powerSum a p.2 * elementaryCoefficient a p.1 := by ring
      _ = _ := by rw [newton_sign he hp2]

/-- When copies are indexed by type and a finite copy number, their power sum
is obtained directly from the multiplicities. This is the `P_l` formula in §10.1. -/
theorem powerSum_copies (c : ι → ℕ) (a : ι → R) (l : ℕ) :
    powerSum (fun p : Σ i, Fin (c i) => a p.1) l =
      ∑ i, (c i : R) * a i ^ l := by
  classical
  simp [powerSum, Fintype.sum_sigma, nsmul_eq_mul]

/-- Equation (74) with powers computed from the type multiplicities directly. -/
theorem newton_recurrence_copies (c : ι → ℕ) (a : ι → R) (k : ℕ) :
    (k : R) * elementaryCoefficient (fun p : Σ i, Fin (c i) => a p.1) k =
      ∑ l ∈ Finset.Icc 1 k,
        (-1 : R) ^ (l - 1) * (∑ i, (c i : R) * a i ^ l) *
          elementaryCoefficient (fun p : Σ i, Fin (c i) => a p.1) (k - l) := by
  simpa only [powerSum_copies] using
    (newton_recurrence (fun p : Σ i, Fin (c i) => a p.1) k)

/-- Specialization to integer coefficients certifies exact divisibility in the
Newton step; no division in a field and no reduction modulo a prime is used. -/
theorem newton_integer_divisibility (a : ι → ℤ) (k : ℕ) :
    (k : ℤ) ∣ ∑ l ∈ Finset.Icc 1 k,
      (-1 : ℤ) ^ (l - 1) * powerSum a l * elementaryCoefficient a (k - l) := by
  exact ⟨elementaryCoefficient a k, (newton_recurrence a k).symm⟩

/-- In the integer multivariate-polynomial case, every monomial coefficient
of the Newton numerator is divisible by `k`, as required for exact division. -/
theorem newton_coefficient_divisibility {σ : Type*}
    (a : ι → MvPolynomial σ ℤ) (k : ℕ) (m : σ →₀ ℕ) :
    (k : ℤ) ∣ MvPolynomial.coeff m
      (∑ l ∈ Finset.Icc 1 k,
        (-1 : MvPolynomial σ ℤ) ^ (l - 1) * powerSum a l *
          elementaryCoefficient a (k - l)) := by
  refine ⟨MvPolynomial.coeff m (elementaryCoefficient a k), ?_⟩
  have h := congrArg (MvPolynomial.coeff m) (newton_recurrence a k)
  have hnat : (k : MvPolynomial σ ℤ) = MvPolynomial.C (k : ℤ) := by simp
  rw [hnat, MvPolynomial.coeff_C_mul] at h
  exact h.symm

end

end Optss
