import Optss.FiniteFourierConvolution
import Mathlib.Algebra.Order.BigOperators.Group.Finset

/-! Natural representation counts and their exact complex Fourier encoding. -/
namespace Optss
noncomputable section
open scoped BigOperators Pointwise ComplexConjugate
variable {N : ℕ} [NeZero N]

def cyclicNatConvolution (f g : ZMod N → ℕ) (x : ZMod N) : ℕ :=
  ∑ y, f y*g (x-y)

def cyclicNatIndicator (A : Finset (ZMod N)) (x : ZMod N) : ℕ := if x∈A then 1 else 0

def cyclicIndicator (A : Finset (ZMod N)) (x : ZMod N) : ℂ := cyclicNatIndicator A x

theorem cyclicNatConvolution_pos_iff (f g : ZMod N → ℕ) (x : ZMod N) :
    0<cyclicNatConvolution f g x ↔ ∃ y, 0<f y ∧ 0<g (x-y) := by
  simp only [cyclicNatConvolution,Nat.pos_iff_ne_zero,ne_eq]
  rw [Finset.sum_eq_zero_iff_of_nonneg (fun _ _ => Nat.zero_le _)]
  push_neg
  simp only [Finset.mem_univ,true_and,mul_ne_zero_iff]

theorem cyclicNatIndicator_pos_iff (A : Finset (ZMod N)) (x : ZMod N) :
    0<cyclicNatIndicator A x ↔ x∈A := by by_cases h : x∈A <;> simp [cyclicNatIndicator,h]

theorem cyclicNatConvolution_indicator_pos_iff (A B : Finset (ZMod N)) (x : ZMod N) :
    0<cyclicNatConvolution (cyclicNatIndicator A) (cyclicNatIndicator B) x ↔ x∈A+B := by
  rw [cyclicNatConvolution_pos_iff]
  simp only [cyclicNatIndicator_pos_iff,Finset.mem_add]
  constructor
  · rintro ⟨y,hy,hz⟩
    exact ⟨y,hy,x-y,hz,by abel⟩
  · rintro ⟨y,hy,z,hz,rfl⟩
    exact ⟨y,hy,by simpa using hz⟩

/-- Counts ordered representations x=a+b-c-d with all four entries in A. -/
def cyclicQuadrupleCount (A : Finset (ZMod N)) (x : ZMod N) : ℕ :=
  let s := cyclicNatConvolution (cyclicNatIndicator A) (cyclicNatIndicator A)
  cyclicNatConvolution s (fun y => s (-y)) x

theorem cyclicQuadrupleCount_pos_iff (A : Finset (ZMod N)) (x : ZMod N) :
    0<cyclicQuadrupleCount A x ↔ x∈(A+A)-(A+A) := by
  rw [cyclicQuadrupleCount,cyclicNatConvolution_pos_iff]
  simp only [cyclicNatConvolution_indicator_pos_iff,Finset.mem_sub]
  constructor
  · rintro ⟨y,hy,hz⟩
    exact ⟨y,hy,-(x-y),hz,by abel⟩
  · rintro ⟨y,hy,z,hz,rfl⟩
    exact ⟨y,hy,by simpa using hz⟩

theorem cyclicNatConvolution_cast (f g : ZMod N → ℕ) (x : ZMod N) :
    (cyclicNatConvolution f g x : ℂ) =
      cyclicConvolution (fun y => (f y : ℂ)) (fun y => (g y : ℂ)) x := by
  simp only [cyclicNatConvolution,cyclicConvolution,Nat.cast_sum,Nat.cast_mul]

theorem cyclicQuadrupleCount_cast (A : Finset (ZMod N)) (x : ZMod N) :
    (cyclicQuadrupleCount A x : ℂ) =
      cyclicConvolution (cyclicConvolution (cyclicIndicator A) (cyclicIndicator A))
        (cyclicAdjoint (cyclicConvolution (cyclicIndicator A) (cyclicIndicator A))) x := by
  simp only [cyclicQuadrupleCount,cyclicNatConvolution_cast,cyclicAdjoint,cyclicConvolution,
    cyclicIndicator,cyclicNatConvolution,Nat.cast_sum,Nat.cast_mul,map_sum,map_mul,map_natCast]

theorem cyclicIndicator_dft_zero (A : Finset (ZMod N)) :
    ZMod.dft (cyclicIndicator A) 0 = A.card := by
  simp [ZMod.dft_apply,cyclicIndicator,cyclicNatIndicator]

theorem cyclicIndicator_normSq_sum (A : Finset (ZMod N)) :
    ∑ x, Complex.normSq (cyclicIndicator A x) = (A.card : ℝ) := by
  simp [cyclicIndicator,cyclicNatIndicator]

theorem cyclicIndicator_parseval (A : Finset (ZMod N)) :
    ∑ k, Complex.normSq (ZMod.dft (cyclicIndicator A) k) = (N : ℝ)*A.card := by
  rw [cyclic_parseval,cyclicIndicator_normSq_sum]

/-- Fourier inversion for the actual natural four-term representation count. -/
theorem cyclicQuadrupleCount_fourier (A : Finset (ZMod N)) (x : ZMod N) :
    (N : ℂ)*(cyclicQuadrupleCount A x : ℂ) =
      ∑ k, ZMod.stdAddChar (k*x) * (Complex.normSq (ZMod.dft (cyclicIndicator A) k) : ℂ)^2 := by
  have h := cyclic_fourier_inversion
    (cyclicConvolution (cyclicConvolution (cyclicIndicator A) (cyclicIndicator A))
      (cyclicAdjoint (cyclicConvolution (cyclicIndicator A) (cyclicIndicator A)))) x
  rw [← cyclicQuadrupleCount_cast] at h
  rw [h]
  apply Finset.sum_congr rfl
  intro k _
  simp only [cyclic_dft_convolution,cyclic_dft_adjoint,Complex.mul_conj,Complex.normSq_mul]
  push_cast
  ring

end
end Optss
