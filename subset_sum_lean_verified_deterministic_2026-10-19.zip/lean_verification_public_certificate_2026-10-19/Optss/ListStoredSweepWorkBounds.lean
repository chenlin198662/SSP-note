import Optss.ListStoredIntegerWorkBounds
import Optss.ListStoredGSWorkBounds

/-! Polynomial storage work of actual descending and complete size sweeps. -/
namespace Optss
variable {r d : ℕ}

/-- Sum of the costs of conversion, a cached GS table, one coefficient,
one row update, and explicit bounded-index control. -/
def listStoredRowFactor (r d : ℕ) : ℕ :=
  (4*r*d+r+1)*listStorageFactor r d+262144*(r+d+1)^8+
    8192*(r+d+1)^5+(4*d+4)*listStorageFactor r d+listStorageFactor r d+4

def listStoredAllFactor (r d : ℕ) : ℕ :=
  (r+1)*listStoredRowFactor r d+listStorageFactor r d+2

theorem listStoredRowFactor_pos (r d : ℕ) : 0 < listStoredRowFactor r d := by
  unfold listStoredRowFactor
  omega

theorem listStoredAllFactor_pos (r d : ℕ) : 0 < listStoredAllFactor r d := by
  unfold listStoredAllFactor
  omega

theorem listStoredReduceIntegerRowStorageWork_bound (D : ListBitIntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (h : n≤k.val) (B : ℕ)
    (hB : ∀ i l,integerPayload (((listMatrixVector D).get i).get l) ≤ B) :
    listStoredReduceIntegerRowStorageWork D k n h ≤
      (n+1)*listStoredRowFactor r d*
        (B+encodedReduceIntegerRowWork (listMatrixVector D) k n h+3) := by
  induction n generalizing D B with
  | zero =>
    rw [listStoredReduceIntegerRowStorageWork,encodedReduceIntegerRowWork]
    have hf := listStoredRowFactor_pos r d
    nlinarith
  | succ n ih =>
    let j : Fin r := ⟨n,by omega⟩
    let Q := listStoredRationalIntegerRows D
    let T := listStoredGSTable Q r le_rfl
    let c := listStoredGsCoefficient Q T k j
    let q := encodedRoundInteger c
    let W := listStoredIntegerRowUpdate D k j q
    let wt := encodedGSTableWork (listMatrixVector Q) r le_rfl
    let wc := encodedGsCoefficientWork (listMatrixVector Q) (listMatrixVector T) k j
    let wr := bitListFractionRoundCost c
    let wu := encodedIntegerRowUpdateWork (listMatrixVector D) k j q
    let wn := encodedReduceIntegerRowWork (listMatrixVector W) k n (by omega)
    let R := B+(wt+wc+wr+wu+wn)+3
    have htotal : encodedReduceIntegerRowWork (listMatrixVector D) k (n+1) h = wt+wc+wr+wu+wn := by
      simp only [encodedReduceIntegerRowWork,wt,wc,wr,wu,wn,W,q,c,T,Q,j,
        listStoredIntegerRowUpdate_eq,listStoredGsCoefficient_eq,listStoredGSTable_eq,
        listStoredRationalIntegerRows_eq]
    have hQ : ∀ i l,fractionPayload (((listMatrixVector Q).get i).get l) ≤ B+1 :=
      listStoredRationalIntegerRows_payload D B hB
    have hT : ∀ i l,fractionPayload (((listMatrixVector T).get i).get l) ≤ 1+wt := by
      intro i l
      change fractionPayload (((listMatrixVector (listStoredGSTable Q r le_rfl)).get i).get l) ≤ _
      rw [listStoredGSTable_eq]
      exact encodedGSTable_output_le_work (listMatrixVector Q) r le_rfl i l
    have hround : integerPayload q ≤ wr := bitListFractionRound_output_le_cost c
    have hW : ∀ i l,integerPayload (((listMatrixVector W).get i).get l) ≤ B+wu := by
      intro i l
      change integerPayload (((listMatrixVector (listStoredIntegerRowUpdate D k j q)).get i).get l) ≤ _
      rw [listStoredIntegerRowUpdate_eq]
      exact encodedIntegerRowUpdate_output_le_work (listMatrixVector D) k j q B hB i l
    have hemb := listStoredRationalIntegerRowsStorageWork_le D B hB
    have htab := listStoredGSTableStorageWork_bound Q r le_rfl (B+1) hQ
    have hcoef := listStoredGsCoefficientStorageWork_bound Q T k j (B+wt+1)
      (fun i l => (hQ i l).trans (by omega)) (fun i l => (hT i l).trans (by omega))
    have hupd := listStoredIntegerRowUpdateStorageWork_le D k j q B wr hB hround
    have hrec := ih W (by omega) (B+wu) hW
    have hindex := bitUnaryAddressWork_factor (r:=r) (d:=d) n (by have hk:=k.isLt; omega)
    have hemb' : listStoredRationalIntegerRowsStorageWork D ≤
        ((4*r*d+r+1)*listStorageFactor r d)*R := hemb.trans (Nat.mul_le_mul_left _ (by dsimp [R]; omega))
    have htab' : listStoredGSTableStorageWork Q r le_rfl ≤ 262144*(r+d+1)^8*R := by
      apply htab.trans
      apply Nat.mul_le_mul_left
      dsimp [R,wt]
      omega
    have hcoef' : listStoredGsCoefficientStorageWork Q T k j ≤ 8192*(r+d+1)^5*R :=
      hcoef.trans (Nat.mul_le_mul_left _ (by dsimp [R]; omega))
    have hupd' : listStoredIntegerRowUpdateStorageWork D k j q ≤ (4*d+4)*listStorageFactor r d*R :=
      hupd.trans (Nat.mul_le_mul_left _ (by change B+wr+wu+1≤R; dsimp [R]; omega))
    have hrec' : listStoredReduceIntegerRowStorageWork W k n (by omega) ≤
        (n+1)*listStoredRowFactor r d*R :=
      hrec.trans (Nat.mul_le_mul_left _ (by change B+wu+wn+3≤R; dsimp [R]; omega))
    have hR : 1≤R := by dsimp [R]; omega
    have hcontrol : bitUnaryAddressWork n+4 ≤ (listStorageFactor r d+4)*R := by
      exact (Nat.add_le_add_right hindex 4).trans (Nat.le_mul_of_pos_right _ hR)
    rw [listStoredReduceIntegerRowStorageWork,htotal]
    change listStoredRationalIntegerRowsStorageWork D+listStoredGSTableStorageWork Q r le_rfl+
      listStoredGsCoefficientStorageWork Q T k j+listStoredIntegerRowUpdateStorageWork D k j q+
      listStoredReduceIntegerRowStorageWork W k n _+bitUnaryAddressWork n+4 ≤
        (n+1+1)*listStoredRowFactor r d*R
    calc
      _ ≤ ((4*r*d+r+1)*listStorageFactor r d)*R+262144*(r+d+1)^8*R+
          8192*(r+d+1)^5*R+(4*d+4)*listStorageFactor r d*R+
          (n+1)*listStoredRowFactor r d*R+(listStorageFactor r d+4)*R := by omega
      _ = _ := by unfold listStoredRowFactor; ring

theorem listStoredReduceIntegerAllStorageWork_bound (D : ListBitIntegerMatrixData r d)
    (n : ℕ) (h : n≤r) (B : ℕ)
    (hB : ∀ i l,integerPayload (((listMatrixVector D).get i).get l) ≤ B) :
    listStoredReduceIntegerAllStorageWork D n h ≤
      (n+1)*listStoredAllFactor r d*
        (B+encodedReduceIntegerAllWork (listMatrixVector D) n h+3) := by
  induction n with
  | zero =>
    rw [listStoredReduceIntegerAllStorageWork,encodedReduceIntegerAllWork]
    have hf := listStoredAllFactor_pos r d
    nlinarith
  | succ n ih =>
    let C := listStoredReduceIntegerAll D n (by omega)
    let w₁ := encodedReduceIntegerAllWork (listMatrixVector D) n (by omega)
    let w₂ := encodedReduceIntegerRowWork (listMatrixVector C) ⟨n,by omega⟩ n le_rfl
    let R := B+(w₁+w₂)+3
    have htotal : encodedReduceIntegerAllWork (listMatrixVector D) (n+1) h = w₁+w₂ := by
      simp only [encodedReduceIntegerAllWork,w₁,w₂,C,listStoredReduceIntegerAll_eq]
    have hC : ∀ i l,integerPayload (((listMatrixVector C).get i).get l) ≤ B+w₁ := by
      intro i l
      change integerPayload (((listMatrixVector (listStoredReduceIntegerAll D n (by omega))).get i).get l) ≤ _
      rw [listStoredReduceIntegerAll_eq]
      exact encodedReduceIntegerAll_output_le_work (listMatrixVector D) n (by omega) B hB i l
    have hrec := ih (by omega)
    have hrow := listStoredReduceIntegerRowStorageWork_bound C ⟨n,by omega⟩ n le_rfl (B+w₁) hC
    have hindex := bitUnaryAddressWork_factor (r:=r) (d:=d) n (by omega)
    have hR : 1≤R := by dsimp [R]; omega
    have hrec' : listStoredReduceIntegerAllStorageWork D n (by omega) ≤
        (n+1)*listStoredAllFactor r d*R :=
      hrec.trans (Nat.mul_le_mul_left _ (by change B+w₁+3≤R; dsimp [R]; omega))
    have hrow' : listStoredReduceIntegerRowStorageWork C ⟨n,by omega⟩ n le_rfl ≤
        (r+1)*listStoredRowFactor r d*R := by
      apply hrow.trans
      change (n+1)*listStoredRowFactor r d*(B+w₁+w₂+3) ≤ _
      have he : B+w₁+w₂+3=R := by dsimp [R]; omega
      rw [he]
      exact Nat.mul_le_mul_right R (Nat.mul_le_mul_right _ (by omega))
    have hcontrol : bitUnaryAddressWork n+2 ≤ (listStorageFactor r d+2)*R :=
      (Nat.add_le_add_right hindex 2).trans (Nat.le_mul_of_pos_right _ hR)
    rw [listStoredReduceIntegerAllStorageWork,htotal]
    change listStoredReduceIntegerAllStorageWork D n _+
      listStoredReduceIntegerRowStorageWork C ⟨n,by omega⟩ n le_rfl+bitUnaryAddressWork n+2 ≤
        (n+1+1)*listStoredAllFactor r d*R
    calc
      _ ≤ (n+1)*listStoredAllFactor r d*R+(r+1)*listStoredRowFactor r d*R+
          (listStorageFactor r d+2)*R := by omega
      _ = _ := by unfold listStoredAllFactor; ring

end Optss
