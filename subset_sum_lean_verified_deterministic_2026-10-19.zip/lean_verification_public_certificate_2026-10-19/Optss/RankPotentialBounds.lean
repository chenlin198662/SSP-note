import Optss.SignedPotential
import Mathlib.Data.Nat.Choose.Bounds
import Mathlib.Data.Nat.Log

/-!
# Exact rank-loss potential accounting

Binomial counting and an explicit survivor-growth comparison imply the squared
potential drop at every rank-losing deletion. A concrete threshold replaces
"sufficiently large" for this elementary step. Finite-path telescoping then
bounds total rank loss and the number of dimension-changing events. Establishing
the long-sumset growth comparison itself remains a separate mathematical task.
-/

namespace Optss
open scoped BigOperators Pointwise Classical
noncomputable section

/-- Elementary lower estimate for the coefficient simplex, with no division. -/
theorem pow_le_factorial_mul_choose (m q : ℕ) :
    (m + 1) ^ q ≤ q.factorial * (m + q).choose q := by
  have h := Nat.pow_sub_le_descFactorial (m + q) q
  rw [Nat.descFactorial_eq_factorial_mul_choose] at h
  simpa only [show m + q + 1 - q = m + 1 by omega] using h

/-- The half-scale count dominates `k^q` up to an explicit factorial constant. -/
theorem half_scale_binomial_bound (m k q : ℕ) (hscale : k ≤ 2 * (m + 1)) :
    k ^ q ≤ (2 ^ q * q.factorial) * (m + q).choose q := by
  calc
    k ^ q ≤ (2 * (m + 1)) ^ q := Nat.pow_le_pow_left hscale q
    _ = 2 ^ q * (m + 1) ^ q := Nat.mul_pow _ _ _
    _ ≤ 2 ^ q * (q.factorial * (m + q).choose q) :=
      Nat.mul_le_mul_left _ (pow_le_factorial_mul_choose m q)
    _ = _ := by ring

/-- A concrete fixed-parameter threshold gives the square-root power gain used
in the paper: the binomial count is at least `γ * k^(q/2)` in squared form. -/
theorem half_scale_choose_squared_gain (m k q γ : ℕ) (hq : 0 < q)
    (hscale : k ≤ 2 * (m + 1))
    (hthreshold : (2 ^ q * q.factorial * γ) ^ 2 ≤ k) :
    k ^ q * γ ^ 2 ≤ ((m + q).choose q) ^ 2 := by
  let B := 2 ^ q * q.factorial
  let C := (m + q).choose q
  have hB : 0 < B := Nat.mul_pos (pow_pos (by omega) _) (Nat.factorial_pos _)
  have hX : k ^ q ≤ B * C := half_scale_binomial_bound m k q hscale
  have hlarge : (B * γ) ^ 2 ≤ k ^ q :=
    hthreshold.trans (Nat.le_self_pow (Nat.ne_of_gt hq) k)
  have hfirst : B ^ 2 * (k ^ q * γ ^ 2) ≤ (k ^ q) ^ 2 := by
    have hmul := Nat.mul_le_mul_left (k ^ q) hlarge
    calc
      _ = k ^ q * (B * γ) ^ 2 := by ring
      _ ≤ k ^ q * k ^ q := hmul
      _ = _ := by ring
  have hsecond : (k ^ q) ^ 2 ≤ B ^ 2 * C ^ 2 := by
    simpa only [Nat.mul_pow] using Nat.pow_le_pow_left hX 2
  exact Nat.le_of_mul_le_mul_left (hfirst.trans hsecond) (pow_pos hB _)

/-- One threshold works uniformly for every positive loss `q ≤ D`. -/
theorem half_scale_choose_squared_gain_uniform (m k q γ D : ℕ)
    (hq : 0 < q) (hD : q ≤ D) (hscale : k ≤ 2 * (m + 1))
    (hthreshold : (2 ^ D * D.factorial * γ) ^ 2 ≤ k) :
    k ^ q * γ ^ 2 ≤ ((m + q).choose q) ^ 2 := by
  apply half_scale_choose_squared_gain m k q γ hq hscale
  apply le_trans _ hthreshold
  apply Nat.pow_le_pow_left
  exact Nat.mul_le_mul_right γ
    (Nat.mul_le_mul (Nat.pow_le_pow_right (by omega) hD) (Nat.factorial_le hD))

/-- Counting disjoint translates and comparing survivor scales imply the actual
squared potential drop, rather than assuming that drop as an invariant. -/
theorem potential_drop_of_counting (old next half k q γ C : ℕ)
    (hcount : C * half ≤ old) (hgrowth : next ≤ γ * half)
    (hgain : k ^ q * γ ^ 2 ≤ C ^ 2) :
    k ^ q * next ^ 2 ≤ old ^ 2 := by
  calc
    k ^ q * next ^ 2 ≤ k ^ q * (γ * half) ^ 2 :=
      Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hgrowth 2)
    _ = (k ^ q * γ ^ 2) * half ^ 2 := by ring
    _ ≤ C ^ 2 * half ^ 2 := Nat.mul_le_mul_right _ hgain
    _ = (C * half) ^ 2 := by ring
    _ ≤ old ^ 2 := Nat.pow_le_pow_left hcount 2

/-- Specialization to `m = floor(k/2)`, including odd values of `k`. -/
theorem potential_drop_of_half_counting (old next half k q γ D : ℕ)
    (hq : 0 < q) (hD : q ≤ D)
    (hcount : (k / 2 + q).choose q * half ≤ old) (hgrowth : next ≤ γ * half)
    (hthreshold : (2 ^ D * D.factorial * γ) ^ 2 ≤ k) :
    k ^ q * next ^ 2 ≤ old ^ 2 := by
  exact potential_drop_of_counting old next half k q γ _ hcount hgrowth
    (half_scale_choose_squared_gain_uniform (k / 2) k q γ D hq hD (by omega) hthreshold)

/-- The cumulative squared potential invariant telescopes along a finite path. -/
theorem rank_potential_telescope (base : ℕ) (μ loss : ℕ → ℕ) (n : ℕ)
    (hdrop : ∀ i < n, base ^ loss i * μ (i+1) ^ 2 ≤ μ i ^ 2) :
    base ^ (∑ i ∈ Finset.range n, loss i) * μ n ^ 2 ≤ μ 0 ^ 2 := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hprev := ih (fun i hi => hdrop i (by omega))
    have hnow := hdrop n (by omega)
    rw [Finset.sum_range_succ, pow_add]
    calc
      base ^ (∑ i ∈ Finset.range n, loss i) * base ^ loss n * μ (n+1) ^ 2 =
          base ^ (∑ i ∈ Finset.range n, loss i) * (base ^ loss n * μ (n+1) ^ 2) := by ring
      _ ≤ base ^ (∑ i ∈ Finset.range n, loss i) * μ n ^ 2 := Nat.mul_le_mul_left _ hnow
      _ ≤ μ 0 ^ 2 := hprev

/-- Positive final potential and a root bound control the exponential of total
rank lost, with no logarithms or real-number rounding conventions. -/
theorem rank_loss_pow_le (base Pmax : ℕ) (μ loss : ℕ → ℕ) (n : ℕ)
    (hdrop : ∀ i < n, base ^ loss i * μ (i+1) ^ 2 ≤ μ i ^ 2)
    (hfinal : 1 ≤ μ n) (hroot : μ 0 ≤ Pmax) :
    base ^ (∑ i ∈ Finset.range n, loss i) ≤ Pmax ^ 2 := by
  calc
    _ ≤ base ^ (∑ i ∈ Finset.range n, loss i) * μ n ^ 2 := by
      simpa using Nat.mul_le_mul_left (base ^ (∑ i ∈ Finset.range n, loss i))
        (Nat.pow_le_pow_left hfinal 2)
    _ ≤ μ 0 ^ 2 := rank_potential_telescope base μ loss n hdrop
    _ ≤ Pmax ^ 2 := Nat.pow_le_pow_left hroot 2

/-- Exact integral logarithmic version of the total-rank-loss bound. -/
theorem rank_loss_sum_le_log (base Pmax : ℕ) (hbase : 1 < base)
    (μ loss : ℕ → ℕ) (n : ℕ)
    (hdrop : ∀ i < n, base ^ loss i * μ (i+1) ^ 2 ≤ μ i ^ 2)
    (hfinal : 1 ≤ μ n) (hroot : μ 0 ≤ Pmax) :
    (∑ i ∈ Finset.range n, loss i) ≤ Nat.log base (Pmax ^ 2) :=
  Nat.le_log_of_pow_le hbase (rank_loss_pow_le base Pmax μ loss n hdrop hfinal hroot)

/-- A complete finite-path bound from counting and survivor growth comparisons.
Rank-preserving steps only need nonincreasing potential; their loss exponent is zero. -/
theorem rank_path_bound_from_counting (k γ D Pmax : ℕ)
    (μ half loss : ℕ → ℕ) (n : ℕ)
    (hthreshold : (2 ^ D * D.factorial * γ) ^ 2 ≤ k)
    (hD : ∀ i < n, loss i ≤ D)
    (hcount : ∀ i < n, 0 < loss i → (k/2 + loss i).choose (loss i) * half i ≤ μ i)
    (hgrowth : ∀ i < n, 0 < loss i → μ (i+1) ≤ γ * half i)
    (hnormal : ∀ i < n, loss i = 0 → μ (i+1) ≤ μ i)
    (hfinal : 1 ≤ μ n) (hroot : μ 0 ≤ Pmax) :
    k ^ (∑ i ∈ Finset.range n, loss i) ≤ Pmax ^ 2 := by
  apply rank_loss_pow_le k Pmax μ loss n ?_ hfinal hroot
  intro i hi
  by_cases hz : loss i = 0
  · simpa only [hz, pow_zero, one_mul] using Nat.pow_le_pow_left (hnormal i hi hz) 2
  · have hp : 0 < loss i := Nat.pos_of_ne_zero hz
    exact potential_drop_of_half_counting (μ i) (μ (i+1)) (half i) k (loss i) γ D
      hp (hD i hi) (hcount i hi hp) (hgrowth i hi hp) hthreshold

/-- Exact rank accounting: each coordinate introduction increases rank, and every
rank loss is charged. The natural-number formulation avoids truncated subtraction. -/
theorem rank_path_balance (rank introCount loss : ℕ → ℕ) (n : ℕ)
    (hstep : ∀ i < n, rank (i+1) + loss i = rank i + introCount i) :
    rank n + (∑ i ∈ Finset.range n, loss i) = rank 0 + ∑ i ∈ Finset.range n, introCount i := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hprev := ih (fun i hi => hstep i (by omega))
    have hnow := hstep n (by omega)
    rw [Finset.sum_range_succ, Finset.sum_range_succ]
    omega

/-- A positive loss at an event contributes at least one to the total loss. -/
theorem positive_event_count_le_sum (a : ℕ → ℕ) (n : ℕ) :
    ((Finset.range n).filter (fun i => 0 < a i)).card ≤ ∑ i ∈ Finset.range n, a i := by
  rw [Finset.card_eq_sum_ones, Finset.sum_filter]
  exact Finset.sum_le_sum (fun i _ => by split_ifs <;> omega)

/-- Total introductions and the combined number of dimension-changing events
are bounded by the terminal rank bound and total loss. -/
theorem rank_path_exceptional_events (rank introCount loss : ℕ → ℕ) (n Rmax Q : ℕ)
    (hstep : ∀ i < n, rank (i+1) + loss i = rank i + introCount i)
    (hrank : rank n ≤ Rmax) (hloss : (∑ i ∈ Finset.range n, loss i) ≤ Q) :
    (∑ i ∈ Finset.range n, introCount i) + rank 0 ≤ Rmax + Q ∧
    ((Finset.range n).filter (fun i => 0 < introCount i)).card +
      ((Finset.range n).filter (fun i => 0 < loss i)).card + rank 0 ≤ Rmax + 2 * Q := by
  have hbalance := rank_path_balance rank introCount loss n hstep
  have hintro := positive_event_count_le_sum introCount n
  have hlossCount := positive_event_count_le_sum loss n
  constructor <;> omega

/-- The precise rank-one-start version used in Lemma 6.2. -/
theorem rank_one_path_exceptional_events (rank introCount loss : ℕ → ℕ) (n Rmax Q : ℕ)
    (hstart : rank 0 = 1)
    (hstep : ∀ i < n, rank (i+1) + loss i = rank i + introCount i)
    (hrank : rank n ≤ Rmax) (hloss : (∑ i ∈ Finset.range n, loss i) ≤ Q) :
    ((Finset.range n).filter (fun i => 0 < introCount i)).card +
      ((Finset.range n).filter (fun i => 0 < loss i)).card ≤ Rmax + 2 * Q - 1 := by
  have h := (rank_path_exceptional_events rank introCount loss n Rmax Q hstep hrank hloss).2
  omega

/-- Combined finite-path conclusion from the counting hypotheses and exact rank
transitions. Every bound is numerical; no asymptotic growth rate is assumed. -/
theorem rank_path_accounting_from_counting (k γ D Pmax Rmax : ℕ) (hk : 1 < k)
    (μ half loss rank introCount : ℕ → ℕ) (n : ℕ)
    (hthreshold : (2 ^ D * D.factorial * γ) ^ 2 ≤ k)
    (hD : ∀ i < n, loss i ≤ D)
    (hcount : ∀ i < n, 0 < loss i → (k/2 + loss i).choose (loss i) * half i ≤ μ i)
    (hgrowth : ∀ i < n, 0 < loss i → μ (i+1) ≤ γ * half i)
    (hnormal : ∀ i < n, loss i = 0 → μ (i+1) ≤ μ i)
    (hfinal : 1 ≤ μ n) (hroot : μ 0 ≤ Pmax)
    (hstep : ∀ i < n, rank (i+1) + loss i = rank i + introCount i)
    (hrank : rank n ≤ Rmax) :
    let Q := Nat.log k (Pmax ^ 2)
    (∑ i ∈ Finset.range n, loss i) ≤ Q ∧
    (∑ i ∈ Finset.range n, introCount i) + rank 0 ≤ Rmax + Q ∧
    ((Finset.range n).filter (fun i => 0 < introCount i)).card +
      ((Finset.range n).filter (fun i => 0 < loss i)).card + rank 0 ≤ Rmax + 2 * Q := by
  dsimp only
  have hpow := rank_path_bound_from_counting k γ D Pmax μ half loss n
    hthreshold hD hcount hgrowth hnormal hfinal hroot
  have hsum := Nat.le_log_of_pow_le hk hpow
  exact ⟨hsum, rank_path_exceptional_events rank introCount loss n Rmax _ hstep hrank hsum⟩

section SignedSupport
variable {ι κ R E G : Type*} [Fintype ι] [Fintype κ]
  [Ring R] [CharZero R] [AddCommGroup E] [Module R E] [AddCommGroup G]
  [DecidableEq E] [DecidableEq G] {q k : ℕ}

/-- The per-deletion potential drop follows from the actual original signed
supports, quotient-independent lost directions, and an explicit scale comparison.
The scale comparison is the remaining input from long-sumset growth. -/
theorem rankLoss_signedPotential_squared_drop (original : ι → G) (current : ι → E)
    (h : PreservesSignedSums k original current) (keep : κ → ι)
    (W : Submodule R E) (hspan : ∀ i, current (keep i) ∈ W) (directions : Fin q → ι)
    (hind : LinearIndependent R (fun j => W.mkQ (current (directions j))))
    (γ D : ℕ) (hq : 0 < q) (hD : q ≤ D)
    (hgrowth : (k • signedAlphabet (fun i => original (keep i))).card ≤
      γ * ((k/2) • signedAlphabet (fun i => original (keep i))).card)
    (hthreshold : (2 ^ D * D.factorial * γ) ^ 2 ≤ k) :
    k ^ q * (k • signedAlphabet (fun i => original (keep i))).card ^ 2 ≤
      (k • signedAlphabet original).card ^ 2 := by
  apply potential_drop_of_half_counting _ _ _ k q γ D hq hD _ hgrowth hthreshold
  exact rankLoss_original_potential_counting original current h keep W hspan directions hind (by omega)

end SignedSupport

end
end Optss
