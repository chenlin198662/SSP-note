import Optss.FreimanCubeCoordinates
import Mathlib.Analysis.SpecificLimits.Basic

/-!
# Finite-depth proof of the two-to-the-dimension growth bound

We repeatedly use the actual cube partition. The unprocessed fraction
shrinks geometrically; all boundary losses are charged to intersections
with genuine affine hyperplanes. No growth or concentration theorem is
assumed as an input.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 1000000
local instance freimanDimensionGrowthDecEqRealVec (n : ℕ) : DecidableEq (Fin n → ℝ) := Classical.decEq _

def freimanDepthCoverage (c : ℝ) : ℕ → ℝ
  | 0 => 0
  | L+1 => c+(1-c)*freimanDepthCoverage c L

def freimanDepthError (n : ℕ) : ℕ → ℝ
  | 0 => 0
  | L+1 => 2*n+(3:ℝ)^n*freimanDepthError n L

theorem freimanDepthCoverage_eq (c : ℝ) (L : ℕ) :
    freimanDepthCoverage c L = 1-(1-c)^L := by
  induction L with
  | zero => simp [freimanDepthCoverage]
  | succ L ih => rw [freimanDepthCoverage, ih, pow_succ]; ring

theorem freimanDepthCoverage_bounds (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c ≤ 1) (L : ℕ) :
    0 ≤ freimanDepthCoverage c L ∧ freimanDepthCoverage c L ≤ 1 := by
  induction L with
  | zero => simp [freimanDepthCoverage]
  | succ L ih =>
    rw [freimanDepthCoverage]
    constructor
    · exact add_nonneg hc0 (mul_nonneg (sub_nonneg.mpr hc1) ih.1)
    · nlinarith

theorem freimanDepthError_nonneg (n L : ℕ) : 0 ≤ freimanDepthError n L := by
  induction L with
  | zero => simp [freimanDepthError]
  | succ L ih => simp only [freimanDepthError]; positivity

theorem freimanDepthError_step (n : ℕ) (hn : 0 < n) (L : ℕ) :
    freimanDepthError n L + 1 ≤ freimanDepthError n (L+1) := by
  have hn' : (1:ℝ) ≤ n := by exact_mod_cast hn
  have hp : (1:ℝ) ≤ 3^n := one_le_pow₀ (by norm_num)
  have he := freimanDepthError_nonneg n L
  rw [freimanDepthError]
  nlinarith

theorem generalFreimanCubeFraction_le_one (n : ℕ) (hn : 0 < n)
    (τ : ℝ) (hτ : 1 ≤ τ) : generalFreimanCubeFraction n τ ≤ 1 := by
  obtain ⟨r, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hn)
  have hh := freimanCubeFraction_le_third r (τ^2)
  apply (div_le_iff₀ (by linarith : 0 < τ)).mpr
  simp only [one_mul]
  exact hh.trans (by linarith)

/-- Quantitative finite-depth lower bound on the actual sumset. The only
input bound concerns actual intersections with every affine hyperplane. -/
theorem freiman_finite_depth_growth (n : ℕ) (hn : 0 < n) (L : ℕ)
    (S : Finset (Fin n → ℝ)) (H : ℕ) (hH : hyperplaneMassBound S H) :
    (2:ℝ)^n * (freimanDepthCoverage (generalFreimanCubeFraction n (2^n)) L * S.card -
      freimanDepthError n L * H) ≤ (S+S).card := by
  let c := generalFreimanCubeFraction n (2^n)
  have hD0 : (0:ℝ) < 2^n := by positivity
  have hD1 : (1:ℝ) ≤ 2^n := one_le_pow₀ (by norm_num)
  have hc0 : 0 < c := generalFreimanCubeFraction_pos n _ hD0
  have hc1 : c ≤ 1 := generalFreimanCubeFraction_le_one n hn _ hD1
  change (2:ℝ)^n * (freimanDepthCoverage c L * S.card - freimanDepthError n L * H) ≤ _
  induction L generalizing S with
  | zero => simp [freimanDepthCoverage, freimanDepthError]
  | succ L ih =>
    have ha := freimanDepthCoverage_bounds c hc0.le hc1 L
    have ha' := freimanDepthCoverage_bounds c hc0.le hc1 (L+1)
    have he := freimanDepthError_nonneg n L
    have he' := freimanDepthError_nonneg n (L+1)
    have heStep := freimanDepthError_step n hn L
    have hS0 : (0:ℝ) ≤ S.card := by positivity
    have hH0 : (0:ℝ) ≤ H := by positivity
    by_cases hlow : ((S+S).card : ℝ) ≤ (2:ℝ)^n * S.card
    · by_cases hS : S.Nonempty
      · rcases freimanCubePartition_alternative n hn S hS (2^n) hD0 hlow H hH with
          hdeg | ⟨T, hTcard, hTT, hTH, hvertices, hclosed⟩
        · have hprev := ih S hH
          have hcov : (freimanDepthCoverage c (L+1) - freimanDepthCoverage c L) * S.card ≤ H := by
            change c*S.card ≤ (H:ℝ) at hdeg
            rw [freimanDepthCoverage]
            nlinarith [mul_nonneg ha.1 hc0.le]
          have herror : (freimanDepthError n (L+1)-freimanDepthError n L)*(H:ℝ) ≥ H := by
            nlinarith
          have hinside : freimanDepthCoverage c (L+1)*S.card-freimanDepthError n (L+1)*H ≤
              freimanDepthCoverage c L*S.card-freimanDepthError n L*H := by linarith
          exact (mul_le_mul_of_nonneg_left hinside hD0.le).trans hprev
        · let I := (unitCubeInterior T).card
          let J := ∑ σ ∈ unitCubeOuterIndices n, (unitCubeCell T σ).card
          let p := (unitCubeOuterIndices n).card
          have hpartition : I+J = S.card := by
            simpa only [I, J, hTcard] using unitCubeCell_outer_card_sum T
          have hpartitionR : (I:ℝ)+(J:ℝ) = S.card := by exact_mod_cast hpartition
          have hboundary := unitCubeClosed_card_le_interior T H
            (hyperplaneMassBound_coordinate_faces T H hTH)
          have hI : c*S.card ≤ I+(2:ℝ)*n*H := by
            have hh : ((unitCubeClosed T).card:ℝ) ≤ I+(2:ℝ)*n*H := by exact_mod_cast hboundary
            exact hclosed.trans hh
          have hchildren :
              ∑ σ ∈ unitCubeOuterIndices n,
                (2:ℝ)^n * (freimanDepthCoverage c L*(unitCubeCell T σ).card-freimanDepthError n L*H) ≤
              ∑ σ ∈ unitCubeOuterIndices n, ((unitCubeCell T σ+unitCubeCell T σ).card:ℝ) := by
            apply Finset.sum_le_sum
            intro σ _
            exact ih _ (hyperplaneMassBound_subset T _ H (unitCubeCell_subset T σ) hTH)
          have hsum : (∑ σ ∈ unitCubeOuterIndices n,
              (2:ℝ)^n * (freimanDepthCoverage c L*(unitCubeCell T σ).card-freimanDepthError n L*H)) =
              (2:ℝ)^n * (freimanDepthCoverage c L*J-p*freimanDepthError n L*H) := by
            simp only [mul_sub, Finset.sum_sub_distrib, ← Finset.mul_sum, Finset.sum_const,
              nsmul_eq_mul, J, Nat.cast_sum]
            ring
          rw [hsum] at hchildren
          have hcount := unitCube_partition_sumset_bound T hvertices
          have hcountR : (2:ℝ)^n*I +
              (∑ σ ∈ unitCubeOuterIndices n, ((unitCubeCell T σ+unitCubeCell T σ).card:ℝ)) ≤
                ((S+S).card:ℝ) := by
            rw [← hTT]
            exact_mod_cast hcount
          have hp : (p:ℝ) ≤ (3:ℝ)^n := by
            have hh : p ≤ 3^n := by
              change (unitCubeOuterIndices n).card ≤ 3^n
              rw [unitCubeOuterIndices_card]
              exact Nat.sub_le _ _
            exact_mod_cast hh
          have herror : (p:ℝ)*freimanDepthError n L*H ≤ (3:ℝ)^n*freimanDepthError n L*H :=
            mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hp he) hH0
          have hcov : freimanDepthCoverage c (L+1)*S.card-freimanDepthError n (L+1)*H ≤
              I+freimanDepthCoverage c L*J-p*freimanDepthError n L*H := by
            rw [freimanDepthCoverage, freimanDepthError]
            have hh := mul_le_mul_of_nonneg_left hI (sub_nonneg.mpr ha.2)
            have hbound : (0:ℝ) ≤ 2*n*H := by positivity
            nlinarith
          have hcombined : (2:ℝ)^n * (I+freimanDepthCoverage c L*J-p*freimanDepthError n L*H) ≤
              ((S+S).card:ℝ) := by linarith
          exact (mul_le_mul_of_nonneg_left hcov hD0.le).trans hcombined
      · have hSE : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hS
        simp only [hSE, Finset.card_empty, Nat.cast_zero, mul_zero, zero_sub, Finset.empty_add]
        exact mul_nonpos_of_nonneg_of_nonpos hD0.le (neg_nonpos.mpr (mul_nonneg he' hH0))
    · have hinside : freimanDepthCoverage c (L+1)*S.card-freimanDepthError n (L+1)*H ≤ S.card := by
        nlinarith
      exact (mul_le_mul_of_nonneg_left hinside hD0.le).trans (le_of_lt (lt_of_not_ge hlow))

end
end Optss
