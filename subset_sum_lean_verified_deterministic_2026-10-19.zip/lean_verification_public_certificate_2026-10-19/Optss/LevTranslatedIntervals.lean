import Optss.IntegerFiberNormalization

/-!
# Lev's interval theorem for arbitrary translated integer sets

This adapter proves translation and common-dilation identities for actual
finite sumsets, and removes the minimum-zero convention from the interval
corollary. The aperiodicity hypothesis explicitly excludes containment in
any translate of `vℤ` for integers `v > 1`.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

/-- Affine images commute with Minkowski addition when the dilation is
common and the translations are added. -/
theorem integer_affine_image_add (A B : Finset ℤ) (a b v : ℤ) :
    A.image (fun x => a + v * x) + B.image (fun x => b + v * x) =
      (A + B).image (fun x => (a + b) + v * x) := by
  ext z
  constructor
  · intro hz
    obtain ⟨x, hx, y, hy, rfl⟩ := Finset.mem_add.mp hz
    obtain ⟨s, hs, rfl⟩ := Finset.mem_image.mp hx
    obtain ⟨t, ht, rfl⟩ := Finset.mem_image.mp hy
    exact Finset.mem_image.mpr ⟨s + t, Finset.add_mem_add hs ht, by ring⟩
  · intro hz
    obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hz
    obtain ⟨s, hs, t, ht, rfl⟩ := Finset.mem_add.mp hx
    exact Finset.mem_add.mpr ⟨a + v * s, Finset.mem_image.mpr ⟨s, hs, rfl⟩,
      b + v * t, Finset.mem_image.mpr ⟨t, ht, rfl⟩, by ring⟩

/-- Exact finite-list affine reconstruction. -/
theorem integer_affine_image_list_sum {α : Type*} (L : List α)
    (A : α → Finset ℤ) (a : α → ℤ) (v : ℤ) :
    (L.map (fun p => (A p).image (fun x => a p + v * x))).sum =
      (L.map A).sum.image (fun x => (L.map a).sum + v * x) := by
  induction L with
  | nil => simp; rfl
  | cons p L ih =>
    simp only [List.map_cons, List.sum_cons, ih]
    exact integer_affine_image_add _ _ _ _ _

/-- Translating an actual contained interval translates both endpoints. -/
theorem integer_translate_interval (S : Finset ℤ) (a b t : ℤ)
    (h : Finset.Icc a b ⊆ S) :
    Finset.Icc (t + a) (t + b) ⊆ S.image (fun x => t + x) := by
  intro x hx
  obtain ⟨hlo, hhi⟩ := Finset.mem_Icc.mp hx
  exact Finset.mem_image.mpr ⟨x - t, h (Finset.mem_Icc.mpr ⟨by omega, by omega⟩), by omega⟩

private theorem lev_normalize_list (L : List (Finset ℤ)) (n W : ℕ) (hn : 2 ≤ n)
    (hcard : ∀ A ∈ L, n ≤ A.card)
    (hbox : ∀ A ∈ L, ∃ u : ℤ, A ⊆ Finset.Icc u (u + W))
    (haper : ∀ A ∈ L, IntegerAperiodic A) :
    ∃ (D : List (ℤ × (Finset ℤ × ℕ))),
      D.length = L.length ∧
      (∀ p ∈ D, LevNormalized p.2.1 p.2.2 ∧ n ≤ p.2.1.card ∧ p.2.2 ≤ W) ∧
      L.sum = (D.map (fun p : ℤ × (Finset ℤ × ℕ) => p.2.1)).sum.image (fun x => (D.map Prod.fst).sum + x) := by
  induction L with
  | nil => exact ⟨[], by simp, by simp, by simp; rfl⟩
  | cons A L ih =>
    obtain ⟨D, hlen, hD, hsum⟩ := ih
      (fun B hB => hcard B (by simp [hB])) (fun B hB => hbox B (by simp [hB]))
      (fun B hB => haper B (by simp [hB]))
    obtain ⟨u, hu⟩ := hbox A (by simp)
    obtain ⟨a, l, B, hnorm, hBc, hA, hW⟩ := integer_aperiodic_normalization A u W
      (hn.trans (hcard A (by simp))) hu (haper A (by simp))
    refine ⟨(a, B, l) :: D, by simp [hlen], ?_, ?_⟩
    · intro p hp
      rcases List.mem_cons.mp hp with rfl | hp
      · exact ⟨hnorm, by rw [hBc]; exact hcard A (by simp), hW⟩
      · exact hD p hp
    · simp only [List.sum_cons, List.map_cons, hsum, hA]
      simpa only [one_mul] using integer_affine_image_add B
        ((D.map (fun p : ℤ × (Finset ℤ × ℕ) => p.2.1)).sum) a ((D.map Prod.fst).sum) 1

/-- The complete integer-set form of Lev 2010 Corollary 1 / CFP Lemma
2.10. Width means diameter; hence the interval has at least
`L.length * (n-1) + 1` elements. -/
theorem lev_translated_interval_corollary (L : List (Finset ℤ)) (n W : ℕ)
    (hn : 3 ≤ n) (hW : 2 ≤ W)
    (hcount : 2 * ((W - 2) / (n - 2) + 1) ≤ L.length)
    (hcard : ∀ A ∈ L, n ≤ A.card)
    (hbox : ∀ A ∈ L, ∃ u : ℤ, A ⊆ Finset.Icc u (u + W))
    (haper : ∀ A ∈ L, IntegerAperiodic A) :
    ∃ a b : ℤ, Finset.Icc a b ⊆ L.sum ∧
      (L.length : ℤ) * ((n : ℤ) - 1) ≤ b - a ∧
      L.length * (n - 1) + 1 ≤ (Finset.Icc a b).card := by
  obtain ⟨D, hlen, hD, hsum⟩ := lev_normalize_list L n W (by omega) hcard hbox haper
  obtain ⟨a, b, hI, hlong⟩ := lev_interval_corollary_width (D.map Prod.snd) n W hn hW
    (by simpa [hlen] using hcount)
    (by intro p hp; obtain ⟨q, hq, rfl⟩ := List.mem_map.mp hp; exact (hD q hq).1)
    (by intro p hp; obtain ⟨q, hq, rfl⟩ := List.mem_map.mp hp; exact (hD q hq).2.1)
    (by intro p hp; obtain ⟨q, hq, rfl⟩ := List.mem_map.mp hp; exact (hD q hq).2.2)
  simp only [List.length_map, hlen] at hlong
  simp only [List.map_map, Function.comp_def] at hI
  let t := (D.map Prod.fst).sum
  refine ⟨t + a, t + b, ?_, by omega, ?_⟩
  · rw [hsum]
    exact integer_translate_interval _ a b t hI
  · rw [Int.card_Icc]
    have hn' : ((n - 1 : ℕ) : ℤ) = (n : ℤ) - 1 := by omega
    have hc : ((L.length * (n - 1) : ℕ) : ℤ) ≤ b - a := by
      rw [Nat.cast_mul, hn']; exact hlong
    omega

end
end Optss
