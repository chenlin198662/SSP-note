import Optss.ComputedProgressionLift
import Optss.FreimanDescriptionBounds
import Optss.StoredTranslateCover

/-! Direct entry-bit bounds for the actual inverse-table and cover outputs. -/
namespace Optss
open scoped BigOperators Pointwise
variable {r p : ℕ}

theorem computedLiftHom_single (table : Array (Option ℤ)) (ρ : IntVec r→+ZMod p)
    (β : Fin r→ℕ) (j : Fin r) :
    computedLiftHom table ρ β (Pi.single j 1)=(computedLiftGeneratorData table ρ β).toVector.get j :=
  gridLinearPart_single _ j

theorem computedLiftHom_entry_bounds (table : Array (Option ℤ)) (ρ : IntVec r→+ZMod p)
    (β : Fin r→ℕ) (U : ℕ)
    (hproper : Set.InjOn (computedLiftHom table ρ β) (integerBudgetBox β))
    (hbound : ∀ x∈integerProgressionValues (computedLiftHom table ρ β) β,|x|≤(U:ℤ)) (j : Fin r) :
    |(computedLiftGeneratorData table ρ β).toVector.get j|≤(U:ℤ) ∧ β j≤U := by
  by_cases hj : β j=0
  · simp [computedLiftGeneratorData_get,hj]
  · have hh := integer_progression_active_bounds (computedLiftHom table ρ β) β hproper U hbound j
      (Nat.pos_of_ne_zero hj)
    rw [computedLiftHom_single] at hh
    exact hh.2

theorem computedLiftHom_description_bits (table : Array (Option ℤ)) (ρ : IntVec r→+ZMod p)
    (β : Fin r→ℕ) (S : Finset ℤ) (u : ℕ) (hS : ∀ a∈S,0≤a ∧ a≤u)
    (hproper : Set.InjOn (computedLiftHom table ρ β) (integerBudgetBox β))
    (hP : integerProgressionValues (computedLiftHom table ρ β) β⊆(S+S)-(S+S)) (j : Fin r) :
    ((computedLiftGeneratorData table ρ β).toVector.get j).natAbs.size≤(u+2).size+2 ∧
      (β j).size≤(u+2).size+2 := by
  have hh := computedLiftHom_entry_bounds table ρ β (2*u) hproper
    (fun x hx => double_difference_interval_bound S u hS (hP hx)) j
  have hab : ((computedLiftGeneratorData table ρ β).toVector.get j).natAbs≤2*u := by
    have h := hh.1
    rw [←Int.natCast_natAbs] at h
    exact_mod_cast h
  exact ⟨interval_description_bits u _ (by omega),interval_description_bits u _ (by omega)⟩

theorem computedLiftCover_entry_bounds (table : Array (Option ℤ)) (ρ : IntVec r→+ZMod p)
    (β : Fin r→ℕ) (input : List ℤ) (u : ℕ) (hS : ∀ a∈input,0≤a ∧ a≤u)
    (hproper : Set.InjOn (computedLiftHom table ρ β) (integerBudgetBox β))
    (hP : integerProgressionValues (computedLiftHom table ρ β) β⊆
      (input.toFinset+input.toFinset)-(input.toFinset+input.toFinset))
    (differences : List ℤ) (B : ℕ)
    (hD : differences.toFinset=integerProgressionValues (computedLiftHom table ρ β) β-
      integerProgressionValues (computedLiftHom table ρ β) β)
    (hB : ∀ x∈differences,|x|≤B) :
    let T := storedTranslateCover differences B input
    ∀ j, |appendProgressionHom (computedLiftHom table ρ β) (listTranslationGenerators T) (Pi.single j 1)|≤(2*u:ℕ) ∧
      appendProgressionWidths β T.length j≤4*u+1 ∧
      (appendProgressionHom (computedLiftHom table ρ β) (listTranslationGenerators T) (Pi.single j 1)).natAbs.size≤(u+2).size+2 ∧
      (appendProgressionWidths β T.length j).size≤(u+2).size+2 := by
  intro T j
  have hs : ∀ a∈input.toFinset,0≤a ∧ a≤u := fun a ha => hS a (List.mem_toFinset.mp ha)
  have hb := computedLiftHom_entry_bounds table ρ β (2*u) hproper
    (fun x hx => double_difference_interval_bound input.toFinset u hs (hP hx))
  have hsub := (storedTranslateCover_spec _ ((integerBudgetBox_nonempty β).image _)
    differences B input hD hB).2.1
  have hgen (k : Fin T.length) : |listTranslationGenerators T k|≤(2*u:ℕ) := by
    have hm : listTranslationGenerators T k∈T.toFinset := by
      exact List.mem_toFinset.mpr (List.get_mem T k)
    have hh := hs _ (hsub hm)
    rw [abs_of_nonneg hh.1]
    omega
  have he := appendProgression_entry_bounds (computedLiftHom table ρ β) β
    (listTranslationGenerators T) (2*u)
    (fun k => by rw [computedLiftHom_single]; exact (hb k).1) (fun k => (hb k).2) hgen j
  have ha : (appendProgressionHom (computedLiftHom table ρ β) (listTranslationGenerators T) (Pi.single j 1)).natAbs≤2*u := by
    have h := he.1
    rw [←Int.natCast_natAbs] at h
    exact_mod_cast h
  refine ⟨he.1,by omega,interval_description_bits u _ (by omega),interval_description_bits u _ (by omega)⟩
end Optss
