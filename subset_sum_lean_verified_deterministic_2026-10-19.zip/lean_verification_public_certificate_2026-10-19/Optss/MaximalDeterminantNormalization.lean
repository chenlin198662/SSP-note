import Mathlib.Analysis.Convex.Combination
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.LinearAlgebra.Determinant
import Mathlib.LinearAlgebra.LinearIndependent.Lemmas
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Finset.Max
import Mathlib.Tactic

/-!
# Normalization by a maximum-determinant vertex basis

The basis is selected from the finite vertex set itself. Its determinant is
maximal among all vertex tuples, so replacing one column bounds every vertex
coordinate by one. Symmetry supplies both signs of each coordinate vector.
An explicit convex combination then places the cube of radius `1 / r` inside
the normalized convex hull. No lattice algorithm or complexity claim is made.
-/

namespace Optss
open scoped BigOperators Classical
noncomputable section

section BasisSelection
variable {E : Type*} [AddCommGroup E] [Module ℝ E] {r : ℕ}

/-- A finite spanning set contains an actual basis with the prescribed dimension. -/
theorem exists_vertex_basis (e₀ : Basis (Fin r) ℝ E) (S : Finset E)
    (hspan : Submodule.span ℝ (S : Set E) = ⊤) :
    ∃ b : Basis (Fin r) ℝ E, ∀ j, b j ∈ S := by
  let v : S → E := Subtype.val
  obtain ⟨κ, a, ha, hsp, hli⟩ := exists_linearIndependent' ℝ v
  letI : Finite κ := Finite.of_injective a ha
  letI : Fintype κ := Fintype.ofFinite κ
  have hsp' : Submodule.span ℝ (Set.range (v ∘ a)) = ⊤ := by
    rw [hsp]
    simpa [v] using hspan
  let b : Basis κ ℝ E := Basis.mk hli hsp'.ge
  have hcard : Fintype.card κ = r := by
    rw [← Module.finrank_eq_card_basis b, Module.finrank_eq_card_basis e₀, Fintype.card_fin]
  let e : κ ≃ Fin r := (Fintype.equivFin κ).trans (finCongr hcard)
  refine ⟨b.reindex e, fun j => ?_⟩
  simp [b, v, (a (e.symm j)).property]

/-- The maximum is attained among finite vertex tuples, and is nonzero because
at least one tuple is a basis. Consequently its entries are distinct. -/
theorem exists_maximal_determinant_vertex_basis (e₀ : Basis (Fin r) ℝ E)
    (S : Finset E) (hspan : Submodule.span ℝ (S : Set E) = ⊤) :
    ∃ b : Basis (Fin r) ℝ E,
      (∀ j, b j ∈ S) ∧ e₀.det b ≠ 0 ∧
      (∀ v : Fin r → E, (∀ j, v j ∈ S) → |e₀.det v| ≤ |e₀.det b|) ∧
      Function.Injective b := by
  obtain ⟨b₀, hb₀⟩ := exists_vertex_basis e₀ S hspan
  let T := Fintype.piFinset (fun _ : Fin r => S)
  have hb₀T : (fun j => b₀ j) ∈ T := Fintype.mem_piFinset.mpr hb₀
  obtain ⟨v, hv, hmax⟩ := T.exists_max_image (fun v => |e₀.det v|) ⟨_, hb₀T⟩
  have hv0 : e₀.det v ≠ 0 := by
    have hpos := abs_pos.mpr (e₀.isUnit_det b₀).ne_zero
    exact abs_pos.mp (hpos.trans_le (hmax _ hb₀T))
  obtain ⟨hli, hsp⟩ := (is_basis_iff_det e₀).mpr (isUnit_iff_ne_zero.mpr hv0)
  let b : Basis (Fin r) ℝ E := Basis.mk hli hsp.ge
  have hb : ⇑b = v := Basis.coe_mk _ _
  refine ⟨b, ?_, ?_, ?_, b.injective⟩
  · simpa only [hb] using Fintype.mem_piFinset.mp hv
  · simpa only [hb] using hv0
  · intro w hw
    simpa only [hb] using hmax w (Fintype.mem_piFinset.mpr hw)

/-- Cramer's replacement-column identity in an arbitrary reference basis. -/
theorem vertex_basis_det_update (e₀ b : Basis (Fin r) ℝ E) (x : E) (j : Fin r) :
    e₀.det (Function.update b j x) = e₀.det b * b.equivFun x j := by
  have h := congrArg (fun f : E →ₗ[ℝ] ℝ => f x)
    (e₀.det_smul_mk_coord_eq_det_update b.linearIndependent b.span_eq.ge j)
  have hmk : Basis.mk b.linearIndependent b.span_eq.ge = b := by ext i; simp
  simpa only [hmk, LinearMap.smul_apply, smul_eq_mul, Basis.coord_apply,
    Basis.equivFun_apply, MultilinearMap.toLinearMap_apply] using h.symm

/-- Maximality alone proves the absolute coordinate bound by replacing one
basis vertex at a time. -/
theorem maximal_determinant_vertex_coordinates (e₀ b : Basis (Fin r) ℝ E)
    (S : Finset E) (hb : ∀ j, b j ∈ S)
    (hmax : ∀ v : Fin r → E, (∀ j, v j ∈ S) → |e₀.det v| ≤ |e₀.det b|)
    {x : E} (hx : x ∈ S) (j : Fin r) : |b.equivFun x j| ≤ 1 := by
  have hu : ∀ i, Function.update b j x i ∈ S := by
    intro i
    by_cases hi : i = j
    · subst i; simpa using hx
    · simpa [Function.update_of_ne hi] using hb i
  have h := hmax (Function.update b j x) hu
  rw [vertex_basis_det_update, abs_mul] at h
  have hpos : 0 < |e₀.det b| := abs_pos.mpr (e₀.isUnit_det b).ne_zero
  nlinarith

end BasisSelection

/-- The coordinate cube in a finite real function space. -/
def coordinateCube (r : ℕ) (a : ℝ) : Set (Fin r → ℝ) := {x | ∀ j, |x j| ≤ a}

/-- Coordinate cubes are convex, including empty cubes when the radius is negative. -/
theorem convex_coordinateCube (r : ℕ) (a : ℝ) : Convex ℝ (coordinateCube r a) := by
  have heq : coordinateCube r a = Set.Icc (fun _ => -a) (fun _ => a) := by
    ext x
    simp only [coordinateCube, Set.mem_setOf_eq, Set.mem_Icc, Pi.le_def, abs_le]
    exact forall_and
  rw [heq]
  exact convex_Icc _ _

/-- An explicit average of points on the signed coordinate axes fills the
cube of radius `1/r`. This is the elementary cross-polytope inclusion. -/
theorem small_cube_subset_convex_of_signed_axes {r : ℕ} (hr : 0 < r)
    (K : Set (Fin r → ℝ)) (hK : Convex ℝ K)
    (hpos : ∀ j : Fin r, Pi.single j (1 : ℝ) ∈ K)
    (hneg : ∀ j : Fin r, -Pi.single j (1 : ℝ) ∈ K) :
    coordinateCube r (1/(r:ℝ)) ⊆ K := by
  intro x hx
  have hrR : (0 : ℝ) < r := by exact_mod_cast hr
  let w : Fin r × Bool → ℝ := fun p =>
    if p.2 then (1/(r:ℝ) + x p.1)/2 else (1/(r:ℝ) - x p.1)/2
  let z : Fin r × Bool → (Fin r → ℝ) := fun p =>
    if p.2 then Pi.single p.1 1 else -Pi.single p.1 1
  have hw : ∀ p ∈ Finset.univ, 0 ≤ w p := by
    rintro ⟨j, t⟩ _
    have hj := (abs_le.mp (hx j))
    cases t <;> dsimp [w] <;> linarith
  have hsum : ∑ p : Fin r × Bool, w p = 1 := by
    rw [Fintype.sum_prod_type]
    simp only [w, Fintype.sum_bool, Bool.false_eq_true, ↓reduceIte]
    have heach (j : Fin r) :
        (1/(r:ℝ) + x j)/2 + (1/(r:ℝ) - x j)/2 = 1/(r:ℝ) := by ring
    simp_rw [heach]
    simp [ne_of_gt hrR]
  have hz : ∀ p ∈ Finset.univ, z p ∈ K := by
    rintro ⟨j, t⟩ _
    cases t
    · exact hneg j
    · exact hpos j
  have hrepr : ∑ p : Fin r × Bool, w p • z p = x := by
    ext j
    rw [Fintype.sum_prod_type]
    simp only [Finset.sum_apply, w, z, Fintype.sum_bool, Bool.false_eq_true,
      ↓reduceIte, Pi.add_apply, Pi.smul_apply, Pi.neg_apply, smul_eq_mul]
    have heach (i : Fin r) :
        (1/(r:ℝ) + x i)/2 * (Pi.single i (1 : ℝ) : Fin r → ℝ) j +
          (1/(r:ℝ) - x i)/2 * -((Pi.single i (1 : ℝ) : Fin r → ℝ) j) =
            (Pi.single i (x i) : Fin r → ℝ) j := by
      by_cases hij : i = j
      · subst i; simp; ring
      · simp [Pi.single_apply, hij, Ne.symm hij]
    simp_rw [heach]
    simp
  rw [← hrepr]
  exact hK.sum_mem hw hsum hz


section Normalization
variable {E : Type*} [AddCommGroup E] [Module ℝ E] {r : ℕ}

/-- The coordinate image of a convex hull is exactly the convex hull of the
coordinate images, rather than merely a containing convex set. -/
theorem basis_coordinates_image_convexHull (b : Basis (Fin r) ℝ E) (S : Set E) :
    b.equivFun '' convexHull ℝ S = convexHull ℝ (b.equivFun '' S) :=
  b.equivFun.toLinearMap.image_convexHull S

/-- A maximum-determinant vertex basis normalizes every finite symmetric
spanning polytope between the cubes of radii `1/r` and `1`. -/
theorem exists_maximal_determinant_normalization (hr : 0 < r)
    (e₀ : Basis (Fin r) ℝ E) (S : Finset E)
    (hspan : Submodule.span ℝ (S : Set E) = ⊤)
    (hsym : ∀ x ∈ S, -x ∈ S) :
    ∃ b : Basis (Fin r) ℝ E,
      (∀ j, b j ∈ S) ∧ e₀.det b ≠ 0 ∧
      (∀ v : Fin r → E, (∀ j, v j ∈ S) → |e₀.det v| ≤ |e₀.det b|) ∧
      coordinateCube r (1/(r:ℝ)) ⊆ b.equivFun '' convexHull ℝ (S : Set E) ∧
      b.equivFun '' convexHull ℝ (S : Set E) ⊆ coordinateCube r 1 := by
  obtain ⟨b, hb, hdet, hmax, _⟩ := exists_maximal_determinant_vertex_basis e₀ S hspan
  refine ⟨b, hb, hdet, hmax, ?_, ?_⟩
  · apply small_cube_subset_convex_of_signed_axes hr
    · rw [basis_coordinates_image_convexHull]
      exact convex_convexHull ℝ _
    · intro j
      refine ⟨b j, subset_convexHull ℝ (S : Set E) (hb j), ?_⟩
      ext i
      simp [Basis.equivFun_self, Pi.single_apply, eq_comm]
    · intro j
      refine ⟨-b j, subset_convexHull ℝ (S : Set E) (hsym _ (hb j)), ?_⟩
      rw [map_neg]
      congr 1
      ext i
      simp [Basis.equivFun_self, Pi.single_apply, eq_comm]
  · rw [basis_coordinates_image_convexHull]
    apply convexHull_min _ (convex_coordinateCube r 1)
    rintro _ ⟨x, hx, rfl⟩ j
    exact maximal_determinant_vertex_coordinates e₀ b S hb hmax hx j

end Normalization

section EuclideanNormalization
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] {r : ℕ}

/-- A continuous Euclidean normalization, suitable for transporting compact
bodies and full lattice bases. The coordinate cubes here use the actual
Euclidean coordinates and need no separately assumed normalization map. -/
theorem exists_euclidean_vertex_normalization (hr : 0 < r)
    (e₀ : Basis (Fin r) ℝ E) (S : Finset E)
    (hspan : Submodule.span ℝ (S : Set E) = ⊤)
    (hsym : ∀ x ∈ S, -x ∈ S) :
    ∃ e : E ≃L[ℝ] EuclideanSpace ℝ (Fin r),
      {x | ∀ j, |x j| ≤ 1/(r:ℝ)} ⊆ e '' convexHull ℝ (S : Set E) ∧
      e '' convexHull ℝ (S : Set E) ⊆ {x | ∀ j, |x j| ≤ 1} ∧
      e '' convexHull ℝ (S : Set E) = convexHull ℝ (e '' (S : Set E)) := by
  letI := FiniteDimensional.of_fintype_basis e₀
  obtain ⟨b, _, _, _, hinner, houter⟩ :=
    exists_maximal_determinant_normalization hr e₀ S hspan hsym
  let e : E ≃L[ℝ] EuclideanSpace ℝ (Fin r) :=
    b.equivFun.toContinuousLinearEquiv.trans (EuclideanSpace.equiv (Fin r) ℝ).symm
  have he (x : E) (j : Fin r) : e x j = b.equivFun x j := rfl
  refine ⟨e, ?_, ?_, e.toLinearMap.image_convexHull (S : Set E)⟩
  · intro x hx
    have hxc : (fun j => x j) ∈ coordinateCube r (1/(r:ℝ)) := hx
    obtain ⟨y, hy, heq⟩ := hinner hxc
    refine ⟨y, hy, ?_⟩
    ext j
    exact congrFun heq j
  · rintro _ ⟨x, hx, rfl⟩ j
    exact houter ⟨x, hx, rfl⟩ j


/-- In standard Euclidean space the reference basis is canonical, so a finite
symmetric spanning vertex set and positive dimension are the only inputs. -/
theorem finite_symmetric_polytope_normalization {r : ℕ} (hr : 0 < r)
    (S : Finset (EuclideanSpace ℝ (Fin r)))
    (hspan : Submodule.span ℝ (S : Set (EuclideanSpace ℝ (Fin r))) = ⊤)
    (hsym : ∀ x ∈ S, -x ∈ S) :
    ∃ e : EuclideanSpace ℝ (Fin r) ≃L[ℝ] EuclideanSpace ℝ (Fin r),
      {x | ∀ j, |x j| ≤ 1/(r:ℝ)} ⊆ e '' convexHull ℝ (S : Set _) ∧
      e '' convexHull ℝ (S : Set _) ⊆ {x | ∀ j, |x j| ≤ 1} ∧
      e '' convexHull ℝ (S : Set _) = convexHull ℝ (e '' (S : Set _)) :=
  exists_euclidean_vertex_normalization hr (EuclideanSpace.basisFun (Fin r) ℝ).toBasis
    S hspan hsym

end EuclideanNormalization

end
end Optss
