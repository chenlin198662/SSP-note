import Optss.ExecutablePrimitiveQuotient

/-!
# An explicit full basis map for a modular integer kernel

Eliminating the augmented coefficient vector `(M,a)` gives an integral
basis of its exact kernel. Dropping its leading coordinate produces the
whole congruence lattice `{x : M ∣ a · x}`. This supplies the lattice used
by short-relation search, without an integer-programming oracle.
-/
namespace Optss
open scoped BigOperators
variable {d : ℕ}

def integerTransposeLinear {m n : ℕ} (f : (Fin m→ℤ) →ₗ[ℤ] (Fin n→ℤ)) :
    (Fin n→ℤ) →ₗ[ℤ] (Fin m→ℤ) where
  toFun x i := ∑ j, f (Pi.single i 1) j*x j
  map_add' x y := by ext i; simp [mul_add,Finset.sum_add_distrib]
  map_smul' a x := by ext i; simp [Finset.mul_sum,mul_left_comm,mul_assoc]

theorem integerTransposeLinear_pairing {m n : ℕ}
    (f : (Fin m→ℤ) →ₗ[ℤ] (Fin n→ℤ)) (a : Fin m→ℤ) (x : Fin n→ℤ) :
    (∑ i,a i*integerTransposeLinear f x i)=∑ j,f a j*x j := by
  have ha : a=∑ i,a i •(Pi.single i (1:ℤ) : Fin m→ℤ) := by
    ext i; simp [Finset.sum_apply,Pi.single_apply,Pi.smul_apply]
  conv_rhs => rw [ha,map_sum]
  simp only [integerTransposeLinear,LinearMap.coe_mk,AddHom.coe_mk,Finset.sum_apply,
    map_smul,Pi.smul_apply,smul_eq_mul,Finset.mul_sum,Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j _
  apply Finset.sum_congr rfl
  intro i _
  ring

def integerTransposeEquiv (e : (Fin d→ℤ) ≃ₗ[ℤ] (Fin d→ℤ)) :
    (Fin d→ℤ) ≃ₗ[ℤ] (Fin d→ℤ) where
  __ := integerTransposeLinear e.toLinearMap
  invFun := integerTransposeLinear e.symm.toLinearMap
  left_inv x := by
    ext i
    change (∑ j,e.symm (Pi.single i 1) j*integerTransposeLinear e.toLinearMap x j)=x i
    rw [integerTransposeLinear_pairing]
    simp [Pi.single_apply]
  right_inv x := by
    ext i
    change (∑ j,e (Pi.single i 1) j*integerTransposeLinear e.symm.toLinearMap x j)=x i
    rw [integerTransposeLinear_pairing]
    simp [Pi.single_apply]

@[simp] theorem integerTransposeEquiv_pairing (e : (Fin d→ℤ) ≃ₗ[ℤ] (Fin d→ℤ))
    (a x : Fin d→ℤ) :
    (∑ i,a i*integerTransposeEquiv e x i)=∑ j,e a j*x j :=
  integerTransposeLinear_pairing e.toLinearMap a x

def integerHeadTail : (Fin (d+1)→ℤ) ≃ₗ[ℤ] (ℤ×(Fin d→ℤ)) :=
  (Fin.consLinearEquiv ℤ (fun _ : Fin (d+1) => ℤ)).symm

def integerTail : (Fin (d+1)→ℤ) →ₗ[ℤ] (Fin d→ℤ) :=
  (LinearMap.snd ℤ ℤ (Fin d→ℤ)).comp integerHeadTail.toLinearMap

def integerPrependZero : (Fin d→ℤ) →ₗ[ℤ] (Fin (d+1)→ℤ) :=
  integerHeadTail.symm.toLinearMap.comp (LinearMap.inr ℤ ℤ (Fin d→ℤ))

def augmentedKernelEquiv (a : Fin d→ℤ) (M : ℤ) :
    (Fin (d+1)→ℤ) ≃ₗ[ℤ] (Fin (d+1)→ℤ) :=
  integerTransposeEquiv (integerDirectionEquiv (Fin.cons M a))

def congruenceLatticeMap (a : Fin d→ℤ) (M : ℤ) : (Fin d→ℤ) →ₗ[ℤ] (Fin d→ℤ) :=
  integerTail.comp ((augmentedKernelEquiv a M).toLinearMap.comp integerPrependZero)

theorem augmentedKernelEquiv_pairing (a : Fin d→ℤ) (M : ℤ) (y : Fin (d+1)→ℤ) :
    M*(augmentedKernelEquiv a M y) 0+
      (∑ j,a j*(augmentedKernelEquiv a M y) j.succ)=
      executableDirectionFactor (Fin.cons M a)*y 0 := by
  have h := integerTransposeEquiv_pairing (integerDirectionEquiv (Fin.cons M a)) (Fin.cons M a) y
  rw [Fin.sum_univ_succ,Fin.sum_univ_succ] at h
  simp only [Fin.cons_zero,Fin.cons_succ,integerDirectionEquiv_tail,zero_mul,Finset.sum_const_zero,add_zero] at h
  exact h

theorem congruenceLatticeMap_mem (a : Fin d→ℤ) (M : ℤ) (w : Fin d→ℤ) :
    M ∣ ∑ j,a j*congruenceLatticeMap a M w j := by
  have h := augmentedKernelEquiv_pairing a M (integerPrependZero w)
  change M*(augmentedKernelEquiv a M (integerPrependZero w)) 0+
      (∑ j,a j*congruenceLatticeMap a M w j)=executableDirectionFactor (Fin.cons M a)*0 at h
  refine ⟨-(augmentedKernelEquiv a M (integerPrependZero w) 0),?_⟩
  linarith

theorem congruenceLatticeMap_injective (a : Fin d→ℤ) (M : ℤ) (hM : M≠0) :
    Function.Injective (congruenceLatticeMap a M) := by
  apply (injective_iff_map_eq_zero _).mpr
  intro w hw
  have h := augmentedKernelEquiv_pairing a M (integerPrependZero w)
  have htail : ∀ j : Fin d,(augmentedKernelEquiv a M (integerPrependZero w)) j.succ=0 :=
    fun j => congrFun hw j
  have hzero : augmentedKernelEquiv a M (integerPrependZero w)=0 := by
    ext j
    refine Fin.cases ?_ (fun k => htail k) j
    simp only [htail,mul_zero,Finset.sum_const_zero,add_zero] at h
    change M*(augmentedKernelEquiv a M (integerPrependZero w)) 0=executableDirectionFactor (Fin.cons M a)*0 at h
    rw [mul_zero] at h
    exact (mul_eq_zero.mp h).resolve_left hM
  have hpre : integerPrependZero w=0 := (augmentedKernelEquiv a M).injective (hzero.trans (map_zero _).symm)
  funext j
  exact congrFun hpre j.succ

theorem congruenceLatticeMap_range (a : Fin d→ℤ) (M : ℤ) (hM : M≠0) (x : Fin d→ℤ) :
    (∃ w,congruenceLatticeMap a M w=x) ↔ M ∣ ∑ j,a j*x j := by
  constructor
  · rintro ⟨w,rfl⟩
    exact congruenceLatticeMap_mem a M w
  · rintro ⟨t,ht⟩
    let v : Fin (d+1)→ℤ := Fin.cons (-t) x
    let y := (augmentedKernelEquiv a M).symm v
    have hyv : augmentedKernelEquiv a M y=v := (augmentedKernelEquiv a M).apply_symm_apply _
    have hpair := augmentedKernelEquiv_pairing a M y
    rw [hyv] at hpair
    change M*(-t)+(∑ j,a j*x j)=executableDirectionFactor (Fin.cons M a)*y 0 at hpair
    have ha : (Fin.cons M a : Fin (d+1)→ℤ)≠0 := by
      intro hz
      exact hM (congrFun hz 0)
    have hfac := executableDirectionFactor_ne_zero (Fin.cons M a) ha
    have hy0 : y 0=0 := by
      apply (mul_eq_zero.mp (show executableDirectionFactor (Fin.cons M a)*y 0=0 by rw [←hpair,ht]; ring)).resolve_left hfac
    have hypre : integerPrependZero (integerTail y)=y := by
      ext j
      refine Fin.cases ?_ (fun k => rfl) j
      exact hy0.symm
    refine ⟨integerTail y,?_⟩
    change integerTail (augmentedKernelEquiv a M (integerPrependZero (integerTail y)))=x
    rw [hypre,hyv]
    rfl

/-- The map contains every `M`-multiple of a coordinate vector, so its
real extension has full rank even though its integer index may exceed one. -/
theorem congruenceLatticeMap_real_surjective (a : Fin d→ℤ) (M : ℤ) (hM : M≠0) :
    Function.Surjective (integerMapRealExtension (congruenceLatticeMap a M)) := by
  apply LinearMap.range_eq_top.mp
  by_contra hproper
  obtain ⟨j,hj⟩ := exists_coordinate_axis_outside (LinearMap.range (integerMapRealExtension (congruenceLatticeMap a M))) hproper
  have hm : M ∣ ∑ i,a i*(M •(Pi.single j (1:ℤ) : Fin d→ℤ)) i := by
    simp [Pi.smul_apply,smul_eq_mul,Pi.single_apply,Finset.mul_sum]
  obtain ⟨w,hw⟩ := (congruenceLatticeMap_range a M hM _).mpr hm
  have hc := integerMapRealExtension_cast (congruenceLatticeMap a M) w
  rw [hw] at hc
  apply hj
  apply LinearMap.mem_range.mpr
  refine ⟨(M:ℝ)⁻¹ •realVector w,?_⟩
  rw [map_smul,hc]
  have hMr : (M:ℝ)≠0 := by exact_mod_cast hM
  ext i
  simp [realVector,Pi.single_apply,Pi.smul_apply,smul_eq_mul,hMr]
end Optss
