import Optss.DenseBoxCorollary

/-!
# Transferring dense-box filling through a proper progression map

This is the coordinate-transfer stage in CFP Lemma 2.22. The original
integer box is assumed proper under its actual additive encoding. Dense
generated-lattice boxing supplies a new GAP, and an explicit small real
dilate of that GAP remains proper under the original encoding.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 800000
variable {d : ℕ}

namespace CenteredProgression
variable {ι G H : Type*} [Fintype ι] [AddCommGroup G] [AddCommGroup H]

def mapHom (P : CenteredProgression ι G) (f : G →+ H) : CenteredProgression ι H where
  lowerRadius := P.lowerRadius
  upperRadius := P.upperRadius
  lower_nonneg := P.lower_nonneg
  upper_nonneg := P.upper_nonneg
  map := f.comp P.map

theorem mapHom_values (P : CenteredProgression ι G) (f : G →+ H) (a : ℝ) :
    (P.mapHom f).values a = (P.values a).image f := by
  simp only [values, mapHom, Finset.image_image, AddMonoidHom.coe_comp, Function.comp_def]
  rfl

end CenteredProgression

/-- Integer rounding in the inner quarter-box allows one common translate
into the original box, even when side lengths are odd. -/
theorem small_centered_box_translate (lo : IntVec d) (W : Fin d → ℕ)
    (hW : ∀ j, 2 ≤ W j) (x : IntVec d)
    (hx : ∀ j, |(x j : ℝ)| ≤ (W j : ℝ) / 4) :
    (fun j => lo j + (W j : ℤ) / 2) + x ∈
      fillingIntegerBox lo (fun j => lo j + W j - 1) := by
  rw [mem_fillingIntegerBox]
  intro j
  have h4real : 4 * |(x j : ℝ)| ≤ W j := by linarith [hx j]
  have h4 : 4 * |x j| ≤ (W j : ℤ) := by exact_mod_cast h4real
  have hlow := neg_abs_le (x j)
  have hhigh := le_abs_self (x j)
  have hw : (2 : ℤ) ≤ W j := by exact_mod_cast hW j
  change lo j ≤ lo j + (W j : ℤ) / 2 + x j ∧
    lo j + (W j : ℤ) / 2 + x j ≤ lo j + W j - 1
  constructor <;> omega

theorem encoding_injective_on_small_box {G : Type*} [AddCommGroup G]
    (ρ : IntVec d →+ G) (lo : IntVec d) (W : Fin d → ℕ)
    (hW : ∀ j, 2 ≤ W j)
    (hρ : Set.InjOn ρ (fillingIntegerBox lo (fun j => lo j + W j - 1)))
    (x y : IntVec d)
    (hx : ∀ j, |(x j : ℝ)| ≤ (W j : ℝ) / 4)
    (hy : ∀ j, |(y j : ℝ)| ≤ (W j : ℝ) / 4) (hxy : ρ x = ρ y) : x = y := by
  have he := hρ (small_centered_box_translate lo W hW x hx)
    (small_centered_box_translate lo W hW y hy) (by simp only [map_add, hxy])
  exact add_left_cancel he

def denseLatticeProperScale (d : ℕ) : ℝ := (4 * denseLatticeBoxingConstant d)⁻¹

theorem denseLatticeProperScale_pos (hd : 0 < d) : 0 < denseLatticeProperScale d := by
  have h := denseLatticeBoxingConstant_pos hd
  unfold denseLatticeProperScale
  positivity

theorem subgroupBasisProgression_small_bound (hd : 0 < d)
    (Γ : AddSubgroup (IntVec d)) (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (n W : Fin d → ℕ)
    (houter : basisCoefficientBox b n ⊆ denseLatticeBoxingConstant d • realCoefficientBox W)
    (x : IntVec d) (hx : x ∈ (subgroupBasisProgression Γ b hΛ n).values
      (denseLatticeProperScale d)) : ∀ j, |(x j : ℝ)| ≤ (W j : ℝ) / 4 := by
  have hC := denseLatticeBoxingConstant_pos hd
  have hη := denseLatticeProperScale_pos hd
  have hh := (subgroupBasisProgression_mem Γ b hΛ n _ hη x).mp hx
  obtain ⟨y, hy, he⟩ := Set.mem_smul_set.mp hh.2
  have hybound := mem_smul_realCoefficientBox_bound W _ hC.le y (houter hy)
  intro j
  have he' := congrFun he j
  change denseLatticeProperScale d * y j = (x j : ℝ) at he'
  rw [← he', abs_mul, abs_of_pos hη]
  calc
    _ ≤ denseLatticeProperScale d * (denseLatticeBoxingConstant d * W j) :=
      mul_le_mul_of_nonneg_left (hybound j) hη.le
    _ = (W j : ℝ) / 4 := by
      unfold denseLatticeProperScale
      field_simp
      ring

/-- Membership of a multiple shrinks the actual basis coordinates; no
linearity of an arbitrarily chosen inverse coordinate map is assumed. -/
theorem subgroupBasisProgression_shrink (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (n : Fin d → ℕ) (x : IntVec d) (hxΓ : x ∈ Γ) (M : ℕ) (hM : 0 < M)
    (hx : realVector (M • x) ∈ basisCoefficientBox b n) :
    x ∈ (subgroupBasisProgression Γ b hΛ n).values ((M : ℝ)⁻¹) := by
  have hMr : (0 : ℝ) < M := by exact_mod_cast hM
  apply (subgroupBasisProgression_mem Γ b hΛ n _ (inv_pos.mpr hMr) x).mpr
  refine ⟨hxΓ, ?_⟩
  rw [mem_smul_basisCoefficientBox_iff _ _ _ (inv_pos.mpr hMr)]
  intro j
  change ∀ j, |b.equivFun (realVector (M • x)) j| ≤ (n j : ℝ) at hx
  have hj := hx j
  rw [map_nsmul, map_nsmul, Pi.smul_apply, nsmul_eq_mul, abs_mul,
    abs_of_nonneg (Nat.cast_nonneg M)] at hj
  exact (le_inv_mul_iff₀ hMr).mpr hj

theorem fillingIntegerBox_width_card (lo : IntVec d) (W : Fin d → ℕ) :
    (fillingIntegerBox lo (fun j => lo j + W j - 1)).card = ∏ j, W j := by
  rw [fillingIntegerBox_card]
  apply Finset.prod_congr rfl
  intro j _
  have he : lo j + (W j : ℤ) - 1 - lo j + 1 = W j := by ring
  rw [he, Int.toNat_natCast]

theorem fillingIntegerBox_dilation_card_le (lo t : IntVec d) (W : Fin d → ℕ)
    (k : ℕ) (hk : 1 ≤ k) :
    (fillingIntegerBox (fun j => t j + (k : ℤ) * lo j)
      (fun j => t j + (k : ℤ) * (lo j + W j - 1))).card ≤
      k ^ d * (fillingIntegerBox lo (fun j => lo j + W j - 1)).card := by
  rw [fillingIntegerBox_card, fillingIntegerBox_width_card]
  calc
    _ ≤ ∏ j : Fin d, k * W j := by
      apply Finset.prod_le_prod'
      intro j _
      have hk' : (1 : ℤ) ≤ k := by exact_mod_cast hk
      have hh : t j + (k : ℤ) * (lo j + W j - 1) -
          (t j + (k : ℤ) * lo j) + 1 ≤ ((k * W j : ℕ) : ℤ) := by
        push_cast
        nlinarith
      exact (Int.toNat_le_toNat hh).trans_eq (Int.toNat_natCast _)
    _ = _ := by rw [Finset.prod_mul_distrib]; simp

/-- A dense actual coordinate set in a proper box yields a containing GAP
whose small real dilate is proper and whose large dilates are filled by the
actual image sumsets. This leaves only the small-doubling container theorem
and the final long-scale properness argument for the long-sumset proof. -/
theorem dense_progression_transfer {G : Type*} [AddCommGroup G]
    (hd : 0 < d) (c : ℝ) (hc : 0 < c) (hc1 : c ≤ 1)
    (A : Finset (IntVec d)) (lo : IntVec d) (W : Fin d → ℕ)
    (hW : ∀ j, denseBoxWidthThreshold c ≤ W j)
    (hbox : A ⊆ fillingIntegerBox lo (fun j => lo j + W j - 1))
    (hdense : c * (fillingIntegerBox lo (fun j => lo j + W j - 1)).card ≤ A.card)
    (hzero : 0 ∈ A) (ρ : IntVec d →+ G)
    (hρ : Set.InjOn ρ (fillingIntegerBox lo (fun j => lo j + W j - 1))) :
    ∃ P : CenteredProgression (Fin d) G,
      P.Proper (denseLatticeProperScale d) ∧
      (∀ j, P.lowerRadius j = P.upperRadius j ∧ 1 ≤ P.lowerRadius j) ∧
      c * (P.values 1).card ≤ (denseLatticeOuterScale d ^ d : ℕ) * (A.image ρ).card ∧
      (∀ x ∈ AddSubgroup.closure (A : Set (IntVec d)), ∀ M : ℕ, 0 < M →
        M • x ∈ fillingIntegerBox lo (fun j => lo j + W j - 1) →
        ρ x ∈ P.values ((M : ℝ)⁻¹)) ∧
      ∀ N : ℕ, denseBoxSummandThreshold d c ≤ N →
        ∃ z : G, (P.values (denseLatticeFillingDilation d c * N)).image (z + ·) ⊆
          N • A.image ρ := by
  obtain ⟨b, hb, n, hn, hinner, houter, hfill⟩ := dense_generated_lattice_boxing hd c hc hc1
    A lo W hW hbox hdense hzero
  let Γ := AddSubgroup.closure (A : Set (IntVec d))
  let P₀ := subgroupBasisProgression Γ b hb n
  let P := P₀.mapHom ρ
  have hW2 : ∀ j, 2 ≤ W j := by
    intro j
    have hw := (denseBoxWidthThreshold_spec c hc _ (hW j)).2
    have hh := mul_le_mul_of_nonneg_right hc1 (Nat.cast_nonneg (W j) : (0 : ℝ) ≤ W j)
    have hh' : (2 : ℝ) ≤ W j := by linarith
    exact_mod_cast hh'
  refine ⟨P, ?_, fun j => ⟨rfl, by change (1 : ℝ) ≤ n j; exact_mod_cast hn j⟩, ?_, ?_, ?_⟩
  · intro u hu v hv huv
    have huP : P₀.map u ∈ P₀.values (denseLatticeProperScale d) :=
      (P₀.mem_values _ _).mpr ⟨u, hu, rfl⟩
    have hvP : P₀.map v ∈ P₀.values (denseLatticeProperScale d) :=
      (P₀.mem_values _ _).mpr ⟨v, hv, rfl⟩
    apply subgroupBasisSynthesisHom_injective Γ b hb
    exact encoding_injective_on_small_box ρ lo W hW2 hρ _ _
      (subgroupBasisProgression_small_bound hd Γ b hb n W houter _ huP)
      (subgroupBasisProgression_small_bound hd Γ b hb n W houter _ hvP) huv
  · have hPbound : ∀ x ∈ P₀.values 1, ∀ j,
        |(x j : ℝ)| ≤ denseLatticeBoxingConstant d * W j := by
      intro x hx
      have hh := (subgroupBasisProgression_mem Γ b hb n 1 zero_lt_one x).mp hx
      rw [one_smul] at hh
      exact mem_smul_realCoefficientBox_bound W _ (denseLatticeBoxingConstant_pos hd).le _
        (houter hh.2)
    obtain ⟨t, ht⟩ := centered_set_subset_translated_box _
      (denseLatticeBoxingConstant_pos hd) W hW2 lo (P₀.values 1) hPbound
    have hcard : (P.values 1).card ≤ denseLatticeOuterScale d ^ d *
        (fillingIntegerBox lo (fun j => lo j + W j - 1)).card := by
      calc
        _ = ((P₀.values 1).image ρ).card := by rw [CenteredProgression.mapHom_values]
        _ ≤ (P₀.values 1).card := Finset.card_image_le
        _ ≤ _ := (Finset.card_le_card ht).trans (fillingIntegerBox_dilation_card_le lo t W
          (denseLatticeOuterScale d) (denseLatticeOuterScale_pos hd))
    have him : (A.image ρ).card = A.card := Finset.card_image_iff.mpr (hρ.mono hbox)
    rw [him]
    have hcard' : ((P.values 1).card : ℝ) ≤ (denseLatticeOuterScale d ^ d : ℕ) *
        (fillingIntegerBox lo (fun j => lo j + W j - 1)).card := by exact_mod_cast hcard
    calc
      _ ≤ c * ((denseLatticeOuterScale d ^ d : ℕ) *
          (fillingIntegerBox lo (fun j => lo j + W j - 1)).card) :=
        mul_le_mul_of_nonneg_left hcard' hc.le
      _ = (denseLatticeOuterScale d ^ d : ℕ) * (c *
          (fillingIntegerBox lo (fun j => lo j + W j - 1)).card) := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_left hdense (by positivity)
  · intro x hx M hM hxM
    rw [CenteredProgression.mapHom_values]
    apply Finset.mem_image.mpr
    refine ⟨x, subgroupBasisProgression_shrink Γ b hb n x hx M hM (hinner ?_), rfl⟩
    rw [mem_realCoefficientBox]
    intro j
    have hj := (mem_fillingIntegerBox _ _ _).mp hxM j
    have hz := (mem_fillingIntegerBox _ _ _).mp (hbox hzero) j
    simp only [Pi.zero_apply] at hz
    have habs : |(M • x) j| ≤ (W j : ℤ) := by rw [abs_le]; constructor <;> omega
    change |((M • x) j : ℝ)| ≤ (W j : ℝ)
    exact_mod_cast habs
  · intro N hN
    obtain ⟨z, _, hfillN⟩ := hfill N hN
    refine ⟨ρ z, ?_⟩
    intro y hy
    obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hy
    rw [CenteredProgression.mapHom_values] at hx
    obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp hx
    have hNpos : 0 < N := by
      have hh := denseBoxSummandThreshold_dilation_lower d hd c hc N hN
      by_contra hnot
      have hn0 : N = 0 := by omega
      simp only [hn0, Nat.cast_zero, mul_zero] at hh
      have hnn : (0 : ℝ) ≤ denseBoxReserveSize d c := by positivity
      linarith
    obtain ⟨huΓ, hubox⟩ := (subgroupBasisProgression_mem Γ b hb n _
      (mul_pos (denseLatticeFillingDilation_pos hd c hc) (by exact_mod_cast hNpos)) u).mp hu
    rw [← Finset.image_nsmul]
    exact Finset.mem_image.mpr ⟨z+u, hfillN u huΓ hubox, map_add ρ z u⟩

end
end Optss
