import Optss.Bogolyubov
import Optss.ThinLatticeBoxing

/-!
# Uniform rank and volume parameters for the Bohr progression

These constants depend only on a positive density bound. Finite maxima
remove any need to assume monotonicity of the lattice-boxing constants.
-/

namespace Optss
noncomputable section
open scoped BigOperators
variable {N : ℕ} [NeZero N]

def bohrRankBound (η : ℝ) : ℕ := ⌈2/η^2⌉₊+1

theorem bogolyubov_rank_le_of_density (A : Finset (ZMod N)) (hA : A.Nonempty)
    (η : ℝ) (hη : 0<η) (hdensity : η≤(A.card : ℝ)/N) :
    (bogolyubovSpectrum A).card+1≤bohrRankBound η := by
  have hN : (0 : ℝ)<N := Nat.cast_pos.mpr (NeZero.pos N)
  have hm : (0 : ℝ)<A.card := Nat.cast_pos.mpr (Finset.card_pos.mpr hA)
  have hd : η*N≤(A.card : ℝ) := (le_div_iff₀ hN).mp hdensity
  have hs : (η*(N : ℝ))^2≤(A.card : ℝ)^2 :=
    pow_le_pow_left₀ (by positivity) hd 2
  have hb : (2*(N : ℝ)^2)/(A.card : ℝ)^2≤2/η^2 := by
    apply (div_le_div_iff₀ (sq_pos_of_pos hm) (sq_pos_of_pos hη)).mpr
    nlinarith [hs]
  have hc := (bogolyubovSpectrum_card A hA).trans hb
  have hn : (bogolyubovSpectrum A).card≤⌈2/η^2⌉₊ := by
    exact_mod_cast hc.trans (Nat.le_ceil (2/η^2))
  exact Nat.add_le_add_right hn 1

def bohrBoxingCeiling (r : ℕ) : ℕ :=
  ⌈latticeBoxingDilation r ((r.factorial : ℝ)*latticeReductionDefectBound r)⌉₊+1

theorem bohrBoxingCeiling_pos (r : ℕ) : 0<bohrBoxingCeiling r := by
  unfold bohrBoxingCeiling
  omega

theorem bohrBoxingCeiling_bound (r : ℕ) :
    latticeBoxingDilation r ((r.factorial : ℝ)*latticeReductionDefectBound r)≤
      (bohrBoxingCeiling r : ℝ) := by
  have h := Nat.le_ceil (latticeBoxingDilation r ((r.factorial : ℝ)*latticeReductionDefectBound r))
  unfold bohrBoxingCeiling
  push_cast
  linarith

def bohrProgressionLoss (r : ℕ) : ℕ := (16*(2*bohrBoxingCeiling r+1))^r

theorem bohrProgressionLoss_pos (r : ℕ) : 0<bohrProgressionLoss r := by
  unfold bohrProgressionLoss
  positivity

def uniformBohrProgressionLoss (R : ℕ) : ℕ :=
  (Finset.range (R+1)).sup bohrProgressionLoss

theorem bohrProgressionLoss_le_uniform {r R : ℕ} (hr : r≤R) :
    bohrProgressionLoss r≤uniformBohrProgressionLoss R :=
  Finset.le_sup (Finset.mem_range.mpr (by omega))

theorem uniformBohrProgressionLoss_pos (R : ℕ) : 0<uniformBohrProgressionLoss R :=
  (bohrProgressionLoss_pos 0).trans_le (bohrProgressionLoss_le_uniform (Nat.zero_le R))

end
end Optss
