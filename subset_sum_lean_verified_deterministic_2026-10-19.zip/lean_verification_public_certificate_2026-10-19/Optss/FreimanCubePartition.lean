import Optss.FreimanCubeInduction
import Mathlib.Data.Fintype.BigOperators

/-!
# Exact cube-cell decomposition for the two-to-the-dimension theorem

Each coordinate is left of the open unit interval, in it, or right of it.
The resulting `3^n` cells partition every finite set. Their doubled sets
remain disjoint, while the interior plus all cube vertices has exactly
`2^n` times as many points and is disjoint from doubled outer cells.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 800000
variable {n : ℕ}
local instance freimanCubePartitionDecEqRealVec (n : ℕ) : DecidableEq (Fin n → ℝ) := Classical.decEq _

def unitCubeCellPred (s : Fin 3) (x : ℝ) : Prop :=
  if s = 0 then x ≤ -1 else if s = 1 then -1 < x ∧ x < 1 else 1 ≤ x

def unitCubeClass (x : ℝ) : Fin 3 := if x ≤ -1 then 0 else if x < 1 then 1 else 2

theorem unitCubeClass_spec (x : ℝ) : unitCubeCellPred (unitCubeClass x) x := by
  unfold unitCubeClass
  split_ifs with h h'
  · simpa [unitCubeCellPred] using h
  · simp only [unitCubeCellPred, show (1 : Fin 3) ≠ 0 by decide, ↓reduceIte]
    exact ⟨by linarith, h'⟩
  · simpa [unitCubeCellPred] using (le_of_not_gt h')

theorem unitCubeCellPred_unique (s t : Fin 3) (x : ℝ)
    (hs : unitCubeCellPred s x) (ht : unitCubeCellPred t x) : s = t := by
  fin_cases s <;> fin_cases t <;> simp [unitCubeCellPred] at hs ht ⊢ <;> linarith

theorem unitCubeCellPred_average (s : Fin 3) (x y : ℝ)
    (hx : unitCubeCellPred s x) (hy : unitCubeCellPred s y) :
    unitCubeCellPred s ((x+y)/2) := by
  fin_cases s <;> simp [unitCubeCellPred] at hx hy ⊢
  · linarith
  · constructor <;> linarith
  · linarith

def unitCubeCell (S : Finset (Fin n → ℝ)) (σ : Fin n → Fin 3) : Finset (Fin n → ℝ) :=
  S.filter (fun x => ∀ j, unitCubeCellPred (σ j) (x j))

def unitCubeInterior (S : Finset (Fin n → ℝ)) : Finset (Fin n → ℝ) :=
  S.filter (fun x => ∀ j, |x j| < 1)

def unitCubeVertices (n : ℕ) : Finset (Fin n → ℝ) :=
  Fintype.piFinset (fun _ => {(-1 : ℝ), 1})

@[simp] theorem mem_unitCubeVertices (v : Fin n → ℝ) :
    v ∈ unitCubeVertices n ↔ ∀ j, v j = -1 ∨ v j = 1 := by
  simp [unitCubeVertices, Fintype.mem_piFinset]

theorem unitCubeVertices_card (n : ℕ) : (unitCubeVertices n).card = 2^n := by
  norm_num [unitCubeVertices, Fintype.card_piFinset]

theorem unitCubeCell_subset (S : Finset (Fin n → ℝ)) (σ : Fin n → Fin 3) :
    unitCubeCell S σ ⊆ S := Finset.filter_subset _ _

theorem unitCubeCell_disjoint (S : Finset (Fin n → ℝ)) :
    Pairwise (fun σ τ : Fin n → Fin 3 => Disjoint (unitCubeCell S σ) (unitCubeCell S τ)) := by
  intro σ τ hστ
  apply Finset.disjoint_left.mpr
  intro x hx hy
  apply hστ
  funext j
  exact unitCubeCellPred_unique (σ j) (τ j) (x j)
    ((Finset.mem_filter.mp hx).2 j) ((Finset.mem_filter.mp hy).2 j)

theorem unitCubeCell_cover (S : Finset (Fin n → ℝ)) :
    Finset.univ.biUnion (unitCubeCell S) = S := by
  ext x
  constructor
  · intro hx
    obtain ⟨σ, _, hx⟩ := Finset.mem_biUnion.mp hx
    exact unitCubeCell_subset S σ hx
  · intro hx
    apply Finset.mem_biUnion.mpr
    exact ⟨fun j => unitCubeClass (x j), Finset.mem_univ _,
      Finset.mem_filter.mpr ⟨hx, fun j => unitCubeClass_spec (x j)⟩⟩

theorem unitCubeCell_card_sum (S : Finset (Fin n → ℝ)) :
    ∑ σ : Fin n → Fin 3, (unitCubeCell S σ).card = S.card := by
  rw [← Finset.card_biUnion (fun σ _ τ _ hστ => unitCubeCell_disjoint S hστ), unitCubeCell_cover]

theorem unitCubeCell_middle (S : Finset (Fin n → ℝ)) :
    unitCubeCell S (fun _ => 1) = unitCubeInterior S := by
  ext x
  simp [unitCubeCell, unitCubeInterior, unitCubeCellPred, abs_lt]

theorem unitCubeCell_doubles_disjoint (S : Finset (Fin n → ℝ)) :
    Pairwise (fun σ τ : Fin n → Fin 3 =>
      Disjoint (unitCubeCell S σ + unitCubeCell S σ) (unitCubeCell S τ + unitCubeCell S τ)) := by
  intro σ τ hστ
  apply Finset.disjoint_left.mpr
  intro z hz hz'
  obtain ⟨x, hx, y, hy, he⟩ := Finset.mem_add.mp hz
  obtain ⟨u, hu, v, hv, he'⟩ := Finset.mem_add.mp hz'
  apply hστ
  funext j
  have hxy : unitCubeCellPred (σ j) (z j / 2) := by
    rw [← he]
    exact unitCubeCellPred_average _ _ _ ((Finset.mem_filter.mp hx).2 j) ((Finset.mem_filter.mp hy).2 j)
  have huv : unitCubeCellPred (τ j) (z j / 2) := by
    rw [← he']
    exact unitCubeCellPred_average _ _ _ ((Finset.mem_filter.mp hu).2 j) ((Finset.mem_filter.mp hv).2 j)
  exact unitCubeCellPred_unique _ _ _ hxy huv

theorem unitCubeInterior_vertices_injective (S : Finset (Fin n → ℝ)) :
    Set.InjOn (fun p : (Fin n → ℝ) × (Fin n → ℝ) => p.1+p.2)
      ((unitCubeInterior S : Set (Fin n → ℝ)) ×ˢ (unitCubeVertices n : Set (Fin n → ℝ))) := by
  intro p hp q hq he
  have hv : p.2 = q.2 := by
    funext j
    have hpj := abs_lt.mp ((Finset.mem_filter.mp hp.1).2 j)
    have hqj := abs_lt.mp ((Finset.mem_filter.mp hq.1).2 j)
    have hej := congrFun he j
    change p.1 j + p.2 j = q.1 j + q.2 j at hej
    rcases (mem_unitCubeVertices _).mp hp.2 j with hpv | hpv <;>
      rcases (mem_unitCubeVertices _).mp hq.2 j with hqv | hqv <;> linarith
  apply Prod.ext _ hv
  change p.1 + p.2 = q.1 + q.2 at he
  rw [hv] at he
  exact add_right_cancel he

theorem unitCubeInterior_vertices_card (S : Finset (Fin n → ℝ)) :
    (unitCubeInterior S + unitCubeVertices n).card = 2^n * (unitCubeInterior S).card := by
  rw [Finset.card_add_iff.mpr (unitCubeInterior_vertices_injective S), unitCubeVertices_card, mul_comm]

theorem unitCubeInterior_vertices_coordinates (S : Finset (Fin n → ℝ))
    (z : Fin n → ℝ) (hz : z ∈ unitCubeInterior S + unitCubeVertices n) :
    ∀ j, -2 < z j ∧ z j < 2 := by
  obtain ⟨x, hx, v, hv, rfl⟩ := Finset.mem_add.mp hz
  intro j
  have hxj := abs_lt.mp ((Finset.mem_filter.mp hx).2 j)
  rcases (mem_unitCubeVertices _).mp hv j with hvj | hvj <;>
    change -2 < x j + v j ∧ x j + v j < 2 <;> constructor <;> linarith

theorem unitCubeInterior_vertices_outer_disjoint (S : Finset (Fin n → ℝ))
    (σ : Fin n → Fin 3) (hσ : σ ≠ fun _ => 1) :
    Disjoint (unitCubeInterior S + unitCubeVertices n) (unitCubeCell S σ + unitCubeCell S σ) := by
  apply Finset.disjoint_left.mpr
  intro z hz hz'
  obtain ⟨x, hx, y, hy, he⟩ := Finset.mem_add.mp hz'
  apply hσ
  funext j
  have hj := unitCubeInterior_vertices_coordinates S z hz j
  have hσj : unitCubeCellPred (σ j) (z j / 2) := by
    rw [← he]
    exact unitCubeCellPred_average _ _ _ ((Finset.mem_filter.mp hx).2 j) ((Finset.mem_filter.mp hy).2 j)
  apply unitCubeCellPred_unique (σ j) 1 (z j / 2) hσj
  simp only [unitCubeCellPred, show (1 : Fin 3) ≠ 0 by decide, ↓reduceIte]
  constructor <;> linarith

def unitCubeOuterIndices (n : ℕ) : Finset (Fin n → Fin 3) :=
  Finset.univ.erase (fun _ => 1)

theorem unitCubeOuterIndices_card (n : ℕ) : (unitCubeOuterIndices n).card = 3^n-1 := by
  simp [unitCubeOuterIndices, Fintype.card_fun]

theorem unitCubeCell_outer_card_sum (S : Finset (Fin n → ℝ)) :
    (unitCubeInterior S).card + ∑ σ ∈ unitCubeOuterIndices n, (unitCubeCell S σ).card = S.card := by
  have hh := Finset.sum_erase_add (Finset.univ : Finset (Fin n → Fin 3))
    (fun σ => (unitCubeCell S σ).card) (Finset.mem_univ (fun _ => 1))
  dsimp only at hh
  rw [unitCubeCell_middle, unitCubeCell_card_sum] at hh
  simpa only [unitCubeOuterIndices, add_comm] using hh

/-- The main exact counting inequality: all these explicitly defined
disjoint sets lie inside the actual input sumset. -/
theorem unitCube_partition_sumset_bound (S : Finset (Fin n → ℝ))
    (hvertices : unitCubeVertices n ⊆ S) :
    2^n * (unitCubeInterior S).card +
      ∑ σ ∈ unitCubeOuterIndices n, (unitCubeCell S σ + unitCubeCell S σ).card ≤ (S+S).card := by
  let C := unitCubeInterior S + unitCubeVertices n
  let D := (unitCubeOuterIndices n).biUnion (fun σ => unitCubeCell S σ + unitCubeCell S σ)
  have hdis : Disjoint C D := by
    apply Finset.disjoint_left.mpr
    intro z hz hzD
    obtain ⟨σ, hσ, hzσ⟩ := Finset.mem_biUnion.mp hzD
    exact Finset.disjoint_left.mp (unitCubeInterior_vertices_outer_disjoint S σ
      (Finset.mem_erase.mp hσ).1) hz hzσ
  have hsub : C ∪ D ⊆ S+S := by
    intro z hz
    rcases Finset.mem_union.mp hz with hz | hz
    · exact Finset.add_subset_add (Finset.filter_subset _ _) hvertices hz
    · obtain ⟨σ, _, hz⟩ := Finset.mem_biUnion.mp hz
      exact Finset.add_subset_add (unitCubeCell_subset S σ) (unitCubeCell_subset S σ) hz
  have hcardD : D.card = ∑ σ ∈ unitCubeOuterIndices n,
      (unitCubeCell S σ + unitCubeCell S σ).card :=
    Finset.card_biUnion (fun σ _ τ _ hστ => unitCubeCell_doubles_disjoint S hστ)
  have hh := Finset.card_le_card hsub
  rwa [Finset.card_union_of_disjoint hdis, hcardD, unitCubeInterior_vertices_card] at hh

def unitCubeClosed (S : Finset (Fin n → ℝ)) : Finset (Fin n → ℝ) :=
  S.filter (fun x => ∀ j, |x j| ≤ 1)

def unitCubeBoundary (S : Finset (Fin n → ℝ)) : Finset (Fin n → ℝ) :=
  Finset.univ.biUnion (fun j : Fin n =>
    S.filter (fun x => x j = -1) ∪ S.filter (fun x => x j = 1))

theorem unitCubeBoundary_card_le (S : Finset (Fin n → ℝ)) (H : ℕ)
    (hfaces : ∀ j, (S.filter (fun x => x j = -1)).card ≤ H ∧
      (S.filter (fun x => x j = 1)).card ≤ H) :
    (unitCubeBoundary S).card ≤ 2*n*H := by
  calc
    _ ≤ ∑ j : Fin n, (S.filter (fun x => x j = -1) ∪ S.filter (fun x => x j = 1)).card :=
      Finset.card_biUnion_le
    _ ≤ ∑ _j : Fin n, (H+H) := Finset.sum_le_sum (fun j _ =>
      (Finset.card_union_le _ _).trans (add_le_add (hfaces j).1 (hfaces j).2))
    _ = _ := by
      simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, Nat.cast_id]
      ring

theorem unitCubeClosed_subset_interior_union_boundary (S : Finset (Fin n → ℝ)) :
    unitCubeClosed S ⊆ unitCubeInterior S ∪ unitCubeBoundary S := by
  intro x hx
  obtain ⟨hxS, hxC⟩ := Finset.mem_filter.mp hx
  by_cases hxI : x ∈ unitCubeInterior S
  · exact Finset.mem_union_left _ hxI
  · apply Finset.mem_union_right
    have hn : ¬∀ j, |x j| < 1 := fun h => hxI (Finset.mem_filter.mpr ⟨hxS, h⟩)
    obtain ⟨j, hj⟩ := not_forall.mp hn
    apply Finset.mem_biUnion.mpr
    refine ⟨j, Finset.mem_univ _, ?_⟩
    by_cases hxm : x j = -1
    · exact Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨hxS, hxm⟩)
    · have hxp : x j = 1 := by
        have hb := abs_le.mp (hxC j)
        by_contra hxp
        apply hj
        rw [abs_lt]
        exact ⟨lt_of_le_of_ne hb.1 (Ne.symm hxm), lt_of_le_of_ne hb.2 hxp⟩
      exact Finset.mem_union_right _ (Finset.mem_filter.mpr ⟨hxS, hxp⟩)

/-- Boundary loss is controlled by the actual coordinate hyperplanes. -/
theorem unitCubeClosed_card_le_interior (S : Finset (Fin n → ℝ)) (H : ℕ)
    (hfaces : ∀ j, (S.filter (fun x => x j = -1)).card ≤ H ∧
      (S.filter (fun x => x j = 1)).card ≤ H) :
    (unitCubeClosed S).card ≤ (unitCubeInterior S).card + 2*n*H :=
  (Finset.card_le_card (unitCubeClosed_subset_interior_union_boundary S)).trans
    ((Finset.card_union_le _ _).trans (add_le_add_left (unitCubeBoundary_card_le S H hfaces) _))

end
end Optss
