import Optss.FreimanSymmetricSubset
import Optss.FreimanHyperplane

/-!
# Exact half-space counting for the Freiman cube induction

Symmetry makes the positive and negative half-spaces equipotent. If at most
a third of the set is on the hyperplane, one positive half-space contains
a third of it; the verified reflection-fiber argument then supplies the
large symmetric subset with the squared doubling parameter used by Bilu.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {E : Type*} [AddCommGroup E] [Module ℝ E]

theorem symmetric_halfspace_card (S : Finset E) (hsym : ∀ x ∈ S, -x ∈ S)
    (f : E →ₗ[ℝ] ℝ) :
    S.card = (S.filter (fun x => f x = 0)).card + 2 * (S.filter (fun x => 0 < f x)).card := by
  have hneg : (S.filter (fun x => 0 < f x)).image (- ·) = S.filter (fun x => f x < 0) := by
    ext x
    simp only [Finset.mem_image, Finset.mem_filter]
    constructor
    · rintro ⟨y, ⟨hy, hfy⟩, rfl⟩
      exact ⟨hsym y hy, by simpa using hfy⟩
    · rintro ⟨hx, hfx⟩
      exact ⟨-x, ⟨hsym x hx, by simpa using hfx⟩, neg_neg x⟩
  have hcard : (S.filter (fun x => f x < 0)).card =
      (S.filter (fun x => 0 < f x)).card := by
    rw [← hneg, Finset.card_image_of_injective _ neg_injective]
  have hsplit : S.filter (fun x => f x ≠ 0) =
      S.filter (fun x => f x < 0) ∪ S.filter (fun x => 0 < f x) := by
    ext x
    simp only [Finset.mem_filter, Finset.mem_union]
    constructor
    · rintro ⟨hx, hfx⟩
      rcases lt_or_gt_of_ne hfx with h | h
      · exact Or.inl ⟨hx, h⟩
      · exact Or.inr ⟨hx, h⟩
    · rintro (⟨hx, hfx⟩ | ⟨hx, hfx⟩)
      · exact ⟨hx, ne_of_lt hfx⟩
      · exact ⟨hx, ne_of_gt hfx⟩
  have hdis : Disjoint (S.filter (fun x => f x < 0)) (S.filter (fun x => 0 < f x)) := by
    apply Finset.disjoint_left.mpr
    intro x hx hy
    exact (not_lt_of_gt (Finset.mem_filter.mp hx).2) (Finset.mem_filter.mp hy).2
  have hh := Finset.filter_card_add_filter_neg_card_eq_card (s := S) (fun x => f x = 0)
  rw [hsplit, Finset.card_union_of_disjoint hdis, hcard] at hh
  omega

/-- The positive symmetric subset used in the nondegenerate branch of the
cube induction, with every cardinality and positivity condition derived. -/
theorem positive_halfspace_symmetric_subset (S : Finset E) (hS : S.Nonempty)
    (hsym : ∀ x ∈ S, -x ∈ S) (f : E →ₗ[ℝ] ℝ)
    (hzero : 3 * (S.filter (fun x => f x = 0)).card ≤ S.card)
    (τ : ℝ) (hτ : 0 < τ) (hdoub : ((S+S).card : ℝ) ≤ τ * S.card) :
    ∃ b : E, ∃ T : Finset E, T.Nonempty ∧ T ⊆ S ∧
      (∀ x ∈ T, 0 < f x) ∧ 0 < f b ∧
      (∀ x ∈ T, (2 : ℝ) • b - x ∈ T) ∧
      (S.card : ℝ) / (9 * τ) ≤ T.card ∧
      ((T+T).card : ℝ) ≤ 9 * τ^2 * T.card := by
  let U := S.filter (fun x => 0 < f x)
  have hSU : S.card ≤ 3 * U.card := by
    have hh := symmetric_halfspace_card S hsym f
    change S.card = _ + 2 * U.card at hh
    omega
  have hUne : U.Nonempty := Finset.card_pos.mp (by have := hS.card_pos; omega)
  have hsub : U ⊆ S := Finset.filter_subset _ _
  have hUdoub : ((U+U).card : ℝ) ≤ (3*τ) * U.card := by
    have hh : ((U+U).card : ℝ) ≤ (S+S).card := by
      exact_mod_cast Finset.card_le_card (Finset.add_subset_add hsub hsub)
    have hSU' : (S.card : ℝ) ≤ 3 * U.card := by exact_mod_cast hSU
    nlinarith
  obtain ⟨t, T, hTU, hTsym, hTsize, hTdoub⟩ :=
    small_doubling_symmetric_subset U hUne (3*τ) (by positivity) hUdoub
  have hsize : (S.card : ℝ) / (9*τ) ≤ T.card := by
    have hT' := (div_le_iff₀ (show 0 < 3*τ by positivity)).mp hTsize
    have hSU' : (S.card : ℝ) ≤ 3 * U.card := by exact_mod_cast hSU
    apply (div_le_iff₀ (show 0 < 9*τ by positivity)).mpr
    nlinarith
  have hTne : T.Nonempty := by
    apply Finset.card_pos.mp
    have hSpos : (0 : ℝ) < S.card := by exact_mod_cast hS.card_pos
    have hh : (0 : ℝ) < T.card := (div_pos hSpos (by positivity)).trans_le hsize
    exact_mod_cast hh
  have hpos : ∀ x ∈ T, 0 < f x := fun x hx => (Finset.mem_filter.mp (hTU hx)).2
  let b := (1/2 : ℝ) • t
  have hb : (2 : ℝ) • b = t := by dsimp [b]; module
  have hfb : 0 < f b := by
    obtain ⟨x, hx⟩ := hTne
    have hxpos := hpos x hx
    have htxpos := hpos _ (hTsym x hx)
    rw [map_sub] at htxpos
    change 0 < f ((1/2 : ℝ) • t)
    rw [map_smul]
    change 0 < (1/2 : ℝ) * f t
    linarith
  refine ⟨b, T, hTne, hTU.trans hsub, hpos, hfb,
    fun x hx => by rw [hb]; exact hTsym x hx, hsize, ?_⟩
  nlinarith

end
end Optss
