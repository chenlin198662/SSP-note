import Optss.Macbeath
import Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar

/-!
# Buffered boundary patches and their packing volumes

These are geometric components of Lemma 4.1. The buffered-body inclusion and
supporting-normal shell containment are derived from their defining sets.
Finite volume accounting uses actual disjoint regions and Haar scaling; no
bound on the erosion-shell volume is postulated. The separate Fubini estimate
(11), local lattice boxing, and the algorithmic contraction remain to be proved.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators ENNReal
open MeasureTheory MeasureTheory.Measure

section Algebra
variable {E : Type*} [AddCommGroup E] [Module ℝ E]

/-- Minkowski erosion: all translations of the eroding set must remain in `K`. -/
def minkowskiErosion (K C : Set E) : Set E := {x | ∀ u ∈ C, x + u ∈ K}

omit [Module ℝ E] in
/-- Erosion by a set containing zero stays inside the original set. -/
theorem erosion_subset {K C : Set E} (hzero : (0 : E) ∈ C) : minkowskiErosion K C ⊆ K := by
  intro x hx
  simpa using hx 0 hzero

/-- Erosion preserves convexity; this also applies after each successive
coordinate erosion in the argument for (11). -/
theorem convex_erosion {K C : Set E} (hK : Convex ℝ K) : Convex ℝ (minkowskiErosion K C) := by
  intro x hx y hy a b ha hb hab
  intro u hu
  convert hK (hx u hu) (hy u hu) ha hb hab using 1
  match_scalars <;> nlinarith

omit [Module ℝ E] in
/-- Erosion by a Minkowski sum equals successive erosions. -/
theorem erosion_add (K C D : Set E) :
    minkowskiErosion K (C+D) = minkowskiErosion (minkowskiErosion K C) D := by
  ext x
  constructor
  · intro hx d hd c hc
    have h := hx (c+d) (Set.add_mem_add hc hd)
    convert h using 1
    abel_nf
  · intro hx u hu
    obtain ⟨c, hc, d, hd, rfl⟩ := hu
    have h := hx d hd c hc
    convert h using 1
    abel_nf

/-- The buffered convex body used at the beginning of Lemma 4.1. -/
def bufferedBody (Z Q : Set E) (c : E) (η a : ℝ) : Set E :=
  (Z + η • Q) ∩ ({c} + (1+a) • Q)

theorem convex_bufferedBody {Z Q : Set E} (hZ : Convex ℝ Z) (hQ : Convex ℝ Q)
    (c : E) (η a : ℝ) : Convex ℝ (bufferedBody Z Q c η a) := by
  exact (hZ.add (hQ.smul η)).inter ((convex_singleton c).add (hQ.smul (1+a)))

/-- The buffer really contains an `ηQ` neighborhood of every relevant center,
including centers on the boundary of `Z`. -/
theorem buffer_translate_subset {Z Q : Set E} (hQ : Convex ℝ Q)
    (hzero : (0 : E) ∈ Q) {x c : E} (hxZ : x ∈ Z) (hxQ : x ∈ {c} + Q)
    {η a : ℝ} (hη : 0 ≤ η) (hηa : η ≤ a) :
    {x} + η • Q ⊆ bufferedBody Z Q c η a := by
  rintro y ⟨x', hx', u, hu, rfl⟩
  have hx'e : x' = x := hx'
  subst x'
  refine ⟨Set.add_mem_add hxZ hu, ?_⟩
  rcases hxQ with ⟨c', hc', q, hq, heq⟩
  have hc'e : c' = c := hc'
  subst c'
  have hqu : q + u ∈ (1+η) • Q := by
    rw [hQ.add_smul (by norm_num : (0 : ℝ) ≤ 1) hη, one_smul]
    exact Set.add_mem_add hq hu
  have hqu' : q + u ∈ (1+a) • Q :=
    smul_set_mono_scale hQ hzero (by linarith) (by linarith) hqu
  refine ⟨c, rfl, q+u, hqu', ?_⟩
  change c + q = x at heq
  change c + (q + u) = x + u
  rw [← add_assoc, heq]

/-- Symmetry turns the verified buffer neighborhood into the Macbeath-core
inclusion asserted on page 30. -/
theorem buffer_subset_macbeathCore {Z Q : Set E} (hQ : Convex ℝ Q)
    (hzero : (0 : E) ∈ Q) (hsym : ∀ u ∈ Q, -u ∈ Q)
    {x c : E} (hxZ : x ∈ Z) (hxQ : x ∈ {c} + Q)
    {η a : ℝ} (hη : 0 ≤ η) (hηa : η ≤ a) :
    η • Q ⊆ macbeathCore (bufferedBody Z Q c η a) x := by
  intro u hu
  have htr := buffer_translate_subset hQ hzero hxZ hxQ hη hηa
  refine ⟨htr (Set.add_mem_add rfl hu), ?_⟩
  have hneg : -u ∈ η • Q := by
    rcases hu with ⟨v, hv, rfl⟩
    exact ⟨-v, hsym v hv, by simp⟩
  simpa only [sub_eq_add_neg] using htr (Set.add_mem_add rfl hneg)

/-- A supporting functional certifies failure of erosion membership whenever
a translated point in the eroding body crosses its supporting hyperplane. -/
theorem not_mem_erosion_of_support {K Q : Set E} (f : E →ₗ[ℝ] ℝ)
    {H r : ℝ} (hupper : ∀ u ∈ K, f u ≤ H) {q y : E} (hq : q ∈ Q)
    (hcross : H - f y < r * f q) : y ∉ minkowskiErosion K (r • Q) := by
  intro hy
  have h := hupper _ (hy (r • q) ⟨q, hq, rfl⟩)
  simp only [map_add, map_smul, smul_eq_mul] at h
  linarith

/-- The actual small-region-to-shell implication on page 30. Positivity of the
support value is explicit; for the paper's full-dimensional centered box it
holds for every nonzero normal. -/
theorem macbeath_region_subset_erosion_shell {K Q : Set E} (hK : Convex ℝ K)
    {x : E} (hx : x ∈ K) (f : E →ₗ[ℝ] ℝ) {H h δ α : ℝ}
    (hupper : ∀ u ∈ K, f u ≤ H) (hh : 0 < h)
    (hattain : ∃ q ∈ Q, f q = h) (hδ : 0 < δ)
    (hnormal : H - f x ≤ δ*h) (hα : α ∈ Set.Icc (0 : ℝ) 1) :
    macbeathRegion K x α ⊆ K \ minkowskiErosion K ((2*(1+α)*δ) • Q) := by
  intro y hy
  refine ⟨macbeathRegion_subset hK hx hα hy, ?_⟩
  obtain ⟨q, hq, hfq⟩ := hattain
  apply not_mem_erosion_of_support f hupper hq
  have hdef := macbeath_support_deficit f hupper hα.1 hy
  have hmul := mul_le_mul_of_nonneg_left hnormal (show 0 ≤ 1+α by linarith [hα.1])
  rw [hfq]
  have hstrict : 0 < (1+α)*δ*h := mul_pos (mul_pos (by linarith [hα.1]) hδ) hh
  nlinarith

/-- The normal condition (10) supplies the shell hypothesis for the buffered
body, using the actual Minkowski-sum support bound. -/
theorem buffered_normal_shell {Z Q : Set E} (hZ : Convex ℝ Z) (hQ : Convex ℝ Q)
    {x c : E} {η a θ α : ℝ} (hx : x ∈ bufferedBody Z Q c η a)
    (hη : 0 ≤ η) (hδ : 0 < θ+η) (hα : α ∈ Set.Icc (0 : ℝ) 1)
    (f : E →ₗ[ℝ] ℝ) {HZ HQ : ℝ} (hZupper : ∀ z ∈ Z, f z ≤ HZ)
    (hQupper : ∀ q ∈ Q, f q ≤ HQ) (hHQ : 0 < HQ)
    (hattain : ∃ q ∈ Q, f q = HQ) (hnormal : HZ - f x ≤ θ*HQ) :
    macbeathRegion (bufferedBody Z Q c η a) x α ⊆
      bufferedBody Z Q c η a \
        minkowskiErosion (bufferedBody Z Q c η a) ((2*(1+α)*(θ+η)) • Q) := by
  apply macbeath_region_subset_erosion_shell (convex_bufferedBody hZ hQ c η a)
    hx f (H := HZ+η*HQ) _ hHQ hattain hδ _ hα
  · intro u hu
    obtain ⟨z, hz, w, ⟨q, hq, rfl⟩, rfl⟩ := hu.1
    simp only [map_add, map_smul, smul_eq_mul]
    exact add_le_add (hZupper z hz) (mul_le_mul_of_nonneg_left (hQupper q hq) hη)
  · nlinarith

end Algebra

section Volume
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
  (μ : Measure E) [IsAddHaarMeasure μ]

omit [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E] in
/-- The buffered body is compact when both original bodies are compact. -/
theorem isCompact_bufferedBody {Z Q : Set E} (hZ : IsCompact Z) (hQ : IsCompact Q)
    (c : E) (η a : ℝ) : IsCompact (bufferedBody Z Q c η a) := by
  exact (hZ.add (hQ.image (continuous_const.smul continuous_id))).inter
    (isCompact_singleton.add (hQ.image (continuous_const.smul continuous_id)))

omit [NormedSpace ℝ E] [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E] in
/-- Closedness of erosion follows from its exact universal-translation definition. -/
theorem isClosed_erosion {K C : Set E} (hK : IsClosed K) : IsClosed (minkowskiErosion K C) := by
  have he : minkowskiErosion K C = ⋂ u ∈ C, (fun x => x+u) ⁻¹' K := by
    ext x
    simp [minkowskiErosion]
  rw [he]
  exact isClosed_biInter (fun u _ => hK.preimage (continuous_id.add continuous_const))

omit [NormedSpace ℝ E] [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E] in
/-- For an eroding body containing zero, compactness survives every erosion. -/
theorem isCompact_erosion {K C : Set E} (hK : IsCompact K) (hzero : (0 : E) ∈ C) :
    IsCompact (minkowskiErosion K C) :=
  hK.of_isClosed_subset (isClosed_erosion hK.isClosed) (erosion_subset hzero)

/-- Translation invariance and homothety give the exact small-region volume. -/
theorem measure_macbeathRegion (K : Set E) (x : E) {α : ℝ} (hα : 0 ≤ α) :
    μ (macbeathRegion K x α) = ENNReal.ofReal (α ^ Module.finrank ℝ E) * μ (macbeathCore K x) := by
  have he : macbeathRegion K x α = (fun u => x+u) '' (α • macbeathCore K x) := by
    rw [macbeathRegion, ← Set.image_image]
    rfl
  rw [he, Set.image_add_left, measure_preimage_add, addHaar_smul_of_nonneg μ hα]

/-- Exact packing-volume accounting: a finite disjoint family occupies no
more measure than the set that contains the actual small regions. -/
theorem macbeath_packing_measure_le {K S : Set E} (hK : IsCompact K)
    (T : Finset E) {α : ℝ} (hα : 0 ≤ α)
    (hdis : ∀ x ∈ T, ∀ y ∈ T, x ≠ y →
      Disjoint (macbeathRegion K x α) (macbeathRegion K y α))
    (hcontain : ∀ x ∈ T, macbeathRegion K x α ⊆ S) :
    ENNReal.ofReal (α ^ Module.finrank ℝ E) *
      (∑ x ∈ T, μ (macbeathCore K x)) ≤ μ S := by
  rw [Finset.mul_sum]
  simp_rw [← measure_macbeathRegion μ K _ hα]
  rw [← measure_biUnion_finset hdis
    (fun x _ => (isCompact_macbeathRegion hK x α).measurableSet)]
  apply measure_mono
  exact Set.iUnion₂_subset hcontain


/-- Combining normal-direction shell containment with greedy packing gives
both the cover and its exact summed-volume estimate. The right-hand side is
the measure of the actual erosion shell, whose bound (11) is a separate step. -/
theorem exists_normal_macbeath_cover {K Q : Set E} (hconv : Convex ℝ K)
    (hcompact : IsCompact K) (C : Finset E) (hC : ∀ x ∈ C, x ∈ K)
    {δ : ℝ} (hδ : 0 < δ)
    (hnormal : ∀ x ∈ C, ∃ (f : E →ₗ[ℝ] ℝ) (H h : ℝ),
      (∀ u ∈ K, f u ≤ H) ∧ 0 < h ∧ (∃ q ∈ Q, f q = h) ∧ H-f x ≤ δ*h) :
    ∃ T : Finset E, T ⊆ C ∧
      (∀ x ∈ T, ∀ y ∈ T, x ≠ y →
        Disjoint (macbeathRegion K x (1/5)) (macbeathRegion K y (1/5))) ∧
      (∀ x ∈ C, ∃ y ∈ T, macbeathRegion K x (1/5) ⊆ macbeathRegion K y 1) ∧
      (∑ x ∈ T, μ (macbeathCore K x)) ≤
        ENNReal.ofReal ((5 : ℝ) ^ Module.finrank ℝ E) *
          μ (K \ minkowskiErosion K (((12/5 : ℝ)*δ) • Q)) := by
  obtain ⟨T, hTC, hdis, hcover⟩ := exists_finite_macbeath_cover hconv C hC
  refine ⟨T, hTC, hdis, hcover, ?_⟩
  have hcontain : ∀ x ∈ T, macbeathRegion K x (1/5) ⊆
      K \ minkowskiErosion K (((12/5 : ℝ)*δ) • Q) := by
    intro x hx
    obtain ⟨f, H, h, hupper, hh, hattain, hcap⟩ := hnormal x (hTC hx)
    convert macbeath_region_subset_erosion_shell hconv (hC x (hTC hx))
      f (α := 1/5) hupper hh hattain hδ hcap ⟨by norm_num, by norm_num⟩ using 1
    norm_num
  have hmeasure := macbeath_packing_measure_le μ hcompact T
    (by norm_num : (0 : ℝ) ≤ 1/5) hdis hcontain
  have hfactor : ENNReal.ofReal ((5 : ℝ)^Module.finrank ℝ E) *
      ENNReal.ofReal (((1/5 : ℝ))^Module.finrank ℝ E) = 1 := by
    rw [← ENNReal.ofReal_mul (by positivity), ← mul_pow]
    norm_num
  calc
    (∑ x ∈ T, μ (macbeathCore K x)) =
        ENNReal.ofReal ((5 : ℝ)^Module.finrank ℝ E) *
        (ENNReal.ofReal (((1/5 : ℝ))^Module.finrank ℝ E) *
        (∑ x ∈ T, μ (macbeathCore K x))) := by rw [← mul_assoc, hfactor, one_mul]
    _ ≤ _ := mul_le_mul_left' hmeasure _

end Volume
end
end Optss
