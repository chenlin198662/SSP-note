import Optss.BooleanFourierPreparation
import Optss.DyadicFourierTwiddles

/-! The dyadic character constructor implemented with Boolean fractions and
Boolean nearest-integer rounding. Integer/complex decoding is proof-only. -/
namespace Optss

def fourierPowTwoDigits : ℕ → List Bool
  | 0 => [true]
  | n+1 => false::fourierPowTwoDigits n

theorem fourierPowTwoDigits_value (n : ℕ) : binaryDigitsValue (fourierPowTwoDigits n)=2^n := by
  induction n with
  | zero => norm_num [fourierPowTwoDigits,binaryDigitsValue]
  | succ n ih => simpa [fourierPowTwoDigits,binaryDigitsValue,ih,pow_succ,mul_comm]

theorem fourierPowTwoDigits_length (n : ℕ) : (fourierPowTwoDigits n).length=n+1 := by
  induction n with
  | zero => rfl
  | succ n ih => simp [fourierPowTwoDigits,ih]

def FourierFraction.ofNatDigits (xs : List Bool) : FourierFraction :=
  ⟨⟨false,bitListTrim xs,[true]⟩,by
    refine ⟨bitListTrim_canonical _,?_,?_,?_⟩
    · norm_num [BitListCanonical,binaryDigitsValue]
    · norm_num [binaryDigitsValue]
    · simpa only [binaryDigitsValue,Bool.toNat_true,mul_zero,add_zero] using Nat.coprime_one_right _⟩

@[simp] theorem FourierFraction.ofNatDigits_value (xs : List Bool) :
    (FourierFraction.ofNatDigits xs).value=(binaryDigitsValue xs : ℚ) := by
  simp [FourierFraction.ofNatDigits,FourierFraction.value,bitListFractionValue,
    signedBitsValue,binaryDigitsValue,bitListTrim_value]

def bitFourierDyadicDenominator (p : ℕ) : FourierFraction :=
  FourierFraction.ofNatDigits (fourierPowTwoDigits (p+2))

theorem bitFourierDyadicDenominator_value (p : ℕ) :
    (bitFourierDyadicDenominator p).value=(dyadicFourierDenominator p : ℚ) := by
  simp [bitFourierDyadicDenominator,dyadicFourierDenominator,fourierPowTwoDigits_value]

def bitDyadicCharacter (X M : FourierFraction) (p : ℕ) : BitFourierInteger :=
  let q := bitRationalCharacter X M (p+2)
  let D := bitFourierDyadicDenominator p
  ⟨bitFourierRoundedFraction (D.mul q.1),bitFourierRoundedFraction (D.mul q.2)⟩

theorem bitDyadicCharacter_canonical (X M : FourierFraction) (p : ℕ) :
    (bitDyadicCharacter X M p).Canonical :=
  ⟨bitFourierRoundedFraction_canonical _,bitFourierRoundedFraction_canonical _⟩

theorem bitDyadicCharacter_value {N : ℕ} [NeZero N] (x : ZMod N) (X M : FourierFraction)
    (hX : X.value=(x.val : ℚ)) (hM : M.value=(N : ℚ)) (p : ℕ) :
    (bitDyadicCharacter X M p).value=dyadicCharacterInteger x p := by
  have hre := congrArg Prod.fst (bitRationalCharacter_value x X M hX hM (p+2))
  have him := congrArg Prod.snd (bitRationalCharacter_value x X M hX hM (p+2))
  dsimp only at hre him
  change FourierInteger.mk
    (bitFourierRoundedFraction ((bitFourierDyadicDenominator p).mul (bitRationalCharacter X M (p+2)).1)).value
    (bitFourierRoundedFraction ((bitFourierDyadicDenominator p).mul (bitRationalCharacter X M (p+2)).2)).value=_
  simp only [bitFourierRoundedFraction_value,FourierFraction.mul_value,
    bitFourierDyadicDenominator_value,hre,him,dyadicCharacterInteger,roundedFourierInteger]

/-- Reduce the actual stored nonnegative argument modulo the actual stored
positive modulus before constructing a character. -/
def bitModularDyadicCharacter (as ms : List Bool) (p : ℕ) : BitFourierInteger :=
  let rem := (bitListDivision as ms).remainder
  bitDyadicCharacter (FourierFraction.ofNatDigits rem) (FourierFraction.ofNatDigits ms) p

theorem bitModularDyadicCharacter_value {N : ℕ} [NeZero N] (as ms : List Bool)
    (hM : binaryDigitsValue ms=N) (p : ℕ) :
    (bitModularDyadicCharacter as ms p).value=
      dyadicCharacterInteger ((binaryDigitsValue as : ℕ) : ZMod N) p := by
  have hpos : 0<binaryDigitsValue ms := by rw [hM]; exact NeZero.pos N
  apply bitDyadicCharacter_value
  · rw [FourierFraction.ofNatDigits_value,(bitListDivision_correct as ms hpos).2,hM,ZMod.val_natCast]
  · rw [FourierFraction.ofNatDigits_value,hM]

theorem bitModularDyadicCharacter_error {N : ℕ} [NeZero N] (as ms : List Bool)
    (hM : binaryDigitsValue ms=N) (p : ℕ) :
    ‖fourierIntegerValue (bitModularDyadicCharacter as ms p).value/(dyadicFourierDenominator p : ℂ)-
      ZMod.stdAddChar ((binaryDigitsValue as : ℕ) : ZMod N)‖≤(1/2 : ℝ)^p := by
  rw [bitModularDyadicCharacter_value as ms hM]
  exact dyadicCharacterInteger_error _ p

end Optss
