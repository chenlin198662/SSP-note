import Optss.ProperizationBoxing
import Optss.ActiveProgression

/-!
# Rank descent for mathematical properization

This module assembles zero-coordinate suppression, actual primitive quotient
and reboxing, and strong rank induction. The rational reduced-basis existence
property is an explicit dependency here, discharged by the completed reduction
proof in `ProperizationExistence`. No algorithmic bit bound is asserted here.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {G : Type*} [AddCommGroup G] [IsAddTorsionFree G]

/-- The exact geometric input supplied by rational lattice reduction. -/
def RationalReductionProperty (r : ℕ) (ω : ℝ) : Prop :=
  ∀ a : (Fin r → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin r),
    Nonempty (RationalNormalizationData a) →
    ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
      basisIntegerLattice b = Set.range realVector ∧
      euclideanOrthogonalityDefect (b.map a.toLinearEquiv) ≤ ω

/-- A uniform upper bound on every reboxing factor below rank `R`. -/
def properizationIterationFactor (Ω : ℕ → ℝ) (t R : ℕ) : ℕ :=
  max 1 ((Finset.range (R+1)).sup
    (fun k => (latticeBoxingResidueModulus k (Ω k))^k*(1+t)^(k+1)))

theorem properizationIterationFactor_pos (Ω : ℕ → ℝ) (t R : ℕ) :
    1 ≤ properizationIterationFactor Ω t R := le_max_left _ _

theorem properizationIterationFactor_bound (Ω : ℕ → ℝ) (t R k : ℕ) (hk : k ≤ R) :
    (latticeBoxingResidueModulus k (Ω k))^k*(1+t)^(k+1) ≤
      properizationIterationFactor Ω t R := by
  exact (Finset.le_sup (f := fun k =>
    (latticeBoxingResidueModulus k (Ω k))^k*(1+t)^(k+1))
    (Finset.mem_range.mpr (by omega))).trans (le_max_right _ _)

theorem integerBudgetBox_nonempty {d : ℕ} (β : Fin d → ℕ) :
    (integerBudgetBox β).Nonempty :=
  ⟨0, by simp [mem_integerBudgetBox, InBox]⟩

/-- A failing properness certificate gives an actual smaller GAP; its whole
coefficient volume is controlled by the uniform rank-dependent factor. -/
theorem positiveProgression_rank_step {d : ℕ} (Ω : ℕ → ℝ) (t R : ℕ)
    (hΩ : ∀ k, 0 < Ω k)
    (hred : ∀ k ≤ R, RationalReductionProperty k (Ω k))
    (hd : d ≤ R) (ρ : IntVec d →+ G) (β : Fin d → ℕ) (hβ : ∀ j, 1 ≤ β j)
    (hbad : ¬ Set.InjOn ρ (integerBudgetBox (fun j => t*β j))) :
    ∃ (ρ' : IntVec (d-1) →+ G) (γ : Fin (d-1) → ℕ),
      d-1 < d ∧ integerProgressionValues ρ β ⊆ integerProgressionValues ρ' γ ∧
      (integerBudgetBox γ).card ≤ properizationIterationFactor Ω t R*(integerBudgetBox β).card := by
  rw [integerBox_proper_iff_no_short_kernel] at hbad
  push_neg at hbad
  obtain ⟨z, hz, hker, hnz⟩ := hbad
  have hz' : z ∈ integerBudgetBox (fun j => 2*t*β j) := by
    simpa only [Nat.mul_assoc] using hz
  obtain ⟨hdrop, p, ℓ, hp, hρ, hb, _, _⟩ :=
    exists_properization_quotient_step ρ β t z hnz hz' hker
  by_cases hd1 : d=1
  · subst d
    refine ⟨0, fun _ => 0, hdrop, ?_, ?_⟩
    · rw [primitiveQuotient_rank_zero p ℓ hp ρ hρ β]
      intro y hy
      have hy0 : y=0 := Finset.mem_singleton.mp hy
      subst y
      exact Finset.mem_image.mpr ⟨0, by simp [mem_integerBudgetBox, InBox], rfl⟩
    · have hcard := Finset.card_pos.mpr (integerBudgetBox_nonempty β)
      have hfac := properizationIterationFactor_pos Ω t R
      simp only [integerBudgetBox_card, Finset.prod_const_one]
      simp only [mul_zero, zero_add, Finset.prod_const_one]
      rw [integerBudgetBox_card] at hcard
      nlinarith
  · have hd2 : 1 < d := by omega
    obtain ⟨a, hrat, hrebox⟩ := primitiveQuotient_reboxing hd2 p ℓ hp ρ hρ β hβ t hb
    obtain ⟨b, hΛ, hdefect⟩ := hred (d-1) (by omega) a hrat
    obtain ⟨γ, _, hvalues, hcard⟩ := hrebox b hΛ (Ω (d-1)) (hΩ (d-1)) hdefect
    refine ⟨reboxedPrimitiveHom p ℓ hp ρ b hΛ, γ, hdrop, hvalues, ?_⟩
    apply hcard.trans
    apply Nat.mul_le_mul_right
    have hf := properizationIterationFactor_bound Ω t R (d-1) (by omega)
    simpa only [Nat.sub_add_cancel (by omega : 1 ≤ d)] using hf

/-- Strong rank induction assembles all quotient steps and zero-coordinate
reductions. The final enlargement factor depends only on the original rank,
dilation, and the dimension-only reduction bounds. -/
theorem integerProgression_properization_of_reduction (Ω : ℕ → ℝ) (t R : ℕ)
    (hΩ : ∀ k, 0 < Ω k) (hred : ∀ k ≤ R, RationalReductionProperty k (Ω k)) :
    ∀ d ≤ R, ∀ (ρ : IntVec d →+ G) (β : Fin d → ℕ),
      ∃ r ≤ d, ∃ (ρ' : IntVec r →+ G) (γ : Fin r → ℕ),
        integerProgressionValues ρ β ⊆ integerProgressionValues ρ' γ ∧
        Set.InjOn ρ' (integerBudgetBox (fun j => t*γ j)) ∧
        (integerBudgetBox γ).card ≤
          (properizationIterationFactor Ω t R)^d*(integerBudgetBox β).card := by
  intro d
  induction d using Nat.strong_induction_on with
  | h d ih =>
    intro hd ρ β
    let A := properizationIterationFactor Ω t R
    have hA : 1 ≤ A := properizationIterationFactor_pos Ω t R
    by_cases hgood : Set.InjOn ρ (integerBudgetBox (fun j => t*β j))
    · refine ⟨d, le_rfl, ρ, β, Finset.Subset.refl _, hgood, ?_⟩
      have hp : 1 ≤ A^d := one_le_pow₀ hA
      change (integerBudgetBox β).card ≤ A^d*(integerBudgetBox β).card
      nlinarith
    · let e := Fintype.card (PositiveCoordinate β)
      let ρ₀ := positiveProgressionHom ρ β
      let β₀ := positiveBudget β
      have he : e ≤ d := positiveCoordinate_count_le β
      have hβ₀ : ∀ j, 1 ≤ β₀ j := fun j => positiveBudget_pos β j
      have hvalues : integerProgressionValues ρ β = integerProgressionValues ρ₀ β₀ := by
        simpa only [one_mul] using positiveProgression_values ρ β 1
      have hcard₀ : (integerBudgetBox β₀).card = (integerBudgetBox β).card := by
        simpa only [one_mul] using (scaledBox_positive_card β 1).symm
      have hbad₀ : ¬ Set.InjOn ρ₀ (integerBudgetBox (fun j => t*β₀ j)) := by
        intro hg
        exact hgood ((positiveProgression_proper_iff ρ β t).mpr hg)
      obtain ⟨ρ₁, β₁, hdrop, hcont₁, hcard₁⟩ := positiveProgression_rank_step Ω t R hΩ hred
        (he.trans hd) ρ₀ β₀ hβ₀ hbad₀
      have hsmall : e-1 < d := hdrop.trans_le he
      obtain ⟨r, hr, ρ', γ, hcont₂, hproper, hcard₂⟩ := ih (e-1) hsmall
        ((Nat.le_of_lt hsmall).trans hd) ρ₁ β₁
      refine ⟨r, hr.trans (Nat.le_of_lt hsmall), ρ', γ, ?_, hproper, ?_⟩
      · rw [hvalues]
        exact hcont₁.trans hcont₂
      · change (integerBudgetBox γ).card ≤ A^d*(integerBudgetBox β).card
        calc
          _ ≤ A^(e-1)*(integerBudgetBox β₁).card := hcard₂
          _ ≤ A^(e-1)*(A*(integerBudgetBox β₀).card) := Nat.mul_le_mul_left _ hcard₁
          _ = A^e*(integerBudgetBox β).card := by
            rw [hcard₀, ← mul_assoc, ← pow_succ, Nat.sub_add_cancel (by omega : 1 ≤ e)]
          _ ≤ A^d*(integerBudgetBox β).card :=
            Nat.mul_le_mul_right _ (pow_le_pow_right₀ hA he)

end
end Optss
