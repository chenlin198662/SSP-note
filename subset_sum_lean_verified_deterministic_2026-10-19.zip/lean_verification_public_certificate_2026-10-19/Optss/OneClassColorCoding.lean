import Optss.ColorRetentionProbability
import Optss.BucketLoadProbability
import Optss.FiniteUniformProbability
import Optss.ColorParameters

/-!
# Two-stage color coding for one size class

A sample is a uniformly chosen pair: a hash of all original labels to buckets,
and fresh repeated colorings for every bucket. The actual support construction
is unconditionally sound and retains each fixed in-box witness with the proved
failure bound. No oracle for concentration or independent events is assumed.
The size-class runtime and its array accounting are separate obligations.
-/

namespace Optss
open scoped BigOperators
noncomputable section

variable {ι G : Type*} [Fintype ι] [DecidableEq ι] [AddCommGroup G] [DecidableEq G]

abbrev HashColorSample (ι : Type*) (b L R : ℕ) :=
  (ι → Fin b) × (Fin b → Fin R → ι → Fin (128*L^2))

def oneClassColorSupport (v : ι → G) (S : Finset ι) (B : Set G) [DecidablePred B]
    {b L R : ℕ} (sample : HashColorSample ι b L R) : Finset G :=
  clippedBucketColorSupport v S sample.1 sample.2 B

/-- The actual target-missing event in the joint independent sample space. -/
def hashColorFailure (v : ι → G) (S : Finset ι) (t : G)
    (B : Set G) [DecidablePred B] (b L R : ℕ) : Finset (HashColorSample ι b L R) :=
  jointUniformEvent (fun bucket => colorSupportFailure v S t bucket B L R)

@[simp] theorem mem_hashColorFailure (v : ι → G) (S : Finset ι) (t : G)
    (B : Set G) [DecidablePred B] (b L R : ℕ) (sample : HashColorSample ι b L R) :
    sample ∈ hashColorFailure v S t B b L R ↔ t ∉ oneClassColorSupport v S B sample := by
  classical
  rcases sample with ⟨bucket, color⟩
  simp only [hashColorFailure, mem_jointUniformEvent, colorSupportFailure,
    Finset.mem_filter, Finset.mem_univ, true_and, oneClassColorSupport]

omit [Fintype ι] in
/-- Every outcome has genuine distinct-label witnesses, irrespective of whether
any probabilistic retention event succeeds. -/
theorem oneClassColorSupport_sound (v : ι → G) (S : Finset ι)
    (B : Set G) [DecidablePred B] {b L R : ℕ} (sample : HashColorSample ι b L R)
    {t : G} (ht : t ∈ oneClassColorSupport v S B sample) :
    t ∈ B ∧ ∃ s : Finset ι, s ⊆ S ∧ (∑ i ∈ s, v i) = t :=
  clippedBucketColorSupport_sound v S sample.1 sample.2 B ht

/-- Combine concentration and conditional coloring retention on the actual
joint distribution. The conditional event may depend on the sampled hash. -/
theorem uniform_hashColorFailure_le (v : ι → G) (S s : Finset ι)
    (B : Set G) [DecidablePred B] (b L R : ℕ)
    (hb : 0 < b) (hL : 0 < L) (hs : s ⊆ S) (hcard : s.card ≤ b*L)
    (hB : (∑ i ∈ s, v i) ∈ B) :
    uniformProbability (hashColorFailure v S (∑ i ∈ s, v i) B b L R) ≤
      (b:ℝ)*(1/2:ℝ)^(4*L) + (b:ℝ)*(1/4:ℝ)^R := by
  classical
  letI : Nonempty (Fin b) := ⟨⟨0,hb⟩⟩
  letI : Nonempty (Fin (128*L^2)) := ⟨⟨0,by positivity⟩⟩
  unfold hashColorFailure
  have hcond := uniformProbability_joint_le
    (fun bucket => colorSupportFailure v S (∑ i ∈ s, v i) bucket B L R)
    (Finset.univ.biUnion (bucketOverloadEvent s b L)) ((b:ℝ)*(1/4:ℝ)^R)
    (by positivity) (by
      intro bucket hgood
      apply uniform_colorSupportFailure_le v S s bucket B L R hL hs hB
      exact (not_mem_any_bucket_overload_iff s b L bucket).mp hgood)
  exact hcond.trans (add_le_add_right (uniform_any_bucket_overload_bound s b L hb hcard) _)

/-- Allocating half the failure allowance to each stage proves the actual
fixed-witness retention guarantee in Lemma A.2. -/
theorem uniform_hashColorFailure_le_allowance (v : ι → G) (S s : Finset ι)
    (B : Set G) [DecidablePred B] (b L R : ℕ)
    (hb : 0 < b) (hL : 0 < L) (hs : s ⊆ S) (hcard : s.card ≤ b*L)
    (hB : (∑ i ∈ s, v i) ∈ B) (ζ : ℝ)
    (hload : 2*(b:ℝ) ≤ ζ*2^(4*L)) (hrepeat : 2*(b:ℝ) ≤ ζ*2^R) :
    uniformProbability (hashColorFailure v S (∑ i ∈ s, v i) B b L R) ≤ ζ := by
  refine (uniform_hashColorFailure_le v S s B b L R hb hL hs hcard hB).trans ?_
  have hrep := bucket_collision_amplification b R ζ hrepeat
  have hlo : (b:ℝ)*(1/2:ℝ)^(4*L) ≤ ζ/2 := by
    rw [one_div_pow, mul_one_div]
    apply (div_le_iff₀ (by positivity : (0:ℝ) < 2^(4*L))).mpr
    nlinarith
  linarith

/-- Success probability in the usual `1−ζ` form, under the explicitly modeled
uniform hash and independent coloring experiment. -/
theorem uniform_oneClassColorSupport_retains (v : ι → G) (S s : Finset ι)
    (B : Set G) [DecidablePred B] (b L R : ℕ)
    (hb : 0 < b) (hL : 0 < L) (hs : s ⊆ S) (hcard : s.card ≤ b*L)
    (hB : (∑ i ∈ s, v i) ∈ B) (ζ : ℝ)
    (hload : 2*(b:ℝ) ≤ ζ*2^(4*L)) (hrepeat : 2*(b:ℝ) ≤ ζ*2^R) :
    1-ζ ≤ uniformProbability
      (Finset.univ.filter (fun sample : HashColorSample ι b L R =>
        (∑ i ∈ s, v i) ∈ oneClassColorSupport v S B sample)) := by
  classical
  letI : Nonempty (Fin b) := ⟨⟨0,hb⟩⟩
  letI : Nonempty (Fin (128*L^2)) := ⟨⟨0,by positivity⟩⟩
  have he : Finset.univ.filter (fun sample : HashColorSample ι b L R =>
      (∑ i ∈ s, v i) ∈ oneClassColorSupport v S B sample) =
      (hashColorFailure v S (∑ i ∈ s, v i) B b L R)ᶜ := by
    ext sample
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_compl,
      mem_hashColorFailure, not_not]
  rw [he, uniformProbability_compl]
  have h := uniform_hashColorFailure_le_allowance v S s B b L R hb hL hs hcard hB ζ hload hrepeat
  linarith


/-- Fixed-witness probability with every bucket, color and repetition parameter
chosen explicitly as in Appendix A.2. Small-vector assumptions are needed only
for the separate array/runtime bound, not for this probability or soundness. -/
theorem configured_oneClass_fixed_witness (v : ι → G) (S s : Finset ι)
    (B : Set G) [DecidablePred B] (k V : ℕ) (hk : 1 ≤ k) (hkm : k ≤ S.card)
    (hV : 1 ≤ V) (hs : s ⊆ S) (hcard : s.card ≤ k) (hB : (∑ i ∈ s, v i) ∈ B)
    (ζ : ℝ) (hζ : 0 < ζ) (hζ1 : ζ < 1) :
    let L := colorLoadParameter S.card V ζ
    let b := colorBucketCount k L
    let R := colorRepetitionCount b ζ
    1-ζ ≤ uniformProbability (Finset.univ.filter (fun sample : HashColorSample ι b L R =>
      (∑ i ∈ s, v i) ∈ oneClassColorSupport v S B sample)) := by
  dsimp only
  obtain ⟨hL, hb, _, _, hcapacity⟩ :=
    color_parameter_bucket_bounds S.card k V ζ hk hkm hV hζ hζ1
  apply uniform_oneClassColorSupport_retains v S s B _ _ _ hb hL hs
    (hcard.trans hcapacity) hB ζ
  · exact color_parameter_load_budget S.card k V ζ hk hkm hV hζ hζ1
  · exact ceil_log_repetitions_sufficient _ hb ζ hζ

end
end Optss
