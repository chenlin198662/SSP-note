import Optss.ModelingSieve
import Mathlib.Combinatorics.Pigeonhole

/-!
# A large short-interval part of the finite model

The least nonnegative residues are partitioned by `floor(8r/q)`. One of the
eight parts contains at least one eighth of the original elements, and its
integer residue interval has diameter strictly less than `q/8`. Combined with
the finite sieve, this supplies the large Freiman-eight model in the first
part of Lemma 10.2. Prime construction, the containing GAP, and complexity are
not asserted here.
-/

namespace Optss
open scoped BigOperators

/-- The eight consecutive parts of the standard residue interval. -/
def modelingPartIndex {q : ℕ} (hq : 0 < q) (lam : ZMod q) (a : ℤ) : Fin 8 := by
  letI : NeZero q := ⟨Nat.ne_of_gt hq⟩
  refine ⟨(8 * modelingResidue lam a / (q : ℤ)).toNat, ?_⟩
  have hr := modelingResidue_bounds lam a
  have hq' : (0 : ℤ) < q := by exact_mod_cast hq
  have hd : 8 * modelingResidue lam a / (q : ℤ) < 8 :=
    (Int.ediv_lt_iff_lt_mul hq').mpr (by omega)
  omega

/-- Two residues in the same part differ by strictly less than `q/8`. -/
theorem modelingPartIndex_difference_lt {q : ℕ} (hq : 0 < q) (lam : ZMod q)
    (a b : ℤ) (he : modelingPartIndex hq lam a = modelingPartIndex hq lam b) :
    8 * (modelingResidue lam a - modelingResidue lam b) < q := by
  letI : NeZero q := ⟨Nat.ne_of_gt hq⟩
  have hq' : (0 : ℤ) < q := by exact_mod_cast hq
  have ha := modelingResidue_bounds lam a
  have hb := modelingResidue_bounds lam b
  have hda : 0 ≤ 8 * modelingResidue lam a / (q : ℤ) :=
    Int.ediv_nonneg (by omega) (by omega)
  have hdb : 0 ≤ 8 * modelingResidue lam b / (q : ℤ) :=
    Int.ediv_nonneg (by omega) (by omega)
  have hed : 8 * modelingResidue lam a / (q : ℤ) =
      8 * modelingResidue lam b / (q : ℤ) := by
    have heval := congrArg Fin.val he
    change (8 * modelingResidue lam a / (q : ℤ)).toNat =
      (8 * modelingResidue lam b / (q : ℤ)).toNat at heval
    omega
  have hlo := Int.ediv_mul_le (8 * modelingResidue lam b) (ne_of_gt hq')
  have hhi : 8 * modelingResidue lam a <
      (8 * modelingResidue lam a / (q : ℤ) + 1) * (q : ℤ) :=
    (Int.ediv_lt_iff_lt_mul hq').mp (by omega)
  rw [hed] at hhi
  nlinarith

private theorem exists_large_eight_fiber {α : Type*} (S : Finset α) (f : α → Fin 8) :
    ∃ j : Fin 8, S.card ≤ 8 * (S.filter (fun a => f a = j)).card := by
  classical
  obtain ⟨j, _, hj⟩ := Finset.exists_max_image (Finset.univ : Finset (Fin 8))
    (fun j => (S.filter (fun a => f a = j)).card) Finset.univ_nonempty
  refine ⟨j, ?_⟩
  calc
    S.card = ∑ k : Fin 8, (S.filter (fun a => f a = k)).card :=
      Finset.card_eq_sum_card_fiberwise (fun a _ => Finset.mem_univ (f a))
    _ ≤ ∑ _k : Fin 8, (S.filter (fun a => f a = j)).card :=
      Finset.sum_le_sum (fun k hk => hj k hk)
    _ = 8 * (S.filter (fun a => f a = j)).card := by simp

/-- One of the eight parts has at least an eighth of the input cardinality,
and lies in an integer residue interval of diameter less than `q/8`.
The empty input is handled with the empty part and interval `[0,0]`. -/
theorem exists_large_modeling_part (S : Finset ℤ) {q : ℕ} (hq : 0 < q)
    (lam : ZMod q) :
    ∃ (T : Finset ℤ) (L U : ℤ), T ⊆ S ∧ S.card ≤ 8 * T.card ∧
      (∀ a ∈ T, L ≤ modelingResidue lam a ∧ modelingResidue lam a ≤ U) ∧
      8 * (U - L) < q := by
  classical
  by_cases hs : S.Nonempty
  · obtain ⟨j, hj⟩ := exists_large_eight_fiber S (modelingPartIndex hq lam)
    let T := S.filter (fun a => modelingPartIndex hq lam a = j)
    have ht : T.Nonempty := by
      apply Finset.card_pos.mp
      have hc := Finset.card_pos.mpr hs
      change S.card ≤ 8 * T.card at hj
      omega
    let R := T.image (modelingResidue lam)
    have hR : R.Nonempty := ht.image _
    have hlo : R.min' hR ∈ R := Finset.min'_mem _ _
    have hhi : R.max' hR ∈ R := Finset.max'_mem _ _
    obtain ⟨a, ha, hae⟩ := Finset.mem_image.mp hhi
    obtain ⟨b, hb, hbe⟩ := Finset.mem_image.mp hlo
    refine ⟨T, R.min' hR, R.max' hR, Finset.filter_subset _ _, hj, ?_, ?_⟩
    · intro x hx
      have hxR : modelingResidue lam x ∈ R := Finset.mem_image.mpr ⟨x, hx, rfl⟩
      exact ⟨Finset.min'_le _ _ hxR, Finset.le_max' _ _ hxR⟩
    · rw [← hae, ← hbe]
      apply modelingPartIndex_difference_lt hq lam a b
      exact (Finset.mem_filter.mp ha).2.trans (Finset.mem_filter.mp hb).2.symm
  · have hs0 : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hs
    subst S
    refine ⟨∅, 0, 0, by simp, by simp, by simp, ?_⟩
    simpa using (show (0 : ℤ) < q by exact_mod_cast hq)

/-- The sieve and the eight-part partition give a large actual Freiman-eight
model. Both directions of relation preservation are proved for the selected
part. This is the finite modeling stage of Lemma 10.2, without the later GAP
construction or any running-time claim. -/
theorem exists_large_freiman_eight_model (S : Finset ℤ) (p q : ℕ) [Fact q.Prime]
    (u : ℤ) (hS : ∀ a ∈ S, 0 ≤ a ∧ a ≤ u) (hq : 8 * u < q)
    (hp : ((modelingDifferences S 8).erase 0).card < p) :
    ∃ (lam : ZMod q) (T : Finset ℤ) (L U : ℤ),
      lam ≠ 0 ∧ T ⊆ S ∧ S.card ≤ 8 * T.card ∧
      (∀ a ∈ T, L ≤ modelingResidue lam a ∧ modelingResidue lam a ≤ U) ∧
      8 * (U - L) < q ∧
      Set.InjOn (fun a => (modelingResidue lam a : ZMod p)) (T : Set ℤ) ∧
      (∀ a b : Fin 8 → ℤ, (∀ i, a i ∈ T) → (∀ i, b i ∈ T) →
        ((∑ i, (modelingResidue lam (a i) : ZMod p)) =
          (∑ i, (modelingResidue lam (b i) : ZMod p)) ↔
          (∑ i, a i) = (∑ i, b i))) := by
  obtain ⟨lam, hlam, hmodel⟩ := exists_freiman_eight_model S p q u hS hq hp
  obtain ⟨T, L, U, hTS, hcard, hinterval, hwidth⟩ :=
    exists_large_modeling_part S (Fact.out : q.Prime).pos lam
  have hrel (a b : Fin 8 → ℤ) (ha : ∀ i, a i ∈ T) (hb : ∀ i, b i ∈ T) :
      ((∑ i, (modelingResidue lam (a i) : ZMod p)) =
        (∑ i, (modelingResidue lam (b i) : ZMod p)) ↔
        (∑ i, a i) = (∑ i, b i)) :=
    hmodel L U hwidth a b (fun i => hTS (ha i)) (fun i => hTS (hb i))
      (fun i => hinterval _ (ha i)) (fun i => hinterval _ (hb i))
  refine ⟨lam, T, L, U, hlam, hTS, hcard, hinterval, hwidth, ?_, hrel⟩
  intro a ha b hb hab
  have he := (hrel (fun _ => a) (fun _ => b) (fun _ => ha) (fun _ => hb)).mp
    (by simp [hab])
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at he
  omega

end Optss
