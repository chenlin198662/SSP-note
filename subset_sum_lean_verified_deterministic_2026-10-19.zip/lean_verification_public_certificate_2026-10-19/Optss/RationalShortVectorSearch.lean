import Optss.BoundedShortVectorSearch
import Optss.ExecutableVertexSelection
import Optss.SharpLatticeDefect
import Optss.RationalGramSchmidt

/-!
# Deterministic finite short-vector search on a rational reduced basis

The executed search enumerates a coefficient cube whose radius depends only
on rank, evaluates exact rational vectors, and tests the unit coordinate box.
Its completeness is proved from the actual sharp LLL defect bound.
-/
namespace Optss
open scoped BigOperators
variable {r : ℕ}

def integerCoefficientTuples (r C : ℕ) : List (Fin r→ℤ) :=
  (vertexIndexTuples (2*C+1) r).map fun t j => (t j:ℤ)-(C:ℤ)

theorem mem_integerCoefficientTuples (C : ℕ) (z : Fin r→ℤ) :
    z∈integerCoefficientTuples r C ↔ z∈integerBudgetBox (fun _ => C) := by
  rw [mem_integerBudgetBox]
  unfold InBox
  constructor
  · intro hz
    obtain ⟨t,ht,rfl⟩ := List.mem_map.mp hz
    intro j
    dsimp only
    have hj := (t j).isLt
    rw [abs_le]
    constructor <;> omega
  · intro hz
    dsimp only at hz
    let t : Fin r→Fin (2*C+1) := fun j => ⟨(z j+C).toNat,by
      have h := abs_le.mp (hz j)
      omega⟩
    apply List.mem_map.mpr
    refine ⟨t,mem_vertexIndexTuples t,?_⟩
    funext j
    have h := abs_le.mp (hz j)
    change (((z j+C).toNat:ℤ)-C)=z j
    omega

theorem integerCoefficientTuples_length (r C : ℕ) :
    (integerCoefficientTuples r C).length=(2*C+1)^r := by
  rw [integerCoefficientTuples,List.length_map,vertexIndexTuples_length]

def rationalIntegerSynthesis (B : Matrix (Fin r) (Fin r) ℚ) (z : Fin r→ℤ) : Fin r→ℚ :=
  fun i => ∑ j,(z j:ℚ)*B j i

def rationalShortCoefficient (B : Matrix (Fin r) (Fin r) ℚ) (z : Fin r→ℤ) : Bool :=
  decide (z≠0 ∧ ∀ i,|rationalIntegerSynthesis B z i|≤1)

def integerSharpDefectBound (r : ℕ) : ℕ := 2^(r*r)

def rationalShortSearchRadius (r : ℕ) : ℕ := shortVectorCoefficientRadius r (integerSharpDefectBound r)

def rationalShortVectorSearch (B : Matrix (Fin r) (Fin r) ℚ) : Option (Fin r→ℤ) :=
  (integerCoefficientTuples r (rationalShortSearchRadius r)).find? (rationalShortCoefficient B)

theorem sharpLatticeDefectBound_le_integer (r : ℕ) :
    sharpLatticeDefectBound r≤(integerSharpDefectBound r:ℝ) := by
  have he : (r:ℝ)*((r:ℝ)-1)/4≤(r*r:ℕ) := by
    push_cast
    nlinarith [show (0:ℝ)≤r from Nat.cast_nonneg r]
  have h := Real.rpow_le_rpow_of_exponent_le (show (1:ℝ)≤2 by norm_num) he
  simpa only [sharpLatticeDefectBound,integerSharpDefectBound,Nat.cast_pow,Nat.cast_ofNat,
    Real.rpow_natCast] using h

theorem rationalIntegerSynthesis_real (B : Matrix (Fin r) (Fin r) ℚ)
    (b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)))
    (hb : ∀ j,b j=rationalEuclideanRows B j) (z : Fin r→ℤ) (i : Fin r) :
    latticeIntegerSynthesis b z i=(rationalIntegerSynthesis B z i:ℝ) := by
  have hs : rationalIntegerSynthesis B z=∑ j,(z j:ℚ) •B j := by
    ext k
    simp [rationalIntegerSynthesis,Finset.sum_apply]
  have h : latticeIntegerSynthesis b z=rationalEuclideanVector (rationalIntegerSynthesis B z) := by
    rw [hs,map_sum]
    unfold latticeIntegerSynthesis
    apply Finset.sum_congr rfl
    intro j _
    rw [rationalEuclideanVector_smul,hb]
    simp only [Rat.cast_intCast]
    rfl
  rw [h]
  rfl

theorem rationalShortCoefficient_iff (B : Matrix (Fin r) (Fin r) ℚ)
    (b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)))
    (hb : ∀ j,b j=rationalEuclideanRows B j) (z : Fin r→ℤ) :
    rationalShortCoefficient B z=true ↔ z≠0 ∧ latticeIntegerSynthesis b z∈euclideanCoordinateCube r 1 := by
  simp only [rationalShortCoefficient,decide_eq_true_eq,euclideanCoordinateCube,Set.mem_setOf_eq]
  constructor
  · rintro ⟨hz,hs⟩
    refine ⟨hz,fun i => ?_⟩
    rw [rationalIntegerSynthesis_real B b hb]
    exact_mod_cast hs i
  · rintro ⟨hz,hs⟩
    refine ⟨hz,fun i => ?_⟩
    have hi := hs i
    rw [rationalIntegerSynthesis_real B b hb] at hi
    exact_mod_cast hi

theorem rationalShortVectorSearch_sound (B : Matrix (Fin r) (Fin r) ℚ)
    (z : Fin r→ℤ) (hz : rationalShortVectorSearch B=some z) :
    z≠0 ∧ ∀ i,|rationalIntegerSynthesis B z i|≤1 := by
  exact of_decide_eq_true (List.find?_eq_some_iff_append.mp hz).1

/-- Exact successful-search criterion for the given actual rational basis. -/
theorem rationalShortVectorSearch_ne_none_iff (hr : 0<r)
    (B : Matrix (Fin r) (Fin r) ℚ)
    (b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)))
    (hb : ∀ j,b j=rationalEuclideanRows B j)
    (hdefect : euclideanOrthogonalityDefect b≤sharpLatticeDefectBound r) :
    rationalShortVectorSearch B≠none ↔
      ∃ x∈basisIntegerLattice b,x≠0 ∧ x∈euclideanCoordinateCube r 1 := by
  classical
  rw [exists_short_lattice_vector_iff_coefficient_box hr b (integerSharpDefectBound r)
    (by unfold integerSharpDefectBound; positivity) (hdefect.trans (sharpLatticeDefectBound_le_integer r))]
  simp only [rationalShortVectorSearch,ne_eq,List.find?_eq_none,not_forall,not_not]
  constructor
  · rintro ⟨z,h⟩
    have h' : z∈integerCoefficientTuples r (rationalShortSearchRadius r) ∧ rationalShortCoefficient B z=true := by tauto
    exact ⟨z,(mem_integerCoefficientTuples _ z).mp h'.1,(rationalShortCoefficient_iff B b hb z).mp h'.2⟩
  · rintro ⟨z,hz,hzn,hzK⟩
    refine ⟨z,?_⟩
    have hm := (mem_integerCoefficientTuples (rationalShortSearchRadius r) z).mpr hz
    have hp := (rationalShortCoefficient_iff B b hb z).mpr ⟨hzn,hzK⟩
    tauto

/-- This literal list length, and hence the number of tested candidates,
depends only on rank. -/
theorem rationalShortVectorSearch_candidates (r : ℕ) :
    (integerCoefficientTuples r (rationalShortSearchRadius r)).length=
      (2*(r.factorial*2^(r*r)*r)+1)^r := by
  rw [integerCoefficientTuples_length]
  rfl
end Optss
