import Optss.CommonGapModel

/-!
# Uniform linear budgets for the actual seed and greedy block

The phase coefficient volume controls the integer determinant bound. The
proved logarithmic seed estimate is therefore absorbed into a constant times
`h`, uniformly over every rank below the phase rank bound.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1000000

def commonPhaseDeterminantConstant (R : ℕ) (C : ℝ) : ℕ := max 1 ⌈(R.factorial : ℝ)*C⌉₊

def commonPhaseBlockConstant (R : ℕ) (C c η : ℝ) (a : ℕ) : ℕ :=
  max 1 ⌈latticeSeedLinearConstant R (commonPhaseDeterminantConstant R C) η+
    greedyProfileConstant c a η⌉₊

/-- Natural determinant bound from the actual phase box volume. -/
theorem common_phase_determinant_bound {d : ℕ} (w : Fin d → ℕ) (R h M : ℕ)
    (hd : d ≤ R) (hh : 1 ≤ h) (C : ℝ) (hC : 0 ≤ C)
    (hvolume : ((integerBudgetBox (fun j => h*w j)).card : ℝ) ≤ C*M) :
    d.factorial*∏ j, w j ≤ commonPhaseDeterminantConstant R C*(M+2) := by
  have hp : (∏ j, w j) ≤ (integerBudgetBox (fun j => h*w j)).card := by
    rw [integerBudgetBox_card]
    apply Finset.prod_le_prod'
    intro j _
    have hw := Nat.mul_le_mul_right (w j) hh
    nlinarith
  have hdet : (d.factorial*∏ j, w j : ℕ) ≤ (R.factorial : ℝ)*C*M := by
    have hprod := (Nat.cast_le.mpr hp).trans hvolume
    have hfact : (d.factorial : ℝ) ≤ R.factorial := Nat.cast_le.mpr (Nat.factorial_le hd)
    have hm := mul_le_mul hfact hprod (by positivity) (by positivity)
    simpa only [Nat.cast_mul, mul_assoc] using hm
  have hK : (R.factorial : ℝ)*C ≤ commonPhaseDeterminantConstant R C :=
    (Nat.le_ceil _).trans (Nat.cast_le.mpr (le_max_right _ _))
  have hb : (d.factorial*∏ j, w j : ℕ) ≤
      (commonPhaseDeterminantConstant R C : ℝ)*(M+2 : ℕ) := by
    calc
      _ ≤ (R.factorial : ℝ)*C*M := hdet
      _ ≤ (commonPhaseDeterminantConstant R C : ℝ)*M := mul_le_mul_of_nonneg_right hK (Nat.cast_nonneg _)
      _ ≤ (commonPhaseDeterminantConstant R C : ℝ)*(M+2 : ℕ) :=
        mul_le_mul_of_nonneg_left (by exact_mod_cast (Nat.le_add_right M 2)) (Nat.cast_nonneg _)
  exact_mod_cast hb

/-- The actual ceiling used by the block selector is bounded by one uniform
integer constant times `h`. In particular this discharges the `B≤K*h` premise
of common-box density and filling. -/
theorem common_phase_block_budget {d : ℕ} (w : Fin d → ℕ) (R h N M : ℕ)
    (hd : d ≤ R) (hh : 1 ≤ h) (hN : 1 ≤ N) (η : ℝ) (hη : 0 < η)
    (hscale : (N : ℝ)^η ≤ h) (hM : M ≤ h*N+1)
    (C : ℝ) (hC : 0 ≤ C)
    (hvolume : ((integerBudgetBox (fun j => h*w j)).card : ℝ) ≤ C*M)
    (c : ℝ) (a : ℕ) :
    ⌈(latticeSeedCardBound d w : ℝ)+greedyProfileConstant c a η*h⌉₊ ≤
      commonPhaseBlockConstant R C c η a*h := by
  have hdet := common_phase_determinant_bound w R h M hd hh C hC hvolume
  have hseed := latticeSeedCardBound_linear d w (commonPhaseDeterminantConstant R C) h N M
    (le_max_left _ _) hh hN η hη hscale hM hdet
  have hmono : latticeSeedLinearConstant d (commonPhaseDeterminantConstant R C) η ≤
      latticeSeedLinearConstant R (commonPhaseDeterminantConstant R C) η := by
    unfold latticeSeedLinearConstant
    exact add_le_add_right (Nat.cast_le.mpr hd) _
  have htotal : (latticeSeedCardBound d w : ℝ)+greedyProfileConstant c a η*h ≤
      (latticeSeedLinearConstant R (commonPhaseDeterminantConstant R C) η+greedyProfileConstant c a η)*h := by
    have hm := hseed.trans (mul_le_mul_of_nonneg_right hmono (Nat.cast_nonneg h))
    nlinarith
  have hK : latticeSeedLinearConstant R (commonPhaseDeterminantConstant R C) η+
      greedyProfileConstant c a η ≤ commonPhaseBlockConstant R C c η a :=
    (Nat.le_ceil _).trans (Nat.cast_le.mpr (le_max_right _ _))
  apply Nat.ceil_le.mpr
  exact htotal.trans (by simpa only [Nat.cast_mul] using mul_le_mul_of_nonneg_right hK (Nat.cast_nonneg h))

/-- Inflating the allocated support box to at least `h` still has the same
uniform linear bound. This absorbs all minimum-width conditions downstream. -/
theorem common_phase_allocated_budget {d : ℕ} (w : Fin d → ℕ) (R h N M : ℕ)
    (hd : d ≤ R) (hh : 1 ≤ h) (hN : 1 ≤ N) (η : ℝ) (hη : 0 < η)
    (hscale : (N : ℝ)^η ≤ h) (hM : M ≤ h*N+1)
    (C : ℝ) (hC : 0 ≤ C)
    (hvolume : ((integerBudgetBox (fun j => h*w j)).card : ℝ) ≤ C*M)
    (c : ℝ) (a : ℕ) :
    max h ⌈(latticeSeedCardBound d w : ℝ)+greedyProfileConstant c a η*h⌉₊ ≤
      commonPhaseBlockConstant R C c η a*h := by
  apply max_le
  · simpa only [one_mul] using Nat.mul_le_mul_right h (le_max_left 1
      ⌈latticeSeedLinearConstant R (commonPhaseDeterminantConstant R C) η+greedyProfileConstant c a η⌉₊)
  · exact common_phase_block_budget w R h N M hd hh hN η hη hscale hM C hC hvolume c a

end
end Optss
