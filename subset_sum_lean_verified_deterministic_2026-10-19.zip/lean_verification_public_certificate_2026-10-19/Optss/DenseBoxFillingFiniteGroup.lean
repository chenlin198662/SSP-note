import Optss.Progression
import Mathlib.Algebra.Group.Action.Pointwise.Finset
import Mathlib.GroupTheory.GroupAction.Defs

/-!
# Finite quotient saturation in dense-box filling

This proves the finite-group step (Claim 2.12) used in the proof of
Conlon–Fox–Pham Lemma 2.15. Nonempty sets which are not contained in a proper
subgroup coset strictly enlarge every nonempty proper subset under addition.
Consequently at most `|G|-1` such summands fill the whole finite group.

Nonemptiness is explicit, including for the trivial quotient, where exclusion
of proper cosets alone is vacuous. The dense sets used by the paper are nonempty.
This module does not assert the full dense-box filling theorem.
-/
namespace Optss
noncomputable section
open scoped BigOperators Pointwise

variable {G : Type*} [AddCommGroup G] [DecidableEq G]

/-- The nonempty affine-generation condition appearing in the quotient step. -/
def CosetSpanning (A : Finset G) : Prop :=
  A.Nonempty ∧ ∀ H : AddSubgroup G, ∀ z : G, (∀ a ∈ A, a - z ∈ H) → H = ⊤

omit [DecidableEq G] in
/-- Zero and generation of the whole group imply the required coset condition. -/
theorem cosetSpanning_of_zero_mem_closure (A : Finset G) (hzero : 0 ∈ A)
    (hgen : AddSubgroup.closure (A : Set G) = ⊤) : CosetSpanning A := by
  refine ⟨⟨0, hzero⟩, ?_⟩
  intro H z hcoset
  exact subgroup_eq_top_of_generators_in_coset hzero hgen (AddMonoidHom.id G)
    Function.surjective_id H z hcoset

/-- A finite set invariant under every translation is the whole group as soon
as it is nonempty. The stabilizer here is the actual translation action. -/
theorem finset_eq_univ_of_stabilizer_top [Fintype G] (S : Finset G) (hS : S.Nonempty)
    (hstab : AddAction.stabilizer G S = ⊤) : S = Finset.univ := by
  apply Finset.eq_univ_of_forall
  intro x
  obtain ⟨s, hs⟩ := hS
  have hp : x - s ∈ AddAction.stabilizer G S := hstab ▸ AddSubgroup.mem_top _
  have he : (x - s) +ᵥ S = S := AddAction.mem_stabilizer_iff.mp hp
  have hm : (x-s) +ᵥ s ∈ (x-s) +ᵥ S := (Finset.vadd_mem_vadd_finset_iff _).mpr hs
  simpa only [he, vadd_eq_add, sub_add_cancel] using hm

/-- If a coset-spanning summand does not increase cardinality, the original
nonempty set was already the entire finite group. -/
theorem finiteGroup_full_of_no_growth [Fintype G] (S A : Finset G) (hS : S.Nonempty)
    (hA : CosetSpanning A) (hcard : (A + S).card ≤ S.card) : S = Finset.univ := by
  obtain ⟨a₀, ha₀⟩ := hA.1
  have he (a : G) (ha : a ∈ A) : a +ᵥ S = A + S :=
    Finset.eq_of_subset_of_card_le (Finset.vadd_finset_subset_add ha)
      (by simpa only [Finset.card_vadd_finset] using hcard)
  have hstab : AddAction.stabilizer G S = ⊤ := by
    apply hA.2 _ a₀
    intro a ha
    apply AddAction.mem_stabilizer_iff.mpr
    calc
      (a-a₀) +ᵥ S = (-a₀) +ᵥ (a +ᵥ S) := by rw [vadd_vadd]; congr 1; abel
      _ = (-a₀) +ᵥ (a₀ +ᵥ S) := by rw [he a ha, he a₀ ha₀]
      _ = S := neg_vadd_vadd _ _
  exact finset_eq_univ_of_stabilizer_top S hS hstab

/-- Every nonempty proper set gains at least one point from a coset-spanning
summand. This is a proved growth step, not a filling hypothesis. -/
theorem finiteGroup_card_add_lt [Fintype G] (S A : Finset G) (hS : S.Nonempty)
    (hA : CosetSpanning A) (hne : S ≠ Finset.univ) : S.card < (A + S).card := by
  by_contra hn
  exact hne (finiteGroup_full_of_no_growth S A hS hA (Nat.le_of_not_gt hn))

/-- Actual finite Minkowski sums grow to the group cardinality. -/
theorem finiteGroup_list_sum_card [Fintype G] (L : List (Finset G))
    (hL : ∀ A ∈ L, CosetSpanning A) :
    L.sum.Nonempty ∧ min (L.length + 1) (Fintype.card G) ≤ L.sum.card := by
  induction L with
  | nil => simp
  | cons A L ih =>
    have hA : CosetSpanning A := hL A (by simp)
    obtain ⟨hS, hcard⟩ := ih (fun B hB => hL B (by simp [hB]))
    simp only [List.sum_cons, List.length_cons]
    refine ⟨hA.1.add hS, ?_⟩
    by_cases he : L.sum = Finset.univ
    · have hfull : A + L.sum = Finset.univ := by
        rw [he]
        apply Finset.eq_univ_of_forall
        intro x
        obtain ⟨a, ha⟩ := hA.1
        exact Finset.mem_add.mpr ⟨a, ha, x-a, Finset.mem_univ _, by abel⟩
      rw [hfull, Finset.card_univ]
      exact min_le_right _ _
    · have hg := finiteGroup_card_add_lt L.sum A hS hA he
      have hlt : L.sum.card < Fintype.card G := by
        have hle := Finset.card_le_univ L.sum
        have hneq : L.sum.card ≠ Fintype.card G := by
          intro h
          exact he (Finset.eq_univ_of_card _ h)
        omega
      omega

/-- A sharpened form of the finite-group saturation claim: `|G|-1` nonempty
coset-spanning summands already suffice. The empty list handles the trivial group. -/
theorem finiteGroup_list_sum_eq_univ [Fintype G] (L : List (Finset G))
    (hL : ∀ A ∈ L, CosetSpanning A) (hcount : Fintype.card G ≤ L.length + 1) :
    L.sum = Finset.univ := by
  have hcard := (finiteGroup_list_sum_card L hL).2
  rw [min_eq_right hcount] at hcard
  apply Finset.eq_univ_of_card
  exact Nat.le_antisymm (Finset.card_le_univ _) hcard

/-- Indexed form of finite quotient saturation for distinct summand positions. -/
theorem finiteGroup_sum_eq_univ [Fintype G] {n : ℕ} (A : Fin n → Finset G)
    (hA : ∀ i, CosetSpanning (A i)) (hcount : Fintype.card G ≤ n+1) :
    (∑ i, A i) = Finset.univ := by
  have hh : ∀ B ∈ List.ofFn A, CosetSpanning B := by
    intro B hB
    obtain ⟨i, rfl⟩ := List.mem_ofFn.mp hB
    exact hA i
  simpa only [List.sum_ofFn, List.length_ofFn] using
    finiteGroup_list_sum_eq_univ (List.ofFn A) hh (by simpa using hcount)

omit [DecidableEq G] in
/-- Full generation survives a surjective quotient map and provides the
nonempty coset-spanning hypotheses needed by the finite filling step. -/
theorem cosetSpanning_image_of_zero_mem_closure {H : Type*} [AddCommGroup H] [DecidableEq H]
    (A : Finset G) (hzero : 0 ∈ A) (hgen : AddSubgroup.closure (A : Set G) = ⊤)
    (f : G →+ H) (hf : Function.Surjective f) : CosetSpanning (A.image f) := by
  refine ⟨⟨0, Finset.mem_image.mpr ⟨0, hzero, f.map_zero⟩⟩, ?_⟩
  intro K z hcoset
  apply subgroup_eq_top_of_generators_in_coset hzero hgen f hf K z
  intro a ha
  exact hcoset (f a) (Finset.mem_image.mpr ⟨a, ha, rfl⟩)

/-- The actual sum of the original sets covers every class of a finite quotient. -/
theorem finiteQuotient_sum_image_eq_univ {H : Type*} [AddCommGroup H] [DecidableEq H] [Fintype H]
    {n : ℕ} (A : Fin n → Finset G) (hzero : ∀ i, 0 ∈ A i)
    (hgen : ∀ i, AddSubgroup.closure (A i : Set G) = ⊤)
    (f : G →+ H) (hf : Function.Surjective f) (hcount : Fintype.card H ≤ n+1) :
    (∑ i, A i).image f = Finset.univ := by
  calc
    _ = ∑ i, (A i).image f := map_sum (Finset.imageAddMonoidHom f) _ _
    _ = Finset.univ := finiteGroup_sum_eq_univ _
      (fun i => cosetSpanning_image_of_zero_mem_closure (A i) (hzero i) (hgen i) f hf) hcount

end
end Optss
