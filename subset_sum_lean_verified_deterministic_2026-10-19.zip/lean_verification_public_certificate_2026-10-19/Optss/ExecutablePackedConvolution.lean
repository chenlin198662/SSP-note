import Optss.PackedDigits
import Mathlib.Data.List.GetD
import Mathlib.Algebra.Order.BigOperators.Group.List

/-!
# Executable packed convolution on coefficient lists

Both coefficient lists are encoded by an actual Horner loop. The base is
computed from their sums, so a proved bound prevents output carries. One natural
integer multiplication is followed by the sequential digit loop. The executable
path contains no polynomials or noncomputable operations; polynomials occur only
in the specification proof.

The explicit step count counts Horner steps and digit extraction steps, not bit
operations. In particular, the cost of multiplying the packed integers remains
separate, and no nearlinear runtime theorem is asserted here.
-/

namespace Optss.ExecutablePackedConvolution

open scoped BigOperators

/-- Least-significant coefficient first, using one multiply-add per list cell. -/
def pack (base : ℕ) : List ℕ → ℕ
  | [] => 0
  | a :: rest => a + base * pack base rest

/-- A mathematical polynomial model, never called by the executable algorithm. -/
noncomputable def model : List ℕ → Polynomial ℕ
  | [] => 0
  | a :: rest => Polynomial.C a + Polynomial.X * model rest

@[simp] theorem model_coeff (xs : List ℕ) (i : ℕ) :
    (model xs).coeff i = xs.getD i 0 := by
  induction xs generalizing i with
  | nil => simp [model]
  | cons a xs ih =>
      cases i with
      | zero => simp [model, Polynomial.coeff_X_mul_zero]
      | succ i => simp [model, Polynomial.coeff_X_mul, ih]

theorem model_eval (xs : List ℕ) (base : ℕ) : (model xs).eval base = pack base xs := by
  induction xs with
  | nil => simp [model, pack]
  | cons a xs ih => simp [model, pack, ih]

@[simp] theorem pack_one (xs : List ℕ) : pack 1 xs = xs.sum := by
  induction xs with
  | nil => rfl
  | cons a xs ih => simp [pack, ih]

/-- Every nonnegative polynomial coefficient is bounded by its total mass. -/
theorem coeff_le_eval_one (p : Polynomial ℕ) (i : ℕ) : p.coeff i ≤ p.eval 1 := by
  rw [Polynomial.eval_eq_sum, Polynomial.sum_def]
  simp only [one_pow, mul_one]
  by_cases hi : p.coeff i = 0
  · simp [hi]
  · exact Finset.single_le_sum (fun _ _ => Nat.zero_le _)
      (Polynomial.mem_support_iff.mpr hi)

/-- Computed base handles zeros and empty lists as well as positive inputs. -/
def carryBase (xs ys : List ℕ) : ℕ := (xs.sum + 1) * (ys.sum + 1)

theorem carryBase_pos (xs ys : List ℕ) : 0 < carryBase xs ys :=
  Nat.mul_pos (Nat.succ_pos _) (Nat.succ_pos _)

/-- The no-carry hypothesis is derived from the actual input lists. -/
theorem product_coeff_lt_base (xs ys : List ℕ) (i : ℕ) :
    (model xs * model ys).coeff i < carryBase xs ys := by
  have h := coeff_le_eval_one (model xs * model ys) i
  rw [Polynomial.eval_mul, model_eval, model_eval, pack_one, pack_one] at h
  unfold carryBase
  simp only [Nat.add_mul, Nat.mul_add, Nat.one_mul, Nat.mul_one]
  omega

/-- The ordinary zero-padded discrete convolution coefficient. -/
def coefficient (xs ys : List ℕ) (i : ℕ) : ℕ :=
  ∑ ab ∈ Finset.antidiagonal i, xs.getD ab.1 0 * ys.getD ab.2 0

@[simp] theorem model_product_coeff (xs ys : List ℕ) (i : ℕ) :
    (model xs * model ys).coeff i = coefficient xs ys i := by
  simp only [Polynomial.coeff_mul, model_coeff, coefficient]

/-- Conventional finite output size: zero for an empty input, otherwise m+n-1. -/
def outputLength {α β : Type*} : List α → List β → ℕ
  | [], _ => 0
  | _, [] => 0
  | _ :: xs, _ :: ys => xs.length + ys.length + 1

/-- Actual encode-multiply-sequential-decode convolution. Both input packings and
its single integer multiplication are evaluated before the digit loop. -/
def convolve (xs ys : List ℕ) : List ℕ :=
  let base := carryBase xs ys
  let left := pack base xs
  let right := pack base ys
  Optss.unpackDigits base (outputLength xs ys) (left * right)

@[simp] theorem convolve_length (xs ys : List ℕ) :
    (convolve xs ys).length = outputLength xs ys := by
  simp [convolve]

/-- Exact coefficients on every emitted cell, without an output-correctness or
carry certificate being supplied by the caller. -/
theorem convolve_getD_lt (xs ys : List ℕ) (i : ℕ) (hi : i < outputLength xs ys) :
    (convolve xs ys).getD i 0 = coefficient xs ys i := by
  rw [convolve, Optss.unpackDigits_getD _ _ _ i hi, ← model_eval, ← model_eval]
  rw [Optss.packed_convolution_of_coeff_lt (model xs) (model ys) (carryBase xs ys)
    (carryBase_pos xs ys) (product_coeff_lt_base xs ys) i]
  exact model_product_coeff xs ys i

/-- The conventional output range contains every possibly nonzero coefficient. -/
theorem coefficient_eq_zero_of_ge (xs ys : List ℕ) (i : ℕ)
    (hi : outputLength xs ys ≤ i) : coefficient xs ys i = 0 := by
  cases xs with
  | nil => simp [coefficient]
  | cons x xs =>
      cases ys with
      | nil => simp [coefficient]
      | cons y ys =>
          apply Finset.sum_eq_zero
          intro ab hab
          have habsum := Finset.mem_antidiagonal.mp hab
          dsimp only [outputLength] at hi
          by_cases hx : ab.1 < (x :: xs).length
          · have hy : (y :: ys).length ≤ ab.2 := by
              simp only [List.length_cons] at hx ⊢
              omega
            rw [List.getD_eq_default _ _ hy]
            simp
          · have hx' : (x :: xs).length ≤ ab.1 := by omega
            rw [List.getD_eq_default _ _ hx']
            simp

/-- Complete zero-padded equality, including indices beyond the emitted array. -/
theorem convolve_getD (xs ys : List ℕ) (i : ℕ) :
    (convolve xs ys).getD i 0 = coefficient xs ys i := by
  by_cases hi : i < outputLength xs ys
  · exact convolve_getD_lt xs ys i hi
  · rw [List.getD_eq_default _ _ (by simpa using (Nat.le_of_not_gt hi)),
      coefficient_eq_zero_of_ge xs ys i (Nat.le_of_not_gt hi)]

/-- The runtime result has exactly the usual polynomial-product coefficient
semantics, although no polynomial is constructed during execution. -/
theorem convolve_coeff (xs ys : List ℕ) (i : ℕ) :
    (convolve xs ys).getD i 0 = (model xs * model ys).coeff i := by
  rw [convolve_getD, model_product_coeff]

/-- Positive output support is exactly the sumset of the positive input support. -/
theorem convolve_support_iff (xs ys : List ℕ) (i : ℕ) :
    0 < (convolve xs ys).getD i 0 ↔
      ∃ a b, a + b = i ∧ 0 < xs.getD a 0 ∧ 0 < ys.getD b 0 := by
  rw [convolve_getD]
  constructor
  · intro hs
    by_contra hn
    push_neg at hn
    have hz : coefficient xs ys i = 0 := by
      apply Finset.sum_eq_zero
      intro ab hab
      have hnab := hn ab.1 ab.2 (Finset.mem_antidiagonal.mp hab)
      by_cases hleft : 0 < xs.getD ab.1 0
      · have hright : ys.getD ab.2 0 = 0 := by have := hnab hleft; omega
        exact mul_eq_zero.mpr (Or.inr hright)
      · have hzero : xs.getD ab.1 0 = 0 := by omega
        exact mul_eq_zero.mpr (Or.inl hzero)
    omega
  · rintro ⟨a, b, hab, ha, hb⟩
    exact Finset.sum_pos' (fun _ _ => Nat.zero_le _)
      ⟨(a, b), Finset.mem_antidiagonal.mpr hab, Nat.mul_pos ha hb⟩

/-- Each input digit is also strictly smaller than the computed packing base. -/
theorem input_lt_base (xs ys : List ℕ) :
    (∀ a ∈ xs, a < carryBase xs ys) ∧ (∀ b ∈ ys, b < carryBase xs ys) := by
  have hleft : xs.sum < carryBase xs ys := by
    simp only [carryBase, Nat.add_mul, Nat.mul_add, Nat.one_mul, Nat.mul_one]
    omega
  have hright : ys.sum < carryBase xs ys := by
    simp only [carryBase, Nat.add_mul, Nat.mul_add, Nat.one_mul, Nat.mul_one]
    omega
  constructor
  · intro a ha
    exact (List.single_le_sum (fun _ _ => Nat.zero_le _) a ha).trans_lt hleft
  · intro b hb
    exact (List.single_le_sum (fun _ _ => Nat.zero_le _) b hb).trans_lt hright

/-- Exact range of a finite Horner encoding, with leading zero digits allowed. -/
theorem pack_lt_pow (base : ℕ) (xs : List ℕ) (hbase : 0 < base)
    (hdigits : ∀ a ∈ xs, a < base) : pack base xs < base ^ xs.length := by
  induction xs with
  | nil => simp [pack]
  | cons a xs ih =>
      have ha := hdigits a List.mem_cons_self
      have htail := ih (fun b hb => hdigits b (List.mem_cons_of_mem _ hb))
      have hp := pow_pos hbase xs.length
      simp only [pack, List.length_cons, pow_succ]
      nlinarith

/-- Explicit input encoding bit lengths. These bounds do not price multiplication. -/
theorem pack_bits (base : ℕ) (xs : List ℕ) (hbase : 0 < base)
    (hdigits : ∀ a ∈ xs, a < base) : (pack base xs).size ≤ xs.length * base.size := by
  apply Nat.size_le.mpr
  calc
    pack base xs < base ^ xs.length := pack_lt_pow base xs hbase hdigits
    _ ≤ (2 ^ base.size) ^ xs.length :=
      Nat.pow_le_pow_left (Nat.lt_size_self base).le _
    _ = _ := by rw [← pow_mul, Nat.mul_comm]

theorem convolve_encoding_bounds (xs ys : List ℕ) :
    (pack (carryBase xs ys) xs).size ≤ xs.length * (carryBase xs ys).size ∧
      (pack (carryBase xs ys) ys).size ≤ ys.length * (carryBase xs ys).size :=
  ⟨pack_bits _ _ (carryBase_pos xs ys) (input_lt_base xs ys).1,
    pack_bits _ _ (carryBase_pos xs ys) (input_lt_base xs ys).2⟩

/-- Structural count of the multiply-add digit steps of the Horner encoder. -/
def packSteps : List ℕ → ℕ
  | [] => 0
  | _ :: xs => packSteps xs + 1

@[simp] theorem packSteps_eq (xs : List ℕ) : packSteps xs = xs.length := by
  induction xs with
  | nil => rfl
  | cons a xs ih => simp [packSteps, ih]

/-- This count excludes input scans, big-integer operation costs, and the one
packed multiplication. It counts the two packing passes and sequential unpack. -/
def digitSteps (xs ys : List ℕ) : ℕ :=
  packSteps xs + packSteps ys + Optss.unpackSteps (outputLength xs ys)

theorem digitSteps_eq (xs ys : List ℕ) :
    digitSteps xs ys = xs.length + ys.length + outputLength xs ys := by
  simp [digitSteps]

theorem digitSteps_le (xs ys : List ℕ) : digitSteps xs ys ≤ 2 * (xs.length + ys.length) := by
  rw [digitSteps_eq]
  cases xs <;> cases ys <;> simp [outputLength]
  all_goals omega

/-- Concrete arrays can use the same verified backend without a polynomial bridge
at runtime. List/array conversion is separate from the packed arithmetic. -/
def convolveArray (xs ys : Array ℕ) : Array ℕ := (convolve xs.toList ys.toList).toArray

@[simp] theorem convolveArray_size (xs ys : Array ℕ) :
    (convolveArray xs ys).size = outputLength xs.toList ys.toList := by
  simp [convolveArray]

theorem convolveArray_getD (xs ys : Array ℕ) (i : ℕ) :
    (convolveArray xs ys)[i]?.getD 0 = coefficient xs.toList ys.toList i := by
  simpa only [convolveArray, List.getElem?_toArray, ← List.getD_eq_getElem?_getD]
    using convolve_getD xs.toList ys.toList i

end Optss.ExecutablePackedConvolution
