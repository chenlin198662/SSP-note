import Optss.MatrixExpressionConstruction
import Optss.ListStoredRationalSize

/-!
# Construct, read, evaluate, and materialize rational matrix inverses

The complete routines below first execute the counted expression constructor
and then evaluate that returned expression against actual list-backed reads.
Their polynomials use the literal framed input bit count. Rank is fixed in
these polynomials, as required for the paper's polytope normalization; no
variable-rank polynomial-time claim is made for Laplace expansion.
-/
namespace Optss
open scoped BigOperators
variable {r : ℕ}

def constructedListMatrixDeterminant (A : ListBitRationalMatrixData r r) : BitListFraction :=
  let expression := buildMatrixDeterminantExpression r
  expression.1.encoded (listStoredMatrixInputs A)

def constructedListMatrixDeterminantWork (A : ListBitRationalMatrixData r r) : ℕ :=
  let expression := buildMatrixDeterminantExpression r
  expression.2+expression.1.work (listStoredMatrixInputs A)+
    expression.1.lookupWork (listStoredMatrixLookupWork A)

def constructedListMatrixInverse (A : ListBitRationalMatrixData r r) : ListBitRationalMatrixData r r :=
  BooleanListArray.ofFn fun i => BooleanListArray.ofFn fun j =>
    let expression := buildMatrixInverseExpression r i j
    expression.1.encoded (listStoredMatrixInputs A)

def constructedListMatrixInverseWork (A : ListBitRationalMatrixData r r) : ℕ :=
  listIndexEnumerationWork r+r*listIndexEnumerationWork r+2*r*r+2*r+1+
    ∑ i : Fin r,∑ j : Fin r,
      let expression := buildMatrixInverseExpression r i j
      expression.2+expression.1.work (listStoredMatrixInputs A)+
        expression.1.lookupWork (listStoredMatrixLookupWork A)

theorem constructedListMatrixDeterminant_eq (A : ListBitRationalMatrixData r r) :
    constructedListMatrixDeterminant A=listStoredMatrixDeterminant A := by
  simp only [constructedListMatrixDeterminant,buildMatrixDeterminantExpression_value,
    listStoredMatrixDeterminant]

theorem constructedListMatrixInverse_eq (A : ListBitRationalMatrixData r r) :
    constructedListMatrixInverse A=listStoredMatrixInverse A := by
  simp only [constructedListMatrixInverse,buildMatrixInverseExpression_value,listStoredMatrixInverse]

theorem constructedListMatrixDeterminantWork_eq (A : ListBitRationalMatrixData r r) :
    constructedListMatrixDeterminantWork A=(buildMatrixDeterminantExpression r).2+
      listStoredMatrixDeterminantWork A := by
  simp only [constructedListMatrixDeterminantWork,buildMatrixDeterminantExpression_value,
    listStoredMatrixDeterminantWork]
  omega

theorem constructedListMatrixInverseWork_eq (A : ListBitRationalMatrixData r r) :
    constructedListMatrixInverseWork A=
      (∑ i : Fin r,∑ j : Fin r,(buildMatrixInverseExpression r i j).2)+listStoredMatrixInverseWork A := by
  simp only [constructedListMatrixInverseWork,buildMatrixInverseExpression_value,
    listStoredMatrixInverseWork,Finset.sum_add_distrib]
  omega

def matrixInverseBuildBound (r : ℕ) : ℕ :=
  RationalExpression.determinantBuildBound r (cofactorInputBuildBound r)+
    RationalExpression.determinantBuildBound r (4*(r+1)+1)+1

theorem constructedListMatrixInverseWork_bound (A : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(listFractionMatrix A i j).WellFormed) (L : ℕ)
    (hbits : ∀ i j,(listFractionMatrix A i j).numerator.length≤L ∧
      (listFractionMatrix A i j).denominator.length≤L) :
    constructedListMatrixInverseWork A≤r*r*matrixInverseBuildBound r+
      (64*(r+1)^4+2*r*r+2*r+1+
       r*r*(2*RationalExpression.determinantNodes r 1+1)*
        (RationalExpression.charge (2*RationalExpression.determinantNodes r 1+1) L+
          listStorageFactor r r*(2*L+1))) := by
  rw [constructedListMatrixInverseWork_eq]
  apply Nat.add_le_add _ (listStoredMatrixInverseWork_bound A hA L hbits)
  calc
    _ ≤ ∑ _i : Fin r,∑ _j : Fin r,matrixInverseBuildBound r := by
      apply Finset.sum_le_sum
      intro i _
      apply Finset.sum_le_sum
      intro j _
      exact buildMatrixInverseExpression_work_le r i j
    _ = _ := by simp; ring

noncomputable def constructedDeterminantPolynomial (r : ℕ) : Polynomial ℕ :=
  Polynomial.C (RationalExpression.determinantBuildBound r (4*(r+1)+1))+
    matrixScalarWorkPolynomial 1 (RationalExpression.determinantNodes r 1)+
    Polynomial.C (RationalExpression.determinantNodes r 1*listStorageFactor r r)*
      (2*Polynomial.X+1)

noncomputable def constructedInversePolynomial (r : ℕ) : Polynomial ℕ :=
  Polynomial.C (r*r*matrixInverseBuildBound r+64*(r+1)^4+2*r*r+2*r+1)+
    matrixScalarWorkPolynomial (r*r) (2*RationalExpression.determinantNodes r 1+1)+
    Polynomial.C (r*r*(2*RationalExpression.determinantNodes r 1+1)*listStorageFactor r r)*
      (2*Polynomial.X+1)

/-- Full determinant source work is polynomial in the actual framed input. -/
theorem constructedListMatrixDeterminantWork_input_polynomial
    (A : ListBitRationalMatrixData r r) (hA : ∀ i j,(listFractionMatrix A i j).WellFormed) :
    constructedListMatrixDeterminantWork A≤(constructedDeterminantPolynomial r).eval (listStoredRationalBits A) := by
  let L := listStoredRationalBits A
  have hbits : ∀ i j,(listFractionMatrix A i j).numerator.length≤L ∧
      (listFractionMatrix A i j).denominator.length≤L := listStoredRationalBits_cell A
  have hs := listStoredMatrixDeterminantWork_bound A hA L hbits
  have hb := buildMatrixDeterminantExpression_work_le r
  have hp := expression_charge_le_polynomial 1 (RationalExpression.determinantNodes r 1) L
  simp only [one_mul] at hp
  rw [constructedListMatrixDeterminantWork_eq]
  simp only [constructedDeterminantPolynomial,Polynomial.eval_add,Polynomial.eval_C,
    Polynomial.eval_mul,Polynomial.eval_ofNat,Polynomial.eval_X,Polynomial.eval_one]
  change _≤_+(matrixScalarWorkPolynomial 1 (RationalExpression.determinantNodes r 1)).eval L+_
  calc
    _ ≤ RationalExpression.determinantBuildBound r (4*(r+1)+1)+
        RationalExpression.determinantNodes r 1*
          (RationalExpression.charge (RationalExpression.determinantNodes r 1) L+
            listStorageFactor r r*(2*L+1)) := Nat.add_le_add hb hs
    _ ≤ _ := by nlinarith

/-- Full inverse source work, including construction, list reads and output
allocation, is polynomial in the actual framed input for each fixed rank. -/
theorem constructedListMatrixInverseWork_input_polynomial
    (A : ListBitRationalMatrixData r r) (hA : ∀ i j,(listFractionMatrix A i j).WellFormed) :
    constructedListMatrixInverseWork A≤(constructedInversePolynomial r).eval (listStoredRationalBits A) := by
  let L := listStoredRationalBits A
  have hbits : ∀ i j,(listFractionMatrix A i j).numerator.length≤L ∧
      (listFractionMatrix A i j).denominator.length≤L := listStoredRationalBits_cell A
  have hs := constructedListMatrixInverseWork_bound A hA L hbits
  have hp := expression_charge_le_polynomial (r*r) (2*RationalExpression.determinantNodes r 1+1) L
  simp only [constructedInversePolynomial,Polynomial.eval_add,Polynomial.eval_C,
    Polynomial.eval_mul,Polynomial.eval_ofNat,Polynomial.eval_X,Polynomial.eval_one]
  change _≤_+(matrixScalarWorkPolynomial (r*r) (2*RationalExpression.determinantNodes r 1+1)).eval L+_
  exact hs.trans (by nlinarith)

/-- The actual returned inverse has both matrix inverse equations, whenever
the actual input determinant is nonzero. -/
theorem constructedListMatrixInverse_spec (A : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(listFractionMatrix A i j).WellFormed)
    (hdet : ((listFractionMatrix A).map bitListFractionValue).det≠0) :
    let B := (listFractionMatrix (constructedListMatrixInverse A)).map bitListFractionValue
    B*((listFractionMatrix A).map bitListFractionValue)=1 ∧
      ((listFractionMatrix A).map bitListFractionValue)*B=1 ∧
      ∀ i j,(listFractionMatrix (constructedListMatrixInverse A) i j).WellFormed := by
  dsimp only
  have he : (listFractionMatrix (constructedListMatrixInverse A)).map bitListFractionValue =
      rationalCofactorInverse ((listFractionMatrix A).map bitListFractionValue) := by
    ext i j
    simp only [listFractionMatrix,constructedListMatrixInverse_eq,listStoredMatrixInverse_eq,Matrix.map_apply]
    exact booleanMatrixInverse_value (listFractionMatrix A) hA i j
  rw [he]
  have hi := rationalCofactorInverse_mul ((listFractionMatrix A).map bitListFractionValue) hdet
  refine ⟨hi.1,hi.2,?_⟩
  intro i j
  simp only [listFractionMatrix,constructedListMatrixInverse_eq,listStoredMatrixInverse_eq]
  exact booleanMatrixInverse_wellFormed (listFractionMatrix A) hA i j
end Optss
