import Optss.DenseRectangularProgressions

/-!
# Completing the actual sublattice box with a disjoint residue reserve

The residue set is the sum of the specified reserve labels, each of
which contains zero and generates the full integer lattice. Thus both
the progression stage and the residue stage are proved from actual input
sets, and their disjointness prevents any label from being reused.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

/-- Finite-label form of exact residue saturation. -/
theorem filling_residues_of_finite_generators {d : ℕ} {ι : Type*} [DecidableEq ι]
    (T : Finset ι) (A : ι → Finset (IntVec d)) (v : Fin d → ℕ)
    (hv : ∀ j, 0 < v j) (hzero : ∀ i ∈ T, 0 ∈ A i)
    (hgen : ∀ i ∈ T, AddSubgroup.closure (A i : Set (IntVec d)) = ⊤)
    (hcount : (∏ j, v j) ≤ T.card + 1) (x : IntVec d) :
    ∃ r ∈ ∑ i ∈ T, A i, ∀ j, (v j : ℤ) ∣ x j - r j := by
  letI : ∀ j, NeZero (v j) := fun j => ⟨ne_of_gt (hv j)⟩
  let f := fillingResidueHom v
  have hcard : Fintype.card (∀ j, ZMod (v j)) ≤ (T.toList.map (fun i => (A i).image f)).length + 1 := by
    simpa only [Fintype.card_pi, ZMod.card, List.length_map, Finset.length_toList] using hcount
  have hfull := finiteGroup_list_sum_eq_univ (T.toList.map (fun i => (A i).image f))
    (by
      intro B hB
      obtain ⟨i, hi, rfl⟩ := List.mem_map.mp hB
      have hiT : i ∈ T := by simpa using hi
      exact cosetSpanning_image_of_zero_mem_closure (A i) (hzero i hiT) (hgen i hiT)
        f (fillingResidueHom_surjective v)) hcard
  have he : (∑ i ∈ T, A i).image f = Finset.univ := by
    rw [show (∑ i ∈ T, A i).image f = ∑ i ∈ T, (A i).image f from
      map_sum (Finset.imageAddMonoidHom f) _ _, ← Finset.sum_map_toList]
    exact hfull
  have hx : f x ∈ (∑ i ∈ T, A i).image f := by rw [he]; simp
  obtain ⟨r, hr, her⟩ := Finset.mem_image.mp hx
  refine ⟨r, hr, fun j => ?_⟩
  exact (ZMod.intCast_eq_intCast_iff_dvd_sub (r j) (x j) (v j)).mp (congrFun her j)

/-- Exact coordinate bound on the sum of finitely many bounded sets. -/
theorem filling_finite_sum_coordinate_bound {d : ℕ} {ι : Type*} [DecidableEq ι]
    (T : Finset ι) (A : ι → Finset (IntVec d)) (W : IntVec d)
    (hA : ∀ i ∈ T, ∀ x ∈ A i, ∀ j, |x j| ≤ W j) :
    ∀ r ∈ ∑ i ∈ T, A i, ∀ j, |r j| ≤ (T.card : ℤ) * W j := by
  induction T using Finset.induction_on with
  | empty => simp
  | @insert i T hi ih =>
    have hr := ih (fun k hk => hA k (Finset.mem_insert_of_mem hk))
    rw [Finset.sum_insert hi, Finset.card_insert_of_not_mem hi]
    intro x hx j
    obtain ⟨a, ha, b, hb, rfl⟩ := Finset.mem_add.mp hx
    have h₁ := hA i (Finset.mem_insert_self _ _) a ha j
    have h₂ := hr b hb j
    have h₃ := abs_add_le (a j) (b j)
    change |a j + b j| ≤ _
    push_cast
    nlinarith

/-- The complete geometric filling construction with specified disjoint
axis batches and a reserve large enough for all bounded periods. -/
theorem dense_box_with_reserve {d : ℕ} {ι : Type*} [DecidableEq ι]
    (S : Fin d → Finset ι) (T : Finset ι) (A : ι → Finset (IntVec d))
    (lo : IntVec d) (W : Fin d → ℕ) (c : ℝ) (K : ℕ)
    (hc : 0 < c) (hc1 : c ≤ 1) (hK : 2 ≤ c * K)
    (hW : ∀ j, 0 < W j) (hN : ∀ j, 4 ≤ c * W j)
    (hcenter : ∀ j, lo j ≤ 0 ∧ 0 ≤ lo j + W j - 1)
    (hcount : ∀ j, 20 ≤ c ^ 2 * (S j).card)
    (hreserve : K ^ d ≤ T.card + 1)
    (hdis : ((Finset.univ : Finset (Fin d)) : Set (Fin d)).PairwiseDisjoint S)
    (hRT : Disjoint (Finset.univ.biUnion S) T)
    (hbox : ∀ i ∈ (Finset.univ.biUnion S) ∪ T,
      A i ⊆ fillingIntegerBox lo (fun j => lo j + W j - 1))
    (hdense : ∀ j, ∀ i ∈ S j,
      c * (fillingIntegerBox lo (fun k => lo k + W k - 1)).card ≤ (A i).card)
    (hzero : ∀ i ∈ T, 0 ∈ A i)
    (hgen : ∀ i ∈ T, AddSubgroup.closure (A i : Set (IntVec d)) = ⊤) :
    ∃ a b t : IntVec d,
      (fillingIntegerBox a b).image (t + ·) ⊆
        ∑ i ∈ (Finset.univ.biUnion S) ∪ T, A i ∧
      ∀ j, (c ^ 2 * (S j).card / 4 - 2 * T.card) * W j ≤ (b j - a j : ℤ) := by
  obtain ⟨v, a, b, t, hv, hP⟩ := dense_rectangular_progression S A lo W c hc hc1 hW hN hcount hdis
    (fun j i hi => hbox i (Finset.mem_union_left _ (Finset.mem_biUnion.mpr ⟨j, Finset.mem_univ _, hi⟩))) hdense
  let vn : Fin d → ℕ := fun j => (v j).toNat
  have hvn : ∀ j, (vn j : ℤ) = v j := fun j => Int.toNat_of_nonneg (hv j).1.le
  have hvnpos : ∀ j, 0 < vn j := by intro j; have := (hv j).1; rw [← hvn j] at this; exact_mod_cast this
  have hvK : ∀ j, vn j ≤ K := by
    intro j
    have hvj := (hv j).2.1
    have hvR : ((vn j : ℕ) : ℝ) = (v j : ℝ) := by exact_mod_cast hvn j
    rw [← hvR] at hvj
    have hh : (vn j : ℝ) ≤ K := (mul_le_mul_left hc).mp (hvj.trans hK)
    exact_mod_cast hh
  have hprod : (∏ j, vn j) ≤ T.card + 1 := by
    calc
      (∏ j, vn j) ≤ ∏ _j : Fin d, K := Finset.prod_le_prod (fun _ _ => Nat.zero_le _) (fun j _ => hvK j)
      _ = K ^ d := by simp
      _ ≤ _ := hreserve
  have hbound : ∀ i ∈ T, ∀ x ∈ A i, ∀ j, |x j| ≤ (W j : ℤ) := by
    intro i hi x hx j
    have hh := (mem_fillingIntegerBox _ _ _).mp (hbox i (Finset.mem_union_right _ hi) hx) j
    have hz := hcenter j
    rw [abs_le]
    constructor <;> omega
  have hres := filling_residues_of_finite_generators T A vn hvnpos hzero hgen hprod
  have hfill := filling_translated_box_subset_sum v a b (fun j => T.card * (W j : ℤ)) t
    (fun j => (hv j).1) (∑ i ∈ Finset.univ.biUnion S, A i) (∑ i ∈ T, A i) hP
    (filling_finite_sum_coordinate_bound T A (fun j => (W j : ℤ)) hbound)
    (fun x => by obtain ⟨r, hr, hd⟩ := hres x; exact ⟨r, hr, by simpa only [hvn] using hd⟩)
  refine ⟨(fun j => v j * a j + T.card * (W j : ℤ)),
    (fun j => v j * b j - T.card * (W j : ℤ)), t, ?_, ?_⟩
  · rwa [← Finset.sum_union hRT] at hfill
  · intro j
    have hlen := (hv j).2.2
    have hv1 : (1 : ℝ) ≤ v j := by exact_mod_cast (show 1 ≤ v j by have := (hv j).1; omega)
    have hnonneg : (0 : ℝ) ≤ ((b j - a j : ℤ) : ℝ) := le_trans (by positivity) hlen
    have hmul := mul_le_mul_of_nonneg_right hv1 hnonneg
    push_cast at hlen hmul ⊢
    nlinarith

end
end Optss
