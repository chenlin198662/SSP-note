import Optss.BooleanVertexGather

/-!
# Boolean maximum-determinant vertex selection

Every tuple is a list of Boolean addresses, every candidate matrix is gathered
through the list reader, and every determinant score is evaluated once. The
maximum scan uses the Boolean fraction comparison and explicitly copies its
selected tuple and score. Rational decoding appears only in specifications.
-/
namespace Optss
open scoped BigOperators
variable {r m : ℕ}

abbrev BitScoredVertex (r : ℕ) := BitVertexTuple r × BitListFraction

def copyScoredVertex (p : BitScoredVertex r) : BitScoredVertex r :=
  (p.1.copy bitWordCopy,listCopyFraction p.2)

def copyScoredVertexWork (p : BitScoredVertex r) : ℕ :=
  p.1.copyWork bitWordCopyWork+listCopyFractionWork p.2+1

theorem copyScoredVertex_eq (p : BitScoredVertex r) : copyScoredVertex p=p := by
  simp [copyScoredVertex,BooleanListArray.copy_eq bitWordCopy bitWordCopy_eq,listCopyFraction_eq]

def bitMaximumScored : List (BitScoredVertex r) → Option (BitScoredVertex r)
  | [] => none
  | p::ps => match bitMaximumScored ps with
    | none => some (copyScoredVertex p)
    | some q => some (copyScoredVertex (if bitListFractionLE p.2 q.2 then q else p))

def bitMaximumScoredWork : List (BitScoredVertex r) → ℕ
  | [] => 1
  | p::ps => bitMaximumScoredWork ps+match bitMaximumScored ps with
    | none => copyScoredVertexWork p+3
    | some q => bitListFractionLECost p.2 q.2+
        copyScoredVertexWork (if bitListFractionLE p.2 q.2 then q else p)+4

theorem bitMaximumScored_none (ps : List (BitScoredVertex r)) :
    bitMaximumScored ps=none ↔ ps=[] := by
  cases ps with
  | nil => simp [bitMaximumScored]
  | cons p ps => simp only [bitMaximumScored]; split <;> simp

theorem bitMaximumScored_mem (ps : List (BitScoredVertex r)) (p : BitScoredVertex r)
    (hp : bitMaximumScored ps=some p) : p∈ps := by
  induction ps generalizing p with
  | nil => simp [bitMaximumScored] at hp
  | cons a ps ih =>
    rw [bitMaximumScored] at hp
    cases he : bitMaximumScored ps with
    | none =>
      simp only [he,copyScoredVertex_eq,Option.some.injEq] at hp
      subst p
      exact List.mem_cons_self
    | some b =>
      simp only [he,copyScoredVertex_eq] at hp
      split_ifs at hp with h
      · have hp' := Option.some.inj hp
        subst p
        exact List.mem_cons_of_mem _ (ih b he)
      · have hp' := Option.some.inj hp
        subst p
        exact List.mem_cons_self

def decodeScoredVertex (p : BitScoredVertex r) : BitVertexTuple r × ℚ :=
  (p.1,bitListFractionValue p.2)

theorem bitMaximumScored_value (ps : List (BitScoredVertex r))
    (hwf : ∀ p∈ps,p.2.WellFormed) :
    (bitMaximumScored ps).map decodeScoredVertex=maximumScored (ps.map decodeScoredVertex) := by
  induction ps with
  | nil => rfl
  | cons p ps ih =>
    have hp := hwf p List.mem_cons_self
    have ht : ∀ q∈ps,q.2.WellFormed := fun q hq => hwf q (List.mem_cons_of_mem _ hq)
    have ih' := ih ht
    simp only [List.map_cons,maximumScored,bitMaximumScored]
    cases he : bitMaximumScored ps with
    | none => simp only [he,Option.map_none] at ih'; simp [he,←ih',copyScoredVertex_eq]
    | some q =>
      have hq := ht q (bitMaximumScored_mem ps q he)
      simp only [he,Option.map_some] at ih'
      rw [←ih']
      dsimp only
      simp only [copyScoredVertex_eq]
      have hc := bitListFractionLE_correct p.2 q.2 hp.2.2.1 hq.2.2.1
      by_cases h : bitListFractionLE p.2 q.2=true
      · have hv := hc.mp h
        simp [h,decodeScoredVertex,hv]
      · have hv : ¬ bitListFractionValue p.2≤bitListFractionValue q.2 := fun hh => h (hc.mpr hh)
        simp [h,decodeScoredVertex,hv]

def bitVertexScore (V : ListBitRationalMatrixData r m) (t : BitVertexTuple r) : BitListFraction :=
  bitFractionAbs (constructedListMatrixDeterminant (bitVertexGather V t))

def bitVertexScoreWork (V : ListBitRationalMatrixData r m) (t : BitVertexTuple r) : ℕ :=
  let A := bitVertexGather V t
  let score := constructedListMatrixDeterminant A
  bitVertexGatherWork V t+constructedListMatrixDeterminantWork A+bitFractionAbsWork score+3

def bitScoredVertexTuples (V : ListBitRationalMatrixData r m) : List (BitScoredVertex r) :=
  (bitVertexTuples m r).map fun t => (t.copy bitWordCopy,bitVertexScore V t)

def bitScoredVertexTuplesWork (V : ListBitRationalMatrixData r m) : ℕ :=
  bitVertexTuplesWork m r+((bitVertexTuples m r).map fun t =>
    t.copyWork bitWordCopyWork+bitVertexScoreWork V t+3).sum+1

def bitSelectVertexTuple (V : ListBitRationalMatrixData r m) : Option (BitVertexTuple r) :=
  (bitMaximumScored (bitScoredVertexTuples V)).map Prod.fst

def bitSelectVertexTupleWork (V : ListBitRationalMatrixData r m) : ℕ :=
  bitScoredVertexTuplesWork V+bitMaximumScoredWork (bitScoredVertexTuples V)+2

theorem bitVertexScore_wellFormed (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    {t : BitVertexTuple r} (ht : t∈bitVertexTuples m r) : (bitVertexScore V t).WellFormed := by
  apply bitFractionAbs_wellFormed
  rw [constructedListMatrixDeterminant_eq,listStoredMatrixDeterminant_eq]
  exact booleanMatrixDeterminant_wellFormed _ (bitVertexGather_wellFormed V hV ht)

theorem bitVertexScore_value (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (t : Fin r → Fin m) :
    bitListFractionValue (bitVertexScore V (encodeVertexTuple t))=
      |(rationalVertexMatrix (storedRationalVertices V) t).det| := by
  have ht : encodeVertexTuple t∈bitVertexTuples m r := by
    rw [bitVertexTuples_eq]
    exact List.mem_map.mpr ⟨t,mem_vertexIndexTuples t,rfl⟩
  rw [bitVertexScore,bitFractionAbs_value,constructedListMatrixDeterminant_eq,
    listStoredMatrixDeterminant_eq]
  rw [booleanMatrixDeterminant_value (listFractionMatrix _) (bitVertexGather_wellFormed V hV ht)]
  congr 1
  change Matrix.det ((rectangularListFractionMatrix (bitVertexGather V (encodeVertexTuple t))).map bitListFractionValue)=_
  rw [bitVertexGather_encode]

theorem maximumScored_map {α β : Type*} (f : α → β) (ps : List (α × ℚ)) :
    maximumScored (ps.map fun p => (f p.1,p.2))=
      (maximumScored ps).map (fun p => (f p.1,p.2)) := by
  induction ps with
  | nil => rfl
  | cons p ps ih =>
    simp only [List.map_cons,maximumScored,ih]
    cases h : maximumScored ps with
    | none => rfl
    | some q => by_cases hle : p.2≤q.2 <;> simp [hle]

theorem bitScoredVertexTuples_value (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) :
    (bitScoredVertexTuples V).map decodeScoredVertex=
      (scoredVertexTuples (storedRationalVertices V)).map (fun p => (encodeVertexTuple p.1,p.2)) := by
  simp only [bitScoredVertexTuples,bitVertexTuples_eq,List.map_map,scoredVertexTuples,
    Function.comp_def,BooleanListArray.copy_eq bitWordCopy bitWordCopy_eq,decodeScoredVertex]
  apply List.map_congr_left
  intro t _
  rw [bitVertexScore_value V hV]

theorem bitSelectVertexTuple_eq (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) :
    bitSelectVertexTuple V=(selectVertexTuple (storedRationalVertices V)).map encodeVertexTuple := by
  have hwf : ∀ p∈bitScoredVertexTuples V,p.2.WellFormed := by
    intro p hp
    obtain ⟨t,ht,rfl⟩ := List.mem_map.mp hp
    exact bitVertexScore_wellFormed V hV ht
  have h := bitMaximumScored_value (bitScoredVertexTuples V) hwf
  rw [bitScoredVertexTuples_value V hV,maximumScored_map] at h
  have h' := congrArg (Option.map Prod.fst) h
  simpa only [Option.map_map,Function.comp_def,decodeScoredVertex,bitSelectVertexTuple,
    selectVertexTuple] using h'
end Optss
