import Mathlib

/-! Materialized radix-two transforms and exact algebraic correctness.
The arrays for the two recursive transforms are constructed once per node.
Scalar butterfly counts are separated from twiddle preparation and storage. -/
namespace Optss
open scoped BigOperators

def radixEvenIndex (n : ℕ) (i : Fin (2^n)) : Fin (2^(n+1)) :=
  ⟨2*i.val,by rw [pow_succ]; have h := i.isLt; omega⟩
def radixOddIndex (n : ℕ) (i : Fin (2^n)) : Fin (2^(n+1)) :=
  ⟨2*i.val+1,by rw [pow_succ]; have h := i.isLt; omega⟩
def radixModIndex (n : ℕ) (i : Fin (2^(n+1))) : Fin (2^n) :=
  ⟨i.val%(2^n),Nat.mod_lt _ (by positivity)⟩

theorem vector_get_ofFn {R : Type*} {m : ℕ} (f : Fin m → R) (i : Fin m) :
    (Vector.ofFn f).get i=f i := by
  change (Vector.ofFn f)[i.val]=f i
  simp

def radixEvenData {R : Type*} (n : ℕ) (A : Vector R (2^(n+1))) : Vector R (2^n) :=
  Vector.ofFn fun i => A.get (radixEvenIndex n i)
def radixOddData {R : Type*} (n : ℕ) (A : Vector R (2^(n+1))) : Vector R (2^n) :=
  Vector.ofFn fun i => A.get (radixOddIndex n i)

def radixTwoTransform {R : Type*} [Add R] [Mul R]
    (T : ℕ → ℕ → R) : (n : ℕ) → Vector R (2^n) → Vector R (2^n)
  | 0,A => A
  | n+1,A =>
    let E := radixTwoTransform T n (radixEvenData n A)
    let O := radixTwoTransform T n (radixOddData n A)
    Vector.ofFn fun k => E.get (radixModIndex n k)+T n k.val*O.get (radixModIndex n k)

def radixTwoFFT {R : Type*} [CommRing R] :
    (n : ℕ) → R → Vector R (2^n) → Vector R (2^n)
  | 0,_,A => A
  | n+1,w,A =>
    let E := radixTwoFFT n (w^2) (radixEvenData n A)
    let O := radixTwoFFT n (w^2) (radixOddData n A)
    Vector.ofFn fun k => E.get (radixModIndex n k)+w^k.val*O.get (radixModIndex n k)

def radixDft {R : Type*} [CommRing R] (n : ℕ) (w : R) (A : Vector R (2^n)) (k : ℕ) : R :=
  ∑ j, A.get j*w^(j.val*k)

theorem sum_radix_split {R : Type*} [AddCommMonoid R] (n : ℕ) (f : Fin (2^(n+1)) → R) :
    (∑ j, f j)=∑ i, (f (radixEvenIndex n i)+f (radixOddIndex n i)) := by
  let e : Fin (2^n)×Fin 2 ≃ Fin (2^(n+1)) :=
    finProdFinEquiv.trans (finCongr (pow_succ 2 n).symm)
  have he := Fintype.sum_equiv e (fun p => f (e p)) f (fun _ => rfl)
  rw [← he,Fintype.sum_prod_type]
  apply Finset.sum_congr rfl
  intro i _
  rw [Fin.sum_univ_two]
  have hzero : e (i,0)=radixEvenIndex n i := by
    apply Fin.ext
    dsimp [e,finProdFinEquiv,radixEvenIndex]
    omega
  have hone : e (i,1)=radixOddIndex n i := by
    apply Fin.ext
    dsimp [e,finProdFinEquiv,radixOddIndex]
    omega
  rw [hzero,hone]

theorem radixDft_split {R : Type*} [CommRing R] (n : ℕ) (w : R)
    (A : Vector R (2^(n+1))) (k : ℕ) :
    radixDft (n+1) w A k=
      radixDft n (w^2) (radixEvenData n A) k+w^k*radixDft n (w^2) (radixOddData n A) k := by
  unfold radixDft
  rw [sum_radix_split,Finset.mul_sum,← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  simp only [radixEvenData,radixOddData,vector_get_ofFn,radixEvenIndex,radixOddIndex]
  have he : (2*i.val)*k=2*(i.val*k) := by ring
  have ho : (2*i.val+1)*k=2*(i.val*k)+k := by ring
  rw [he,ho,pow_add w (2*(i.val*k)) k,pow_mul w 2 (i.val*k)]
  ring

theorem power_mod_of_period {R : Type*} [Monoid R] (w : R) (m k : ℕ) (hw : w^m=1) :
    w^(k%m)=w^k := by
  conv_rhs => rw [← Nat.mod_add_div k m,pow_add,pow_mul,hw,one_pow,mul_one]

theorem radixDft_mod {R : Type*} [CommRing R] (n : ℕ) (w : R)
    (A : Vector R (2^n)) (k : ℕ) (hw : w^(2^n)=1) :
    radixDft n w A (k%(2^n))=radixDft n w A k := by
  apply Finset.sum_congr rfl
  intro j _
  congr 1
  rw [Nat.mul_comm j.val (k%(2^n)),pow_mul,power_mod_of_period w _ k hw,
    ← pow_mul,Nat.mul_comm k j.val]

/-- The materialized recursive transform equals the defining DFT sum at
every output index. The root need not be primitive. -/
theorem radixTwoFFT_correct {R : Type*} [CommRing R] (n : ℕ) (w : R)
    (A : Vector R (2^n)) (hw : w^(2^n)=1) (k : Fin (2^n)) :
    (radixTwoFFT n w A).get k=radixDft n w A k.val := by
  induction n generalizing w with
  | zero =>
    have hk : k=0 := by
      apply Fin.ext
      have h := k.isLt
      norm_num at h
      omega
    subst k
    simp [radixTwoFFT,radixDft]
  | succ n ih =>
    have hw' : (w^2)^(2^n)=1 := by
      rw [← pow_mul,show 2*(2^n)=2^(n+1) by rw [pow_succ]; omega]
      exact hw
    simp only [radixTwoFFT,vector_get_ofFn]
    rw [ih _ _ hw',ih _ _ hw']
    change radixDft n (w^2) (radixEvenData n A) (k.val%(2^n))+
      w^k.val*radixDft n (w^2) (radixOddData n A) (k.val%(2^n))=_
    rw [radixDft_mod _ _ _ _ hw',radixDft_mod _ _ _ _ hw',radixDft_split]

/-- A prepared table of twiddle factors gives precisely the power-based FFT.
Only table levels strictly below the transform depth are read. -/
theorem radixTwoTransform_exact {R : Type*} [CommRing R]
    (T : ℕ → ℕ → R) (n : ℕ) (w : R) (A : Vector R (2^n))
    (hT : ∀ l<n, ∀ k, T l k=w^(2^(n-(l+1))*k)) :
    radixTwoTransform T n A=radixTwoFFT n w A := by
  induction n generalizing w with
  | zero => rfl
  | succ n ih =>
    have hchild : ∀ l<n, ∀ k, T l k=(w^2)^(2^(n-(l+1))*k) := by
      intro l hl k
      rw [hT l (by omega) k,← pow_mul]
      congr 1
      have he : n+1-(l+1)=(n-(l+1))+1 := by omega
      rw [he,pow_succ]
      ring
    have htop (k : ℕ) : T n k=w^k := by
      simpa only [Nat.sub_self,pow_zero,one_mul] using hT n (by omega) k
    simp only [radixTwoTransform,radixTwoFFT]
    rw [ih _ _ hchild,ih _ _ hchild]
    apply Vector.ext
    intro i hi
    change (Vector.ofFn _).get ⟨i,hi⟩=(Vector.ofFn _).get ⟨i,hi⟩
    simp only [vector_get_ofFn,htop]

theorem radixTwoTransform_correct {R : Type*} [CommRing R]
    (T : ℕ → ℕ → R) (n : ℕ) (w : R) (A : Vector R (2^n))
    (hT : ∀ l<n, ∀ k, T l k=w^(2^(n-(l+1))*k)) (hw : w^(2^n)=1)
    (k : Fin (2^n)) :
    (radixTwoTransform T n A).get k=radixDft n w A k.val := by
  rw [radixTwoTransform_exact T n w A hT]
  exact radixTwoFFT_correct n w A hw k

/-- Number of output butterflies in the actual recursive shape. A butterfly
here means one output addition and one output multiplication. -/
def radixTwoButterflyCount : ℕ → ℕ
  | 0 => 0
  | n+1 => 2*radixTwoButterflyCount n+2^(n+1)

theorem radixTwoButterflyCount_eq (n : ℕ) : radixTwoButterflyCount n=n*2^n := by
  induction n with
  | zero => simp [radixTwoButterflyCount]
  | succ n ih => rw [radixTwoButterflyCount,ih,pow_succ]; ring

end Optss
