import Optss.ListBluesteinBounds

/-! Source work for the actual sequential Bluestein path: all character
arithmetic, three cached-list FFTs, pointwise products, and local list
construction/traversal. Immutable digit payloads are shared between lists;
this is not a pointer-address or garbage-collector simulation. -/
namespace Optss
set_option maxRecDepth 4096
set_option maxHeartbeats 800000

def listBluesteinTransformWork (depth : List Bool) (p : ℕ) (input : List Bool) : ℕ :=
  let chirps := listBluesteinChirps input p
  let neg := chirps.map Prod.fst
  let pos := chirps.map Prod.snd
  let fuel := radixListFuel depth
  let A := fourierListPad bitFourierZero fuel
    (List.zipWith (fun b z => if b then z else bitFourierZero) input neg)
  let B := fourierListPad bitFourierZero fuel (pos.reverse++pos.tail)
  let C := listCyclicConvolution depth p A B
  listBluesteinChirpsWork input p+listCyclicConvolutionWork depth p A B+
    (List.zipWith bitFourierMulWork neg (fourierListDrop input.tail C)).sum+
    radixListFuelWork depth+32*input.length+16*fuel.length+32

def listBluesteinWorkBound (N n p : ℕ) : ℕ :=
  5+N*(864*(N.size+2)^2+
    2*(4194304*((2*N).size+p+72)^2*(characterWorkBits (2*N) (p+2)+1)^3))+
  (3*listDyadicWorkPolynomial n p (2*(n*(p+6)+(p+4)+2)+1)+
    512*2^n*(n*(p+6)+(p+4)+3)^2+6*2^n+8)+
  512*N*(3*n*(p+6)+2*(p+4)+8)^2+
  (2*2^n+2*n)+32*N+16*2^n+32

theorem listBluesteinTransformWork_bound (depth : List Bool) (p : ℕ) (input : List Bool)
    (hinput : input≠[]) :
    listBluesteinTransformWork depth p input≤listBluesteinWorkBound input.length depth.length p := by
  obtain ⟨hn,hla,hlb,hneg,ha,hb⟩ := listBluestein_prepared_bounds depth p input hinput
  let neg := (listBluesteinChirps input p).map Prod.fst
  let pos := (listBluesteinChirps input p).map Prod.snd
  let A := fourierListPad bitFourierZero (radixListFuel depth)
      (List.zipWith (fun b z => if b then z else bitFourierZero) input neg)
  let B := fourierListPad bitFourierZero (radixListFuel depth) (pos.reverse++pos.tail)
  let C := listCyclicConvolution depth p A B
  let L := 3*depth.length*(p+6)+2*(p+4)+7
  have hc := listCyclicConvolution_list_bounds depth p (p+4) A B hla hlb ha hb
  have hwork := listCyclicConvolutionWork_list_bound depth p (p+4) A B hla hlb ha hb
  have hchirps := listBluesteinChirpsWork_bound input p hinput
  have hpoint : (List.zipWith bitFourierMulWork neg (fourierListDrop input.tail C)).sum≤
      512*input.length*(L+1)^2 := by
    have hh : ∀ w∈List.zipWith bitFourierMulWork neg (fourierListDrop input.tail C),w≤512*(L+1)^2 := by
      apply fourier_forall_zipWith
      intro z hz w hw
      have hz' := (hneg z hz).2.mono (by dsimp [L]; omega : p+4≤L)
      have hw' := (hc.2 w (List.mem_of_mem_drop (by simpa only [fourierListDrop_eq] using hw))).2
      have hm := bitFourierMulWork_bound z w L hz' hw'
      nlinarith only [hm]
    have hs := List.sum_le_card_nsmul _ _ hh
    have hlen : (List.zipWith bitFourierMulWork neg (fourierListDrop input.tail C)).length≤ input.length := by
      rw [List.length_zipWith]
      exact (Nat.min_le_left _ _).trans_eq hn
    calc
      _≤(List.zipWith bitFourierMulWork neg (fourierListDrop input.tail C)).length*(512*(L+1)^2) := hs
      _≤ input.length*(512*(L+1)^2) := Nat.mul_le_mul_right _ hlen
      _=_ := by ring
  change listBluesteinChirpsWork input p+listCyclicConvolutionWork depth p A B+
    (List.zipWith bitFourierMulWork neg (fourierListDrop input.tail C)).sum+
    radixListFuelWork depth+32*input.length+16*(radixListFuel depth).length+32≤_
  rw [radixListFuelWork_eq,radixListFuel_length]
  unfold listBluesteinWorkBound
  dsimp only [L] at hpoint
  norm_num only [Nat.add_assoc] at hpoint hwork hchirps ⊢
  omega

end Optss
