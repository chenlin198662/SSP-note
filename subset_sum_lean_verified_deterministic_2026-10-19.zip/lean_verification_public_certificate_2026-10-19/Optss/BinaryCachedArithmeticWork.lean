import Optss.LoopArithmeticBounds
import Optss.LatticeArithmeticInputBits

/-!
# Binary charges for the complete cached lattice reduction

The fold proof inspects the actual operands of each multiplication and
addition. Its hypotheses concern rational values and finite partial sums;
applications discharge these with the proven Gram-Schmidt arithmetic bounds.
The final theorem bounds the complete actual execution by a polynomial in
dimensions and original input bit lengths. No stage running-time estimate is
assumed. Rounding, comparisons and integer updates still carry primitive
charges; container and fuel administration remain outside this counter.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

/-- Accumulation of actual binary charges along a dot/product-sum fold.
The partial-sum condition covers every recursive suffix of the input list. -/
theorem meteredProductSum_binary_work_of_bits {ι : Type*} [DecidableEq ι]
    (u v : ι → ℚ) (xs : List ι) (hxs : xs.Nodup) (L : ℕ)
    (hvals : ∀ i ∈ xs, RationalBitBound (u i) L ∧ RationalBitBound (v i) L ∧
      RationalBitBound (u i*v i) L)
    (hacc : ∀ s : Finset ι, s ⊆ xs.toFinset → RationalBitBound (∑ i ∈ s, u i*v i) L) :
    (meteredProductSum binaryRationalArithmetic u v xs).2 ≤
      2*xs.length*(2048*(L+1)^3) := by
  induction xs with
  | nil => simp [meteredProductSum]
  | cons i xs ih =>
    have hhead := hvals i (List.mem_cons_self)
    have htail : xs.toFinset ⊆ (i::xs).toFinset := by
      intro j hj
      simp only [List.toFinset_cons, Finset.mem_insert]
      exact Or.inr hj
    have htailval : RationalBitBound (meteredProductSum binaryRationalArithmetic u v xs).1 L := by
      rw [meteredProductSum_value, ← List.sum_toFinset _ (show xs.Nodup from hxs.tail)]
      exact hacc xs.toFinset htail
    have hm := (binaryRationalArithmetic_cubic (u i) (v i) L hhead.1 hhead.2.1).2.2.1
    have hp : RationalBitBound (binaryRationalArithmetic.mul (u i) (v i)).1 L := by
      rw [binaryRationalArithmetic.mul_value]
      exact hhead.2.2
    have ha := (binaryRationalArithmetic_cubic
      (binaryRationalArithmetic.mul (u i) (v i)).1
      (meteredProductSum binaryRationalArithmetic u v xs).1 L hp htailval).1
    have hi := ih hxs.tail (fun j hj => hvals j (List.mem_cons_of_mem _ hj))
      (fun s hs => hacc s (hs.trans htail))
    rw [meteredProductSum]
    simp only [List.length_cons]
    nlinarith

/-- A shared magnitude envelope for all cached cells, dot/projection sums and
Lovász intermediates at one independent integer matrix. -/
def cachedOperandMagnitude (r d K : ℕ) : ℕ := (8+K+2*K^6)^(2*(r+d)+10)

theorem cachedOperandMagnitude_ge_pow (r d K e : ℕ) (hK : 1 ≤ K) (he : e ≤ 6) :
    K^e ≤ cachedOperandMagnitude r d K := by
  have hbase : 1 ≤ 8+K+2*K^6 := by omega
  have hk : K^6 ≤ 8+K+2*K^6 := by omega
  exact (Nat.pow_le_pow_right hK he).trans (hk.trans
    (by simpa only [pow_one] using Nat.pow_le_pow_right hbase (by omega : 1 ≤ 2*(r+d)+10)))

theorem cachedOperandMagnitude_ge_dot (r d K : ℕ) (hK : 1 ≤ K) :
    (2*K^4)^d ≤ cachedOperandMagnitude r d K := by
  have hk : K^4 ≤ K^6 := Nat.pow_le_pow_right hK (by omega)
  have hb : 2*K^4 ≤ 8+K+2*K^6 := by omega
  exact (Nat.pow_le_pow_left hb d).trans
    (Nat.pow_le_pow_right (by omega) (by omega : d ≤ 2*(r+d)+10))

theorem cachedOperandMagnitude_ge_projection (r d K : ℕ) :
    (2*K^6)^(r+1) ≤ cachedOperandMagnitude r d K := by
  exact (Nat.pow_le_pow_left (by omega : 2*K^6 ≤ 8+K+2*K^6) (r+1)).trans
    (Nat.pow_le_pow_right (by omega) (by omega : r+1 ≤ 2*(r+d)+10))

/-- The universal magnitude envelope has bit length polynomial in dimension
and in the bits of the fixed arithmetic base. -/
theorem cachedOperandMagnitude_bits (r d K : ℕ) (hK : 4 ≤ K) :
    (cachedOperandMagnitude r d K).size ≤ (8*(2*(r+d)+10))*K.size := by
  have hK1 : 1 ≤ K := by omega
  have hk6 : K ≤ K^6 := by
    simpa only [pow_one] using Nat.pow_le_pow_right hK1 (by omega : 1 ≤ 6)
  have hk3 : K^3 ≤ K^6 := Nat.pow_le_pow_right hK1 (by omega)
  have h8 : 8 ≤ K^6 := by nlinarith [Nat.pow_le_pow_left hK 3]
  have h4 : 4 ≤ K^2 := by nlinarith
  have hb : 8+K+2*K^6 ≤ K^8 := by
    have hm := Nat.mul_le_mul_right (K^6) h4
    nlinarith [pow_add K 2 6]
  apply nat_size_le_of_le_pow (by omega : 0 < 8*(2*(r+d)+10))
  calc
    _ ≤ (K^8)^(2*(r+d)+10) := Nat.pow_le_pow_left hb _
    _ = _ := by rw [← pow_mul]

/-- Conversion from an actual reduced magnitude bound to the common bit bound. -/
theorem cachedOperandMagnitude_to_bits (r d K : ℕ) (hK : 4 ≤ K) {q : ℚ}
    (hq : RationalSizeBound q (cachedOperandMagnitude r d K)) :
    RationalBitBound q ((8*(2*(r+d)+10))*K.size) := by
  have hb := cachedOperandMagnitude_bits r d K hK
  exact ⟨(Nat.size_le_size hq.1).trans hb, (Nat.size_le_size hq.2).trans hb⟩

/-- Exact binary work of a cross-dot fold, with every operand hypothesis
discharged from the independent integer matrix and its entry height. -/
theorem meteredCrossDot_binary_work (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k j : Fin r) :
    let K := gsArithmeticBase d H (gramPotential A)
    let L := (8*(2*(r+d)+10))*K.size
    (meteredRationalDot binaryRationalArithmetic
      (rationalGramSchmidt (rationalIntegerRows A) j) (rationalIntegerRows A k)).2 ≤
        2*d*(2048*(L+1)^3) := by
  let K := gsArithmeticBase d H (gramPotential A)
  have hK : 4 ≤ K := by unfold K gsArithmeticBase; omega
  have hc : ∀ q, RationalSizeBound q (cachedOperandMagnitude r d K) →
      RationalBitBound q ((8*(2*(r+d)+10))*K.size) :=
    fun q hq => cachedOperandMagnitude_to_bits r d K hK hq
  have hvals : ∀ l ∈ (List.ofFn (id : Fin d → Fin d)),
      RationalBitBound (rationalGramSchmidt (rationalIntegerRows A) j l) ((8*(2*(r+d)+10))*K.size) ∧
      RationalBitBound (rationalIntegerRows A k l) ((8*(2*(r+d)+10))*K.size) ∧
      RationalBitBound (rationalGramSchmidt (rationalIntegerRows A) j l*rationalIntegerRows A k l)
        ((8*(2*(r+d)+10))*K.size) := by
    intro l _
    refine ⟨hc _ ((rationalGramSchmidt_size A hA H j l).mono ?_),
      hc _ ((rationalIntegerRows_size A H hH k l).mono ?_),
      hc _ ((rationalDotTerm_sizes A hA H hH k j l).1.mono ?_)⟩
    all_goals exact cachedOperandMagnitude_ge_pow r d K _ (by omega) (by omega)
  have hacc : ∀ s : Finset (Fin d), s ⊆ (List.ofFn (id : Fin d → Fin d)).toFinset →
      RationalBitBound (∑ l ∈ s, rationalGramSchmidt (rationalIntegerRows A) j l*rationalIntegerRows A k l)
        ((8*(2*(r+d)+10))*K.size) := by
    intro s _
    exact hc _ ((rationalPartialDot_cross_size A hA H hH k j s).mono
      (cachedOperandMagnitude_ge_dot r d K (by omega)))
  have hb := meteredProductSum_binary_work_of_bits
    (rationalGramSchmidt (rationalIntegerRows A) j) (rationalIntegerRows A k)
    (List.ofFn id) (List.nodup_ofFn_ofInjective Function.injective_id)
    ((8*(2*(r+d)+10))*K.size) hvals hacc
  simpa only [meteredRationalDot, List.length_ofFn] using hb

/-- Fixed bit and work envelopes for one cached table at an integer matrix. -/
def cachedArithmeticBits (r d H P : ℕ) : ℕ :=
  (8*(2*(r+d)+10))*(gsArithmeticBase d H P).size

def cachedBinaryWorkBound (r d H P : ℕ) : ℕ :=
  2048*(cachedArithmeticBits r d H P+1)^3

theorem meteredSelfDot_binary_work (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (H : ℕ) (j : Fin r) :
    (meteredRationalDot binaryRationalArithmetic
      (rationalGramSchmidt (rationalIntegerRows A) j) (rationalGramSchmidt (rationalIntegerRows A) j)).2 ≤
        2*d*cachedBinaryWorkBound r d H (gramPotential A) := by
  let K := gsArithmeticBase d H (gramPotential A)
  have hK : 4 ≤ K := by unfold K gsArithmeticBase; omega
  have hc : ∀ q, RationalSizeBound q (cachedOperandMagnitude r d K) →
      RationalBitBound q (cachedArithmeticBits r d H (gramPotential A)) :=
    fun q hq => cachedOperandMagnitude_to_bits r d K hK hq
  have hvals : ∀ l ∈ (List.ofFn (id : Fin d → Fin d)),
      RationalBitBound (rationalGramSchmidt (rationalIntegerRows A) j l) (cachedArithmeticBits r d H (gramPotential A)) ∧
      RationalBitBound (rationalGramSchmidt (rationalIntegerRows A) j l) (cachedArithmeticBits r d H (gramPotential A)) ∧
      RationalBitBound (rationalGramSchmidt (rationalIntegerRows A) j l*rationalGramSchmidt (rationalIntegerRows A) j l)
        (cachedArithmeticBits r d H (gramPotential A)) := by
    intro l _
    have hg := rationalGramSchmidt_size A hA H j l
    have hb := hc _ (hg.mono (cachedOperandMagnitude_ge_pow r d K 2 (by omega) (by omega)))
    refine ⟨hb, hb, hc _ ((hg.mul hg).mono ?_)⟩
    simpa only [← pow_add] using cachedOperandMagnitude_ge_pow r d K 4 (by omega) (by omega)
  have hacc : ∀ s : Finset (Fin d), s ⊆ (List.ofFn (id : Fin d → Fin d)).toFinset →
      RationalBitBound (∑ l ∈ s, rationalGramSchmidt (rationalIntegerRows A) j l*rationalGramSchmidt (rationalIntegerRows A) j l)
        (cachedArithmeticBits r d H (gramPotential A)) := by
    intro s _
    exact hc _ ((rationalPartialDot_self_size A hA H j s).mono
      (cachedOperandMagnitude_ge_dot r d K (by omega)))
  have hb := meteredProductSum_binary_work_of_bits
    (rationalGramSchmidt (rationalIntegerRows A) j) (rationalGramSchmidt (rationalIntegerRows A) j)
    (List.ofFn id) (List.nodup_ofFn_ofInjective Function.injective_id)
    (cachedArithmeticBits r d H (gramPotential A)) hvals hacc
  simpa only [meteredRationalDot, List.length_ofFn, cachedBinaryWorkBound] using hb

/-- Complete cross and self dot products fit the common operand-bit bound. -/
theorem cachedDot_operands_bits (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k j : Fin r) :
    RationalBitBound (rationalDot (rationalGramSchmidt (rationalIntegerRows A) j) (rationalIntegerRows A k))
      (cachedArithmeticBits r d H (gramPotential A)) ∧
    RationalBitBound (rationalDot (rationalGramSchmidt (rationalIntegerRows A) j)
      (rationalGramSchmidt (rationalIntegerRows A) j)) (cachedArithmeticBits r d H (gramPotential A)) := by
  have hK : 4 ≤ gsArithmeticBase d H (gramPotential A) := by unfold gsArithmeticBase; omega
  constructor
  · exact cachedOperandMagnitude_to_bits r d _ hK
      ((rationalPartialDot_cross_size A hA H hH k j Finset.univ).mono
        (cachedOperandMagnitude_ge_dot r d _ (by omega)))
  · exact cachedOperandMagnitude_to_bits r d _ hK
      ((rationalPartialDot_self_size A hA H j Finset.univ).mono
        (cachedOperandMagnitude_ge_dot r d _ (by omega)))

/-- Binary charge of an actual projection coefficient from a correct cached
row, including both dot-product folds and exact normalized division. -/
theorem meteredGsCoefficient_binary_work (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ))
    (T : RationalGSTable r d) (k j : Fin r)
    (hT : (T.get j).get = rationalGramSchmidt (rationalIntegerRows A) j) :
    (meteredGsCoefficient binaryRationalArithmetic (rationalIntegerRows A) T k j).2 ≤
      (4*d+1)*cachedBinaryWorkBound r d H (gramPotential A) := by
  rw [meteredGsCoefficient]
  simp only [hT, meteredRationalDot_value]
  have hx := meteredCrossDot_binary_work A hA H hH k j
  have hy := meteredSelfDot_binary_work A hA H j
  obtain ⟨hxbit,hybit⟩ := cachedDot_operands_bits A hA H hH k j
  have hdiv := (binaryRationalArithmetic_cubic _ _ _ hxbit hybit).2.2.2
  change _ ≤ (4*d+1)*cachedBinaryWorkBound r d H (gramPotential A)
  change _ ≤ cachedBinaryWorkBound r d H (gramPotential A) at hdiv
  change _ ≤ 2*d*cachedBinaryWorkBound r d H (gramPotential A) at hx
  nlinarith


/-- Every partial projection sum over a subtype of preceding rows has the
common operand bound. This directly covers suffixes of the cached row fold. -/
theorem projectionSubtype_operands_bits (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r) (l : Fin d)
    (s : Finset (Finset.Iio k)) :
    RationalBitBound (∑ i ∈ s, rationalGsCoefficient (rationalIntegerRows A) k i *
      rationalGramSchmidt (rationalIntegerRows A) i l)
      (cachedArithmeticBits r d H (gramPotential A)) := by
  let K := gsArithmeticBase d H (gramPotential A)
  have hK : 4 ≤ K := by unfold K gsArithmeticBase; omega
  apply cachedOperandMagnitude_to_bits r d K hK
  have hterms : ∀ i ∈ s, RationalSizeBound
      (rationalGsCoefficient (rationalIntegerRows A) k i *
        rationalGramSchmidt (rationalIntegerRows A) i l) (K^6) := by
    intro i _
    exact rationalProjectionTerm_size A hA H hH k i l
  have hb := rational_sum_size s _ (K^6) (by positivity) hterms
  have hcard : Fintype.card (Finset.Iio k) = k.val := by
    rw [← Fintype.card_congr (lowerFinEquiv k), Fintype.card_fin]
  have hs : s.card ≤ k.val := by simpa only [hcard] using s.card_le_univ
  apply hb.mono
  exact (Nat.pow_le_pow_right (by have hp : 1 ≤ K^6 := one_le_pow₀ (by omega); omega : 1 ≤ 2*K^6)
    (show s.card ≤ r+1 by have := k.isLt; omega)).trans
      (cachedOperandMagnitude_ge_projection r d K)

/-- Binary work of the exact projection fold used to construct one cached
Gram-Schmidt coordinate. -/
theorem meteredProjection_binary_work (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r) (l : Fin d) :
    (meteredProductSum binaryRationalArithmetic
      (fun i : Finset.Iio k => rationalGsCoefficient (rationalIntegerRows A) k i)
      (fun i => rationalGramSchmidt (rationalIntegerRows A) i l)
      (List.ofFn (lowerFinEquiv k))).2 ≤ 2*k.val*cachedBinaryWorkBound r d H (gramPotential A) := by
  let K := gsArithmeticBase d H (gramPotential A)
  have hK : 4 ≤ K := by unfold K gsArithmeticBase; omega
  have hvals : ∀ i ∈ List.ofFn (lowerFinEquiv k),
      RationalBitBound (rationalGsCoefficient (rationalIntegerRows A) k i)
        (cachedArithmeticBits r d H (gramPotential A)) ∧
      RationalBitBound (rationalGramSchmidt (rationalIntegerRows A) i l)
        (cachedArithmeticBits r d H (gramPotential A)) ∧
      RationalBitBound (rationalGsCoefficient (rationalIntegerRows A) k i *
        rationalGramSchmidt (rationalIntegerRows A) i l)
        (cachedArithmeticBits r d H (gramPotential A)) := by
    intro i _
    refine ⟨cachedOperandMagnitude_to_bits r d K hK
        ((rationalGsCoefficient_size A hA H hH k i).mono ?_),
      cachedOperandMagnitude_to_bits r d K hK
        ((rationalGramSchmidt_size A hA H i l).mono ?_),
      cachedOperandMagnitude_to_bits r d K hK
        ((rationalProjectionTerm_size A hA H hH k i l).mono ?_)⟩
    all_goals exact cachedOperandMagnitude_ge_pow r d K _ (by omega) (by omega)
  have hb := meteredProductSum_binary_work_of_bits _ _ _
    (List.nodup_ofFn_ofInjective (lowerFinEquiv k).injective)
    (cachedArithmeticBits r d H (gramPotential A)) hvals
    (fun s _ => projectionSubtype_operands_bits A hA H hH k l s)
  simpa only [List.length_ofFn, cachedBinaryWorkBound] using hb

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

/-- Binary work of one entire materialized Gram-Schmidt row, charged at the
actual scalar operands in coefficient and residual computation. -/
theorem meteredGSRow_binary_work (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (T : RationalGSTable r d) (k : Fin r)
    (hT : ∀ i : Fin r, i < k → (T.get i).get = rationalGramSchmidt (rationalIntegerRows A) i) :
    (meteredGSRow binaryRationalArithmetic (rationalIntegerRows A) T k).2 ≤
      (k.val*(4*d+1)+d*(2*k.val+1))*cachedBinaryWorkBound r d H (gramPotential A) := by
  let Q := rationalIntegerRows A
  let W := cachedBinaryWorkBound r d H (gramPotential A)
  let coeff : Vector (ℚ × ℕ) r := Vector.ofFn fun i =>
    if i < k then meteredGsCoefficient binaryRationalArithmetic Q T k i else (0,0)
  have hcv : ∀ i : Finset.Iio k, (coeff.get i).1 = rationalGsCoefficient Q k i := by
    intro i
    have hi : (i:Fin r) < k := Finset.mem_Iio.mp i.2
    simp only [coeff, get_ofFn, hi, ↓reduceIte, meteredGsCoefficient_value, cachedGsCoefficient,
      hT i hi, rationalGsCoefficient]
    rfl
  have htv : (fun i : Finset.Iio k => (T.get i).get) =
      (fun i : Finset.Iio k => rationalGramSchmidt Q i) := funext fun i => hT i (Finset.mem_Iio.mp i.2)
  have hc : (∑ i : Fin r, (coeff.get i).2) ≤ k.val*(4*d+1)*W := by
    calc
      _ ≤ ∑ i : Fin r, if i < k then (4*d+1)*W else 0 := by
        apply Finset.sum_le_sum
        intro i _
        simp only [coeff, get_ofFn]
        split_ifs with hi
        · exact meteredGsCoefficient_binary_work A hA H hH T k i (hT i hi)
        · exact le_rfl
      _ = _ := by
        rw [← Finset.sum_filter]
        have he : Finset.univ.filter (fun i : Fin r => i < k) = Finset.Iio k := by ext i; simp
        rw [he]
        simp [Nat.mul_assoc]
  have hrow : ∀ l : Fin d,
      let acc := meteredProductSum binaryRationalArithmetic (fun i : Finset.Iio k => (coeff.get i).1)
        (fun i => (T.get i).get l) (List.ofFn (lowerFinEquiv k))
      acc.2+(binaryRationalArithmetic.sub (Q k l) acc.1).2 ≤ (2*k.val+1)*W := by
    intro l
    have heCoeff : (fun i : Finset.Iio k => (coeff.get i).1) =
        (fun i : Finset.Iio k => rationalGsCoefficient Q k i) := funext hcv
    have heRows : (fun i : Finset.Iio k => (T.get i).get l) =
        (fun i : Finset.Iio k => rationalGramSchmidt Q i l) := by
      funext i
      exact congrFun (congrFun htv i) l
    simp only [heCoeff, heRows]
    have hp := meteredProjection_binary_work A hA H hH k l
    have hacc : RationalBitBound
        (meteredProductSum binaryRationalArithmetic
          (fun i : Finset.Iio k => rationalGsCoefficient Q k i)
          (fun i => rationalGramSchmidt Q i l) (List.ofFn (lowerFinEquiv k))).1
        (cachedArithmeticBits r d H (gramPotential A)) := by
      rw [meteredProductSum_value, List.map_ofFn, List.sum_ofFn]
      simp only [Function.comp_apply]
      rw [Equiv.sum_comp (lowerFinEquiv k) (fun i : Finset.Iio k =>
        rationalGsCoefficient Q k i*rationalGramSchmidt Q i l)]
      exact projectionSubtype_operands_bits A hA H hH k l Finset.univ
    have hK : 4 ≤ gsArithmeticBase d H (gramPotential A) := by unfold gsArithmeticBase; omega
    have hin := cachedOperandMagnitude_to_bits r d _ hK
      ((rationalIntegerRows_size A H hH k l).mono
        (cachedOperandMagnitude_ge_pow r d _ 2 (by omega) (by omega)))
    have hsub := (binaryRationalArithmetic_cubic _ _ _ hin hacc).2.1
    change _ ≤ W at hsub
    change _ ≤ 2*k.val*W at hp
    dsimp only [Q] at *
    nlinarith
  change (∑ i : Fin r, (coeff.get i).2) + _ ≤ _
  have hr : (∑ l : Fin d,
      let acc := meteredProductSum binaryRationalArithmetic (fun i : Finset.Iio k => (coeff.get i).1)
        (fun i => (T.get i).get l) (List.ofFn (lowerFinEquiv k))
      acc.2+(binaryRationalArithmetic.sub (Q k l) acc.1).2) ≤ d*((2*k.val+1)*W) := by
    calc
      _ ≤ ∑ _l : Fin d, ((2*k.val+1)*W) := Finset.sum_le_sum (fun l _ => hrow l)
      _ = _ := by simp
  calc
    _ ≤ k.val*(4*d+1)*W+d*((2*k.val+1)*W) := by
      simpa only [coeff, Q, get_ofFn] using Nat.add_le_add hc hr
    _ = _ := by ring


/-- Binary charge of the actual materialized Gram-Schmidt table. -/
theorem meteredGSTable_binary_work (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (n : ℕ) (hn : n ≤ r) :
    (meteredGSTable binaryRationalArithmetic (rationalIntegerRows A) n hn).2 ≤
      n*(r*(4*d+1)+d*(2*r+1))*cachedBinaryWorkBound r d H (gramPotential A) := by
  induction n with
  | zero => simp [meteredGSTable]
  | succ n ih =>
    rw [meteredGSTable]
    have hT : ∀ i : Fin r, i < (⟨n, by omega⟩ : Fin r) →
        ((meteredGSTable binaryRationalArithmetic (rationalIntegerRows A) n (by omega)).1.get i).get =
          rationalGramSchmidt (rationalIntegerRows A) i := by
      intro i hi
      rw [meteredGSTable_value]
      exact cachedGSTable_correct _ n (by omega) i hi
    have hr := meteredGSRow_binary_work A hA H hH
      (meteredGSTable binaryRationalArithmetic (rationalIntegerRows A) n (by omega)).1
      ⟨n, by omega⟩ hT
    have hi := ih (by omega)
    have hn' : n ≤ r := by omega
    have hm : n*(4*d+1)+d*(2*n+1) ≤ r*(4*d+1)+d*(2*r+1) := by gcongr
    have hr' := hr.trans (Nat.mul_le_mul_right (cachedBinaryWorkBound r d H (gramPotential A)) hm)
    nlinarith

theorem cachedBinaryWorkBound_pos (r d H P : ℕ) : 0 < cachedBinaryWorkBound r d H P := by
  unfold cachedBinaryWorkBound
  positivity

theorem cachedBinaryWorkBound_mono (r d : ℕ) {H H' P P' : ℕ}
    (hH : H ≤ H') (hP : P ≤ P') :
    cachedBinaryWorkBound r d H P ≤ cachedBinaryWorkBound r d H' P' := by
  have hb : gsArithmeticBase d H P ≤ gsArithmeticBase d H' P' := by
    unfold gsArithmeticBase
    gcongr
  have hs := Nat.size_le_size hb
  unfold cachedBinaryWorkBound cachedArithmeticBits
  gcongr

/-- Binary charge of an inner sweep under integer height and potential bounds
for its actual recorded states. Later applications derive these state bounds
from the original input using `integerRowSweepTrace` invariants. -/
theorem meteredReduceIntegerRow_binary_work_of_states (D : IntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (hn : n ≤ k.val) (H P : ℕ)
    (hstates : ∀ B ∈ integerRowSweepTrace (integerMatrixDataRows D) k n hn,
      LinearIndependent ℝ (fun i j => (B i j:ℝ)) ∧ gramPotential B ≤ P ∧
        (∀ i j, |B i j| ≤ (H:ℤ))) :
    (meteredReduceIntegerRow binaryRationalArithmetic D k n hn).2 ≤
      n*cachedInnerArithmeticBound r d*cachedBinaryWorkBound r d H P := by
  induction n generalizing D with
  | zero => simp [meteredReduceIntegerRow]
  | succ n ih =>
    let A := integerMatrixDataRows D
    have hmem : A ∈ integerRowSweepTrace A k (n+1) hn := by
      rw [integerRowSweepTrace]
      exact List.mem_cons_self
    obtain ⟨hA,hP,hH⟩ := hstates A hmem
    let j : Fin r := ⟨n, by omega⟩
    let T := (meteredGSTable binaryRationalArithmetic (rationalIntegerRows A) r le_rfl).1
    let q := round (meteredGsCoefficient binaryRationalArithmetic (rationalIntegerRows A) T k j).1
    let W := (meteredIntegerRowUpdate D k j q).1
    have hq : q = round (rationalGsCoefficient (rationalIntegerRows A) k j) := by
      dsimp only [q, T]
      rw [meteredGsCoefficient_value, meteredGSTable_value, cachedGsCoefficient_correct]
    have hW : integerMatrixDataRows W = Function.update A k (A k - q • A j) := by
      dsimp only [W]
      rw [meteredIntegerRowUpdate_value, integerMatrixDataRows_materialize]
    have htail : ∀ B ∈ integerRowSweepTrace (integerMatrixDataRows W) k n (by omega),
        LinearIndependent ℝ (fun i j => (B i j:ℝ)) ∧ gramPotential B ≤ P ∧
          (∀ i j, |B i j| ≤ (H:ℤ)) := by
      intro B hB
      apply hstates B
      rw [integerRowSweepTrace]
      apply List.mem_cons_of_mem
      simpa only [hW, hq] using hB
    have ht := ih W (by omega) htail
    have htable := meteredGSTable_binary_work A hA H hH r le_rfl
    have hT : (T.get j).get = rationalGramSchmidt (rationalIntegerRows A) j := by
      dsimp only [T]
      rw [meteredGSTable_value]
      exact cachedGSTable_full_correct _ j
    have hc := meteredGsCoefficient_binary_work A hA H hH T k j hT
    have hmono := cachedBinaryWorkBound_mono r d (H := H) (H' := H) le_rfl hP
    have htable' := htable.trans (Nat.mul_le_mul_left (r*(r*(4*d+1)+d*(2*r+1))) hmono)
    have hc' := hc.trans (Nat.mul_le_mul_left (4*d+1) hmono)
    have hone : 1 ≤ cachedBinaryWorkBound r d H P := cachedBinaryWorkBound_pos r d H P
    have hround : 1+2*d ≤ (1+2*d)*cachedBinaryWorkBound r d H P :=
      Nat.le_mul_of_pos_right _ hone
    rw [meteredReduceIntegerRow]
    simp only [meteredIntegerRowUpdate_work]
    change (meteredGSTable binaryRationalArithmetic (rationalIntegerRows A) r le_rfl).2 +
      (meteredGsCoefficient binaryRationalArithmetic (rationalIntegerRows A) T k j).2 + 1 + 2*d +
      (meteredReduceIntegerRow binaryRationalArithmetic W k n (by omega)).2 ≤ _
    calc
      _ = (meteredGSTable binaryRationalArithmetic (rationalIntegerRows A) r le_rfl).2 +
          (meteredGsCoefficient binaryRationalArithmetic (rationalIntegerRows A) T k j).2 + (1+2*d) +
          (meteredReduceIntegerRow binaryRationalArithmetic W k n (by omega)).2 := by omega
      _ ≤ (r*(r*(4*d+1)+d*(2*r+1)))*cachedBinaryWorkBound r d H P +
          (4*d+1)*cachedBinaryWorkBound r d H P + (1+2*d)*cachedBinaryWorkBound r d H P +
          n*cachedInnerArithmeticBound r d*cachedBinaryWorkBound r d H P :=
        Nat.add_le_add (Nat.add_le_add (Nat.add_le_add htable' hc') hround) ht
      _ = _ := by unfold cachedInnerArithmeticBound; ring


/-- Accumulation over the actual outer sweep, with the inner-state premise
expressed using its proved semantic trace rather than arbitrary costs. -/
theorem meteredReduceIntegerAll_binary_work_of_states (D : IntegerMatrixData r d)
    (n : ℕ) (hn : n ≤ r) (H P : ℕ)
    (hstates : ∀ (k : Fin r), k.val < n → ∀ B ∈ integerRowSweepTrace
      (rationalReduceIntegerAll (integerMatrixDataRows D) k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl,
      LinearIndependent ℝ (fun i j => (B i j:ℝ)) ∧ gramPotential B ≤ P ∧
        (∀ i j, |B i j| ≤ (H:ℤ))) :
    (meteredReduceIntegerAll binaryRationalArithmetic D n hn).2 ≤
      n*r*cachedInnerArithmeticBound r d*cachedBinaryWorkBound r d H P := by
  induction n with
  | zero => simp [meteredReduceIntegerAll]
  | succ n ih =>
    have hi := ih (by omega) (fun k hk => hstates k (by omega))
    let C := (meteredReduceIntegerAll binaryRationalArithmetic D n (by omega)).1
    have hC : integerMatrixDataRows C =
        rationalReduceIntegerAll (integerMatrixDataRows D) n (by omega) := by
      dsimp only [C]
      rw [meteredReduceIntegerAll_value, materializedReduceIntegerAll_eq,
        cachedReduceIntegerAll_eq]
    have hc := meteredReduceIntegerRow_binary_work_of_states C ⟨n, by omega⟩ n le_rfl H P
      (by intro B hB; exact hstates ⟨n, by omega⟩ (by change n < n+1; omega) B (by simpa only [hC] using hB))
    have hnr : n ≤ r := by omega
    have hc' := hc.trans (Nat.mul_le_mul_right (cachedBinaryWorkBound r d H P)
      (Nat.mul_le_mul_right (cachedInnerArithmeticBound r d) hnr))
    rw [meteredReduceIntegerAll]
    change (meteredReduceIntegerAll binaryRationalArithmetic D n (by omega)).2 +
      (meteredReduceIntegerRow binaryRationalArithmetic C ⟨n, by omega⟩ n le_rfl).2 ≤ _
    calc
      _ ≤ n*r*cachedInnerArithmeticBound r d*cachedBinaryWorkBound r d H P +
          r*cachedInnerArithmeticBound r d*cachedBinaryWorkBound r d H P := Nat.add_le_add hi hc'
      _ = _ := by ring

theorem sweepArithmeticHeight_mono (r d : ℕ) {H H' P P' : ℕ}
    (hH : H ≤ H') (hP : P ≤ P') :
    sweepArithmeticHeight r d H P ≤ sweepArithmeticHeight r d H' P' := by
  unfold sweepArithmeticHeight partialReductionGrowth
  gcongr

theorem le_sweepArithmeticHeight (r d H P : ℕ) : H ≤ sweepArithmeticHeight r d H P := by
  have hg : 1 ≤ partialReductionGrowth r P ^ r := by
    apply one_le_pow₀
    unfold partialReductionGrowth
    omega
  exact (by omega : H ≤ H+r*P+d*H^2+2).trans (Nat.le_mul_of_pos_right _ hg)

/-- The full pass charge is derived from the actual input matrix. All partial
row-update heights and all rational operands are bounded internally. -/
theorem meteredReduceIntegerAll_binary_work (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ)))
    (H P : ℕ) (hP : gramPotential (integerMatrixDataRows D) ≤ P)
    (hH : ∀ i j, |integerMatrixDataRows D i j| ≤ (H:ℤ)) (n : ℕ) (hn : n ≤ r) :
    (meteredReduceIntegerAll binaryRationalArithmetic D n hn).2 ≤
      n*r*cachedInnerArithmeticBound r d*
        cachedBinaryWorkBound r d (sweepArithmeticHeight r d H P) P := by
  apply meteredReduceIntegerAll_binary_work_of_states
  intro k hk B hB
  obtain ⟨hind,hp⟩ := outerSweep_innerTrace_independent_potential
    (integerMatrixDataRows D) hD k B hB
  refine ⟨hind, hp ▸ hP, ?_⟩
  intro i j
  have hb := outerSweep_innerTrace_all_entries (integerMatrixDataRows D) hD H hH k B hB i j
  have hm := sweepArithmeticHeight_mono r d (H := H) (H' := H) le_rfl hP
  have hbound : (B i j).natAbs ≤ sweepArithmeticHeight r d H P := hb.trans hm
  simpa only [Int.natCast_natAbs] using (show ((B i j).natAbs:ℤ) ≤ (sweepArithmeticHeight r d H P:ℤ) by exact_mod_cast hbound)
/-- The same common envelope also covers the complete Lovász expression. -/
theorem cachedOperandMagnitude_ge_lovasz (r d K : ℕ) (hK : 1 ≤ K) :
    cachedLovaszHeight d K ≤ cachedOperandMagnitude r d K := by
  let B := 8+K+2*K^6
  have hB : 2 ≤ B := by dsimp only [B]; omega
  have hKB : K ≤ B := by dsimp only [B]; omega
  have h8 : 8 ≤ B := by dsimp only [B]; omega
  have hk4 : K^4 ≤ K^6 := Nat.pow_le_pow_right hK (by omega)
  have hd : (2*K^4)^d ≤ B^d := Nat.pow_le_pow_left (by dsimp only [B]; omega) d
  have hbig : 8*K^8*((2*K^4)^d)^2 ≤ B^(2*d+9) := by
    calc
      _ ≤ B*B^8*(B^d)^2 := Nat.mul_le_mul
        (Nat.mul_le_mul h8 (Nat.pow_le_pow_left hKB _)) (Nat.pow_le_pow_left hd _)
      _ = _ := by rw [← pow_mul]; ring
  have hsmall : 3*(2*K^4)^d+1 ≤ B^(2*d+9) := by
    have hbpow : 1 ≤ B^d := one_le_pow₀ (by omega)
    have hfour : 3*(2*K^4)^d+1 ≤ B*B^d := by nlinarith
    exact hfour.trans (by
      rw [← pow_succ']
      exact Nat.pow_le_pow_right (by omega) (by omega))
  calc
    _ ≤ 2*B^(2*d+9) := by unfold cachedLovaszHeight; omega
    _ ≤ B*B^(2*d+9) := Nat.mul_le_mul_right _ hB
    _ = B^(2*d+10) := by rw [← pow_succ']
    _ ≤ cachedOperandMagnitude r d K := Nat.pow_le_pow_right (by omega) (by omega)

/-- All binary rational calls in one materialized Lovász test have charges
bounded by the same fixed input-derived envelope. The final comparison is
still explicitly charged as one primitive operation. -/
theorem meteredLovaszPair_binary_work (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (T : RationalGSTable r d)
    (j k : Fin r)
    (hT : ∀ i, (T.get i).get = rationalGramSchmidt (rationalIntegerRows A) i) :
    (meteredLovaszPair binaryRationalArithmetic (rationalIntegerRows A) T j k).2 ≤
      (8*d+7)*cachedBinaryWorkBound r d H (gramPotential A) := by
  let Q := rationalIntegerRows A
  let K := gsArithmeticBase d H (gramPotential A)
  let L := cachedArithmeticBits r d H (gramPotential A)
  let W := cachedBinaryWorkBound r d H (gramPotential A)
  let u := rationalGsCoefficient Q k j
  let x := rationalDot (rationalGramSchmidt Q k) (rationalGramSchmidt Q k)
  let y := rationalDot (rationalGramSchmidt Q j) (rationalGramSchmidt Q j)
  have hK : 4 ≤ K := by unfold K gsArithmeticBase; omega
  have hc : ∀ q, RationalSizeBound q (cachedOperandMagnitude r d K) → RationalBitBound q L :=
    fun q hq => cachedOperandMagnitude_to_bits r d K hK hq
  have hu : RationalBitBound u L := hc _ ((rationalGsCoefficient_size A hA H hH k j).mono
    (cachedOperandMagnitude_ge_pow r d K 4 (by omega) (by omega)))
  have hx : RationalBitBound x L := (cachedDot_operands_bits A hA H hH k k).2
  have hy : RationalBitBound y L := (cachedDot_operands_bits A hA H hH k j).2
  have hconst : ∀ z : ℚ, RationalSizeBound z 4 → RationalBitBound z L := by
    intro z hz
    apply hc z (hz.mono _)
    exact hK.trans (by simpa only [pow_one] using
      cachedOperandMagnitude_ge_pow r d K 1 (by omega) (by omega))
  have hfour : RationalBitBound 4 L := hconst _ (by norm_num [RationalSizeBound])
  have hthree : RationalBitBound 3 L := hconst _ (by norm_num [RationalSizeBound])
  obtain ⟨huu,huy,hxy,_,_⟩ := rationalLovasz_intermediate_sizes A hA H hH j k
  have hm := cachedOperandMagnitude_ge_lovasz r d K (by omega)
  have huu' : RationalBitBound (u*u) L := hc _ (huu.mono hm)
  have huy' : RationalBitBound (u*u*y) L := hc _ (huy.mono hm)
  have hxy' : RationalBitBound (x+u*u*y) L := hc _ (hxy.mono hm)
  have c1 : (binaryRationalArithmetic.mul u u).2 ≤ W :=
    (binaryRationalArithmetic_cubic _ _ L hu hu).2.2.1
  have c2 : (binaryRationalArithmetic.mul (u*u) y).2 ≤ W :=
    (binaryRationalArithmetic_cubic _ _ L huu' hy).2.2.1
  have c3 : (binaryRationalArithmetic.add x (u*u*y)).2 ≤ W :=
    (binaryRationalArithmetic_cubic _ _ L hx huy').1
  have c4 : (binaryRationalArithmetic.mul 4 (x+u*u*y)).2 ≤ W :=
    (binaryRationalArithmetic_cubic _ _ L hfour hxy').2.2.1
  have c5 : (binaryRationalArithmetic.mul 3 y).2 ≤ W :=
    (binaryRationalArithmetic_cubic _ _ L hthree hy).2.2.1
  have nx := meteredSelfDot_binary_work A hA H k
  have ny := meteredSelfDot_binary_work A hA H j
  have nc := meteredGsCoefficient_binary_work A hA H hH T k j (hT j)
  have hcval : cachedGsCoefficient (rationalIntegerRows A) T k j = u := by
    dsimp only [u, Q, cachedGsCoefficient, rationalGsCoefficient]
    rw [hT j]
  rw [meteredLovaszPair]
  simp only [meteredRationalDot_value, meteredGsCoefficient_value,
    binaryRationalArithmetic.mul_value, binaryRationalArithmetic.add_value]
  simp only [hcval, hT]
  change _ ≤ (8*d+7)*W
  have hone : 1 ≤ W := cachedBinaryWorkBound_pos r d H (gramPotential A)
  have hnx : (meteredRationalDot binaryRationalArithmetic
      (rationalGramSchmidt Q k) (rationalGramSchmidt Q k)).2 ≤ 2*d*W := nx
  have hny : (meteredRationalDot binaryRationalArithmetic
      (rationalGramSchmidt Q j) (rationalGramSchmidt Q j)).2 ≤ 2*d*W := ny
  have hnc : (meteredGsCoefficient binaryRationalArithmetic Q T k j).2 ≤ (4*d+1)*W := nc
  calc
    _ ≤ 2*d*W+2*d*W+(4*d+1)*W+W+W+W+W+W+W :=
      Nat.add_le_add (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add
        (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add hnx hny) hnc) c1) c2) c3) c4) c5) hone
    _ = _ := by ring
/-- Binary charge of the actual finite search and its one cached table. -/
theorem meteredFailingAdjacentPairs_binary_work (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |integerMatrixDataRows D i j| ≤ (H:ℤ)) :
    (meteredFailingAdjacentPairs binaryRationalArithmetic D).2 ≤
      cachedSearchArithmeticBound r d*
        cachedBinaryWorkBound r d H (gramPotential (integerMatrixDataRows D)) := by
  let A := integerMatrixDataRows D
  let T := (meteredGSTable binaryRationalArithmetic (rationalIntegerRows A) r le_rfl).1
  let W := cachedBinaryWorkBound r d H (gramPotential A)
  have hT : ∀ i, (T.get i).get = rationalGramSchmidt (rationalIntegerRows A) i := by
    intro i
    dsimp only [T]
    rw [meteredGSTable_value]
    exact cachedGSTable_full_correct _ i
  have ht := meteredGSTable_binary_work A hD H hH r le_rfl
  have hs : (∑ j : Fin r, ∑ k : Fin r,
      if k.val = j.val+1 then
        (meteredLovaszPair binaryRationalArithmetic (rationalIntegerRows A) T j k).2
      else 0) ≤ r*r*(8*d+7)*W := by
    calc
      _ ≤ ∑ _j : Fin r, ∑ _k : Fin r, (8*d+7)*W := by
        apply Finset.sum_le_sum
        intro j _
        apply Finset.sum_le_sum
        intro k _
        split_ifs
        · exact meteredLovaszPair_binary_work A hD H hH T j k hT
        · exact Nat.zero_le _
      _ = _ := by simp; ring
  unfold meteredFailingAdjacentPairs
  simp only [get_ofFn, apply_ite Prod.snd]
  calc
    _ ≤ r*(r*(4*d+1)+d*(2*r+1))*W + r*r*(8*d+7)*W := Nat.add_le_add ht hs
    _ = _ := by unfold cachedSearchArithmeticBound; ring

/-- Every accepted pair belongs to the already computed finite set. -/
theorem leastPairInFinset_mem (S : Finset (Fin r × Fin r)) (hS : S.Nonempty) :
    leastPairInFinset S hS ∈ S := by
  letI : LinearOrder (Fin r × Fin r) :=
    LinearOrder.lift' (toLex : Fin r × Fin r → Fin r ×ₗ Fin r)
      (fun _ _ h => toLex_inj.mp h)
  exact Finset.min'_mem S hS

/-- All binary rational charges of the actual loop have a common bound derived
only from its initial height and potential. Rounding, comparisons and integer
row updates remain primitive charges; container and fuel costs are separate. -/
theorem meteredReductionFuel_binary_work (fuel : ℕ) (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ)))
    (H P : ℕ) (hP : gramPotential (integerMatrixDataRows D) ≤ P)
    (hH : ∀ i j, |integerMatrixDataRows D i j| ≤ (H:ℤ)) (hcover : r*P ≤ H) :
    (meteredReductionFuel binaryRationalArithmetic fuel D).work ≤
      ((meteredReductionFuel binaryRationalArithmetic fuel D).swaps+1)*
        cachedPassArithmeticBound r d*
        cachedBinaryWorkBound r d (sweepArithmeticHeight r d H P) P := by
  induction fuel generalizing D with
  | zero => simp [meteredReductionFuel]
  | succ n ih =>
    let C := (meteredReduceIntegerAll binaryRationalArithmetic D r le_rfl).1
    let A := integerMatrixDataRows C
    let tests := meteredFailingAdjacentPairs binaryRationalArithmetic C
    let W := cachedBinaryWorkBound r d (sweepArithmeticHeight r d H P) P
    have hCeq : C = materializedReduceIntegerAll D r le_rfl := meteredReduceIntegerAll_value _ _ _ _
    obtain ⟨hC, hpC, hhC⟩ := materializedFullSweep_invariants D hD
    rw [← hCeq] at hC hpC hhC
    have hCA : LinearIndependent ℝ (fun i j => (A i j:ℝ)) := hC
    have hpA : gramPotential A ≤ P := hpC ▸ hP
    have hHA : ∀ i j, |A i j| ≤ (H:ℤ) := by
      intro i j
      exact (hhC i j).trans (by exact_mod_cast (Nat.mul_le_mul_left r hP).trans hcover)
    have hs := meteredReduceIntegerAll_binary_work D hD H P hP hH r le_rfl
    have ht := meteredFailingAdjacentPairs_binary_work C hCA H hHA
    have hmono := cachedBinaryWorkBound_mono r d (le_sweepArithmeticHeight r d H P) hpA
    have ht' : tests.2 ≤ cachedSearchArithmeticBound r d*W :=
      ht.trans (Nat.mul_le_mul_left _ hmono)
    have hpass : (meteredReduceIntegerAll binaryRationalArithmetic D r le_rfl).2+tests.2 ≤
        cachedPassArithmeticBound r d*W := by
      calc
        _ ≤ r*r*cachedInnerArithmeticBound r d*W+cachedSearchArithmeticBound r d*W :=
          Nat.add_le_add hs ht'
        _ = _ := by unfold cachedPassArithmeticBound; ring
    rw [meteredReductionFuel]
    split_ifs with hbad
    · let p := leastPairInFinset tests.1 hbad
      have hp : p ∈ failingAdjacentPairs A := by
        have hm := leastPairInFinset_mem tests.1 hbad
        change p ∈ tests.1 at hm
        dsimp only [tests] at hm
        rw [meteredFailingAdjacentPairs_value, cachedFailingAdjacentPairs_eq A hCA] at hm
        exact hm
      have hpair := (mem_failingAdjacentPairs A p).mp hp
      have hdec : gramPotential (swapRows A p.1 p.2) < gramPotential A :=
        gramPotential_swap_lt_of_three_quarters A hCA p.1 p.2 hpair.1 hpair.2
      have hind : LinearIndependent ℝ (fun i j => (swapRows A p.1 p.2 i j:ℝ)) :=
        hCA.comp (Equiv.swap p.1 p.2) (Equiv.swap p.1 p.2).injective
      let E := materializeIntegerMatrix (swapRows A p.1 p.2)
      have hE : LinearIndependent ℝ (fun i j => (integerMatrixDataRows E i j:ℝ)) := by
        simpa only [E, integerMatrixDataRows_materialize] using hind
      have hpE : gramPotential (integerMatrixDataRows E) ≤ P := by
        simpa only [E, integerMatrixDataRows_materialize] using hdec.le.trans hpA
      have hhE : ∀ i j, |integerMatrixDataRows E i j| ≤ (H:ℤ) := by
        intro i j
        simpa only [E, integerMatrixDataRows_materialize, swapRows] using
          hHA ((Equiv.swap p.1 p.2) i) j
      have hi := ih E hE hpE hhE
      change _ + tests.2 + (meteredReductionFuel binaryRationalArithmetic n E).work ≤
        ((meteredReductionFuel binaryRationalArithmetic n E).swaps+1+1)*cachedPassArithmeticBound r d*W
      calc
        _ ≤ cachedPassArithmeticBound r d*W +
            ((meteredReductionFuel binaryRationalArithmetic n E).swaps+1)*cachedPassArithmeticBound r d*W :=
          Nat.add_le_add hpass hi
        _ = _ := by ring
    · simpa only [MeteredLatticeResult.work, MeteredLatticeResult.swaps, zero_add, one_mul] using hpass
/-- Eliminate the large intermediate height from the charge by bounding its
bit length with the fixed polynomial arithmetic base. -/
theorem sweep_cachedBinaryWorkBound_le (r d H P : ℕ) :
    cachedBinaryWorkBound r d (sweepArithmeticHeight r d H P) P ≤
      2048*(8*(2*(r+d)+10)*(2*r+4)*(sweepArithmeticBase r d H P).size+1)^3 := by
  have hs : (gsArithmeticBase d (sweepArithmeticHeight r d H P) P).size ≤
      (2*r+4)*(sweepArithmeticBase r d H P).size :=
    nat_size_le_of_le_pow (by omega) (sweepGSArithmeticBase_le_pow r d H P)
  have hb : cachedArithmeticBits r d (sweepArithmeticHeight r d H P) P ≤
      8*(2*(r+d)+10)*(2*r+4)*(sweepArithmeticBase r d H P).size := by
    unfold cachedArithmeticBits
    exact (Nat.mul_le_mul_left (8*(2*(r+d)+10)) hs).trans_eq (by ring)
  unfold cachedBinaryWorkBound
  exact Nat.mul_le_mul_left 2048 (Nat.pow_le_pow_left (Nat.add_le_add_right hb 1) 3)

/-- Uniform full-execution charge for an arbitrary fuel value, with its actual
swap count. All heights and potentials in the bound refer to the original input. -/
theorem meteredReductionFuel_binary_initial_work (fuel : ℕ)
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) :
    (meteredReductionFuel binaryRationalArithmetic fuel (materializeIntegerMatrix A)).work ≤
      ((materializedReductionFuel fuel (materializeIntegerMatrix A)).2+1)*
        (32*(r+1)^4*(d+1))*
        (2048*(8*(2*(r+d)+10)*(2*r+4)*(loopArithmeticBase r d H (gramPotential A)).size+1)^3) := by
  have hind : LinearIndependent ℝ (fun i j =>
      (integerMatrixDataRows (materializeIntegerMatrix A) i j:ℝ)) := by
    simpa only [integerMatrixDataRows_materialize] using hA
  have hh : ∀ i j, |integerMatrixDataRows (materializeIntegerMatrix A) i j| ≤
      (max H (r*gramPotential A):ℕ) := by
    intro i j
    rw [integerMatrixDataRows_materialize]
    exact (hH i j).trans (by exact_mod_cast le_max_left H (r*gramPotential A))
  have hb := meteredReductionFuel_binary_work fuel (materializeIntegerMatrix A) hind
    (max H (r*gramPotential A)) (gramPotential A)
    (by rw [integerMatrixDataRows_materialize]) hh (le_max_right _ _)
  have he := congrArg Prod.snd (meteredReductionFuel_value binaryRationalArithmetic fuel
    (materializeIntegerMatrix A))
  change (meteredReductionFuel binaryRationalArithmetic fuel (materializeIntegerMatrix A)).swaps =
    (materializedReductionFuel fuel (materializeIntegerMatrix A)).2 at he
  rw [he] at hb
  exact hb.trans (Nat.mul_le_mul
    (Nat.mul_le_mul_left _ (cachedPassArithmeticBound_le r d))
    (sweep_cachedBinaryWorkBound_le r d (max H (r*gramPotential A)) (gramPotential A)))

/-- Actual binary-rational execution: a polynomial charge in dimensions,
original input bits and the actual number of accepted interchanges. -/
theorem binaryMeteredCachedData_work_le (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) :
    (meteredCachedData binaryRationalArithmetic A).work ≤
      ((cachedReductionData A).2+1)*(32*(r+1)^4*(d+1))*
        (2048*(8*(2*(r+d)+10)*(2*r+4)*(loopArithmeticBase r d H (gramPotential A)).size+1)^3) := by
  rw [meteredCachedData_def, cachedReductionData_def]
  exact meteredReductionFuel_binary_initial_work _ A hA H hH

/-- Explicit input-bit polynomial, with the swap count eliminated using
three geometric contractions per input-potential bit. This is the proved
mixed arithmetic charge; primitive round/comparison/integer operations and
container administration retain the scope documented above. -/
theorem binaryMeteredCachedData_input_polynomial (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) :
    (meteredCachedData binaryRationalArithmetic A).work ≤
      (3*(r*(r+1)+1)*(r.size+d.size+2*H.size+4))*(32*(r+1)^4*(d+1))*
        (2048*(8*(2*(r+d)+10)*(2*r+4)*
          (3*H.size+5*r.size+2*d.size+
            8*(r*(r+1)+1)*(r.size+d.size+2*H.size+4)+12)+1)^3) := by
  have hb := binaryMeteredCachedData_work_le A hA H hH
  have hs := (cachedIntegerReduction A hA).swapCount_input_bits A H hH
  have hbits := globalSweepArithmeticBase_input_bits A H hH
  change (cachedReductionData A).2+1 ≤ _ at hs
  change (loopArithmeticBase r d H (gramPotential A)).size ≤ _ at hbits
  apply hb.trans
  apply Nat.mul_le_mul
  · exact Nat.mul_le_mul_right _ hs
  · exact Nat.mul_le_mul_left 2048 (Nat.pow_le_pow_left
      (Nat.add_le_add_right (Nat.mul_le_mul_left _ hbits) 1) 3)

end Optss
