import Optss.CostedWitnessRecovery

/-!
# Localized work bounds for decision-to-witness recovery

The generic charged recovery theorem in `CostedWitnessRecovery` asks for a
work bound on every pair of integer boxes.  The actual binary searches only
query boxes nested in the original feasible box.  This file proves that
stronger, localized fact.  It is the form needed to reuse the input bit bound
for every adaptive decision call.
-/

namespace Optss

open scoped BigOperators

/-- Both endpoints of the smaller box lie in the corresponding original
coordinate interval.  In particular the smaller box is consistent. -/
def NestedBox {n : ℕ} (l u l' u' : Fin n → ℤ) : Prop :=
  ∀ i, l i ≤ l' i ∧ l' i ≤ u' i ∧ u' i ≤ u i

theorem nestedBox_refl_of_feasible {n : ℕ} {P : (Fin n → ℤ) → Prop}
    {l u : Fin n → ℤ} (h : BoxFeasible P l u) : NestedBox l u l u := by
  obtain ⟨x, hx, _⟩ := h
  intro i
  exact ⟨le_rfl, (hx i).1.trans (hx i).2, le_rfl⟩

/-- An integer between two endpoints has no larger binary magnitude than the
larger endpoint magnitude. -/
theorem natAbs_le_endpoint_max {l z u : ℤ} (hl : l ≤ z) (hu : z ≤ u) :
    z.natAbs ≤ max l.natAbs u.natAbs := by
  by_cases hz : 0 ≤ z
  · have hzu : z.natAbs ≤ u.natAbs := by
      have hucast : u ≤ (u.natAbs : ℤ) := Int.le_natAbs
      have hzcast : (z.natAbs : ℤ) = z := by
        rw [Int.natCast_natAbs, abs_of_nonneg hz]
      have hh : (z.natAbs : ℤ) ≤ (u.natAbs : ℤ) := by
        rw [hzcast]
        exact hu.trans hucast
      exact Int.ofNat_le.mp hh
    exact hzu.trans (le_max_right _ _)
  · have hzl : z.natAbs ≤ l.natAbs := by
      have hlcast : (-(l.natAbs : ℤ)) ≤ l := by
        simpa only [Int.natCast_natAbs] using neg_abs_le l
      have hzcast : (z.natAbs : ℤ) = -z := by
        rw [Int.natCast_natAbs, abs_of_nonpos (le_of_not_ge hz)]
      have hzle : -z ≤ (l.natAbs : ℤ) := by omega
      have hh : (z.natAbs : ℤ) ≤ (l.natAbs : ℤ) := by
        rw [hzcast]
        exact hzle
      exact Int.ofNat_le.mp hh
    exact hzl.trans (le_max_left _ _)

theorem natAbs_size_le_of_between {l z u : ℤ} (hl : l ≤ z) (hu : z ≤ u)
    {B : ℕ} (hbl : l.natAbs.size ≤ B) (hbu : u.natAbs.size ≤ B) :
    z.natAbs.size ≤ B := by
  have h := natAbs_le_endpoint_max hl hu
  apply (Nat.size_le_size h).trans
  rcases le_total l.natAbs u.natAbs with hle | hle
  · rw [max_eq_right hle]
    exact hbu
  · rw [max_eq_left hle]
    exact hbl

theorem nestedBox_endpoint_bits {n : ℕ} {l u l' u' : Fin n → ℤ}
    (hnested : NestedBox l u l' u') {B : ℕ}
    (hl : ∀ i, (l i).natAbs.size ≤ B)
    (hu : ∀ i, (u i).natAbs.size ≤ B) :
    (∀ i, (l' i).natAbs.size ≤ B) ∧ (∀ i, (u' i).natAbs.size ≤ B) := by
  constructor <;> intro i
  · exact natAbs_size_le_of_between (hnested i).1
      ((hnested i).2.1.trans (hnested i).2.2) (hl i) (hu i)
  · exact natAbs_size_le_of_between ((hnested i).1.trans (hnested i).2.1)
      (hnested i).2.2 (hl i) (hu i)

theorem intToNat_le_natAbs (z : ℤ) : z.toNat ≤ z.natAbs := by
  cases z <;> simp

/-- The binary size of one nonnegative coordinate width grows by at most one
bit beyond the endpoint budget. -/
theorem boxWidth_size_le_endpoint_bits {l u : ℤ} {B : ℕ}
    (hl : l.natAbs.size ≤ B) (hu : u.natAbs.size ≤ B) :
    (u - l).toNat.size ≤ B + 1 := by
  apply Nat.size_le.mpr
  have hlpow : l.natAbs < 2 ^ B := Nat.size_le.mp hl
  have hupow : u.natAbs < 2 ^ B := Nat.size_le.mp hu
  have habs : (u - l).natAbs ≤ u.natAbs + l.natAbs := by
    simpa only [sub_eq_add_neg, Int.natAbs_neg] using
      Int.natAbs_add_le u (-l)
  have hpow : u.natAbs + l.natAbs < 2 ^ (B + 1) := by
    rw [pow_succ]
    omega
  exact (intToNat_le_natAbs (u - l)).trans_lt (habs.trans_lt hpow)

/-- Hence all coordinate searches make at most `n*(B+1)` post-feasibility
oracle calls. -/
theorem boxWidth_sizes_sum_le {n B : ℕ} (l u : Fin n → ℤ)
    (hl : ∀ i, (l i).natAbs.size ≤ B)
    (hu : ∀ i, (u i).natAbs.size ≤ B) :
    (∑ i, (u i - l i).toNat.size) ≤ n * (B + 1) := by
  calc
    (∑ i, (u i - l i).toNat.size) ≤ ∑ _i : Fin n, (B + 1) := by
      apply Finset.sum_le_sum
      intro i _
      exact boxWidth_size_le_endpoint_bits (hl i) (hu i)
    _ = n * (B + 1) := by simp

/-- The charged natural binary search only evaluates points in its input
interval, so a work bound is needed there only. -/
theorem thresholdSearchCharged_work_le_interval (test : ℕ → Bool × ℕ)
    (lo width W : ℕ)
    (hW : ∀ n, lo ≤ n → n ≤ lo + width → (test n).2 ≤ W) :
    (thresholdSearchCharged test lo width).work ≤
      (thresholdSearchCharged test lo width).calls * W := by
  induction width using Nat.strong_induction_on generalizing lo with
  | h width ih =>
    by_cases hw : width = 0
    · subst width
      simp [thresholdSearchCharged]
    · have hhalf : width / 2 < width := by omega
      have hright : width - width / 2 - 1 < width := by omega
      have hquery := hW (lo + width / 2) (by omega) (by omega)
      cases hq : (test (lo + width / 2)).1 with
      | false =>
          have hrec := ih _ hright (lo + width / 2 + 1) (by
            intro n hnlo hnhi
            apply hW n <;> omega)
          rw [thresholdSearchCharged, dif_neg hw]
          simp only [hq, Bool.false_eq_true, ↓reduceIte]
          nlinarith
      | true =>
          have hrec := ih _ hhalf lo (by
            intro n hnlo hnhi
            apply hW n <;> omega)
          rw [thresholdSearchCharged, dif_neg hw]
          simp only [hq, ↓reduceIte]
          nlinarith

/-- Integer-interval version of the localized charged-search work bound. -/
theorem integerThresholdSearchCharged_work_le_interval (test : ℤ → Bool × ℕ)
    (lower upper : ℤ) (W : ℕ) (hlu : lower ≤ upper)
    (hW : ∀ z, lower ≤ z → z ≤ upper → (test z).2 ≤ W) :
    (integerThresholdSearchCharged test lower upper).work ≤
      (integerThresholdSearchCharged test lower upper).calls * W := by
  apply thresholdSearchCharged_work_le_interval
  intro n hnlo hnhi
  apply hW (lower + n)
  · omega
  · have hcast : ((upper - lower).toNat : ℤ) = upper - lower :=
      Int.toNat_of_nonneg (by omega)
    have hnhi' : n ≤ (upper - lower).toNat := by simpa using hnhi
    have hnhiZ : (n : ℤ) ≤ ((upper - lower).toNat : ℤ) := by
      exact_mod_cast hnhi'
    rw [hcast] at hnhiZ
    omega

/-- On a feasible box, every oracle call made by coordinate recovery is made
on a nested subbox.  Hence a work bound for nested subboxes bounds the literal
sum accumulated by the charged execution. -/
theorem recoverBoxCharged_work_le_nested : ∀ (n : ℕ)
    (P : (Fin n → ℤ) → Prop)
    (oracle : (Fin n → ℤ) → (Fin n → ℤ) → Bool × ℕ)
    (_horacle : ∀ l u, (oracle l u).1 = true ↔ BoxFeasible P l u)
    (l u : Fin n → ℤ) (_hfeas : BoxFeasible P l u) (W : ℕ)
    (_hW : ∀ l' u', NestedBox l u l' u' → (oracle l' u').2 ≤ W),
    (recoverBoxCharged n oracle l u).work ≤
      (recoverBoxCharged n oracle l u).calls * W := by
  intro n
  induction n with
  | zero =>
      intro P oracle horacle l u hfeas W hW
      simp [recoverBoxCharged]
  | succ n ih =>
      intro P oracle horacle l u hfeas W hW
      let chargedHead := integerThresholdSearchCharged
        (fun a => oracle l (Fin.cons a (Fin.tail u))) (l 0) (u 0)
      let plainHead := integerThresholdSearch
        (headThresholdOracle (fun l u => (oracle l u).1) l u) (l 0) (u 0)
      have hprojection := integerThresholdSearchCharged_projection
        (fun a => oracle l (Fin.cons a (Fin.tail u))) (l 0) (u 0)
      change chargedHead.value = plainHead.1 ∧
        chargedHead.calls = plainHead.2 at hprojection
      have hplain := recover_head_correct P (fun l u => (oracle l u).1)
        (fun l' u' => horacle l' u') l u hfeas
      change l 0 ≤ plainHead.1 ∧ plainHead.1 ≤ u 0 ∧
        plainHead.2 ≤ (u 0 - l 0).toNat.size ∧
        BoxFeasible (fun x => P (Fin.cons plainHead.1 x))
          (Fin.tail l) (Fin.tail u) at hplain
      have hheadLower : l 0 ≤ chargedHead.value := hprojection.1.symm ▸ hplain.1
      have hheadUpper : chargedHead.value ≤ u 0 := hprojection.1.symm ▸ hplain.2.1
      have htailFeasible :
          BoxFeasible (fun x => P (Fin.cons chargedHead.value x))
            (Fin.tail l) (Fin.tail u) := by
        rw [hprojection.1]
        exact hplain.2.2.2
      have hlu : ∀ i, l i ≤ u i := by
        obtain ⟨x, hx, _⟩ := hfeas
        exact fun i => (hx i).1.trans (hx i).2
      have hheadWork : chargedHead.work ≤ chargedHead.calls * W := by
        apply integerThresholdSearchCharged_work_le_interval
          (fun a => oracle l (Fin.cons a (Fin.tail u))) (l 0) (u 0) W (hlu 0)
        intro z hzlo hzhi
        apply hW l (Fin.cons z (Fin.tail u))
        intro i
        refine Fin.cases ?_ (fun j => ?_) i
        · simp only [Fin.cons_zero]
          exact ⟨le_rfl, hzlo, hzhi⟩
        · simp only [Fin.cons_succ, Fin.tail]
          exact ⟨le_rfl, hlu j.succ, le_rfl⟩
      let tailOracle := fun l' u' =>
        oracle (Fin.cons chargedHead.value l') (Fin.cons chargedHead.value u')
      have htailOracle : ∀ l' u', (tailOracle l' u').1 = true ↔
          BoxFeasible (fun x => P (Fin.cons chargedHead.value x)) l' u' := by
        intro l' u'
        exact (horacle _ _).trans
          (boxFeasible_fixed_head_iff P chargedHead.value l' u')
      have htailWork := ih (fun x => P (Fin.cons chargedHead.value x))
        tailOracle htailOracle (Fin.tail l) (Fin.tail u) htailFeasible W (by
          intro l' u' hnested
          apply hW (Fin.cons chargedHead.value l')
            (Fin.cons chargedHead.value u')
          intro i
          refine Fin.cases ?_ (fun j => ?_) i
          · simp only [Fin.cons_zero]
            exact ⟨hheadLower, le_rfl, hheadUpper⟩
          · simpa using hnested j)
      change chargedHead.work +
          (recoverBoxCharged n tailOracle (Fin.tail l) (Fin.tail u)).work ≤
        (chargedHead.calls +
          (recoverBoxCharged n tailOracle (Fin.tail l) (Fin.tail u)).calls) * W
      nlinarith

/-- Total recovery needs the cost of the initial feasibility query explicitly;
after a positive answer all remaining calls satisfy the nested-box premise. -/
theorem recoverBoxWithCheckCharged_work_le_nested {n : ℕ}
    (P : (Fin n → ℤ) → Prop)
    (oracle : (Fin n → ℤ) → (Fin n → ℤ) → Bool × ℕ)
    (horacle : ∀ l u, (oracle l u).1 = true ↔ BoxFeasible P l u)
    (l u : Fin n → ℤ) (W : ℕ)
    (hfirst : (oracle l u).2 ≤ W)
    (hW : ∀ l' u', NestedBox l u l' u' → (oracle l' u').2 ≤ W) :
    (recoverBoxWithCheckCharged n oracle l u).work ≤
      (recoverBoxWithCheckCharged n oracle l u).calls * W := by
  cases hanswer : (oracle l u).1 with
  | false =>
      simp [recoverBoxWithCheckCharged, hanswer]
      exact hfirst
  | true =>
      have hfeas := (horacle l u).mp hanswer
      have hrec := recoverBoxCharged_work_le_nested n P oracle horacle l u hfeas W hW
      simp only [recoverBoxWithCheckCharged, hanswer, ↓reduceIte]
      calc
        (recoverBoxCharged n oracle l u).work + (oracle l u).2 ≤
            (recoverBoxCharged n oracle l u).calls * W + W :=
          Nat.add_le_add hrec hfirst
        _ = ((recoverBoxCharged n oracle l u).calls + 1) * W := by ring

/-- Semantic correctness, the logarithmic query count, and localized charged
work in one theorem. -/
theorem recoverBoxWithCheckCharged_correct_nested {n : ℕ}
    (P : (Fin n → ℤ) → Prop)
    (oracle : (Fin n → ℤ) → (Fin n → ℤ) → Bool × ℕ)
    (horacle : ∀ l u, (oracle l u).1 = true ↔ BoxFeasible P l u)
    (l u : Fin n → ℤ) (W : ℕ)
    (hfirst : (oracle l u).2 ≤ W)
    (hW : ∀ l' u', NestedBox l u l' u' → (oracle l' u').2 ≤ W) :
    ((recoverBoxWithCheckCharged n oracle l u).point = none ↔
      ¬BoxFeasible P l u) ∧
    (∀ x, (recoverBoxWithCheckCharged n oracle l u).point = some x →
      (∀ i, l i ≤ x i ∧ x i ≤ u i) ∧ P x) ∧
    (recoverBoxWithCheckCharged n oracle l u).calls ≤
      1 + ∑ i, (u i - l i).toNat.size ∧
    (recoverBoxWithCheckCharged n oracle l u).work ≤
      (1 + ∑ i, (u i - l i).toNat.size) * W := by
  have hp := recoverBoxWithCheckCharged_projection n oracle l u
  have hc := recoverBoxWithCheck_correct P (fun l u => (oracle l u).1)
    horacle l u
  have hw := recoverBoxWithCheckCharged_work_le_nested P oracle horacle
    l u W hfirst hW
  rw [hp.2] at hw
  rw [hp.1, hp.2]
  refine ⟨hc.1, hc.2.1, hc.2.2, ?_⟩
  exact hw.trans (Nat.mul_le_mul_right W hc.2.2)

end Optss
