import Optss.BinaryGcd
import Optss.RationalInputHeight

/-!
# Rational normalization through verified binary arithmetic

A signed integer fraction is reduced using the checked binary gcd and two
checked binary divisions. The rational is constructed from its coprime fields,
so execution does not call the built-in rational normalizer. The recorded work
is the sum of proved division operand-width charges.
-/

namespace Optss

theorem signed_quotient_natAbs (z : ℤ) (g : ℕ) :
    (z.sign*(z.natAbs/g:ℕ)).natAbs = z.natAbs/g := by
  by_cases hz : z = 0
  · simp [hz]
  · simp only [Int.natAbs_mul, Int.natAbs_sign_of_nonzero hz,
      Int.natAbs_natCast, one_mul]

/-- The result contains the normalized rational and the actual sum of the
binary arithmetic work charges incurred while computing its fields. -/
def binaryNormalizeFraction (z : ℤ) (D : ℕ) (hD : 0 < D) : ℚ × ℕ := by
  let g := binaryGcd z.natAbs D
  have hg : g.value = z.natAbs.gcd D := binaryGcd_correct _ _
  have hgpos : 0 < g.value := hg ▸ Nat.gcd_pos_of_pos_right _ hD
  let nq := binaryLongDivision z.natAbs g.value
  let dq := binaryLongDivision D g.value
  have hn : nq.quotient = z.natAbs/(z.natAbs.gcd D) := by
    exact (binaryLongDivision_correct _ _ hgpos).1.trans (by rw [hg])
  have hd : dq.quotient = D/(z.natAbs.gcd D) := by
    exact (binaryLongDivision_correct _ _ hgpos).1.trans (by rw [hg])
  have hdpos : 0 < dq.quotient := by rw [hd]; exact Nat.div_gcd_pos_of_pos_right _ hD
  have hc : (z.sign*(nq.quotient:ℤ)).natAbs.Coprime dq.quotient := by
    rw [hn, hd, signed_quotient_natAbs]
    exact Nat.coprime_div_gcd_div_gcd (Nat.gcd_pos_of_pos_right _ hD)
  exact (Rat.mk' (z.sign*(nq.quotient:ℤ)) dq.quotient hdpos.ne' hc,
    g.widthWork+nq.widthWork+dq.widthWork)

theorem binaryNormalizeFraction_num (z : ℤ) (D : ℕ) (hD : 0 < D) :
    (binaryNormalizeFraction z D hD).1.num =
      z.sign*(z.natAbs/(z.natAbs.gcd D):ℕ) := by
  change z.sign*((binaryLongDivision z.natAbs (binaryGcd z.natAbs D).value).quotient:ℤ) = _
  rw [binaryGcd_correct, (binaryLongDivision_correct _ _ (Nat.gcd_pos_of_pos_right _ hD)).1]

theorem binaryNormalizeFraction_den (z : ℤ) (D : ℕ) (hD : 0 < D) :
    (binaryNormalizeFraction z D hD).1.den = D/(z.natAbs.gcd D) := by
  change (binaryLongDivision D (binaryGcd z.natAbs D).value).quotient = _
  rw [binaryGcd_correct, (binaryLongDivision_correct _ _ (Nat.gcd_pos_of_pos_right _ hD)).1]

theorem binaryNormalizeFraction_correct (z : ℤ) (D : ℕ) (hD : 0 < D) :
    (binaryNormalizeFraction z D hD).1 = (z:ℚ)/(D:ℚ) := by
  conv_lhs => rw [← Rat.num_div_den (binaryNormalizeFraction z D hD).1]
  rw [binaryNormalizeFraction_num, binaryNormalizeFraction_den]
  have hg : (z.natAbs.gcd D:ℚ) ≠ 0 := by
    exact_mod_cast (Nat.gcd_pos_of_pos_right z.natAbs hD).ne'
  have hDq : (D:ℚ) ≠ 0 := by exact_mod_cast hD.ne'
  rw [Int.cast_mul, Int.cast_natCast,
    Nat.cast_div (Nat.gcd_dvd_left _ _) hg, Nat.cast_div (Nat.gcd_dvd_right _ _) hg]
  have hz : (z.sign:ℚ)*(z.natAbs:ℚ) = z := by
    simpa only [Int.cast_mul, Int.cast_natCast] using
      congrArg (fun t : ℤ => (t:ℚ)) (Int.sign_mul_natAbs z)
  field_simp
  nlinarith [hz]

/-- Normalization's division charges are bounded by an explicit cubic in the
maximum input magnitude bit length. Sign storage needs only a constant bit. -/
theorem binaryNormalizeFraction_widthWork (z : ℤ) (D : ℕ) (hD : 0 < D) :
    (binaryNormalizeFraction z D hD).2 ≤
      16*(max z.natAbs.size D.size)^2*(2*max z.natAbs.size D.size+2)+
        16*max z.natAbs.size D.size*(2*max z.natAbs.size D.size+2) := by
  let L := max z.natAbs.size D.size
  have hn : z.natAbs.size ≤ L := le_max_left _ _
  have hd : D.size ≤ L := le_max_right _ _
  let g := binaryGcd z.natAbs D
  have hg : g.value = z.natAbs.gcd D := binaryGcd_correct _ _
  have hgpos : 0 < g.value := hg ▸ Nat.gcd_pos_of_pos_right _ hD
  have hgb : g.value.size ≤ L :=
    (Nat.size_le_size (hg ▸ Nat.gcd_le_right _ hD)).trans hd
  have hbN : (binaryLongDivision z.natAbs g.value).widthWork ≤ 8*L*(2*L+2) :=
    (binaryLongDivision_widthWork _ _ hgpos).trans
      (Nat.mul_le_mul (Nat.mul_le_mul_left 8 hn) (by omega))
  have hbD : (binaryLongDivision D g.value).widthWork ≤ 8*L*(2*L+2) :=
    (binaryLongDivision_widthWork _ _ hgpos).trans
      (Nat.mul_le_mul (Nat.mul_le_mul_left 8 hd) (by omega))
  have hbG : g.widthWork ≤ 16*L^2*(2*L+2) := binaryGcd_widthWork _ _
  change g.widthWork+(binaryLongDivision z.natAbs g.value).widthWork+
      (binaryLongDivision D g.value).widthWork ≤ _
  change _ ≤ 16*L^2*(2*L+2)+16*L*(2*L+2)
  nlinarith

end Optss
