import Mathlib.Combinatorics.Pigeonhole
import Mathlib.Algebra.Group.Pointwise.Finset.Basic
import Mathlib.Tactic

/-!
# Large symmetric subsets of sets with small doubling

This is the exact double-counting argument in Bilu, Proposition 5.3, a
necessary input to his cube lemma and the refined dimension theorem.
Source: https://www.numdam.org/item/AST_1999__258__77_0.pdf (1999), p. 86.
The proof is valid in any additive commutative group; a center in a real
vector space is obtained by dividing the reflection parameter by two.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {G : Type*} [AddCommGroup G] [DecidableEq G]

def reflectionSlice (S : Finset G) (t : G) : Finset G :=
  S.filter (fun x => t - x ∈ S)

@[simp] theorem mem_reflectionSlice (S : Finset G) (t x : G) :
    x ∈ reflectionSlice S t ↔ x ∈ S ∧ t - x ∈ S := Finset.mem_filter

theorem reflectionSlice_subset (S : Finset G) (t : G) : reflectionSlice S t ⊆ S :=
  Finset.filter_subset _ _

theorem reflectionSlice_symmetric (S : Finset G) (t x : G)
    (hx : x ∈ reflectionSlice S t) : t - x ∈ reflectionSlice S t := by
  obtain ⟨hx, htx⟩ := (mem_reflectionSlice S t x).mp hx
  exact (mem_reflectionSlice S t _).mpr ⟨htx, by simpa using hx⟩

theorem reflectionSlice_card_fiber (S : Finset G) (t : G) :
    ((S ×ˢ S).filter (fun p => p.1 + p.2 = t)).card = (reflectionSlice S t).card := by
  apply Finset.card_bij (fun p _ => p.1)
  · intro p hp
    obtain ⟨hp, he⟩ := Finset.mem_filter.mp hp
    obtain ⟨hx, hy⟩ := Finset.mem_product.mp hp
    apply (mem_reflectionSlice S t _).mpr
    exact ⟨hx, by rw [← he]; simpa only [add_sub_cancel_left] using hy⟩
  · intro p hp q hq he
    apply Prod.ext he
    have hp' := (Finset.mem_filter.mp hp).2
    have hq' := (Finset.mem_filter.mp hq).2
    rw [he] at hp'
    exact add_left_cancel (hp'.trans hq'.symm)
  · intro x hx
    obtain ⟨hx, htx⟩ := (mem_reflectionSlice S t x).mp hx
    exact ⟨(x, t-x), Finset.mem_filter.mpr
      ⟨Finset.mem_product.mpr ⟨hx, htx⟩, by change x + (t-x) = t; abel⟩, rfl⟩

theorem sum_reflectionSlice_card (S : Finset G) :
    ∑ t ∈ S + S, (reflectionSlice S t).card = S.card * S.card := by
  have hh := Finset.card_eq_sum_card_fiberwise
    (s := S ×ˢ S) (t := S+S) (f := fun p => p.1+p.2)
    (fun p hp => Finset.add_mem_add (Finset.mem_product.mp hp).1 (Finset.mem_product.mp hp).2)
  simpa only [Finset.card_product, reflectionSlice_card_fiber] using hh.symm

/-- Exact integer averaging: at least one actual reflection slice has the
average representation count or more. -/
theorem exists_large_reflectionSlice (S : Finset G) (hS : S.Nonempty) :
    ∃ t ∈ S + S, S.card * S.card ≤ (S+S).card * (reflectionSlice S t).card := by
  have hSS : (S+S).Nonempty := hS.add hS
  obtain ⟨t, ht, hmax⟩ := Finset.exists_max_image (S+S)
    (fun t => (reflectionSlice S t).card) hSS
  refine ⟨t, ht, ?_⟩
  calc
    _ = ∑ u ∈ S+S, (reflectionSlice S u).card := (sum_reflectionSlice_card S).symm
    _ ≤ ∑ _u ∈ S+S, (reflectionSlice S t).card := Finset.sum_le_sum hmax
    _ = _ := by simp

/-- Bilu Proposition 5.3, with weak inequalities and the actual symmetric
subset explicitly constructed. The new doubling bound is also established. -/
theorem small_doubling_symmetric_subset (S : Finset G) (hS : S.Nonempty)
    (τ : ℝ) (hτ : 0 < τ) (hdoub : ((S+S).card : ℝ) ≤ τ * S.card) :
    ∃ t : G, ∃ T : Finset G, T ⊆ S ∧
      (∀ x ∈ T, t-x ∈ T) ∧ (S.card : ℝ) / τ ≤ T.card ∧
      ((T+T).card : ℝ) ≤ τ^2 * T.card := by
  obtain ⟨t, _, ht⟩ := exists_large_reflectionSlice S hS
  let T := reflectionSlice S t
  have hcard : (S.card : ℝ) ≤ τ * T.card := by
    have ht' : (S.card : ℝ) * S.card ≤ ((S+S).card : ℝ) * T.card := by exact_mod_cast ht
    have hSpos : (0 : ℝ) < S.card := by exact_mod_cast hS.card_pos
    have hmul := mul_le_mul_of_nonneg_right hdoub (Nat.cast_nonneg T.card : (0 : ℝ) ≤ T.card)
    nlinarith
  refine ⟨t, T, reflectionSlice_subset S t, reflectionSlice_symmetric S t,
    (div_le_iff₀ hτ).mpr (by simpa only [mul_comm] using hcard), ?_⟩
  have hsub : T+T ⊆ S+S := Finset.add_subset_add
    (reflectionSlice_subset S t) (reflectionSlice_subset S t)
  calc
    _ ≤ ((S+S).card : ℝ) := by exact_mod_cast Finset.card_le_card hsub
    _ ≤ τ * S.card := hdoub
    _ ≤ τ * (τ * T.card) := mul_le_mul_of_nonneg_left hcard hτ.le
    _ = _ := by ring

end
end Optss
