import Optss.ComputedShortKernel
import Optss.ProperizationQuotient

/-!
# Exact executable properness test and quotient-body accounting

The short-relation routine decides properness without an integer feasibility
oracle. If it returns a relation, its computed primitive quotient has a
section, preserves the encoded values, and satisfies the actual quotient-body
lattice-point bound used by Appendix B.2. Bit-cost assembly of the full rank
recursion is a separate stage.
-/
namespace Optss
open scoped BigOperators
variable {d : ℕ}

def progressionLinearEncoding (a : Fin d→ℤ) : (Fin d→ℤ) →ₗ[ℤ] ℤ where
  toFun z := ∑ j,a j*z j
  map_add' x y := by simp [mul_add,Finset.sum_add_distrib]
  map_smul' n x := by simp [Finset.mul_sum,mul_left_comm,mul_assoc]

def computedProgressionProper (a : Fin d→ℤ) (β : Fin d→ℕ) : Bool :=
  (computedShortKernelVector a (fun j => 2*β j)).isNone

theorem computedProgressionProper_correct (hd : 0<d) (a : Fin d→ℤ)
    (β : Fin d→ℕ) (hβ : ∀ j,0<β j) :
    computedProgressionProper a β=true ↔
      Set.InjOn (progressionLinearEncoding a) (integerBudgetBox β) := by
  classical
  have hs := computedShortKernelVector_complete hd a (fun j => 2*β j) (by intro j; exact Nat.mul_pos (by decide) (hβ j))
  have hp := integerBox_proper_iff_no_short_kernel (progressionLinearEncoding a).toAddMonoidHom β
  change Set.InjOn (progressionLinearEncoding a) (integerBudgetBox β) ↔
    ∀ z∈integerBudgetBox (fun j => 2*β j),(∑ j,a j*z j)=0 → z=0 at hp
  rw [hp]
  unfold computedProgressionProper
  rw [Option.isNone_iff_eq_none]
  constructor
  · intro hn z hz hker
    by_contra hzn
    exact (hs.mpr ⟨z,hz,hzn,hker⟩) hn
  · intro h
    by_contra hn
    obtain ⟨z,hz,hzn,hker⟩ := hs.mp hn
    exact hzn (h z hz hker)

theorem executableQuotient_box_representative (z : Fin (d+1)→ℤ) (hz : z≠0)
    (β : Fin (d+1)→ℕ) (t : ℕ) (hbound : z∈integerBudgetBox (fun j => 2*t*β j))
    (q : Fin d→ℤ)
    (hq : realVector q∈integerLinearImageBox (executablePrimitiveQuotient z) β) :
    ∃ x∈integerBudgetBox (fun j => (1+t)*β j),executablePrimitiveQuotient z x=q := by
  have hpbound : InBox (fun j => ((2*t*β j:ℕ):ℤ)) (executablePrimitiveDirection z) := by
    intro j
    exact (executablePrimitiveDirection_abs_le z hz j).trans ((mem_integerBudgetBox _ z).mp hbound j)
  obtain ⟨y,hy,hFy⟩ := hq
  apply quotient_integer_representative β t (executablePrimitiveDirection z) hpbound
    (executablePrimitiveQuotient z).toAddMonoidHom (integerMapRealExtension (executablePrimitiveQuotient z))
    (executablePrimitiveQuotient_surjective z)
    (fun x => (integerMapRealExtension_cast (executablePrimitiveQuotient z) x).symm)
    (executablePrimitiveQuotient_primitive z) ?_ q y ((mem_realCoefficientBox β y).mp hy) hFy
  intro x hx
  have hm : x∈Submodule.span ℝ {realVector (executablePrimitiveDirection z)} := by
    rw [←executablePrimitiveQuotient_real_ker z,LinearMap.mem_ker]
    exact hx
  obtain ⟨a,ha⟩ := Submodule.mem_span_singleton.mp hm
  exact ⟨a,ha.symm⟩

theorem executableQuotient_box_card (z : Fin (d+1)→ℤ) (hz : z≠0)
    (β : Fin (d+1)→ℕ) (t : ℕ) (hbound : z∈integerBudgetBox (fun j => 2*t*β j)) :
    (integerPoints (integerLinearImageBox (executablePrimitiveQuotient z) β)
      (integerLinearImageBox_compact _ β).isBounded).card≤
      (1+t)^(d+1)*(integerBudgetBox β).card := by
  classical
  have hsub : integerPoints (integerLinearImageBox (executablePrimitiveQuotient z) β)
      (integerLinearImageBox_compact _ β).isBounded ⊆
      (integerBudgetBox (fun j => (1+t)*β j)).image (executablePrimitiveQuotient z) := by
    intro q hq
    exact Finset.mem_image.mpr (executableQuotient_box_representative z hz β t hbound q
      ((mem_integerPoints _ _ q).mp hq))
  exact (Finset.card_le_card hsub).trans
    ((Finset.card_image_le).trans (integerBudgetBox_dilation_card_le β t))

/-- One actual detected relation supplies every algebraic and counting input
for the lower-dimensional call to the lattice-boxing routine. -/
theorem computedProperizationQuotient_spec (a : Fin (d+1)→ℤ)
    (β : Fin (d+1)→ℕ) (hβ : ∀ j,0<β j) (t : ℕ) (ht : 0<t)
    (z : Fin (d+1)→ℤ) (hz : computedShortKernelVector a (fun j => 2*t*β j)=some z) :
    z≠0 ∧ Function.Surjective (executablePrimitiveQuotient z) ∧
    (∀ x,executableDescendedHom z (progressionLinearEncoding a).toAddMonoidHom
      (executablePrimitiveQuotient z x)=progressionLinearEncoding a x) ∧
    (∃ u : Fin d→(Fin d→ℤ),LinearIndependent ℝ (fun j => realVector (u j)) ∧
      ∀ j,realVector (u j)∈integerLinearImageBox (executablePrimitiveQuotient z) β) ∧
    (integerPoints (integerLinearImageBox (executablePrimitiveQuotient z) β)
      (integerLinearImageBox_compact _ β).isBounded).card≤
      (1+t)^(d+1)*(integerBudgetBox β).card := by
  have hs := computedShortKernelVector_sound a (fun j => 2*t*β j) (by intro j; exact Nat.mul_pos (Nat.mul_pos (by decide) ht) (hβ j)) z hz
  refine ⟨hs.2.1,executablePrimitiveQuotient_surjective z,?_,?_,
    executableQuotient_box_card z hs.2.1 β t hs.1⟩
  · exact executableDescendedHom_quotient z hs.2.1 (progressionLinearEncoding a).toAddMonoidHom hs.2.2
  · exact integerLinearImageBox_independent (executablePrimitiveQuotient z)
      (executablePrimitiveQuotient_surjective z) β (fun j => hβ j)
end Optss
