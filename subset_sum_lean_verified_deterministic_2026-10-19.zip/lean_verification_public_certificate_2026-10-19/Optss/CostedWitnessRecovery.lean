import Optss.WitnessRecovery

/-!
# Charged decision-to-witness recovery

This is the same threshold-search recovery as `WitnessRecovery`, with the
work returned by every Boolean oracle call accumulated along the executed
path.  The projection theorem connects the charged run to the previously
verified value/call-count algorithm.
-/
namespace Optss

structure ChargedThresholdResult (α : Type) where
  value : α
  calls : ℕ
  work : ℕ

/-- Binary search whose oracle returns both its Boolean answer and its actual
work.  A singleton interval needs no call because its upper endpoint is
already known feasible by the correctness proof. -/
def thresholdSearchCharged (test : ℕ → Bool × ℕ) (lo width : ℕ) :
    ChargedThresholdResult ℕ :=
  if _hw : width = 0 then ⟨lo, 0, 0⟩
  else
    let q := test (lo + width / 2)
    if q.1 then
      let r := thresholdSearchCharged test lo (width / 2)
      ⟨r.value, r.calls + 1, r.work + q.2⟩
    else
      let r := thresholdSearchCharged test
        (lo + width / 2 + 1) (width - width / 2 - 1)
      ⟨r.value, r.calls + 1, r.work + q.2⟩
termination_by width
decreasing_by all_goals omega

theorem thresholdSearchCharged_projection (test : ℕ → Bool × ℕ)
    (lo width : ℕ) :
    (thresholdSearchCharged test lo width).value =
        (thresholdSearch (fun n => (test n).1) lo width).1 ∧
      (thresholdSearchCharged test lo width).calls =
        (thresholdSearch (fun n => (test n).1) lo width).2 := by
  induction width using Nat.strong_induction_on generalizing lo with
  | h width ih =>
    by_cases hw : width = 0
    · subst width
      simp [thresholdSearchCharged, thresholdSearch]
    · have hhalf : width / 2 < width := by omega
      have hright : width - width / 2 - 1 < width := by omega
      cases hq : (test (lo + width / 2)).1 with
      | false =>
          have hrec := ih _ hright (lo + width / 2 + 1)
          rw [thresholdSearchCharged, thresholdSearch, dif_neg hw]
          simp only [hw, hq, Bool.false_eq_true, ↓reduceIte]
          exact ⟨hrec.1, congrArg (fun n => n + 1) hrec.2⟩
      | true =>
          have hrec := ih _ hhalf lo
          rw [thresholdSearchCharged, thresholdSearch, dif_neg hw]
          simp only [hw, hq, ↓reduceIte]
          exact ⟨hrec.1, congrArg (fun n => n + 1) hrec.2⟩

theorem thresholdSearchCharged_work_le (test : ℕ → Bool × ℕ)
    (lo width W : ℕ) (hW : ∀ n, (test n).2 ≤ W) :
    (thresholdSearchCharged test lo width).work ≤
      (thresholdSearchCharged test lo width).calls * W := by
  induction width using Nat.strong_induction_on generalizing lo with
  | h width ih =>
    by_cases hw : width = 0
    · subst width
      simp [thresholdSearchCharged]
    · have hhalf : width / 2 < width := by omega
      have hright : width - width / 2 - 1 < width := by omega
      cases hq : (test (lo + width / 2)).1 with
      | false =>
          have hrec := ih _ hright (lo + width / 2 + 1)
          have hquery := hW (lo + width / 2)
          rw [thresholdSearchCharged, dif_neg hw]
          simp only [hq, Bool.false_eq_true, ↓reduceIte]
          nlinarith
      | true =>
          have hrec := ih _ hhalf lo
          have hquery := hW (lo + width / 2)
          rw [thresholdSearchCharged, dif_neg hw]
          simp only [hq, ↓reduceIte]
          nlinarith

/-- Integer-interval wrapper around the charged natural search. -/
def integerThresholdSearchCharged (test : ℤ → Bool × ℕ)
    (lower upper : ℤ) : ChargedThresholdResult ℤ :=
  let r := thresholdSearchCharged (fun n => test (lower + n)) 0
    (upper - lower).toNat
  ⟨lower + r.value, r.calls, r.work⟩

theorem integerThresholdSearchCharged_projection (test : ℤ → Bool × ℕ)
    (lower upper : ℤ) :
    (integerThresholdSearchCharged test lower upper).value =
        (integerThresholdSearch (fun z => (test z).1) lower upper).1 ∧
      (integerThresholdSearchCharged test lower upper).calls =
        (integerThresholdSearch (fun z => (test z).1) lower upper).2 := by
  have h := thresholdSearchCharged_projection
    (fun n => test (lower + n)) 0 (upper - lower).toNat
  exact ⟨congrArg (fun n : ℕ => lower + (n : ℤ)) h.1, h.2⟩

theorem integerThresholdSearchCharged_work_le (test : ℤ → Bool × ℕ)
    (lower upper : ℤ) (W : ℕ) (hW : ∀ z, (test z).2 ≤ W) :
    (integerThresholdSearchCharged test lower upper).work ≤
      (integerThresholdSearchCharged test lower upper).calls * W := by
  exact thresholdSearchCharged_work_le (fun n => test (lower + n)) 0
    (upper - lower).toNat W (fun n => hW (lower + n))

structure ChargedBoxResult (n : ℕ) where
  point : Fin n → ℤ
  calls : ℕ
  work : ℕ

/-- Coordinate recovery with the work of every actually executed oracle call
summed into `work`. -/
def recoverBoxCharged : (n : ℕ) →
    ((Fin n → ℤ) → (Fin n → ℤ) → Bool × ℕ) →
    (Fin n → ℤ) → (Fin n → ℤ) → ChargedBoxResult n
  | 0, _, _, _ => ⟨Fin.elim0, 0, 0⟩
  | n + 1, oracle, l, u =>
      let head := integerThresholdSearchCharged
        (fun a => oracle l (Fin.cons a (Fin.tail u))) (l 0) (u 0)
      let tailOracle := fun l' u' =>
        oracle (Fin.cons head.value l') (Fin.cons head.value u')
      let tail := recoverBoxCharged n tailOracle (Fin.tail l) (Fin.tail u)
      ⟨Fin.cons head.value tail.point, head.calls + tail.calls,
        head.work + tail.work⟩

theorem recoverBoxCharged_projection : ∀ (n : ℕ)
    (oracle : (Fin n → ℤ) → (Fin n → ℤ) → Bool × ℕ)
    (l u : Fin n → ℤ),
    (recoverBoxCharged n oracle l u).point =
        (recoverBox n (fun l u => (oracle l u).1) l u).1 ∧
      (recoverBoxCharged n oracle l u).calls =
        (recoverBox n (fun l u => (oracle l u).1) l u).2 := by
  intro n
  induction n with
  | zero =>
      intro oracle l u
      simp [recoverBoxCharged, recoverBox]
  | succ n ih =>
      intro oracle l u
      let chargedHead := integerThresholdSearchCharged
        (fun a => oracle l (Fin.cons a (Fin.tail u))) (l 0) (u 0)
      let plainHead := integerThresholdSearch
        (headThresholdOracle (fun l u => (oracle l u).1) l u) (l 0) (u 0)
      have hhead := integerThresholdSearchCharged_projection
        (fun a => oracle l (Fin.cons a (Fin.tail u))) (l 0) (u 0)
      change chargedHead.value = plainHead.1 ∧ chargedHead.calls = plainHead.2 at hhead
      have htail := ih
        (fun l' u' => oracle (Fin.cons plainHead.1 l')
          (Fin.cons plainHead.1 u')) (Fin.tail l) (Fin.tail u)
      simp only [recoverBoxCharged, recoverBox]
      simp only [chargedHead, plainHead, headThresholdOracle,
        hhead.1, hhead.2, htail.1, htail.2]
      constructor <;> trivial

theorem recoverBoxCharged_work_le : ∀ (n : ℕ)
    (oracle : (Fin n → ℤ) → (Fin n → ℤ) → Bool × ℕ)
    (l u : Fin n → ℤ) (W : ℕ)
    (_hW : ∀ l u, (oracle l u).2 ≤ W),
    (recoverBoxCharged n oracle l u).work ≤
      (recoverBoxCharged n oracle l u).calls * W := by
  intro n
  induction n with
  | zero =>
      intro oracle l u W hW
      simp [recoverBoxCharged]
  | succ n ih =>
      intro oracle l u W hW
      let head := integerThresholdSearchCharged
        (fun a => oracle l (Fin.cons a (Fin.tail u))) (l 0) (u 0)
      let tailOracle := fun l' u' =>
        oracle (Fin.cons head.value l') (Fin.cons head.value u')
      have hh : head.work ≤ head.calls * W := by
        exact integerThresholdSearchCharged_work_le
          (fun z => oracle l (Fin.cons z (Fin.tail u))) (l 0) (u 0) W
          (fun z => hW _ _)
      have ht := ih tailOracle (Fin.tail l) (Fin.tail u) W
        (fun l' u' => hW _ _)
      change head.work +
          (recoverBoxCharged n tailOracle (Fin.tail l) (Fin.tail u)).work ≤
        (head.calls +
          (recoverBoxCharged n tailOracle (Fin.tail l) (Fin.tail u)).calls) * W
      nlinarith

structure ChargedCheckedBoxResult (n : ℕ) where
  point : Option (Fin n → ℤ)
  calls : ℕ
  work : ℕ

/-- Add the initial feasibility call and retain the exact sum of all oracle
work along the recovery path. -/
def recoverBoxWithCheckCharged (n : ℕ)
    (oracle : (Fin n → ℤ) → (Fin n → ℤ) → Bool × ℕ)
    (l u : Fin n → ℤ) : ChargedCheckedBoxResult n :=
  let first := oracle l u
  if first.1 then
    let r := recoverBoxCharged n oracle l u
    ⟨some r.point, r.calls + 1, r.work + first.2⟩
  else
    ⟨none, 1, first.2⟩

theorem recoverBoxWithCheckCharged_projection (n : ℕ)
    (oracle : (Fin n → ℤ) → (Fin n → ℤ) → Bool × ℕ)
    (l u : Fin n → ℤ) :
    (recoverBoxWithCheckCharged n oracle l u).point =
        (recoverBoxWithCheck n (fun l u => (oracle l u).1) l u).1 ∧
      (recoverBoxWithCheckCharged n oracle l u).calls =
        (recoverBoxWithCheck n (fun l u => (oracle l u).1) l u).2 := by
  have hr := recoverBoxCharged_projection n oracle l u
  unfold recoverBoxWithCheckCharged recoverBoxWithCheck
  split <;> simp_all

theorem recoverBoxWithCheckCharged_work_le (n : ℕ)
    (oracle : (Fin n → ℤ) → (Fin n → ℤ) → Bool × ℕ)
    (l u : Fin n → ℤ) (W : ℕ) (hW : ∀ l u, (oracle l u).2 ≤ W) :
    (recoverBoxWithCheckCharged n oracle l u).work ≤
      (recoverBoxWithCheckCharged n oracle l u).calls * W := by
  have hr := recoverBoxCharged_work_le n oracle l u W hW
  have hf := hW l u
  by_cases hfirst : (oracle l u).1 = true
  · simp only [recoverBoxWithCheckCharged, hfirst, ↓reduceIte]
    calc
      (recoverBoxCharged n oracle l u).work + (oracle l u).2 ≤
          (recoverBoxCharged n oracle l u).calls * W + W :=
        Nat.add_le_add hr hf
      _ = ((recoverBoxCharged n oracle l u).calls + 1) * W := by ring
  · simp only [recoverBoxWithCheckCharged, hfirst, Bool.false_eq_true, ↓reduceIte]
    simpa only [one_mul] using hf

/-- Semantic correctness inherited from the uncharged recovery, plus a bound
on the literal accumulated oracle work. -/
theorem recoverBoxWithCheckCharged_correct {n : ℕ}
    (P : (Fin n → ℤ) → Prop)
    (oracle : (Fin n → ℤ) → (Fin n → ℤ) → Bool × ℕ)
    (horacle : ∀ l u, (oracle l u).1 = true ↔ BoxFeasible P l u)
    (l u : Fin n → ℤ) (W : ℕ) (hW : ∀ l u, (oracle l u).2 ≤ W) :
    ((recoverBoxWithCheckCharged n oracle l u).point = none ↔
      ¬BoxFeasible P l u) ∧
    (∀ x, (recoverBoxWithCheckCharged n oracle l u).point = some x →
      (∀ i, l i ≤ x i ∧ x i ≤ u i) ∧ P x) ∧
    (recoverBoxWithCheckCharged n oracle l u).calls ≤
      1 + ∑ i, (u i - l i).toNat.size ∧
    (recoverBoxWithCheckCharged n oracle l u).work ≤
      (1 + ∑ i, (u i - l i).toNat.size) * W := by
  have hp := recoverBoxWithCheckCharged_projection n oracle l u
  have hc := recoverBoxWithCheck_correct P (fun l u => (oracle l u).1)
    horacle l u
  have hw := recoverBoxWithCheckCharged_work_le n oracle l u W hW
  rw [hp.2] at hw
  rw [hp.1, hp.2]
  refine ⟨hc.1, hc.2.1, hc.2.2, ?_⟩
  exact hw.trans (Nat.mul_le_mul_right W hc.2.2)

end Optss

