import Optss.ListChirpPreparation

/-! Structural padding and prefix removal for the stored Bluestein pipeline.
Neither answer routine decodes a magnitude or uses random-access indexing. -/
namespace Optss

def fourierListPad {α : Type*} (z : α) : List Bool → List α → List α
  | [],_ => []
  | _::fuel,[] => z::fourierListPad z fuel []
  | _::fuel,x::xs => x::fourierListPad z fuel xs

def fourierListDrop {α : Type*} : List Bool → List α → List α
  | [],xs => xs
  | _::_,[] => []
  | _::fuel,_::xs => fourierListDrop fuel xs

theorem fourierListPad_length {α : Type*} (z : α) (fuel : List Bool) (xs : List α) :
    (fourierListPad z fuel xs).length=fuel.length := by
  induction fuel generalizing xs with
  | nil => rfl
  | cons b fuel ih => cases xs <;> simp only [fourierListPad,List.length_cons,ih]

theorem fourierListPad_get {α : Type*} (z : α) (fuel : List Bool) (xs : List α)
    (i : ℕ) (hi : i<fuel.length) :
    (fourierListPad z fuel xs)[i]'(by rw [fourierListPad_length]; exact hi)=xs[i]?.getD z := by
  induction fuel generalizing xs i with
  | nil => simp only [List.length_nil] at hi; omega
  | cons b fuel ih =>
    cases xs with
    | nil =>
      cases i with
      | zero => rfl
      | succ i => exact ih [] i (by simpa only [List.length_cons,Nat.succ_lt_succ_iff] using hi)
    | cons x xs =>
      cases i with
      | zero => rfl
      | succ i => exact ih xs i (by simpa only [List.length_cons,Nat.succ_lt_succ_iff] using hi)

theorem fourierListPad_map {α β : Type*} (f : α → β) (z : α) (fuel : List Bool) (xs : List α) :
    (fourierListPad z fuel xs).map f=fourierListPad (f z) fuel (xs.map f) := by
  induction fuel generalizing xs with
  | nil => rfl
  | cons b fuel ih => cases xs <;> simp only [fourierListPad,List.map_nil,List.map_cons,ih]

theorem fourierListPad_ofFn {α : Type*} {m : ℕ} (z : α) (fuel : List Bool) (f : Fin m → α) :
    fourierListPad z fuel (List.ofFn f)=List.ofFn (fun i : Fin fuel.length =>
      if h : i.val < m then f ⟨i.val,h⟩ else z) := by
  apply List.ext_getElem
  · simp only [fourierListPad_length,List.length_ofFn]
  · intro i hi hi'
    have hil : i<fuel.length := by simpa only [List.length_ofFn] using hi'
    rw [fourierListPad_get _ _ _ _ hil,List.getElem_ofFn,List.getElem?_ofFn]
    by_cases him : i < m <;> simp only [him,↓reduceDIte,Option.getD_some,Option.getD_none]

theorem fourierListDrop_eq {α : Type*} (fuel : List Bool) (xs : List α) :
    fourierListDrop fuel xs=xs.drop fuel.length := by
  induction fuel generalizing xs with
  | nil => rfl
  | cons b fuel ih => cases xs <;> simp only [fourierListDrop,List.drop_nil,List.length_cons,List.drop_succ_cons,ih]

theorem fourierListDrop_map {α β : Type*} (f : α → β) (fuel : List Bool) (xs : List α) :
    (fourierListDrop fuel xs).map f=fourierListDrop fuel (xs.map f) := by
  simp only [fourierListDrop_eq,List.map_drop]

end Optss
