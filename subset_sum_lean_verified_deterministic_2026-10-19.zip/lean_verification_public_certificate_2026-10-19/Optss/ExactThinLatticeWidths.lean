import Optss.ThinLatticeBoxing
import Optss.ExactLatticeBoxingWidths

/-! Exact zero-allowing widths for constructive inner lattice boxing. -/
namespace Optss
noncomputable section
open scoped BigOperators Pointwise
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [FiniteDimensional ℝ E] {r : ℕ}

theorem normalized_thin_lattice_boxing_exact_widths (hr : 0<r)
    (K : Set (EuclideanSpace ℝ (Fin r))) (hK : IsCompact K) (hne : K.Nonempty)
    (hinner : euclideanCoordinateCube r (1/(r : ℝ))⊆K)
    (houter : K⊆euclideanCoordinateCube r 1)
    (b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)))
    (ω : ℝ) (hω : 0<ω) (hdual : BasisDualNormBound b ω) :
    let n := basisFloorWidth b K hK hne
    (∀ x∈K, x∈basisIntegerLattice b → x∈basisCoefficientBox b n) ∧
      basisCoefficientBox b n⊆latticeBoxingDilation r ω • K := by
  have hrR : (0 : ℝ)<r := by exact_mod_cast hr
  have hsqrt : 0<Real.sqrt (r : ℝ) := Real.sqrt_pos.mpr hrR
  let n := basisFloorWidth b K hK hne
  have hn (j : Fin r) : (n j : ℝ)*‖b j‖≤2*ω*Real.sqrt r := by
    have h := basisFloorWidth_mul_norm_le b K hK hne ω (Real.sqrt r) hω.le hdual
      (fun y hy => norm_le_sqrt_dimension_of_cube (houter hy)) j
    change (n j : ℝ)*‖b j‖≤ω*Real.sqrt r at h
    nlinarith
  refine ⟨fun _ hx hΛ => lattice_points_subset_floor_box b K hK hne hx hΛ,?_⟩
  intro z hz
  have hzNorm := basisCoefficientBox_norm_le b n (2*ω*Real.sqrt r) hn hz
  let J := latticeBoxingDilation r ω
  have hJ : 0<J := by dsimp [J,latticeBoxingDilation]; positivity
  have hscaled : ‖J⁻¹ • z‖≤1/(r : ℝ) := by
    rw [norm_smul,Real.norm_of_nonneg (inv_nonneg.mpr hJ.le)]
    calc
      J⁻¹*‖z‖≤J⁻¹*((r : ℝ)*(2*ω*Real.sqrt r)) :=
        mul_le_mul_of_nonneg_left hzNorm (inv_nonneg.mpr hJ.le)
      _ = _ := by
        dsimp [J,latticeBoxingDilation]
        field_simp [ne_of_gt hrR,ne_of_gt hsqrt,ne_of_gt hω]
        ring
  refine ⟨J⁻¹ • z,hinner (mem_cube_of_norm_le hscaled),?_⟩
  change J • (J⁻¹ • z)=z
  rw [smul_smul,mul_inv_cancel₀ (ne_of_gt hJ),one_smul]

theorem basisFloorWidth_map
    {F : Type*} [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]
    (b : Basis (Fin r) ℝ E) (f : E ≃ₗ[ℝ] F)
    (K : Set E) (hK : IsCompact K) (hne : K.Nonempty)
    (hF : IsCompact (f '' K)) (hneF : (f '' K).Nonempty) :
    basisFloorWidth (b.map f) (f '' K) hF hneF=basisFloorWidth b K hK hne := by
  funext j
  unfold basisFloorWidth
  rw [basisCoordinateRadius_map b f K hK hne hF hneF j]

theorem thin_lattice_boxing_exact_widths_of_normalization
    (hr : 0<r) (K : Set E) (hK : IsCompact K) (hne : K.Nonempty)
    (e : E ≃L[ℝ] EuclideanSpace ℝ (Fin r))
    (hinner : euclideanCoordinateCube r (1/(r : ℝ))⊆e '' K)
    (houter : e '' K⊆euclideanCoordinateCube r 1)
    (b : Basis (Fin r) ℝ E) (ω : ℝ) (hω : 0<ω)
    (hdefect : euclideanOrthogonalityDefect (b.map e.toLinearEquiv)≤ω) :
    let n := basisFloorWidth b K hK hne
    (∀ x∈K, x∈basisIntegerLattice b → x∈basisCoefficientBox b n) ∧
      basisCoefficientBox b n⊆latticeBoxingDilation r ((r.factorial : ℝ)*ω) • K := by
  have hKF := hK.image e.continuous
  have hneF := hne.image e
  have h := normalized_thin_lattice_boxing_exact_widths hr (e '' K) hKF hneF
    hinner houter (b.map e.toLinearEquiv) ((r.factorial : ℝ)*ω)
    (mul_pos (by exact_mod_cast Nat.factorial_pos r) hω)
    (basisDualNormBound_of_orthogonalityDefect _ ω hdefect)
  dsimp only at h
  have hw : basisFloorWidth (b.map e.toLinearEquiv) (e '' K) hKF hneF=
      basisFloorWidth b K hK hne := basisFloorWidth_map b e.toLinearEquiv K hK hne hKF hneF
  rw [hw] at h
  let n := basisFloorWidth b K hK hne
  refine ⟨?_,?_⟩
  · intro y hy hΛ
    have hΛ' : e y∈basisIntegerLattice (b.map e.toLinearEquiv) := by
      rw [basisIntegerLattice_map]
      exact ⟨y,hΛ,rfl⟩
    have hh := h.1 (e y) ⟨y,hy,rfl⟩ hΛ'
    rw [basisCoefficientBox_map] at hh
    obtain ⟨z,hz,he⟩ := hh
    exact e.injective he ▸ hz
  · intro y hy
    have hy' : e y∈basisCoefficientBox (b.map e.toLinearEquiv) n := by
      rw [basisCoefficientBox_map]
      exact ⟨y,hy,rfl⟩
    obtain ⟨u,⟨z,hz,rfl⟩,he⟩ := h.2 hy'
    refine ⟨z,hz,e.injective ?_⟩
    simpa only [map_smul] using he
end
end Optss
