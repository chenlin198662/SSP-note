import Optss.FreimanConcentration

/-!
# Genuine generic projections for finitely many subspaces

Successively choose linear forms which are nonzero on every nonzero
residual subspace. Each step decreases each residual dimension by one
until it reaches zero. Thus the resulting projection to `ℝ^r` has the
maximal possible rank on every member of an actual finite family.
This discharges the generic-position choice in Bilu Theorem 5.6.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 1000000
variable {E : Type*} [AddCommGroup E] [Module ℝ E]

/-- A single actual functional is nonzero on every nonzero member of a
specified finite family of subspaces. -/
theorem finite_subspaces_detecting_form (A : Finset (Submodule ℝ E)) :
    ∃ f : E →ₗ[ℝ] ℝ, ∀ L ∈ A, L ≠ ⊥ → ∃ x ∈ L, f x ≠ 0 := by
  have hw : ∀ L : Submodule ℝ E, ∃ x : E, L ≠ ⊥ → x ∈ L ∧ x ≠ 0 := by
    intro L
    by_cases hL : L = ⊥
    · exact ⟨0, fun h => False.elim (h hL)⟩
    · obtain ⟨x, hxL, hx0⟩ := (Submodule.ne_bot_iff L).mp hL
      exact ⟨x, fun _ => ⟨hxL, hx0⟩⟩
  choose w hw using hw
  obtain ⟨f, _, hf⟩ := finite_avoidance_linear_form (⊥ : Submodule ℝ E) (A.image w)
  refine ⟨f, ?_⟩
  intro L hL hL0
  exact ⟨w L, (hw L hL0).1, hf _ (Finset.mem_image.mpr ⟨L, hL, rfl⟩)
    (by simpa only [Submodule.mem_bot] using (hw L hL0).2)⟩

/-- Restriction rank-nullity, with both spaces represented in the ambient
space rather than as nested subtype kernels. -/
theorem finrank_map_add_inf_ker [FiniteDimensional ℝ E]
    {F : Type*} [AddCommGroup F] [Module ℝ F] (f : E →ₗ[ℝ] F) (L : Submodule ℝ E) :
    Module.finrank ℝ (L.map f) + Module.finrank ℝ ↥(L ⊓ LinearMap.ker f) = Module.finrank ℝ L := by
  have hh := (f.comp L.subtype).finrank_range_add_finrank_ker
  have hr : LinearMap.range (f.comp L.subtype) = L.map f := by
    rw [LinearMap.range_comp, Submodule.range_subtype]
  have hk : Module.finrank ℝ (LinearMap.ker (f.comp L.subtype)) =
      Module.finrank ℝ ↥(L ⊓ LinearMap.ker f) := by
    rw [LinearMap.ker_comp]
    rw [← Submodule.finrank_map_subtype_eq L (Submodule.comap L.subtype (LinearMap.ker f)),
      Submodule.map_comap_subtype]
  rw [← hr, ← hk]
  exact hh

theorem finrank_inf_kernel_drop [FiniteDimensional ℝ E]
    (L : Submodule ℝ E) (f : E →ₗ[ℝ] ℝ) (hf : ∃ x ∈ L, f x ≠ 0) :
    Module.finrank ℝ ↥(L ⊓ LinearMap.ker f) + 1 = Module.finrank ℝ L := by
  have hr : L.map f = ⊤ := by
    obtain ⟨x, hx, hfx⟩ := hf
    apply top_unique
    intro y _
    refine Submodule.mem_map.mpr ⟨(y/f x) • x, L.smul_mem _ hx, ?_⟩
    simp only [map_smul, smul_eq_mul]
    exact div_mul_cancel₀ y hfx
  have hh := finrank_map_add_inf_ker f L
  rw [hr, finrank_top, Module.finrank_self] at hh
  omega

def linearMapCons {r : ℕ} (f : E →ₗ[ℝ] ℝ) (g : E →ₗ[ℝ] (Fin r → ℝ)) :
    E →ₗ[ℝ] (Fin (r+1) → ℝ) where
  toFun x := Fin.cons (f x) (g x)
  map_add' x y := by ext i; refine Fin.cases ?_ (fun j => ?_) i <;> simp
  map_smul' a x := by ext i; refine Fin.cases ?_ (fun j => ?_) i <;> simp

theorem linearMapCons_ker {r : ℕ} (f : E →ₗ[ℝ] ℝ) (g : E →ₗ[ℝ] (Fin r → ℝ)) :
    LinearMap.ker (linearMapCons f g) = LinearMap.ker g ⊓ LinearMap.ker f := by
  ext x
  change ((Fin.cons (f x) (g x) : Fin (r+1) → ℝ) = 0) ↔ (g x = 0 ∧ f x = 0)
  constructor
  · intro h
    refine ⟨?_, congrFun h 0⟩
    funext j
    exact congrFun h j.succ
  · rintro ⟨hg, hf⟩
    funext j
    exact Fin.cases hf (fun i => congrFun hg i) j

/-- The kernel has the smallest dimension allowed by rank-nullity on
all subspaces in the finite family simultaneously. -/
theorem exists_finite_generic_kernel [FiniteDimensional ℝ E]
    (A : Finset (Submodule ℝ E)) (r : ℕ) :
    ∃ f : E →ₗ[ℝ] (Fin r → ℝ), ∀ L ∈ A,
      Module.finrank ℝ ↥(L ⊓ LinearMap.ker f) = Module.finrank ℝ L-r := by
  induction r with
  | zero =>
    refine ⟨0, ?_⟩
    intro L _
    rw [LinearMap.ker_zero, inf_top_eq, Nat.sub_zero]
  | succ r ih =>
    obtain ⟨g, hg⟩ := ih
    obtain ⟨f, hf⟩ := finite_subspaces_detecting_form
      (A.image (fun L => L ⊓ LinearMap.ker g))
    refine ⟨linearMapCons f g, ?_⟩
    intro L hL
    rw [linearMapCons_ker, ← inf_assoc]
    by_cases hK : L ⊓ LinearMap.ker g = ⊥
    · have hh := hg L hL
      rw [hK, finrank_bot] at hh
      rw [hK, bot_inf_eq, finrank_bot]
      omega
    · have hh := finrank_inf_kernel_drop (L ⊓ LinearMap.ker g) f
        (hf _ (Finset.mem_image.mpr ⟨L, hL, rfl⟩) hK)
      rw [hg L hL] at hh
      omega

/-- Maximal image rank on every member of the given finite family. -/
theorem exists_finite_generic_projection [FiniteDimensional ℝ E]
    (A : Finset (Submodule ℝ E)) (r : ℕ) :
    ∃ f : E →ₗ[ℝ] (Fin r → ℝ), ∀ L ∈ A,
      Module.finrank ℝ (L.map f) = min r (Module.finrank ℝ L) := by
  obtain ⟨f, hf⟩ := exists_finite_generic_kernel A r
  refine ⟨f, ?_⟩
  intro L hL
  have hh := finrank_map_add_inf_ker f L
  rw [hf L hL] at hh
  omega

def differenceSpanFamily (S : Finset E) : Finset (Submodule ℝ E) :=
  (S-S).powerset.image (fun T : Finset E => Submodule.span ℝ (T : Set E))

theorem differenceSpanFamily_mem (S T : Finset E) (hTS : T ⊆ S) :
    Submodule.span ℝ ((T-T : Finset E) : Set E) ∈ differenceSpanFamily S := by
  exact Finset.mem_image.mpr ⟨T-T, Finset.mem_powerset.mpr (Finset.sub_subset_sub hTS hTS), rfl⟩

/-- A projection which is injective on the input and preserves all
relevant affine dimensions up to the target dimension. -/
theorem finite_set_generic_projection [FiniteDimensional ℝ E]
    (S : Finset E) (r : ℕ) (hr : 0 < r) :
    ∃ f : E →ₗ[ℝ] (Fin r → ℝ), Set.InjOn f (S : Set E) ∧
      ∀ T ⊆ S, Module.finrank ℝ ((Submodule.span ℝ ((T-T : Finset E) : Set E)).map f) =
        min r (Module.finrank ℝ (Submodule.span ℝ ((T-T : Finset E) : Set E))) := by
  obtain ⟨f, hf⟩ := exists_finite_generic_projection (differenceSpanFamily S) r
  refine ⟨f, ?_, fun T hT => hf _ (differenceSpanFamily_mem S T hT)⟩
  intro x hx y hy hxy
  by_contra hn
  have hz : x-y ≠ 0 := sub_ne_zero.mpr hn
  let L := Submodule.span ℝ ({x-y} : Set E)
  have hL : L ∈ differenceSpanFamily S := by
    apply Finset.mem_image.mpr
    refine ⟨{x-y}, Finset.mem_powerset.mpr ?_, ?_⟩
    · intro z hz'
      have he : z = x-y := Finset.mem_singleton.mp hz'
      rw [he]
      exact Finset.sub_mem_sub hx hy
    · simp only [Finset.coe_singleton, L]
  have hdim := hf L hL
  have hLdim : Module.finrank ℝ L = 1 := finrank_span_singleton hz
  have hLmap : L.map f = ⊥ := by
    apply bot_unique
    apply Submodule.map_le_iff_le_comap.mpr
    apply Submodule.span_le.mpr
    intro z hz'
    have he : z = x-y := Set.mem_singleton_iff.mp hz'
    rw [he]
    change f (x-y) = 0
    rw [map_sub, hxy, sub_self]
  rw [hLmap, finrank_bot, hLdim] at hdim
  omega

end
end Optss
