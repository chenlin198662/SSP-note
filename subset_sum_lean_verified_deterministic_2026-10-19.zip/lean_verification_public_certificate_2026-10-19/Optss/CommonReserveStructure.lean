import Optss.CommonLatticeCoordinates

/-!
# Reserve and remainder in the same complete lattice

The union of a consecutive block window leaves exactly the endpoint remainder.
A constant-lattice window therefore makes both retained parts generate the
same whole subgroup. The initial rank certificate also survives further
bounded deletions from the remainder.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1000000
namespace BoundedBlockSelector
variable {ι : Type} [DecidableEq ι] {d : ℕ} {v : ι → IntVec d}
  {initial : Finset ι} {B : ℕ}

theorem reserve_succ (F : BoundedBlockSelector v initial B) (start ℓ : ℕ) :
    F.reserve start (ℓ+1) = F.reserve start ℓ ∪ (F.block (start+ℓ)).chosen := by
  rw [reserve, Finset.range_succ, Finset.biUnion_insert]
  exact Finset.union_comm _ _

/-- The actual endpoint remainder is exactly the starting labels minus the
union of the intervening actual blocks. -/
theorem remaining_after_reserve (F : BoundedBlockSelector v initial B) (start ℓ : ℕ) :
    F.remaining (start+ℓ) = F.remaining start \ F.reserve start ℓ := by
  induction ℓ with
  | zero => simp [reserve]
  | succ ℓ ih =>
    rw [Nat.add_succ, F.remaining_step, ih, F.reserve_succ]
    ext i
    simp [Finset.mem_sdiff, Finset.mem_union, and_assoc]

/-- One generating block already ensures that the whole reserve generates
the common lattice; the reverse inclusion follows from its actual labels. -/
theorem reserve_generated (F : BoundedBlockSelector v initial B) (start ℓ : ℕ)
    (hℓ : 0 < ℓ)
    (hgen : AddSubgroup.closure ((F.block start).sums : Set (IntVec d)) = generatedLattice v (F.remaining start)) :
    generatedLattice v (F.reserve start ℓ) = generatedLattice v (F.remaining start) := by
  apply le_antisymm (generatedLattice_mono v (F.reserve_subset start ℓ))
  have hv := (F.valid _ (F.remaining_subset start)).2
  change (F.block start).sums = labelledSubsetSupport v (F.block start).chosen at hv
  rw [← hgen, hv, labelledSubsetSupport_generated]
  apply generatedLattice_mono
  intro i hi
  apply Finset.mem_biUnion.mpr
  exact ⟨0, Finset.mem_range.mpr hℓ, by simpa only [Nat.add_zero] using hi⟩

/-- Protected rank survives every further bounded deletion, in addition to
all actual earlier block removals. -/
theorem remaining_protected (F : BoundedBlockSelector v initial B) (n extra k : ℕ)
    (hbudget : n*B+extra ≤ k)
    (hprotected : ∀ deleted : Finset ι, deleted.card ≤ k →
      labelSpan ℝ (fun i => realVector (v i)) (initial \ deleted) = ⊤) :
    ∀ D : Finset ι, D.card ≤ extra →
      labelSpan ℝ (fun i => realVector (v i)) (F.remaining n \ D) = ⊤ := by
  intro D hD
  have hcard : ((initial \ F.remaining n) ∪ D).card ≤ k :=
    (Finset.card_union_le _ _).trans ((Nat.add_le_add (F.deleted_card_le n) hD).trans hbudget)
  have he : initial \ ((initial \ F.remaining n) ∪ D) = F.remaining n \ D := by
    ext i
    have hs : i ∈ F.remaining n → i ∈ initial := fun hi => F.remaining_subset n hi
    simp only [Finset.mem_sdiff, Finset.mem_union]
    tauto
  simpa only [he] using hprotected ((initial \ F.remaining n) ∪ D) hcard

/-- Both retained parts of a nonempty constant-lattice window generate the
entire same subgroup before any further deletions. -/
theorem reserve_remainder_same_lattice (F : BoundedBlockSelector v initial B) (start ℓ : ℕ)
    (hℓ : 0 < ℓ)
    (hgen : AddSubgroup.closure ((F.block start).sums : Set (IntVec d)) = generatedLattice v (F.remaining start))
    (hend : generatedLattice v (F.remaining (start+ℓ)) = generatedLattice v (F.remaining start)) :
    generatedLattice v (F.reserve start ℓ) = generatedLattice v (F.remaining start) ∧
      generatedLattice v (F.remaining start \ F.reserve start ℓ) = generatedLattice v (F.remaining start) ∧
      Disjoint (F.reserve start ℓ) (F.remaining start \ F.reserve start ℓ) := by
  refine ⟨F.reserve_generated start ℓ hℓ hgen, ?_, Finset.disjoint_sdiff⟩
  rw [← F.remaining_after_reserve]
  exact hend

end BoundedBlockSelector
end
end Optss
