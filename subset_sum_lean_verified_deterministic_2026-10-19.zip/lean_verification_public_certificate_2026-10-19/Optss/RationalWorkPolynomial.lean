import Optss.EncodedRationalScalarWork
import Mathlib.Algebra.Polynomial.Eval.Defs

/-!
# One explicit polynomial for all encoded rational scalar work

The previous dimension/bit-width formulas are bounded by evaluation of a
single polynomial with natural coefficients. This makes polynomial growth
literal rather than an informal description of the arithmetic expressions.
Storage-control costs remain a separate component.
-/

namespace Optss

/-- A deliberately generous dimension-independent scalar-work polynomial. -/
noncomputable def rationalScalarPolynomial : Polynomial ℕ :=
  let X := Polynomial.X
  let C := (X*X+1)*X+1
  let B := X*X*((X*X+1)*X+2)
  let F := 3*(X*(X+1)+1)*(X+X+2*(B+1)+4)
  let V := 3*(C+1)+5*X+2*X+8*(X*(X+1)+1)*(X+X+2*(C+1)+4)+12
  let O := (X*(X+1)+1)*(X+X+2*((X*X+1)*X+2)+4)+X*X*X+1
  105*(X*X)*((X*X+1)*(X+1)+1)^2+1+
    (F+1)*(32*(X+1)^4*(X+1))*(65536*(8*(2*(X+X)+10)*(2*X+4)*V+1)^3)+
    X*X*(128*(O+1)^3)

theorem rationalEncodedScalarBound_le_polynomial (r d L N : ℕ)
    (hr : r ≤ N) (hd : d ≤ N) (hL : L ≤ N) :
    rationalEncodedScalarBound r d L ≤ rationalScalarPolynomial.eval N := by
  have hrs : r.size ≤ N := (Nat.size_le.mpr Nat.lt_two_pow_self).trans hr
  have hds : d.size ≤ N := (Nat.size_le.mpr Nat.lt_two_pow_self).trans hd
  unfold rationalScalarPolynomial
  simp only [Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_pow,
    Polynomial.eval_X, Polynomial.eval_one, Polynomial.eval_ofNat]
  unfold rationalEncodedScalarBound rationalEncodedLoopBound bitLengthReductionFuel
    rationalClearedArithmeticBits rationalOutputUnscaleBits
  dsimp only
  gcongr

theorem encodedRationalScalarWork_polynomial {r d : ℕ} (A : BitRationalMatrixData r d)
    (hWF : ∀ i j, ((A.get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows A i j:ℝ)))
    (L : ℕ) (hL : ∀ i j, ((A.get i).get j).numerator.length ≤ L ∧
      ((A.get i).get j).denominator.length ≤ L) :
    encodedRationalScalarWork A ≤ rationalScalarPolynomial.eval (r+d+L+1) :=
  (encodedRationalScalarWork_bound A hWF hA L hL).trans
    (rationalEncodedScalarBound_le_polynomial r d L (r+d+L+1) (by omega) (by omega) (by omega))

/-- Literal encoded input size: one sign slot plus both magnitude lists per
matrix entry. Dimensions are fixed by the typed matrix representation. -/
def bitRationalMatrixSize {r d : ℕ} (A : BitRationalMatrixData r d) : ℕ :=
  r*d+∑ i : Fin r, ∑ j : Fin d,
    (((A.get i).get j).numerator.length+((A.get i).get j).denominator.length)

theorem bitRationalMatrixSize_cell {r d : ℕ} (A : BitRationalMatrixData r d)
    (i : Fin r) (j : Fin d) :
    ((A.get i).get j).numerator.length ≤ bitRationalMatrixSize A ∧
      ((A.get i).get j).denominator.length ≤ bitRationalMatrixSize A := by
  let f : Fin r → Fin d → ℕ := fun k l =>
    ((A.get k).get l).numerator.length+((A.get k).get l).denominator.length
  have hr : f i j ≤ ∑ k : Fin d, f i k :=
    Finset.single_le_sum (f := f i) (fun _ _ => Nat.zero_le _) (Finset.mem_univ j)
  have ht : (∑ k : Fin d, f i k) ≤ ∑ k : Fin r, ∑ l : Fin d, f k l :=
    Finset.single_le_sum (f := fun k => ∑ l : Fin d, f k l)
      (fun _ _ => Nat.zero_le _) (Finset.mem_univ i)
  have h : f i j ≤ bitRationalMatrixSize A := by
    unfold bitRationalMatrixSize
    exact (hr.trans ht).trans (Nat.le_add_left _ _)
  dsimp only [f] at h
  omega

/-- A single polynomial in the actual number of encoded input bits for the
square rational basis problem stated in Theorem 2.G. -/
noncomputable def rationalInputScalarPolynomial : Polynomial ℕ :=
  rationalScalarPolynomial.comp (3*Polynomial.X+1)

theorem encodedRationalScalarWork_input_size {r : ℕ} (A : BitRationalMatrixData r r)
    (hWF : ∀ i j, ((A.get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows A i j:ℝ))) :
    encodedRationalScalarWork A ≤ rationalInputScalarPolynomial.eval (bitRationalMatrixSize A) := by
  have hsize : r ≤ bitRationalMatrixSize A := by
    have hr : r ≤ r*r := by nlinarith
    exact hr.trans (Nat.le_add_right _ _)
  have hw := encodedRationalScalarWork_bound A hWF hA (bitRationalMatrixSize A)
    (bitRationalMatrixSize_cell A)
  have hb := rationalEncodedScalarBound_le_polynomial r r (bitRationalMatrixSize A)
    (3*bitRationalMatrixSize A+1) (by omega) (by omega) (by omega)
  have hfinal := hw.trans hb
  simpa only [rationalInputScalarPolynomial, Polynomial.eval_comp,
    Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_X,
    Polynomial.eval_one, Polynomial.eval_ofNat] using hfinal

end Optss
