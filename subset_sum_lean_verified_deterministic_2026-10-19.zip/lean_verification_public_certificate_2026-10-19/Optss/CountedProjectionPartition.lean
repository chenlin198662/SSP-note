import Optss.Basic

/-!
# Exact exceptional/live partition under an integer coordinate map

This is the algebraic identity used in equation (4) of Theorem 1.4.  It is
stated for compressed multiplicities: original counts split exactly into
exception and live counts, and a coordinate projection maps the live counted
support onto the original live scalar support.
-/

namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators

variable {ι G H : Type*} [Fintype ι] [AddCommGroup G] [AddCommGroup H]

theorem map_weightedSum (ρ : G →+ H) (u : ι → G) (x : ι → ℤ) :
    ρ (weightedSum u x) = weightedSum (fun i => ρ (u i)) x := by
  simp only [weightedSum, map_sum, map_zsmul]

/-- An additive map which represents every positive-capacity type maps the
entire counted support exactly.  No condition is needed for dead types. -/
theorem image_countSums_of_represents_on_support
    (ρ : G →+ H) (u : ι → G) (v : ι → H) (c : ι → ℕ)
    (hrep : ∀ i, 0 < c i → ρ (u i) = v i) :
    ρ '' countSums u (fun i => (c i : ℤ)) =
      countSums v (fun i => (c i : ℤ)) := by
  ext y
  constructor
  · rintro ⟨z, ⟨x, hx, rfl⟩, rfl⟩
    refine ⟨x, hx, ?_⟩
    rw [map_weightedSum]
    unfold weightedSum
    apply Finset.sum_congr rfl
    intro i _
    by_cases hci : 0 < c i
    · change x i • v i = x i • ρ (u i)
      rw [hrep i hci]
    · have hcz : c i = 0 := by omega
      have hxi := hx i
      have hxi' : 0 ≤ x i ∧ x i ≤ 0 := by simpa [hcz] using hxi
      have hxz : x i = 0 := by omega
      simp [hxz]
  · rintro ⟨x, hx, rfl⟩
    refine ⟨weightedSum u x, ⟨x, hx, rfl⟩, ?_⟩
    rw [map_weightedSum]
    unfold weightedSum
    apply Finset.sum_congr rfl
    intro i _
    by_cases hci : 0 < c i
    · change x i • ρ (u i) = x i • v i
      rw [hrep i hci]
    · have hcz : c i = 0 := by omega
      have hxi := hx i
      have hxi' : 0 ≤ x i ∧ x i ≤ 0 := by simpa [hcz] using hxi
      have hxz : x i = 0 := by omega
      simp [hxz]

/-- Removing exact exception multiplicities splits the original counted
support as the Minkowski sum of exception and live supports. -/
theorem countSums_exception_live_partition
    (v : ι → G) (capacity e : ι → ℕ) (he : ∀ i, e i ≤ capacity i) :
    countSums v (fun i => (capacity i : ℤ)) =
      countSums v (fun i => (e i : ℤ)) +
        countSums v (fun i => ((capacity i - e i : ℕ) : ℤ)) := by
  ext y
  have hcap : (fun i => ((e i : ℕ) : ℤ) + ((capacity i - e i : ℕ) : ℤ)) =
      fun i => (capacity i : ℤ) := by
    funext i
    have hei := he i
    omega
  rw [← hcap, mem_countSums_add_iff v
    (fun i => (e i : ℤ)) (fun i => ((capacity i - e i : ℕ) : ℤ))
    (fun i => Int.natCast_nonneg _) (fun i => Int.natCast_nonneg _)]
  rfl

/-- Exact public partition identity: the original scalar support is the
exception support plus the projection of the live coordinate support. -/
theorem countSums_exception_add_projected_live
    (projection : G →+ H) (u : ι → G) (scalar : ι → H)
    (capacity e : ι → ℕ) (he : ∀ i, e i ≤ capacity i)
    (hrep : ∀ i, 0 < capacity i - e i → projection (u i) = scalar i) :
    countSums scalar (fun i => (capacity i : ℤ)) =
      countSums scalar (fun i => (e i : ℤ)) +
        projection '' countSums u
          (fun i => ((capacity i - e i : ℕ) : ℤ)) := by
  rw [countSums_exception_live_partition scalar capacity e he]
  rw [image_countSums_of_represents_on_support projection u scalar
    (fun i => capacity i - e i) hrep]

end
end Optss
