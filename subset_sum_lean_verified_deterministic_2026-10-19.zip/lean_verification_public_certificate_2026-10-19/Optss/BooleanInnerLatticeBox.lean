import Optss.ThinLatticeBoxOutputSize

/-!
# Actual inner lattice boxes by Boolean division of floor widths

Every output width is computed by long division by the supplied positive
dimension constant. The resulting box lies inside the original body and
retains a dimension-only fraction of its lattice-point count. Zero widths
remain valid and the basis still generates the entire original lattice.
-/
namespace Optss
open scoped BigOperators Pointwise
variable {r m : ℕ}

def divideLatticeBoxWidths (box : BooleanLatticeBoxResult r) (cs : List Bool) : BooleanLatticeBoxResult r :=
  ⟨box.columns,⟨box.widths.data.map (fun w => (bitListDivision w cs).quotient),
    by simp [box.widths.length_eq]⟩⟩

def divideLatticeBoxWidthsWork (box : BooleanLatticeBoxResult r) (cs : List Bool) : ℕ :=
  2*r+1+(box.widths.data.map (fun w => bitListDivisionBitWork w cs)).sum

theorem divideLatticeBoxWidths_get (box : BooleanLatticeBoxResult r) (cs : List Bool) (j : Fin r) :
    ((divideLatticeBoxWidths box cs).widths.toVector.get j)=
      (bitListDivision (box.widths.toVector.get j) cs).quotient := by
  simp [divideLatticeBoxWidths,BooleanListArray.toVector,Vector.get]

theorem divideLatticeBoxWidths_value (box : BooleanLatticeBoxResult r) (cs : List Bool)
    (hc : 0<binaryDigitsValue cs) :
    decodedLatticeBoxWidths (divideLatticeBoxWidths box cs)=
      fun j => decodedLatticeBoxWidths box j/binaryDigitsValue cs := by
  funext j
  simp only [decodedLatticeBoxWidths,divideLatticeBoxWidths_get]
  exact (bitListDivision_correct _ _ hc).1

theorem divideLatticeBoxWidths_canonical (box : BooleanLatticeBoxResult r) (cs : List Bool)
    (hc : 0<binaryDigitsValue cs) (j : Fin r) :
    BitListCanonical ((divideLatticeBoxWidths box cs).widths.toVector.get j) := by
  rw [divideLatticeBoxWidths_get,(bitListDivision_encodings _ _ hc).1]
  simp [BitListCanonical,binaryDigitsValue_bits]

theorem divideLatticeBoxWidths_output_bits (box : BooleanLatticeBoxResult r) (cs : List Bool) :
    latticeBoxOutputBits (divideLatticeBoxWidths box cs)≤latticeBoxOutputBits box := by
  simp only [latticeBoxOutputBits,divideLatticeBoxWidths,List.map_map,Function.comp_def]
  apply Nat.add_le_add_left
  exact List.sum_le_sum (fun w _ => bitListDivision_quotient_length_le w cs)

theorem divideLatticeBoxWidthsWork_bound (box : BooleanLatticeBoxResult r) (cs : List Bool)
    (hc : 0<binaryDigitsValue cs) (L : ℕ) (hL : latticeBoxOutputBits box≤L) :
    divideLatticeBoxWidthsWork box cs≤2*r+1+r*16*(L+1)*(cs.length+1) := by
  have hw : ∀ w∈box.widths.data,w.length≤L := by
    intro w hw
    have h := List.single_le_sum (fun _ _ => Nat.zero_le _) w.length (List.mem_map.mpr ⟨w,hw,rfl⟩)
    unfold latticeBoxOutputBits at hL
    exact h.trans (by omega)
  have hs := List.sum_le_card_nsmul (box.widths.data.map (fun w => bitListDivisionBitWork w cs))
    (16*(L+1)*(cs.length+1)) (by
      intro z hz
      obtain ⟨w,hw',rfl⟩ := List.mem_map.mp hz
      exact (bitListDivisionBitWork_bound w cs hc).trans (by gcongr; exact hw w hw'))
  simp only [List.length_map,box.widths.length_eq,nsmul_eq_mul] at hs
  unfold divideLatticeBoxWidthsWork
  nlinarith

def booleanInnerLatticeBox (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (cs : List Bool) : Option (BooleanLatticeBoxResult r) :=
  (booleanThinLatticeBox V G).map (fun box => divideLatticeBoxWidths box cs)

def booleanInnerLatticeBoxWork (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (cs : List Bool) : ℕ :=
  booleanThinLatticeBoxWork V G+(match booleanThinLatticeBox V G with
    | none => 1
    | some box => divideLatticeBoxWidthsWork box cs+1)

theorem booleanInnerLatticeBox_spec (hr : 0<r)
    (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetG : (storedRationalMatrix G).det≠0)
    (hsym : ∀ y∈rationalVertexSet (storedRationalVertices V),-y∈rationalVertexSet (storedRationalVertices V))
    (hspan : Submodule.span ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))=⊤)
    (cs : List Bool) (hc : 0<binaryDigitsValue cs)
    (hCJ : latticeBoxingDilation r ((r.factorial:ℝ)*sharpLatticeDefectBound r)≤(binaryDigitsValue cs:ℝ)) :
    ∃ box,booleanInnerLatticeBox V G cs=some box ∧
      ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
        (∀ i j,(storedRationalMatrix box.columns i j:ℝ)=b j i) ∧
        basisIntegerLattice b=(Submodule.span ℤ (Set.range (fun j i => (storedRationalMatrix G i j:ℝ))) : Set _) ∧
        (∀ j,BitListCanonical (box.widths.toVector.get j)) ∧
        basisCoefficientBox b (decodedLatticeBoxWidths box) ⊆ storedVertexHull V ∧
        (basisLatticePoints b (storedVertexHull V) (storedVertexHull_compact V)).card≤
          (2*binaryDigitsValue cs+1)^r*∏ j,(2*decodedLatticeBoxWidths box j+1) ∧
        (∀ i j,(rectangularListFractionMatrix box.columns i j).WellFormed) := by
  obtain ⟨outer,houter,b,hcols,hΛ,hcanon,hsub,hencl,hne,hB⟩ :=
    booleanThinLatticeBox_spec hr V G hV hG hdetG hsym hspan
  let box := divideLatticeBoxWidths outer cs
  have hwidth := divideLatticeBoxWidths_value outer cs hc
  have hzero : (0:Fin r→ℝ)∈storedVertexHull V := by
    obtain ⟨x,hx⟩ := hne
    have hneg := symmetric_vertex_hull (rationalVertexSet (storedRationalVertices V)) hsym x hx
    have hh := (convex_convexHull ℝ (rationalVertexSet (storedRationalVertices V):Set (Fin r→ℝ)))
      hx hneg (show (0:ℝ)≤1/2 by norm_num) (show (0:ℝ)≤1/2 by norm_num)
      (show (1:ℝ)/2+1/2=1 by norm_num)
    convert hh using 1 <;> module
  have hJ : 0≤latticeBoxingDilation r ((r.factorial:ℝ)*sharpLatticeDefectBound r) := by
    have hω := sharpLatticeDefectBound_pos r
    unfold latticeBoxingDilation
    positivity
  refine ⟨box,?_,b,hcols,hΛ,divideLatticeBoxWidths_canonical outer cs hc,?_,?_,hB⟩
  · rw [booleanInnerLatticeBox,houter]
    rfl
  · change basisCoefficientBox b (decodedLatticeBoxWidths (divideLatticeBoxWidths outer cs))⊆_
    rw [hwidth]
    exact basisCoefficientBox_div_subset b _ _ (convex_convexHull ℝ _) hzero _ hJ hencl _ hc hCJ
  · change _≤(2*binaryDigitsValue cs+1)^r*∏ j,(2*decodedLatticeBoxWidths (divideLatticeBoxWidths outer cs) j+1)
    rw [hwidth]
    exact (thin_lattice_box_card b _ (storedVertexHull_compact V) _ hsub).trans (divided_width_volume _ _ hc)

noncomputable def booleanInnerLatticeBoxPolynomial (r cBits : ℕ) : Polynomial ℕ :=
  booleanLatticeBoxPolynomial r+Polynomial.C (2*r+2)+
    Polynomial.C (r*16*(cBits+1))*(booleanLatticeBoxOutputSize r+1)

theorem booleanInnerLatticeBoxWork_input_polynomial (hr : 0<r)
    (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetG : (storedRationalMatrix G).det≠0)
    (hspan : Submodule.span ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))=⊤)
    (cs : List Bool) (hc : 0<binaryDigitsValue cs) :
    booleanInnerLatticeBoxWork V G cs≤(booleanInnerLatticeBoxPolynomial r cs.length).eval
      (listStoredRationalBits V+listStoredRationalBits G) := by
  let N := listStoredRationalBits V+listStoredRationalBits G
  have hw := booleanThinLatticeBoxWork_input_polynomial hr V G hV hG hdetG hspan
  unfold booleanInnerLatticeBoxWork
  simp only [booleanInnerLatticeBoxPolynomial,Polynomial.eval_add,Polynomial.eval_C,
    Polynomial.eval_mul,Polynomial.eval_one]
  cases he : booleanThinLatticeBox V G with
  | none => simp only; omega
  | some box =>
    have hb := booleanThinLatticeBox_output_bits V G hV hG hdetG hspan box he
    have hd := divideLatticeBoxWidthsWork_bound box cs hc _ hb
    simp only
    nlinarith
end Optss
