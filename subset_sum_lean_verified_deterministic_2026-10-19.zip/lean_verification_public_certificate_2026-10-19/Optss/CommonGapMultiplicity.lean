import Optss.CommonGapRescale

/-!
# Common-GAP existence with arbitrary labelled multiplicities

A fixed inflation of the internal scale discharges every bounded parameter
case without discarding an unbounded multiset. The construction uses the same
actual labelled phase iteration and respects every available copy. This is the
mathematical part of Theorem 9.5; a compressed counter implementation and its
running-time analysis are separate obligations.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1600000

/-- Unconditional common-GAP output for arbitrary finite positive labelled
multisets. The reserve, rank and filling constants depend only on `η`.
There is no multiplicity bound or assumption of a successful phase. -/
theorem theorem9_5_mathematical (η : ℝ) (hη : 0 < η) :
    ∃ R Rconst : ℕ, ∃ c : ℝ, 0 < c ∧ 1 ≤ c ∧ ∀ f : ℕ, ∃ Econst : ℕ,
      ∀ (ι : Type) [LinearOrder ι] (scalar : ι → ℤ) (initial : Finset ι) (N h : ℕ),
        1 ≤ N → (N : ℝ)^η ≤ h →
        (∀ i ∈ initial, scalar i ∈ Finset.Icc 1 (N : ℤ)) →
        Nonempty (CommonGapDecomposition scalar initial h (f*h) R
          (Econst*h*(Nat.log 2 (h*N+2)+1)^2) (Rconst*h) c) := by
  obtain ⟨N₀, H₀, R, Rconst, c, hc, hlarge⟩ := common_gap_unrestricted_scale η hη
  let Nbase := max 1 N₀
  let A := max 1 (max H₀ (max ⌈(Nbase : ℝ)^η⌉₊ ⌈c⁻¹⌉₊))
  let K := A*(Nbase+1)+1
  let L := Nat.log 2 K+2
  have hA : 1 ≤ A := le_max_left _ _
  have hcA : 1 ≤ c*(A : ℝ) := by
    have hi : ⌈c⁻¹⌉₊ ≤ A := (le_max_right _ _).trans ((le_max_right H₀ _).trans (le_max_right 1 _))
    have hb := (Nat.le_ceil (c⁻¹)).trans (Nat.cast_le.mpr hi)
    simpa only [mul_inv_cancel₀ hc.ne'] using mul_le_mul_of_nonneg_left hb hc.le
  refine ⟨R, Rconst*A, c*A, by positivity, hcA, ?_⟩
  intro f
  obtain ⟨E, hlarge⟩ := hlarge f
  refine ⟨E*A*L^2, ?_⟩
  intro ι _ scalar initial N h hN hscale hbox
  have hh : 1 ≤ h := by
    have hNR : (1 : ℝ) ≤ N := by exact_mod_cast hN
    exact_mod_cast (Real.one_le_rpow hNR hη.le).trans hscale
  let N' := max Nbase N
  have hNN' : N ≤ N' := le_max_right _ _
  have hN₀' : N₀ ≤ N' := (le_max_right 1 N₀).trans (le_max_left _ _)
  have hN' : 1 ≤ N' := hN.trans hNN'
  have hH' : H₀ ≤ A*h := ((le_max_left H₀ _).trans (le_max_right 1 _)).trans
    (by simpa only [mul_one] using Nat.mul_le_mul_left A hh)
  have hhA : h ≤ A*h := by simpa only [one_mul] using Nat.mul_le_mul_right h hA
  have hscale' : (N' : ℝ)^η ≤ (A*h : ℕ) := by
    by_cases hb : Nbase ≤ N
    · have he : N' = N := max_eq_right hb
      rw [he]
      exact hscale.trans (Nat.cast_le.mpr hhA)
    · have he : N' = Nbase := max_eq_left (by omega)
      rw [he]
      have hceil : ⌈(Nbase : ℝ)^η⌉₊ ≤ A := (le_max_left _ _).trans ((le_max_right H₀ _).trans (le_max_right 1 _))
      exact (Nat.le_ceil _).trans ((Nat.cast_le.mpr hceil).trans
        (Nat.cast_le.mpr (by simpa only [mul_one] using Nat.mul_le_mul_left A hh)))
  have hbox' : ∀ i ∈ initial, scalar i ∈ Finset.Icc 1 (N' : ℤ) := by
    intro i hi
    obtain ⟨hl, hu⟩ := Finset.mem_Icc.mp (hbox i hi)
    exact Finset.mem_Icc.mpr ⟨hl, hu.trans (by exact_mod_cast hNN')⟩
  obtain ⟨out⟩ := hlarge ι scalar initial N' (A*h) hN₀' hH' hN' hscale' hbox'
  have hNmult : N' ≤ (Nbase+1)*N := by
    apply max_le
    · have hm := Nat.mul_le_mul_left Nbase hN
      nlinarith
    · nlinarith
  have hprod : (A*h)*N'+2 ≤ K*(h*N+2) := by
    have hm := Nat.mul_le_mul_left (A*h) hNmult
    dsimp only [K]
    nlinarith
  have hlog := common_product_log_bound ((A*h)*N'+2) K (h*N+2) hprod
  have hsq : (Nat.log 2 ((A*h)*N'+2)+1)^2 ≤ L^2*(Nat.log 2 (h*N+2)+1)^2 := by
    simpa only [mul_pow] using Nat.pow_le_pow_left hlog 2
  have hE : E*(A*h)*(Nat.log 2 ((A*h)*N'+2)+1)^2 ≤
      (E*A*L^2)*h*(Nat.log 2 (h*N+2)+1)^2 :=
    (Nat.mul_le_mul_left (E*(A*h)) hsq).trans_eq (by ring)
  have hR : Rconst*(A*h) ≤ (Rconst*A)*h := by rw [mul_assoc]
  refine ⟨((out.restrict h (f*h) (c*A) (Nat.mul_le_mul_left f hhA)
    (by push_cast; ring_nf; exact le_rfl)).weakenBounds _ _ hE hR)⟩

end
end Optss
