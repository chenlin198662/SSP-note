import Optss.BooleanListIndex
import Optss.EncodedCachedReduction

/-!
# Cached reduction with explicit list-backed matrix storage

All matrix and coefficient arrays in these answer routines are fixed-size
lists. Reads scan Boolean addresses and copy the returned payload. Updates
copy every retained row and cell. Vector conversions occur only in the
mathematical projection and proofs. This gives a concrete, conservative
storage implementation to which the encoded arithmetic correctness applies.
-/

namespace Optss
variable {r d : ℕ}

abbrev ListBitRationalMatrixData (r d : ℕ) :=
  BooleanListArray (BooleanListArray BitListFraction d) r
abbrev ListBitIntegerMatrixData (r d : ℕ) :=
  BooleanListArray (BooleanListArray BitListInteger d) r

/-- Explicit scalar payload copies. -/
def listCopyFraction (q : BitListFraction) : BitListFraction :=
  ⟨q.negative,bitWordCopy q.numerator,bitWordCopy q.denominator⟩
def listCopyInteger (z : BitListInteger) : BitListInteger :=
  ⟨z.negative,bitWordCopy z.digits⟩
@[simp] theorem listCopyFraction_eq (q : BitListFraction) : listCopyFraction q = q := by
  cases q; simp [listCopyFraction,bitWordCopy_eq]
@[simp] theorem listCopyInteger_eq (z : BitListInteger) : listCopyInteger z = z := by
  cases z; simp [listCopyInteger,bitWordCopy_eq]

/-- Mathematical projection; never called by the answer routines. -/
def listMatrixVector {α : Type*} (A : BooleanListArray (BooleanListArray α d) r) :
    Vector (Vector α d) r :=
  Vector.ofFn fun i => (A.toVector.get i).toVector

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

private theorem get_set {α : Type*} {n : ℕ} (v : Vector α n)
    (k i : Fin n) (a : α) :
    (v.set k.val a k.isLt).get i = if i = k then a else v.get i := by
  change (v.set k.val a k.isLt)[i.val] = _
  rw [Vector.getElem_set]
  split <;> rename_i h
  · have he : i = k := Fin.ext h.symm
    simp [he]
  · have he : i ≠ k := fun he => h (congrArg Fin.val he.symm)
    simp [he]
    rfl

@[simp] theorem listMatrixVector_ofFn {α : Type*} (f : Fin r → BooleanListArray α d) :
    listMatrixVector (BooleanListArray.ofFn f) = Vector.ofFn fun i => (f i).toVector := by
  simp only [listMatrixVector,BooleanListArray.ofFn_toVector,get_ofFn]

/-- Every matrix lookup physically copies the row and then the scalar cell. -/
def listMatrixRead {α : Type*} (copy : α → α)
    (A : BooleanListArray (BooleanListArray α d) r) (i : Fin r) (j : Fin d) : α :=
  (A.read (BooleanListArray.copy copy) i).read copy j

theorem listMatrixRead_eq {α : Type*} (copy : α → α) (hc : ∀ x,copy x=x)
    (A : BooleanListArray (BooleanListArray α d) r) (i : Fin r) (j : Fin d) :
    listMatrixRead copy A i j = ((listMatrixVector A).get i).get j := by
  simp only [listMatrixRead,BooleanListArray.read_toVector _ hc,
    BooleanListArray.read_toVector _ (BooleanListArray.copy_eq copy hc),listMatrixVector,get_ofFn]

theorem listMatrixRead_fun {α : Type*} (copy : α → α) (hc : ∀ x,copy x=x)
    (A : BooleanListArray (BooleanListArray α d) r) (i : Fin r) :
    listMatrixRead copy A i = ((listMatrixVector A).get i).get :=
  funext fun j => listMatrixRead_eq copy hc A i j

theorem listMatrixVector_write {α : Type*} (copy : α → α) (hc : ∀ x,copy x=x)
    (A : BooleanListArray (BooleanListArray α d) r) (k : Fin r) (row : BooleanListArray α d) :
    listMatrixVector (A.write (BooleanListArray.copy copy) k row) =
      (listMatrixVector A).set k.val row.toVector k.isLt := by
  apply Vector.ext
  intro i hi
  change (listMatrixVector (A.write (BooleanListArray.copy copy) k row)).get ⟨i,hi⟩ =
    ((listMatrixVector A).set k.val row.toVector k.isLt).get ⟨i,hi⟩
  simp only [listMatrixVector,get_ofFn,BooleanListArray.write_toVector _
    (BooleanListArray.copy_eq copy hc),get_set]
  split_ifs <;> rfl

def listStoredGsCoefficient (A T : ListBitRationalMatrixData r d) (k j : Fin r) : BitListFraction :=
  let num := encodedRationalDot (listMatrixRead listCopyFraction T j)
    (listMatrixRead listCopyFraction A k)
  let den := encodedRationalDot (listMatrixRead listCopyFraction T j)
    (listMatrixRead listCopyFraction T j)
  bitListFractionDiv num den

theorem listStoredGsCoefficient_eq (A T : ListBitRationalMatrixData r d) (k j : Fin r) :
    listStoredGsCoefficient A T k j = encodedGsCoefficient (listMatrixVector A) (listMatrixVector T) k j := by
  simp only [listStoredGsCoefficient,encodedGsCoefficient,listMatrixRead_eq _ listCopyFraction_eq,listMatrixRead_fun _ listCopyFraction_eq]

def listStoredGSCoefficients (A T : ListBitRationalMatrixData r d) (k : Fin r) :
    BooleanListArray BitListFraction r :=
  BooleanListArray.ofFn fun i => if bitIndexLT i k then listStoredGsCoefficient A T k i else bitListFractionZero

theorem listStoredGSCoefficients_eq (A T : ListBitRationalMatrixData r d) (k : Fin r) :
    (listStoredGSCoefficients A T k).toVector =
      encodedGSCoefficients (listMatrixVector A) (listMatrixVector T) k := by
  simp only [listStoredGSCoefficients,encodedGSCoefficients,BooleanListArray.ofFn_toVector,
    listStoredGsCoefficient_eq,bitIndexLT_correct,Fin.lt_def]

def listStoredGSRow (A T : ListBitRationalMatrixData r d) (k : Fin r) :
    BooleanListArray BitListFraction d :=
  let coeff := listStoredGSCoefficients A T k
  BooleanListArray.ofFn fun l =>
    let acc := encodedProductSum (fun i : Finset.Iio k => coeff.read listCopyFraction i)
      (fun i => listMatrixRead listCopyFraction T i l) (List.ofFn (lowerFinEquiv k))
    bitListFractionSub (listMatrixRead listCopyFraction A k l) acc

theorem listStoredGSRow_eq (A T : ListBitRationalMatrixData r d) (k : Fin r) :
    (listStoredGSRow A T k).toVector = encodedGSRow (listMatrixVector A) (listMatrixVector T) k := by
  simp only [listStoredGSRow,encodedGSRow,BooleanListArray.ofFn_toVector,
    BooleanListArray.read_toVector _ listCopyFraction_eq,listStoredGSCoefficients_eq,
    listMatrixRead_eq _ listCopyFraction_eq,listMatrixRead_fun _ listCopyFraction_eq]

def listStoredGSTable (A : ListBitRationalMatrixData r d) (n : ℕ) (hn : n ≤ r) :
    ListBitRationalMatrixData r d :=
  match n with
  | 0 => BooleanListArray.ofFn fun _ => BooleanListArray.ofFn fun _ => bitListFractionZero
  | n+1 =>
    let T := listStoredGSTable A n (by omega)
    let k : Fin r := ⟨n,by omega⟩
    T.write (BooleanListArray.copy listCopyFraction) k (listStoredGSRow A T k)
termination_by n

theorem listStoredGSTable_eq (A : ListBitRationalMatrixData r d) (n : ℕ) (hn : n ≤ r) :
    listMatrixVector (listStoredGSTable A n hn) = encodedGSTable (listMatrixVector A) n hn := by
  induction n with
  | zero =>
    simp only [listStoredGSTable,listMatrixVector_ofFn,BooleanListArray.ofFn_toVector,encodedGSTable]
    apply Vector.ext
    intro i hi
    apply Vector.ext
    intro j hj
    simp
  | succ n ih =>
    rw [listStoredGSTable,listMatrixVector_write _ listCopyFraction_eq,listStoredGSRow_eq,ih,encodedGSTable]

def listStoredRationalIntegerRows (D : ListBitIntegerMatrixData r d) : ListBitRationalMatrixData r d :=
  BooleanListArray.ofFn fun i => BooleanListArray.ofFn fun j =>
    let z := listMatrixRead listCopyInteger D i j
    ⟨z.negative,z.digits,[true]⟩

theorem listStoredRationalIntegerRows_eq (D : ListBitIntegerMatrixData r d) :
    listMatrixVector (listStoredRationalIntegerRows D) = encodedRationalIntegerRows (listMatrixVector D) := by
  simp only [listStoredRationalIntegerRows,listMatrixVector_ofFn,BooleanListArray.ofFn_toVector,
    listMatrixRead_eq _ listCopyInteger_eq,encodedRationalIntegerRows]

def listStoredIntegerRowUpdate (D : ListBitIntegerMatrixData r d) (k j : Fin r)
    (c : BitListInteger) : ListBitIntegerMatrixData r d :=
  let row := BooleanListArray.ofFn fun l => bitListIntegerRowCell
    (listMatrixRead listCopyInteger D k l) (listCopyInteger c) (listMatrixRead listCopyInteger D j l)
  D.write (BooleanListArray.copy listCopyInteger) k row

theorem listStoredIntegerRowUpdate_eq (D : ListBitIntegerMatrixData r d) (k j : Fin r)
    (c : BitListInteger) : listMatrixVector (listStoredIntegerRowUpdate D k j c) =
      bitListIntegerRowUpdate (listMatrixVector D) k j c := by
  simp only [listStoredIntegerRowUpdate,listMatrixVector_write _ listCopyInteger_eq,
    BooleanListArray.ofFn_toVector,listMatrixRead_eq _ listCopyInteger_eq,listCopyInteger_eq,
    bitListIntegerRowUpdate]

def listStoredReduceIntegerRow (D : ListBitIntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) : ListBitIntegerMatrixData r d :=
  match n with
  | 0 => D
  | n+1 =>
    let j : Fin r := ⟨n,by omega⟩
    let Q := listStoredRationalIntegerRows D
    let T := listStoredGSTable Q r le_rfl
    let q := encodedRoundInteger (listStoredGsCoefficient Q T k j)
    let W := listStoredIntegerRowUpdate D k j q
    listStoredReduceIntegerRow W k n (by omega)
termination_by n

theorem listStoredReduceIntegerRow_eq (D : ListBitIntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) :
    listMatrixVector (listStoredReduceIntegerRow D k n h) =
      encodedReduceIntegerRow (listMatrixVector D) k n h := by
  induction n generalizing D with
  | zero => rw [listStoredReduceIntegerRow,encodedReduceIntegerRow]
  | succ n ih =>
    rw [listStoredReduceIntegerRow,encodedReduceIntegerRow,ih,listStoredIntegerRowUpdate_eq,
      listStoredGsCoefficient_eq,listStoredGSTable_eq,listStoredRationalIntegerRows_eq]

def listStoredReduceIntegerAll (D : ListBitIntegerMatrixData r d)
    (n : ℕ) (h : n ≤ r) : ListBitIntegerMatrixData r d :=
  match n with
  | 0 => D
  | n+1 =>
    let C := listStoredReduceIntegerAll D n (by omega)
    listStoredReduceIntegerRow C ⟨n,by omega⟩ n le_rfl
termination_by n

theorem listStoredReduceIntegerAll_eq (D : ListBitIntegerMatrixData r d)
    (n : ℕ) (h : n ≤ r) :
    listMatrixVector (listStoredReduceIntegerAll D n h) =
      encodedReduceIntegerAll (listMatrixVector D) n h := by
  induction n with
  | zero => rw [listStoredReduceIntegerAll,encodedReduceIntegerAll]
  | succ n ih =>
    rw [listStoredReduceIntegerAll,encodedReduceIntegerAll,listStoredReduceIntegerRow_eq,ih]

def listStoredLovaszPair (A T : ListBitRationalMatrixData r d) (j k : Fin r) : Bool :=
  let nk := encodedRationalDot (listMatrixRead listCopyFraction T k) (listMatrixRead listCopyFraction T k)
  let nj := encodedRationalDot (listMatrixRead listCopyFraction T j) (listMatrixRead listCopyFraction T j)
  let mu := listStoredGsCoefficient A T k j
  let square := bitListFractionMul (listCopyFraction mu) mu
  let product := bitListFractionMul square (listCopyFraction nj)
  let total := bitListFractionAdd nk product
  let left := bitListFractionMul encodedFractionFour total
  let right := bitListFractionMul encodedFractionThree nj
  bitListFractionLT left right

theorem listStoredLovaszPair_eq (A T : ListBitRationalMatrixData r d) (j k : Fin r) :
    listStoredLovaszPair A T j k = encodedLovaszPair (listMatrixVector A) (listMatrixVector T) j k := by
  simp only [listStoredLovaszPair,encodedLovaszPair,listStoredGsCoefficient_eq,
    listMatrixRead_eq _ listCopyFraction_eq,listMatrixRead_fun _ listCopyFraction_eq,listCopyFraction_eq]

/-- Actual swap deep-copies every row and every integer payload. -/
def listStoredSwapRows (D : ListBitIntegerMatrixData r d) (j k : Fin r) : ListBitIntegerMatrixData r d :=
  BooleanListArray.ofFn fun i => D.read (BooleanListArray.copy listCopyInteger) (Equiv.swap j k i)

theorem listStoredSwapRows_eq (D : ListBitIntegerMatrixData r d) (j k : Fin r) :
    listMatrixVector (listStoredSwapRows D j k) = encodedSwapRows (listMatrixVector D) j k := by
  simp only [listStoredSwapRows,listMatrixVector_ofFn,encodedSwapRows,listMatrixVector,get_ofFn,
    BooleanListArray.read_toVector _ (BooleanListArray.copy_eq _ listCopyInteger_eq),BooleanListArray.ofFn_toVector,get_ofFn]

end Optss
