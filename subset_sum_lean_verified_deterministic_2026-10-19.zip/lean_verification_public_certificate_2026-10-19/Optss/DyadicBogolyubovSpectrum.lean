import Optss.DyadicDFTPrecision

/-! Fixed-slack spectrum selection from the actual radix-two/Bluestein
integer transform. This replaces the direct quadratic character summation.
The transform and output arrays are materialized once before selection. -/
namespace Optss
open scoped Pointwise
variable {N : ℕ} [NeZero N]

def dyadicDFTOutputDenominator (N : ℕ) : ℕ :=
  let n := bluesteinPadExponent N
  2^n*(dyadicFourierDenominator (dyadicDFTPrecision n))^(3*n+3)

def dyadicRationalDFT (N : ℕ) [NeZero N] (f : Vector Bool N) : Vector (ℚ×ℚ) N :=
  let p := dyadicDFTPrecision (bluesteinPadExponent N)
  let V := canonicalDyadicDFT N p f
  let D := dyadicDFTOutputDenominator N
  Vector.ofFn fun k => ((V.get k).re/(D : ℚ),(V.get k).im/(D : ℚ))

theorem dyadicRationalDFT_value (f : Vector Bool N) (k : Fin N) :
    rationalComplexValue ((dyadicRationalDFT N f).get k)=
      fourierIntegerValue ((canonicalDyadicDFT N
        (dyadicDFTPrecision (bluesteinPadExponent N)) f).get k)/
      (dyadicDFTOutputDenominator N : ℂ) := by
  dsimp only [dyadicRationalDFT]
  rw [vector_get_ofFn]
  simp only [rationalComplexValue,fourierIntegerValue,Rat.cast_div,Rat.cast_intCast,Rat.cast_natCast]
  ring

theorem dyadicRationalDFT_certified (f : Vector Bool N) (k : Fin N) :
    ‖rationalComplexValue ((dyadicRationalDFT N f).get k)-
      ZMod.dft (cyclicBooleanInput N f) (k.val : ZMod N)‖≤1/(64*(N : ℝ)) := by
  rw [dyadicRationalDFT_value]
  simpa only [dyadicDFTOutputDenominator,Nat.cast_mul,Nat.cast_pow] using
    canonicalDyadicDFT_certified N f k

def dyadicIndicatorData (A : Finset (ZMod N)) : Vector Bool N :=
  Vector.ofFn fun j => decide ((j.val : ZMod N)∈A)

theorem cyclicBooleanInput_indicator (A : Finset (ZMod N)) :
    cyclicBooleanInput N (dyadicIndicatorData A)=cyclicIndicator A := by
  funext x
  simp [cyclicBooleanInput,dyadicIndicatorData,vector_get_ofFn,cyclicIndicator,cyclicNatIndicator]

def dyadicFourierValues (A : Finset (ZMod N)) : ZMod N → ℚ×ℚ :=
  let V := dyadicRationalDFT N (dyadicIndicatorData A)
  fun k => V.get ⟨k.val,k.val_lt⟩

theorem dyadicFourierValues_certified (A : Finset (ZMod N)) (hA : A.Nonempty) (k : ZMod N) :
    ‖rationalComplexValue (dyadicFourierValues A k)-ZMod.dft (cyclicIndicator A) k‖≤
      (A.card : ℝ)^2/(64*N) := by
  have h := dyadicRationalDFT_certified (dyadicIndicatorData A) ⟨k.val,k.val_lt⟩
  rw [cyclicBooleanInput_indicator,ZMod.natCast_zmod_val] at h
  have hm : (1 : ℝ)≤A.card := by exact_mod_cast Finset.card_pos.mpr hA
  exact h.trans (div_le_div_of_nonneg_right (by nlinarith) (by positivity))

def dyadicBogolyubovSpectrum (A : Finset (ZMod N)) : Finset (ZMod N) :=
  let V := dyadicRationalDFT N (dyadicIndicatorData A)
  rationalApproximateSpectrum A (fun k => rationalComplexEnergy (V.get ⟨k.val,k.val_lt⟩))

theorem dyadicBogolyubovSpectrum_card (A : Finset (ZMod N)) (hA : A.Nonempty) :
    ((dyadicBogolyubovSpectrum A).card : ℝ)≤16*(N : ℝ)^2/(A.card : ℝ)^2 :=
  rationalApproximateSpectrum_card A hA _
    (rational_fourier_values_energy_error A _ (dyadicFourierValues_certified A hA))

theorem dyadicBogolyubovSpectrum_subset_double_difference (A : Finset (ZMod N)) (hA : A.Nonempty) :
    cyclicBohrSet (dyadicBogolyubovSpectrum A)⊆(↑((A+A)-(A+A)) : Set (ZMod N)) :=
  rationalApproximateSpectrum_subset_double_difference A hA _
    (rational_fourier_values_energy_error A _ (dyadicFourierValues_certified A hA))

theorem dyadicBogolyubovSpectrum_progression (A : Finset (ZMod N)) (hA : A.Nonempty) :
    ∃ ρ : IntVec ((dyadicBogolyubovSpectrum A).card+1) →+ ZMod N,
    ∃ m : Fin ((dyadicBogolyubovSpectrum A).card+1) → ℕ,
      Set.InjOn ρ (integerBudgetBox m) ∧ integerProgressionValues ρ m⊆(A+A)-(A+A) ∧
      N≤bohrProgressionLoss ((dyadicBogolyubovSpectrum A).card+1)*
        (integerProgressionValues ρ m).card ∧
      (((dyadicBogolyubovSpectrum A).card+1 : ℕ) : ℝ)≤1+16*(N : ℝ)^2/(A.card : ℝ)^2 :=
  rationalApproximateSpectrum_progression A hA _
    (rational_fourier_values_energy_error A _ (dyadicFourierValues_certified A hA))

end Optss
