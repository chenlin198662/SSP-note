import Optss.ListRadixTwo

/-! Work of the sequential-list FFT. Scalar bit gates and digit-list visits
are counted by the already verified Boolean routines. Administration counts
list-cell inspection/allocation, including both append passes and both zip
passes. It does not assert a machine cost for pointer representation. -/
namespace Optss
open scoped BigOperators

/-- Literal scalar calls along the stored list execution. -/
def listBitRadixTwoScalarWork (D : BitListInteger) :
    List (List BitFourierInteger) → List BitFourierInteger → ℕ
  | [],_ => 0
  | t::ts,A =>
    let p := fourierListSplit A
    let E := listBitRadixTwo D ts p.1
    let O := listBitRadixTwo D ts p.2
    listBitRadixTwoScalarWork D ts p.1+listBitRadixTwoScalarWork D ts p.2+
      (List.zipWith (fun eo w => bitFourierButterflyWork D eo.1 w eo.2)
        (List.zip (E++E) (O++O)) t).sum

/-- Pass charges include cell inspection and output constructors: four per
input cell for splitting, two for append, four for zip, and five for the
butterfly zip. Each pass also includes its terminal branch. -/
def listBitRadixTwoAdministration (D : BitListInteger) :
    List (List BitFourierInteger) → List BitFourierInteger → ℕ
  | [],_ => 1
  | t::ts,A =>
    let p := fourierListSplit A
    let E := listBitRadixTwo D ts p.1
    let O := listBitRadixTwo D ts p.2
    listBitRadixTwoAdministration D ts p.1+listBitRadixTwoAdministration D ts p.2+
      (4*A.length+1)+(2*E.length+1)+(2*O.length+1)+
      (4*min (2*E.length) (2*O.length)+1)+
      (5*min (min (2*E.length) (2*O.length)) t.length+1)+1

theorem listBitRadixTwoScalarWork_eq (D : BitListInteger) (T : ℕ → ℕ → BitFourierInteger)
    (n : ℕ) (A : Vector BitFourierInteger (2^n)) :
    listBitRadixTwoScalarWork D (radixTwiddleLists T n) (List.ofFn A.get)=
      bitFixedPointRadixTwoWork D T n A := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [radixTwiddleLists,listBitRadixTwoScalarWork,fourierListSplit_ofFn]
    dsimp only
    rw [ih,ih,listBitRadixTwo_eq,listBitRadixTwo_eq,fourierList_double_ofFn,fourierList_double_ofFn]
    change _+_+(List.zipWith _ (List.zipWith Prod.mk _ _) _).sum=_
    rw [fourierList_zipWith_ofFn,fourierList_zipWith_ofFn,List.sum_ofFn]
    rfl

theorem listBitRadixTwoAdministration_bound (D : BitListInteger) (T : ℕ → ℕ → BitFourierInteger)
    (n : ℕ) (A : Vector BitFourierInteger (2^n)) :
    listBitRadixTwoAdministration D (radixTwiddleLists T n) (List.ofFn A.get)≤64*(n+1)*2^n := by
  induction n with
  | zero => simp [listBitRadixTwoAdministration,radixTwiddleLists]
  | succ n ih =>
    have he := ih (radixEvenData n A)
    have ho := ih (radixOddData n A)
    rw [radixTwiddleLists,listBitRadixTwoAdministration,fourierListSplit_ofFn]
    dsimp only
    rw [listBitRadixTwo_eq,listBitRadixTwo_eq]
    simp only [List.length_ofFn,min_self]
    have hpow : 2^(n+1)=2*2^n := by rw [pow_succ]; omega
    rw [hpow,min_self]
    have hp : 0<2^n := Nat.pow_pos (by decide)
    nlinarith only [he,ho,hp]

/-- Combined scalar-bit and source-list-cell work is quasilinear in the
number of entries when the coefficient and precision bit lengths are
polylogarithmic. Character/table construction is a separate proved stage. -/
theorem listBitRadixTwo_combined_bound (D : BitListInteger) (d B : ℕ)
    (hD : D.value=(d : ℤ)) (hDc : BitListCanonical D.digits)
    (T : ℕ → ℕ → BitFourierInteger) (n : ℕ) (A : Vector BitFourierInteger (2^n))
    (hAc : ∀ j, (A.get j).Canonical) (hA : ∀ j, FourierIntegerBound (A.get j).value B)
    (hTc : ∀ l<n, ∀ k, (T l k).Canonical)
    (hT : ∀ l<n, ∀ k, FourierIntegerBound (T l k).value (2*d)) :
    listBitRadixTwoScalarWork D (radixTwiddleLists T n) (List.ofFn A.get)+
      listBitRadixTwoAdministration D (radixTwiddleLists T n) (List.ofFn A.get)≤
      576*(n+1)*2^n*(n*(d.size+3)+B.size+2)^2 := by
  rw [listBitRadixTwoScalarWork_eq]
  have hs := bitFixedPointRadixTwoWork_bound D d B hD hDc T n A hAc hA hTc hT
  have ha := listBitRadixTwoAdministration_bound D T n A
  rw [radixTwoButterflyCount_eq] at hs
  have hsq : 1≤(n*(d.size+3)+B.size+2)^2 := Nat.one_le_pow 2 _ (by omega)
  have hm := Nat.mul_le_mul_left (64*(n+1)*2^n) hsq
  have hn := Nat.mul_le_mul_right (2^n*(n*(d.size+3)+B.size+2)^2) (Nat.le_succ n)
  nlinarith only [hs,ha,hm,hn]

end Optss
