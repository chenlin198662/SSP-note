import Optss.ProgressionCoordinates

/-!
# Removing zero-width GAP coordinates

The same explicit coordinate restriction used for signed-budget preprocessing
gives an exact smaller integer GAP. It preserves values, coefficient volume,
and properness of every integer dilation, including dilation zero.
-/

namespace Optss
noncomputable section
open scoped Classical
variable {G : Type*} [AddCommGroup G] [DecidableEq G]
variable {d : ℕ}

def restorePositiveHom (β : Fin d → ℕ) :
    IntVec (Fintype.card (PositiveCoordinate β)) →+ IntVec d where
  toFun := restorePositiveCoordinates β
  map_zero' := by ext j; simp [restorePositiveCoordinates]
  map_add' x y := by
    ext j
    by_cases hj : 0 < β j <;> simp [restorePositiveCoordinates, hj]

theorem restorePositive_injective (β : Fin d → ℕ) :
    Function.Injective (restorePositiveCoordinates β) :=
  Function.LeftInverse.injective (restrict_restorePositiveCoordinates β)

theorem positiveCoordinate_count_le (β : Fin d → ℕ) :
    Fintype.card (PositiveCoordinate β) ≤ d := by
  simpa using Fintype.card_subtype_le (fun j : Fin d => 0 < β j)

theorem restore_restrict_scaledBox (β : Fin d → ℕ) (t : ℕ) (x : IntVec d)
    (hx : x ∈ integerBudgetBox (fun j => t*β j)) :
    restorePositiveCoordinates β (restrictPositiveCoordinates β x) = x := by
  ext j
  by_cases hj : 0 < β j
  · simp [restorePositiveCoordinates, restrictPositiveCoordinates, positiveCoordinateIndex, hj]
  · have hz : β j=0 := Nat.eq_zero_of_not_pos hj
    have hxj := (mem_integerBudgetBox _ _).mp hx j
    simp only [hz, mul_zero, Int.natCast_zero, abs_nonpos_iff] at hxj
    simp [restorePositiveCoordinates, hj, hxj]

theorem restrictPositive_scaledBox (β : Fin d → ℕ) (t : ℕ) (x : IntVec d)
    (hx : x ∈ integerBudgetBox (fun j => t*β j)) :
    restrictPositiveCoordinates β x ∈ integerBudgetBox (fun j => t*positiveBudget β j) := by
  rw [mem_integerBudgetBox]
  intro j
  exact (mem_integerBudgetBox _ _).mp hx (positiveCoordinateIndex β j)

theorem restorePositive_scaledBox (β : Fin d → ℕ) (t : ℕ)
    (x : IntVec (Fintype.card (PositiveCoordinate β)))
    (hx : x ∈ integerBudgetBox (fun j => t*positiveBudget β j)) :
    restorePositiveCoordinates β x ∈ integerBudgetBox (fun j => t*β j) := by
  rw [mem_integerBudgetBox]
  intro j
  by_cases hj : 0 < β j
  · have h := (mem_integerBudgetBox _ _).mp hx (Fintype.equivFin (PositiveCoordinate β) ⟨j,hj⟩)
    simpa only [restorePositiveCoordinates, dif_pos hj, positiveBudget, positiveCoordinateIndex,
      Equiv.symm_apply_apply] using h
  · simp only [restorePositiveCoordinates, dif_neg hj, abs_zero]
    positivity

theorem scaledBox_eq_image_positive (β : Fin d → ℕ) (t : ℕ) :
    integerBudgetBox (fun j => t*β j) =
      (integerBudgetBox (fun j => t*positiveBudget β j)).image (restorePositiveCoordinates β) := by
  ext x
  constructor
  · intro hx
    exact Finset.mem_image.mpr ⟨restrictPositiveCoordinates β x,
      restrictPositive_scaledBox β t x hx, restore_restrict_scaledBox β t x hx⟩
  · rintro hx
    obtain ⟨z, hz, rfl⟩ := Finset.mem_image.mp hx
    exact restorePositive_scaledBox β t z hz

theorem scaledBox_positive_card (β : Fin d → ℕ) (t : ℕ) :
    (integerBudgetBox (fun j => t*β j)).card =
      (integerBudgetBox (fun j => t*positiveBudget β j)).card := by
  rw [scaledBox_eq_image_positive]
  exact Finset.card_image_of_injective _ (restorePositive_injective β)

def positiveProgressionHom (ρ : IntVec d →+ G) (β : Fin d → ℕ) :
    IntVec (Fintype.card (PositiveCoordinate β)) →+ G := ρ.comp (restorePositiveHom β)

theorem positiveProgression_values (ρ : IntVec d →+ G) (β : Fin d → ℕ) (t : ℕ) :
    integerProgressionValues ρ (fun j => t*β j) =
      integerProgressionValues (positiveProgressionHom ρ β) (fun j => t*positiveBudget β j) := by
  unfold integerProgressionValues
  rw [scaledBox_eq_image_positive, Finset.image_image]
  rfl

theorem positiveProgression_proper_iff (ρ : IntVec d →+ G) (β : Fin d → ℕ) (t : ℕ) :
    Set.InjOn ρ (integerBudgetBox (fun j => t*β j)) ↔
      Set.InjOn (positiveProgressionHom ρ β)
        (integerBudgetBox (fun j => t*positiveBudget β j)) := by
  constructor
  · intro h x hx y hy he
    apply restorePositive_injective β
    exact h (restorePositive_scaledBox β t x hx) (restorePositive_scaledBox β t y hy) he
  · intro h x hx y hy he
    have he' : positiveProgressionHom ρ β (restrictPositiveCoordinates β x) =
        positiveProgressionHom ρ β (restrictPositiveCoordinates β y) := by
      change ρ (restorePositiveCoordinates β (restrictPositiveCoordinates β x)) =
        ρ (restorePositiveCoordinates β (restrictPositiveCoordinates β y))
      rwa [restore_restrict_scaledBox β t x hx, restore_restrict_scaledBox β t y hy]
    have hres := h (restrictPositive_scaledBox β t x hx) (restrictPositive_scaledBox β t y hy) he'
    have heq := congrArg (restorePositiveCoordinates β) hres
    simpa only [restore_restrict_scaledBox β t x hx, restore_restrict_scaledBox β t y hy] using heq

end
end Optss
