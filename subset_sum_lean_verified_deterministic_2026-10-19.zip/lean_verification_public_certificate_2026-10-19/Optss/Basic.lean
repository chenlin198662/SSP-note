import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Module.Pi
import Mathlib.Tactic

/-!
# Exact finite subset-sum semantics

This file formalizes the copy-labelled interpretation in §2.1 and the integer
count interpretation in §9.1. It makes no assertion about algorithmic complexity.
-/

namespace Optss

open scoped BigOperators

abbrev IntVec (d : ℕ) := Fin d → ℤ

variable {ι G : Type*} [Fintype ι] [AddCommGroup G]

/-- Integer counts respect every multiplicity, including zero capacities. -/
def BoundedCounts (c x : ι → ℤ) : Prop := ∀ i, 0 ≤ x i ∧ x i ≤ c i

/-- Sum of labelled types with integer coefficients. -/
def weightedSum (v : ι → G) (x : ι → ℤ) : G := ∑ i, x i • v i

/-- Subset-sum support for types stored with integer multiplicities. -/
def countSums (v : ι → G) (c : ι → ℤ) : Set G :=
  {t | ∃ x, BoundedCounts c x ∧ weightedSum v x = t}

/-- Each element of the finite index type is a separate input copy. -/
def subsetSums (v : ι → G) : Set G :=
  {t | ∃ s : Finset ι, ∑ i ∈ s, v i = t}

/-- Feasibility for an exact set of targets, as in §2.2. -/
def Feasible (v : ι → G) (c : ι → ℤ) (T : Set G) : Prop :=
  ∃ t, t ∈ T ∧ t ∈ countSums v c

/-- The paper's set difference `T - S` is a Minkowski difference, not set subtraction. -/
def targetShift (T S : Set G) : Set G := {r | ∃ t ∈ T, ∃ s ∈ S, r = t - s}

@[simp] theorem weightedSum_zero (v : ι → G) : weightedSum v (fun _ => 0) = 0 := by
  simp [weightedSum]

theorem weightedSum_add (v : ι → G) (x y : ι → ℤ) :
    weightedSum v (fun i => x i + y i) = weightedSum v x + weightedSum v y := by
  simp [weightedSum, add_zsmul, Finset.sum_add_distrib]

theorem weightedSum_sub (v : ι → G) (x y : ι → ℤ) :
    weightedSum v (fun i => x i - y i) = weightedSum v x - weightedSum v y := by
  simp only [weightedSum, sub_eq_add_neg, add_zsmul, neg_zsmul,
    Finset.sum_add_distrib, Finset.sum_neg_distrib]

theorem zero_mem_countSums (v : ι → G) {c : ι → ℤ} (hc : ∀ i, 0 ≤ c i) :
    0 ∈ countSums v c := by
  exact ⟨fun _ => 0, fun i => ⟨le_rfl, hc i⟩, weightedSum_zero v⟩

theorem countSums_mono (v : ι → G) {c d : ι → ℤ} (h : ∀ i, c i ≤ d i) :
    countSums v c ⊆ countSums v d := by
  rintro t ⟨x, hx, rfl⟩
  exact ⟨x, fun i => ⟨(hx i).1, (hx i).2.trans (h i)⟩, rfl⟩

theorem mem_subsetSums_iff_binary (v : ι → G) (t : G) :
    t ∈ subsetSums v ↔ t ∈ countSums v (fun _ => 1) := by
  classical
  constructor
  · rintro ⟨s, rfl⟩
    refine ⟨fun i => if i ∈ s then 1 else 0, ?_, ?_⟩
    · intro i
      dsimp
      split_ifs <;> omega
    · simp [weightedSum, Finset.sum_ite_mem]
  · rintro ⟨x, hx, rfl⟩
    refine ⟨Finset.univ.filter (fun i => x i = 1), ?_⟩
    rw [Finset.sum_filter]
    unfold weightedSum
    apply Finset.sum_congr rfl
    intro i _
    have hxi := hx i
    dsimp at hxi
    by_cases h : x i = 1
    · simp [h]
    · have hz : x i = 0 := by omega
      simp [hz]

/-- Algebraic heart of Lemmas 2.2 and 9.3(iv): split the available copies. -/
theorem mem_countSums_add_iff (v : ι → G) (c d : ι → ℤ)
    (hc : ∀ i, 0 ≤ c i) (hd : ∀ i, 0 ≤ d i) (t : G) :
    t ∈ countSums v (fun i => c i + d i) ↔
      ∃ a ∈ countSums v c, ∃ b ∈ countSums v d, a + b = t := by
  constructor
  · rintro ⟨x, hx, rfl⟩
    let p : ι → ℤ := fun i => min (x i) (c i)
    let q : ι → ℤ := fun i => x i - p i
    have hp : BoundedCounts c p := by
      intro i
      exact ⟨le_min (hx i).1 (hc i), min_le_right _ _⟩
    have hq : BoundedCounts d q := by
      intro i
      dsimp [q, p]
      have hi := hx i
      dsimp at hi
      have hdi := hd i
      constructor
      · exact sub_nonneg.mpr (min_le_left _ _)
      · by_cases h : x i ≤ c i
        · rw [min_eq_left h]
          simpa using hdi
        · rw [min_eq_right (le_of_not_ge h)]
          omega
    refine ⟨weightedSum v p, ⟨p, hp, rfl⟩, weightedSum v q, ⟨q, hq, rfl⟩, ?_⟩
    rw [← weightedSum_add]
    congr 1
    funext i
    dsimp [q]
    omega
  · rintro ⟨a, ⟨x, hx, rfl⟩, b, ⟨y, hy, rfl⟩, rfl⟩
    refine ⟨fun i => x i + y i, ?_, weightedSum_add v x y⟩
    intro i
    exact ⟨add_nonneg (hx i).1 (hy i).1, add_le_add (hx i).2 (hy i).2⟩

/-- Exact answer preservation when designated multiplicities are removed.
This is the logical conclusion of Lemma 2.2 / Lemma 9.3(iv), without a cost claim. -/
theorem remove_counts_iff (v : ι → G) (c e : ι → ℤ) (he : BoundedCounts c e)
    (T : Set G) :
    Feasible v c T ↔ Feasible v (fun i => c i - e i) (targetShift T (countSums v e)) := by
  have hr : ∀ i, 0 ≤ c i - e i := fun i => sub_nonneg.mpr (he i).2
  have hc : (fun i => e i + (c i - e i)) = c := by funext i; omega
  constructor
  · rintro ⟨t, ht, hs⟩
    rw [← hc] at hs
    rcases (mem_countSums_add_iff v e (fun i => c i - e i) (fun i => (he i).1) hr t).mp hs with
      ⟨a, ha, b, hb, hab⟩
    refine ⟨b, ⟨t, ht, a, ha, ?_⟩, hb⟩
    exact eq_sub_iff_add_eq.mpr (by simpa [add_comm] using hab)
  · rintro ⟨b, ⟨t, ht, a, ha, hba⟩, hb⟩
    refine ⟨t, ht, ?_⟩
    rw [← hc]
    apply (mem_countSums_add_iff v e (fun i => c i - e i) (fun i => (he i).1) hr t).mpr
    exact ⟨a, ha, b, hb, by rw [hba]; abel⟩

end Optss
