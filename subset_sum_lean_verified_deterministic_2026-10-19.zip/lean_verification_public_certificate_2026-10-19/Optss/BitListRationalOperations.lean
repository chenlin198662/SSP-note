import Optss.BitRationalRepresentation
import Optss.BitListMultiplication

/-!
# Signed rational operations on Boolean-list fractions

All answer routines manipulate explicit bit lists and Boolean signs. Decoding
is used only by correctness statements. Normalization uses the verified list
gcd and division routines, including zero and negative numerators.
-/

namespace Optss

/-- Signed difference using the final ripple borrow to choose its sign. -/
def bitListSignedDiff (negative : Bool) (xs ys : List Bool) : Bool × List Bool :=
  let diff := bitListSubAux false xs ys
  if diff.borrow then (!negative, bitListTrim (bitListSub ys xs))
  else (negative, bitListTrim diff.digits)

theorem bitListSignedDiff_correct (negative : Bool) (xs ys : List Bool) :
    signedBitsValue (bitListSignedDiff negative xs ys).1 (bitListSignedDiff negative xs ys).2 =
      signedBitsValue negative xs-signedBitsValue negative ys := by
  have he := bitListSubAux_correct xs ys false
  unfold bitListSignedDiff
  dsimp only
  split_ifs with h
  · have hlt := (bitListSub_borrow_iff xs ys).mp h
    cases negative <;> simp only [signedBitsValue, Bool.not_false, Bool.not_true,
      Bool.false_eq_true, ↓reduceIte, bitListTrim_value, bitListSub_correct]
    all_goals (rw [Int.ofNat_sub hlt.le]; ring)
  · have hf : (bitListSubAux false xs ys).borrow = false := Bool.eq_false_iff.mpr h
    rw [hf] at he
    simp only [Bool.toNat_false, mul_zero, add_zero] at he
    have hz : (binaryDigitsValue (bitListSubAux false xs ys).digits:ℤ) =
        (binaryDigitsValue xs:ℤ)-(binaryDigitsValue ys:ℤ) := by omega
    cases negative <;> simp only [signedBitsValue, Bool.false_eq_true, ↓reduceIte, bitListTrim_value]
    all_goals (rw [hz] <;> ring)

/-- Signed addition uses ripple addition for equal signs, subtraction otherwise. -/
def bitListSignedAdd (s t : Bool) (xs ys : List Bool) : Bool × List Bool :=
  if s = t then (s, bitListAdd xs ys) else bitListSignedDiff s xs ys

theorem bitListSignedAdd_correct (s t : Bool) (xs ys : List Bool) :
    signedBitsValue (bitListSignedAdd s t xs ys).1 (bitListSignedAdd s t xs ys).2 =
      signedBitsValue s xs+signedBitsValue t ys := by
  unfold bitListSignedAdd
  split_ifs with h
  · subst t
    cases s <;> simp [signedBitsValue, bitListAdd_correct, Int.natCast_add]
    all_goals ring
  · rw [bitListSignedDiff_correct]
    cases s <;> cases t <;> simp_all [signedBitsValue]
    all_goals ring

theorem bitListSignedDiff_length (s : Bool) (xs ys : List Bool) :
    (bitListSignedDiff s xs ys).2.length ≤ max xs.length ys.length := by
  unfold bitListSignedDiff
  dsimp only
  split_ifs
  · exact (bitListTrim_length_le _).trans ((bitListSub_length_le ys xs).trans_eq (max_comm _ _))
  · exact (bitListTrim_length_le _).trans_eq (bitListSubAux_length xs ys false)

theorem bitListSignedAdd_length (s t : Bool) (xs ys : List Bool) :
    (bitListSignedAdd s t xs ys).2.length ≤ max xs.length ys.length+1 := by
  unfold bitListSignedAdd
  split_ifs
  · exact (bitListTrim_length_le _).trans (bitListAddAux_length xs ys false)
  · exact (bitListSignedDiff_length s xs ys).trans (by omega)

theorem signedBitsValue_mul_right (s : Bool) (xs ys : List Bool) :
    signedBitsValue s (bitListMultiplication xs ys) =
      signedBitsValue s xs * (binaryDigitsValue ys:ℤ) := by
  cases s <;> simp [signedBitsValue, bitListMultiplication_correct, Int.natCast_mul]

theorem signedBitsValue_xor_mul (s t : Bool) (xs ys : List Bool) :
    signedBitsValue (Bool.xor s t) (bitListMultiplication xs ys) =
      signedBitsValue s xs * signedBitsValue t ys := by
  cases s <;> cases t <;> simp [signedBitsValue, bitListMultiplication_correct, Int.natCast_mul]

def bitListFractionNeg (p : BitListFraction) : BitListFraction :=
  ⟨!p.negative,p.numerator,p.denominator⟩

def bitListFractionMul (p q : BitListFraction) : BitListFraction :=
  bitListNormalizeFraction (Bool.xor p.negative q.negative)
    (bitListMultiplication p.numerator q.numerator)
    (bitListMultiplication p.denominator q.denominator)

def bitListFractionAdd (p q : BitListFraction) : BitListFraction :=
  let x := bitListMultiplication p.numerator q.denominator
  let y := bitListMultiplication q.numerator p.denominator
  let sum := bitListSignedAdd p.negative q.negative x y
  bitListNormalizeFraction sum.1 sum.2 (bitListMultiplication p.denominator q.denominator)

def bitListFractionSub (p q : BitListFraction) : BitListFraction :=
  bitListFractionAdd p (bitListFractionNeg q)

def bitListFractionZero : BitListFraction := ⟨false,[],[true]⟩

/-- Division by zero follows the rational field convention and returns 0/1. -/
def bitListFractionDiv (p q : BitListFraction) : BitListFraction :=
  let qn := bitListTrim q.numerator
  if qn.isEmpty then bitListFractionZero else
    bitListNormalizeFraction (Bool.xor p.negative q.negative)
      (bitListMultiplication p.numerator q.denominator)
      (bitListMultiplication p.denominator qn)

theorem bitListFractionNeg_correct (p : BitListFraction) :
    bitListFractionValue (bitListFractionNeg p) = -bitListFractionValue p := by
  unfold bitListFractionNeg bitListFractionValue signedBitsValue
  cases p.negative <;> simp <;> ring

theorem bitListFractionMul_correct (p q : BitListFraction) (hp : 0 < binaryDigitsValue p.denominator) (hq : 0 < binaryDigitsValue q.denominator) :
    bitListFractionValue (bitListFractionMul p q) = bitListFractionValue p*bitListFractionValue q := by
  unfold bitListFractionMul
  rw [bitListNormalizeFraction_correct _ _ _ (by
    rw [bitListMultiplication_correct]; exact Nat.mul_pos hp hq)]
  rw [signedBitsValue_xor_mul, bitListMultiplication_correct]
  simp only [Int.cast_mul, Nat.cast_mul, bitListFractionValue, div_mul_div_comm]

theorem bitListFractionAdd_correct (p q : BitListFraction) (hp : 0 < binaryDigitsValue p.denominator) (hq : 0 < binaryDigitsValue q.denominator) :
    bitListFractionValue (bitListFractionAdd p q) = bitListFractionValue p+bitListFractionValue q := by
  unfold bitListFractionAdd
  dsimp only
  rw [bitListNormalizeFraction_correct _ _ _ (by
    rw [bitListMultiplication_correct]; exact Nat.mul_pos hp hq)]
  rw [bitListSignedAdd_correct, signedBitsValue_mul_right, signedBitsValue_mul_right,
    bitListMultiplication_correct]
  have hp' : (binaryDigitsValue p.denominator:ℚ) ≠ 0 := by exact_mod_cast hp.ne'
  have hq' : (binaryDigitsValue q.denominator:ℚ) ≠ 0 := by exact_mod_cast hq.ne'
  simp only [Int.cast_add, Int.cast_mul, Int.cast_natCast, Nat.cast_mul, bitListFractionValue]
  field_simp

theorem bitListFractionSub_correct (p q : BitListFraction) (hp : 0 < binaryDigitsValue p.denominator) (hq : 0 < binaryDigitsValue q.denominator) :
    bitListFractionValue (bitListFractionSub p q) = bitListFractionValue p-bitListFractionValue q := by
  rw [bitListFractionSub, bitListFractionAdd_correct p (bitListFractionNeg q) hp hq, bitListFractionNeg_correct, sub_eq_add_neg]

@[simp] theorem bitListFractionZero_value : bitListFractionValue bitListFractionZero = 0 := by
  simp [bitListFractionZero, bitListFractionValue, signedBitsValue, binaryDigitsValue]

theorem bitListFractionDiv_correct (p q : BitListFraction) (hp : 0 < binaryDigitsValue p.denominator) (hq : 0 < binaryDigitsValue q.denominator) :
    bitListFractionValue (bitListFractionDiv p q) = bitListFractionValue p/bitListFractionValue q := by
  unfold bitListFractionDiv
  dsimp only
  split_ifs with hz
  · have hn : binaryDigitsValue q.numerator = 0 := by
      have he := List.isEmpty_iff.mp hz
      have hv := bitListTrim_value q.numerator
      rw [he] at hv
      exact hv.symm
    have hqz : bitListFractionValue q = 0 := by simp [bitListFractionValue, signedBitsValue, hn]
    rw [bitListFractionZero_value, hqz, div_zero]
  · have hqn : 0 < binaryDigitsValue (bitListTrim q.numerator) :=
      (bitListTrim_canonical _).pos_of_not_empty hz
    rw [bitListNormalizeFraction_correct _ _ _ (by
      rw [bitListMultiplication_correct]; exact Nat.mul_pos hp hqn)]
    rw [bitListMultiplication_correct]
    have ht : signedBitsValue q.negative (bitListTrim q.numerator) = signedBitsValue q.negative q.numerator := by
      simp only [signedBitsValue, bitListTrim_value]
    have hn : (binaryDigitsValue q.numerator:ℚ) ≠ 0 := by
      rw [bitListTrim_value] at hqn
      exact_mod_cast hqn.ne'
    have hp' : (binaryDigitsValue p.denominator:ℚ) ≠ 0 := by exact_mod_cast hp.ne'
    have hq' : (binaryDigitsValue q.denominator:ℚ) ≠ 0 := by exact_mod_cast hq.ne'
    unfold bitListFractionValue signedBitsValue
    cases p.negative <;> cases q.negative <;>
      simp only [Bool.xor_false, Bool.xor_true, Bool.not_false, Bool.not_true,
        Bool.false_eq_true, ↓reduceIte, bitListMultiplication_correct, bitListTrim_value,
        Int.cast_neg, Int.cast_natCast, Nat.cast_mul] <;> field_simp

@[simp] theorem bitListFractionZero_wellFormed : bitListFractionZero.WellFormed := by
  norm_num [BitListFraction.WellFormed, bitListFractionZero, BitListCanonical, binaryDigitsValue]

theorem bitListFractionNeg_wellFormed (p : BitListFraction) (hp : p.WellFormed) :
    (bitListFractionNeg p).WellFormed := hp

theorem bitListFractionMul_wellFormed (p q : BitListFraction)
    (hp : 0 < binaryDigitsValue p.denominator) (hq : 0 < binaryDigitsValue q.denominator) :
    (bitListFractionMul p q).WellFormed := by
  apply bitListNormalizeFraction_wellFormed
  rw [bitListMultiplication_correct]
  exact Nat.mul_pos hp hq

theorem bitListFractionAdd_wellFormed (p q : BitListFraction)
    (hp : 0 < binaryDigitsValue p.denominator) (hq : 0 < binaryDigitsValue q.denominator) :
    (bitListFractionAdd p q).WellFormed := by
  apply bitListNormalizeFraction_wellFormed
  rw [bitListMultiplication_correct]
  exact Nat.mul_pos hp hq

theorem bitListFractionSub_wellFormed (p q : BitListFraction)
    (hp : 0 < binaryDigitsValue p.denominator) (hq : 0 < binaryDigitsValue q.denominator) :
    (bitListFractionSub p q).WellFormed := bitListFractionAdd_wellFormed p (bitListFractionNeg q) hp hq

theorem bitListFractionDiv_wellFormed (p q : BitListFraction)
    (hp : 0 < binaryDigitsValue p.denominator) : (bitListFractionDiv p q).WellFormed := by
  unfold bitListFractionDiv
  dsimp only
  split_ifs with hz
  · exact bitListFractionZero_wellFormed
  · apply bitListNormalizeFraction_wellFormed
    rw [bitListMultiplication_correct]
    exact Nat.mul_pos hp ((bitListTrim_canonical _).pos_of_not_empty hz)

/-- Concrete gate/list count of one unsigned product. -/
def bitListProductWork (xs ys : List Bool) : ℕ :=
  bitListMultiplicationGates xs ys+bitListMultiplicationVisits xs ys

/-- Work semantics of the signed-difference branches. -/
def bitListSignedDiffCost (xs ys : List Bool) : ℕ :=
  let diff := bitListSubAux false xs ys
  bitListRippleGates 8 xs ys+bitListSubVisits xs ys+3+
    if diff.borrow then
      bitListRippleGates 8 ys xs+bitListSubVisits ys xs+bitListTrimVisits (bitListSub ys xs)
    else bitListTrimVisits diff.digits

def bitListSignedAddCost (s t : Bool) (xs ys : List Bool) : ℕ :=
  if s = t then bitListRippleGates 6 xs ys+bitListAddVisits xs ys+
    bitListTrimVisits (bitListAddAux false xs ys)+1 else bitListSignedDiffCost xs ys+1

theorem bitListSignedDiffCost_bound (xs ys : List Bool) (L : ℕ)
    (hx : xs.length ≤ L) (hy : ys.length ≤ L) : bitListSignedDiffCost xs ys ≤ 25*(L+1) := by
  have hm : max xs.length ys.length ≤ L := max_le hx hy
  have ht := bitListSub_length_le ys xs
  unfold bitListSignedDiffCost
  dsimp only
  split_ifs <;> simp only [bitListRippleGates_eq, bitListSubVisits_eq,
    bitListTrimVisits_eq, bitListSubAux_length] <;> omega

theorem bitListSignedAddCost_bound (s t : Bool) (xs ys : List Bool) (L : ℕ)
    (hx : xs.length ≤ L) (hy : ys.length ≤ L) : bitListSignedAddCost s t xs ys ≤ 30*(L+1) := by
  have hm : max xs.length ys.length ≤ L := max_le hx hy
  have ht := bitListAddAux_length xs ys false
  unfold bitListSignedAddCost
  split_ifs
  · simp only [bitListRippleGates_eq, bitListAddVisits_eq, bitListTrimVisits_eq]
    omega
  · have h := bitListSignedDiffCost_bound xs ys L hx hy
    omega

/-- Operation work sums actual product, signed-addition and normalization
counts; the fixed overhead covers sign and record/control operations. -/
def bitListFractionMulCost (p q : BitListFraction) : ℕ :=
  bitListProductWork p.numerator q.numerator+bitListProductWork p.denominator q.denominator+
    bitListNormalizeFractionCost (bitListMultiplication p.numerator q.numerator)
      (bitListMultiplication p.denominator q.denominator)+1

def bitListFractionAddCost (p q : BitListFraction) : ℕ :=
  let x := bitListMultiplication p.numerator q.denominator
  let y := bitListMultiplication q.numerator p.denominator
  let sum := bitListSignedAdd p.negative q.negative x y
  bitListProductWork p.numerator q.denominator+bitListProductWork q.numerator p.denominator+
    bitListProductWork p.denominator q.denominator+bitListSignedAddCost p.negative q.negative x y+
      bitListNormalizeFractionCost sum.2 (bitListMultiplication p.denominator q.denominator)+1

def bitListFractionSubCost (p q : BitListFraction) : ℕ :=
  bitListFractionAddCost p (bitListFractionNeg q)+1

def bitListFractionDivCost (p q : BitListFraction) : ℕ :=
  let qn := bitListTrim q.numerator
  bitListTrimVisits q.numerator + if qn.isEmpty then 1 else
    bitListProductWork p.numerator q.denominator+bitListProductWork p.denominator qn+
      bitListNormalizeFractionCost (bitListMultiplication p.numerator q.denominator)
        (bitListMultiplication p.denominator qn)+3

theorem bitListFractionMulCost_bound (p q : BitListFraction)
    (hp : 0 < binaryDigitsValue p.denominator) (hq : 0 < binaryDigitsValue q.denominator)
    (L : ℕ) (hpl : p.numerator.length ≤ L ∧ p.denominator.length ≤ L)
    (hql : q.numerator.length ≤ L ∧ q.denominator.length ≤ L) :
    bitListFractionMulCost p q ≤ 2048*(L+1)^3 := by
  have hn := bitListMultiplication_uniform_cost p.numerator q.numerator L hpl.1 hql.1
  have hd := bitListMultiplication_uniform_cost p.denominator q.denominator L hpl.2 hql.2
  have hnlen : (bitListMultiplication p.numerator q.numerator).length ≤ 2*L :=
    (bitListMultiplication_length_le _ _).trans (by omega)
  have hdlen : (bitListMultiplication p.denominator q.denominator).length ≤ 2*L :=
    (bitListMultiplication_length_le _ _).trans (by omega)
  have hdpos : 0 < binaryDigitsValue (bitListMultiplication p.denominator q.denominator) := by
    rw [bitListMultiplication_correct]; exact Nat.mul_pos hp hq
  have hc := bitListNormalizeFractionCost_bound _ _ hdpos (2*L) hnlen hdlen
  unfold bitListFractionMulCost bitListProductWork
  nlinarith [show 1 ≤ (L+1)^2 by nlinarith]

theorem bitListFractionAddCost_bound (p q : BitListFraction)
    (hp : 0 < binaryDigitsValue p.denominator) (hq : 0 < binaryDigitsValue q.denominator)
    (L : ℕ) (hpl : p.numerator.length ≤ L ∧ p.denominator.length ≤ L)
    (hql : q.numerator.length ≤ L ∧ q.denominator.length ≤ L) :
    bitListFractionAddCost p q ≤ 2048*(L+1)^3 := by
  let x := bitListMultiplication p.numerator q.denominator
  let y := bitListMultiplication q.numerator p.denominator
  let sum := bitListSignedAdd p.negative q.negative x y
  have hx : x.length ≤ 2*L := (bitListMultiplication_length_le _ _).trans (by omega)
  have hy : y.length ≤ 2*L := (bitListMultiplication_length_le _ _).trans (by omega)
  have hs : sum.2.length ≤ 2*L+1 := (bitListSignedAdd_length _ _ _ _).trans (by omega)
  have hd : (bitListMultiplication p.denominator q.denominator).length ≤ 2*L+1 :=
    (bitListMultiplication_length_le _ _).trans (by omega)
  have hdpos : 0 < binaryDigitsValue (bitListMultiplication p.denominator q.denominator) := by
    rw [bitListMultiplication_correct]; exact Nat.mul_pos hp hq
  have hc := bitListNormalizeFractionCost_bound sum.2 _ hdpos (2*L+1) hs hd
  have hsc := bitListSignedAddCost_bound p.negative q.negative x y (2*L) hx hy
  have h₁ := bitListMultiplication_uniform_cost p.numerator q.denominator L hpl.1 hql.2
  have h₂ := bitListMultiplication_uniform_cost q.numerator p.denominator L hql.1 hpl.2
  have h₃ := bitListMultiplication_uniform_cost p.denominator q.denominator L hpl.2 hql.2
  change _+_+_+bitListSignedAddCost p.negative q.negative x y+
    bitListNormalizeFractionCost sum.2 _+1 ≤ _
  unfold bitListProductWork
  nlinarith [show 1 ≤ (L+1)^2 by nlinarith]

theorem bitListFractionSubCost_bound (p q : BitListFraction)
    (hp : 0 < binaryDigitsValue p.denominator) (hq : 0 < binaryDigitsValue q.denominator)
    (L : ℕ) (hpl : p.numerator.length ≤ L ∧ p.denominator.length ≤ L)
    (hql : q.numerator.length ≤ L ∧ q.denominator.length ≤ L) :
    bitListFractionSubCost p q ≤ 4096*(L+1)^3 := by
  have h := bitListFractionAddCost_bound p (bitListFractionNeg q) hp hq L hpl hql
  unfold bitListFractionSubCost
  nlinarith [show 1 ≤ (L+1)^3 by exact one_le_pow₀ (by omega)]

theorem bitListFractionDivCost_bound (p q : BitListFraction)
    (hp : 0 < binaryDigitsValue p.denominator)
    (L : ℕ) (hpl : p.numerator.length ≤ L ∧ p.denominator.length ≤ L)
    (hql : q.numerator.length ≤ L ∧ q.denominator.length ≤ L) :
    bitListFractionDivCost p q ≤ 2048*(L+1)^3 := by
  unfold bitListFractionDivCost
  dsimp only
  split_ifs with hz
  · rw [bitListTrimVisits_eq]
    nlinarith [hql.1, show 1 ≤ (L+1)^2 by nlinarith]
  · let qn := bitListTrim q.numerator
    have hqn : qn.length ≤ L := (bitListTrim_length_le _).trans hql.1
    have hqp := (bitListTrim_canonical q.numerator).pos_of_not_empty hz
    have hx : (bitListMultiplication p.numerator q.denominator).length ≤ 2*L :=
      (bitListMultiplication_length_le _ _).trans (by omega)
    have hy : (bitListMultiplication p.denominator qn).length ≤ 2*L :=
      (bitListMultiplication_length_le _ _).trans (by omega)
    have hdpos : 0 < binaryDigitsValue (bitListMultiplication p.denominator qn) := by
      rw [bitListMultiplication_correct]; exact Nat.mul_pos hp hqp
    have hc := bitListNormalizeFractionCost_bound _ _ hdpos (2*L) hx hy
    have h₁ := bitListMultiplication_uniform_cost p.numerator q.denominator L hpl.1 hql.2
    have h₂ := bitListMultiplication_uniform_cost p.denominator qn L hpl.2 hqn
    rw [bitListTrimVisits_eq]
    change _+(_+_+bitListNormalizeFractionCost _ (bitListMultiplication p.denominator qn)+3) ≤ _
    unfold bitListProductWork
    nlinarith [hql.1, show 1 ≤ (L+1)^2 by nlinarith]

end Optss
