import Optss.ColorSupport
import Optss.ColorProbability

/-!
# Probability of retaining an actual color-coded support witness

The failure event is defined using the actual output of the finite support
construction. Its probability is bounded by collision events in the explicit
independent uniform coloring sample space. The first random hashing stage and
its bucket-load concentration bound are separate dependencies.
-/

namespace Optss
open scoped BigOperators
noncomputable section

variable {ι G : Type*} [Fintype ι] [DecidableEq ι] [AddCommGroup G] [DecidableEq G]

/-- Actual failure of the computed, finally clipped support to retain a target. -/
def colorSupportFailure (v : ι → G) (S : Finset ι) (t : G)
    {b : ℕ} (bucket : ι → Fin b) (B : Set G) [DecidablePred B] (L R : ℕ) :
    Finset (Fin b → Fin R → ι → Fin (128*L^2)) := by
  classical
  exact Finset.univ.filter (fun color => t ∉ clippedBucketColorSupport v S bucket color B)

/-- A missing fixed witness implies all repetitions collided in some bucket.
Different buckets are allowed to retain it through different repetitions. -/
theorem colorSupportFailure_subset_collision (v : ι → G) (S s : Finset ι)
    {b : ℕ} (bucket : ι → Fin b) (B : Set G) [DecidablePred B] (L R : ℕ)
    (hs : s ⊆ S) (hB : (∑ i ∈ s, v i) ∈ B) :
    colorSupportFailure v S (∑ i ∈ s, v i) bucket B L R ⊆
      bucketCollisionEvent b L R (fun j => s.filter (fun i => bucket i = j)) := by
  classical
  intro color hcolor
  have hfail := (Finset.mem_filter.mp hcolor).2
  apply Classical.byContradiction
  intro hnot
  have hgood : ∀ p, ∃ a, Set.InjOn (color p a)
      (↑(s.filter (fun i => bucket i = p)) : Set ι) := by
    intro p
    apply Classical.byContradiction
    intro hn
    push_neg at hn
    apply hnot
    exact (mem_bucketCollisionEvent b L R _ color).mpr ⟨p, hn⟩
  exact hfail (clippedBucketColorSupport_retains v S s bucket color B hs hB hgood)

/-- With bucket loads bounded by `8L`, the actual support loses a fixed in-box
witness with probability at most `b*(1/4)^R` under independent repeated colors. -/
theorem uniform_colorSupportFailure_le (v : ι → G) (S s : Finset ι)
    {b : ℕ} (bucket : ι → Fin b) (B : Set G) [DecidablePred B] (L R : ℕ)
    (hL : 0 < L) (hs : s ⊆ S) (hB : (∑ i ∈ s, v i) ∈ B)
    (hload : ∀ j, (s.filter (fun i => bucket i = j)).card ≤ 8*L) :
    uniformProbability (colorSupportFailure v S (∑ i ∈ s, v i) bucket B L R) ≤
      b * (1/4 : ℝ)^R := by
  exact (uniformProbability_mono
    (colorSupportFailure_subset_collision v S s bucket B L R hs hB)).trans
    (uniform_bucket_collision_bound b L R _ hL hload)

/-- An explicit power-of-two repetition condition supplies the paper's second
failure allowance, without requiring a real logarithm in the algorithm. -/
theorem uniform_colorSupportFailure_le_allowance (v : ι → G) (S s : Finset ι)
    {b : ℕ} (bucket : ι → Fin b) (B : Set G) [DecidablePred B] (L R : ℕ)
    (hL : 0 < L) (hs : s ⊆ S) (hB : (∑ i ∈ s, v i) ∈ B)
    (hload : ∀ j, (s.filter (fun i => bucket i = j)).card ≤ 8*L)
    (ζ : ℝ) (hR : 2*(b:ℝ) ≤ ζ*2^R) :
    uniformProbability (colorSupportFailure v S (∑ i ∈ s, v i) bucket B L R) ≤ ζ/2 := by
  refine (uniform_colorSupportFailure_le v S s bucket B L R hL hs hB hload).trans ?_
  have hpow : (1/4 : ℝ)^R ≤ (1/2 : ℝ)^R := pow_le_pow_left₀ (by norm_num) (by norm_num) R
  have hpowpos : (0:ℝ) < 2^R := by positivity
  calc
    (b:ℝ)*(1/4:ℝ)^R ≤ b*(1/2:ℝ)^R := mul_le_mul_of_nonneg_left hpow (by positivity)
    _ = (b:ℝ)/2^R := by rw [one_div_pow, mul_one_div]
    _ ≤ ζ/2 := by apply (div_le_iff₀ hpowpos).mpr; nlinarith

end
end Optss
