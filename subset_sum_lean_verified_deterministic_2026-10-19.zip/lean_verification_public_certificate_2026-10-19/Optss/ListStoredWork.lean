import Optss.ListStoredArrayWork
import Optss.BooleanListIndexWork
import Optss.EncodedReductionWork

/-!
# Storage work of the actual list-backed cached evaluator

These are instrumentation recurrences for `ListStoredCachedReduction` and
`ListStoredReductionLoop`. They charge every list-array access and deep copy,
Boolean index operation, finite-list construction, and recursive control step.
Scalar arithmetic work is separate and already has its encoded work semantics.
Instrumentation counters are mathematical observations, not executed routines.
-/
namespace Optss
open scoped BigOperators
variable {r d : ℕ}

/-- Finite enumeration includes encoding and copying each structural index. -/
def listIndexEnumerationWork (n : ℕ) : ℕ :=
  2*n+1+∑ i : Fin n, (bitUnaryAddressWork i.val+2*(i.val+1)+1)

theorem listIndexEnumerationWork_le (n : ℕ) : listIndexEnumerationWork n ≤ 32*(n+1)^3 := by
  have hs : (∑ i : Fin n,(bitUnaryAddressWork i.val+2*(i.val+1)+1)) ≤ n*(16*(n+1)^2+2*(n+1)+1) := by
    calc
      _ ≤ ∑ _i : Fin n,(16*(n+1)^2+2*(n+1)+1) := by
        apply Finset.sum_le_sum
        intro i _
        have h := bitUnaryAddressWork_le i.val
        have hp := Nat.pow_le_pow_left (show i.val+1≤n+1 by omega) 2
        have hi := i.isLt
        nlinarith
      _ = _ := by simp
  unfold listIndexEnumerationWork
  nlinarith

/-- Input-reading and list-control work of the dot-product fold. -/
def listProductStorageWork {ι : Type*} (u v : ι → ℕ) : List ι → ℕ
  | [] => 1
  | i::is => u i+v i+listProductStorageWork u v is+3

theorem listProductStorageWork_le {ι : Type*} (u v : ι → ℕ) (is : List ι)
    (U V : ℕ) (hu : ∀ i ∈ is,u i ≤ U) (hv : ∀ i ∈ is,v i ≤ V) :
    listProductStorageWork u v is ≤ is.length*(U+V+3)+1 := by
  induction is with
  | nil => simp [listProductStorageWork]
  | cons i is ih =>
    have hiu := hu i List.mem_cons_self
    have hiv := hv i List.mem_cons_self
    have ht := ih (fun j hj => hu j (List.mem_cons_of_mem _ hj))
      (fun j hj => hv j (List.mem_cons_of_mem _ hj))
    simp only [listProductStorageWork,List.length_cons]
    nlinarith

def listDotStorageWork (u v : Fin d → ℕ) : ℕ :=
  listIndexEnumerationWork d+listProductStorageWork u v (List.ofFn id)

def listStoredGsCoefficientStorageWork (A T : ListBitRationalMatrixData r d) (k j : Fin r) : ℕ :=
  let u := listMatrixReadWork listCopyFraction listCopyFractionWork T j
  let v := listMatrixReadWork listCopyFraction listCopyFractionWork A k
  listDotStorageWork u v+listDotStorageWork u u+4

def listStoredGSCoefficientsStorageWork (A T : ListBitRationalMatrixData r d) (k : Fin r) : ℕ :=
  listIndexEnumerationWork r+∑ i : Fin r,
    (bitIndexLTWork i k+if bitIndexLT i k then listStoredGsCoefficientStorageWork A T k i else 1)

def listStoredGSRowStorageWork (A T : ListBitRationalMatrixData r d) (k : Fin r) : ℕ :=
  let coeff := listStoredGSCoefficients A T k
  listStoredGSCoefficientsStorageWork A T k+listIndexEnumerationWork d+
    ∑ l : Fin d,
      (listIndexEnumerationWork k.val+
        listProductStorageWork (fun i : Finset.Iio k => coeff.readWork listCopyFractionWork i)
          (fun i => listMatrixReadWork listCopyFraction listCopyFractionWork T i l)
          (List.ofFn (lowerFinEquiv k))+
        listMatrixReadWork listCopyFraction listCopyFractionWork A k l+3)

def listStoredGSTableStorageWork (A : ListBitRationalMatrixData r d) (n : ℕ) (hn : n≤r) : ℕ :=
  match n with
  | 0 => listIndexEnumerationWork r+r*listIndexEnumerationWork d+2*r*d+1
  | n+1 =>
    let T := listStoredGSTable A n (by omega)
    let k : Fin r := ⟨n,by omega⟩
    let row := listStoredGSRow A T k
    listStoredGSTableStorageWork A n (by omega)+listStoredGSRowStorageWork A T k+
      listMatrixWriteWork listCopyFractionWork T k row+bitUnaryAddressWork n+3
termination_by n

def listStoredRationalIntegerRowsStorageWork (D : ListBitIntegerMatrixData r d) : ℕ :=
  listIndexEnumerationWork r+r*listIndexEnumerationWork d+
    ∑ i : Fin r, ∑ j : Fin d,
      (listMatrixReadWork listCopyInteger listCopyIntegerWork D i j+3)

def listStoredIntegerRowUpdateStorageWork (D : ListBitIntegerMatrixData r d) (k j : Fin r)
    (c : BitListInteger) : ℕ :=
  let row := BooleanListArray.ofFn fun l => bitListIntegerRowCell
    (listMatrixRead listCopyInteger D k l) (listCopyInteger c) (listMatrixRead listCopyInteger D j l)
  listIndexEnumerationWork d+
    (∑ l : Fin d,(listMatrixReadWork listCopyInteger listCopyIntegerWork D k l+
      listCopyIntegerWork c+listMatrixReadWork listCopyInteger listCopyIntegerWork D j l+2))+
    listMatrixWriteWork listCopyIntegerWork D k row+1

def listStoredReduceIntegerRowStorageWork (D : ListBitIntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (h : n≤k.val) : ℕ :=
  match n with
  | 0 => 1
  | n+1 =>
    let j : Fin r := ⟨n,by omega⟩
    let Q := listStoredRationalIntegerRows D
    let T := listStoredGSTable Q r le_rfl
    let q := encodedRoundInteger (listStoredGsCoefficient Q T k j)
    let W := listStoredIntegerRowUpdate D k j q
    listStoredRationalIntegerRowsStorageWork D+listStoredGSTableStorageWork Q r le_rfl+
      listStoredGsCoefficientStorageWork Q T k j+listStoredIntegerRowUpdateStorageWork D k j q+
      listStoredReduceIntegerRowStorageWork W k n (by omega)+bitUnaryAddressWork n+4
termination_by n

def listStoredReduceIntegerAllStorageWork (D : ListBitIntegerMatrixData r d)
    (n : ℕ) (h : n≤r) : ℕ :=
  match n with
  | 0 => 1
  | n+1 =>
    let C := listStoredReduceIntegerAll D n (by omega)
    listStoredReduceIntegerAllStorageWork D n (by omega)+
      listStoredReduceIntegerRowStorageWork C ⟨n,by omega⟩ n le_rfl+bitUnaryAddressWork n+2
termination_by n

def listStoredLovaszPairStorageWork (A T : ListBitRationalMatrixData r d) (j k : Fin r) : ℕ :=
  let mu := listStoredGsCoefficient A T k j
  let nj := encodedRationalDot (listMatrixRead listCopyFraction T j) (listMatrixRead listCopyFraction T j)
  listDotStorageWork (listMatrixReadWork listCopyFraction listCopyFractionWork T k)
    (listMatrixReadWork listCopyFraction listCopyFractionWork T k)+
    listDotStorageWork (listMatrixReadWork listCopyFraction listCopyFractionWork T j)
      (listMatrixReadWork listCopyFraction listCopyFractionWork T j)+
    listStoredGsCoefficientStorageWork A T k j+
    listCopyFractionWork mu+listCopyFractionWork nj+9

def listStoredFailingPairsStorageWork (D : ListBitIntegerMatrixData r d) : ℕ :=
  let Q := listStoredRationalIntegerRows D
  let T := listStoredGSTable Q r le_rfl
  listStoredRationalIntegerRowsStorageWork D+listStoredGSTableStorageWork Q r le_rfl+
    listIndexEnumerationWork r+
    ∑ j : Fin r,(listIndexEnumerationWork r+
      ∑ k : Fin r,(bitIndexAdjacentWork j k+
        (if bitIndexAdjacent j k then listStoredLovaszPairStorageWork Q T j k else 1)+
        4*(r+1)+3))

def bitPairLEWork (p q : Fin r × Fin r) : ℕ :=
  bitIndexLTWork p.1 q.1+bitIndexEQWork p.1 q.1+bitIndexLEWork p.2 q.2+2

def bitLeastPairWork : List (Fin r × Fin r) → ℕ
  | [] => 1
  | p::ps => bitLeastPairWork ps+
    match bitLeastPair ps with
    | none => 2*(r+1)+2
    | some q => bitPairLEWork p q+2*(r+1)+3

def listStoredBooleanSwapRowsStorageWork (D : ListBitIntegerMatrixData r d) (j k : Fin r) : ℕ :=
  listIndexEnumerationWork r+∑ i : Fin r,
    (bitIndexEQWork i j+bitIndexEQWork i k+
      D.readWork (BooleanListArray.copyWork listCopyIntegerWork)
        (if bitIndexEQ i j then k else if bitIndexEQ i k then j else i)+2)

/-- Storage work follows the same actual pair selection and Boolean fuel. -/
def listStoredReductionFuelStorageWork : List Bool → ListBitIntegerMatrixData r d → ℕ
  | [],_ => 1
  | _::fuel,D =>
    let C := listStoredReduceIntegerAll D r le_rfl
    let pairs := listStoredFailingPairs C
    let here := listStoredReduceIntegerAllStorageWork D r le_rfl+
      listStoredFailingPairsStorageWork C+bitLeastPairWork pairs+3
    match bitLeastPair pairs with
    | none => here
    | some p => here+listStoredBooleanSwapRowsStorageWork C p.1 p.2+
        listStoredReductionFuelStorageWork fuel (listStoredBooleanSwapRows C p.1 p.2)+3

end Optss
