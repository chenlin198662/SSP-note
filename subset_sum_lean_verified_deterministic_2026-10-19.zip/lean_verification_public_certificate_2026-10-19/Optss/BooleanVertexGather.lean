import Optss.BooleanVertexTuples

/-!
# Gathering vertex-basis candidates through actual Boolean addresses

Tuple entries remain Boolean words: the answer routines never decode them
into natural indices. Each gather copies the tuple address, the selected
vertex row, and the selected scalar. The gathered square matrix is materialized
once and has the exact rational columns specified by its encoded tuple.
-/
namespace Optss
open scoped BigOperators
variable {r m : ℕ}

def bitAddressFractionRead {m : ℕ} (row : BooleanListArray BitListFraction m) (address : List Bool) : BitListFraction :=
  (bitIndexedRead listCopyFraction address row.data).getD bitListFractionZero

theorem bitAddressFractionRead_unary {m : ℕ} (row : BooleanListArray BitListFraction m) (k : Fin m) :
    bitAddressFractionRead row (bitUnaryAddress k.val)=row.toVector.get k := by
  have hk : k.val<row.data.length := by simpa only [row.length_eq] using k.isLt
  simp only [bitAddressFractionRead,bitIndexedRead_correct,bitUnaryAddress_value,
    List.getElem?_eq_getElem hk,Option.map_some,Option.getD_some,listCopyFraction_eq]
  simp [BooleanListArray.toVector,Vector.get]

def bitVertexGatherCell (V : ListBitRationalMatrixData r m) (t : BitVertexTuple r) (i j : Fin r) : BitListFraction :=
  let address := t.read bitWordCopy j
  let row := V.read (BooleanListArray.copy listCopyFraction) i
  bitAddressFractionRead row address

def bitVertexGatherCellWork (V : ListBitRationalMatrixData r m) (t : BitVertexTuple r) (i j : Fin r) : ℕ :=
  let address := t.read bitWordCopy j
  let row := V.read (BooleanListArray.copy listCopyFraction) i
  t.readWork bitWordCopyWork j+V.readWork (BooleanListArray.copyWork listCopyFractionWork) i+
    bitIndexedReadWork listCopyFractionWork address row.data+3

def bitVertexGather (V : ListBitRationalMatrixData r m) (t : BitVertexTuple r) : ListBitRationalMatrixData r r :=
  BooleanListArray.ofFn fun i => BooleanListArray.ofFn fun j => bitVertexGatherCell V t i j

def bitVertexGatherWork (V : ListBitRationalMatrixData r m) (t : BitVertexTuple r) : ℕ :=
  matrixProductAllocationWork r r+∑ i : Fin r,∑ j : Fin r,bitVertexGatherCellWork V t i j

theorem bitVertexGatherCell_encode (V : ListBitRationalMatrixData r m) (t : Fin r → Fin m) (i j : Fin r) :
    bitVertexGatherCell V (encodeVertexTuple t) i j=rectangularListFractionMatrix V i (t j) := by
  simp only [bitVertexGatherCell,BooleanListArray.read_toVector _ bitWordCopy_eq,encodeVertexTuple_get,
    bitAddressFractionRead_unary,BooleanListArray.read_toVector _
      (BooleanListArray.copy_eq listCopyFraction listCopyFraction_eq)]
  exact (rectangularListFractionMatrix_row V i (t j)).symm

theorem bitVertexGather_entry (V : ListBitRationalMatrixData r m) (t : BitVertexTuple r) (i j : Fin r) :
    rectangularListFractionMatrix (bitVertexGather V t) i j=bitVertexGatherCell V t i j := by
  simp [rectangularListFractionMatrix,bitVertexGather,listMatrixVector_ofFn,
    BooleanListArray.ofFn_toVector,Vector.get]

theorem bitVertexGather_encode (V : ListBitRationalMatrixData r m) (t : Fin r → Fin m) :
    (rectangularListFractionMatrix (bitVertexGather V (encodeVertexTuple t))).map bitListFractionValue=
      rationalVertexMatrix (storedRationalVertices V) t := by
  ext i j
  rw [Matrix.map_apply,bitVertexGather_entry,bitVertexGatherCell_encode]
  rfl

theorem bitVertexGather_wellFormed (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    {t : BitVertexTuple r} (ht : t∈bitVertexTuples m r) (i j : Fin r) :
    (rectangularListFractionMatrix (bitVertexGather V t) i j).WellFormed := by
  obtain ⟨u,rfl⟩ := bitVertexTuples_members ht
  rw [bitVertexGather_entry,bitVertexGatherCell_encode]
  exact hV _ _

theorem bitVertexGather_lengths (V : ListBitRationalMatrixData r m) (L : ℕ)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).numerator.length≤L ∧
      (rectangularListFractionMatrix V i j).denominator.length≤L)
    {t : BitVertexTuple r} (ht : t∈bitVertexTuples m r) (i j : Fin r) :
    (rectangularListFractionMatrix (bitVertexGather V t) i j).numerator.length≤L ∧
      (rectangularListFractionMatrix (bitVertexGather V t) i j).denominator.length≤L := by
  obtain ⟨u,rfl⟩ := bitVertexTuples_members ht
  rw [bitVertexGather_entry,bitVertexGatherCell_encode]
  exact hV _ _

/-- Explicit dimension/field-width bound for one genuine addressed gather. -/
def vertexGatherCellBound (r m L : ℕ) : ℕ :=
  64*(r+1)^2*(2*m+2)+64*(r+1)^2*(m*(4*L+5)+2)+
    m*(12*(m+2)+2*(4*L+3))+4

theorem bitVertexGatherCellWork_bound (V : ListBitRationalMatrixData r m) (t : BitVertexTuple r)
    (ht : ∀ w∈t.data,w.length≤m) (L : ℕ)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).numerator.length≤L ∧
      (rectangularListFractionMatrix V i j).denominator.length≤L) (i j : Fin r) :
    bitVertexGatherCellWork V t i j≤vertexGatherCellBound r m L := by
  have hw : ∀ row∈V.data,∀ q∈row.data,listCopyFractionWork q≤4*L+3 := by
    apply (matrixRows_forall V (fun q => listCopyFractionWork q≤4*L+3)).mpr
    intro a b
    have h := hV a b
    rw [listCopyFractionWork_eq,fractionPayload]
    omega
  have htuple := t.readWork_le bitWordCopyWork j (2*m+1) (by
    intro w hw; rw [bitWordCopyWork_eq]; have h := ht w hw; omega)
  have hrows := V.readWork_le (BooleanListArray.copyWork listCopyFractionWork) i (m*(4*L+5)+1) (by
    intro row hr
    exact row.copyWork_le listCopyFractionWork (4*L+3) (hw row hr))
  let row := V.read (BooleanListArray.copy listCopyFraction) i
  have hrow : ∀ q∈row.data,listCopyFractionWork q≤4*L+3 := by
    rw [show row=V.toVector.get i from BooleanListArray.read_toVector _
      (BooleanListArray.copy_eq listCopyFraction listCopyFraction_eq) V i]
    exact (V.forall_data_iff (fun row => ∀ q∈row.data,listCopyFractionWork q≤4*L+3)).mp hw i
  have haddr : (t.read bitWordCopy j).length≤m+1 := by
    rw [BooleanListArray.read_toVector _ bitWordCopy_eq]
    exact (((t.forall_data_iff (fun w => w.length≤m)).mp ht) j).trans (by omega)
  have hraw := bitIndexedReadWork_le listCopyFractionWork (t.read bitWordCopy j)
    row.data (m+1) (4*L+3) (by omega) haddr hrow
  rw [row.length_eq] at hraw
  unfold bitVertexGatherCellWork vertexGatherCellBound
  dsimp only [row] at hraw
  dsimp only
  norm_num only [Nat.add_assoc] at htuple hrows hraw
  omega

theorem bitVertexGatherWork_bound (V : ListBitRationalMatrixData r m) (t : BitVertexTuple r)
    (ht : t∈bitVertexTuples m r) (L : ℕ)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).numerator.length≤L ∧
      (rectangularListFractionMatrix V i j).denominator.length≤L) :
    bitVertexGatherWork V t≤matrixProductAllocationWork r r+r*r*vertexGatherCellBound r m L := by
  unfold bitVertexGatherWork
  apply Nat.add_le_add_left
  calc
    _ ≤ ∑ _i : Fin r,∑ _j : Fin r,vertexGatherCellBound r m L := by
      apply Finset.sum_le_sum
      intro i _
      apply Finset.sum_le_sum
      intro j _
      exact bitVertexGatherCellWork_bound V t (bitVertexTuples_word_length ht) L hV i j
    _ = _ := by simp; ring
end Optss
