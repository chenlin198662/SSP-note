import Mathlib.Data.Nat.Size
import Mathlib.Tactic

/-!
# Binary long division and explicit work accounting

The algorithm visits each input bit once, retaining an exact quotient and a
remainder below the divisor. The work field records a conservative sum of
operand-width charges for shifts, comparisons and subtraction. This is an
arithmetic implementation and charge bound; correspondence to a particular
machine's primitive bit instructions remains a separate refinement.
-/

namespace Optss

/-- Little-endian bit-string value, including noncanonical leading zeros. -/
def binaryDigitsValue : List Bool → ℕ
  | [] => 0
  | b :: bs => 2*binaryDigitsValue bs+b.toNat

theorem binaryDigitsValue_bits (n : ℕ) : binaryDigitsValue n.bits = n := by
  induction n using Nat.binaryRec' with
  | z => simp [binaryDigitsValue]
  | f b n hn ih =>
    rw [Nat.bits_append_bit n b hn, binaryDigitsValue, ih, Nat.bit_val]

theorem binaryDigitsValue_lt_pow (bs : List Bool) :
    binaryDigitsValue bs < 2^bs.length := by
  induction bs with
  | nil => simp [binaryDigitsValue]
  | cons b bs ih =>
    simp only [binaryDigitsValue, List.length_cons, pow_succ]
    cases b <;> simp only [Bool.toNat_false, Bool.toNat_true] <;> omega

structure BinaryDivisionResult where
  quotient : ℕ
  remainder : ℕ
  rounds : ℕ
  widthWork : ℕ
  deriving Repr, DecidableEq

/-- One binary long-division transition. The work charge bounds the lengths of
all operands needed by the two shifts, comparison and possible subtraction. -/
def binaryDivisionStep (b : Bool) (d : ℕ) (out : BinaryDivisionResult) :
    BinaryDivisionResult :=
  let u := 2*out.remainder+b.toNat
  let charge := 8*(out.quotient.size+d.size+2)
  if d ≤ u then
    ⟨2*out.quotient+1, u-d, out.rounds+1, out.widthWork+charge⟩
  else
    ⟨2*out.quotient, u, out.rounds+1, out.widthWork+charge⟩

def binaryDivisionDigits (d : ℕ) : List Bool → BinaryDivisionResult
  | [] => ⟨0,0,0,0⟩
  | b :: bs => binaryDivisionStep b d (binaryDivisionDigits d bs)

def binaryLongDivision (n d : ℕ) : BinaryDivisionResult :=
  binaryDivisionDigits d n.bits

theorem binaryDivisionStep_correct (b : Bool) (d n : ℕ)
    (out : BinaryDivisionResult) (he : out.quotient*d+out.remainder=n)
    (hr : out.remainder < d) :
    (binaryDivisionStep b d out).quotient*d+(binaryDivisionStep b d out).remainder =
      2*n+b.toNat ∧ (binaryDivisionStep b d out).remainder < d := by
  have hb : b.toNat ≤ 1 := by cases b <;> decide
  unfold binaryDivisionStep
  dsimp only
  split_ifs with h
  · dsimp
    constructor
    · have ht := Nat.sub_add_cancel h
      nlinarith
    · omega
  · dsimp
    constructor
    · nlinarith
    · omega

theorem binaryDivisionDigits_correct (d : ℕ) (hd : 0 < d) (bs : List Bool) :
    (binaryDivisionDigits d bs).quotient*d+(binaryDivisionDigits d bs).remainder =
      binaryDigitsValue bs ∧ (binaryDivisionDigits d bs).remainder < d := by
  induction bs with
  | nil => simp [binaryDivisionDigits, binaryDigitsValue, hd]
  | cons b bs ih =>
    exact binaryDivisionStep_correct b d (binaryDigitsValue bs) _ ih.1 ih.2

theorem binaryDivisionDigits_quotient_le (d : ℕ) (hd : 0 < d) (bs : List Bool) :
    (binaryDivisionDigits d bs).quotient ≤ binaryDigitsValue bs := by
  have he := (binaryDivisionDigits_correct d hd bs).1
  have hm := Nat.le_mul_of_pos_right (binaryDivisionDigits d bs).quotient hd
  omega

theorem binaryDivisionDigits_quotient_bits (d : ℕ) (hd : 0 < d) (bs : List Bool) :
    (binaryDivisionDigits d bs).quotient.size ≤ bs.length :=
  Nat.size_le.mpr ((binaryDivisionDigits_quotient_le d hd bs).trans_lt
    (binaryDigitsValue_lt_pow bs))

theorem binaryDigitAppend_bits (n : ℕ) (b : Bool) :
    (2*n+b.toNat).size ≤ n.size+1 := by
  apply Nat.size_le.mpr
  rw [pow_succ]
  have hn := Nat.lt_size_self n
  have hb : b.toNat ≤ 1 := by cases b <;> decide
  omega

/-- The trial remainder, including its appended bit, never exceeds one more
bit than the divisor. This covers the temporary value before subtraction. -/
theorem binaryDivisionStep_remainder_bits (b : Bool) (d : ℕ)
    (out : BinaryDivisionResult) (hr : out.remainder < d) :
    out.remainder.size ≤ d.size ∧ (2*out.remainder+b.toNat).size ≤ d.size+1 := by
  have hs := Nat.size_le_size hr.le
  exact ⟨hs, (binaryDigitAppend_bits out.remainder b).trans (by omega)⟩

/-- Operand-width accounting for two appends, a comparison, a subtraction and
constant control work fits the charge recorded by the executable transition. -/
theorem binaryDivisionStep_width_charge (b : Bool) (d : ℕ)
    (out : BinaryDivisionResult) (hr : out.remainder < d) :
    (out.quotient.size+1)+(out.remainder.size+1)+
      2*(max (2*out.remainder+b.toNat).size d.size+1)+2 ≤
      8*(out.quotient.size+d.size+2) := by
  obtain ⟨hrb, hub⟩ := binaryDivisionStep_remainder_bits b d out hr
  have hm : max (2*out.remainder+b.toNat).size d.size ≤ d.size+1 :=
    max_le hub (by omega)
  omega

theorem binaryDivisionDigits_rounds (d : ℕ) (bs : List Bool) :
    (binaryDivisionDigits d bs).rounds = bs.length := by
  induction bs with
  | nil => rfl
  | cons b bs ih => simp [binaryDivisionDigits, binaryDivisionStep, ih]; split_ifs <;> rfl

theorem binaryDivisionDigits_widthWork (d : ℕ) (hd : 0 < d) (bs : List Bool) :
    (binaryDivisionDigits d bs).widthWork ≤ 8*bs.length*(bs.length+d.size+2) := by
  induction bs with
  | nil => simp [binaryDivisionDigits]
  | cons b bs ih =>
    have hq := binaryDivisionDigits_quotient_bits d hd bs
    have he : (binaryDivisionDigits d (b::bs)).widthWork =
        (binaryDivisionDigits d bs).widthWork +
          8*((binaryDivisionDigits d bs).quotient.size+d.size+2) := by
      simp only [binaryDivisionDigits, binaryDivisionStep]
      split_ifs <;> rfl
    rw [he, List.length_cons]
    nlinarith

/-- The computed answer is exactly the standard natural quotient/remainder. -/
theorem binaryLongDivision_correct (n d : ℕ) (hd : 0 < d) :
    (binaryLongDivision n d).quotient = n/d ∧
      (binaryLongDivision n d).remainder = n%d := by
  have h := binaryDivisionDigits_correct d hd n.bits
  rw [binaryDigitsValue_bits] at h
  change (binaryLongDivision n d).quotient*d+(binaryLongDivision n d).remainder=n ∧
    (binaryLongDivision n d).remainder < d at h
  constructor
  · conv_rhs => rw [← h.1]
    simp [Nat.add_div, hd, Nat.div_eq_of_lt h.2, Nat.mod_eq_of_lt h.2, not_le.mpr h.2]
  · conv_rhs => rw [← h.1]
    simp [Nat.add_mod, Nat.mod_eq_of_lt h.2]

theorem binaryLongDivision_rounds (n d : ℕ) :
    (binaryLongDivision n d).rounds = n.size := by
  rw [binaryLongDivision, binaryDivisionDigits_rounds, Nat.size_eq_bits_len]

theorem binaryLongDivision_widthWork (n d : ℕ) (hd : 0 < d) :
    (binaryLongDivision n d).widthWork ≤ 8*n.size*(n.size+d.size+2) := by
  simpa only [binaryLongDivision, Nat.size_eq_bits_len] using
    binaryDivisionDigits_widthWork d hd n.bits

end Optss
