import Optss.BooleanTaylorWork

/-! Polynomial gate/list work of the implemented Boolean arctangent sums.
The bounds include every power, division, and partial-sum operand. -/
namespace Optss
open scoped BigOperators

def arctanWorkBits (B n : ℕ) : ℕ := 64*(n+1)^2*(B.size+1)
def arctanScalarCharge (B n : ℕ) : ℕ := 2048*(arctanWorkBits B n+1)^3

theorem arctanWorkBits_bounds (B n : ℕ) :
    (4*n+2)*(B.size+1)≤arctanWorkBits B n ∧
    (4*n+2)^2≤arctanWorkBits B n ∧
    (arctanTermHeight B n).size≤arctanWorkBits B n ∧
    (arctanPartialHeight B n).size≤arctanWorkBits B n := by
  have ht := arctanTermHeight_bits B n
  have hp := arctanPartialHeight_bits B n
  have hs := nat_size_le_value (4*n+1)
  have hm := Nat.mul_le_mul_left (2*n) hs
  have hB : 1≤B.size+1 := by omega
  have hn : 1≤(n+1)^2 := by nlinarith
  have hmul := Nat.mul_le_mul_left (64*(n+1)^2) hB
  unfold arctanWorkBits
  constructor
  · nlinarith
  constructor
  · nlinarith
  constructor <;> nlinarith

theorem arctanScalarCharge_large (B n : ℕ) :
    259≤arctanScalarCharge B n ∧
      64*(4*n+2)^2+3≤arctanScalarCharge B n := by
  have h := (arctanWorkBits_bounds B n).2.1
  unfold arctanScalarCharge
  have hp : 1≤(arctanWorkBits B n+1)^2 := by nlinarith
  constructor <;> nlinarith

theorem arctan_power_bits (x : FourierFraction) (B n j : ℕ)
    (hx : RationalSizeBound x.value B) (hj : j≤4*n+1) :
    RationalBitBound (x.pow j).value (arctanWorkBits B n) := by
  rw [FourierFraction.pow_value]
  apply (hx.pow j).bitBound.mono
  exact (nat_power_size_le B j).trans ((by nlinarith : j*B.size+1≤(4*n+2)*(B.size+1)).trans
    (arctanWorkBits_bounds B n).1)

theorem arctan_power_work (x : FourierFraction) (B n j : ℕ)
    (hx : RationalSizeBound x.value B) (hj : j≤4*n+1) :
    fourierFractionPowWork x j≤(j+2)*arctanScalarCharge B n := by
  have h := fourierFractionPowWork_height x B j hx
  have hs : (j+1)*(B.size+1)≤arctanWorkBits B n :=
    (Nat.mul_le_mul_right _ (by omega : j+1≤4*n+2)).trans (arctanWorkBits_bounds B n).1
  have hp := Nat.pow_le_pow_left (Nat.add_le_add_right hs 1) 3
  have hm := Nat.mul_le_mul_left 2048 hp
  have hU := (arctanScalarCharge_large B n).1
  change _≤arctanScalarCharge B n at hm
  have hjm := Nat.mul_le_mul_left j hm
  have hlarge := (arctanScalarCharge_large B n).2
  have hjU : j≤arctanScalarCharge B n := by nlinarith
  nlinarith

theorem bitArctanTermWork_bound (x : FourierFraction) (B n i : ℕ)
    (hx : RationalSizeBound x.value B) (hi : i<2*n) :
    bitArctanTermWork x i≤(6*n+12)*arctanScalarCharge B n := by
  let L := arctanWorkBits B n
  let U := arctanScalarCharge B n
  let s := (FourierFraction.nat 1).neg.pow i
  let q := x.pow (2*i+1)
  let d := FourierFraction.nat (2*i+1)
  have hU : 259≤U := (arctanScalarCharge_large B n).1
  have hs : RationalSizeBound (FourierFraction.nat 1).neg.value 1 := by
    norm_num [FourierFraction.neg_value,FourierFraction.nat_value,RationalSizeBound]
  have hsign : RationalSizeBound s.value 1 := by
    simpa only [s,FourierFraction.pow_value,one_pow] using hs.pow i
  have hq : RationalSizeBound q.value (B^(2*i+1)) := by
    simpa only [q,FourierFraction.pow_value] using hx.pow (2*i+1)
  have hqb : (B^(2*i+1)).size≤L := (nat_power_size_le _ _).trans
    ((by nlinarith : (2*i+1)*B.size+1≤(4*n+2)*(B.size+1)).trans (arctanWorkBits_bounds B n).1)
  have hLb : 1≤L := by have := (arctanWorkBits_bounds B n).2.1; dsimp [L]; nlinarith
  have hsb : RationalBitBound s.value L := hsign.bitBound.mono (by simpa using hLb)
  have hqq : RationalBitBound q.value L := hq.bitBound.mono hqb
  have hprod : RationalBitBound (s.mul q).value L := by
    rw [FourierFraction.mul_value]
    exact (by simpa only [one_mul] using hsign.mul hq : RationalSizeBound (s.value*q.value) (B^(2*i+1))).bitBound.mono hqb
  have hd : RationalBitBound d.value L := by
    rw [FourierFraction.nat_value]
    have hb := RationalSizeBound.natCast (2*i+1) (4*n+1) (by omega) (by omega)
    apply hb.bitBound.mono
    exact (nat_size_le_value _).trans ((by nlinarith : 4*n+1≤(4*n+2)*(B.size+1)).trans
      (arctanWorkBits_bounds B n).1)
  have hm := s.mulWork_bound q L hsb hqq
  have hv := (s.mul q).divWork_bound d L hprod hd
  change _≤U at hm hv
  have hp := arctan_power_work x B n (2*i+1) hx (by omega)
  have hsp := fourierFractionPowWork_height (FourierFraction.nat 1).neg 1 i hs
  have hsignwidth : (i+1)*((1 : ℕ).size+1)≤L := by
    have h1 : (1 : ℕ).size=1 := Nat.size_one
    rw [h1]
    have := (arctanWorkBits_bounds B n).2.1
    dsimp [L]
    nlinarith
  have hpowsign := Nat.mul_le_mul_left 2048 (Nat.pow_le_pow_left (Nat.add_le_add_right hsignwidth 1) 3)
  change _≤U at hpowsign
  have hip := Nat.mul_le_mul_left i hpowsign
  have hlarge : 64*(4*n+2)^2+3≤U := (arctanScalarCharge_large B n).2
  have hn := fourierNatFractionWork_bound (2*i+1)
  have hn' : fourierNatFractionWork (2*i+1)≤U := hn.trans
    ((Nat.add_le_add_right (Nat.mul_le_mul_left 64 (Nat.pow_le_pow_left (by omega : 2*i+1+1≤4*n+2) 2)) 3).trans (arctanScalarCharge_large B n).2)
  have h1 := fourierNatFractionWork_bound 1
  norm_num at h1
  change fourierNatFractionWork 1+1+fourierFractionPowWork (FourierFraction.nat 1).neg i+
    fourierFractionPowWork x (2*i+1)+bitListFractionMulCost s.val q.val+
    fourierNatFractionWork (2*i+1)+bitListFractionDivCost (s.mul q).val d.val+1≤_
  nlinarith

theorem bitArctanPartialWork_bound (x : FourierFraction) (B n : ℕ)
    (hx : RationalSizeBound x.value B) :
    bitArctanPartialWork x n≤65536*(n+1)^2*(arctanWorkBits B n+1)^3 := by
  let L := arctanWorkBits B n
  let U := arctanScalarCharge B n
  have hU : 259≤U := (arctanScalarCharge_large B n).1
  have hf : ∀ i<2*n, RationalBitBound (bitArctanTerm x i).value L := by
    intro i hi
    rw [bitArctanTerm_value]
    exact (rationalArctanTerm_height x.value B n i hx hi).bitBound.mono (arctanWorkBits_bounds B n).2.2.1
  have hs : ∀ i≤2*n, RationalBitBound (fourierFractionSum (bitArctanTerm x) i).value L := by
    intro i hi
    simp only [fourierFractionSum_value,bitArctanTerm_value]
    exact (rationalArctanPartialSum_height x.value B n hx (Finset.range i)
      (Finset.range_mono hi)).bitBound.mono (arctanWorkBits_bounds B n).2.2.2
  have h := fourierFractionSumWork_uniform (bitArctanTerm x) (bitArctanTermWork x) (2*n) L
    ((6*n+12)*U) (fun i hi => bitArctanTermWork_bound x B n i hx hi) hf hs
  have h0 := fourierNatFractionWork_bound 0
  norm_num at h0
  change bitArctanPartialWork x n≤fourierNatFractionWork 0+2*n*((6*n+12)*U+U+1) at h
  have he : 65536*(n+1)^2*(arctanWorkBits B n+1)^3=32*(n+1)^2*U := by
    dsimp [U,arctanScalarCharge]; ring
  rw [he]
  nlinarith

end Optss
