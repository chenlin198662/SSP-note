import Optss.BooleanListArray
import Optss.EncodedRationalReduction

/-!
# Rational input/output on explicit list storage

All answer routines traverse list-backed rows directly. Magnitude payloads are
copied explicitly before scalar calls; the common denominator is computed once.
Native vectors occur only in the mathematical projection and its correctness
proofs, never in the input-clearing or output-unscaling answer paths.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

def ioCopyFraction (q : BitListFraction) : BitListFraction :=
  ⟨q.negative,bitWordCopy q.numerator,bitWordCopy q.denominator⟩

def ioCopyInteger (z : BitListInteger) : BitListInteger := ⟨z.negative,bitWordCopy z.digits⟩

@[simp] theorem ioCopyFraction_eq (q : BitListFraction) : ioCopyFraction q = q := by
  cases q
  simp [ioCopyFraction,bitWordCopy_eq]
@[simp] theorem ioCopyInteger_eq (z : BitListInteger) : ioCopyInteger z = z := by
  cases z
  simp [ioCopyInteger,bitWordCopy_eq]

def ioListArrayMap {α β : Type*} {n : ℕ} (f : α → β) (A : BooleanListArray α n) : BooleanListArray β n :=
  ⟨A.data.map f,by rw [List.length_map,A.length_eq]⟩

def ioMatrixMap {α β : Type*} (f : α → β)
    (A : BooleanListArray (BooleanListArray α d) r) : BooleanListArray (BooleanListArray β d) r :=
  ioListArrayMap (ioListArrayMap f) A

/-- Proof-only mathematical projection of nested list storage. -/
def ioMatrixVector {α : Type*} (A : BooleanListArray (BooleanListArray α d) r) : Vector (Vector α d) r :=
  Vector.ofFn fun i => (A.toVector.get i).toVector

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

private theorem get_ofFn_fun {α : Type*} {n : ℕ} (f : Fin n → α) :
    (Vector.ofFn f).get = f := funext (get_ofFn f)

theorem ioListArrayMap_get {α β : Type*} {n : ℕ} (f : α → β)
    (A : BooleanListArray α n) (i : Fin n) :
    (ioListArrayMap f A).toVector.get i = f (A.toVector.get i) := by
  simp only [ioListArrayMap,BooleanListArray.toVector,get_ofFn,List.getElem_map]

theorem ioMatrixMap_get {α β : Type*} (f : α → β)
    (A : BooleanListArray (BooleanListArray α d) r) (i : Fin r) (j : Fin d) :
    ((ioMatrixVector (ioMatrixMap f A)).get i).get j =
      f (((ioMatrixVector A).get i).get j) := by
  simp only [ioMatrixVector,get_ofFn,ioMatrixMap,ioListArrayMap_get]

/-- Collect copied denominator lists in row-major order, using an explicit
continuation to avoid extra flattening passes. -/
def ioDenominatorsInto : List BitListFraction → List (List Bool) → List (List Bool)
  | [], tail => tail
  | q::qs, tail => bitWordCopy q.denominator::ioDenominatorsInto qs tail

def ioRowDenominatorsInto : List (BooleanListArray BitListFraction d) → List (List Bool) → List (List Bool)
  | [], tail => tail
  | row::rows, tail => ioDenominatorsInto row.data (ioRowDenominatorsInto rows tail)

def listStoredDenominators (A : BooleanListArray (BooleanListArray BitListFraction d) r) : List (List Bool) :=
  ioRowDenominatorsInto A.data []

def listStoredInputDenominator (A : BooleanListArray (BooleanListArray BitListFraction d) r) : List Bool :=
  bitListProduct (listStoredDenominators A)

/-- Copy the shared denominator and both input magnitude fields explicitly. -/
def listStoredClearCell (D : List Bool) (q : BitListFraction) : BitListInteger :=
  bitListClearFraction (bitWordCopy D) (ioCopyFraction q)

def listStoredClearRationalInput (A : BooleanListArray (BooleanListArray BitListFraction d) r) :
    List Bool × BooleanListArray (BooleanListArray BitListInteger d) r :=
  let D := listStoredInputDenominator A
  (D,ioMatrixMap (listStoredClearCell D) A)

/-- Output normalization likewise receives physically copied scalar payloads. -/
def listStoredUnscaleCell (D : List Bool) (z : BitListInteger) : BitListFraction :=
  bitListUnscaleInteger (bitWordCopy D) (ioCopyInteger z)

def listStoredUnscale (D : List Bool) (A : BooleanListArray (BooleanListArray BitListInteger d) r) :
    BooleanListArray (BooleanListArray BitListFraction d) r := ioMatrixMap (listStoredUnscaleCell D) A

@[simp] theorem listStoredClearCell_eq (D : List Bool) (q : BitListFraction) :
    listStoredClearCell D q = bitListClearFraction D q := by simp [listStoredClearCell,bitWordCopy_eq]
@[simp] theorem listStoredUnscaleCell_eq (D : List Bool) (z : BitListInteger) :
    listStoredUnscaleCell D z = bitListUnscaleInteger D z := by simp [listStoredUnscaleCell,bitWordCopy_eq]

theorem ioDenominatorsInto_eq (qs : List BitListFraction) (tail : List (List Bool)) :
    ioDenominatorsInto qs tail = (qs.map BitListFraction.denominator)++tail := by
  induction qs with
  | nil => rfl
  | cons q qs ih => simp only [ioDenominatorsInto,bitWordCopy_eq,ih,List.map_cons,List.cons_append]

theorem ioRowDenominatorsInto_eq (rows : List (BooleanListArray BitListFraction d)) (tail : List (List Bool)) :
    ioRowDenominatorsInto rows tail = (rows.flatMap fun row => row.data.map BitListFraction.denominator)++tail := by
  induction rows with
  | nil => rfl
  | cons row rows ih => simp [ioRowDenominatorsInto,ioDenominatorsInto_eq,ih,List.append_assoc]

private theorem listArray_data_eq_ofFn {α : Type*} {n : ℕ} (A : BooleanListArray α n) :
    A.data = List.ofFn A.toVector.get := by
  apply List.ext_getElem
  · simp [A.length_eq]
  · intro i hi hj
    simp only [List.getElem_ofFn,BooleanListArray.toVector,get_ofFn]

theorem listStoredDenominators_eq (A : BooleanListArray (BooleanListArray BitListFraction d) r) :
    listStoredDenominators A = (bitRationalMatrixEntries (ioMatrixVector A)).map BitListFraction.denominator := by
  rw [listStoredDenominators,ioRowDenominatorsInto_eq,List.append_nil,listArray_data_eq_ofFn A]
  simp only [List.flatMap_def,List.map_ofFn,listArray_data_eq_ofFn,List.map_ofFn,
    bitRationalMatrixEntries,ioMatrixVector,get_ofFn,List.map_flatten,List.map_map,Function.comp_def]

theorem listStoredInputDenominator_eq (A : BooleanListArray (BooleanListArray BitListFraction d) r) :
    listStoredInputDenominator A = bitRationalInputDenominator (ioMatrixVector A) := by
  rw [listStoredInputDenominator,listStoredDenominators_eq]
  rfl

/-- Literal scalar encodings, not only decoded values, agree with the verified
array input-clearing operation. -/
theorem listStoredClearRationalInput_eq (A : BooleanListArray (BooleanListArray BitListFraction d) r) :
    ((listStoredClearRationalInput A).1,ioMatrixVector (listStoredClearRationalInput A).2) =
      bitListClearRationalInput (ioMatrixVector A) := by
  apply Prod.ext
  · exact listStoredInputDenominator_eq A
  · apply Vector.ext
    intro i hi
    apply Vector.ext
    intro j hj
    change ((ioMatrixVector (listStoredClearRationalInput A).2).get ⟨i,hi⟩).get ⟨j,hj⟩ =
      (((bitListClearRationalInput (ioMatrixVector A)).2).get ⟨i,hi⟩).get ⟨j,hj⟩
    simp only [listStoredClearRationalInput,ioMatrixMap_get,listStoredClearCell_eq,
      listStoredInputDenominator_eq,bitListClearRationalInput,get_ofFn]

theorem listStoredUnscale_get (D : List Bool) (A : BooleanListArray (BooleanListArray BitListInteger d) r)
    (i : Fin r) (j : Fin d) :
    ((ioMatrixVector (listStoredUnscale D A)).get i).get j =
      bitListUnscaleInteger D (((ioMatrixVector A).get i).get j) := by
  rw [listStoredUnscale,ioMatrixMap_get,listStoredUnscaleCell_eq]

end Optss
