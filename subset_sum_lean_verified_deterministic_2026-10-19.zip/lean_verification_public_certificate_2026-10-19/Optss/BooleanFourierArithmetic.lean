import Optss.FixedPointRadixBounds
import Optss.BitListIntegerOperations

/-! Pure Boolean-list complex integer arithmetic for Fourier butterflies.
Costs count the actual signed-integer Boolean gates/list traversals; array
lookup and storage administration are not included in these scalar costs. -/
namespace Optss

structure BitFourierInteger where
  re : BitListInteger
  im : BitListInteger
  deriving Repr

def BitFourierInteger.value (z : BitFourierInteger) : FourierInteger := ⟨z.re.value,z.im.value⟩

def BitFourierInteger.Canonical (z : BitFourierInteger) : Prop :=
  BitListCanonical z.re.digits ∧ BitListCanonical z.im.digits

def BitFourierInteger.Width (z : BitFourierInteger) (L : ℕ) : Prop :=
  z.re.digits.length≤L ∧ z.im.digits.length≤L

def bitFourierAdd (z w : BitFourierInteger) : BitFourierInteger :=
  ⟨bitListIntegerAdd z.re w.re,bitListIntegerAdd z.im w.im⟩

def bitFourierMul (z w : BitFourierInteger) : BitFourierInteger :=
  let rr := bitListIntegerMul z.re w.re
  let ii := bitListIntegerMul z.im w.im
  let ri := bitListIntegerMul z.re w.im
  let ir := bitListIntegerMul z.im w.re
  ⟨bitListIntegerSub rr ii,bitListIntegerAdd ri ir⟩

def bitFourierScale (D : BitListInteger) (z : BitFourierInteger) : BitFourierInteger :=
  ⟨bitListIntegerMul D z.re,bitListIntegerMul D z.im⟩

def bitFourierButterfly (D : BitListInteger) (e t o : BitFourierInteger) : BitFourierInteger :=
  bitFourierAdd (bitFourierScale D e) (bitFourierMul t o)

theorem bitFourierAdd_value (z w : BitFourierInteger) :
    (bitFourierAdd z w).value=z.value+w.value := by
  change FourierInteger.mk (bitListIntegerAdd z.re w.re).value (bitListIntegerAdd z.im w.im).value=
    FourierInteger.mk (z.re.value+w.re.value) (z.im.value+w.im.value)
  simp only [bitListIntegerAdd_value]

theorem bitFourierMul_value (z w : BitFourierInteger) :
    (bitFourierMul z w).value=z.value*w.value := by
  change FourierInteger.mk
    (bitListIntegerSub (bitListIntegerMul z.re w.re) (bitListIntegerMul z.im w.im)).value
    (bitListIntegerAdd (bitListIntegerMul z.re w.im) (bitListIntegerMul z.im w.re)).value=
    FourierInteger.mk (z.re.value*w.re.value-z.im.value*w.im.value)
      (z.re.value*w.im.value+z.im.value*w.re.value)
  simp only [bitListIntegerSub_value,bitListIntegerAdd_value,bitListIntegerMul_value]

theorem bitFourierScale_value (D : BitListInteger) (z : BitFourierInteger) :
    (bitFourierScale D z).value=fourierIntegerScale D.value z.value := by
  simp [bitFourierScale,BitFourierInteger.value,fourierIntegerScale,bitListIntegerMul_value]

theorem bitFourierButterfly_value (D : BitListInteger) (e t o : BitFourierInteger) :
    (bitFourierButterfly D e t o).value=fourierIntegerScale D.value e.value+t.value*o.value := by
  rw [bitFourierButterfly,bitFourierAdd_value,bitFourierScale_value,bitFourierMul_value]

theorem bitFourierAdd_canonical (z w : BitFourierInteger) : (bitFourierAdd z w).Canonical :=
  ⟨bitListIntegerAdd_canonical _ _,bitListIntegerAdd_canonical _ _⟩

theorem bitFourierMul_canonical (z w : BitFourierInteger) : (bitFourierMul z w).Canonical :=
  ⟨bitListIntegerSub_canonical _ _,bitListIntegerAdd_canonical _ _⟩

theorem bitFourierScale_canonical (D : BitListInteger) (z : BitFourierInteger) :
    (bitFourierScale D z).Canonical := ⟨bitListIntegerMul_canonical _ _,bitListIntegerMul_canonical _ _⟩

theorem bitFourierButterfly_canonical (D : BitListInteger) (e t o : BitFourierInteger) :
    (bitFourierButterfly D e t o).Canonical := bitFourierAdd_canonical _ _

theorem bitFourierAdd_width (z w : BitFourierInteger) (L : ℕ) (hz : z.Width L) (hw : w.Width L) :
    (bitFourierAdd z w).Width (L+1) := by
  constructor
  · exact (bitListIntegerAdd_length _ _).trans (by dsimp [BitFourierInteger.Width] at hz hw; omega)
  · exact (bitListIntegerAdd_length _ _).trans (by dsimp [BitFourierInteger.Width] at hz hw; omega)

theorem bitFourierMul_width (z w : BitFourierInteger) (L : ℕ) (hz : z.Width L) (hw : w.Width L) :
    (bitFourierMul z w).Width (2*L+1) := by
  have hrr := bitListIntegerMul_length z.re w.re
  have hii := bitListIntegerMul_length z.im w.im
  have hri := bitListIntegerMul_length z.re w.im
  have hir := bitListIntegerMul_length z.im w.re
  constructor
  · exact (bitListIntegerSub_length _ _).trans (by dsimp [BitFourierInteger.Width] at hz hw; omega)
  · exact (bitListIntegerAdd_length _ _).trans (by dsimp [BitFourierInteger.Width] at hz hw; omega)

theorem bitFourierScale_width (D : BitListInteger) (z : BitFourierInteger) (L : ℕ)
    (hD : D.digits.length≤L) (hz : z.Width L) : (bitFourierScale D z).Width (2*L) := by
  constructor
  · exact (bitListIntegerMul_length _ _).trans (by dsimp [BitFourierInteger.Width] at hz; omega)
  · exact (bitListIntegerMul_length _ _).trans (by dsimp [BitFourierInteger.Width] at hz; omega)

def bitFourierAddWork (z w : BitFourierInteger) : ℕ :=
  bitListIntegerAddCost z.re w.re+bitListIntegerAddCost z.im w.im

def bitFourierMulWork (z w : BitFourierInteger) : ℕ :=
  bitListIntegerMulCost z.re w.re+bitListIntegerMulCost z.im w.im+
  bitListIntegerMulCost z.re w.im+bitListIntegerMulCost z.im w.re+
  bitListIntegerSubCost (bitListIntegerMul z.re w.re) (bitListIntegerMul z.im w.im)+
  bitListIntegerAddCost (bitListIntegerMul z.re w.im) (bitListIntegerMul z.im w.re)

def bitFourierScaleWork (D : BitListInteger) (z : BitFourierInteger) : ℕ :=
  bitListIntegerMulCost D z.re+bitListIntegerMulCost D z.im

def bitFourierButterflyWork (D : BitListInteger) (e t o : BitFourierInteger) : ℕ :=
  bitFourierScaleWork D e+bitFourierMulWork t o+
    bitFourierAddWork (bitFourierScale D e) (bitFourierMul t o)

theorem bitFourierAddWork_bound (z w : BitFourierInteger) (L : ℕ)
    (hz : z.Width L) (hw : w.Width L) : bitFourierAddWork z w≤60*(L+1) := by
  have hre := bitListIntegerAddCost_bound z.re w.re L hz.1 hw.1
  have him := bitListIntegerAddCost_bound z.im w.im L hz.2 hw.2
  unfold bitFourierAddWork
  omega

theorem bitFourierMulWork_bound (z w : BitFourierInteger) (L : ℕ)
    (hz : z.Width L) (hw : w.Width L) :
    bitFourierMulWork z w≤164*(L+1)^2+61*(2*L+1) := by
  have hrr := bitListIntegerMulCost_bound z.re w.re L hz.1 hw.1
  have hii := bitListIntegerMulCost_bound z.im w.im L hz.2 hw.2
  have hri := bitListIntegerMulCost_bound z.re w.im L hz.1 hw.2
  have hir := bitListIntegerMulCost_bound z.im w.re L hz.2 hw.1
  have hrrL : (bitListIntegerMul z.re w.re).digits.length≤2*L :=
    (bitListIntegerMul_length _ _).trans (by have h₁ := hz.1; have h₂ := hw.1; omega)
  have hiiL : (bitListIntegerMul z.im w.im).digits.length≤2*L :=
    (bitListIntegerMul_length _ _).trans (by have h₁ := hz.2; have h₂ := hw.2; omega)
  have hriL : (bitListIntegerMul z.re w.im).digits.length≤2*L :=
    (bitListIntegerMul_length _ _).trans (by have h₁ := hz.1; have h₂ := hw.2; omega)
  have hirL : (bitListIntegerMul z.im w.re).digits.length≤2*L :=
    (bitListIntegerMul_length _ _).trans (by have h₁ := hz.2; have h₂ := hw.1; omega)
  have hs := bitListIntegerSubCost_bound _ _ (2*L) hrrL hiiL
  have ha := bitListIntegerAddCost_bound _ _ (2*L) hriL hirL
  unfold bitFourierMulWork
  omega

theorem bitFourierScaleWork_bound (D : BitListInteger) (z : BitFourierInteger) (L : ℕ)
    (hD : D.digits.length≤L) (hz : z.Width L) : bitFourierScaleWork D z≤82*(L+1)^2 := by
  have hre := bitListIntegerMulCost_bound D z.re L hD hz.1
  have him := bitListIntegerMulCost_bound D z.im L hD hz.2
  unfold bitFourierScaleWork
  omega

/-- Includes the larger intermediate products inside the butterfly, not
only the input and output widths. -/
theorem bitFourierButterflyWork_bound (D : BitListInteger) (e t o : BitFourierInteger) (L : ℕ)
    (hD : D.digits.length≤L) (he : e.Width L) (ht : t.Width L) (ho : o.Width L) :
    bitFourierButterflyWork D e t o≤512*(L+1)^2 := by
  have hs := bitFourierScaleWork_bound D e L hD he
  have hm := bitFourierMulWork_bound t o L ht ho
  have hsw := bitFourierScale_width D e L hD he
  have hmw := bitFourierMul_width t o L ht ho
  have ha := bitFourierAddWork_bound (bitFourierScale D e) (bitFourierMul t o) (2*L+1)
    ⟨hsw.1.trans (Nat.le_succ _),hsw.2.trans (Nat.le_succ _)⟩ hmw
  unfold bitFourierButterflyWork
  nlinarith

end Optss
