import Optss.Enumeration
import Optss.MultivariateConvolution
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Int.Interval

/-!
# Removing unusable labels and zero-budget coordinates

These are the preprocessing steps in the proof of Lemma 2.1. The input labels
remain distinct even when their vectors agree. Deleting zero vectors preserves
the sum, and every absolute-budget witness uses only individually in-box labels.
Positive-coordinate restriction has an explicit inverse on the budget box.
-/

namespace Optss
open scoped BigOperators
noncomputable section
variable {ι : Type*} [Fintype ι] {d : ℕ}

def colorEligibleLabels (v : ι → IntVec d) (Δ : Fin d → ℕ) : Finset ι := by
  classical
  exact Finset.univ.filter (fun i => InBox (fun j => (Δ j : ℤ)) (v i) ∧ v i ≠ 0)

def removeZeroLabels (v : ι → IntVec d) (s : Finset ι) : Finset ι := by
  classical
  exact s.filter (fun i => v i ≠ 0)

omit [Fintype ι] in
theorem removeZeroLabels_sum (v : ι → IntVec d) (s : Finset ι) :
    (∑ i ∈ removeZeroLabels v s, v i) = ∑ i ∈ s, v i := by
  classical
  exact Finset.sum_subset (Finset.filter_subset _ _) (by
    intro i hi hn
    simpa only [removeZeroLabels, Finset.mem_filter, hi, true_and, not_not] using hn)

omit [Fintype ι] in
theorem absoluteBudget_item_inBox (v : ι → IntVec d) (s : Finset ι)
    (Δ : Fin d → ℕ) (h : AbsoluteBudget v s (fun j => (Δ j : ℤ)))
    {i : ι} (hi : i ∈ s) : InBox (fun j => (Δ j : ℤ)) (v i) := by
  intro j
  exact (Finset.single_le_sum (fun x _ => abs_nonneg (v x j)) hi).trans (h j)

theorem removeZeroLabels_eligible (v : ι → IntVec d) (s : Finset ι)
    (Δ : Fin d → ℕ) (h : AbsoluteBudget v s (fun j => (Δ j : ℤ))) :
    removeZeroLabels v s ⊆ colorEligibleLabels v Δ := by
  classical
  intro i hi
  obtain ⟨his, hn⟩ := Finset.mem_filter.mp hi
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, absoluteBudget_item_inBox v s Δ h his, hn⟩

omit [Fintype ι] in
theorem removeZeroLabels_budget (v : ι → IntVec d) (s : Finset ι)
    (Δ : Fin d → ℕ) (h : AbsoluteBudget v s (fun j => (Δ j : ℤ))) :
    AbsoluteBudget v (removeZeroLabels v s) (fun j => (Δ j : ℤ)) := by
  classical
  exact absoluteBudget_mono v (Finset.filter_subset _ _) h

/-- If preprocessing leaves no labels, every required sum is zero. -/
theorem budgeted_sum_eq_zero_of_no_eligible (v : ι → IntVec d) (Δ : Fin d → ℕ)
    (hempty : colorEligibleLabels v Δ = ∅) (s : Finset ι)
    (h : AbsoluteBudget v s (fun j => (Δ j : ℤ))) : (∑ i ∈ s, v i) = 0 := by
  have hs : removeZeroLabels v s = ∅ :=
    Finset.subset_empty.mp (hempty ▸ removeZeroLabels_eligible v s Δ h)
  rw [← removeZeroLabels_sum v s, hs, Finset.sum_empty]

abbrev PositiveCoordinate (Δ : Fin d → ℕ) := {j : Fin d // 0 < Δ j}

def positiveCoordinateIndex (Δ : Fin d → ℕ) :
    Fin (Fintype.card (PositiveCoordinate Δ)) → Fin d :=
  fun j => ((Fintype.equivFin (PositiveCoordinate Δ)).symm j).val

def positiveBudget (Δ : Fin d → ℕ) : Fin (Fintype.card (PositiveCoordinate Δ)) → ℕ :=
  fun j => Δ (positiveCoordinateIndex Δ j)

def restrictPositiveCoordinates (Δ : Fin d → ℕ) (x : IntVec d) :
    IntVec (Fintype.card (PositiveCoordinate Δ)) := fun j => x (positiveCoordinateIndex Δ j)

def restorePositiveCoordinates (Δ : Fin d → ℕ)
    (x : IntVec (Fintype.card (PositiveCoordinate Δ))) : IntVec d :=
  fun j => if h : 0 < Δ j then x (Fintype.equivFin (PositiveCoordinate Δ) ⟨j,h⟩) else 0

theorem positiveBudget_pos (Δ : Fin d → ℕ) (j : Fin (Fintype.card (PositiveCoordinate Δ))) :
    0 < positiveBudget Δ j := ((Fintype.equivFin (PositiveCoordinate Δ)).symm j).property

theorem inBox_zero_coordinate (Δ : Fin d → ℕ) (x : IntVec d)
    (hx : InBox (fun j => (Δ j : ℤ)) x) {j : Fin d} (hj : Δ j = 0) : x j = 0 := by
  have h := hx j
  simp only [hj, Nat.cast_zero, abs_nonpos_iff] at h
  exact h

theorem restore_restrictPositiveCoordinates (Δ : Fin d → ℕ) (x : IntVec d)
    (hx : InBox (fun j => (Δ j : ℤ)) x) :
    restorePositiveCoordinates Δ (restrictPositiveCoordinates Δ x) = x := by
  funext j
  by_cases hj : 0 < Δ j
  · simp [restorePositiveCoordinates, restrictPositiveCoordinates, positiveCoordinateIndex, hj]
  · simp [restorePositiveCoordinates, hj, inBox_zero_coordinate Δ x hx (Nat.eq_zero_of_not_pos hj)]

theorem restrict_restorePositiveCoordinates (Δ : Fin d → ℕ)
    (x : IntVec (Fintype.card (PositiveCoordinate Δ))) :
    restrictPositiveCoordinates Δ (restorePositiveCoordinates Δ x) = x := by
  funext j
  have hj := positiveBudget_pos Δ j
  simp only [positiveBudget] at hj
  have hpos := ((Fintype.equivFin (PositiveCoordinate Δ)).symm j).property
  simp [restrictPositiveCoordinates, restorePositiveCoordinates, positiveCoordinateIndex, hpos]

theorem restrictPositiveCoordinates_inBox (Δ : Fin d → ℕ) (x : IntVec d)
    (hx : InBox (fun j => (Δ j : ℤ)) x) :
    InBox (fun j => (positiveBudget Δ j : ℤ)) (restrictPositiveCoordinates Δ x) :=
  fun j => hx (positiveCoordinateIndex Δ j)

theorem restrictPositiveCoordinates_ne_zero (Δ : Fin d → ℕ) (x : IntVec d)
    (hx : InBox (fun j => (Δ j : ℤ)) x) (hn : x ≠ 0) :
    restrictPositiveCoordinates Δ x ≠ 0 := by
  intro h
  apply hn
  rw [← restore_restrictPositiveCoordinates Δ x hx, h]
  ext j
  simp [restorePositiveCoordinates]

omit [Fintype ι] in
theorem restrictPositiveCoordinates_sum (Δ : Fin d → ℕ) (v : ι → IntVec d) (s : Finset ι) :
    restrictPositiveCoordinates Δ (∑ i ∈ s, v i) =
      ∑ i ∈ s, restrictPositiveCoordinates Δ (v i) := by
  ext j
  simp [restrictPositiveCoordinates]

omit [Fintype ι] in
theorem restrictPositiveCoordinates_budget (Δ : Fin d → ℕ) (v : ι → IntVec d) (s : Finset ι)
    (h : AbsoluteBudget v s (fun j => (Δ j : ℤ))) :
    AbsoluteBudget (fun i => restrictPositiveCoordinates Δ (v i)) s
      (fun j => (positiveBudget Δ j : ℤ)) := fun j => h (positiveCoordinateIndex Δ j)

def integerBudgetBox (Δ : Fin d → ℕ) : Finset (IntVec d) :=
  Fintype.piFinset (fun j => Finset.Icc (-(Δ j : ℤ)) (Δ j : ℤ))

@[simp] theorem mem_integerBudgetBox (Δ : Fin d → ℕ) (x : IntVec d) :
    x ∈ integerBudgetBox Δ ↔ InBox (fun j => (Δ j : ℤ)) x := by
  simp [integerBudgetBox, Fintype.mem_piFinset, InBox, abs_le]

theorem integerBudgetBox_card (Δ : Fin d → ℕ) :
    (integerBudgetBox Δ).card = ∏ j, (2*Δ j+1) := by
  rw [integerBudgetBox, Fintype.card_piFinset]
  apply Finset.prod_congr rfl
  intro j _
  rw [Int.card_Icc]
  omega

theorem integerBudgetBox_card_le (Δ : Fin d → ℕ) :
    (integerBudgetBox Δ).card ≤ 2^d * boxVolume Δ := by
  rw [integerBudgetBox_card]
  calc
    _ ≤ ∏ j : Fin d, (2 * (Δ j + 1)) := by
      apply Finset.prod_le_prod'
      intro j _
      omega
    _ = 2^d * boxVolume Δ := by simp [Finset.prod_mul_distrib, boxVolume]

end
end Optss
