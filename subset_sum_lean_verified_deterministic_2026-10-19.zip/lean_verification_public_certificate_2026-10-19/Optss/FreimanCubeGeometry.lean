import Optss.FreimanHyperplane
import Optss.FreimanSymmetricSubset

/-!
# Geometric extension and reflection selection for Freiman cubes

These are the geometric and injectivity steps of Bilu Proposition 5.4:
an added symmetric segment captures one member of each reflection pair,
and choosing opposite-half-space representatives preserves cardinality.
The full dimension induction for the cube lemma is separate.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {E : Type*} [AddCommGroup E] [Module ℝ E]

def cubeAxisExtension (a : E) (D : Set E) : Set E :=
  {x | ∃ s : ℝ, |s| ≤ 1 ∧ ∃ q ∈ D, x = s • a + q}

theorem cubeAxisExtension_symmetric (a : E) (D : Set E)
    (hD : ∀ q ∈ D, -q ∈ D) : ∀ x ∈ cubeAxisExtension a D, -x ∈ cubeAxisExtension a D := by
  rintro x ⟨s, hs, q, hq, rfl⟩
  exact ⟨-s, by simpa using hs, -q, hD q hq, by simp [add_comm]⟩

/-- The one-direction base of the cube construction: maximize the absolute
value of the quotient coordinate, and every input point is in the resulting
segment modulo the kernel. This also handles a functional vanishing on the
whole input. -/
theorem exists_segment_mod_kernel (S : Finset E) (hS : S.Nonempty)
    (hsym : ∀ x ∈ S, -x ∈ S) (f : E →ₗ[ℝ] ℝ) :
    ∃ a ∈ S, -a ∈ S ∧ ∀ x ∈ S,
      x ∈ cubeAxisExtension a ({0} : Set E) + (LinearMap.ker f : Set E) := by
  obtain ⟨a, ha, hmax⟩ := Finset.exists_max_image S (fun x => |f x|) hS
  refine ⟨a, ha, hsym a ha, ?_⟩
  intro x hx
  by_cases hfa : f a = 0
  · have hfx : f x = 0 := abs_nonpos_iff.mp (by simpa [hfa] using hmax x hx)
    refine Set.mem_add.mpr ⟨a, ?_, x-a, ?_, by abel⟩
    · exact ⟨1, by norm_num, 0, Set.mem_singleton _, by simp⟩
    · change f (x-a) = 0
      simp [hfx, hfa]
  · let t := f x / f a
    have ht : |t| ≤ 1 := by
      rw [show t = f x / f a from rfl, abs_div, div_le_one (abs_pos.mpr hfa)]
      exact hmax x hx
    refine Set.mem_add.mpr ⟨t • a, ?_, x-t • a, ?_, by abel⟩
    · exact ⟨t, ht, 0, Set.mem_singleton _, by simp⟩
    · change f (x-t • a) = 0
      simp only [map_sub, map_smul, smul_eq_mul, t, div_mul_cancel₀ _ hfa, sub_self]

/-- The elementary geometric alternative behind the cube induction. The
input point and its local reflection lie in the same open half-space. -/
theorem cube_axis_reflection_alternative (L : Submodule ℝ E) (f : E →ₗ[ℝ] ℝ)
    (hfL : L ≤ LinearMap.ker f) (a q y : E) (t : ℝ) (D : Set E)
    (ha : 0 < f a) (hq : q ∈ D) (hqneg : -q ∈ D) (hy : y ∈ L)
    (hqp : 0 < f (a+q)) (hqm : 0 < f (a-q))
    (hup : 0 < f (a + q + t • a + y))
    (hvp : 0 < f (a - q - t • a - y)) :
    a + q + t • a + y ∈ cubeAxisExtension a D + (L : Set E) ∨
      a - q - t • a - y ∈ cubeAxisExtension a D + (L : Set E) := by
  have hfy : f y = 0 := hfL hy
  simp only [map_add, map_sub, map_smul, smul_eq_mul, hfy, add_zero, sub_zero] at hqp hqm hup hvp
  have htlow : -2 < t := by nlinarith
  have hthigh : t < 2 := by nlinarith
  by_cases ht : t ≤ 0
  · left
    refine Set.mem_add.mpr ⟨(1+t) • a + q, ?_, y, hy, ?_⟩
    · exact ⟨1+t, abs_le.mpr ⟨by linarith, by linarith⟩, q, hq, rfl⟩
    · simp only [add_smul, one_smul]
      abel
  · right
    refine Set.mem_add.mpr ⟨(1-t) • a - q, ?_, -y, L.neg_mem hy, ?_⟩
    · exact ⟨1-t, abs_le.mpr ⟨by linarith, by linarith⟩, -q, hqneg, by simp [sub_eq_add_neg]⟩
    · simp only [sub_smul, one_smul]
      abel

/-- Selecting a point when possible, and otherwise the negative of its
local reflection, is injective because the two choices lie in opposite
open half-spaces. -/
theorem reflection_selection_card_le (U T : Finset E) (a : E) (f : E →ₗ[ℝ] ℝ)
    (hpositive : ∀ x ∈ U, 0 < f x)
    (hreflect : ∀ x ∈ U, (2 : ℝ) • a - x ∈ U)
    (hTsym : ∀ x ∈ T, -x ∈ T)
    (hcover : ∀ x ∈ U, x ∈ T ∨ (2 : ℝ) • a - x ∈ T) : U.card ≤ T.card := by
  let F : E → E := fun x => if x ∈ T then x else -((2 : ℝ) • a - x)
  apply Finset.card_le_card_of_injOn F
  · intro x hx
    dsimp only [F]
    split_ifs with h
    · exact h
    · exact hTsym _ ((hcover x hx).resolve_left h)
  · intro x hx y hy he
    dsimp only [F] at he
    by_cases hxT : x ∈ T <;> by_cases hyT : y ∈ T
    · simpa only [if_pos hxT, if_pos hyT] using he
    · simp only [if_pos hxT, if_neg hyT] at he
      have hp := hpositive x hx
      have hn := hpositive _ (hreflect y hy)
      have hh := congrArg f he
      rw [map_neg] at hh
      linarith
    · simp only [if_neg hxT, if_pos hyT] at he
      have hp := hpositive y hy
      have hn := hpositive _ (hreflect x hx)
      have hh := congrArg f he
      rw [map_neg] at hh
      linarith
    · simp only [if_neg hxT, if_neg hyT] at he
      exact sub_right_injective (neg_injective he)

end
end Optss
