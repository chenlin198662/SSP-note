import Optss.FreimanGridLift
import Optss.FreimanCoveringBounds
import Optss.ActiveProgression
import Mathlib.Data.Nat.Size

/-! Short descriptions before properization in Lemma 10.2. These are exact
entry bounds for the lifted progression and the actual covering progression;
they make no assertion about the running time of finding the entries. -/
namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {r s : ℕ}

theorem single_mem_integerBudgetBox (β : Fin r → ℕ) (j : Fin r) (a : ℤ)
    (ha : |a|≤(β j : ℤ)) : Pi.single j a∈integerBudgetBox β := by
  rw [mem_integerBudgetBox]
  intro i
  by_cases hi : i=j
  · simpa [Pi.single_apply,hi] using ha
  · simp [Pi.single_apply,hi]

theorem integer_progression_active_bounds (ρ : IntVec r →+ ℤ) (β : Fin r → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox β)) (U : ℕ)
    (hbound : ∀ x∈integerProgressionValues ρ β, |x|≤(U : ℤ))
    (j : Fin r) (hj : 0<β j) :
    ρ (Pi.single j 1)≠0 ∧ |ρ (Pi.single j 1)|≤(U : ℤ) ∧ β j≤U := by
  have hunit : Pi.single j (1 : ℤ)∈integerBudgetBox β :=
    single_mem_integerBudgetBox β j 1 (by simpa using (show (1 : ℤ)≤β j by omega))
  have hnonzero : ρ (Pi.single j 1)≠0 := by
    intro he
    have hz : (0 : IntVec r)∈integerBudgetBox β := by rw [mem_integerBudgetBox]; intro i; simp
    have hv := hproper hunit hz (by simpa using he)
    have hh := congrFun hv j
    simpa using hh
  have hgen := hbound _ (Finset.mem_image.mpr ⟨_,hunit,rfl⟩)
  have hend : Pi.single j (β j : ℤ)∈integerBudgetBox β :=
    single_mem_integerBudgetBox β j _ (by simp)
  have hlast := hbound _ (Finset.mem_image.mpr ⟨_,hend,rfl⟩)
  have he : Pi.single j (β j : ℤ)=(β j : ℤ) • (Pi.single j 1 : IntVec r) := by
    ext i
    by_cases hi : i=j <;> simp [Pi.single_apply,hi]
  rw [he,map_zsmul,smul_eq_mul,abs_mul,abs_of_nonneg (by positivity : (0 : ℤ)≤β j)] at hlast
  have hab : (1 : ℤ)≤|ρ (Pi.single j 1)| := by
    have h := abs_pos.mpr hnonzero
    omega
  have hw : (β j : ℤ)≤U := by nlinarith [show (0 : ℤ)≤β j by positivity]
  exact ⟨hnonzero,hgen,by exact_mod_cast hw⟩

theorem double_difference_interval_bound (T : Finset ℤ) (u : ℕ)
    (hT : ∀ a∈T, 0≤a ∧ a≤u) {x : ℤ} (hx : x∈(T+T)-(T+T)) :
    |x|≤(2*u : ℕ) := by
  obtain ⟨a,ha,b,hb,rfl⟩ := Finset.mem_sub.mp hx
  obtain ⟨a₀,ha₀,a₁,ha₁,rfl⟩ := Finset.mem_add.mp ha
  obtain ⟨b₀,hb₀,b₁,hb₁,rfl⟩ := Finset.mem_add.mp hb
  have h₀ := hT a₀ ha₀
  have h₁ := hT a₁ ha₁
  have h₂ := hT b₀ hb₀
  have h₃ := hT b₁ hb₁
  rw [abs_le]
  push_cast
  constructor <;> omega

/-- Remove precisely the zero-width coordinates. Every remaining generator
is nonzero, and both generators and widths are bounded by the ambient radius. -/
theorem active_integer_progression_description (ρ : IntVec r →+ ℤ) (β : Fin r → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox β)) (U : ℕ)
    (hbound : ∀ x∈integerProgressionValues ρ β, |x|≤(U : ℤ)) :
    ∃ d≤r, ∃ (ρ' : IntVec d →+ ℤ) (γ : Fin d → ℕ),
      integerProgressionValues ρ' γ=integerProgressionValues ρ β ∧
      (integerBudgetBox γ).card=(integerBudgetBox β).card ∧
      Set.InjOn ρ' (integerBudgetBox γ) ∧
      ∀ j, 0<γ j ∧ ρ' (Pi.single j 1)≠0 ∧
        |ρ' (Pi.single j 1)|≤(U : ℤ) ∧ γ j≤U := by
  let d := Fintype.card (PositiveCoordinate β)
  let ρ' := positiveProgressionHom ρ β
  let γ := positiveBudget β
  have hv : integerProgressionValues ρ' γ=integerProgressionValues ρ β := by
    simpa only [one_mul] using (positiveProgression_values ρ β 1).symm
  have hc : (integerBudgetBox γ).card=(integerBudgetBox β).card := by
    simpa only [one_mul] using (scaledBox_positive_card β 1).symm
  have hp : Set.InjOn ρ' (integerBudgetBox γ) := by
    simpa only [one_mul] using (positiveProgression_proper_iff ρ β 1).mp
      (by simpa only [one_mul] using hproper)
  refine ⟨d,positiveCoordinate_count_le β,ρ',γ,hv,hc,hp,?_⟩
  intro j
  have hj : 0<γ j := positiveBudget_pos β j
  exact ⟨hj,integer_progression_active_bounds ρ' γ hp U (by rwa [hv]) j hj⟩

/-- The model lift has a short integer description after inactive coordinates
are removed. No bound on the model's chosen real lattice basis is needed. -/
theorem lifted_progression_short_description {H : Type*} [AddCommGroup H]
    (T : Finset ℤ) (hT : T.Nonempty) (u : ℕ) (hbound : ∀ a∈T, 0≤a ∧ a≤u)
    (f : ℤ → H) (hf : FreimanEight T f) (ρ : IntVec r →+ H) (β : Fin r → ℕ)
    (hP : integerProgressionValues ρ β⊆(T.image f+T.image f)-(T.image f+T.image f))
    (hproper : Set.InjOn ρ (integerBudgetBox β)) :
    ∃ d≤r, ∃ (ρ' : IntVec d →+ ℤ) (γ : Fin d → ℕ),
      integerProgressionValues ρ' γ⊆(T+T)-(T+T) ∧
      (integerBudgetBox γ).card=(integerBudgetBox β).card ∧
      Set.InjOn ρ' (integerBudgetBox γ) ∧
      ∀ j, 0<γ j ∧ ρ' (Pi.single j 1)≠0 ∧
        |ρ' (Pi.single j 1)|≤(2*u : ℕ) ∧ γ j≤2*u := by
  obtain ⟨ρ₀,_,hP₀,hproper₀,_⟩ := lift_model_progression T hT f hf ρ β hP hproper
  obtain ⟨d,hd,ρ',γ,hv,hc,hp,hbounds⟩ := active_integer_progression_description ρ₀ β
    hproper₀ (2*u) (fun _ hx => double_difference_interval_bound T u hbound (hP₀ hx))
  exact ⟨d,hd,ρ',γ,by rwa [hv],hc,hp,hbounds⟩

theorem appendProgressionHom_single_left (ρ : IntVec r →+ ℤ) (f : Fin s → ℤ)
    (j : Fin r) :
    appendProgressionHom ρ f (Pi.single (Fin.castAdd s j) 1)=ρ (Pi.single j 1) := by
  have hleft : (fun i : Fin r => (Pi.single (Fin.castAdd s j) (1 : ℤ) : IntVec (r+s)) (Fin.castAdd s i))=
      Pi.single j 1 := by
    ext i
    simp [Pi.single_apply,Fin.ext_iff]
  have hright (i : Fin s) : (Pi.single (Fin.castAdd s j) (1 : ℤ) : IntVec (r+s)) (Fin.natAdd r i)=0 := by
    have hne : Fin.natAdd r i≠Fin.castAdd s j := by
      intro h
      have hh := congrArg Fin.val h
      change r+i.val=j.val at hh
      omega
    simp [Pi.single_apply,hne]
  change ρ _+∑ i, (Pi.single (Fin.castAdd s j) (1 : ℤ) : IntVec (r+s)) (Fin.natAdd r i) • f i=_
  rw [hleft]
  simp only [hright,zero_zsmul,Finset.sum_const_zero,add_zero]

theorem appendProgressionHom_single_right (ρ : IntVec r →+ ℤ) (f : Fin s → ℤ)
    (j : Fin s) :
    appendProgressionHom ρ f (Pi.single (Fin.natAdd r j) 1)=f j := by
  have hleft : (fun i : Fin r => (Pi.single (Fin.natAdd r j) (1 : ℤ) : IntVec (r+s)) (Fin.castAdd s i))=0 := by
    ext i
    have hne : Fin.castAdd s i≠Fin.natAdd r j := by
      intro h
      have hh := congrArg Fin.val h
      change i.val=r+j.val at hh
      omega
    simp [Pi.single_apply,hne]
  have hright (i : Fin s) :
      (Pi.single (Fin.natAdd r j) (1 : ℤ) : IntVec (r+s)) (Fin.natAdd r i)=(Pi.single j (1 : ℤ) : IntVec s) i := by
    simp [Pi.single_apply,Fin.ext_iff]
  change ρ _+∑ i, (Pi.single (Fin.natAdd r j) (1 : ℤ) : IntVec (r+s)) (Fin.natAdd r i) • f i=_
  rw [hleft,map_zero,zero_add]
  simp [hright,Pi.single_apply]

theorem appendProgression_entry_bounds (ρ : IntVec r →+ ℤ) (β : Fin r → ℕ)
    (f : Fin s → ℤ) (U : ℕ)
    (hρ : ∀ j, |ρ (Pi.single j 1)|≤(U : ℤ))
    (hβ : ∀ j, β j≤U) (hf : ∀ j, |f j|≤(U : ℤ)) (j : Fin (r+s)) :
    |appendProgressionHom ρ f (Pi.single j 1)|≤(U : ℤ) ∧
      appendProgressionWidths β s j≤2*U+1 := by
  refine Fin.addCases ?_ ?_ j
  · intro i
    rw [appendProgressionHom_single_left]
    exact ⟨hρ i,by simp only [appendProgressionWidths,Fin.addCases_left]; have h := hβ i; omega⟩
  · intro i
    rw [appendProgressionHom_single_right]
    exact ⟨hf i,by simp [appendProgressionWidths,Fin.addCases_right]⟩

theorem interval_description_bits (u n : ℕ) (hn : n≤4*u+1) :
    n.size≤(u+2).size+2 := by
  apply Nat.size_le.mpr
  have h := Nat.lt_size_self (u+2)
  rw [pow_add]
  norm_num
  omega

/-- The actual Ruzsa-covering construction has bounded entries before any
properization. The translations are chosen from the original interval. -/
theorem progression_covering_short_description (A : Finset ℤ) (u : ℕ)
    (hA : ∀ a∈A, 0≤a ∧ a≤u) (ρ : IntVec r →+ ℤ) (β : Fin r → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox β))
    (hbound : ∀ x∈integerProgressionValues ρ β, |x|≤(2*u : ℕ))
    (K : ℝ) (hK : ((A+integerProgressionValues ρ β).card : ℝ)≤
      K*(integerProgressionValues ρ β).card) :
    ∃ d≤r+⌈K⌉₊, ∃ (ρ' : IntVec d →+ ℤ) (γ : Fin d → ℕ),
      A⊆integerProgressionValues ρ' γ ∧
      (integerBudgetBox γ).card≤(2^r*3^⌈K⌉₊)*(integerBudgetBox β).card ∧
      ∀ j, |ρ' (Pi.single j 1)|≤(2*u : ℕ) ∧ γ j≤4*u+1 ∧
        (ρ' (Pi.single j 1)).natAbs.size≤(u+2).size+2 ∧ (γ j).size≤(u+2).size+2 := by
  obtain ⟨q,hq,ρ₀,β₀,hvalues,hcard,_,hentries⟩ :=
    active_integer_progression_description ρ β hproper (2*u) hbound
  have hP : (integerProgressionValues ρ₀ β₀).Nonempty := (integerBudgetBox_nonempty β₀).image ρ₀
  have hK₀ : ((A+integerProgressionValues ρ₀ β₀).card : ℝ)≤
      K*(integerProgressionValues ρ₀ β₀).card := by rwa [hvalues]
  obtain ⟨F,hFA,hF,hcover⟩ := Finset.ruzsa_covering_add hP hK₀
  have hFc : F.card≤⌈K⌉₊ := by exact_mod_cast hF.trans (Nat.le_ceil K)
  refine ⟨q+F.card,Nat.add_le_add hq hFc,appendProgressionHom ρ₀ (finsetGenerators F),
    appendProgressionWidths β₀ F.card,?_,?_,?_⟩
  · apply hcover.trans
    simpa only [finsetGenerators_image] using
      appendProgression_covers_difference ρ₀ β₀ (finsetGenerators F)
  · apply (appendProgressionWidths_card_le β₀ F.card).trans
    rw [hcard]
    gcongr <;> norm_num
  · intro j
    have hf (i : Fin F.card) : |finsetGenerators F i|≤(2*u : ℕ) := by
      have hi := hA _ (hFA ((F.equivFin.symm i).property))
      change |(F.equivFin.symm i).val|≤(2*u : ℕ)
      rw [abs_of_nonneg hi.1]
      push_cast
      omega
    have hb := appendProgression_entry_bounds ρ₀ β₀ (finsetGenerators F) (2*u)
      (fun i => (hentries i).2.2.1) (fun i => (hentries i).2.2.2) hf j
    have hn : (appendProgressionHom ρ₀ (finsetGenerators F) (Pi.single j 1)).natAbs≤2*u := by
      have he := hb.1
      rw [← Int.natCast_natAbs] at he
      exact_mod_cast he
    refine ⟨hb.1,by omega,interval_description_bits u _ (by omega),
      interval_description_bits u _ (by omega)⟩

end
end Optss
