import Optss.IntegerProgramming
import Mathlib.Data.Pi.Interval
import Mathlib.Data.Finset.Max

/-!
# Finite box extrema, partition, discrepancy, and objectives

These are the elementary exact reductions of §11.2–11.3. Optima are obtained
from actual finite feasible boxes, rather than assumed as input certificates.
The file makes no proximity, binary-search cost, or running-time claim.
-/

namespace Optss
open scoped BigOperators
noncomputable section
variable {ι G : Type*} [Fintype ι] [AddCommGroup G]

/-- Select the endpoint minimizing one linear row coordinate by coordinate. -/
def rowBoxMinimizer (a l u : ι → ℤ) (i : ι) : ℤ :=
  if 0 ≤ a i then l i else u i

/-- Select the endpoint maximizing one linear row coordinate by coordinate. -/
def rowBoxMaximizer (a l u : ι → ℤ) (i : ι) : ℤ :=
  if 0 ≤ a i then u i else l i

omit [Fintype ι] in
theorem rowBoxMinimizer_mem (a l u : ι → ℤ) (hlu : ∀ i, l i ≤ u i) :
    ∀ i, l i ≤ rowBoxMinimizer a l u i ∧ rowBoxMinimizer a l u i ≤ u i := by
  intro i
  have hi := hlu i
  simp only [rowBoxMinimizer]
  split_ifs <;> exact ⟨by omega, by omega⟩

omit [Fintype ι] in
theorem rowBoxMaximizer_mem (a l u : ι → ℤ) (hlu : ∀ i, l i ≤ u i) :
    ∀ i, l i ≤ rowBoxMaximizer a l u i ∧ rowBoxMaximizer a l u i ≤ u i := by
  intro i
  have hi := hlu i
  simp only [rowBoxMaximizer]
  split_ifs <;> exact ⟨by omega, by omega⟩

theorem weightedSum_rowBoxMinimizer (a l u : ι → ℤ) (hlu : ∀ i, l i ≤ u i) :
    weightedSum a (rowBoxMinimizer a l u) = ∑ i, min (a i * l i) (a i * u i) := by
  simp only [weightedSum, zsmul_eq_mul, Int.cast_id]
  apply Finset.sum_congr rfl
  intro i _
  have hi := hlu i
  by_cases ha : 0 ≤ a i
  · rw [rowBoxMinimizer, if_pos ha, min_eq_left (by nlinarith)]
    ring
  · rw [rowBoxMinimizer, if_neg ha, min_eq_right (by nlinarith)]
    ring

theorem weightedSum_rowBoxMaximizer (a l u : ι → ℤ) (hlu : ∀ i, l i ≤ u i) :
    weightedSum a (rowBoxMaximizer a l u) = ∑ i, max (a i * l i) (a i * u i) := by
  simp only [weightedSum, zsmul_eq_mul, Int.cast_id]
  apply Finset.sum_congr rfl
  intro i _
  have hi := hlu i
  by_cases ha : 0 ≤ a i
  · rw [rowBoxMaximizer, if_pos ha, max_eq_right (by nlinarith)]
    ring
  · rw [rowBoxMaximizer, if_neg ha, max_eq_left (by nlinarith)]
    ring

theorem weightedSum_le_box_max (a l u x : ι → ℤ)
    (hx : ∀ i, l i ≤ x i ∧ x i ≤ u i) :
    weightedSum a x ≤ ∑ i, max (a i * l i) (a i * u i) := by
  simp only [weightedSum, zsmul_eq_mul, Int.cast_id]
  apply Finset.sum_le_sum
  intro i _
  have hi := hx i
  by_cases ha : 0 ≤ a i
  · exact (by nlinarith : x i * a i ≤ a i * u i).trans (le_max_right _ _)
  · exact (by nlinarith : x i * a i ≤ a i * l i).trans (le_max_left _ _)

/-- Both exact extrema are attained by explicit feasible integer endpoints. -/
theorem linear_row_box_extrema (a l u : ι → ℤ) (hlu : ∀ i, l i ≤ u i) :
    (∃ xmin : ι → ℤ, (∀ i, l i ≤ xmin i ∧ xmin i ≤ u i) ∧
      weightedSum a xmin = ∑ i, min (a i * l i) (a i * u i)) ∧
    (∃ xmax : ι → ℤ, (∀ i, l i ≤ xmax i ∧ xmax i ≤ u i) ∧
      weightedSum a xmax = ∑ i, max (a i * l i) (a i * u i)) ∧
    ∀ x : ι → ℤ, (∀ i, l i ≤ x i ∧ x i ≤ u i) →
      (∑ i, min (a i * l i) (a i * u i)) ≤ weightedSum a x ∧
      weightedSum a x ≤ ∑ i, max (a i * l i) (a i * u i) := by
  exact ⟨⟨rowBoxMinimizer a l u, rowBoxMinimizer_mem a l u hlu,
      weightedSum_rowBoxMinimizer a l u hlu⟩,
    ⟨rowBoxMaximizer a l u, rowBoxMaximizer_mem a l u hlu,
      weightedSum_rowBoxMaximizer a l u hlu⟩,
    fun x hx => ⟨weightedSum_ge_box_min a l u x hx, weightedSum_le_box_max a l u x hx⟩⟩

variable [DecidableEq ι]

/-- A subset and its complement partition the labelled input exactly. -/
theorem subset_complement_sum (v : ι → G) (s : Finset ι) :
    (∑ i ∈ s, v i) + (∑ i ∈ sᶜ, v i) = ∑ i, v i := by
  classical
  exact Finset.sum_add_sum_compl s v

/-- Equal sums on the two sides of a partition are exactly the doubled-target
condition, which avoids division in the ambient group. -/
theorem equal_partition_iff_twice (v : ι → G) (s : Finset ι) :
    (∑ i ∈ s, v i) = (∑ i ∈ sᶜ, v i) ↔
      (2 : ℕ) • (∑ i ∈ s, v i) = ∑ i, v i := by
  classical
  rw [← subset_complement_sum v s, two_nsmul]
  exact ⟨fun h => by rw [h], fun h => add_left_cancel h⟩

/-- The difference between partition sides equals `2Ax - A1`. -/
theorem partition_difference (v : ι → G) (s : Finset ι) :
    (∑ i ∈ s, v i) - (∑ i ∈ sᶜ, v i) =
      (2 : ℕ) • (∑ i ∈ s, v i) - ∑ i, v i := by
  classical
  rw [← subset_complement_sum v s, two_nsmul]
  abel

/-- Binary coordinates are precisely the indicators of labelled subsets. -/
theorem binary_counts_iff_indicator (x : ι → ℤ) :
    (∀ i, 0 ≤ x i ∧ x i ≤ 1) ↔
      ∃ s : Finset ι, ∀ i, x i = if i ∈ s then 1 else 0 := by
  classical
  constructor
  · intro hx
    refine ⟨Finset.univ.filter (fun i => x i = 1), ?_⟩
    intro i
    by_cases hi : x i = 1
    · simp [hi]
    · have : x i = 0 := by have := hx i; omega
      simp [this]
  · rintro ⟨s, hs⟩ i
    rw [hs i]
    split_ifs <;> norm_num

/-- The linear image of an indicator is the corresponding subset sum. -/
theorem weightedSum_indicator (v : ι → G) (s : Finset ι) :
    weightedSum v (fun i => if i ∈ s then 1 else 0) = ∑ i ∈ s, v i := by
  classical
  simp [weightedSum, Finset.sum_ite_mem]

/-- Coordinatewise discrepancy at threshold `k`, without choosing a norm
representation for the finite-dimensional integer vector space. -/
def DiscrepancyThreshold {d : ℕ} (v : ι → IntVec d) (x : ι → ℤ) (k : ℤ) : Prop :=
  ∀ j, |(2 : ℤ) * (weightedSum v x) j - (∑ i, v i) j| ≤ k

omit [DecidableEq ι] in
theorem discrepancyThreshold_mono {d : ℕ} (v : ι → IntVec d) (x : ι → ℤ)
    {k h : ℤ} (hkh : k ≤ h) (hk : DiscrepancyThreshold v x k) :
    DiscrepancyThreshold v x h := fun j => (hk j).trans hkh

omit [DecidableEq ι] in
theorem discrepancyThreshold_iff_inequalities {d : ℕ} (v : ι → IntVec d)
    (x : ι → ℤ) (k : ℤ) :
    DiscrepancyThreshold v x k ↔ ∀ j,
      -k ≤ (2 : ℤ) * (weightedSum v x) j - (∑ i, v i) j ∧
      (2 : ℤ) * (weightedSum v x) j - (∑ i, v i) j ≤ k := by
  simp only [DiscrepancyThreshold, abs_le]

/-- The actual finite set of feasible vectors inside the integer box. -/
def feasibleIntegerBox (v : ι → G) (l u : ι → ℤ) (t : G) : Finset (ι → ℤ) := by
  classical
  exact (Finset.Icc l u).filter (fun x => weightedSum v x = t)

theorem mem_feasibleIntegerBox (v : ι → G) (l u x : ι → ℤ) (t : G) :
    x ∈ feasibleIntegerBox v l u t ↔
      (∀ i, l i ≤ x i ∧ x i ≤ u i) ∧ weightedSum v x = t := by
  classical
  simp only [feasibleIntegerBox, Finset.mem_filter, Finset.mem_Icc, Pi.le_def, ← forall_and]

theorem feasibleIntegerBox_nonempty_iff (v : ι → G) (l u : ι → ℤ) (t : G) :
    (feasibleIntegerBox v l u t).Nonempty ↔ BoundedIP v l u t := by
  simp only [Finset.Nonempty, mem_feasibleIntegerBox, BoundedIP]

/-- Feasibility below a proposed objective threshold. -/
def ObjectiveThreshold (v : ι → G) (l u c : ι → ℤ) (t : G) (k : ℤ) : Prop :=
  ∃ x : ι → ℤ, (∀ i, l i ≤ x i ∧ x i ≤ u i) ∧
    weightedSum v x = t ∧ weightedSum c x ≤ k

omit [DecidableEq ι] in
theorem objectiveThreshold_mono (v : ι → G) (l u c : ι → ℤ) (t : G)
    {k h : ℤ} (hkh : k ≤ h) (hk : ObjectiveThreshold v l u c t k) :
    ObjectiveThreshold v l u c t h := by
  rcases hk with ⟨x, hx, hxt, hcx⟩
  exact ⟨x, hx, hxt, hcx.trans hkh⟩

/-- A nonempty finite feasible box has an actual minimizing vector and a
maximizing vector, even if some variable bounds were originally very large. -/
theorem boundedIP_exists_objective_extrema (v : ι → G) (l u c : ι → ℤ) (t : G)
    (hfeas : BoundedIP v l u t) :
    (∃ xmin : ι → ℤ,
      (∀ i, l i ≤ xmin i ∧ xmin i ≤ u i) ∧ weightedSum v xmin = t ∧
      ∀ x : ι → ℤ, (∀ i, l i ≤ x i ∧ x i ≤ u i) → weightedSum v x = t →
        weightedSum c xmin ≤ weightedSum c x) ∧
    (∃ xmax : ι → ℤ,
      (∀ i, l i ≤ xmax i ∧ xmax i ≤ u i) ∧ weightedSum v xmax = t ∧
      ∀ x : ι → ℤ, (∀ i, l i ≤ x i ∧ x i ≤ u i) → weightedSum v x = t →
        weightedSum c x ≤ weightedSum c xmax) := by
  classical
  have hn := (feasibleIntegerBox_nonempty_iff v l u t).mpr hfeas
  obtain ⟨xmin, hminmem, hmin⟩ := (feasibleIntegerBox v l u t).exists_min_image (weightedSum c) hn
  obtain ⟨xmax, hmaxmem, hmax⟩ := (feasibleIntegerBox v l u t).exists_max_image (weightedSum c) hn
  obtain ⟨hminbox, hmint⟩ := (mem_feasibleIntegerBox v l u xmin t).mp hminmem
  obtain ⟨hmaxbox, hmaxt⟩ := (mem_feasibleIntegerBox v l u xmax t).mp hmaxmem
  exact ⟨⟨xmin, hminbox, hmint, fun x hx hxt =>
      hmin x ((mem_feasibleIntegerBox v l u x t).mpr ⟨hx, hxt⟩)⟩,
    ⟨xmax, hmaxbox, hmaxt, fun x hx hxt =>
      hmax x ((mem_feasibleIntegerBox v l u x t).mpr ⟨hx, hxt⟩)⟩⟩

/-- The minimum is the exact transition point of the monotone threshold
predicate, and comes with a feasible vector attaining it. -/
theorem exists_objective_transition (v : ι → G) (l u c : ι → ℤ) (t : G)
    (hfeas : BoundedIP v l u t) :
    ∃ xmin : ι → ℤ, (∀ i, l i ≤ xmin i ∧ xmin i ≤ u i) ∧
      weightedSum v xmin = t ∧
      ∀ k : ℤ, ObjectiveThreshold v l u c t k ↔ weightedSum c xmin ≤ k := by
  obtain ⟨⟨xmin, hx, hxt, hmin⟩, _⟩ := boundedIP_exists_objective_extrema v l u c t hfeas
  refine ⟨xmin, hx, hxt, fun k => ?_⟩
  constructor
  · rintro ⟨x, hbox, heq, hcx⟩
    exact (hmin x hbox heq).trans hcx
  · intro hk
    exact ⟨xmin, hx, hxt, hk⟩

/-- Add the objective as one coordinate and add one unit slack column. -/
def objectiveSlackColumns (v : ι → G) (c : ι → ℤ) : ι ⊕ Unit → G × ℤ :=
  Sum.elim (fun i => (v i, c i)) (fun _ => (0, 1))

omit [DecidableEq ι] in
theorem weightedSum_objectiveSlackColumns (v : ι → G) (c : ι → ℤ)
    (y : ι ⊕ Unit → ℤ) :
    weightedSum (objectiveSlackColumns v c) y =
      (weightedSum v (fun i => y (Sum.inl i)),
       weightedSum c (fun i => y (Sum.inl i)) + y (Sum.inr ())) := by
  apply Prod.ext <;>
    simp [weightedSum, objectiveSlackColumns, Fintype.sum_sum_type,
      Prod.fst_sum, Prod.snd_sum, zsmul_eq_mul]

omit [DecidableEq ι] in
/-- An objective threshold is exactly one additional bounded integer row,
using an explicitly bounded slack derived from the row's box minimum. -/
theorem objectiveThreshold_iff_augmentedIP (v : ι → G) (l u c : ι → ℤ)
    (t : G) (k : ℤ) :
    ObjectiveThreshold v l u c t k ↔
      BoundedIP (objectiveSlackColumns v c)
        (Sum.elim l (fun _ => 0))
        (Sum.elim u (fun _ => k - ∑ i, min (c i * l i) (c i * u i))) (t, k) := by
  constructor
  · rintro ⟨x, hx, hxt, hcx⟩
    obtain ⟨s, hs0, hsb, hcs⟩ :=
      (le_iff_exists_bounded_slack (weightedSum c x) k _
        (weightedSum_ge_box_min c l u x hx)).mp hcx
    refine ⟨Sum.elim x (fun _ => s), ?_, ?_⟩
    · intro i
      cases i with
      | inl i => exact hx i
      | inr j => exact ⟨hs0, hsb⟩
    · rw [weightedSum_objectiveSlackColumns]
      change (weightedSum v x, weightedSum c x + s) = (t, k)
      rw [hxt, hcs]
  · rintro ⟨y, hy, heq⟩
    rw [weightedSum_objectiveSlackColumns] at heq
    refine ⟨fun i => y (Sum.inl i), fun i => hy (Sum.inl i), congrArg Prod.fst heq, ?_⟩
    have hs := (hy (Sum.inr ())).1
    have hsum := congrArg Prod.snd heq
    dsimp at hs hsum
    omega

omit [DecidableEq ι] in
/-- A lower objective threshold is an upper threshold for the negated row. -/
theorem objective_lower_threshold_iff (v : ι → G) (l u c : ι → ℤ)
    (t : G) (k : ℤ) :
    (∃ x : ι → ℤ, (∀ i, l i ≤ x i ∧ x i ≤ u i) ∧
      weightedSum v x = t ∧ k ≤ weightedSum c x) ↔
    ObjectiveThreshold v l u (fun i => -c i) t (-k) := by
  have hneg (x : ι → ℤ) : weightedSum (fun i => -c i) x = -weightedSum c x := by
    simp [weightedSum]
  simp only [ObjectiveThreshold, hneg, neg_le_neg_iff]

/-- Exact vector partition first tests even total coordinates, then asks for
one subset summing to their coordinatewise halves. -/
theorem equal_partition_iff_half_sum {d : ℕ} (v : ι → IntVec d) :
    (∃ s : Finset ι, (∑ i ∈ s, v i) = (∑ i ∈ sᶜ, v i)) ↔
      (∀ j, (2 : ℤ) ∣ (∑ i, v i) j) ∧
      (fun j => (∑ i, v i) j / 2) ∈ subsetSums v := by
  constructor
  · rintro ⟨s, hs⟩
    have ht := (equal_partition_iff_twice v s).mp hs
    have hj (j : Fin d) : (∑ i, v i) j = 2 * (∑ i ∈ s, v i) j := by
      have h := congrFun ht j
      simpa [two_nsmul, two_mul] using h.symm
    refine ⟨fun j => ⟨(∑ i ∈ s, v i) j, hj j⟩, s, ?_⟩
    funext j
    rw [hj]
    omega
  · rintro ⟨heven, s, hs⟩
    refine ⟨s, (equal_partition_iff_twice v s).mpr ?_⟩
    rw [hs]
    funext j
    have h := Int.ediv_mul_cancel (heven j)
    simpa [two_nsmul, two_mul, mul_comm] using h

/-- The maximum absolute coordinate difference of the two partition sums. -/
def partitionDiscrepancy {d : ℕ} (v : ι → IntVec d) (s : Finset ι) : ℕ :=
  Finset.univ.sup (fun j => ((∑ i ∈ s, v i j) - (∑ i ∈ sᶜ, v i j)).natAbs)

/-- The discrepancy search interval `[0,nN]` follows from the original
coordinate bounds, for every binary partition. -/
theorem partitionDiscrepancy_le {d : ℕ} (v : ι → IntVec d) (s : Finset ι)
    (N : ℕ) (hv : ∀ i j, |v i j| ≤ (N : ℤ)) :
    partitionDiscrepancy v s ≤ Fintype.card ι * N := by
  apply Finset.sup_le
  intro j _
  have h : |(∑ i ∈ s, v i j) - (∑ i ∈ sᶜ, v i j)| ≤ (Fintype.card ι : ℤ) * N := by
    calc
      _ ≤ |∑ i ∈ s, v i j| + |∑ i ∈ sᶜ, v i j| := abs_sub _ _
      _ ≤ (∑ i ∈ s, |v i j|) + (∑ i ∈ sᶜ, |v i j|) :=
        add_le_add (Finset.abs_sum_le_sum_abs _ _) (Finset.abs_sum_le_sum_abs _ _)
      _ = ∑ i, |v i j| := Finset.sum_add_sum_compl s _
      _ ≤ ∑ _i : ι, (N : ℤ) := Finset.sum_le_sum (fun i _ => hv i j)
      _ = _ := by simp
  rw [← Int.natCast_natAbs] at h
  exact_mod_cast h

/-- Every binary discrepancy instance has an attaining optimal partition,
whose value lies within the finite interval used by the paper. -/
theorem exists_minimum_discrepancy {d : ℕ} (v : ι → IntVec d)
    (N : ℕ) (hv : ∀ i j, |v i j| ≤ (N : ℤ)) :
    ∃ s : Finset ι, partitionDiscrepancy v s ≤ Fintype.card ι * N ∧
      ∀ t : Finset ι, partitionDiscrepancy v s ≤ partitionDiscrepancy v t := by
  classical
  obtain ⟨s, hs, hmin⟩ := (Finset.univ : Finset (Finset ι)).exists_min_image
    (partitionDiscrepancy v) (by simp)
  exact ⟨s, partitionDiscrepancy_le v s N hv, fun t => hmin t (by simp)⟩

/-- The maximum-coordinate discrepancy and the inequalities on the binary
indicator vector define exactly the same threshold decision problem. -/
theorem partitionDiscrepancy_le_iff {d : ℕ} (v : ι → IntVec d)
    (s : Finset ι) (k : ℕ) :
    partitionDiscrepancy v s ≤ k ↔
      DiscrepancyThreshold v (fun i => if i ∈ s then 1 else 0) (k : ℤ) := by
  rw [partitionDiscrepancy, Finset.sup_le_iff, DiscrepancyThreshold]
  simp only [Finset.mem_univ, true_implies]
  apply forall_congr'
  intro j
  rw [weightedSum_indicator]
  have hid := congrFun (partition_difference v s) j
  simp only [Pi.sub_apply, Pi.add_apply, two_nsmul, Finset.sum_apply] at hid
  simp only [Finset.sum_apply]
  rw [two_mul, ← hid, ← Int.natCast_natAbs]
  exact_mod_cast (Iff.rfl :
    ((∑ i ∈ s, v i j) - (∑ i ∈ sᶜ, v i j)).natAbs ≤ k ↔
    ((∑ i ∈ s, v i j) - (∑ i ∈ sᶜ, v i j)).natAbs ≤ k)

/-- Optimal binary discrepancy has an actual binary witness and is the
transition point for all nonnegative discrepancy thresholds. -/
theorem exists_binary_discrepancy_transition {d : ℕ} (v : ι → IntVec d)
    (N : ℕ) (hv : ∀ i j, |v i j| ≤ (N : ℤ)) :
    ∃ k : ℕ, k ≤ Fintype.card ι * N ∧
      (∃ x : ι → ℤ, (∀ i, 0 ≤ x i ∧ x i ≤ 1) ∧ DiscrepancyThreshold v x (k : ℤ)) ∧
      ∀ h : ℕ,
        (∃ x : ι → ℤ, (∀ i, 0 ≤ x i ∧ x i ≤ 1) ∧ DiscrepancyThreshold v x (h : ℤ)) ↔
        k ≤ h := by
  obtain ⟨s, hsbound, hsmin⟩ := exists_minimum_discrepancy v N hv
  have hbinary : ∀ i, (0 : ℤ) ≤ (if i ∈ s then 1 else 0) ∧
      (if i ∈ s then 1 else 0) ≤ (1 : ℤ) := by
    intro i
    split_ifs <;> norm_num
  refine ⟨partitionDiscrepancy v s, hsbound,
    ⟨fun i => if i ∈ s then 1 else 0, hbinary,
      (partitionDiscrepancy_le_iff v s _).mp le_rfl⟩, fun h => ?_⟩
  constructor
  · rintro ⟨x, hx, hdisc⟩
    obtain ⟨t, ht⟩ := (binary_counts_iff_indicator x).mp hx
    have heq : x = fun i => if i ∈ t then 1 else 0 := funext ht
    rw [heq] at hdisc
    exact (hsmin t).trans ((partitionDiscrepancy_le_iff v t h).mpr hdisc)
  · intro hh
    exact ⟨fun i => if i ∈ s then 1 else 0, hbinary,
      (partitionDiscrepancy_le_iff v s h).mp hh⟩

/-- Maximization has the dual threshold transition and an attaining feasible
vector, obtained from the finite feasible box. -/
theorem exists_max_objective_transition (v : ι → G) (l u c : ι → ℤ) (t : G)
    (hfeas : BoundedIP v l u t) :
    ∃ xmax : ι → ℤ, (∀ i, l i ≤ xmax i ∧ xmax i ≤ u i) ∧
      weightedSum v xmax = t ∧
      ∀ k : ℤ,
        (∃ x : ι → ℤ, (∀ i, l i ≤ x i ∧ x i ≤ u i) ∧
          weightedSum v x = t ∧ k ≤ weightedSum c x) ↔ k ≤ weightedSum c xmax := by
  obtain ⟨_, ⟨xmax, hx, hxt, hmax⟩⟩ := boundedIP_exists_objective_extrema v l u c t hfeas
  refine ⟨xmax, hx, hxt, fun k => ?_⟩
  constructor
  · rintro ⟨x, hbox, heq, hcx⟩
    exact hcx.trans (hmax x hbox heq)
  · intro hk
    exact ⟨xmax, hx, hxt, hk⟩

end
end Optss
