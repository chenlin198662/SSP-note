import Optss.ListCyclicConvolutionWork
import Optss.StoredBluesteinDenominator
import Optss.DyadicBluestein

/-! Both Bluestein chirp signs are computed from one actual Boolean square
per input position. A stored Boolean counter advances along the input list. -/
namespace Optss

def bitChirpPair (ms : List Bool) (p : ℕ) (counter : List Bool) : BitFourierInteger × BitFourierInteger :=
  let sq := bitListMultiplication counter counter
  (bitNegativeCharacter sq ms p,bitModularDyadicCharacter sq ms p)

def bitChirpPairWork (ms : List Bool) (p : ℕ) (counter : List Bool) : ℕ :=
  let sq := bitListMultiplication counter counter
  bitListMultiplicationGates counter counter+bitListMultiplicationVisits counter counter+
    bitNegativeCharacterWork sq ms p+bitModularDyadicCharacterWork sq ms p+2

theorem bitChirpPair_value {N : ℕ} [NeZero N] (ms : List Bool) (p : ℕ) (counter : List Bool)
    (hM : binaryDigitsValue ms=N) :
    ((bitChirpPair ms p counter).1.value,(bitChirpPair ms p counter).2.value)=
      (dyadicCharacterInteger (-((binaryDigitsValue counter)^2 : ZMod N)) p,
        dyadicCharacterInteger ((binaryDigitsValue counter)^2 : ZMod N) p) := by
  simp only [bitChirpPair,bitNegativeCharacter_value _ _ hM,bitModularDyadicCharacter_value _ _ hM,
    bitListMultiplication_correct,Nat.cast_mul,pow_two]

theorem bitChirpPair_canonical (ms : List Bool) (p : ℕ) (counter : List Bool) :
    (bitChirpPair ms p counter).1.Canonical ∧ (bitChirpPair ms p counter).2.Canonical :=
  ⟨bitNegativeCharacter_canonical _ _ _,bitDyadicCharacter_canonical _ _ _⟩

theorem bitChirpPairWork_bound {N : ℕ} [NeZero N] (ms : List Bool) (p : ℕ) (counter : List Bool)
    (hM : binaryDigitsValue ms=N) (L : ℕ) (hm : ms.length≤L) (hc : counter.length≤L) :
    bitChirpPairWork ms p counter≤768*(L+1)^2+
      2*(4194304*(N.size+p+72)^2*(characterWorkBits N (p+2)+1)^3) := by
  have hsq := bitListMultiplication_length_le counter counter
  have hsq' : (bitListMultiplication counter counter).length≤2*L := by omega
  have hn := bitNegativeCharacterWork_bound (bitListMultiplication counter counter) ms hM p
  have hp := bitModularDyadicCharacterWork_bound (bitListMultiplication counter counter) ms hM p
  have hn' : bitNegativeCharacterWork (bitListMultiplication counter counter) ms p≤64*(3*L+2)^2+
      4194304*(N.size+p+72)^2*(characterWorkBits N (p+2)+1)^3 := hn.trans
    (Nat.add_le_add_right (Nat.mul_le_mul_left 64 (Nat.pow_le_pow_left (by omega :
      (bitListMultiplication counter counter).length+ms.length+2≤3*L+2) 2)) _)
  have hmprod := Nat.mul_le_mul (Nat.add_le_add_right hsq' 1) (Nat.add_le_add_right hm 1)
  have hs := bitListMultiplication_total_le counter counter
  have hsqmul := Nat.mul_le_mul hc (by omega : counter.length+counter.length+3≤2*L+3)
  unfold bitChirpPairWork
  dsimp only
  nlinarith only [hn',hp,hmprod,hm,hs,hsqmul]

def bitChirpPairs (ms : List Bool) (p : ℕ) : List Bool → List Bool → List (BitFourierInteger × BitFourierInteger)
  | [],_ => []
  | _::fuel,counter => bitChirpPair ms p counter::bitChirpPairs ms p fuel (bitListAdd counter [true])

def bitChirpPairsWork (ms : List Bool) (p : ℕ) : List Bool → List Bool → ℕ
  | [],_ => 1
  | _::fuel,counter => bitChirpPairWork ms p counter+bitListSignedAddCost false false counter [true]+
      bitChirpPairsWork ms p fuel (bitListAdd counter [true])+2

theorem bitChirpPairs_length (ms fuel counter : List Bool) (p : ℕ) :
    (bitChirpPairs ms p fuel counter).length=fuel.length := by
  induction fuel generalizing counter with
  | nil => rfl
  | cons b fuel ih => simp only [bitChirpPairs,List.length_cons,ih]

theorem bitChirpPairs_get {N : ℕ} [NeZero N] (ms fuel counter : List Bool) (p : ℕ)
    (hM : binaryDigitsValue ms=N) (i : ℕ) (hi : i<fuel.length) :
    let q := (bitChirpPairs ms p fuel counter)[i]'(by rw [bitChirpPairs_length]; exact hi)
    (q.1.value,q.2.value)=
      (dyadicCharacterInteger (-((binaryDigitsValue counter+i)^2 : ZMod N)) p,
        dyadicCharacterInteger ((binaryDigitsValue counter+i)^2 : ZMod N) p) := by
  induction fuel generalizing counter i with
  | nil => simp only [List.length_nil] at hi; omega
  | cons b fuel ih =>
    cases i with
    | zero => simpa only [bitChirpPairs,List.getElem_cons_zero,Nat.cast_zero,add_zero] using bitChirpPair_value ms p counter hM
    | succ i =>
      have h := ih (bitListAdd counter [true]) i (by simpa only [List.length_cons,Nat.succ_lt_succ_iff] using hi)
      simpa only [bitChirpPairs,List.getElem_cons_succ,bitListAdd_correct,binaryDigitsValue,Bool.toNat_true,
        mul_zero,zero_add,Nat.add_assoc,Nat.add_comm,Nat.cast_add,Nat.cast_one,
        add_assoc,add_comm,add_left_comm] using h

theorem bitChirpPairsWork_bound {N : ℕ} [NeZero N] (ms fuel counter : List Bool) (p L : ℕ)
    (hM : binaryDigitsValue ms=N) (hm : ms.length≤L) (hL : 1≤L) (hc : BitListCanonical counter)
    (hbound : (binaryDigitsValue counter+fuel.length).size≤L) :
    bitChirpPairsWork ms p fuel counter≤1+fuel.length*(832*(L+1)^2+
      2*(4194304*(N.size+p+72)^2*(characterWorkBits N (p+2)+1)^3)) := by
  induction fuel generalizing counter with
  | nil => simp [bitChirpPairsWork]
  | cons b fuel ih =>
    have hcounter : counter.length≤L := by
      rw [hc.length]
      exact (Nat.size_le_size (Nat.le_add_right _ _)).trans hbound
    have hnext : (binaryDigitsValue (bitListAdd counter [true])+fuel.length).size≤L := by
      simpa only [bitListAdd_correct,binaryDigitsValue,Bool.toNat_true,mul_zero,zero_add,
        List.length_cons,Nat.add_assoc,Nat.add_comm] using hbound
    have hi := ih (bitListAdd counter [true]) (bitListTrim_canonical _) hnext
    have hpair := bitChirpPairWork_bound ms p counter hM L hm hcounter
    have hadd := bitListSignedAddCost_bound false false counter [true] L hcounter (by simpa using hL)
    rw [bitChirpPairsWork,List.length_cons]
    nlinarith only [hi,hpair,hadd]


def listLengthDigits : List Bool → List Bool
  | [] => []
  | _::xs => bitListAdd (listLengthDigits xs) [true]

def listLengthDigitsWork : List Bool → ℕ
  | [] => 1
  | _::xs => listLengthDigitsWork xs+bitListSignedAddCost false false (listLengthDigits xs) [true]+2

theorem listLengthDigits_value (xs : List Bool) : binaryDigitsValue (listLengthDigits xs)=xs.length := by
  induction xs with
  | nil => rfl
  | cons x xs ih => simp only [listLengthDigits,bitListAdd_correct,ih,binaryDigitsValue,Bool.toNat_true,mul_zero,zero_add,List.length_cons]

theorem listLengthDigits_canonical (xs : List Bool) : BitListCanonical (listLengthDigits xs) := by
  cases xs with
  | nil => simp [listLengthDigits,BitListCanonical,binaryDigitsValue]
  | cons x xs => exact bitListTrim_canonical _

theorem listLengthDigits_length (xs : List Bool) : (listLengthDigits xs).length=xs.length.size := by
  rw [(listLengthDigits_canonical xs).length,listLengthDigits_value]

theorem listLengthDigitsWork_bound (xs : List Bool) (L : ℕ) (hL : 1≤L) (hx : xs.length.size≤L) :
    listLengthDigitsWork xs≤1+xs.length*32*(L+1) := by
  induction xs with
  | nil => simp [listLengthDigitsWork]
  | cons x xs ih =>
    have hs : xs.length.size≤L := (Nat.size_le_size (Nat.le_succ _)).trans hx
    have hi := ih hs
    have hl : (listLengthDigits xs).length≤L := by rw [listLengthDigits_length]; exact hs
    have ha := bitListSignedAddCost_bound false false (listLengthDigits xs) [true] L hl (by simpa using hL)
    rw [listLengthDigitsWork,List.length_cons]
    nlinarith only [hi,ha]

def listBluesteinChirps (input : List Bool) (p : ℕ) : List (BitFourierInteger × BitFourierInteger) :=
  let ms := false::listLengthDigits input
  bitChirpPairs ms p input []

def listBluesteinChirpsWork (input : List Bool) (p : ℕ) : ℕ :=
  let ms := false::listLengthDigits input
  listLengthDigitsWork input+bitChirpPairsWork ms p input []+3

theorem listBluesteinChirpsWork_bound (input : List Bool) (p : ℕ) (hinput : input≠[]) :
    listBluesteinChirpsWork input p≤5+input.length*(864*(input.length.size+2)^2+
      2*(4194304*((2*input.length).size+p+72)^2*(characterWorkBits (2*input.length) (p+2)+1)^3)) := by
  have hN : 0 < input.length := List.length_pos_iff.mpr hinput
  haveI : NeZero (2*input.length) := ⟨by omega⟩
  have hM : binaryDigitsValue (false::listLengthDigits input)=2*input.length := by
    simp only [binaryDigitsValue,Bool.toNat_false,listLengthDigits_value,add_zero]
  have hs : (false::listLengthDigits input).length ≤ input.length.size+1 := by
    rw [List.length_cons,listLengthDigits_length]
  have h := bitChirpPairsWork_bound (false::listLengthDigits input) input [] p (input.length.size+1)
    hM hs (by omega) (by simp [BitListCanonical,binaryDigitsValue])
    (by simp only [binaryDigitsValue,zero_add]; omega)
  have hlen := listLengthDigitsWork_bound input (input.length.size+1) (by omega) (by omega)
  unfold listBluesteinChirpsWork
  dsimp only
  have hsquare : input.length.size+2 ≤ (input.length.size+2)^2 := by nlinarith
  have hmul := Nat.mul_le_mul_left (input.length*32) hsquare
  nlinarith only [h,hlen,hmul]

theorem bitChirpPairs_negative_values {N : ℕ} [NeZero N] (ms fuel : List Bool) (p : ℕ)
    (hM : binaryDigitsValue ms=N) :
    (bitChirpPairs ms p fuel []).map (fun q => q.1.value)=List.ofFn
      (fun k : Fin fuel.length => dyadicCharacterInteger (-(k.val : ZMod N)^2) p) := by
  apply List.ext_getElem
  · simp only [List.length_map,bitChirpPairs_length,List.length_ofFn]
  · intro i hi hi'
    have hil : i<fuel.length := by simpa only [List.length_ofFn] using hi'
    have h := congrArg Prod.fst (bitChirpPairs_get ms fuel [] p hM i hil)
    simpa only [List.getElem_map,List.getElem_ofFn,binaryDigitsValue,Nat.cast_zero,zero_add] using h

theorem bitChirpPairs_positive_values {N : ℕ} [NeZero N] (ms fuel : List Bool) (p : ℕ)
    (hM : binaryDigitsValue ms=N) :
    (bitChirpPairs ms p fuel []).map (fun q => q.2.value)=List.ofFn
      (fun k : Fin fuel.length => dyadicCharacterInteger ((k.val : ZMod N)^2) p) := by
  apply List.ext_getElem
  · simp only [List.length_map,bitChirpPairs_length,List.length_ofFn]
  · intro i hi hi'
    have hil : i<fuel.length := by simpa only [List.length_ofFn] using hi'
    have h := congrArg Prod.snd (bitChirpPairs_get ms fuel [] p hM i hil)
    simpa only [List.getElem_map,List.getElem_ofFn,binaryDigitsValue,Nat.cast_zero,zero_add] using h

end Optss
