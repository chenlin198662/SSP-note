import Mathlib.Algebra.MvPolynomial.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Tactic

/-!
# Exact generating-function support

This formalizes the support semantics underlying §10.1. Natural coefficients
count subsets of distinct copy labels, so a positive coefficient is exactly a
subset witness. Repeated exponent vectors do not identify different copies.
The multiplicity form is equal to the product indexed by the available labels.

Exponents are nonnegative finitely supported vectors. One exponent coordinate
may encode cardinality; the others may encode the absolute coordinates within
an orthant. This file does not claim a fast convolution algorithm or a cost bound.
-/

namespace Optss

open scoped BigOperators

noncomputable section

variable {ι σ : Type*} [Fintype ι]

/-- Generating polynomial with one binary choice for each labelled input copy. -/
def subsetGenerating (u : ι → σ →₀ ℕ) : MvPolynomial σ ℕ :=
  ∏ i, (1 + MvPolynomial.monomial (u i) 1)

/-- Expanding the product gives one monomial for each actual subset of labels. -/
theorem subsetGenerating_expand (u : ι → σ →₀ ℕ) :
    subsetGenerating u =
      ∑ s ∈ (Finset.univ : Finset ι).powerset,
        MvPolynomial.monomial (∑ i ∈ s, u i) 1 := by
  classical
  rw [subsetGenerating, Finset.prod_one_add]
  apply Finset.sum_congr rfl
  intro s _
  exact (MvPolynomial.monomial_sum_one s u).symm

/-- Each coefficient counts the subsets producing that exponent vector. -/
theorem subsetGenerating_coeff [DecidableEq σ] (u : ι → σ →₀ ℕ) (e : σ →₀ ℕ) :
    MvPolynomial.coeff e (subsetGenerating u) =
      (((Finset.univ : Finset ι).powerset).filter
        (fun s => (∑ i ∈ s, u i) = e)).card := by
  classical
  rw [subsetGenerating_expand, MvPolynomial.coeff_sum]
  simp

/-- Coefficient positivity is equivalent to existence of a subset witness. -/
theorem subsetGenerating_coeff_pos_iff (u : ι → σ →₀ ℕ) (e : σ →₀ ℕ) :
    0 < MvPolynomial.coeff e (subsetGenerating u) ↔
      ∃ s : Finset ι, (∑ i ∈ s, u i) = e := by
  classical
  rw [subsetGenerating_coeff, Finset.card_pos]
  simp [Finset.Nonempty]

/-- In particular, zero coefficients are exactly the exponents with no witness. -/
theorem subsetGenerating_coeff_eq_zero_iff (u : ι → σ →₀ ℕ) (e : σ →₀ ℕ) :
    MvPolynomial.coeff e (subsetGenerating u) = 0 ↔
      ¬∃ s : Finset ι, (∑ i ∈ s, u i) = e := by
  rw [← subsetGenerating_coeff_pos_iff]
  omega

/-- A coordinate equal to one for every input records the exact number of
selected copies. This is the cardinality variable `Y` used in §10.1. -/
theorem subsetGenerating_coeff_pos_iff_with_cardinality
    (u : ι → σ →₀ ℕ) (j : σ) (hj : ∀ i, u i j = 1) (e : σ →₀ ℕ) :
    0 < MvPolynomial.coeff e (subsetGenerating u) ↔
      ∃ s : Finset ι, (∑ i ∈ s, u i) = e ∧ s.card = e j := by
  rw [subsetGenerating_coeff_pos_iff]
  constructor
  · rintro ⟨s, hs⟩
    refine ⟨s, hs, ?_⟩
    have h := congrArg (fun f : σ →₀ ℕ => f j) hs
    simpa [hj] using h
  · rintro ⟨s, hs, _⟩
    exact ⟨s, hs⟩

/-- The polynomial can be represented directly by integer multiplicities. -/
def multiplicityGenerating (c : ι → ℕ) (u : ι → σ →₀ ℕ) : MvPolynomial σ ℕ :=
  ∏ i, (1 + MvPolynomial.monomial (u i) 1) ^ c i

/-- Taking a power for a type is exactly the product over that type's copies. -/
theorem multiplicityGenerating_eq_copies (c : ι → ℕ) (u : ι → σ →₀ ℕ) :
    multiplicityGenerating c u =
      subsetGenerating (fun p : Σ i, Fin (c i) => u p.1) := by
  classical
  simp [multiplicityGenerating, subsetGenerating, Fintype.prod_sigma]

/-- Positivity in the multiplicity representation has a genuine available-copy
witness: a type has precisely `c i` separate labels, each used at most once. -/
theorem multiplicityGenerating_coeff_pos_iff (c : ι → ℕ)
    (u : ι → σ →₀ ℕ) (e : σ →₀ ℕ) :
    0 < MvPolynomial.coeff e (multiplicityGenerating c u) ↔
      ∃ s : Finset (Σ i, Fin (c i)), (∑ p ∈ s, u p.1) = e := by
  rw [multiplicityGenerating_eq_copies, subsetGenerating_coeff_pos_iff]

end

end Optss
