import Optss.RankDimension
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics

/-!
# Actual floor-power scales for scalar rank bounds

The scale is exactly `floor (N^(δ/3))`. Real-power divergence proves all
"sufficiently large" assertions below, including the effect of rounding.
No growth comparison for generalized arithmetic progressions is assumed here.
-/

namespace Optss
open Filter
open scoped Topology BigOperators
noncomputable section

/-- The integral scale used in the scalar rank analysis. -/
def rankScale (δ : ℝ) (N : ℕ) : ℕ := ⌊(N : ℝ) ^ (δ / 3)⌋₊

/-- Every positive real power eventually dominates a constant multiple of a
strictly smaller real power, also along natural arguments. -/
theorem eventually_nat_rpow_dominates (a b C : ℝ) (hab : b < a) :
    ∀ᶠ N : ℕ in atTop, C * (N : ℝ)^b < (N : ℝ)^a := by
  have hlim : Tendsto (fun N : ℕ => (N : ℝ)^(a-b)) atTop atTop :=
    (tendsto_rpow_atTop (sub_pos.mpr hab)).comp tendsto_natCast_atTop_atTop
  filter_upwards [hlim.eventually (eventually_gt_atTop C), eventually_ge_atTop 1] with N hC hN
  have hNpos : (0 : ℝ) < N := by exact_mod_cast (show 0 < N by omega)
  have hp : 0 < (N : ℝ)^b := Real.rpow_pos_of_pos hNpos _
  have hm := mul_lt_mul_of_pos_right hC hp
  calc
    _ < (N : ℝ)^(a-b) * (N : ℝ)^b := hm
    _ = (N : ℝ)^a := by rw [← Real.rpow_add hNpos, sub_add_cancel]

/-- A constant-factor lower estimate for the actual natural floor. -/
theorem eventually_rpow_le_twice_floor (a : ℝ) (ha : 0 < a) :
    ∀ᶠ N : ℕ in atTop, (N : ℝ)^a ≤ 2 * (⌊(N : ℝ)^a⌋₊ : ℝ) := by
  have hlim : Tendsto (fun N : ℕ => (N : ℝ)^a) atTop atTop :=
    (tendsto_rpow_atTop ha).comp tendsto_natCast_atTop_atTop
  filter_upwards [hlim.eventually (eventually_ge_atTop 2)] with N hN
  have hf := Nat.lt_floor_add_one ((N : ℝ)^a)
  linarith

/-- The floor does not change the exponent in a strict power-dominance bound. -/
theorem eventually_floor_rpow_pow_dominates (a b C : ℝ) (q : ℕ)
    (ha : 0 < a) (hab : b < a * q) :
    ∀ᶠ N : ℕ in atTop, C * (N : ℝ)^b < (⌊(N : ℝ)^a⌋₊ : ℝ)^q := by
  filter_upwards [eventually_nat_rpow_dominates (a*q) b ((2:ℝ)^q*C) hab,
    eventually_rpow_le_twice_floor a ha] with N hbig hfloor
  have hp := pow_le_pow_left₀ (Real.rpow_nonneg (Nat.cast_nonneg _) _) hfloor q
  have hpow : (N : ℝ)^(a*(q:ℝ)) = ((N : ℝ)^a)^q := by
    rw [Real.rpow_mul (Nat.cast_nonneg _), Real.rpow_natCast]
  rw [hpow] at hbig
  have hmul : (2:ℝ)^q * (C * (N : ℝ)^b) <
      (2:ℝ)^q * (⌊(N : ℝ)^a⌋₊ : ℝ)^q := by
    calc
      _ = ((2:ℝ)^q*C) * (N : ℝ)^b := by ring
      _ < ((N : ℝ)^a)^q := hbig
      _ ≤ (2 * (⌊(N : ℝ)^a⌋₊ : ℝ))^q := hp
      _ = _ := mul_pow _ _ _
  exact (mul_lt_mul_left (pow_pos (by norm_num : (0:ℝ)<2) _)).mp hmul

/-- The original scalar potential has degree `1 + a` in the real scale. -/
theorem floor_scalar_potential_le_rpow (a : ℝ) (ha : 0 ≤ a) (N : ℕ) (hN : 1 ≤ N) :
    (2 * (⌊(N : ℝ)^a⌋₊ : ℝ) * N + 1) ≤ 3 * (N : ℝ)^(a+1) := by
  have hN1 : (1:ℝ) ≤ N := by exact_mod_cast hN
  have hNpos : (0:ℝ) < N := by linarith
  have hf := Nat.floor_le (Real.rpow_nonneg (Nat.cast_nonneg N) a)
  have hpow1 : 1 ≤ (N : ℝ)^a := Real.one_le_rpow hN1 ha
  rw [Real.rpow_add hNpos, Real.rpow_one]
  nlinarith

/-- A uniform integer form of power dominance for the exact scalar potential.
It simultaneously supplies the factorial rank threshold and squared-loss threshold. -/
theorem eventually_floor_scalar_potential_pow_lt (a : ℝ) (ha : 0 < a)
    (C p q : ℕ) (hexp : (a+1)*p < a*q) :
    ∀ᶠ N : ℕ in atTop,
      C * (2 * ⌊(N : ℝ)^a⌋₊ * N + 1)^p < ⌊(N : ℝ)^a⌋₊^q := by
  filter_upwards [eventually_floor_rpow_pow_dominates a ((a+1)*p)
    ((C:ℝ)*3^p) q ha hexp, eventually_ge_atTop 1] with N hbig hN
  have hpot := floor_scalar_potential_le_rpow a ha.le N hN
  have hp := pow_le_pow_left₀ (by positivity :
    (0:ℝ) ≤ 2 * (⌊(N : ℝ)^a⌋₊ : ℝ) * N + 1) hpot p
  have hpow : ((N : ℝ)^(a+1))^p = (N : ℝ)^((a+1)*(p:ℝ)) := by
    rw [Real.rpow_mul (Nat.cast_nonneg _), Real.rpow_natCast]
  have hreal : (C:ℝ) * (2 * (⌊(N : ℝ)^a⌋₊ : ℝ) * N + 1)^p <
      (⌊(N : ℝ)^a⌋₊ : ℝ)^q := by
    calc
      _ ≤ (C:ℝ) * (3 * (N : ℝ)^(a+1))^p :=
        mul_le_mul_of_nonneg_left hp (Nat.cast_nonneg _)
      _ = ((C:ℝ)*3^p) * (N : ℝ)^((a+1)*(p:ℝ)) := by rw [mul_pow, hpow]; ring
      _ < _ := hbig
  exact_mod_cast hreal

/-- The manuscript's rank threshold with the exact floor scale. -/
theorem eventually_rankScale_factorial_threshold (δ : ℝ) (hδ : 0 < δ) (D : ℕ)
    (hD : 1 + 3/δ < (D:ℝ)) :
    ∀ᶠ N : ℕ in atTop,
      D.factorial * (2 * rankScale δ N * N + 1) < (rankScale δ N + 1)^D := by
  have ha : 0 < δ/3 := by positivity
  have hmul : (δ/3+1)*(1:ℝ) < (δ/3)*D := by
    have h := (div_lt_iff₀ hδ).mp (show 3/δ < (D:ℝ)-1 by linarith)
    nlinarith
  filter_upwards [eventually_floor_scalar_potential_pow_lt (δ/3) ha D.factorial 1 D (by simpa using hmul)]
    with N hN
  have hbase : D.factorial * (2 * rankScale δ N * N + 1) < (rankScale δ N)^D := by
    simpa only [pow_one, rankScale] using hN
  exact hbase.trans_le (Nat.pow_le_pow_left (Nat.le_succ _) D)

/-- The manuscript's total-rank-loss threshold with the exact floor scale. -/
theorem eventually_rankScale_loss_threshold (δ : ℝ) (hδ : 0 < δ) (Q : ℕ)
    (hQ : 2 * (1 + δ/3) < (δ/3)*Q) :
    ∀ᶠ N : ℕ in atTop, (2 * rankScale δ N * N + 1)^2 < (rankScale δ N)^Q := by
  have ha : 0 < δ/3 := by positivity
  have hexp : (δ/3+1)*(2:ℝ) < (δ/3)*Q := by nlinarith
  simpa only [one_mul, rankScale] using
    eventually_floor_scalar_potential_pow_lt (δ/3) ha 1 2 Q hexp

/-- Fixed constants needed by the per-deletion binomial estimate are eventually
below the same actual scale. -/
theorem rankScale_tendsto_atTop (δ : ℝ) (hδ : 0 < δ) :
    Tendsto (rankScale δ) atTop atTop := by
  exact tendsto_nat_floor_atTop.comp
    ((tendsto_rpow_atTop (by positivity : 0 < δ/3)).comp tendsto_natCast_atTop_atTop)

/-- The uniform finite rank-loss counting threshold is now proved eventually. -/
theorem eventually_rankScale_counting_threshold (δ : ℝ) (hδ : 0 < δ) (D γ : ℕ) :
    ∀ᶠ N : ℕ in atTop, (2^D * D.factorial * γ)^2 ≤ rankScale δ N :=
  (rankScale_tendsto_atTop δ hδ).eventually (eventually_ge_atTop _)

/-- All sufficiently large inputs have actual current rank less than `D`,
uniformly over finite input families with the signed-sum invariant. -/
theorem eventually_inputSpanRank_scalar_lt
    {ι K E : Type*} [Fintype ι] [DivisionRing K] [CharZero K]
    [AddCommGroup E] [Module K E]
    (δ : ℝ) (hδ : 0 < δ) (D : ℕ) (hD : 1 + 3/δ < (D:ℝ)) :
    ∀ᶠ N : ℕ in atTop, ∀ (original : ι → ℤ) (current : ι → E),
      PreservesSignedSums (rankScale δ N) original current →
      (∀ i, |original i| ≤ (N:ℤ)) → inputSpanRank K current < D := by
  filter_upwards [eventually_rankScale_factorial_threshold δ hδ D hD] with N hN
  intro original current hpres hbox
  exact inputSpanRank_scalar_lt_of_power original current hpres N hbox D hN

/-- An upper bound on the exponential of total rank loss gives a fixed bound on
that loss at every sufficiently large natural input size. -/
theorem eventually_rankScale_loss_lt (δ : ℝ) (hδ : 0 < δ) (Q : ℕ)
    (hQ : 2 * (1 + δ/3) < (δ/3)*Q) :
    ∀ᶠ N : ℕ in atTop, ∀ L : ℕ,
      (rankScale δ N)^L ≤ (2 * rankScale δ N * N + 1)^2 → L < Q := by
  filter_upwards [eventually_rankScale_loss_threshold δ hδ Q hQ,
    (rankScale_tendsto_atTop δ hδ).eventually (eventually_ge_atTop 1)] with N hN hk
  intro L hL
  by_contra hnot
  have hQL : Q ≤ L := by omega
  have hpow := Nat.pow_le_pow_right hk hQL
  exact (not_lt_of_ge (hpow.trans hL)) hN

/-- Apply the eventual bound directly to a path with verified potential drops. -/
theorem eventually_rank_path_loss_lt (δ : ℝ) (hδ : 0 < δ) (Q : ℕ)
    (hQ : 2 * (1 + δ/3) < (δ/3)*Q) :
    ∀ᶠ N : ℕ in atTop, ∀ (μ loss : ℕ → ℕ) (n : ℕ),
      (∀ i < n, (rankScale δ N)^loss i * μ (i+1)^2 ≤ μ i^2) →
      1 ≤ μ n → μ 0 ≤ 2 * rankScale δ N * N + 1 →
      (∑ i ∈ Finset.range n, loss i) < Q := by
  filter_upwards [eventually_rankScale_loss_lt δ hδ Q hQ] with N hN
  intro μ loss n hdrop hfinal hroot
  exact hN _ (rank_loss_pow_le _ _ μ loss n hdrop hfinal hroot)

/-- The asymptotic path estimate follows from disjoint-translate counting and an
explicit survivor-growth comparison. The growth comparison itself is not asserted. -/
theorem eventually_rank_path_loss_lt_from_counting
    (δ : ℝ) (hδ : 0 < δ) (D γ Q : ℕ)
    (hQ : 2 * (1 + δ/3) < (δ/3)*Q) :
    ∀ᶠ N : ℕ in atTop, ∀ (μ half loss : ℕ → ℕ) (n : ℕ),
      (∀ i < n, loss i ≤ D) →
      (∀ i < n, 0 < loss i →
        (rankScale δ N / 2 + loss i).choose (loss i) * half i ≤ μ i) →
      (∀ i < n, 0 < loss i → μ (i+1) ≤ γ * half i) →
      (∀ i < n, loss i = 0 → μ (i+1) ≤ μ i) →
      1 ≤ μ n → μ 0 ≤ 2 * rankScale δ N * N + 1 →
      (∑ i ∈ Finset.range n, loss i) < Q := by
  filter_upwards [eventually_rankScale_loss_lt δ hδ Q hQ,
    eventually_rankScale_counting_threshold δ hδ D γ] with N hN hthreshold
  intro μ half loss n hD hcount hgrowth hnormal hfinal hroot
  exact hN _ (rank_path_bound_from_counting _ γ D _ μ half loss n
    hthreshold hD hcount hgrowth hnormal hfinal hroot)

/-- Concrete dimension cutoff, with no unchosen "sufficiently large constant". -/
def rankDimensionCutoff (δ : ℝ) : ℕ := ⌊1 + 3/δ⌋₊ + 1

/-- Concrete total-loss cutoff. -/
def rankLossCutoff (δ : ℝ) : ℕ := ⌊2 + 6/δ⌋₊ + 1

theorem rankDimensionCutoff_exponent (δ : ℝ) :
    1 + 3/δ < (rankDimensionCutoff δ : ℝ) := by
  simpa only [rankDimensionCutoff, Nat.cast_add, Nat.cast_one] using
    Nat.lt_floor_add_one (1 + 3/δ)

theorem rankLossCutoff_exponent (δ : ℝ) (hδ : 0 < δ) :
    2 * (1 + δ/3) < (δ/3)*(rankLossCutoff δ : ℝ) := by
  have hf : 2 + 6/δ < (rankLossCutoff δ : ℝ) := by
    simpa only [rankLossCutoff, Nat.cast_add, Nat.cast_one] using
      Nat.lt_floor_add_one (2 + 6/δ)
  have h := (div_lt_iff₀ hδ).mp (show 6/δ < (rankLossCutoff δ : ℝ)-2 by linarith)
  nlinarith

/-- Both scalar thresholds hold for the explicitly chosen cutoffs. -/
theorem eventually_rankScale_cutoff_thresholds (δ : ℝ) (hδ : 0 < δ) :
    ∀ᶠ N : ℕ in atTop,
      (rankDimensionCutoff δ).factorial * (2 * rankScale δ N * N + 1) <
        (rankScale δ N + 1)^(rankDimensionCutoff δ) ∧
      (2 * rankScale δ N * N + 1)^2 < (rankScale δ N)^(rankLossCutoff δ) :=
  (eventually_rankScale_factorial_threshold δ hδ _ (rankDimensionCutoff_exponent δ)).and
    (eventually_rankScale_loss_threshold δ hδ _ (rankLossCutoff_exponent δ hδ))

/-- Rational exponents require no extra limit assumption or approximation. -/
theorem eventually_rankScale_rational_cutoff_thresholds (δ : ℚ) (hδ : 0 < δ) :
    ∀ᶠ N : ℕ in atTop,
      (rankDimensionCutoff (δ:ℝ)).factorial * (2 * rankScale (δ:ℝ) N * N + 1) <
        (rankScale (δ:ℝ) N + 1)^(rankDimensionCutoff (δ:ℝ)) ∧
      (2 * rankScale (δ:ℝ) N * N + 1)^2 <
        (rankScale (δ:ℝ) N)^(rankLossCutoff (δ:ℝ)) :=
  eventually_rankScale_cutoff_thresholds (δ:ℝ) (by exact_mod_cast hδ)

end
end Optss
