import Optss.CommonBoxDenseBlocks

/-!
# Proper scalar progressions filled by the common block family

The full-lattice coordinate box contains all surviving items. A fixed small
real dilation stays in the original proper phase box and is filled by the
actual sum of the dense blocks.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1200000
local instance commonProperFillingDecEqInt : DecidableEq ℤ := Classical.decEq _
local instance commonProperFillingDecEqIntVec {d : ℕ} : DecidableEq (IntVec d) :=
  @Fintype.decidablePiFintype (Fin d) (fun _ => ℤ) (fun _ => Int.instDecidableEq) (Fin.fintype d)
variable {d : ℕ}

/-- Geometric containment in the old box at every positive real dilation. -/
theorem common_basis_progression_bound (hd : 0 < d) (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (n w : Fin d → ℕ)
    (houter : basisCoefficientBox b n ⊆ denseLatticeBoxingConstant d • realCoefficientBox w)
    (s : ℝ) (hs : 0 < s) (x : IntVec d)
    (hx : x ∈ (subgroupBasisProgression Γ b hΛ n).values s) :
    ∀ j, |(x j : ℝ)| ≤ s*denseLatticeBoxingConstant d*w j := by
  have hx' := (subgroupBasisProgression_mem Γ b hΛ n s hs x).mp hx
  obtain ⟨y, hy, he⟩ := hx'.2
  have hb := mem_smul_realCoefficientBox_bound w _ (denseLatticeBoxingConstant_pos hd).le y (houter hy)
  intro j
  have hj := congrFun he j
  change s*y j = (x j : ℝ) at hj
  rw [← hj, abs_mul, abs_of_pos hs]
  exact (mul_le_mul_of_nonneg_left (hb j) hs.le).trans_eq (by ring)

/-- The original phase properness transfers to the entire new basis lattice
on every sufficiently small real dilation. -/
theorem common_basis_scalar_proper (hd : 0 < d) (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (n w : Fin d → ℕ) (ρ : IntVec d →+ ℤ) (H : ℕ)
    (hρ : Set.InjOn ρ (integerBudgetBox (fun j => H*w j)))
    (houter : basisCoefficientBox b n ⊆ denseLatticeBoxingConstant d • realCoefficientBox w)
    (s : ℝ) (hs : 0 < s) (hscale : s*denseLatticeBoxingConstant d ≤ H) :
    ((subgroupBasisProgression Γ b hΛ n).mapHom ρ).Proper s := by
  intro x hx y hy hxy
  apply subgroupBasisSynthesisHom_injective Γ b hΛ
  apply hρ
  · apply (mem_integerBudgetBox _ _).mpr
    intro j
    have hm : subgroupBasisSynthesisHom Γ b hΛ x ∈ (subgroupBasisProgression Γ b hΛ n).values s :=
      (CenteredProgression.mem_values _ _ _).mpr ⟨x, hx, rfl⟩
    have hb := common_basis_progression_bound hd Γ b hΛ n w houter s hs _ hm j
    have hb' := hb.trans (mul_le_mul_of_nonneg_right hscale (Nat.cast_nonneg (w j)))
    dsimp only
    exact_mod_cast hb'
  · apply (mem_integerBudgetBox _ _).mpr
    intro j
    have hm : subgroupBasisSynthesisHom Γ b hΛ y ∈ (subgroupBasisProgression Γ b hΛ n).values s :=
      (CenteredProgression.mem_values _ _ _).mpr ⟨y, hy, rfl⟩
    have hb := common_basis_progression_bound hd Γ b hΛ n w houter s hs _ hm j
    have hb' := hb.trans (mul_le_mul_of_nonneg_right hscale (Nat.cast_nonneg (w j)))
    dsimp only
    exact_mod_cast hb'
  · exact hxy

/-- Explicit small filling scale; only dimension, the phase-density constant,
the block-size constant, and the number of retained blocks occur. -/
def commonBoxFilledScale (d K : ℕ) (C : ℝ) (N : ℕ) : ℝ :=
  min (denseLatticeProperScale d) (denseBoxDilation d (commonBoxBlockDensity d K C)*N)

theorem commonBoxFilledScale_pos (hd : 0 < d) (K : ℕ) (hK : 1 ≤ K)
    (C : ℝ) (hC : 0 < C) (N : ℕ) (hN : 0 < N) : 0 < commonBoxFilledScale d K C N := by
  have hc := (commonBoxBlockDensity_bounds d K hK C hC).1
  have hγ := denseBoxDilation_pos d _ hd hc
  exact lt_min (denseLatticeProperScale_pos hd) (by positivity)

/-- The common dense block family yields a genuinely proper filled scalar
GAP containing every surviving original item. The reserve support on the right
is the actual Minkowski sum of these blocks. -/
theorem common_dense_blocks_proper_progression {ι : Type} (hd : 0 < d)
    (v : ι → IntVec d) (available : Finset ι)
    (hfull : labelSpan ℝ (fun i => realVector (v i)) available = ⊤)
    (w : Fin d → ℕ) (hbox : ∀ i ∈ available, InCenteredBox w (v i))
    (ρ : IntVec d →+ ℤ) (h B K M N : ℕ) (hh : 1 ≤ h) (hhB : h ≤ B)
    (hK : 1 ≤ K) (hBK : B ≤ K*h)
    (hρ : Set.InjOn ρ (integerBudgetBox (fun j => 20*h*w j)))
    (C : ℝ) (hC : 0 < C)
    (hvolume : ((integerBudgetBox (fun j => h*w j)).card : ℝ) ≤ C*M)
    (A : ℕ → Finset (IntVec d))
    (hAbox : ∀ i < N, ∀ x ∈ A i, InCenteredBox (fun j => B*w j) x)
    (hdense : ∀ i < N, (M : ℝ)/4 ≤ (A i).card)
    (hzero : ∀ i < N, 0 ∈ A i)
    (hgen : ∀ i < N, AddSubgroup.closure (A i : Set (IntVec d)) = generatedLattice v available)
    (hN0 : 0 < N) (hN : denseBoxSummandThreshold d (commonBoxBlockDensity d K C) ≤ N)
    (hwidth : denseBoxWidthThreshold (commonBoxBlockDensity d K C) ≤ 2*B+1) :
    ∃ P : CenteredProgression (Fin d) ℤ,
      (∀ j, P.lowerRadius j = P.upperRadius j ∧ 1 ≤ P.lowerRadius j) ∧
      (∀ i ∈ available, ρ (v i) ∈ P.values 1) ∧
      P.Proper (commonBoxFilledScale d K C N*h) ∧
      ∃ t : ℤ, (P.values (commonBoxFilledScale d K C N*h)).image (t+·) ⊆
        (∑ i ∈ Finset.range N, A i).image ρ := by
  obtain ⟨b, hΛ, n, hn, hinner, houter, _, t, ht, hfill⟩ :=
    common_box_dense_blocks_filling hd v available hfull w hbox h B K M N
      (hh.trans hhB) hK hBK C hC hvolume A hAbox hdense hzero hgen hN hwidth
  let Γ := generatedLattice v available
  let P₀ := subgroupBasisProgression Γ b hΛ n
  let P := P₀.mapHom ρ
  let c := commonBoxFilledScale d K C N
  have hc : 0 < c := commonBoxFilledScale_pos hd K hK C hC N hN0
  have hhr : (0 : ℝ) < h := by exact_mod_cast (show 0 < h by omega)
  have hscale : (c*h)*denseLatticeBoxingConstant d ≤ (20*h : ℕ) := by
    have hJ := denseLatticeBoxingConstant_pos hd
    have hcη : c ≤ denseLatticeProperScale d := min_le_left _ _
    have hmul := mul_le_mul_of_nonneg_right hcη (mul_nonneg hhr.le hJ.le)
    have he : denseLatticeProperScale d*((h : ℝ)*denseLatticeBoxingConstant d) = h/4 := by
      unfold denseLatticeProperScale
      field_simp
      ring
    rw [he] at hmul
    push_cast
    nlinarith
  refine ⟨P, fun j => ⟨rfl, by change (1 : ℝ) ≤ (n j : ℝ); exact_mod_cast hn j⟩, ?_,
    common_basis_scalar_proper hd Γ b hΛ n w ρ (20*h) hρ houter (c*h) (mul_pos hc hhr) hscale,
    ρ t, ?_⟩
  · intro i hi
    rw [CenteredProgression.mapHom_values]
    refine Finset.mem_image.mpr ⟨v i, ?_, rfl⟩
    apply (subgroupBasisProgression_mem Γ b hΛ n 1 zero_lt_one (v i)).mpr
    refine ⟨AddSubgroup.subset_closure ⟨i, hi, rfl⟩, ?_⟩
    rw [one_smul]
    apply hinner
    rw [mem_realCoefficientBox]
    intro j
    change |(v i j : ℝ)| ≤ (w j : ℝ)
    exact_mod_cast hbox i hi j
  · intro x hx
    obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
    rw [CenteredProgression.mapHom_values] at hy
    obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp hy
    obtain ⟨z, hz, rfl⟩ := (CenteredProgression.mem_values _ _ _).mp hu
    have hz' := (CenteredProgression.mem_coefficientBox P₀ (c*h) z).mp hz
    have hmem := hfill z (fun j => by
      have hbound : |(z j : ℝ)| ≤ (c*h)*n j := abs_le.mpr (hz' j)
      have hcγ : c ≤ denseBoxDilation d (commonBoxBlockDensity d K C)*N := min_le_right _ _
      have hγ := denseBoxDilation_pos d _ hd (commonBoxBlockDensity_bounds d K hK C hC).1
      have hhBR : (h : ℝ) ≤ B := by exact_mod_cast hhB
      have hstep := mul_le_mul hcγ hhBR (Nat.cast_nonneg h) (by positivity)
      have hstep' := mul_le_mul_of_nonneg_right hstep (Nat.cast_nonneg (n j))
      push_cast
      exact hbound.trans (by simpa only [mul_assoc] using hstep'))
    exact Finset.mem_image.mpr ⟨_, hmem, map_add ρ _ _⟩

end
end Optss
