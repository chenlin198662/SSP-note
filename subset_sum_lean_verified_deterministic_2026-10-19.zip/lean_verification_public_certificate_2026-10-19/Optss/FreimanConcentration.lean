import Optss.FreimanDimensionGrowth

/-!
# Freiman's two-to-the-dimension concentration theorem

This derives Bilu, Astérisque 258 (1999), Theorem 5.1 from the verified
cube lemma and a finite-depth sumset partition. The positive constant is
chosen using an actual geometrically decreasing residual fraction.
Primary source: https://www.numdam.org/item/AST_1999__258__77_0.pdf
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 1000000
local instance freimanConcentrationDecEqRealVec (n : ℕ) : DecidableEq (Fin n → ℝ) := Classical.decEq _

/-- If doubling is less than `2^n` by a fixed amount, a fixed positive
fraction of the input lies in an actual affine hyperplane. -/
theorem freiman_hyperplane_concentration (n : ℕ) (hn : 0 < n) (ε : ℝ) (hε : 0 < ε) :
    ∃ δ : ℝ, 0 < δ ∧ ∀ S : Finset (Fin n → ℝ), S.Nonempty →
      ((S+S).card:ℝ) < ((2:ℝ)^n-ε)*S.card →
      ∃ f : (Fin n → ℝ) →ₗ[ℝ] ℝ, f ≠ 0 ∧ ∃ t : ℝ,
        δ*S.card ≤ (S.filter (fun x => f x = t)).card := by
  let D : ℝ := 2^n
  let c := generalFreimanCubeFraction n D
  have hD : 0 < D := by dsimp [D]; positivity
  have hD1 : 1 ≤ D := one_le_pow₀ (by norm_num)
  have hc : 0 < c := generalFreimanCubeFraction_pos n D hD
  have hc1 : c ≤ 1 := generalFreimanCubeFraction_le_one n hn D hD1
  obtain ⟨L, hL⟩ := exists_pow_lt_of_lt_one (div_pos hε (by positivity : 0 < 2*D))
    (show 1-c < 1 by linarith)
  let e := freimanDepthError n L
  have he : 0 ≤ e := freimanDepthError_nonneg n L
  let δ := ε / (4*D*(e+1))
  have hδ : 0 < δ := div_pos hε (by positivity)
  refine ⟨δ, hδ, ?_⟩
  intro S hS hsmall
  by_contra hbad
  have hall : ∀ (f : (Fin n → ℝ) →ₗ[ℝ] ℝ), f ≠ 0 → ∀ t : ℝ,
      ((S.filter (fun x => f x = t)).card:ℝ) < δ*S.card := by
    intro f hf t
    exact lt_of_not_ge (fun hh => hbad ⟨f, hf, t, hh⟩)
  have hSc : (0:ℝ) < S.card := by exact_mod_cast hS.card_pos
  let H := ⌊δ*S.card⌋₊
  have hH : hyperplaneMassBound S H := by
    intro f hf t
    exact Nat.le_floor (hall f hf t).le
  have hHle : (H:ℝ) ≤ δ*S.card := Nat.floor_le (by positivity)
  have hg := freiman_finite_depth_growth n hn L S H hH
  change D*(freimanDepthCoverage c L*S.card-e*H) ≤ ((S+S).card:ℝ) at hg
  rw [freimanDepthCoverage_eq] at hg
  have hres : D*(1-c)^L < ε/2 := by
    have hh := (lt_div_iff₀ (by positivity : 0 < 2*D)).mp hL
    nlinarith
  have hδeq : δ*(4*D*(e+1)) = ε := div_mul_cancel₀ _ (by positivity)
  have herror : D*e*δ ≤ ε/4 := by
    have hδ0 := hδ.le
    have hDeδ : 0 ≤ D*δ := mul_nonneg hD.le hδ0
    nlinarith
  have herrorH : D*e*(H:ℝ) ≤ (ε/4)*S.card := by
    calc
      _ ≤ D*e*(δ*S.card) := mul_le_mul_of_nonneg_left hHle (mul_nonneg hD.le he)
      _ = (D*e*δ)*S.card := by ring
      _ ≤ (ε/4)*S.card := mul_le_mul_of_nonneg_right herror hSc.le
  have hresS : D*(1-c)^L*S.card < (ε/2)*S.card := mul_lt_mul_of_pos_right hres hSc
  change ((S+S).card:ℝ) < (D-ε)*S.card at hsmall
  nlinarith

end
end Optss
