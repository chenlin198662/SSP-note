import Optss.ComputedBohrProgression
import Optss.RationalShortVectorSearch

/-! Integer-only rank constants for the computed Bohr progression. -/
namespace Optss

def computableBohrCeiling (r : ℕ) : ℕ :=
  2*(r+1)^3*r.factorial*integerSharpDefectBound r+1

theorem computableBohrCeiling_pos (r : ℕ) : 0<computableBohrCeiling r := by
  unfold computableBohrCeiling
  omega

theorem computableBohrCeiling_bound (r : ℕ) :
    latticeBoxingDilation r ((r.factorial:ℝ)*sharpLatticeDefectBound r)≤(computableBohrCeiling r:ℝ) := by
  have hs : Real.sqrt (r:ℝ)≤(r:ℝ)+1 := by
    have h := Real.sq_sqrt (Nat.cast_nonneg r)
    have hn := Real.sqrt_nonneg (r:ℝ)
    nlinarith [show (0:ℝ)≤r from Nat.cast_nonneg r]
  have hdef := sharpLatticeDefectBound_le_integer r
  have hω := sharpLatticeDefectBound_pos r
  have hf : (0:ℝ)≤r.factorial := Nat.cast_nonneg _
  unfold latticeBoxingDilation
  calc
    2*(r:ℝ)^2*Real.sqrt r*((r.factorial:ℝ)*sharpLatticeDefectBound r)≤
        2*((r:ℝ)+1)^2*((r:ℝ)+1)*((r.factorial:ℝ)*(integerSharpDefectBound r:ℝ)) := by gcongr <;> nlinarith
    _≤(computableBohrCeiling r:ℝ) := by
      unfold computableBohrCeiling
      push_cast
      nlinarith

def computableBohrLoss (r : ℕ) : ℕ := (16*(2*computableBohrCeiling r+1))^r

theorem computableBohrLoss_pos (r : ℕ) : 0<computableBohrLoss r := by
  unfold computableBohrLoss
  positivity

def listBohrFrequencyFamily {N : ℕ} (S : List (ZMod N)) : Fin (S.length+1)→ZMod N :=
  Fin.cons 1 S.get

theorem listBohrFrequencyFamily_zero {N : ℕ} (S : List (ZMod N)) : listBohrFrequencyFamily S 0=1 := rfl

theorem listBohrFrequencyFamily_covers {N : ℕ} (S : List (ZMod N)) (k : ZMod N) (hk : k∈S) :
    ∃ j,listBohrFrequencyFamily S j=k := by
  obtain ⟨i,hi⟩ := List.mem_iff_get.mp hk
  exact ⟨i.succ,by simpa only [listBohrFrequencyFamily,Fin.cons_succ] using hi⟩

def computedListBohrBox {N : ℕ} [NeZero N] (S : List (ZMod N)) :
    Option (BooleanLatticeBoxResult (S.length+1)) :=
  computedBohrBox (listBohrFrequencyFamily S) 0 (computableBohrCeiling (S.length+1)).bits

theorem computedListBohrBox_spec {N : ℕ} [NeZero N] (S : List (ZMod N)) :
    ∃ box,computedListBohrBox S=some box ∧
      Set.InjOn (storedPhaseProjection (N:=N) 0 box) (integerBudgetBox (decodedLatticeBoxWidths box)) ∧
      (↑(integerProgressionValues (storedPhaseProjection (N:=N) 0 box) (decodedLatticeBoxWidths box)):Set (ZMod N))⊆
        cyclicBohrSet S.toFinset ∧
      N≤computableBohrLoss (S.length+1)*
        (integerProgressionValues (storedPhaseProjection (N:=N) 0 box) (decodedLatticeBoxWidths box)).card ∧
      (∀ j,BitListCanonical (box.widths.toVector.get j)) := by
  obtain ⟨box,hbox,hproper,hsub,hcard,hcanon⟩ := computedBohrBox_spec
    (listBohrFrequencyFamily S) 0 (listBohrFrequencyFamily_zero S) S.toFinset
    (fun k hk => listBohrFrequencyFamily_covers S k (List.mem_toFinset.mp hk))
    (computableBohrCeiling (S.length+1)).bits
    (by rw [binaryDigitsValue_bits]; exact computableBohrCeiling_pos _)
    (by rw [binaryDigitsValue_bits]; exact computableBohrCeiling_bound _)
  refine ⟨box,hbox,hproper,?_,?_,hcanon⟩
  · intro x hx
    obtain ⟨z,hz,rfl⟩ := Finset.mem_image.mp hx
    exact hsub z hz
  · simpa only [integerProgressionValues,Finset.card_image_of_injOn hproper,
      integerBudgetBox_card,computableBohrLoss,binaryDigitsValue_bits] using hcard
end Optss
