import Optss.FixedPointRadixTwo
import Optss.BinaryMultiplication

/-! Actual integer-entry heights in the fixed-point butterfly arrays. These
bounds avoid assumptions that intermediate rational values remain small. -/
namespace Optss

def FourierIntegerBound (z : FourierInteger) (B : ℕ) : Prop :=
  |z.re|≤(B : ℤ) ∧ |z.im|≤(B : ℤ)

theorem FourierIntegerBound.add {z w : FourierInteger} {B C : ℕ}
    (hz : FourierIntegerBound z B) (hw : FourierIntegerBound w C) :
    FourierIntegerBound (z+w) (B+C) := by
  constructor
  · change |z.re+w.re|≤((B+C : ℕ) : ℤ)
    push_cast
    exact (abs_add _ _).trans (add_le_add hz.1 hw.1)
  · change |z.im+w.im|≤((B+C : ℕ) : ℤ)
    push_cast
    exact (abs_add _ _).trans (add_le_add hz.2 hw.2)

theorem FourierIntegerBound.mul {z w : FourierInteger} {B C : ℕ}
    (hz : FourierIntegerBound z B) (hw : FourierIntegerBound w C) :
    FourierIntegerBound (z*w) (2*(B*C)) := by
  have h₁ : |z.re*w.re|≤(B : ℤ)*C := by rw [abs_mul]; gcongr; exact hz.1; exact hw.1
  have h₂ : |z.im*w.im|≤(B : ℤ)*C := by rw [abs_mul]; gcongr; exact hz.2; exact hw.2
  have h₃ : |z.re*w.im|≤(B : ℤ)*C := by rw [abs_mul]; gcongr; exact hz.1; exact hw.2
  have h₄ : |z.im*w.re|≤(B : ℤ)*C := by rw [abs_mul]; gcongr; exact hz.2; exact hw.1
  constructor
  · change |z.re*w.re-z.im*w.im|≤((2*(B*C) : ℕ) : ℤ)
    push_cast
    have h := abs_sub (z.re*w.re) (z.im*w.im)
    omega
  · change |z.re*w.im+z.im*w.re|≤((2*(B*C) : ℕ) : ℤ)
    push_cast
    have h := abs_add (z.re*w.im) (z.im*w.re)
    omega

theorem FourierIntegerBound.scale {z : FourierInteger} {B : ℕ}
    (hz : FourierIntegerBound z B) (D : ℕ) :
    FourierIntegerBound (fourierIntegerScale D z) (D*B) := by
  constructor
  · change |(D : ℤ)*z.re|≤((D*B : ℕ) : ℤ)
    rw [abs_mul,abs_of_nonneg (by positivity : (0 : ℤ)≤D),Nat.cast_mul]
    exact mul_le_mul_of_nonneg_left hz.1 (by positivity)
  · change |(D : ℤ)*z.im|≤((D*B : ℕ) : ℤ)
    rw [abs_mul,abs_of_nonneg (by positivity : (0 : ℤ)≤D),Nat.cast_mul]
    exact mul_le_mul_of_nonneg_left hz.2 (by positivity)

theorem fixedPointRadixTwo_entry_bound (D B : ℕ) (T : ℕ → ℕ → FourierInteger)
    (n : ℕ) (A : Vector FourierInteger (2^n))
    (hA : ∀ j, FourierIntegerBound (A.get j) B)
    (hT : ∀ l<n, ∀ k, FourierIntegerBound (T l k) (2*D)) (k : Fin (2^n)) :
    FourierIntegerBound ((fixedPointRadixTwo D T n A).get k) ((5*D)^n*B) := by
  induction n with
  | zero => simpa only [fixedPointRadixTwo,pow_zero,one_mul] using hA k
  | succ n ih =>
    have he := ih (radixEvenData n A)
      (fun j => by simpa only [radixEvenData,vector_get_ofFn] using hA (radixEvenIndex n j))
      (fun l hl k => hT l (by omega) k) (radixModIndex n k)
    have ho := ih (radixOddData n A)
      (fun j => by simpa only [radixOddData,vector_get_ofFn] using hA (radixOddIndex n j))
      (fun l hl k => hT l (by omega) k) (radixModIndex n k)
    have hb := (he.scale D).add ((hT n (by omega) k.val).mul ho)
    have hsize : D*((5*D)^n*B)+2*((2*D)*((5*D)^n*B))=(5*D)^(n+1)*B := by
      rw [pow_succ]
      ring
    rw [hsize] at hb
    simpa only [fixedPointRadixTwo,vector_get_ofFn] using hb

theorem nat_power_size_le (a n : ℕ) : (a^n).size≤n*a.size+1 := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [pow_succ]
    exact (nat_mul_size_le _ _).trans (by nlinarith)

/-- Entry bit lengths grow linearly in the depth and denominator bit length. -/
theorem fixedPointRadixTwo_entry_bits (D B : ℕ) (T : ℕ → ℕ → FourierInteger)
    (n : ℕ) (A : Vector FourierInteger (2^n))
    (hA : ∀ j, FourierIntegerBound (A.get j) B)
    (hT : ∀ l<n, ∀ k, FourierIntegerBound (T l k) (2*D)) (k : Fin (2^n)) :
    ((fixedPointRadixTwo D T n A).get k).re.natAbs.size≤n*(D.size+3)+B.size+1 ∧
      ((fixedPointRadixTwo D T n A).get k).im.natAbs.size≤n*(D.size+3)+B.size+1 := by
  have hb := fixedPointRadixTwo_entry_bound D B T n A hA hT k
  have hcoeff : (5*D).size≤D.size+3 := by
    have h := nat_mul_size_le 5 D
    have hfive : (5 : ℕ).size≤3 := Nat.size_le.mpr (by decide)
    omega
  have hpow : ((5*D)^n).size≤n*(D.size+3)+1 :=
    (nat_power_size_le _ _).trans (by gcongr)
  have htotal : ((5*D)^n*B).size≤n*(D.size+3)+B.size+1 :=
    (nat_mul_size_le _ _).trans (by omega)
  constructor
  · apply (Nat.size_le_size ?_).trans htotal
    have hh := hb.1
    rw [← Int.natCast_natAbs] at hh
    exact_mod_cast hh
  · apply (Nat.size_le_size ?_).trans htotal
    have hh := hb.2
    rw [← Int.natCast_natAbs] at hh
    exact_mod_cast hh

end Optss
