import Optss.EncodedFuelConstruction
import Optss.ListStorageRationalIO

/-!
# Structural fuel directly from nested list storage

The initializer traverses stored row lists and magnitude bits directly. It uses
no vector conversion, integer magnitude arithmetic, or dimension computation.
Its result is literally the already verified structural fuel list. Constructor
and traversal counts include the row scan and all repeated token copies.
-/

namespace Optss
variable {r d : ℕ}

private theorem data_eq_ofFn {α : Type*} {n : ℕ} (A : BooleanListArray α n) :
    A.data = List.ofFn A.toVector.get := by
  apply List.ext_getElem
  · simp [A.length_eq]
  · intro i hi hj
    simp [List.getElem_ofFn, BooleanListArray.toVector, Vector.get]

theorem ioArrayVector_toList {α : Type*} {n : ℕ} (A : BooleanListArray α n) :
    A.toVector.toList = A.data := by
  rw [BooleanListArray.toVector, Vector.toList_ofFn]
  apply List.ext_getElem
  · simp [A.length_eq]
  · intro i hi hj
    simp only [List.getElem_ofFn]

theorem ioMatrixVector_toList {α : Type*}
    (A : BooleanListArray (BooleanListArray α d) r) :
    (ioMatrixVector A).toList = A.data.map BooleanListArray.toVector := by
  rw [ioMatrixVector, Vector.toList_ofFn, data_eq_ofFn A, List.map_ofFn]
  rfl

/-- A row marker, a sign marker per entry and the actual digit bits. -/
def listStorageFuelRowsInto :
    List (BooleanListArray BitListInteger d) → List Bool → List Bool
  | [], tail => tail
  | row::rows, tail =>
    false::fuelEntriesInto row.data (listStorageFuelRowsInto rows tail)

def listStoredFuelTokens (D : BooleanListArray (BooleanListArray BitListInteger d) r) : List Bool :=
  listStorageFuelRowsInto D.data [false,false,false]

def listStoredStructuralFuel (D : BooleanListArray (BooleanListArray BitListInteger d) r) : List Bool :=
  let tokens := listStoredFuelTokens D
  let square := fuelListRepeat tokens tokens
  let cube := fuelListRepeat tokens square
  fuelListRepeat [false,false,false,false,false,false,false,false,false] cube

theorem listStorageFuelRowsInto_eq (rows : List (BooleanListArray BitListInteger d))
    (tail : List Bool) :
    listStorageFuelRowsInto rows tail = fuelRowsInto (rows.map BooleanListArray.toVector) tail := by
  induction rows with
  | nil => rfl
  | cons row rows ih =>
    simp only [listStorageFuelRowsInto, List.map_cons, fuelRowsInto, ioArrayVector_toList, ih]

theorem listStoredFuelTokens_eq (D : BooleanListArray (BooleanListArray BitListInteger d) r) :
    listStoredFuelTokens D = encodedFuelTokens (ioMatrixVector D) := by
  rw [listStoredFuelTokens, listStorageFuelRowsInto_eq, encodedFuelTokens, ioMatrixVector_toList]

theorem listStoredStructuralFuel_eq (D : BooleanListArray (BooleanListArray BitListInteger d) r) :
    listStoredStructuralFuel D = encodedStructuralFuel (ioMatrixVector D) := by
  simp only [listStoredStructuralFuel, listStoredFuelTokens_eq, encodedStructuralFuel]

theorem listStoredStructuralFuel_length (D : BooleanListArray (BooleanListArray BitListInteger d) r) :
    (listStoredStructuralFuel D).length = 9*(r+bitIntegerMatrixSize (ioMatrixVector D)+3)^3 := by
  rw [listStoredStructuralFuel_eq, encodedStructuralFuel_length]

/-- Each row costs a test, stored-list access and marker construction. -/
def listStorageFuelRowsIntoWork : List (BooleanListArray BitListInteger d) → ℕ
  | [] => 1
  | row::rows => listStorageFuelRowsIntoWork rows+fuelEntriesIntoWork row.data+3

/-- Also includes the outer list access and the three seed tokens. -/
def listStoredFuelTokensWork (D : BooleanListArray (BooleanListArray BitListInteger d) r) : ℕ :=
  listStorageFuelRowsIntoWork D.data+4

def listStoredStructuralFuelWork (D : BooleanListArray (BooleanListArray BitListInteger d) r) : ℕ :=
  let tokens := listStoredFuelTokens D
  let square := fuelListRepeat tokens tokens
  let cube := fuelListRepeat tokens square
  listStoredFuelTokensWork D+fuelListRepeatWork tokens tokens+fuelListRepeatWork tokens square+
    fuelListRepeatWork [false,false,false,false,false,false,false,false,false] cube+9

theorem listStorageFuelRowsIntoWork_le (rows : List (BooleanListArray BitListInteger d)) :
    listStorageFuelRowsIntoWork rows ≤ fuelRowsIntoWork (rows.map BooleanListArray.toVector) := by
  induction rows with
  | nil => rfl
  | cons row rows ih =>
    simp only [listStorageFuelRowsIntoWork, List.map_cons, fuelRowsIntoWork, ioArrayVector_toList]
    omega

theorem listStoredFuelTokensWork_le (D : BooleanListArray (BooleanListArray BitListInteger d) r) :
    listStoredFuelTokensWork D ≤ encodedFuelTokensWork (ioMatrixVector D) := by
  have h := listStorageFuelRowsIntoWork_le D.data
  simp only [listStoredFuelTokensWork, encodedFuelTokensWork, ioMatrixVector_toList]
  omega

theorem listStoredStructuralFuelWork_le (D : BooleanListArray (BooleanListArray BitListInteger d) r) :
    listStoredStructuralFuelWork D ≤ encodedStructuralFuelWork (ioMatrixVector D) := by
  have h := listStoredFuelTokensWork_le D
  simp only [listStoredStructuralFuelWork, encodedStructuralFuelWork, listStoredFuelTokens_eq]
  omega

theorem listStoredStructuralFuelWork_bound (D : BooleanListArray (BooleanListArray BitListInteger d) r) :
    listStoredStructuralFuelWork D ≤ 64*(r+bitIntegerMatrixSize (ioMatrixVector D)+3)^3 :=
  (listStoredStructuralFuelWork_le D).trans (encodedStructuralFuelWork_bound _)

end Optss
