import Optss.LatticeBoxingCounting

/-!
# Integer coordinates in a basis of the whole standard lattice

Equality with the complete integer lattice constructs an actual integer linear
equivalence, not just coordinates in a real vector space. This gives the
smaller GAP encoding used after quotient-body boxing in properization.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {r : ℕ}

theorem exists_integer_basis_synthesis (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (hΛ : basisIntegerLattice b = Set.range realVector) (z : IntVec r) :
    ∃ x : IntVec r, realVector x = b.equivFun.symm (realVector z) := by
  apply hΛ ▸ show b.equivFun.symm (realVector z) ∈ basisIntegerLattice b from ?_
  intro j
  refine ⟨z j, ?_⟩
  change b.equivFun (b.equivFun.symm (realVector z)) j = (z j:ℝ)
  rw [LinearEquiv.apply_symm_apply]
  rfl

def integerBasisSynthesis (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (hΛ : basisIntegerLattice b = Set.range realVector) (z : IntVec r) : IntVec r :=
  (exists_integer_basis_synthesis b hΛ z).choose

@[simp] theorem integerBasisSynthesis_cast (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (hΛ : basisIntegerLattice b = Set.range realVector) (z : IntVec r) :
    realVector (integerBasisSynthesis b hΛ z) = b.equivFun.symm (realVector z) :=
  (exists_integer_basis_synthesis b hΛ z).choose_spec

def integerBasisSynthesisHom (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (hΛ : basisIntegerLattice b = Set.range realVector) : IntVec r →+ IntVec r where
  toFun := integerBasisSynthesis b hΛ
  map_zero' := by
    apply realVector_is_injective
    rw [integerBasisSynthesis_cast]
    rw [map_zero, map_zero]
  map_add' x y := by
    apply realVector_is_injective
    have hcast (u v : IntVec r) : realVector (u+v)=realVector u+realVector v := by
      ext j
      simp [realVector]
    rw [integerBasisSynthesis_cast, hcast, map_add, hcast,
      integerBasisSynthesis_cast, integerBasisSynthesis_cast]

theorem integerBasisSynthesis_bijective (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (hΛ : basisIntegerLattice b = Set.range realVector) :
    Function.Bijective (integerBasisSynthesis b hΛ) := by
  constructor
  · intro x y h
    apply realVector_is_injective
    apply b.equivFun.symm.injective
    simpa only [integerBasisSynthesis_cast] using congrArg realVector h
  · intro x
    have hx : realVector x ∈ basisIntegerLattice b := hΛ ▸ Set.mem_range_self x
    choose z hz using hx
    refine ⟨z, realVector_is_injective ?_⟩
    rw [integerBasisSynthesis_cast]
    have he : b.equivFun (realVector x)=realVector z := funext hz
    rw [← he, LinearEquiv.symm_apply_apply]

/-- An actual unimodular change of integer coordinates, extracted from the
whole-lattice basis hypothesis. -/
def integerBasisEquiv (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (hΛ : basisIntegerLattice b = Set.range realVector) : IntVec r ≃ₗ[ℤ] IntVec r :=
  LinearEquiv.ofBijective (integerBasisSynthesisHom b hΛ).toIntLinearMap
    (integerBasisSynthesis_bijective b hΛ)

@[simp] theorem integerBasisEquiv_cast (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (hΛ : basisIntegerLattice b = Set.range realVector) (z : IntVec r) :
    realVector (integerBasisEquiv b hΛ z) = b.equivFun.symm (realVector z) :=
  integerBasisSynthesis_cast b hΛ z

@[simp] theorem integerBasisEquiv_symm_cast (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (hΛ : basisIntegerLattice b = Set.range realVector) (x : IntVec r) :
    realVector ((integerBasisEquiv b hΛ).symm x) = b.equivFun (realVector x) := by
  apply b.equivFun.symm.injective
  rw [LinearEquiv.symm_apply_apply, ← integerBasisEquiv_cast,
    LinearEquiv.apply_symm_apply]

theorem integerBasisEquiv_box (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (hΛ : basisIntegerLattice b = Set.range realVector) (n : Fin r → ℕ) (x : IntVec r) :
    (integerBasisEquiv b hΛ).symm x ∈ integerBudgetBox n ↔
      realVector x ∈ basisCoefficientBox b n := by
  rw [mem_integerBudgetBox]
  constructor
  · intro hx j
    have hcast := congrFun (integerBasisEquiv_symm_cast b hΛ x) j
    change (((integerBasisEquiv b hΛ).symm x j):ℝ) = b.equivFun (realVector x) j at hcast
    have hj : |(((integerBasisEquiv b hΛ).symm x j):ℝ)| ≤ (n j:ℝ) := by
      exact_mod_cast hx j
    rw [hcast] at hj
    exact hj
  · intro hx j
    have hcast := congrFun (integerBasisEquiv_symm_cast b hΛ x) j
    change (((integerBasisEquiv b hΛ).symm x j):ℝ) = b.equivFun (realVector x) j at hcast
    have hj := hx j
    change |b.equivFun (realVector x) j| ≤ (n j:ℝ) at hj
    rw [← hcast] at hj
    exact_mod_cast hj

end
end Optss
