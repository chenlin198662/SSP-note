import Optss.RationalGramSchmidt
import Mathlib.Data.Prod.Lex

/-!
# Executable exact lattice reduction

The executed path uses rational Gram-Schmidt, integer matrix operations, and
the least failing adjacent pair in a finite ordered search. It contains no
real computation or classical choice. Termination and all output guarantees
are checked by the same integer Gram-potential argument as the mathematical
procedure. This module does not assert an arithmetic bit-cost bound.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

/-- Exact finite search space of adjacent pairs failing the `3/4` integer
Gram-determinant comparison. -/
def failingAdjacentPairs (A : Matrix (Fin r) (Fin d) ℤ) : Finset (Fin r × Fin r) :=
  Finset.univ.filter fun p => p.2.val = p.1.val+1 ∧
    4*prefixGramDet (swapRows A p.1 p.2) ⟨p.2.val, by omega⟩ <
      3*prefixGramDet A ⟨p.2.val, by omega⟩

theorem mem_failingAdjacentPairs (A : Matrix (Fin r) (Fin d) ℤ) (p : Fin r × Fin r) :
    p ∈ failingAdjacentPairs A ↔ p.2.val = p.1.val+1 ∧
      4*prefixGramDet (swapRows A p.1 p.2) ⟨p.2.val, by omega⟩ <
        3*prefixGramDet A ⟨p.2.val, by omega⟩ := by
  simp only [failingAdjacentPairs, Finset.mem_filter, Finset.mem_univ, true_and]

/-- Deterministic lexicographic choice from the finite failing-pair set. The
irreducibility annotation prevents proof elaboration from expanding its finite
search; it does not affect executable code generation. -/
@[irreducible] def leastFailingAdjacentPair (A : Matrix (Fin r) (Fin d) ℤ)
    (h : (failingAdjacentPairs A).Nonempty) : Fin r × Fin r := by
  letI : LinearOrder (Fin r × Fin r) :=
    LinearOrder.lift' (toLex : Fin r × Fin r → Fin r ×ₗ Fin r)
      (fun _ _ h => toLex_inj.mp h)
  exact (failingAdjacentPairs A).min' h

theorem leastFailingAdjacentPair_mem (A : Matrix (Fin r) (Fin d) ℤ)
    (h : (failingAdjacentPairs A).Nonempty) :
    leastFailingAdjacentPair A h ∈ failingAdjacentPairs A := by
  letI : LinearOrder (Fin r × Fin r) :=
    LinearOrder.lift' (toLex : Fin r × Fin r → Fin r ×ₗ Fin r)
      (fun _ _ h => toLex_inj.mp h)
  unfold leastFailingAdjacentPair
  exact Finset.min'_mem _ _

/-- A proof-elaboration boundary around the computable finite search test. -/
@[irreducible] def decidableFailingAdjacentPairs (A : Matrix (Fin r) (Fin d) ℤ) :
    Decidable (failingAdjacentPairs A).Nonempty := inferInstance

/-- Executable rational size sweep, kept opaque to proof elaboration. -/
@[irreducible] def executableSizeSweep (A : Matrix (Fin r) (Fin d) ℤ) :
    Matrix (Fin r) (Fin d) ℤ := rationalReduceIntegerAll A r le_rfl

theorem executableSizeSweep_spec (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ))) :
    LinearIndependent ℝ (fun i => fun j => (executableSizeSweep A i j:ℝ)) ∧
    Submodule.span ℤ (Set.range (executableSizeSweep A)) = Submodule.span ℤ (Set.range A) ∧
    gramPotential (executableSizeSweep A) = gramPotential A ∧
    ∀ k j : Fin r, j < k →
      |gsCoefficient (euclideanIntegerRows (executableSizeSweep A)) k j| ≤ 1/2 := by
  unfold executableSizeSweep
  exact rationalReduceIntegerAll_spec A hA

/-- A purely executable, structurally recursive loop. The initial potential is
sufficient fuel: every swap strictly decreases that positive integer. Fuel is
only a termination device; the loop stops immediately when its finite test
finds no failing pair. -/
def executableReductionFuel : ℕ → Matrix (Fin r) (Fin d) ℤ →
    Matrix (Fin r) (Fin d) ℤ × ℕ
  | 0, A => (A, 0)
  | n+1, A =>
    let C := executableSizeSweep A
    letI : Decidable (failingAdjacentPairs C).Nonempty := decidableFailingAdjacentPairs C
    if hfail : (failingAdjacentPairs C).Nonempty then
      let p := leastFailingAdjacentPair C hfail
      let out := executableReductionFuel n (swapRows C p.1 p.2)
      (out.1, out.2+1)
    else (C, 0)

/-- The semantic specification is separate from the computed data. -/
def IntegerReductionSpecification (A B : Matrix (Fin r) (Fin d) ℤ) (s : ℕ) : Prop :=
  LinearIndependent ℝ (fun i => fun j => (B i j:ℝ)) ∧
  Submodule.span ℤ (Set.range B) = Submodule.span ℤ (Set.range A) ∧
  (∀ k j : Fin r, j < k → |gsCoefficient (euclideanIntegerRows B) k j| ≤ 1/2) ∧
  (∀ j k : Fin r, k.val = j.val+1 →
    3*prefixGramDet B ⟨k.val, by omega⟩ ≤
      4*prefixGramDet (swapRows B j k) ⟨k.val, by omega⟩) ∧
  4^s*gramPotential B ≤ 3^s*gramPotential A

theorem executableReductionFuel_spec (fuel : ℕ) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ)))
    (hfuel : gramPotential A ≤ fuel) :
    IntegerReductionSpecification A (executableReductionFuel fuel A).1
      (executableReductionFuel fuel A).2 := by
  induction fuel generalizing A with
  | zero => exact False.elim (by have := gramPotential_pos A hA; omega)
  | succ n ih =>
    let C := executableSizeSweep A
    obtain ⟨hC, hspanC, hpotC, hsizeC⟩ := executableSizeSweep_spec A hA
    change LinearIndependent ℝ (fun i => fun j => (C i j:ℝ)) at hC
    change Submodule.span ℤ (Set.range C) = Submodule.span ℤ (Set.range A) at hspanC
    change gramPotential C = gramPotential A at hpotC
    change ∀ k j : Fin r, j < k → |gsCoefficient (euclideanIntegerRows C) k j| ≤ 1/2 at hsizeC
    letI : Decidable (failingAdjacentPairs C).Nonempty := decidableFailingAdjacentPairs C
    rw [executableReductionFuel]
    change IntegerReductionSpecification A
      (if hfail : (failingAdjacentPairs C).Nonempty then
        let p := leastFailingAdjacentPair C hfail
        let out := executableReductionFuel n (swapRows C p.1 p.2)
        (out.1, out.2+1)
      else (C, 0)).1 _
    split
    · rename_i hfail
      let p := leastFailingAdjacentPair C hfail
      have hp : p ∈ failingAdjacentPairs C := leastFailingAdjacentPair_mem C hfail
      have hbad := (mem_failingAdjacentPairs C p).mp hp
      have hswap : LinearIndependent ℝ (fun i => fun l => ((swapRows C p.1 p.2) i l:ℝ)) :=
        hC.comp (Equiv.swap p.1 p.2) (Equiv.swap p.1 p.2).injective
      have hcontract : 4*gramPotential (swapRows C p.1 p.2) < 3*gramPotential A := by
        rw [← hpotC]
        exact gramPotential_swap_three_quarters C hC p.1 p.2 hbad.1 hbad.2
      have hremaining : gramPotential (swapRows C p.1 p.2) ≤ n := by omega
      obtain ⟨hout, hspan, hsize, hlovasz, hbound⟩ :=
        ih (swapRows C p.1 p.2) hswap hremaining
      let out := executableReductionFuel n (swapRows C p.1 p.2)
      change IntegerReductionSpecification A out.1 (out.2+1)
      refine ⟨hout, hspan.trans ((span_permuteVector C (Equiv.swap p.1 p.2)).trans hspanC),
        hsize, hlovasz, ?_⟩
      change 4^out.2*gramPotential out.1 ≤ 3^out.2*gramPotential (swapRows C p.1 p.2) at hbound
      calc
        4^(out.2+1)*gramPotential out.1 = 4*(4^out.2*gramPotential out.1) := by rw [pow_succ]; ring
        _ ≤ 4*(3^out.2*gramPotential (swapRows C p.1 p.2)) := Nat.mul_le_mul_left 4 hbound
        _ = 3^out.2*(4*gramPotential (swapRows C p.1 p.2)) := by ring
        _ ≤ 3^out.2*(3*gramPotential A) := Nat.mul_le_mul_left _ hcontract.le
        _ = 3^(out.2+1)*gramPotential A := by rw [pow_succ]; ring
    · rename_i hfail
      change IntegerReductionSpecification A C 0
      refine ⟨hC, hspanC, hsizeC, ?_, by simpa only [pow_zero, one_mul] using hpotC.le⟩
      intro j k hjk
      by_contra hn
      exact hfail ⟨(j,k), (mem_failingAdjacentPairs C (j,k)).mpr ⟨hjk, lt_of_not_ge hn⟩⟩

/-- The deterministic executable procedure together with its checked output
record. Its matrix and count fields come directly from the rational loop;
proof fields introduce no operations into the executed program. -/
def executableIntegerReduction (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ))) : IntegerLLLResult A :=
  let out := executableReductionFuel (gramPotential A) A
  let h := executableReductionFuel_spec (gramPotential A) A hA le_rfl
  { rows := out.1
    swapCount := out.2
    independent := h.1
    sameLattice := h.2.1
    sizeReduced := h.2.2.1
    lovasz := h.2.2.2.1
    contraction := h.2.2.2.2 }

/-- The actual executable result has the same logarithmic swap bound as the
verified mathematical procedure. -/
theorem executableIntegerReduction_swapCount_le_log (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ))) :
    ((executableIntegerReduction A hA).swapCount:ℝ) ≤
      Real.log (gramPotential A:ℝ) / Real.log (4/3:ℝ) :=
  (executableIntegerReduction A hA).swapCount_le_log A

/-- Every actual Euclidean basis represented by the executable output rows
has the verified dimension-only orthogonality-defect bound. -/
theorem executableIntegerReduction_defect_le (A : Matrix (Fin r) (Fin r) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ)))
    (b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)))
    (hb : ∀ i, b i = euclideanIntegerRows (executableIntegerReduction A hA).rows i) :
    euclideanOrthogonalityDefect b ≤ latticeReductionDefectBound r :=
  (executableIntegerReduction A hA).defect_le A b hb

end Optss
