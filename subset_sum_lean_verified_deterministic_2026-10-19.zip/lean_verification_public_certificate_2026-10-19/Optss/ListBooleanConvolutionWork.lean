import Optss.ListBooleanConvolution

/-! Work of exact Boolean cyclic support convolution, including preparation
of stored zero/one entries, the three FFTs, the common denominator, and every
rounding/comparison used to recover the Boolean support. -/
namespace Optss
set_option maxRecDepth 4096
set_option maxHeartbeats 800000

theorem bitFourierBoolean_bounds (b : Bool) : (bitFourierBoolean b).Canonical ∧ (bitFourierBoolean b).Width 1 := by
  cases b
  · exact ⟨bitFourierZero_canonical,bitFourierZero_width _⟩
  · norm_num [bitFourierBoolean,BitFourierInteger.Canonical,BitFourierInteger.Width,BitListCanonical,binaryDigitsValue]

def listConvolutionDenominatorWork (depth : List Bool) (p : ℕ) : ℕ :=
  16*depth.length+16+4*(p+3)*(3*depth.length)+2*(depth.length+(p+2)*(3*depth.length))+3

theorem listConvolutionDenominatorWork_bound (depth : List Bool) (p : ℕ) :
    listConvolutionDenominatorWork depth p≤64*(depth.length+1)*(p+3) := by
  unfold listConvolutionDenominatorWork
  nlinarith

def listBooleanConvolutionWork (depth : List Bool) (f g : List Bool) : ℕ :=
  let p := dyadicDFTPrecision depth.length
  let den := listConvolutionDenominator depth p
  let A := f.map bitFourierBoolean
  let B := g.map bitFourierBoolean
  let C := listCyclicConvolution depth p A B
  listCyclicConvolutionWork depth p A B+
    (C.map (bitConvolutionPositiveWork den)).sum+
    listConvolutionDenominatorWork depth p+16*(f.length+g.length)+8*C.length+32

def listBooleanConvolutionWorkBound (n : ℕ) : ℕ :=
  let p := dyadicDFTPrecision n
  3*listDyadicWorkPolynomial n p (2*(n*(p+6)+3)+1)+
    512*2^n*(n*(p+6)+4)^2+6*2^n+8+
    2^n*(1048576*(3*n*(p+6)+10)^3)+
    64*(n+1)*(p+3)+40*2^n+32

theorem listBooleanConvolutionWork_bound (depth : List Bool) (f g : List Bool)
    (hf : f.length=2^depth.length) (hg : g.length=2^depth.length) :
    listBooleanConvolutionWork depth f g≤listBooleanConvolutionWorkBound depth.length := by
  let p := dyadicDFTPrecision depth.length
  let A := f.map bitFourierBoolean
  let B := g.map bitFourierBoolean
  let C := listCyclicConvolution depth p A B
  have ha : ∀ z∈A,z.Canonical ∧ z.Width 1 := by
    intro z hz
    obtain ⟨b,hb,rfl⟩ := List.mem_map.mp hz
    exact bitFourierBoolean_bounds b
  have hb : ∀ z∈B,z.Canonical ∧ z.Width 1 := by
    intro z hz
    obtain ⟨b,hb,rfl⟩ := List.mem_map.mp hz
    exact bitFourierBoolean_bounds b
  have hla : A.length=2^depth.length := by simpa only [A,List.length_map] using hf
  have hlb : B.length=2^depth.length := by simpa only [B,List.length_map] using hg
  have hc := listCyclicConvolution_list_bounds depth p 1 A B hla hlb ha hb
  have hw := listCyclicConvolutionWork_list_bound depth p 1 A B hla hlb ha hb
  let den := listConvolutionDenominator depth p
  let L := 3*depth.length*(p+6)+9
  have hd : den.length≤L := by
    rw [listConvolutionDenominator_length]
    dsimp [L]
    nlinarith
  have hp : 0<binaryDigitsValue den := by
    rw [listConvolutionDenominator_value]
    exact cyclicConvolutionDenominator_pos _ _
  have hs : (C.map (bitConvolutionPositiveWork den)).sum≤2^depth.length*(1048576*(L+1)^3) := by
    have h := List.sum_le_card_nsmul (C.map (bitConvolutionPositiveWork den)) (1048576*(L+1)^3) (by
      intro w hw
      obtain ⟨z,hz,rfl⟩ := List.mem_map.mp hw
      apply bitConvolutionPositiveWork_bound den z hp L
      · simpa only [Nat.mul_one,Nat.reduceAdd] using (hc.2 z hz).2
      · exact hd)
    have hcl : C.length=2^depth.length := hc.1
    have hml : (C.map (bitConvolutionPositiveWork den)).length=2^depth.length :=
      (List.length_map (bitConvolutionPositiveWork den)).trans hcl
    rw [hml,nsmul_eq_mul] at h
    exact h
  have hden := listConvolutionDenominatorWork_bound depth p
  change listCyclicConvolutionWork depth p A B+(C.map (bitConvolutionPositiveWork den)).sum+
    listConvolutionDenominatorWork depth p+16*(f.length+g.length)+8*C.length+32≤_
  rw [hf,hg,hc.1]
  unfold listBooleanConvolutionWorkBound
  change _≤3*listDyadicWorkPolynomial depth.length p (2*(depth.length*(p+6)+3)+1)+
    512*2^depth.length*(depth.length*(p+6)+4)^2+6*2^depth.length+8+
    2^depth.length*(1048576*(3*depth.length*(p+6)+10)^3)+64*(depth.length+1)*(p+3)+40*2^depth.length+32
  dsimp only [L] at hs
  norm_num only [Nat.add_assoc] at hw hs ⊢
  omega

def listSupportFFTWorkFactor (n p b : ℕ) : ℕ :=
  2*(320*(n+3)^2+4194304*(n+p+73)^2*(8192*(n+p+73)^4+1)^3+16)+
    4*(p+3)+4+576*(n+1)*(n*(p+6)+b+3)^2

theorem listSupportFFTWorkFactor_bound (n p b : ℕ) :
    listDyadicWorkPolynomial n p b≤2^n*listSupportFFTWorkFactor n p b := by
  have hM : 0 < 2^n := pow_pos (by decide) _
  have hh : 4*(p+3)+4≤2^n*(4*(p+3)+4) := Nat.le_mul_of_pos_left _ hM
  unfold listDyadicWorkPolynomial listSupportFFTWorkFactor
  rw [pow_succ]
  generalize 320*(n+3)^2+4194304*(n+p+73)^2*(8192*(n+p+73)^4+1)^3+16 = X at *
  generalize (n*(p+6)+b+3)^2 = Y at *
  nlinarith only [hh]

def listBooleanConvolutionWorkFactor (n : ℕ) : ℕ :=
  let p := dyadicDFTPrecision n
  3*listSupportFFTWorkFactor n p (2*(n*(p+6)+3)+1)+
    512*(n*(p+6)+4)^2+14+1048576*(3*n*(p+6)+10)^3+
    64*(n+1)*(p+3)+72

theorem listBooleanConvolutionWorkBound_factor (n : ℕ) :
    listBooleanConvolutionWorkBound n≤2^n*listBooleanConvolutionWorkFactor n := by
  let p := dyadicDFTPrecision n
  have hM : 0 < 2^n := pow_pos (by decide) _
  have hfft := listSupportFFTWorkFactor_bound n p (2*(n*(p+6)+3)+1)
  have hden : 64*(n+1)*(p+3)≤2^n*(64*(n+1)*(p+3)) := Nat.le_mul_of_pos_left _ hM
  have hsmall : 8≤2^n*8 := Nat.le_mul_of_pos_left _ hM
  have hsmall' : 32≤2^n*32 := Nat.le_mul_of_pos_left _ hM
  change listBooleanConvolutionWorkBound n≤_
  unfold listBooleanConvolutionWorkBound listBooleanConvolutionWorkFactor
  change 3*listDyadicWorkPolynomial n p (2*(n*(p+6)+3)+1)+512*2^n*(n*(p+6)+4)^2+6*2^n+8+
    2^n*(1048576*(3*n*(p+6)+10)^3)+64*(n+1)*(p+3)+40*2^n+32≤
    2^n*(3*listSupportFFTWorkFactor n p (2*(n*(p+6)+3)+1)+512*(n*(p+6)+4)^2+14+
      1048576*(3*n*(p+6)+10)^3+64*(n+1)*(p+3)+72)
  generalize listDyadicWorkPolynomial n p (2*(n*(p+6)+3)+1) = X at *
  generalize listSupportFFTWorkFactor n p (2*(n*(p+6)+3)+1) = Y at *
  generalize (n*(p+6)+4)^2 = Z at *
  generalize (3*n*(p+6)+10)^3 = W at *
  nlinarith only [hfft,hden,hsmall,hsmall']

theorem listBooleanConvolutionWork_nearlinear (depth : List Bool) (f g : List Bool)
    (hf : f.length=2^depth.length) (hg : g.length=2^depth.length) :
    listBooleanConvolutionWork depth f g≤2^depth.length*listBooleanConvolutionWorkFactor depth.length :=
  (listBooleanConvolutionWork_bound depth f g hf hg).trans (listBooleanConvolutionWorkBound_factor depth.length)

theorem listBooleanConvolutionWorkFactor_mono {n m : ℕ} (h : n ≤ m) :
    listBooleanConvolutionWorkFactor n≤listBooleanConvolutionWorkFactor m := by
  dsimp only [listBooleanConvolutionWorkFactor,listSupportFFTWorkFactor,dyadicDFTPrecision]
  gcongr

end Optss
