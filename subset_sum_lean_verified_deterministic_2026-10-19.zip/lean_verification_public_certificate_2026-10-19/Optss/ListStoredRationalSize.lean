import Optss.ListStorageRationalIOWork
import Optss.RationalWorkPolynomial

/-!
# Literal input size of a list-stored rational matrix

The size counts one row marker, one sign per entry, and every bit in both
magnitude lists. Its equality with the indexed mathematical size permits the
proved arithmetic bounds to apply to the actual list representation.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

def listStoredRationalBits
    (A : BooleanListArray (BooleanListArray BitListFraction d) r) : ℕ :=
  (A.data.map fun row => 1+(row.data.map fun q =>
    1+q.numerator.length+q.denominator.length).sum).sum

theorem booleanListArray_data_eq_ofFn {α : Type*} {n : ℕ} (A : BooleanListArray α n) :
    A.data = List.ofFn A.toVector.get := by
  apply List.ext_getElem
  · simp [A.length_eq]
  · intro i hi hj
    simp [List.getElem_ofFn, BooleanListArray.toVector, Vector.get]

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

theorem listStoredRationalBits_eq
    (A : BooleanListArray (BooleanListArray BitListFraction d) r) :
    listStoredRationalBits A = r+bitRationalMatrixSize (ioMatrixVector A) := by
  simp only [listStoredRationalBits,booleanListArray_data_eq_ofFn,List.map_ofFn,
    List.sum_ofFn,bitRationalMatrixSize,ioMatrixVector,get_ofFn,Function.comp_apply]
  simp only [Finset.sum_add_distrib,Finset.sum_const,Finset.card_univ,
    Fintype.card_fin,nsmul_eq_mul,Nat.mul_one,Nat.cast_id]
  omega

theorem listStoredRationalBits_cell
    (A : BooleanListArray (BooleanListArray BitListFraction d) r) (i : Fin r) (j : Fin d) :
    (((ioMatrixVector A).get i).get j).numerator.length ≤ listStoredRationalBits A ∧
      (((ioMatrixVector A).get i).get j).denominator.length ≤ listStoredRationalBits A := by
  have h := bitRationalMatrixSize_cell (ioMatrixVector A) i j
  rw [listStoredRationalBits_eq]
  omega

theorem listStoredRationalBits_rank
    (A : BooleanListArray (BooleanListArray BitListFraction d) r) :
    r ≤ listStoredRationalBits A := by
  rw [listStoredRationalBits_eq]
  omega

/-- One polynomial for actual clearing, including traversal and deep copying. -/
noncomputable def listStoredInputPolynomial : Polynomial ℕ :=
  let X := Polynomial.X
  128*(X*X+X+1)*((X*X+1)*(X+1)+1)^2

theorem listStoredClearRationalInputWork_input_size
    (A : BooleanListArray (BooleanListArray BitListFraction r) r)
    (hWF : ∀ i j, (((ioMatrixVector A).get i).get j).WellFormed) :
    listStoredClearRationalInputWork A ≤
      listStoredInputPolynomial.eval (listStoredRationalBits A) := by
  have hr := listStoredRationalBits_rank A
  apply (listStoredClearRationalInputWork_bound A (listStoredRationalBits A)
    (listStoredRationalBits_cell A) (fun i j => (hWF i j).2.2.1)).trans
  simp only [listStoredInputPolynomial,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_pow,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat]
  gcongr

/-- A single polynomial for copying and normalizing the actual reduced output. -/
noncomputable def listStoredOutputPolynomial : Polynomial ℕ :=
  let X := Polynomial.X
  let O := (X*(X+1)+1)*(X+X+2*((X*X+1)*X+2)+4)+X*X*X+1
  144*(X*X+X+1)*(O+1)^3

/-- The generic list-output adapter inherits the size bounds of an exact
encoded reduction result. Final algorithm correctness discharges `hB`. -/
theorem listStoredUnscaleWork_of_reduction
    (A : BooleanListArray (BooleanListArray BitListFraction r) r)
    (hWF : ∀ i j, (((ioMatrixVector A).get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows (ioMatrixVector A) i j : ℝ)))
    (B : BooleanListArray (BooleanListArray BitListInteger r) r)
    (hB : ioMatrixVector B =
      (encodedIntegerReduction (bitListClearRationalInput (ioMatrixVector A)).2).rows) :
    listStoredUnscaleWork (listStoredInputDenominator A) B ≤
      listStoredOutputPolynomial.eval (listStoredRationalBits A) := by
  let N := listStoredRationalBits A
  have hr : r ≤ N := listStoredRationalBits_rank A
  have hrs : r.size ≤ N := (Nat.size_le.mpr Nat.lt_two_pow_self).trans hr
  have hlen := encodedRationalUnscale_operand_lengths (ioMatrixVector A) hWF hA
    N (listStoredRationalBits_cell A)
  dsimp only at hlen
  have hp : 0 < binaryDigitsValue (listStoredInputDenominator A) := by
    rw [listStoredInputDenominator_eq]
    exact bitRationalInputDenominator_positive _ (fun i j => (hWF i j).2.2.1)
  have hD : (listStoredInputDenominator A).length ≤ rationalOutputUnscaleBits r r N := by
    rw [listStoredInputDenominator_eq]
    exact hlen.1
  have hrows : ∀ i j, (((ioMatrixVector B).get i).get j).digits.length ≤
      rationalOutputUnscaleBits r r N := by
    rw [hB]
    exact hlen.2
  apply (listStoredUnscaleWork_bound _ B (rationalOutputUnscaleBits r r N)
    hp hD hrows).trans
  simp only [listStoredOutputPolynomial,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_pow,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat]
  unfold rationalOutputUnscaleBits
  change _ ≤ 144*(N*N+N+1)*
    ((N*(N+1)+1)*(N+N+2*((N*N+1)*N+2)+4)+N*N*N+1+1)^3
  gcongr

end Optss
