import Optss.ListStoredWork

/-! Uniform costs of concrete list accesses and bounded-index control. -/
namespace Optss
variable {r d : ℕ}

/-- One uniform dimension factor for array and control operations. -/
def listStorageFactor (r d : ℕ) : ℕ := 2048*(r+d+1)^4

theorem listStorageFactor_pos (r d : ℕ) : 0 < listStorageFactor r d := by
  unfold listStorageFactor
  positivity

theorem listMatrixAccessBound_payload (r d B : ℕ) :
    listMatrixAccessBound r d (2*B+3) ≤ listStorageFactor r d*(B+1) := by
  have h := listMatrixAccessBound_le r d (2*B+3)
  unfold listStorageFactor
  exact h.trans (by nlinarith)

theorem listFractionReadWork_le (A : ListBitRationalMatrixData r d) (i : Fin r) (j : Fin d)
    (B : ℕ) (hB : ∀ a b,fractionPayload (((listMatrixVector A).get a).get b) ≤ B) :
    listMatrixReadWork listCopyFraction listCopyFractionWork A i j ≤ listStorageFactor r d*(B+1) := by
  apply (listMatrixReadWork_le _ listCopyFraction_eq _ A i j (2*B+3) ?_).trans
    (listMatrixAccessBound_payload r d B)
  intro a b
  rw [listCopyFractionWork_eq]
  exact Nat.add_le_add_right (Nat.mul_le_mul_left 2 (hB a b)) 3

theorem listIntegerReadWork_le (A : ListBitIntegerMatrixData r d) (i : Fin r) (j : Fin d)
    (B : ℕ) (hB : ∀ a b,integerPayload (((listMatrixVector A).get a).get b) ≤ B) :
    listMatrixReadWork listCopyInteger listCopyIntegerWork A i j ≤ listStorageFactor r d*(B+1) := by
  apply (listMatrixReadWork_le _ listCopyInteger_eq _ A i j (2*B+3) ?_).trans
    (listMatrixAccessBound_payload r d B)
  intro a b
  rw [listCopyIntegerWork_eq]
  have h := hB a b
  omega

theorem listFractionWriteWork_le (A : ListBitRationalMatrixData r d) (i : Fin r)
    (row : BooleanListArray BitListFraction d) (B : ℕ)
    (hB : ∀ a b,fractionPayload (((listMatrixVector A).get a).get b) ≤ B)
    (hr : ∀ b,fractionPayload (row.toVector.get b) ≤ B) :
    listMatrixWriteWork listCopyFractionWork A i row ≤ listStorageFactor r d*(B+1) := by
  apply (listMatrixWriteWork_le _ A i row (2*B+3) ?_ ?_).trans (listMatrixAccessBound_payload r d B)
  · intro a b
    rw [listCopyFractionWork_eq]
    exact Nat.add_le_add_right (Nat.mul_le_mul_left 2 (hB a b)) 3
  · intro b
    rw [listCopyFractionWork_eq]
    exact Nat.add_le_add_right (Nat.mul_le_mul_left 2 (hr b)) 3

theorem listIntegerWriteWork_le (A : ListBitIntegerMatrixData r d) (i : Fin r)
    (row : BooleanListArray BitListInteger d) (B : ℕ)
    (hB : ∀ a b,integerPayload (((listMatrixVector A).get a).get b) ≤ B)
    (hr : ∀ b,integerPayload (row.toVector.get b) ≤ B) :
    listMatrixWriteWork listCopyIntegerWork A i row ≤ listStorageFactor r d*(B+1) := by
  apply (listMatrixWriteWork_le _ A i row (2*B+3) ?_ ?_).trans (listMatrixAccessBound_payload r d B)
  · intro a b
    rw [listCopyIntegerWork_eq]
    have h := hB a b
    omega
  · intro b
    rw [listCopyIntegerWork_eq]
    have h := hr b
    omega

theorem listFractionArrayReadWork_le (a : BooleanListArray BitListFraction r) (i : Fin r)
    (B : ℕ) (hB : ∀ j,fractionPayload (a.toVector.get j) ≤ B) :
    a.readWork listCopyFractionWork i ≤ listStorageFactor r d*(B+1) := by
  have h := a.readWork_le listCopyFractionWork i (2*B+3)
    ((a.forall_data_iff (fun q => listCopyFractionWork q ≤ 2*B+3)).mpr (by
      intro j
      rw [listCopyFractionWork_eq]
      exact Nat.add_le_add_right (Nat.mul_le_mul_left 2 (hB j)) 3))
  have hp : (r+1)^2 ≤ (r+d+1)^4 :=
    (Nat.pow_le_pow_left (show r+1≤r+d+1 by omega) 2).trans
      (Nat.pow_le_pow_right (by omega) (by decide : (2:ℕ)≤4))
  unfold listStorageFactor
  exact h.trans (by nlinarith)

theorem listEnumerationWork_factor (n : ℕ) (hn : n≤r+d) :
    listIndexEnumerationWork n ≤ listStorageFactor r d := by
  have hp : (n+1)^3 ≤ (r+d+1)^4 :=
    (Nat.pow_le_pow_left (by omega) 3).trans
      (Nat.pow_le_pow_right (by omega) (by decide : (3:ℕ)≤4))
  exact (listIndexEnumerationWork_le n).trans (by unfold listStorageFactor; omega)

theorem bitUnaryAddressWork_factor (n : ℕ) (hn : n≤r+d) :
    bitUnaryAddressWork n ≤ listStorageFactor r d := by
  have hp : (n+1)^2 ≤ (r+d+1)^4 :=
    (Nat.pow_le_pow_left (by omega) 2).trans
      (Nat.pow_le_pow_right (by omega) (by decide : (2:ℕ)≤4))
  exact (bitUnaryAddressWork_le n).trans (by unfold listStorageFactor; omega)

theorem bitIndex_controls_factor (i j : Fin r) :
    bitIndexLEWork i j ≤ listStorageFactor r d ∧
    bitIndexEQWork i j ≤ listStorageFactor r d ∧
    bitIndexLTWork i j ≤ listStorageFactor r d ∧
    bitIndexAdjacentWork i j ≤ listStorageFactor r d := by
  have hp : (r+r+1)^2 ≤ 4*(r+d+1)^4 := by
    have h₁ : r+r+1≤2*(r+d+1) := by omega
    have h₂ := Nat.pow_le_pow_left h₁ 2
    have h₃ : (r+d+1)^2 ≤ (r+d+1)^4 := Nat.pow_le_pow_right (by omega) (by decide)
    nlinarith
  have h₁ := bitIndexLEWork_le i j
  have h₂ := bitIndexEQWork_le i j
  have h₃ := bitIndexLTWork_le i j
  have h₄ := bitIndexAdjacentWork_le i j
  unfold listStorageFactor
  omega

end Optss
