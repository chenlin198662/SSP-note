import Optss.PackedConvolution

/-!
# Sequential extraction of packed coefficient digits

The recursion removes the least significant digit once per step. It avoids
recomputing a power and a division from the full packed integer separately for
every coefficient. Theorems count extraction steps, not bit-operation costs.
-/

namespace Optss

/-- Extract exactly `n` base-`b` digits, least significant first. -/
def unpackDigits (b : ℕ) : ℕ → ℕ → List ℕ
  | 0, _ => []
  | n+1, z => z % b :: unpackDigits b n (z / b)

@[simp] theorem unpackDigits_length (b n z : ℕ) : (unpackDigits b n z).length = n := by
  induction n generalizing z with
  | zero => rfl
  | succ n ih => simp [unpackDigits, ih]

/-- Each entry is the corresponding digit of the original packed integer. -/
theorem unpackDigits_getD (b n z i : ℕ) (hi : i < n) :
    (unpackDigits b n z).getD i 0 = z / b ^ i % b := by
  induction n generalizing z i with
  | zero => omega
  | succ n ih =>
    cases i with
    | zero => simp [unpackDigits]
    | succ i =>
      simp only [unpackDigits, List.getD_cons_succ]
      rw [ih (z/b) i (by omega), Nat.div_div_eq_div_mul, pow_succ']

/-- Polynomial coefficients are recovered by the sequential digit loop. -/
theorem unpackDigits_polynomial (p : Polynomial ℕ) (b n : ℕ)
    (hb : 0 < b) (hcoeff : ∀ i, p.coeff i < b) (i : ℕ) (hi : i < n) :
    (unpackDigits b n (p.eval b)).getD i 0 = p.coeff i := by
  rw [unpackDigits_getD b n _ i hi, polynomial_coeff_eq_packed_digit p b hb hcoeff]

/-- The digit loop performs one division/remainder pair for every emitted cell. -/
def unpackSteps : ℕ → ℕ
  | 0 => 0
  | n+1 => unpackSteps n + 1

@[simp] theorem unpackSteps_eq (n : ℕ) : unpackSteps n = n := by
  induction n with
  | zero => rfl
  | succ n ih => simp [unpackSteps, ih]

end Optss
