import Optss.BohrPhaseLattice

/-! Pigeonhole density of short integer vectors in the actual phase lattice. -/
namespace Optss
noncomputable section
open scoped BigOperators Pointwise
open Classical
variable {N r : ℕ} [NeZero N]

def phaseResidueVector (a : Fin r → ZMod N) (x : ZMod N) : IntVec r :=
  fun j => ((a j*x).val : ℤ)

theorem phaseResidueVector_mem (a : Fin r → ZMod N) (base : Fin r) (ha : a base=1)
    (x : ZMod N) : phaseResidueVector a x∈cyclicPhaseLattice a base := by
  intro j
  simp only [phaseResidueVector,Int.cast_natCast,ZMod.natCast_zmod_val,ha,one_mul]

/-- Sixteen bins per coordinate, each of diameter at most floor(N/16). -/
def phaseBin (a : Fin r → ZMod N) (x : ZMod N) : Fin r → Fin 16 := fun j =>
  ⟨(a j*x).val/(N/16+1),by
    apply (Nat.div_lt_iff_lt_mul (by omega : 0<N/16+1)).mpr
    have hmod := Nat.mod_lt N (by decide : 0<16)
    have hdiv := Nat.mod_add_div N 16
    have hv := (a j*x).val_lt
    omega⟩

theorem same_phaseBin_difference_small (a : Fin r → ZMod N) (x y : ZMod N)
    (h : phaseBin a x=phaseBin a y) (j : Fin r) :
    |phaseResidueVector a x j-phaseResidueVector a y j|≤(N/16 : ℕ) := by
  have he := congrArg Fin.val (congrFun h j)
  change (a j*x).val/(N/16+1)=(a j*y).val/(N/16+1) at he
  have hx := Nat.mod_add_div (a j*x).val (N/16+1)
  have hy := Nat.mod_add_div (a j*y).val (N/16+1)
  have hxm := Nat.mod_lt (a j*x).val (by omega : 0<N/16+1)
  have hym := Nat.mod_lt (a j*y).val (by omega : 0<N/16+1)
  rw [he] at hx
  simp only [phaseResidueVector,abs_le]
  omega

def phaseLatticeCube (a : Fin r → ZMod N) (base : Fin r) (M : ℕ) : Finset (IntVec r) :=
  (integerBudgetBox (fun _ => M)).filter fun z => z∈cyclicPhaseLattice a base

/-- The small phase cube contains at least N/16^r lattice points. This remains
valid for N<16, when its only point can be zero. -/
theorem phaseLatticeCube_density (a : Fin r → ZMod N) (base : Fin r) (ha : a base=1) :
    N≤16^r*(phaseLatticeCube a base (N/16)).card := by
  have hpow : (0 : ℝ)<(16 : ℝ)^r := by positivity
  have hN : (0 : ℝ)<N := Nat.cast_pos.mpr (NeZero.pos N)
  obtain ⟨tag,htag⟩ := Fintype.exists_le_card_fiber_of_nsmul_le_card (phaseBin a)
    (b := (N : ℝ)/(16 : ℝ)^r) (by
      simp only [Fintype.card_fun,Fintype.card_fin,ZMod.card,nsmul_eq_mul,Nat.cast_pow,Nat.cast_ofNat]
      exact le_of_eq (mul_div_cancel₀ _ (ne_of_gt hpow)))
  let T : Finset (ZMod N) := Finset.univ.filter fun x => phaseBin a x=tag
  have hT : 0<T.card := by
    have hp : 0<(T.card : ℝ) := (div_pos hN hpow).trans_le htag
    exact Nat.cast_pos.mp hp
  obtain ⟨anchor,hanchor⟩ := Finset.card_pos.mp hT
  let f : ZMod N → IntVec r := fun x => phaseResidueVector a x-phaseResidueVector a anchor
  have hinj : Function.Injective f := by
    intro x y h
    have he := congrFun h base
    change phaseResidueVector a x base-phaseResidueVector a anchor base=
      phaseResidueVector a y base-phaseResidueVector a anchor base at he
    have he' : phaseResidueVector a x base=phaseResidueVector a y base := by omega
    simp only [phaseResidueVector,ha,one_mul] at he'
    apply ZMod.val_injective N
    exact_mod_cast he'
  have hsub : T.image f⊆phaseLatticeCube a base (N/16) := by
    intro z hz
    obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp hz
    change f x∈(integerBudgetBox (fun _ => N/16)).filter (fun z => z∈cyclicPhaseLattice a base)
    apply Finset.mem_filter.mpr
    refine ⟨?_,(cyclicPhaseLattice a base).sub_mem (phaseResidueVector_mem a base ha x)
      (phaseResidueVector_mem a base ha anchor)⟩
    rw [mem_integerBudgetBox]
    intro j
    exact same_phaseBin_difference_small a x anchor
      ((Finset.mem_filter.mp hx).2.trans (Finset.mem_filter.mp hanchor).2.symm) j
  have hcard : T.card≤(phaseLatticeCube a base (N/16)).card := by
    rw [← Finset.card_image_of_injective T hinj]
    exact Finset.card_le_card hsub
  have hreal : (N : ℝ)≤(16 : ℝ)^r*T.card := by
    have h := (div_le_iff₀ hpow).mp htag
    simpa only [mul_comm] using h
  have hnat : N≤16^r*T.card := by exact_mod_cast hreal
  exact hnat.trans (Nat.mul_le_mul_left _ hcard)

end
end Optss
