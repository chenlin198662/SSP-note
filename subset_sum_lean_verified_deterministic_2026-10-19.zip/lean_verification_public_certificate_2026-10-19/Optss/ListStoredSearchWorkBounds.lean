import Optss.ListStoredGSWorkBounds
import Optss.ListStoredIntegerWorkBounds

/-! Concrete list storage costs for Lovász tests, pair search, and swaps. -/
namespace Optss
open scoped BigOperators
variable {r d : ℕ}

theorem listStoredFailingPairs_length (D : ListBitIntegerMatrixData r d) :
    (listStoredFailingPairs D).length ≤ r*r := by
  unfold listStoredFailingPairs
  dsimp only
  rw [List.length_flatMap]
  calc
    _ ≤ ((List.ofFn (id : Fin r → Fin r)).map fun _ => r).sum := by
      apply List.sum_le_sum
      intro n hn
      simp only [List.mem_ofFn] at hn
      obtain ⟨i,rfl⟩ := hn
      exact (List.length_filter_le _ _).trans (by simp)
    _ = r*r := by simp

theorem listDotStorageWork_uniform (u v : Fin d → ℕ) (B : ℕ)
    (hu : ∀ i,u i≤listStorageFactor r d*(B+1))
    (hv : ∀ i,v i≤listStorageFactor r d*(B+1)) :
    listDotStorageWork u v ≤ (5*d+3)*listStorageFactor r d*(B+1) := by
  let V := listStorageFactor r d*(B+1)
  have hF : 1 ≤ listStorageFactor r d := listStorageFactor_pos r d
  have hV : 1≤V := by dsimp [V]; nlinarith
  have hFV : listStorageFactor r d≤V := by dsimp [V]; nlinarith
  have h := listProductStorageWork_le u v (List.ofFn id) V V
    (fun i _ => hu i) (fun i _ => hv i)
  simp only [List.length_ofFn] at h
  have he := listEnumerationWork_factor (r:=r) (d:=d) d (by omega)
  unfold listDotStorageWork
  rw [Nat.mul_assoc]
  change _≤(5*d+3)*V
  nlinarith

theorem listStoredLovaszPairStorageWork_bound (A T : ListBitRationalMatrixData r d)
    (j k : Fin r) (B : ℕ)
    (hA : ∀ i l,fractionPayload (((listMatrixVector A).get i).get l)≤B)
    (hT : ∀ i l,fractionPayload (((listMatrixVector T).get i).get l)≤B) :
    listStoredLovaszPairStorageWork A T j k ≤
      65536*(r+d+1)^6*(B+encodedLovaszPairWork (listMatrixVector A) (listMatrixVector T) j k+3) := by
  let S := r+d+1
  let W := encodedLovaszPairWork (listMatrixVector A) (listMatrixVector T) j k
  have hS : 1≤S := by dsimp [S]; omega
  have hd : d≤S := by dsimp [S]; omega
  have hread (i : Fin r) (l : Fin d) := listFractionReadWork_le T i l B hT
  have hk := listDotStorageWork_uniform (r:=r)
    (listMatrixReadWork listCopyFraction listCopyFractionWork T k)
    (listMatrixReadWork listCopyFraction listCopyFractionWork T k) B (hread k) (hread k)
  have hj := listDotStorageWork_uniform (r:=r)
    (listMatrixReadWork listCopyFraction listCopyFractionWork T j)
    (listMatrixReadWork listCopyFraction listCopyFractionWork T j) B (hread j) (hread j)
  have hg := listStoredGsCoefficientStorageWork_bound A T k j B hA hT
  have hmu := encodedGsCoefficient_output_le_work (listMatrixVector A) (listMatrixVector T) k j
  have hnj := encodedRationalDot_output_le_work
    (((listMatrixVector T).get j).get) (((listMatrixVector T).get j).get)
  have hmuw : encodedGsCoefficientWork (listMatrixVector A) (listMatrixVector T) k j≤W := by
    unfold W encodedLovaszPairWork
    dsimp only
    omega
  have hnjw : encodedRationalDotWork (((listMatrixVector T).get j).get)
      (((listMatrixVector T).get j).get)≤W := by
    unfold W encodedLovaszPairWork
    dsimp only
    omega
  have hcopyMu : listCopyFractionWork (listStoredGsCoefficient A T k j) ≤ 2*W+3 := by
    rw [listStoredGsCoefficient_eq,listCopyFractionWork_eq]
    exact Nat.add_le_add_right (Nat.mul_le_mul_left 2 (hmu.trans hmuw)) 3
  have hcopyNj : listCopyFractionWork (encodedRationalDot
      (listMatrixRead listCopyFraction T j) (listMatrixRead listCopyFraction T j)) ≤ 2*W+5 := by
    rw [listMatrixRead_fun _ listCopyFraction_eq,listCopyFractionWork_eq]
    change 2*((encodedRationalDot _ _).numerator.length+
      (encodedRationalDot _ _).denominator.length)+3≤_
    omega
  have hpower : S^5≤S^6 := Nat.pow_le_pow_right hS (by omega)
  have hpow : 1≤S^6 := one_le_pow₀ hS
  have hdot : (5*d+3)*listStorageFactor r d*(B+1) ≤ 16384*S^6*(B+1) := by
    calc
      _ ≤ (8*S)*(2048*S^4)*(B+1) := by
        change (5*d+3)*(2048*S^4)*(B+1)≤_
        gcongr
        omega
      _ = 16384*S^5*(B+1) := by ring
      _ ≤ _ := by gcongr
  unfold listStoredLovaszPairStorageWork
  dsimp only
  change _≤65536*S^6*(B+W+3)
  have hg' : listStoredGsCoefficientStorageWork A T k j ≤ 8192*S^6*(B+2) :=
    hg.trans (by change 8192*S^5*(B+2)≤_; gcongr)
  nlinarith

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

theorem listStoredBooleanSwapRowsStorageWork_bound (D : ListBitIntegerMatrixData r d)
    (j k : Fin r) (B : ℕ)
    (hB : ∀ i l,integerPayload (((listMatrixVector D).get i).get l)≤B) :
    listStoredBooleanSwapRowsStorageWork D j k ≤
      (4*r+1)*listStorageFactor r d*(B+1) := by
  let F := listStorageFactor r d
  have hF : 2048≤F := listStorageFactor_ge_2048 r d
  have hrows : ∀ row ∈ D.data, ∀ z ∈ row.data,listCopyIntegerWork z≤2*B+3 := by
    apply (BooleanListArray.forall_data_iff D
      (fun row => ∀ z ∈ row.data,listCopyIntegerWork z≤2*B+3)).mpr
    intro i
    apply (BooleanListArray.forall_data_iff _ (fun z => listCopyIntegerWork z≤2*B+3)).mpr
    intro l
    have hh := hB i l
    simp only [listMatrixVector,get_ofFn] at hh
    rw [listCopyIntegerWork_eq]
    omega
  have hread (i : Fin r) : D.readWork (BooleanListArray.copyWork listCopyIntegerWork) i≤F*(B+1) := by
    have hh := D.readWork_le (BooleanListArray.copyWork listCopyIntegerWork) i
      (d*((2*B+3)+2)+1) (fun row hr => row.copyWork_le _ _ (hrows row hr))
    have hb : 64*(r+1)^2*(d*((2*B+3)+2)+1+1) ≤ listMatrixAccessBound r d (2*B+3) := by
      unfold listMatrixAccessBound
      simp only [Nat.add_assoc,Nat.reduceAdd]
      omega
    exact hh.trans (hb.trans (listMatrixAccessBound_payload r d B))
  have hper (i : Fin r) : bitIndexEQWork i j+bitIndexEQWork i k+
      D.readWork (BooleanListArray.copyWork listCopyIntegerWork)
        (if bitIndexEQ i j then k else if bitIndexEQ i k then j else i)+2≤4*F*(B+1) := by
    have hj := (bitIndex_controls_factor (d:=d) i j).2.1
    have hk := (bitIndex_controls_factor (d:=d) i k).2.1
    have hr := hread (if bitIndexEQ i j then k else if bitIndexEQ i k then j else i)
    change bitIndexEQWork i j≤F at hj
    change bitIndexEQWork i k≤F at hk
    nlinarith
  have hs : (∑ i : Fin r,(bitIndexEQWork i j+bitIndexEQWork i k+
      D.readWork (BooleanListArray.copyWork listCopyIntegerWork)
        (if bitIndexEQ i j then k else if bitIndexEQ i k then j else i)+2)) ≤ r*(4*F*(B+1)) := by
    calc
      _ ≤ ∑ _i : Fin r,4*F*(B+1) := Finset.sum_le_sum fun i _ => hper i
      _ = _ := by simp
  have he := listEnumerationWork_factor (r:=r) (d:=d) r (by omega)
  change listIndexEnumerationWork r≤F at he
  unfold listStoredBooleanSwapRowsStorageWork
  change _≤(4*r+1)*F*(B+1)
  nlinarith

set_option maxHeartbeats 800000 in
theorem listStoredFailingPairsStorageWork_bound (D : ListBitIntegerMatrixData r d)
    (B : ℕ) (hB : ∀ i l,integerPayload (((listMatrixVector D).get i).get l)≤B) :
    listStoredFailingPairsStorageWork D ≤
      16777216*(r+d+1)^12*(B+encodedFailingAdjacentPairsWork (listMatrixVector D)+3) := by
  let S := r+d+1
  let F := listStorageFactor r d
  let Q := listStoredRationalIntegerRows D
  let T := listStoredGSTable Q r le_rfl
  let wt := encodedGSTableWork (listMatrixVector Q) r le_rfl
  let W := encodedFailingAdjacentPairsWork (listMatrixVector D)
  let X := B+W+3
  let U := S^12*X
  have hS : 1≤S := by dsimp [S]; omega
  have hX : 1≤X := by dsimp [X]; omega
  have hr : r≤S := by dsimp [S]; omega
  have hd : d≤S := by dsimp [S]; omega
  have hr1 : r+1≤S := by dsimp [S]; omega
  have hF : 1≤F := listStorageFactor_pos r d
  have hFdim : r+d+1≤F := listStorageFactor_ge_dim r d
  have htotal : W = wt+∑ j : Fin r, ∑ k : Fin r,
      if k.val=j.val+1 then encodedLovaszPairWork (listMatrixVector Q) (listMatrixVector T) j k else 0 := by
    simp only [W,wt,T,Q,encodedFailingAdjacentPairsWork,listStoredGSTable_eq,
      listStoredRationalIntegerRows_eq]
  have hwt : wt≤W := by rw [htotal]; omega
  have hpair (j k : Fin r) (ha : k.val=j.val+1) :
      encodedLovaszPairWork (listMatrixVector Q) (listMatrixVector T) j k ≤ W := by
    let f : Fin r → Fin r → ℕ := fun j k =>
      if k.val=j.val+1 then encodedLovaszPairWork (listMatrixVector Q) (listMatrixVector T) j k else 0
    have hk := Finset.single_le_sum (f:=f j) (fun _ _ => Nat.zero_le _) (Finset.mem_univ k)
    have hj := Finset.single_le_sum (f:=fun j => ∑ k,f j k)
      (fun _ _ => Nat.zero_le _) (Finset.mem_univ j)
    have hh : f j k≤∑ j,∑ k,f j k := hk.trans hj
    simp only [f,ha,if_true] at hh
    rw [htotal]
    exact hh.trans (Nat.le_add_left _ _)
  have hQ : ∀ i l,fractionPayload (((listMatrixVector Q).get i).get l)≤B+1 :=
    listStoredRationalIntegerRows_payload D B hB
  have hT : ∀ i l,fractionPayload (((listMatrixVector T).get i).get l)≤1+wt := by
    intro i l
    dsimp only [T]
    rw [listStoredGSTable_eq]
    exact encodedGSTable_output_le_work _ r _ i l
  have hpc (j k : Fin r) : (if bitIndexAdjacent j k then
      listStoredLovaszPairStorageWork Q T j k else 1) ≤ 131072*S^6*X := by
    split_ifs with ha
    · have hw := hpair j k ((bitIndexAdjacent_correct j k).mp ha)
      have hh := listStoredLovaszPairStorageWork_bound Q T j k (B+wt+1)
        (fun i l => (hQ i l).trans (by omega))
        (fun i l => (hT i l).trans (by omega))
      apply hh.trans
      change 65536*S^6*(B+wt+1+_+3)≤_
      have hx : B+wt+1+encodedLovaszPairWork (listMatrixVector Q) (listMatrixVector T) j k+3≤2*X := by
        dsimp [X]
        omega
      exact (Nat.mul_le_mul_left (65536*S^6) hx).trans_eq (by ring)
    · have hp := one_le_pow₀ hS (n:=6)
      nlinarith
  have hF6 : F≤2048*S^6 := by
    dsimp [F,listStorageFactor]
    exact Nat.mul_le_mul_left 2048 (Nat.pow_le_pow_right hS (by omega))
  have hcell (j k : Fin r) : bitIndexAdjacentWork j k+
      (if bitIndexAdjacent j k then listStoredLovaszPairStorageWork Q T j k else 1)+
        4*(r+1)+3 ≤ 262144*S^6*X := by
    have hi := (bitIndex_controls_factor (d:=d) j k).2.2.2
    change bitIndexAdjacentWork j k≤F at hi
    have hp := hpc j k
    have hdim : r+1≤F := by omega
    nlinarith
  have hsum : (∑ j : Fin r, ∑ k : Fin r,(bitIndexAdjacentWork j k+
      (if bitIndexAdjacent j k then listStoredLovaszPairStorageWork Q T j k else 1)+
        4*(r+1)+3)) ≤ 262144*U := by
    calc
      _ ≤ ∑ _j : Fin r,∑ _k : Fin r,262144*S^6*X :=
        Finset.sum_le_sum fun j _ => Finset.sum_le_sum fun k _ => hcell j k
      _ = r*r*(262144*S^6*X) := by simp; ring
      _ ≤ S*S*(262144*S^6*X) := by gcongr
      _ = 262144*S^8*X := by ring
      _ ≤ 262144*U := by
        dsimp [U]
        rw [← Nat.mul_assoc]
        exact Nat.mul_le_mul_right X (Nat.mul_le_mul_left _
          (Nat.pow_le_pow_right hS (by omega)))
  have htable : listStoredGSTableStorageWork Q r le_rfl≤262144*U := by
    apply (listStoredGSTableStorageWork_bound Q r le_rfl (B+1) hQ).trans
    change 262144*S^8*(B+1+wt+2)≤_
    dsimp [U]
    rw [← Nat.mul_assoc]
    exact Nat.mul_le_mul (Nat.mul_le_mul_left _
      (Nat.pow_le_pow_right hS (by omega : 8≤12))) (by dsimp [X]; omega)
  have hemb : listStoredRationalIntegerRowsStorageWork D≤12288*U := by
    apply (listStoredRationalIntegerRowsStorageWork_le D B hB).trans
    have hdim : 4*r*d+r+1≤6*S^2 := by nlinarith
    calc
      _ ≤ (6*S^2)*(2048*S^4)*X := by
        change (4*r*d+r+1)*(2048*S^4)*(B+1)≤_
        gcongr
        dsimp [X]; omega
      _ = 12288*S^6*X := by ring
      _ ≤ 12288*U := by
        dsimp [U]
        rw [← Nat.mul_assoc]
        exact Nat.mul_le_mul_right X (Nat.mul_le_mul_left _
          (Nat.pow_le_pow_right hS (by omega)))
  have he := listEnumerationWork_factor (r:=r) (d:=d) r (by omega)
  have hen : (r+1)*listIndexEnumerationWork r≤2048*U := by
    calc
      _ ≤ S*(2048*S^4) := by change _≤S*F; gcongr
      _ = 2048*S^5 := by ring
      _ ≤ 2048*U := by
        dsimp [U]
        apply Nat.mul_le_mul_left
        exact (Nat.pow_le_pow_right hS (by omega : 5≤12)).trans (Nat.le_mul_of_pos_right _ hX)
  unfold listStoredFailingPairsStorageWork
  change listStoredRationalIntegerRowsStorageWork D+listStoredGSTableStorageWork Q r le_rfl+
    listIndexEnumerationWork r+(∑ j : Fin r,(listIndexEnumerationWork r+
      ∑ k : Fin r,(bitIndexAdjacentWork j k+
        (if bitIndexAdjacent j k then listStoredLovaszPairStorageWork Q T j k else 1)+
        4*(r+1)+3)))≤16777216*S^12*X
  rw [Finset.sum_add_distrib]
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,Nat.cast_id]
  calc
    _ ≤ (12288+262144+2048+262144)*U := by nlinarith only [hemb,htable,hen,hsum]
    _ ≤ 16777216*U := Nat.mul_le_mul_right U (by norm_num)
    _ = 16777216*S^12*X := by dsimp [U]; ring

end Optss
