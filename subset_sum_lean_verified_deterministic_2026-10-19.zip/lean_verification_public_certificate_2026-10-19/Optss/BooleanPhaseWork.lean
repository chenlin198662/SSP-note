import Optss.BooleanArctanWork

/-! Work for the Boolean rational phase constructor, including its computed
π approximation. No transcendental constant is supplied by an oracle. -/
namespace Optss
open scoped BigOperators
set_option maxRecDepth 4096
set_option maxHeartbeats 800000

def piWorkBits (n : ℕ) : ℕ := 4096*(n+1)^2

theorem piWorkBits_bounds (n : ℕ) :
    arctanWorkBits 3 n≤piWorkBits n ∧
    2*(arctanPartialHeight 3 n).size+2≤piWorkBits n ∧ 5≤piWorkBits n := by
  have hh := arctanPartialHeight_bits 3 n
  have hthree : (3 : ℕ).size=2 := by
    have hle := Nat.size_le.mpr (by decide : 3<2^2)
    have hlt := Nat.lt_size.mpr (by decide : 2^1≤3)
    omega
  have hs := nat_size_le_value (4*n+1)
  rw [hthree] at hh
  have hm := Nat.mul_le_mul_left (2*n) hs
  dsimp [piWorkBits,arctanWorkBits]
  rw [hthree]
  constructor
  · nlinarith
  constructor <;> nlinarith

theorem fourierNat_bits_small (n L : ℕ) (hn : n≤4) (hL : 5≤L) :
    RationalBitBound (FourierFraction.nat n).value L := by
  rw [FourierFraction.nat_value]
  exact (RationalSizeBound.natCast n 5 (by omega) (by omega)).bitBound.mono
    ((nat_size_le_value 5).trans hL)

theorem bitPiApproximationWork_bound (n : ℕ) :
    bitPiApproximationWork n≤262144*(n+1)^2*(piWorkBits n+1)^3 := by
  let L := piWorkBits n
  let U := 2048*(L+1)^3
  let one := FourierFraction.nat 1
  let two := FourierFraction.nat 2
  let three := FourierFraction.nat 3
  let four := FourierFraction.nat 4
  let a := bitArctanPartial (one.div two) n
  let b := bitArctanPartial (one.div three) n
  have hL : 5≤L := (piWorkBits_bounds n).2.2
  have hU : 1603≤U := by
    have hp : 0<(L+1)^3 := by positivity
    dsimp [U]; omega
  have hc (i : ℕ) (hi : i≤4) : RationalBitBound (FourierFraction.nat i).value L :=
    fourierNat_bits_small i L hi hL
  have hdiv2 := one.divWork_bound two L (hc 1 (by omega)) (hc 2 (by omega))
  have hdiv3 := one.divWork_bound three L (hc 1 (by omega)) (hc 3 (by omega))
  have hx2 : RationalSizeBound (one.div two).value 3 := by
    norm_num [one,two,FourierFraction.div_value,FourierFraction.nat_value,RationalSizeBound]
  have hx3 : RationalSizeBound (one.div three).value 3 := by
    norm_num [one,three,FourierFraction.div_value,FourierFraction.nat_value,RationalSizeBound]
  have ha : RationalSizeBound a.value (arctanPartialHeight 3 n) := by
    rw [bitArctanPartial_value]
    exact rationalArctanPartialSum_height _ 3 n hx2 (Finset.range (2*n)) (by rfl)
  have hb : RationalSizeBound b.value (arctanPartialHeight 3 n) := by
    rw [bitArctanPartial_value]
    exact rationalArctanPartialSum_height _ 3 n hx3 (Finset.range (2*n)) (by rfl)
  have habits : (arctanPartialHeight 3 n).size≤L := by
    have := (piWorkBits_bounds n).2.1
    dsimp [L]; omega
  have hsum : RationalBitBound (a.add b).value L := by
    rw [FourierFraction.add_value]
    apply (ha.add hb).bitBound.mono
    have h1 := nat_mul_size_le 2 (arctanPartialHeight 3 n)
    have h2 := nat_mul_size_le (2*arctanPartialHeight 3 n) (arctanPartialHeight 3 n)
    have ht : (2 : ℕ).size≤2 := Nat.size_le.mpr (by decide)
    have h := (piWorkBits_bounds n).2.1
    dsimp [L]; omega
  have hadd := a.addWork_bound b L (ha.bitBound.mono habits) (hb.bitBound.mono habits)
  have hmul := four.mulWork_bound (a.add b) L (hc 4 (by omega)) hsum
  have hpa := bitArctanPartialWork_bound (one.div two) 3 n hx2
  have hpb := bitArctanPartialWork_bound (one.div three) 3 n hx3
  have hpow := Nat.pow_le_pow_left (Nat.add_le_add_right (piWorkBits_bounds n).1 1) 3
  have hpa' : bitArctanPartialWork (one.div two) n≤32*(n+1)^2*U := by
    apply hpa.trans
    have h := Nat.mul_le_mul_left (65536*(n+1)^2) hpow
    dsimp [U,L]; nlinarith
  have hpb' : bitArctanPartialWork (one.div three) n≤32*(n+1)^2*U := by
    apply hpb.trans
    have h := Nat.mul_le_mul_left (65536*(n+1)^2) hpow
    dsimp [U,L]; nlinarith
  have hcwork (i : ℕ) (hi : i≤4) : fourierNatFractionWork i≤U :=
    (fourierNatFractionWork_bound i).trans (by
      have hpow := Nat.pow_le_pow_left (by omega : i+1≤5) 2
      nlinarith)
  have h1 := hcwork 1 (by omega)
  have h2 := hcwork 2 (by omega)
  have h3 := hcwork 3 (by omega)
  have h4 := hcwork 4 (by omega)
  change _≤U at hdiv2 hdiv3 hadd hmul
  have he : 262144*(n+1)^2*(piWorkBits n+1)^3=128*(n+1)^2*U := by dsimp [U,L]; ring
  rw [he]
  change 2*fourierNatFractionWork 1+fourierNatFractionWork 2+fourierNatFractionWork 3+
    fourierNatFractionWork 4+bitListFractionDivCost one.val two.val+bitListFractionDivCost one.val three.val+
    bitArctanPartialWork (one.div two) n+bitArctanPartialWork (one.div three) n+
    bitListFractionAddCost a.val b.val+bitListFractionMulCost four.val (a.add b).val+1≤_
  have hscale : U≤(n+1)^2*U := Nat.le_mul_of_pos_left _ (by positivity)
  nlinarith


def phaseWorkBits (N p : ℕ) : ℕ := 8192*(N.size+p+70)^2

theorem phaseWorkBits_bounds (N p : ℕ) :
    piWorkBits (p+2)≤phaseWorkBits N p ∧
    (fourierPhaseHeight N p).size≤phaseWorkBits N p ∧
    N.size≤phaseWorkBits N p ∧ 5≤phaseWorkBits N p := by
  have h := fourierPhaseHeight_bits_polynomial N p
  have hp : (p+3)^2≤(N.size+p+70)^2 := Nat.pow_le_pow_left (by omega) 2
  have hZ : 1≤N.size+p+70 := by omega
  have hsquare : N.size+p+70≤(N.size+p+70)^2 := by
    simpa only [pow_two,one_mul] using Nat.mul_le_mul_right (N.size+p+70) hZ
  have hN : N.size≤(N.size+p+70)^2 := (by omega : N.size≤N.size+p+70).trans hsquare
  dsimp [phaseWorkBits,piWorkBits]
  constructor
  · nlinarith
  constructor
  · omega
  constructor <;> nlinarith

theorem bitFourierPhaseAngleWork_bound {N : ℕ} [NeZero N] (x : ZMod N)
    (X M : FourierFraction) (hX : X.value=(x.val : ℚ)) (hM : M.value=(N : ℚ)) (p : ℕ) :
    bitFourierPhaseAngleWork X M p≤524288*(p+3)^2*(phaseWorkBits N p+1)^3 := by
  let L := phaseWorkBits N p
  let U := 2048*(L+1)^3
  let two := FourierFraction.nat 2
  let pi := bitPiApproximation (p+2)
  have hN : 0<N := NeZero.pos N
  have hp : RationalSizeBound pi.value (fourierPiHeight (p+2)) := by
    rw [bitPiApproximation_value]
    exact rationalPiApproximation_height _
  have htwo : RationalSizeBound two.value 2 := by
    norm_num [two,FourierFraction.nat_value,RationalSizeBound]
  have hxx : RationalSizeBound X.value N := by
    rw [hX]; exact RationalSizeBound.natCast _ _ hN x.val_lt.le
  have hmm : RationalSizeBound M.value N := by
    rw [hM]; exact RationalSizeBound.natCast _ _ hN le_rfl
  have hmul : RationalSizeBound (two.mul pi).value (2*fourierPiHeight (p+2)) := by
    rw [FourierFraction.mul_value]; exact htwo.mul hp
  have hmulX : RationalSizeBound ((two.mul pi).mul X).value (2*fourierPiHeight (p+2)*N) := by
    rw [FourierFraction.mul_value]; exact hmul.mul hxx
  have h1 : fourierPiHeight (p+2)≤2*fourierPiHeight (p+2) := by omega
  have h2 : 2*fourierPiHeight (p+2)≤2*fourierPiHeight (p+2)*N := Nat.le_mul_of_pos_right _ hN
  have h3 : 2*fourierPiHeight (p+2)*N≤fourierPhaseHeight N p := Nat.le_mul_of_pos_right _ hN
  have hbits := (phaseWorkBits_bounds N p).2.1
  have hpi : RationalBitBound pi.value L := hp.bitBound.mono ((Nat.size_le_size (h1.trans (h2.trans h3))).trans hbits)
  have hmulbits : RationalBitBound (two.mul pi).value L := hmul.bitBound.mono ((Nat.size_le_size (h2.trans h3)).trans hbits)
  have hmulXbits : RationalBitBound ((two.mul pi).mul X).value L := hmulX.bitBound.mono ((Nat.size_le_size h3).trans hbits)
  have hXbits : RationalBitBound X.value L := hxx.bitBound.mono (phaseWorkBits_bounds N p).2.2.1
  have hMbits : RationalBitBound M.value L := hmm.bitBound.mono (phaseWorkBits_bounds N p).2.2.1
  have htbits := fourierNat_bits_small 2 L (by omega) (phaseWorkBits_bounds N p).2.2.2
  have hm1 := two.mulWork_bound pi L htbits hpi
  have hm2 := (two.mul pi).mulWork_bound X L hmulbits hXbits
  have hd := ((two.mul pi).mul X).divWork_bound M L hmulXbits hMbits
  change _≤U at hm1 hm2 hd
  have hpwork := bitPiApproximationWork_bound (p+2)
  have hpwork' : bitPiApproximationWork (p+2)≤128*(p+3)^2*U := by
    have hpow := Nat.pow_le_pow_left (Nat.add_le_add_right (phaseWorkBits_bounds N p).1 1) 3
    have h := Nat.mul_le_mul_left (262144*(p+3)^2) hpow
    have h' : 262144*(p+3)^2*(piWorkBits (p+2)+1)^3≤128*(p+3)^2*U := by
      dsimp only [U,L]
      nlinarith only [h]
    exact hpwork.trans (by simpa only [show p+2+1=p+3 by omega] using h')
  have htwoWork := fourierNatFractionWork_bound 2
  norm_num at htwoWork
  have hU : 579≤U := by
    have hp : 1≤(L+1)^3 := Nat.one_le_pow 3 (L+1) (by omega)
    have hh := Nat.mul_le_mul_left 2048 hp
    change 579≤2048*(L+1)^3
    omega
  have hscale : U≤(p+3)^2*U := Nat.le_mul_of_pos_left _ (by positivity)
  have he : 524288*(p+3)^2*(phaseWorkBits N p+1)^3=256*(p+3)^2*U := by dsimp [U,L]; ring
  rw [he]
  change fourierNatFractionWork 2+bitPiApproximationWork (p+2)+
    bitListFractionMulCost two.val pi.val+bitListFractionMulCost (two.mul pi).val X.val+
    bitListFractionDivCost ((two.mul pi).mul X).val M.val+1≤_
  nlinarith only [htwoWork,hpwork',hm1,hm2,hd,hU,hscale]

end Optss
