import Optss.IntegerSubgroupBasis

/-!
# Integer synthesis in a basis of a generated lattice

A real basis of the complete image of an integer subgroup induces an injective
integer additive map whose range is exactly that subgroup. This connects the
geometric coefficient box to an actual integer GAP.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {d : ℕ}

theorem exists_subgroup_basis_synthesis (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (z : IntVec d) :
    ∃ x ∈ Γ, realVector x = b.equivFun.symm (realVector z) := by
  apply hΛ ▸ show b.equivFun.symm (realVector z) ∈ basisIntegerLattice b from ?_
  intro j
  refine ⟨z j, ?_⟩
  change b.equivFun (b.equivFun.symm (realVector z)) j = (z j : ℝ)
  rw [LinearEquiv.apply_symm_apply]
  rfl

def subgroupBasisSynthesis (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (z : IntVec d) : IntVec d :=
  (exists_subgroup_basis_synthesis Γ b hΛ z).choose

theorem subgroupBasisSynthesis_mem (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (z : IntVec d) : subgroupBasisSynthesis Γ b hΛ z ∈ Γ :=
  (exists_subgroup_basis_synthesis Γ b hΛ z).choose_spec.1

@[simp] theorem subgroupBasisSynthesis_cast (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (z : IntVec d) :
    realVector (subgroupBasisSynthesis Γ b hΛ z) = b.equivFun.symm (realVector z) :=
  (exists_subgroup_basis_synthesis Γ b hΛ z).choose_spec.2

def subgroupBasisSynthesisHom (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d))) :
    IntVec d →+ IntVec d where
  toFun := subgroupBasisSynthesis Γ b hΛ
  map_zero' := by
    apply realVector_is_injective
    rw [subgroupBasisSynthesis_cast, map_zero, map_zero]
  map_add' x y := by
    apply realVector_is_injective
    rw [subgroupBasisSynthesis_cast, map_add, map_add, map_add,
      subgroupBasisSynthesis_cast, subgroupBasisSynthesis_cast]

@[simp] theorem subgroupBasisSynthesisHom_cast (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (z : IntVec d) :
    realVector (subgroupBasisSynthesisHom Γ b hΛ z) = b.equivFun.symm (realVector z) :=
  subgroupBasisSynthesis_cast Γ b hΛ z

theorem subgroupBasisSynthesisHom_injective (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d))) :
    Function.Injective (subgroupBasisSynthesisHom Γ b hΛ) := by
  intro x y h
  apply realVector_is_injective
  apply b.equivFun.symm.injective
  simpa only [subgroupBasisSynthesisHom_cast] using congrArg realVector h

theorem subgroupBasisSynthesisHom_range (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d))) :
    (subgroupBasisSynthesisHom Γ b hΛ).range = Γ := by
  ext x
  constructor
  · rintro ⟨z, rfl⟩
    exact subgroupBasisSynthesis_mem Γ b hΛ z
  · intro hx
    have hxΛ : realVector x ∈ basisIntegerLattice b := hΛ ▸ ⟨x, hx, rfl⟩
    choose z hz using hxΛ
    refine ⟨z, realVector_is_injective ?_⟩
    rw [subgroupBasisSynthesisHom_cast]
    have he : b.equivFun (realVector x) = realVector z := funext hz
    rw [← he, LinearEquiv.symm_apply_apply]

/-- Exact coefficient-box membership under the integer synthesis map. -/
theorem subgroupBasisSynthesisHom_box (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (n : Fin d → ℕ) (z : IntVec d) :
    z ∈ integerBudgetBox n ↔
      realVector (subgroupBasisSynthesisHom Γ b hΛ z) ∈ basisCoefficientBox b n := by
  rw [mem_integerBudgetBox, subgroupBasisSynthesisHom_cast]
  change (∀ j, |z j| ≤ (n j : ℤ)) ↔
    ∀ j, |b.equivFun (b.equivFun.symm (realVector z)) j| ≤ (n j : ℝ)
  rw [LinearEquiv.apply_symm_apply]
  change (∀ j, |z j| ≤ (n j : ℤ)) ↔ ∀ j, |(z j : ℝ)| ≤ (n j : ℝ)
  constructor <;> intro h j
  · exact_mod_cast h j
  · exact_mod_cast h j

end
end Optss
