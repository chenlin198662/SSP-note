import Optss.DenseBoxCoordinates

/-!
# Rectangular progressions from disjoint coordinate batches

Each axis progression is obtained from its own actual label batch.
Their Minkowski sum is a rectangular sublattice progression. Pairwise
disjointness makes the final support a sum over the union of the batches,
with no input label reused.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

private theorem filling_sum_mem {ι G : Type*} [DecidableEq ι] [AddCommMonoid G] [DecidableEq G]
    (S : Finset ι) (A : ι → Finset G) (x : ι → G)
    (hx : ∀ i ∈ S, x i ∈ A i) : (∑ i ∈ S, x i) ∈ ∑ i ∈ S, A i := by
  induction S using Finset.induction_on with
  | empty => simp
  | @insert i S hi ih =>
    rw [Finset.sum_insert hi, Finset.sum_insert hi]
    exact Finset.add_mem_add (hx i (Finset.mem_insert_self _ _))
      (ih (fun j hj => hx j (Finset.mem_insert_of_mem hj)))

/-- The exact sublattice box stage of dense-box filling. The supplied
batches are actual disjoint sets of labels; all geometric filling and
period bounds are derived from density. -/
theorem dense_rectangular_progression {d : ℕ} {ι : Type*} [DecidableEq ι]
    (S : Fin d → Finset ι) (A : ι → Finset (IntVec d))
    (lo : IntVec d) (W : Fin d → ℕ) (c : ℝ)
    (hc : 0 < c) (hc1 : c ≤ 1) (hW : ∀ j, 0 < W j)
    (hN : ∀ j, 4 ≤ c * W j) (hcount : ∀ j, 20 ≤ c ^ 2 * (S j).card)
    (hdis : ((Finset.univ : Finset (Fin d)) : Set (Fin d)).PairwiseDisjoint S)
    (hbox : ∀ j, ∀ i ∈ S j, A i ⊆ fillingIntegerBox lo (fun k => lo k + W k - 1))
    (hdense : ∀ j, ∀ i ∈ S j,
      c * (fillingIntegerBox lo (fun k => lo k + W k - 1)).card ≤ (A i).card) :
    ∃ (v a b t : IntVec d), (∀ j, 0 < v j ∧ c * v j ≤ 2 ∧
        c ^ 2 * (S j).card * W j / 4 ≤ (b j - a j : ℤ)) ∧
      (fillingRectangularProgression v a b).image (t + ·) ⊆
        ∑ i ∈ Finset.univ.biUnion S, A i := by
  have hp : ∀ j : Fin d, ∃ (v a b : ℤ) (t : IntVec d), 0 < v ∧ c * v ≤ 2 ∧
      (Finset.Icc a b).image (fun x k => t k + if k = j then v * x else 0) ⊆ ∑ i ∈ S j, A i ∧
      c ^ 2 * (S j).card * W j / 4 ≤ (b - a : ℤ) := by
    intro j
    exact dense_box_coordinate_progression (S j) A j lo W c hc hc1 hW (hN j) (hcount j)
      (hbox j) (hdense j)
  choose v a b t hv using hp
  refine ⟨v, a, b, ∑ j, t j, fun j => ⟨(hv j).1, (hv j).2.1, (hv j).2.2.2⟩, ?_⟩
  intro x hx
  obtain ⟨p, hp, rfl⟩ := Finset.mem_image.mp hx
  obtain ⟨q, hq, rfl⟩ := Finset.mem_image.mp hp
  have hqm := (mem_fillingIntegerBox _ _ _).mp hq
  have hmem : (∑ j : Fin d, (fun k => t j k + if k = j then v j * q j else 0)) ∈
      ∑ j : Fin d, ∑ i ∈ S j, A i := by
    apply filling_sum_mem
    intro j hj
    exact (hv j).2.2.1 (Finset.mem_image.mpr ⟨q j, Finset.mem_Icc.mpr (hqm j), rfl⟩)
  have he : (∑ j : Fin d, (fun k => t j k + if k = j then v j * q j else 0)) =
      (∑ j, t j) + (fun j => v j * q j) := by
    funext k
    simp only [Finset.sum_apply, Pi.add_apply, Finset.sum_add_distrib]
    simp
  rw [he, ← Finset.sum_biUnion hdis] at hmem
  exact hmem

end
end Optss
