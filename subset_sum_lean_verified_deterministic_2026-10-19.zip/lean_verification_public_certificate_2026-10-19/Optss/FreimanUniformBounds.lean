import Optss.FreimanModelCovering
import Optss.BohrDensityParameters

/-! Uniform constants for the containing-progression construction. -/
namespace Optss
noncomputable section
open scoped Pointwise Classical

def freimanCoveringFactor (r K : ℕ) (t : ℝ) : ℕ :=
  properizationVolumeFactor (r+K) ⌈t⌉₊*(2^r*3^K)

def uniformFreimanCoveringFactor (R K : ℕ) (t : ℝ) : ℕ :=
  (Finset.range (R+1)).sup (fun r => freimanCoveringFactor r K t)

theorem freimanCoveringFactor_le_uniform {r R : ℕ} (hr : r≤R) (K : ℕ) (t : ℝ) :
    freimanCoveringFactor r K t≤uniformFreimanCoveringFactor R K t := by
  unfold uniformFreimanCoveringFactor
  exact Finset.le_sup (f := fun n => freimanCoveringFactor n K t)
    (Finset.mem_range.mpr (show r<R+1 by omega))

variable {G H : Type*} [AddCommGroup G] [AddCommGroup H] [DecidableEq G] [DecidableEq H] [IsAddTorsionFree G]

theorem freiman_finite_model_covering_uniform [Fintype H]
    (S T : Finset G) (hS : S.Nonempty) (hTS : T⊆S) (hcard : S.card≤8*T.card)
    (f : G → H) (hf : FreimanEight T f) (hinj : Set.InjOn f T)
    (C : ℚ≥0) (hC : ((S+S).card : ℚ≥0)≤C*S.card)
    {r : ℕ} (R : ℕ) (hr : r≤R) (ρ : IntVec r →+ H) (β : Fin r → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox β))
    (hP : integerProgressionValues ρ β⊆(T.image f+T.image f)-(T.image f+T.image f))
    (M : ℕ) (hM : 0<M) (hsize : Fintype.card H≤M*(integerProgressionValues ρ β).card)
    (t : ℝ) :
    let K : ℝ := (C^5/((1/(M : ℚ≥0))/8) : ℚ≥0)
    ∃ d≤R+⌈K⌉₊, ∃ (ρ' : IntVec d →+ G) (γ : Fin d → ℕ),
      S⊆integerProgressionValues ρ' γ ∧
      Set.InjOn ρ' (realDilatedIntegerBox γ t) ∧
      ((integerBudgetBox γ).card : ℚ≥0)≤
        (uniformFreimanCoveringFactor R ⌈K⌉₊ t : ℕ)*C^4*S.card := by
  dsimp only
  let K : ℝ := (C^5/((1/(M : ℚ≥0))/8) : ℚ≥0)
  obtain ⟨d,hd,ρ',γ,hcont,hproper',hvol⟩ :=
    freiman_finite_model_covering S T hS hTS hcard f hf hinj C hC ρ β hproper hP M hM hsize t
  refine ⟨d,hd.trans (Nat.add_le_add_right hr _),ρ',γ,hcont,hproper',?_⟩
  have hfactor : (freimanCoveringFactor r ⌈K⌉₊ t : ℚ≥0)≤
      (uniformFreimanCoveringFactor R ⌈K⌉₊ t : ℚ≥0) :=
    Nat.cast_le.mpr (freimanCoveringFactor_le_uniform hr _ _)
  apply hvol.trans
  change (freimanCoveringFactor r ⌈K⌉₊ t : ℚ≥0)*C^4*S.card≤_
  gcongr

end
end Optss
