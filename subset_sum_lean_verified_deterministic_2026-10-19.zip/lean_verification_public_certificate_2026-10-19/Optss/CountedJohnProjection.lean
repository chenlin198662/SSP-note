import Optss.CountedJohnSandwich
import Optss.CountedProjectionPartition

/-!
# Projected public consequences of counted John geometry

The geometric sandwich lives in real coordinate space, while the common GAP
map is integer-linear.  This file takes exact integer lattice preimages and
derives the two scalar inclusions displayed as equation (4) in Theorem 1.4.
-/

namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators

variable {ι : Type*} [Fintype ι]
variable {d : ℕ}

/-- Integer lattice points represented by a real coordinate set. -/
def integerCoordinatePoints (K : Set (Fin d → ℝ)) : Set (IntVec d) :=
  realVector ⁻¹' K

@[simp] theorem mem_integerCoordinatePoints_iff (K : Set (Fin d → ℝ))
    (z : IntVec d) :
    z ∈ integerCoordinatePoints K ↔ realVector z ∈ K := Iff.rfl

/-- The inner and outer parts of `CountedJohnGeometry` become exact
inclusions for integer coordinate supports. -/
theorem countedJohnGeometry_integer_support_sandwich
    (capacity e r : ι → ℕ) (u : ι → IntVec d) (width : Fin d → ℕ)
    (t : IntVec d) (hr : ∀ i, r i ≤ capacity i - e i)
    (hgeom : CountedJohnGeometry capacity e r u width t) :
    let b := fun i => capacity i - e i - r i
    let K := {realVector t} +
      zonotope (fun i => realVector (u i)) (fun i => (b i : ℝ))
    let Z := zonotope (fun i => realVector (u i))
      (fun i => ((r i + b i : ℕ) : ℝ))
    integerCoordinatePoints K ⊆
      countSums u (fun i => ((capacity i - e i : ℕ) : ℤ)) ∧
    countSums u (fun i => ((capacity i - e i : ℕ) : ℤ)) ⊆
      integerCoordinatePoints Z := by
  dsimp only
  dsimp only [CountedJohnGeometry] at hgeom
  have hcoeff :
      (fun i => ((r i + (capacity i - e i - r i) : ℕ) : ℤ)) =
        fun i => ((capacity i - e i : ℕ) : ℤ) := by
    funext i
    have hri := hr i
    congr 1
    omega
  constructor
  · intro z hz
    have hzreal := hgeom.1 ⟨hz, ⟨z, rfl⟩⟩
    rw [hcoeff] at hzreal
    exact (realVector_mem_countSums_iff u _ z).1 hzreal
  · intro z hz
    have hzreal := (realVector_mem_countSums_iff u _ z).2 hz
    rw [← hcoeff] at hzreal
    exact (hgeom.2.1 hzreal).1

/-- Equation (4), including the exact exceptional support: attainable scalar
sums lie between the projection of the inner and outer integer coordinate
regions, with every exceptional subset sum added on both sides. -/
theorem counted_john_projected_sandwich
    (projection : IntVec d →+ ℤ) (u : ι → IntVec d) (scalar : ι → ℤ)
    (capacity e r : ι → ℕ) (width : Fin d → ℕ) (t : IntVec d)
    (he : ∀ i, e i ≤ capacity i)
    (hr : ∀ i, r i ≤ capacity i - e i)
    (hrep : ∀ i, 0 < capacity i - e i → projection (u i) = scalar i)
    (hgeom : CountedJohnGeometry capacity e r u width t) :
    let b := fun i => capacity i - e i - r i
    let K := {realVector t} +
      zonotope (fun i => realVector (u i)) (fun i => (b i : ℝ))
    let Z := zonotope (fun i => realVector (u i))
      (fun i => ((r i + b i : ℕ) : ℝ))
    countSums scalar (fun i => (e i : ℤ)) +
        projection '' integerCoordinatePoints K ⊆
      countSums scalar (fun i => (capacity i : ℤ)) ∧
    countSums scalar (fun i => (capacity i : ℤ)) ⊆
      countSums scalar (fun i => (e i : ℤ)) +
        projection '' integerCoordinatePoints Z := by
  dsimp only
  obtain ⟨hinner, houter⟩ :=
    countedJohnGeometry_integer_support_sandwich capacity e r u width t hr hgeom
  have hpartition := countSums_exception_add_projected_live
    projection u scalar capacity e he hrep
  constructor
  · intro y hy
    obtain ⟨a, ha, b, ⟨z, hz, rfl⟩, rfl⟩ := hy
    rw [hpartition]
    exact ⟨a, ha, projection z, ⟨z, hinner hz, rfl⟩, rfl⟩
  · intro y hy
    rw [hpartition] at hy
    obtain ⟨a, ha, b, ⟨z, hz, rfl⟩, rfl⟩ := hy
    exact ⟨a, ha, projection z, ⟨z, houter hz, rfl⟩, rfl⟩

end
end Optss
