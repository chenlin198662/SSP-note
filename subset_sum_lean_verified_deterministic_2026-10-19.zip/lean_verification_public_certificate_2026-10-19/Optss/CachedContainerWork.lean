import Optss.EncodedCachedReduction
import Optss.BitMatrixFuel

/-!
# Container accounting for the actual encoded cached computation

This is a source-level accounting interpretation: one unit counts an array
slot read/write, a shallow copied slot, a list-cell construction/visit or a
finite-index test. Bit-list payloads are immutable and shared; their internal
operations have separate scalar gate/list charges. Setting a persistent array
is conservatively charged for copying every slot plus writing the new slot.

The value projection agrees with the actual encoded routines. Auxiliary
accounting pairs and vectors are proof instrumentation, not additional source
containers; this does not assert a machine-step implementation theorem for
Lean's arrays, allocation, index arithmetic or garbage collection.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

/-- Fold interpretation counts the actual input-list branch visits and operand
array accesses. Scalar fraction operations are accounted separately. -/
def containerProductSum {ι : Type*} (u v : ι → BitListFraction × ℕ) :
    List ι → BitListFraction × ℕ
  | [] => (bitListFractionZero,1)
  | i::is =>
    let a := u i
    let b := v i
    let product := bitListFractionMul a.1 b.1
    let tail := containerProductSum u v is
    (bitListFractionAdd product tail.1,a.2+b.2+tail.2+1)

theorem containerProductSum_value {ι : Type*} (u v : ι → BitListFraction × ℕ)
    (xs : List ι) :
    (containerProductSum u v xs).1 = encodedProductSum (fun i => (u i).1) (fun i => (v i).1) xs := by
  induction xs with
  | nil => rfl
  | cons i xs ih => simp only [containerProductSum, encodedProductSum, ih]

theorem containerProductSum_work {ι : Type*} (u v : ι → BitListFraction × ℕ)
    (xs : List ι) (U V : ℕ) (hu : ∀ i ∈ xs, (u i).2 ≤ U)
    (hv : ∀ i ∈ xs, (v i).2 ≤ V) :
    (containerProductSum u v xs).2 ≤ xs.length*(U+V+1)+1 := by
  induction xs with
  | nil => simp [containerProductSum]
  | cons i xs ih =>
    have ha := hu i (List.mem_cons_self)
    have hb := hv i (List.mem_cons_self)
    have ht := ih (fun j hj => hu j (List.mem_cons_of_mem _ hj))
      (fun j hj => hv j (List.mem_cons_of_mem _ hj))
    simp only [containerProductSum, List.length_cons]
    nlinarith

/-- Creating the finite list costs one cell and one index step per element,
plus its terminating test. -/
def containerRationalDot (u v : Fin d → BitListFraction × ℕ) : BitListFraction × ℕ :=
  let s := containerProductSum u v (List.ofFn id)
  (s.1,s.2+2*d+1)

theorem containerRationalDot_value (u v : Fin d → BitListFraction × ℕ) :
    (containerRationalDot u v).1 = encodedRationalDot (fun i => (u i).1) (fun i => (v i).1) :=
  containerProductSum_value u v _

theorem containerRationalDot_work (u v : Fin d → BitListFraction × ℕ)
    (U V : ℕ) (hu : ∀ i, (u i).2 ≤ U) (hv : ∀ i, (v i).2 ≤ V) :
    (containerRationalDot u v).2 ≤ d*(U+V+3)+2 := by
  have h := containerProductSum_work u v (List.ofFn id) U V (fun i _ => hu i) (fun i _ => hv i)
  simp only [List.length_ofFn] at h
  unfold containerRationalDot
  dsimp only
  nlinarith

/-- Each nested matrix lookup charges two array-slot reads. This upper bound
also covers a compiler that hoists or shares the outer row lookup. -/
def containerGsCoefficient (A T : BitRationalMatrixData r d) (k j : Fin r) :
    BitListFraction × ℕ :=
  let x := containerRationalDot (fun l => ((T.get j).get l,2))
    (fun l => ((A.get k).get l,2))
  let y := containerRationalDot (fun l => ((T.get j).get l,2))
    (fun l => ((T.get j).get l,2))
  (bitListFractionDiv x.1 y.1,x.2+y.2)

theorem containerGsCoefficient_value (A T : BitRationalMatrixData r d) (k j : Fin r) :
    (containerGsCoefficient A T k j).1 = encodedGsCoefficient A T k j := by
  simp only [containerGsCoefficient, encodedGsCoefficient, containerRationalDot_value]

theorem containerGsCoefficient_work (A T : BitRationalMatrixData r d) (k j : Fin r) :
    (containerGsCoefficient A T k j).2 ≤ 14*d+4 := by
  have hx := containerRationalDot_work (fun l => ((T.get j).get l,2))
    (fun l => ((A.get k).get l,2)) 2 2 (fun _ => le_rfl) (fun _ => le_rfl)
  have hy := containerRationalDot_work (fun l => ((T.get j).get l,2))
    (fun l => ((T.get j).get l,2)) 2 2 (fun _ => le_rfl) (fun _ => le_rfl)
  unfold containerGsCoefficient
  dsimp only
  omega

/-- Materialized coefficient array: allocate/write `r` slots and perform the
same `r` index comparisons as `encodedGSCoefficients`. -/
def containerGSCoefficients (A T : BitRationalMatrixData r d) (k : Fin r) :
    Vector BitListFraction r × ℕ :=
  let samples : Vector (BitListFraction × ℕ) r := Vector.ofFn fun i =>
    if i < k then containerGsCoefficient A T k i else (bitListFractionZero,0)
  (Vector.ofFn (fun i => (samples.get i).1),3*r+∑ i : Fin r, (samples.get i).2)

theorem containerGSCoefficients_value (A T : BitRationalMatrixData r d) (k : Fin r) :
    (containerGSCoefficients A T k).1 = encodedGSCoefficients A T k := by
  apply Vector.ext
  intro i hi
  change ((containerGSCoefficients A T k).1).get ⟨i,hi⟩ = (encodedGSCoefficients A T k).get ⟨i,hi⟩
  simp only [containerGSCoefficients, encodedGSCoefficients, get_ofFn]
  split_ifs <;> simp only [containerGsCoefficient_value]

theorem containerGSCoefficients_work (A T : BitRationalMatrixData r d) (k : Fin r) :
    (containerGSCoefficients A T k).2 ≤ r*(14*d+7) := by
  have hs : (∑ i : Fin r, (if i < k then containerGsCoefficient A T k i else (bitListFractionZero,0)).2) ≤
      r*(14*d+4) := by
    calc
      _ ≤ ∑ _i : Fin r, (14*d+4) := by
        apply Finset.sum_le_sum
        intro i _
        split_ifs
        · exact containerGsCoefficient_work A T k i
        · exact Nat.zero_le _
      _ = _ := by simp
  unfold containerGSCoefficients
  simp only [get_ofFn]
  nlinarith

def containerGSRow (A T : BitRationalMatrixData r d) (k : Fin r) :
    Vector BitListFraction d × ℕ :=
  let coeff := containerGSCoefficients A T k
  let samples : Vector (BitListFraction × ℕ) d := Vector.ofFn fun l =>
    let acc := containerProductSum (fun i : Finset.Iio k => (coeff.1.get i,1))
      (fun i => ((T.get i).get l,2)) (List.ofFn (lowerFinEquiv k))
    (bitListFractionSub ((A.get k).get l) acc.1, acc.2+2*k.val+1+2)
  (Vector.ofFn (fun l => (samples.get l).1),coeff.2+2*d+∑ l : Fin d, (samples.get l).2)

theorem containerGSRow_value (A T : BitRationalMatrixData r d) (k : Fin r) :
    (containerGSRow A T k).1 = encodedGSRow A T k := by
  apply Vector.ext
  intro l hl
  change ((containerGSRow A T k).1).get ⟨l,hl⟩ = (encodedGSRow A T k).get ⟨l,hl⟩
  simp only [containerGSRow, encodedGSRow, get_ofFn, containerProductSum_value,
    containerGSCoefficients_value]

theorem containerGSRow_work (A T : BitRationalMatrixData r d) (k : Fin r) :
    (containerGSRow A T k).2 ≤ r*(14*d+7)+d*(6*r+6) := by
  let coeff := containerGSCoefficients A T k
  have hs : (∑ l : Fin d,
      ((containerProductSum (fun i : Finset.Iio k => (coeff.1.get i,1))
        (fun i => ((T.get i).get l,2)) (List.ofFn (lowerFinEquiv k))).2+2*k.val+1+2)) ≤
      d*(6*r+4) := by
    calc
      _ ≤ ∑ _l : Fin d, (6*r+4) := by
        apply Finset.sum_le_sum
        intro l _
        have h := containerProductSum_work (fun i : Finset.Iio k => (coeff.1.get i,1))
          (fun i => ((T.get i).get l,2)) (List.ofFn (lowerFinEquiv k)) 1 2
          (fun _ _ => le_rfl) (fun _ _ => le_rfl)
        simp only [List.length_ofFn] at h
        have hk := k.isLt
        omega
      _ = _ := by simp
  have hc := containerGSCoefficients_work A T k
  unfold containerGSRow
  simp only [get_ofFn]
  change coeff.2+2*d+_ ≤ _
  nlinarith

/-- Cached-table interpretation with a worst-case shallow copy at each set.
The initial repeated zero row is shared between the `r` outer slots. -/
def containerGSTable (A : BitRationalMatrixData r d) (n : ℕ) (hn : n ≤ r) :
    BitRationalMatrixData r d × ℕ :=
  match n with
  | 0 => (Vector.replicate r (Vector.replicate d bitListFractionZero),2*(r+d))
  | n+1 =>
    let T := containerGSTable A n (by omega)
    let row := containerGSRow A T.1 ⟨n,by omega⟩
    (T.1.set n row.1 (by omega),T.2+row.2+r+1)
termination_by n

theorem containerGSTable_value (A : BitRationalMatrixData r d) (n : ℕ) (hn : n ≤ r) :
    (containerGSTable A n hn).1 = encodedGSTable A n hn := by
  induction n with
  | zero => rw [containerGSTable, encodedGSTable]
  | succ n ih => rw [containerGSTable, encodedGSTable, containerGSRow_value, ih]

theorem containerGSTable_work (A : BitRationalMatrixData r d) (n : ℕ) (hn : n ≤ r) :
    (containerGSTable A n hn).2 ≤
      2*(r+d)+n*(r*(14*d+7)+d*(6*r+6)+r+1) := by
  induction n with
  | zero => simp only [containerGSTable, zero_mul, add_zero, le_refl]
  | succ n ih =>
    have ht := ih (by omega)
    have hr := containerGSRow_work A (containerGSTable A n (by omega)).1 ⟨n,by omega⟩
    rw [containerGSTable]
    dsimp only
    nlinarith
/-- Integer-to-fraction arrays reuse each stored sign and magnitude list.
Only the new two-level array skeleton and nested input reads are charged. -/
def containerRationalIntegerRows (D : BitIntegerMatrixData r d) :
    BitRationalMatrixData r d × ℕ := (encodedRationalIntegerRows D,4*r*d+2*r)

/-- Updating one row constructs only its `d` slots and conservatively copies
the `r` outer row references. Existing bit-list payloads are not deep-copied. -/
def containerIntegerRowUpdate (D : BitIntegerMatrixData r d) (k j : Fin r) (q : BitListInteger) :
    BitIntegerMatrixData r d × ℕ := (bitListIntegerRowUpdate D k j q,6*d+r+1)

def containerInnerBound (r d : ℕ) : ℕ :=
  (4*r*d+2*r)+(2*(r+d)+r*(r*(14*d+7)+d*(6*r+6)+r+1))+(14*d+4)+(6*d+r+1)+1

def containerReduceIntegerRow (D : BitIntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (hn : n ≤ k.val) : BitIntegerMatrixData r d × ℕ :=
  match n with
  | 0 => (D,1)
  | n+1 =>
    let Q := containerRationalIntegerRows D
    let T := containerGSTable Q.1 r le_rfl
    let c := containerGsCoefficient Q.1 T.1 k ⟨n,by omega⟩
    let U := containerIntegerRowUpdate D k ⟨n,by omega⟩ (encodedRoundInteger c.1)
    let tail := containerReduceIntegerRow U.1 k n (by omega)
    (tail.1,Q.2+T.2+c.2+U.2+tail.2+1)
termination_by n

theorem containerReduceIntegerRow_value (D : BitIntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (hn : n ≤ k.val) :
    (containerReduceIntegerRow D k n hn).1 = encodedReduceIntegerRow D k n hn := by
  induction n generalizing D with
  | zero => rw [containerReduceIntegerRow, encodedReduceIntegerRow]
  | succ n ih =>
    rw [containerReduceIntegerRow, encodedReduceIntegerRow, ih]
    simp only [containerIntegerRowUpdate, containerGsCoefficient_value, containerGSTable_value,
      containerRationalIntegerRows]

theorem containerReduceIntegerRow_work (D : BitIntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (hn : n ≤ k.val) :
    (containerReduceIntegerRow D k n hn).2 ≤ n*containerInnerBound r d+1 := by
  induction n generalizing D with
  | zero => simp only [containerReduceIntegerRow, zero_mul, zero_add, le_refl]
  | succ n ih =>
    let Q := containerRationalIntegerRows D
    let T := containerGSTable Q.1 r le_rfl
    let c := containerGsCoefficient Q.1 T.1 k ⟨n,by omega⟩
    let U := containerIntegerRowUpdate D k ⟨n,by omega⟩ (encodedRoundInteger c.1)
    have ht := containerGSTable_work Q.1 r le_rfl
    have hc := containerGsCoefficient_work Q.1 T.1 k ⟨n,by omega⟩
    have hi := ih U.1 (by omega)
    rw [containerReduceIntegerRow]
    change Q.2+T.2+c.2+U.2+(containerReduceIntegerRow U.1 k n (by omega)).2+1 ≤ _
    have hQ : Q.2 = 4*r*d+2*r := rfl
    have hU : U.2 = 6*d+r+1 := rfl
    change T.2 ≤ _ at ht
    change c.2 ≤ _ at hc
    rw [hQ,hU]
    unfold containerInnerBound at hi ⊢
    nlinarith

def containerReduceIntegerAll (D : BitIntegerMatrixData r d)
    (n : ℕ) (hn : n ≤ r) : BitIntegerMatrixData r d × ℕ :=
  match n with
  | 0 => (D,1)
  | n+1 =>
    let C := containerReduceIntegerAll D n (by omega)
    let row := containerReduceIntegerRow C.1 ⟨n,by omega⟩ n le_rfl
    (row.1,C.2+row.2+1)
termination_by n

theorem containerReduceIntegerAll_value (D : BitIntegerMatrixData r d)
    (n : ℕ) (hn : n ≤ r) :
    (containerReduceIntegerAll D n hn).1 = encodedReduceIntegerAll D n hn := by
  induction n with
  | zero => rw [containerReduceIntegerAll, encodedReduceIntegerAll]
  | succ n ih =>
    rw [containerReduceIntegerAll, encodedReduceIntegerAll, containerReduceIntegerRow_value, ih]

theorem containerReduceIntegerAll_work (D : BitIntegerMatrixData r d)
    (n : ℕ) (hn : n ≤ r) :
    (containerReduceIntegerAll D n hn).2 ≤ n*(r*containerInnerBound r d+2)+1 := by
  induction n with
  | zero => simp only [containerReduceIntegerAll, zero_mul, zero_add, le_refl]
  | succ n ih =>
    have hi := ih (by omega)
    have hr := containerReduceIntegerRow_work (containerReduceIntegerAll D n (by omega)).1
      ⟨n,by omega⟩ n le_rfl
    have hm : n*containerInnerBound r d ≤ r*containerInnerBound r d :=
      Nat.mul_le_mul_right _ (by omega)
    rw [containerReduceIntegerAll]
    dsimp only
    nlinarith

/-- Shared norm/coefficient values are retained through the final scalar test. -/
def containerLovaszPair (A T : BitRationalMatrixData r d) (j k : Fin r) : Bool × ℕ :=
  let x := containerRationalDot (fun l => ((T.get k).get l,2)) (fun l => ((T.get k).get l,2))
  let y := containerRationalDot (fun l => ((T.get j).get l,2)) (fun l => ((T.get j).get l,2))
  let u := containerGsCoefficient A T k j
  let square := bitListFractionMul u.1 u.1
  let product := bitListFractionMul square y.1
  let total := bitListFractionAdd x.1 product
  let left := bitListFractionMul encodedFractionFour total
  let right := bitListFractionMul encodedFractionThree y.1
  (bitListFractionLT left right,x.2+y.2+u.2)

theorem containerLovaszPair_value (A T : BitRationalMatrixData r d) (j k : Fin r) :
    (containerLovaszPair A T j k).1 = encodedLovaszPair A T j k := by
  simp only [containerLovaszPair, encodedLovaszPair, containerRationalDot_value,
    containerGsCoefficient_value]

theorem containerLovaszPair_work (A T : BitRationalMatrixData r d) (j k : Fin r) :
    (containerLovaszPair A T j k).2 ≤ 28*d+8 := by
  have hx := containerRationalDot_work (fun l => ((T.get k).get l,2))
    (fun l => ((T.get k).get l,2)) 2 2 (fun _ => le_rfl) (fun _ => le_rfl)
  have hy := containerRationalDot_work (fun l => ((T.get j).get l,2))
    (fun l => ((T.get j).get l,2)) 2 2 (fun _ => le_rfl) (fun _ => le_rfl)
  have hu := containerGsCoefficient_work A T k j
  unfold containerLovaszPair
  dsimp only
  omega

/-- Materializing both finite index lists and flattening their product visits
and constructs each list cell a bounded number of times. -/
def containerPairEnumerationWork (r : ℕ) : ℕ :=
  (2*r+1)+∑ _j : Fin r, ((2*r+1)+(2*r+1))

/-- Each finite filter step reads two table slots, visits one list cell and
may retain that cell in its output list. -/
def containerPairFilterWork (r : ℕ) : ℕ :=
  (∑ _p : Fin r × Fin r, (4:ℕ))+1

theorem containerPairAdministrationWork_le (r : ℕ) :
    containerPairEnumerationWork r+containerPairFilterWork r ≤ 8*(r+1)^2 := by
  unfold containerPairEnumerationWork containerPairFilterWork
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin,
    Fintype.card_prod, smul_eq_mul]
  nlinarith

/-- The finite filter scans the `r²` pairs once and reads two array slots per
pair. Enumeration/list-cell overhead is conservatively covered by `8(r+1)²`. -/
def containerFailingAdjacentPairs (D : BitIntegerMatrixData r d) : Finset (Fin r × Fin r) × ℕ :=
  let Q := containerRationalIntegerRows D
  let T := containerGSTable Q.1 r le_rfl
  let tests : Vector (Vector (Bool × ℕ) r) r := Vector.ofFn fun j => Vector.ofFn fun k =>
    if k.val = j.val+1 then containerLovaszPair Q.1 T.1 j k else (false,0)
  (Finset.univ.filter (fun p => ((tests.get p.1).get p.2).1),
    Q.2+T.2+3*r*r+2*r+(containerPairEnumerationWork r+containerPairFilterWork r)+∑ j : Fin r, ∑ k : Fin r, ((tests.get j).get k).2)

theorem containerFailingAdjacentPairs_value (D : BitIntegerMatrixData r d) :
    (containerFailingAdjacentPairs D).1 = encodedFailingAdjacentPairs D := by
  ext p
  simp only [containerFailingAdjacentPairs, encodedFailingAdjacentPairs, Finset.mem_filter,
    Finset.mem_univ, true_and, get_ofFn, containerGSTable_value, containerRationalIntegerRows]
  split_ifs <;> simp only [containerLovaszPair_value]

def containerSearchBound (r d : ℕ) : ℕ :=
  (4*r*d+2*r)+(2*(r+d)+r*(r*(14*d+7)+d*(6*r+6)+r+1))+
    3*r*r+2*r+8*(r+1)^2+r*r*(28*d+8)

theorem containerFailingAdjacentPairs_work (D : BitIntegerMatrixData r d) :
    (containerFailingAdjacentPairs D).2 ≤ containerSearchBound r d := by
  let Q := containerRationalIntegerRows D
  let T := containerGSTable Q.1 r le_rfl
  have ht := containerGSTable_work Q.1 r le_rfl
  have hs : (∑ j : Fin r, ∑ k : Fin r,
      (if k.val = j.val+1 then containerLovaszPair Q.1 T.1 j k else (false,0)).2) ≤ r*r*(28*d+8) := by
    calc
      _ ≤ ∑ _j : Fin r, ∑ _k : Fin r, (28*d+8) := by
        apply Finset.sum_le_sum
        intro j _
        apply Finset.sum_le_sum
        intro k _
        split_ifs
        · exact containerLovaszPair_work Q.1 T.1 j k
        · exact Nat.zero_le _
      _ = _ := by simp; ring
  unfold containerFailingAdjacentPairs
  simp only [get_ofFn]
  change Q.2+T.2+3*r*r+2*r+(containerPairEnumerationWork r+containerPairFilterWork r)+_ ≤ _
  have hQ : Q.2 = 4*r*d+2*r := rfl
  have ha := containerPairAdministrationWork_le r
  change T.2 ≤ _ at ht
  rw [hQ]
  calc
    _ ≤ (4*r*d+2*r)+(2*(r+d)+r*(r*(14*d+7)+d*(6*r+6)+r+1))+
        3*r*r+2*r+8*(r+1)^2+r*r*(28*d+8) :=
      Nat.add_le_add (by omega) hs
    _ = _ := rfl
/-- Finite minimum is a single fold through its stored entries. Each entry
charges a visit and at most two comparisons of finite indices. -/
def containerLeastPair (S : Finset (Fin r × Fin r)) (hS : S.Nonempty) :
    (Fin r × Fin r) × ℕ := (leastPairInFinset S hS,3*S.card+1)

/-- A swap constructs only the outer vector. It reads one old row reference
and performs at most two equality tests per new slot. -/
def containerSwapRows (D : BitIntegerMatrixData r d) (j k : Fin r) :
    BitIntegerMatrixData r d × ℕ := (encodedSwapRows D j k,5*r)

def containerPassBound (r d : ℕ) : ℕ :=
  (r*(r*containerInnerBound r d+2)+1)+containerSearchBound r d+3*r*r+5*r+4

/-- The counted loop follows exactly the encoded branches and row arrays.
The fuel-list visit and nonempty test contribute two administrative units. -/
def containerReductionFuel : List Bool → BitIntegerMatrixData r d → EncodedLatticeResult r d × ℕ
  | [], D => (⟨D,0⟩,1)
  | _::fuel, D =>
    let C := containerReduceIntegerAll D r le_rfl
    let tests := containerFailingAdjacentPairs C.1
    if h : tests.1.Nonempty then
      let p := containerLeastPair tests.1 h
      let W := containerSwapRows C.1 p.1.1 p.1.2
      let tail := containerReductionFuel fuel W.1
      (⟨tail.1.rows,tail.1.swaps+1⟩,C.2+tests.2+p.2+W.2+tail.2+2)
    else (⟨C.1,0⟩,C.2+tests.2+2)

theorem containerReductionFuel_value (fuel : List Bool) (D : BitIntegerMatrixData r d) :
    (containerReductionFuel fuel D).1 = encodedReductionFuel fuel D := by
  induction fuel generalizing D with
  | nil => rfl
  | cons b fuel ih =>
    rw [containerReductionFuel, encodedReductionFuel]
    simp only [containerFailingAdjacentPairs_value, containerReduceIntegerAll_value]
    split_ifs
    · simp only [containerLeastPair, containerSwapRows, ih]
    · rfl

/-- Per-pass container work is bounded by a fixed polynomial in dimensions. -/
theorem containerPassBound_le (r d : ℕ) :
    containerPassBound r d ≤ 128*(r+1)^4*(d+1) := by
  let rem := 108*r^4*d+120*r^4+502*r^3*d+506*r^3+
    698*r^2*d+732*r^2+502*r*d+482*r+126*d+115
  have he : containerPassBound r d+rem = 128*(r+1)^4*(d+1) := by
    unfold containerPassBound containerInnerBound containerSearchBound rem
    ring
  exact (Nat.le_add_right _ rem).trans he.le

theorem containerPassBound_pos (r d : ℕ) : 0 < containerPassBound r d := by
  unfold containerPassBound
  omega

/-- The actual loop's number of accepted interchanges controls every executed
container pass, without a height or potential assumption. -/
theorem containerReductionFuel_work (fuel : List Bool) (D : BitIntegerMatrixData r d) :
    (containerReductionFuel fuel D).2 ≤
      ((containerReductionFuel fuel D).1.swaps+1)*containerPassBound r d := by
  induction fuel generalizing D with
  | nil =>
    simp only [containerReductionFuel, EncodedLatticeResult.swaps, zero_add, one_mul]
    exact containerPassBound_pos r d
  | cons b fuel ih =>
    let C := containerReduceIntegerAll D r le_rfl
    let tests := containerFailingAdjacentPairs C.1
    have hs := containerReduceIntegerAll_work D r le_rfl
    have ht := containerFailingAdjacentPairs_work C.1
    change C.2 ≤ _ at hs
    change tests.2 ≤ _ at ht
    have hc : tests.1.card ≤ r*r := by simpa using Finset.card_le_univ tests.1
    have hpass : C.2+tests.2+(3*tests.1.card+1)+5*r+2 ≤ containerPassBound r d := by
      unfold containerPassBound
      nlinarith
    rw [containerReductionFuel]
    split_ifs with hbad
    · let p := containerLeastPair tests.1 hbad
      let W := containerSwapRows C.1 p.1.1 p.1.2
      have hi := ih W.1
      change C.2+tests.2+p.2+W.2+(containerReductionFuel fuel W.1).2+2 ≤
        ((containerReductionFuel fuel W.1).1.swaps+1+1)*containerPassBound r d
      have hp : p.2 = 3*tests.1.card+1 := rfl
      have hW : W.2 = 5*r := rfl
      rw [hp,hW]
      calc
        _ = (C.2+tests.2+(3*tests.1.card+1)+5*r+2)+(containerReductionFuel fuel W.1).2 := by omega
        _ ≤ containerPassBound r d+((containerReductionFuel fuel W.1).1.swaps+1)*containerPassBound r d :=
          Nat.add_le_add hpass hi
        _ = _ := by ring
    · change C.2+tests.2+2 ≤ (0+1)*containerPassBound r d
      omega

/-- Final container accounting refers to the exact encoded algorithm's swap
counter and shallowly shared arrays, rather than assigned layer weights. -/
theorem encodedReductionFuel_container_work (fuel : List Bool) (D : BitIntegerMatrixData r d) :
    (containerReductionFuel fuel D).2 ≤
      ((encodedReductionFuel fuel D).swaps+1)*(128*(r+1)^4*(d+1)) := by
  have h := containerReductionFuel_work fuel D
  rw [containerReductionFuel_value] at h
  exact h.trans (Nat.mul_le_mul_left _ (containerPassBound_le r d))
/-- Every recursive swap consumes one actual fuel-list cell. -/
theorem encodedReductionFuel_swaps_le_length (fuel : List Bool) (D : BitIntegerMatrixData r d) :
    (encodedReductionFuel fuel D).swaps ≤ fuel.length := by
  induction fuel generalizing D with
  | nil => simp only [encodedReductionFuel, List.length_nil, EncodedLatticeResult.swaps, le_refl]
  | cons b fuel ih =>
    rw [encodedReductionFuel]
    split_ifs
    · simp only [EncodedLatticeResult.swaps, List.length_cons]
      exact Nat.add_le_add_right (ih _) 1
    · exact Nat.zero_le _

/-- With the actual polynomial input-size initializer, container operations
are polynomial in rank, ambient dimension and the stored integer input size.
The initializer's own construction cost is separate from this loop bound. -/
theorem bitMatrixReductionFuel_container_work (D : BitIntegerMatrixData r d) :
    (containerReductionFuel (bitMatrixReductionFuel D) D).2 ≤
      (3*(r*(r+1)+1)*(r.size+d.size+2*(bitIntegerMatrixSize D+1)+4)+1)*
        (128*(r+1)^4*(d+1)) := by
  have h := encodedReductionFuel_container_work (bitMatrixReductionFuel D) D
  have hs := encodedReductionFuel_swaps_le_length (bitMatrixReductionFuel D) D
  rw [bitMatrixReductionFuel_length] at hs
  exact h.trans (Nat.mul_le_mul_right _ (Nat.add_le_add_right hs 1))

end Optss
