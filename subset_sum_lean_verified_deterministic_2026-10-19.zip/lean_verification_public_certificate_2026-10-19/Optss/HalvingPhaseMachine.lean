import Mathlib.Data.Finset.Card
import Mathlib.Data.Nat.Log
import Mathlib.Tactic

/-!
# A terminating finite-label phase machine

Each actual step either returns a finished state or removes labels while
strictly halving a positive integer potential. Running for one more than the
binary logarithm of the initial potential always finishes. The implementation
records its exact number of step calls and bounds all deleted labels.
-/
namespace Optss
open scoped Classical

/-- A total phase operation, with a positive potential and a proved per-step
removal budget. `none` is the successful terminal outcome. -/
structure HalvingPhaseMachine (ι : Type*) [DecidableEq ι]
    (potential : Finset ι → ℕ) (Good : Finset ι → Prop) (D : ℕ) where
  step : Finset ι → Option (Finset ι)
  positive : ∀ s, 0 < potential s
  done : ∀ s, step s = none → Good s
  next_subset : ∀ s t, step s = some t → t ⊆ s
  decreases : ∀ s t, step s = some t → 2*potential t < potential s
  deletes : ∀ s t, step s = some t → (s \ t).card ≤ D

namespace HalvingPhaseMachine
variable {ι : Type*} [DecidableEq ι] {potential : Finset ι → ℕ}
  {Good : Finset ι → Prop} {D : ℕ}

/-- Execute at most `fuel` actual phases, recording the exact calls made. -/
def run (F : HalvingPhaseMachine ι potential Good D) : ℕ → Finset ι → Finset ι × ℕ
  | 0, s => (s, 0)
  | n+1, s => match F.step s with
      | none => (s, 1)
      | some t => let out := F.run n t; (out.1, out.2+1)

/-- Cardinality accounting for successive genuine subset deletions. -/
theorem deleted_card_chain (s t u : Finset ι) (ht : t ⊆ s) (hu : u ⊆ t) :
    (s \ u).card ≤ (s \ t).card+(t \ u).card := by
  have he : s \ u = (s \ t) ∪ (t \ u) := by
    ext i
    have hts : i ∈ t → i ∈ s := fun hi => ht hi
    have hut : i ∈ u → i ∈ t := fun hi => hu hi
    simp only [Finset.mem_sdiff, Finset.mem_union]
    tauto
  rw [he]
  exact Finset.card_union_le _ _

/-- All execution invariants, including terminal correctness whenever the
fuel covers the current potential. -/
theorem run_spec (F : HalvingPhaseMachine ι potential Good D) (fuel : ℕ) (s : Finset ι) :
    (F.run fuel s).1 ⊆ s ∧ (s \ (F.run fuel s).1).card ≤ fuel*D ∧
      (F.run fuel s).2 ≤ fuel ∧ (potential s < 2^fuel → Good (F.run fuel s).1) := by
  induction fuel generalizing s with
  | zero =>
    simp only [run, Finset.sdiff_self, Finset.card_empty, zero_mul, pow_zero]
    exact ⟨Finset.Subset.rfl, le_rfl, le_rfl, fun hp => (by have := F.positive s; omega)⟩
  | succ n ih =>
    cases hs : F.step s with
    | none =>
      simp only [run, hs, Finset.sdiff_self, Finset.card_empty]
      exact ⟨Finset.Subset.rfl, Nat.zero_le _, by omega, fun _ => F.done s hs⟩
    | some t =>
      simp only [run, hs]
      obtain ⟨hsub, hdeleted, hcalls, hgood⟩ := ih t
      have hts := F.next_subset s t hs
      refine ⟨hsub.trans hts, ?_, by omega, ?_⟩
      · have hd := (deleted_card_chain s t _ hts hsub).trans
          (Nat.add_le_add (F.deletes s t hs) hdeleted)
        exact hd.trans_eq (by ring)
      · intro hp
        apply hgood
        have hh := F.decreases s t hs
        rw [pow_succ] at hp
        omega

/-- A fixed finite fuel derived from the input potential suffices; no
termination premise or assumed successful endpoint is required. -/
def finish (F : HalvingPhaseMachine ι potential Good D) (s : Finset ι) : Finset ι × ℕ :=
  F.run (Nat.log 2 (potential s)+1) s

theorem finish_spec (F : HalvingPhaseMachine ι potential Good D) (s : Finset ι) :
    (F.finish s).1 ⊆ s ∧ Good (F.finish s).1 ∧
      (s \ (F.finish s).1).card ≤ (Nat.log 2 (potential s)+1)*D ∧
      (F.finish s).2 ≤ Nat.log 2 (potential s)+1 := by
  obtain ⟨hsub, hd, hc, hg⟩ := F.run_spec (Nat.log 2 (potential s)+1) s
  exact ⟨hsub, hg (Nat.lt_pow_succ_log_self (by decide) _), hd, hc⟩

end HalvingPhaseMachine
end Optss
