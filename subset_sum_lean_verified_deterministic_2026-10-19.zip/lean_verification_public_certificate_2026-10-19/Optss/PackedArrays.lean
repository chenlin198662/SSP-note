import Optss.IntegerConvolution
import Optss.PackedDigits
import Mathlib.Data.Finsupp.Interval

/-!
# Flat arrays for bounded exponent boxes

Division and remainder invert the mixed-radix exponent index. Explicit arrays
store one entry for each point of the retained box; the packed product array
reads back to the exact truncated polynomial product. This supplies a checked
representation bridge, while leaving the fast integer arithmetic cost separate.
-/

namespace Optss
open scoped BigOperators
noncomputable section

/-- Decode each digit by its own coordinate radix. -/
def boxDecode : {d : ℕ} → (Fin d → ℕ) → ℕ → (Fin d → ℕ)
  | 0, _, _ => Fin.elim0
  | _+1, m, k => Fin.cons (k % (m 0+1))
      (boxDecode (fun i => m i.succ) (k / (m 0+1)))

theorem boxDecode_le {d : ℕ} (m : Fin d → ℕ) (k : ℕ) :
    ∀ j, boxDecode m k j ≤ m j := by
  induction d generalizing k with
  | zero => intro j; exact Fin.elim0 j
  | succ d ih =>
    intro j
    refine Fin.cases ?_ (fun i => ?_) j
    · exact Nat.le_of_lt_succ (Nat.mod_lt _ (Nat.zero_lt_succ _))
    · exact ih (fun i => m i.succ) (k / (m 0+1)) i

theorem boxIndex_boxDecode {d : ℕ} (m : Fin d → ℕ) (k : ℕ)
    (hk : k < boxVolume m) : boxIndex m (boxDecode m k) = k := by
  induction d generalizing k with
  | zero => simpa [boxIndex] using (show 0 = k by simpa [boxVolume, eq_comm] using hk)
  | succ d ih =>
    have htail : k / (m 0+1) < boxVolume (fun i => m i.succ) := by
      apply (Nat.div_lt_iff_lt_mul (Nat.zero_lt_succ _)).mpr
      simpa only [boxVolume, Fin.prod_univ_succ, Nat.mul_comm] using hk
    simp only [boxIndex, boxDecode, Fin.cons_zero, Fin.cons_succ]
    rw [ih _ _ htail]
    exact Nat.mod_add_div _ _

theorem boxDecode_boxIndex {d : ℕ} (m x : Fin d → ℕ) (hx : ∀ j, x j ≤ m j) :
    boxDecode m (boxIndex m x) = x :=
  boxIndex_injOn m (boxDecode_le m _) hx (boxIndex_boxDecode m _ (boxIndex_lt m x hx))

/-- Finite-support exponent corresponding to an array index. -/
def boxExponent {d : ℕ} (m : Fin d → ℕ) (k : ℕ) : Fin d →₀ ℕ :=
  Finsupp.equivFunOnFinite.symm (boxDecode m k)

@[simp] theorem boxExponent_apply {d : ℕ} (m : Fin d → ℕ) (k : ℕ) (j : Fin d) :
    boxExponent m k j = boxDecode m k j := rfl

theorem boxExponent_le {d : ℕ} (Δ : Fin d →₀ ℕ) (k : ℕ) :
    boxExponent Δ k ≤ Δ := boxDecode_le Δ k

theorem boxExponent_boxIndex {d : ℕ} (Δ e : Fin d →₀ ℕ) (he : e ≤ Δ) :
    boxExponent Δ (boxIndex Δ e) = e := by
  apply Finsupp.ext
  exact congrFun (boxDecode_boxIndex Δ e he)

/-- A flat bounded-exponent array, with a checked entry for every legal index. -/
def polynomialArray {d : ℕ} {R : Type*} [CommSemiring R]
    (Δ : Fin d →₀ ℕ) (p : MvPolynomial (Fin d) R) : Array R :=
  Array.ofFn (fun i : Fin (boxVolume Δ) => p.coeff (boxExponent Δ i))

@[simp] theorem polynomialArray_size {d : ℕ} {R : Type*} [CommSemiring R]
    (Δ : Fin d →₀ ℕ) (p : MvPolynomial (Fin d) R) :
    (polynomialArray Δ p).size = boxVolume Δ := Array.size_ofFn

theorem polynomialArray_getElem {d : ℕ} {R : Type*} [CommSemiring R]
    (Δ : Fin d →₀ ℕ) (p : MvPolynomial (Fin d) R) (e : Fin d →₀ ℕ) (he : e ≤ Δ) :
    (polynomialArray Δ p)[boxIndex Δ e]'(by
      rw [polynomialArray_size]; exact boxIndex_lt Δ e he) = p.coeff e := by
  simp [polynomialArray, boxExponent_boxIndex Δ e he]

/-- Reconstruct a bounded polynomial from its array, interpreting a missing
entry as zero. Correctly sized arrays have no missing entries in the box. -/
def polynomialFromArray {d : ℕ} {R : Type*} [CommSemiring R]
    (Δ : Fin d →₀ ℕ) (a : Array R) : MvPolynomial (Fin d) R :=
  ∑ e ∈ Finset.Iic Δ, MvPolynomial.monomial e (a[boxIndex Δ e]?.getD 0)

theorem polynomialFromArray_coeff {d : ℕ} {R : Type*} [CommSemiring R]
    (Δ : Fin d →₀ ℕ) (a : Array R) (e : Fin d →₀ ℕ) :
    (polynomialFromArray Δ a).coeff e =
      if e ≤ Δ then a[boxIndex Δ e]?.getD 0 else 0 := by
  classical
  simp [polynomialFromArray, MvPolynomial.coeff_sum, MvPolynomial.coeff_monomial]

/-- Reading back the bounded array retains exactly the intended coefficients. -/
theorem polynomialFromArray_polynomialArray {d : ℕ} {R : Type*} [CommSemiring R]
    (Δ : Fin d →₀ ℕ) (p : MvPolynomial (Fin d) R) :
    polynomialFromArray Δ (polynomialArray Δ p) = truncatePolynomial Δ p := by
  ext e
  rw [polynomialFromArray_coeff, coeff_truncatePolynomial]
  by_cases he : e ≤ Δ
  · simp only [if_pos he]
    have hi : boxIndex Δ e < (polynomialArray Δ p).size := by
      rw [polynomialArray_size]; exact boxIndex_lt Δ e he
    rw [Array.getElem?_eq_getElem hi, Option.getD_some]
    exact polynomialArray_getElem Δ p e he
  · simp only [if_neg he]

/-- The exponent enumeration and the flat array have exactly the same size. -/
theorem exponentBox_card {d : ℕ} (Δ : Fin d →₀ ℕ) :
    (Finset.Iic Δ).card = boxVolume Δ := by
  classical
  rw [Finsupp.card_Iic]
  simp only [Nat.card_Iic]
  exact Finset.prod_subset (Finset.subset_univ Δ.support) (by
    intro j _ hj
    simp [Finsupp.not_mem_support_iff.mp hj])

/-- Prepared products are shared by every output coefficient. -/
structure PackedSignedProduct where
  base : ℕ
  positivePositive : ℕ
  positiveNegative : ℕ
  negativePositive : ℕ
  negativeNegative : ℕ

/-- One digit extraction from each of the four shared packed products. -/
def PackedSignedProduct.coefficient (data : PackedSignedProduct) (i : ℕ) : ℤ :=
  (data.positivePositive / data.base ^ i % data.base : ℕ) -
  (data.positiveNegative / data.base ^ i % data.base : ℕ) -
  (data.negativePositive / data.base ^ i % data.base : ℕ) +
  (data.negativeNegative / data.base ^ i % data.base : ℕ)

/-- Prepare the four input packings and four multiplications once, before
iterating over output cells. Bounds are established by the correctness theorem. -/
def preparePackedProduct {d : ℕ} (m n : Fin d → ℕ)
    (p q : MvPolynomial (Fin d) ℤ) (A C : ℕ) : PackedSignedProduct :=
  let b := boxVolume (m+n) * (A+1) * (C+1) + 1
  let pp := (flattenPolynomial ℕ (m+n) (naturalCoefficients p)).eval b
  let pn := (flattenPolynomial ℕ (m+n) (naturalCoefficients (-p))).eval b
  let qp := (flattenPolynomial ℕ (m+n) (naturalCoefficients q)).eval b
  let qn := (flattenPolynomial ℕ (m+n) (naturalCoefficients (-q))).eval b
  ⟨b, pp*qp, pp*qn, pn*qp, pn*qn⟩

theorem preparePackedProduct_coefficient {d : ℕ} (m n : Fin d → ℕ)
    (p q : MvPolynomial (Fin d) ℤ) (A C : ℕ) (e : Fin d →₀ ℕ) :
    (preparePackedProduct m n p q A C).coefficient (boxIndex (m+n) e) =
      packedIntegerCoefficient m n p q A C e := rfl

/-- Decode the four shared products sequentially, then combine their signs
entrywise. This materializes the padded product array only once. -/
def PackedSignedProduct.toArray (data : PackedSignedProduct) (n : ℕ) : Array ℤ :=
  let pp := (unpackDigits data.base n data.positivePositive).toArray
  let pn := (unpackDigits data.base n data.positiveNegative).toArray
  let np := (unpackDigits data.base n data.negativePositive).toArray
  let nn := (unpackDigits data.base n data.negativeNegative).toArray
  Array.ofFn (fun i : Fin n =>
    (pp[i.val]?.getD 0 : ℤ) - (pn[i.val]?.getD 0 : ℤ) -
    (np[i.val]?.getD 0 : ℤ) + (nn[i.val]?.getD 0 : ℤ))

@[simp] theorem PackedSignedProduct.toArray_size (data : PackedSignedProduct) (n : ℕ) :
    (data.toArray n).size = n := Array.size_ofFn

theorem PackedSignedProduct.toArray_getD (data : PackedSignedProduct) (n i : ℕ)
    (hi : i < n) : (data.toArray n)[i]?.getD 0 = data.coefficient i := by
  simp only [PackedSignedProduct.toArray, Array.getElem?_ofFn, dif_pos hi,
    Option.getD_some, List.getElem?_toArray]
  simp only [← List.getD_eq_getElem?_getD, unpackDigits_getD _ _ _ i hi]
  rfl

/-- Crop a once-prepared padded product array to the retained exponent box. -/
def sequentialPackedProductArray {d : ℕ} (Δ : Fin d →₀ ℕ)
    (p q : MvPolynomial (Fin d) ℤ) (A C : ℕ) : Array ℤ :=
  let data := preparePackedProduct Δ Δ (truncatePolynomial Δ p) (truncatePolynomial Δ q) A C
  let padded := data.toArray (boxVolume (Δ+Δ))
  Array.ofFn (fun i : Fin (boxVolume Δ) =>
    padded[boxIndex (Δ+Δ) (boxExponent Δ i)]?.getD 0)

/-- Product array whose entries are obtained from packed integer arithmetic. -/
def packedProductArray {d : ℕ} (Δ : Fin d →₀ ℕ)
    (p q : MvPolynomial (Fin d) ℤ) (A C : ℕ) : Array ℤ :=
  let data := preparePackedProduct Δ Δ (truncatePolynomial Δ p) (truncatePolynomial Δ q) A C
  Array.ofFn (fun i : Fin (boxVolume Δ) => data.coefficient (boxIndex (Δ+Δ) (boxExponent Δ i)))

@[simp] theorem packedProductArray_size {d : ℕ} (Δ : Fin d →₀ ℕ)
    (p q : MvPolynomial (Fin d) ℤ) (A C : ℕ) :
    (packedProductArray Δ p q A C).size = boxVolume Δ := Array.size_ofFn

/-- Equality is at the array representation, not just at polynomial support. -/
theorem packedProductArray_eq {d : ℕ} (Δ : Fin d →₀ ℕ)
    (p q : MvPolynomial (Fin d) ℤ) (A C : ℕ)
    (hA : ∀ e, ((truncatePolynomial Δ p).coeff e).natAbs ≤ A)
    (hC : ∀ e, ((truncatePolynomial Δ q).coeff e).natAbs ≤ C) :
    packedProductArray Δ p q A C = polynomialArray Δ (p*q) := by
  unfold packedProductArray polynomialArray
  dsimp only
  congr 1
  funext i
  exact packed_truncated_integer_product Δ p q A C hA hC _ (boxExponent_le Δ i)

/-- Complete array construction/readback realizes exact truncated multiplication. -/
theorem polynomialFromArray_packedProductArray {d : ℕ} (Δ : Fin d →₀ ℕ)
    (p q : MvPolynomial (Fin d) ℤ) (A C : ℕ)
    (hA : ∀ e, ((truncatePolynomial Δ p).coeff e).natAbs ≤ A)
    (hC : ∀ e, ((truncatePolynomial Δ q).coeff e).natAbs ≤ C) :
    polynomialFromArray Δ (packedProductArray Δ p q A C) = truncatePolynomial Δ (p*q) := by
  rw [packedProductArray_eq Δ p q A C hA hC, polynomialFromArray_polynomialArray]


theorem sequentialPackedProductArray_eq {d : ℕ} (Δ : Fin d →₀ ℕ)
    (p q : MvPolynomial (Fin d) ℤ) (A C : ℕ) :
    sequentialPackedProductArray Δ p q A C = packedProductArray Δ p q A C := by
  unfold sequentialPackedProductArray packedProductArray
  dsimp only
  congr 1
  funext i
  apply PackedSignedProduct.toArray_getD
  apply boxIndex_lt
  intro j
  exact (boxExponent_le Δ i j).trans (Nat.le_add_right _ _)

/-- The sequentially decoded and cropped array realizes the same exact integer
product; all four packed multiplications are shared across its output entries. -/
theorem sequentialPackedProductArray_correct {d : ℕ} (Δ : Fin d →₀ ℕ)
    (p q : MvPolynomial (Fin d) ℤ) (A C : ℕ)
    (hA : ∀ e, ((truncatePolynomial Δ p).coeff e).natAbs ≤ A)
    (hC : ∀ e, ((truncatePolynomial Δ q).coeff e).natAbs ≤ C) :
    sequentialPackedProductArray Δ p q A C = polynomialArray Δ (p*q) ∧
      polynomialFromArray Δ (sequentialPackedProductArray Δ p q A C) =
        truncatePolynomial Δ (p*q) := by
  rw [sequentialPackedProductArray_eq, packedProductArray_eq Δ p q A C hA hC]
  exact ⟨rfl, polynomialFromArray_polynomialArray Δ (p*q)⟩

end
end Optss
