import Optss.LongSumsetGrowth
import Optss.SeededGreedyProfile
import Optss.NonproperProgressionGrowth

/-!
# Long-sumset growth supplies the actual greedy profile

The only dynamic condition is the algorithm's explicit no-restart test.
Scalar repeated-sumset growth is transported to the actual remaining
coefficient vectors by properness on their `h`-fold box.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1200000
local instance longSumsetGreedyProfileDecEqInt : DecidableEq ℤ := Classical.decEq _
local instance longSumsetGreedyProfileDecEqIntVec {d : ℕ} : DecidableEq (IntVec d) :=
  @Fintype.decidablePiFintype (Fin d) (fun _ => ℤ) (fun _ => Int.instDecidableEq) (Fin.fintype d)

/-- The rounded square-root cutoff is above the required real power. -/
theorem greedySqrtCutoff_ge_ambient_power (N h : ℕ) (η : ℝ)
    (hscale : (N : ℝ)^η ≤ h) : (N : ℝ)^(η/2) ≤ greedySqrtCutoff h := by
  have hpow : ((N : ℝ)^(η/2))^2 = (N : ℝ)^η := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul (Nat.cast_nonneg N)]
    congr 1
    norm_num
  have hs := Real.sq_sqrt (Nat.cast_nonneg h)
  have hle : (N : ℝ)^(η/2) ≤ Real.sqrt h := by
    have hp := Real.rpow_nonneg (Nat.cast_nonneg N) (η/2)
    have hq := Real.sqrt_nonneg (h : ℝ)
    nlinarith
  exact hle.trans (Nat.le_ceil _)

/-- Every shorter repeated sumset has exactly its encoded cardinality when
one proper box contains the largest repeated sumset. -/
theorem repeated_card_of_proper_projection {G : Type*} [AddCommGroup G] [DecidableEq G]
    (ρ : G →+ ℤ) (U : Finset G) (hzero : 0 ∈ U) (h q : ℕ) (hq : q ≤ h)
    (hproper : Set.InjOn ρ (h • U : Finset G)) :
    (q • U.image ρ).card = (q • U).card := by
  rw [← Finset.image_nsmul ρ U q]
  apply Finset.card_image_iff.mpr
  exact hproper.mono (Finset.nsmul_subset_nsmul_right hzero hq)

/-- Box properness is sufficient for every live repeated sumset. -/
theorem greedyLiveValues_proper {ι : Type*} {d : ℕ} (v : ι → IntVec d)
    (st : GreedyBlockState ι (IntVec d)) (ρ : IntVec d →+ ℤ) (w : Fin d → ℕ) (h : ℕ)
    (hbox : ∀ i ∈ st.remaining, InCenteredBox w (v i))
    (hproper : Set.InjOn ρ (integerBudgetBox (fun j => h*w j))) :
    Set.InjOn ρ (h • greedyLiveValues v st : Finset (IntVec d)) := by
  apply hproper.mono
  have hU : greedyLiveValues v st ⊆ integerBudgetBox w := by
    intro x hx
    rcases Finset.mem_insert.mp hx with rfl | hx
    · simp [InBox]
    · obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hx
      exact (mem_integerBudgetBox _ _).mpr (hbox i hi)
  have hsub := Finset.nsmul_subset_nsmul hU
    (show (0 : IntVec d) ∈ integerBudgetBox w by simp [InBox]) (le_refl h)
  have hB : h • integerBudgetBox w ⊆ integerBudgetBox (fun j => h*w j) := by
    have hh := nsmul_integerBudgetBox_subset w h
    simpa only [Finset.subset_iff, ← Finset.mem_coe, Finset.coe_nsmul] using hh
  exact hsub.trans hB

/-- Constants depending only on `η` supply the profile for every actual
remaining state whose scalar `h`-sumset has not fallen below half the phase
potential. This discharges the external profile premise of the greedy proof. -/
theorem long_sumset_greedy_profile (η : ℝ) (hη : 0 < η) :
    ∃ a N₀ : ℕ, ∃ c : ℝ, 1 ≤ a ∧ 0 < c ∧
      ∀ (ι : Type) [LinearOrder ι] (d : ℕ) (v : ι → IntVec d)
        (st : GreedyBlockState ι (IntVec d)) (ρ : IntVec d →+ ℤ)
        (w : Fin d → ℕ) (N h M : ℕ),
        N₀ ≤ N → 1 ≤ h → (N : ℝ)^η ≤ h →
        (∀ i ∈ st.remaining, ρ (v i) ∈ Finset.Icc 0 (N : ℤ)) →
        (∀ i ∈ st.remaining, InCenteredBox w (v i)) →
        Set.InjOn ρ (integerBudgetBox (fun j => h*w j)) →
        (M : ℝ)/2 ≤ (h • greedyLiveValues v st).card →
        GreedyRepeatedProfile v st c M a h (greedySqrtCutoff h) := by
  obtain ⟨R, N₀, c, hc, hratio⟩ := long_sumset_growth_lower (η/2) (by positivity)
  refine ⟨max 1 R, N₀, c/2, le_max_left _ _, by positivity, ?_⟩
  intro ι _ d v st ρ w N h M hN hh hscale hscalar hbox hproper hnorestart q hq hqh
  let U := greedyLiveValues v st
  let X := U.image ρ
  have hzero : 0 ∈ U := Finset.mem_insert_self _ _
  have hXzero : 0 ∈ X := Finset.mem_image.mpr ⟨0, hzero, map_zero ρ⟩
  have hX : X ⊆ Finset.Icc 0 (N : ℤ) := by
    intro x hx
    obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
    rcases Finset.mem_insert.mp hy with rfl | hy
    · simp
    · obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hy
      exact hscalar i hi
  have hp := greedyLiveValues_proper v st ρ w h hbox hproper
  have hcard : ∀ s ≤ h, (s • X).card = (s • U).card :=
    fun s hs => repeated_card_of_proper_projection ρ U hzero h s hs hp
  have hqscale : (N : ℝ)^(η/2) ≤ q :=
    (greedySqrtCutoff_ge_ambient_power N h η hscale).trans (by exact_mod_cast hq)
  have hg := hratio N q h X hN hX hXzero hqscale hqh
  rw [hcard q hqh, hcard h le_rfl] at hg
  have hbase : (q : ℝ)/h ≤ 1 := (div_le_one (by exact_mod_cast (show 0 < h by omega))).mpr
    (by exact_mod_cast hqh)
  have hpow := pow_le_pow_of_le_one (by positivity : (0 : ℝ) ≤ (q : ℝ)/h)
    hbase (le_max_right 1 R)
  have hnon : (0 : ℝ) ≤ ((q : ℝ)/h)^R := by positivity
  calc
    c/2*M*((q : ℝ)/h)^(max 1 R) ≤ c/2*M*((q : ℝ)/h)^R :=
      mul_le_mul_of_nonneg_left hpow (by positivity)
    _ = c*((q : ℝ)/h)^R*((M : ℝ)/2) := by ring
    _ ≤ c*((q : ℝ)/h)^R*(h • U).card :=
      mul_le_mul_of_nonneg_left hnorestart (mul_nonneg hc.le hnon)
    _ ≤ (q • U).card := hg

/-- A seeded run never leaves its original available labels. -/
theorem seededProfileRun_remaining_subset {ι : Type} [LinearOrder ι] {d : ℕ}
    (v : ι → IntVec d) (available : Finset ι)
    (hfull : labelSpan ℝ (fun i => realVector (v i)) available = ⊤)
    (w : Fin d → ℕ) (hbox : ∀ i ∈ available, InCenteredBox w (v i)) (n : ℕ) :
    (greedyBlockRun v n (seededProfileInitialState v available hfull w hbox)).remaining ⊆ available := by
  have hs := (smallGreedySeed_spec v available hfull w hbox).1
  have hp := (greedyBlockRun_partition v (seededProfileInitialState v available hfull w hbox) n).trans
    (greedyBlockSeed_partition v available (smallGreedySeed v available hfull w hbox) hs)
  intro i hi
  have hm := Finset.mem_union_right
    (greedyBlockRun v n (seededProfileInitialState v available hfull w hbox)).chosen hi
  rw [hp] at hm
  exact hm

/-- The actual seed-and-greedy algorithm reaches a quarter-density block with
linear size, full starting lattice, and no reused labels. Its profile is proved
from long sumsets; the sole dynamic assumption is that the explicit restart
test does not fire before this block finishes. -/
theorem seeded_greedy_block_from_long_sumsets (η : ℝ) (hη : 0 < η) :
    ∃ a N₀ : ℕ, ∃ c : ℝ, 1 ≤ a ∧ 0 < c ∧
      ∀ (ι : Type) [LinearOrder ι] (d : ℕ) (v : ι → IntVec d) (available : Finset ι)
        (hfull : labelSpan ℝ (fun i => realVector (v i)) available = ⊤)
        (w : Fin d → ℕ) (hbox : ∀ i ∈ available, InCenteredBox w (v i))
        (ρ : IntVec d →+ ℤ) (N h M : ℕ),
        N₀ ≤ N → 1 ≤ N → 1 ≤ h → (N : ℝ)^η ≤ h → M ≤ h*N+1 →
        (∀ i ∈ available, ρ (v i) ∈ Finset.Icc 0 (N : ℤ)) →
        Set.InjOn ρ (integerBudgetBox (fun j => h*w j)) →
        (∀ n < greedyPaperScaleBudget c a h M,
          (greedyBlockRun v n (seededProfileInitialState v available hfull w hbox)).sums.card < greedyQuarterTarget M →
          (M : ℝ)/2 ≤ ((h • greedyLiveValues v
            (greedyBlockRun v n (seededProfileInitialState v available hfull w hbox))).card : ℝ)) →
        let out := seededGreedyProfileBlock v available hfull w hbox c a h M
        out.Valid v ∧ out.chosen ⊆ available ∧ out.remaining = available \ out.chosen ∧
        0 ∈ out.sums ∧ AddSubgroup.closure (out.sums : Set (IntVec d)) = generatedLattice v available ∧
        (M : ℝ)/4 ≤ out.sums.card ∧
        (out.chosen.card : ℝ) ≤ latticeSeedCardBound d w+greedyProfileConstant c a η*h ∧
        (∀ x ∈ out.sums, InCenteredBox (fun j => out.chosen.card*w j) x) ∧
        (∀ x ∈ out.sums, ∀ j, |(x j : ℝ)| ≤
          ((latticeSeedCardBound d w : ℝ)+greedyProfileConstant c a η*h)*w j) := by
  obtain ⟨a, N₀, c, ha, hc, hprofile⟩ := long_sumset_greedy_profile η hη
  refine ⟨a, N₀, c, ha, hc, ?_⟩
  intro ι _ d v available hfull w hbox ρ N h M hN₀ hN hh hscale hM hscalar hproper hnorestart
  apply seededGreedyProfileBlock_correct v available hfull w hbox c hc a h N M ha hh hN η hη hscale hM
  · intro n hn hsmall
    have hsub := seededProfileRun_remaining_subset v available hfull w hbox n
    have hp := hprofile ι d v (greedyBlockRun v n (seededProfileInitialState v available hfull w hbox))
      ρ w N h M hN₀ hh hscale (fun i hi => hscalar i (hsub hi))
      (fun i hi => hbox i (hsub hi)) hproper (hnorestart n hn hsmall)
    exact hp
  · exact hnorestart

end
end Optss
