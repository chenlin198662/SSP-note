import Optss.RationalLatticeReduction
import Optss.LatticeReductionBounds
import Optss.LatticeBoxingCounting

/-!
# Full-lattice reduction and boxing for rational quotient bodies

The verified integer reduction theorem discharges the adapter's remaining
defect premise. Every certified rational normalization therefore admits a
basis of the complete standard lattice with a dimension-only normalized
orthogonality defect. For actual integer images of positive-width boxes,
normalization, reduction, geometric boxing, and uniform lattice counting are
combined without any supplied-basis or reduction assumption.

These are mathematical existence and counting theorems; no algorithmic
bit-complexity bound is asserted.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {r d : ℕ}

/-- A rational normalization has an actual basis of the entire standard lattice
with the proved dimension-only defect bound. The integer reduction premise is
fully discharged by the potential and size-reduction construction. -/
theorem exists_standard_lattice_basis_bounded_defect
    (a : (Fin r → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin r))
    (c : RationalNormalizationData a) :
    ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
      basisIntegerLattice b = Set.range (@realVector r) ∧
      euclideanOrthogonalityDefect (b.map a.toLinearEquiv) ≤ latticeReductionDefectBound r := by
  obtain ⟨B, hspan, hB, hdefect⟩ :=
    exists_integer_bounded_defect c.integerColumns.transpose c.integerColumns_linearIndependent
  exact exists_standard_lattice_basis_of_integer_reduction a c B hB hspan
    (latticeReductionDefectBound r)
    (hdefect (basisOfEuclideanIntegerRows B hB) (basisOfEuclideanIntegerRows_apply B hB))

/-- The full-lattice boxing theorem for an actual surjective integer image of
an integer-width box. The same full standard lattice is used for every real
dilation in the counting conclusion, with no additional basis certificate. -/
theorem integerLinearImageBox_full_lattice_boxing (hr : 0 < r)
    (π : IntVec d →ₗ[ℤ] IntVec r) (hπ : Function.Surjective π)
    (β : Fin d → ℕ) (hβ : ∀ j, 1 ≤ β j) :
    ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
      basisIntegerLattice b = Set.range (@realVector r) ∧
      ∃ n : Fin r → ℕ, (∀ j, 1 ≤ n j) ∧
        integerLinearImageBox π β ⊆ basisCoefficientBox b n ∧
        basisCoefficientBox b n ⊆
          latticeBoxingDilation r ((r.factorial:ℝ)*latticeReductionDefectBound r) •
            integerLinearImageBox π β ∧
        ∀ s : ℝ,
          (integerPoints (s • basisCoefficientBox b n)
            ((basisCoefficientBox_compact b n).smul s).isBounded).card ≤
          (latticeBoxingResidueModulus r (latticeReductionDefectBound r))^r *
            (integerPoints (s • integerLinearImageBox π β)
              ((integerLinearImageBox_compact π β).smul s).isBounded).card := by
  obtain ⟨a, hinner, houter, ⟨c⟩⟩ :=
    integerLinearImageBox_rational_normalization hr π hπ β hβ
  obtain ⟨b, hΛ, hdefect⟩ := exists_standard_lattice_basis_bounded_defect a c
  obtain ⟨u, hu, huK⟩ := integerLinearImageBox_independent π hπ β hβ
  have huΛ (i : Fin r) : realVector (u i) ∈ basisIntegerLattice b := by
    rw [hΛ]
    exact ⟨u i, rfl⟩
  obtain ⟨n, hn, hsub, hencl, hcount⟩ := lattice_boxing_and_counting_of_normalization hr
    (integerLinearImageBox π β) (integerLinearImageBox_compact π β)
    (integerLinearImageBox_convex π β)
    (fun _ hx => integerLinearImageBox_symmetric π β hx) a hinner houter
    b (latticeReductionDefectBound r) (latticeReductionDefectBound_pos r)
    hdefect (fun i => realVector (u i)) hu huK huΛ
  refine ⟨b, hΛ, n, hn, hsub, hencl, fun s => ?_⟩
  simpa only [basisLatticePoints_standard_card b hΛ] using hcount s

/-- The unit-dilation consequence controls the actual coefficient-box volume
by the quotient body's entire set of integer points. -/
theorem integerLinearImageBox_full_lattice_boxing_card (hr : 0 < r)
    (π : IntVec d →ₗ[ℤ] IntVec r) (hπ : Function.Surjective π)
    (β : Fin d → ℕ) (hβ : ∀ j, 1 ≤ β j) :
    ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
      basisIntegerLattice b = Set.range (@realVector r) ∧
      ∃ n : Fin r → ℕ, (∀ j, 1 ≤ n j) ∧
        integerLinearImageBox π β ⊆ basisCoefficientBox b n ∧
        (∏ j, (2*n j+1)) ≤
          (latticeBoxingResidueModulus r (latticeReductionDefectBound r))^r *
            (integerPoints (integerLinearImageBox π β)
              (integerLinearImageBox_compact π β).isBounded).card := by
  obtain ⟨b, hΛ, n, hn, hsub, _, hc⟩ := integerLinearImageBox_full_lattice_boxing hr π hπ β hβ
  refine ⟨b, hΛ, n, hn, hsub, ?_⟩
  have h := hc 1
  simp only [one_smul] at h
  rw [← basisLatticePoints_standard_card b hΛ,
    basisLatticePoints_box_card] at h
  exact h

end
end Optss
