import Optss.ListBooleanConvolution

/-! Constant-stage repeated sums and differences on actual Boolean lists.
The source routines cache each doubling once and reuse that stored array for
both arguments of the next convolution. -/
namespace Optss
open scoped Pointwise
set_option maxRecDepth 4096

noncomputable def cyclicIndicatorList (n : ℕ) (A : Finset (ZMod (2^n))) : List Bool :=
  List.ofFn fun k : Fin (2^n) => decide ((k.val : ZMod (2^n))∈A)

theorem cyclicIndicatorList_length (n : ℕ) (A : Finset (ZMod (2^n))) :
    (cyclicIndicatorList n A).length=2^n := List.length_ofFn

theorem cyclicBooleanSupport_indicator (n : ℕ) (A : Finset (ZMod (2^n))) :
    cyclicBooleanSupport n (Vector.ofFn fun k : Fin (2^n) => decide ((k.val : ZMod (2^n))∈A))=A := by
  ext x
  simp only [cyclicBooleanSupport,Finset.mem_filter,Finset.mem_univ,true_and,vector_get_ofFn,
    cyclicArrayIndex,ZMod.natCast_zmod_val,decide_eq_true_eq]

theorem listBooleanConvolution_indicator (depth : List Bool) (A B : Finset (ZMod (2^depth.length))) :
    listBooleanConvolution depth (cyclicIndicatorList depth.length A) (cyclicIndicatorList depth.length B)=
      cyclicIndicatorList depth.length (A+B) := by
  have h := listBooleanConvolution_support depth
    (Vector.ofFn fun k : Fin (2^depth.length) => decide ((k.val : ZMod (2^depth.length))∈A))
    (Vector.ofFn fun k : Fin (2^depth.length) => decide ((k.val : ZMod (2^depth.length))∈B))
  have hA : (Vector.ofFn fun k : Fin (2^depth.length) => decide ((k.val : ZMod (2^depth.length))∈A)).get=
      (fun k : Fin (2^depth.length) => decide ((k.val : ZMod (2^depth.length))∈A)) := by
    funext k; rw [vector_get_ofFn]
  have hB : (Vector.ofFn fun k : Fin (2^depth.length) => decide ((k.val : ZMod (2^depth.length))∈B)).get=
      (fun k : Fin (2^depth.length) => decide ((k.val : ZMod (2^depth.length))∈B)) := by
    funext k; rw [vector_get_ofFn]
  simpa only [hA,hB,cyclicBooleanSupport_indicator,cyclicIndicatorList] using h

theorem listCyclicReflect_indicator (n : ℕ) (A : Finset (ZMod (2^n))) :
    listCyclicReflect (cyclicIndicatorList n A)=cyclicIndicatorList n (-A) := by
  let V := Vector.ofFn fun k : Fin (2^n) => decide ((k.val : ZMod (2^n))∈A)
  have hV : List.ofFn V.get=cyclicIndicatorList n A := by
    apply congrArg List.ofFn
    funext k
    rw [vector_get_ofFn]
  rw [←hV,listCyclicReflect_ofFn]
  apply congrArg List.ofFn
  funext k
  simp only [V,vector_get_ofFn,cyclicArrayIndex,ZMod.natCast_zmod_val]
  congr 1
  simp

def listBooleanDoublings (depth : List Bool) : List Bool → List Bool → List Bool
  | [],input => input
  | _::steps,input =>
    let doubled := listBooleanConvolution depth input input
    listBooleanDoublings depth steps doubled

def listBooleanDifference (depth : List Bool) (steps input : List Bool) : List Bool :=
  let sums := listBooleanDoublings depth steps input
  listBooleanConvolution depth sums (listCyclicReflect sums)

theorem listBooleanDoublings_indicator (depth steps : List Bool) (A : Finset (ZMod (2^depth.length))) :
    listBooleanDoublings depth steps (cyclicIndicatorList depth.length A)=
      cyclicIndicatorList depth.length ((2^steps.length) • A) := by
  induction steps generalizing A with
  | nil => simp [listBooleanDoublings]
  | cons b steps ih =>
    rw [listBooleanDoublings,listBooleanConvolution_indicator,ih]
    simp only [List.length_cons,pow_succ,nsmul_add]
    congr 1
    rw [show 2^steps.length*2=2^steps.length+2^steps.length by omega,add_nsmul]

theorem listBooleanDifference_indicator (depth steps : List Bool) (A : Finset (ZMod (2^depth.length))) :
    listBooleanDifference depth steps (cyclicIndicatorList depth.length A)=
      cyclicIndicatorList depth.length (((2^steps.length) • A)-((2^steps.length) • A)) := by
  rw [listBooleanDifference,listBooleanDoublings_indicator,listCyclicReflect_indicator,listBooleanConvolution_indicator]
  congr 1
  ext x
  simp only [Finset.mem_add,Finset.mem_neg,Finset.mem_sub]
  constructor
  · rintro ⟨a,ha,b,⟨c,hc,rfl⟩,rfl⟩
    exact ⟨a,ha,c,hc,by abel⟩
  · rintro ⟨a,ha,b,hb,rfl⟩
    exact ⟨a,ha,-b,⟨b,hb,rfl⟩,by abel⟩

end Optss
