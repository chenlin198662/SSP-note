import Optss.Basic
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.Group.Pointwise.Finset.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Order.Interval.Finset.Nat

/-!
# The finite modeling sieve

This file proves the finite algebraic step of Lemma 10.2: counting the marked
multipliers and reflecting bounded integer relations with an unmarked
multiplier. It does not assert the subsequent Fourier, lattice, progression,
prime-search, or running-time conclusions.
-/

namespace Optss

open scoped BigOperators Pointwise

/-- The representative of `lam * a (mod q)` in the standard residue interval. -/
def modelingResidue {q : ℕ} (lam : ZMod q) (a : ℤ) : ℤ :=
  (lam * (a : ZMod q)).val

theorem modelingResidue_congr {q : ℕ} [NeZero q] (lam : ZMod q) (a : ℤ) :
    (modelingResidue lam a : ZMod q) = lam * (a : ZMod q) := by
  simpa only [modelingResidue, Int.cast_natCast] using
    ZMod.natCast_zmod_val (lam * (a : ZMod q))

theorem modelingResidue_bounds {q : ℕ} [NeZero q] (lam : ZMod q) (a : ℤ) :
    0 ≤ modelingResidue lam a ∧ modelingResidue lam a < q := by
  constructor
  · exact Int.natCast_nonneg _
  · unfold modelingResidue
    exact_mod_cast ZMod.val_lt (lam * (a : ZMod q))

/-- The actual marks from equation (75), including possible repetitions before
taking the finite image. -/
def modelingMarks (D : Finset ℤ) (p q : ℕ) [Fact q.Prime] : Finset (ZMod q) :=
  ((D.erase 0) ×ˢ Finset.Icc 1 ((q - 1) / p)).image
    (fun et => ((et.2 * p : ℕ) : ZMod q) / (et.1 : ZMod q))

theorem modelingMarks_card_le (D : Finset ℤ) (p q : ℕ) [Fact q.Prime] :
    (modelingMarks D p q).card ≤ (D.erase 0).card * ((q - 1) / p) := by
  calc
    _ ≤ ((D.erase 0) ×ˢ Finset.Icc 1 ((q - 1) / p)).card := Finset.card_image_le
    _ = _ := by rw [Finset.card_product]; simp

/-- A bounded integer that vanishes modulo `q` must itself be zero. -/
theorem bounded_intCast_eq_zero {q : ℕ} {z : ℤ} (hz : |z| < (q : ℤ))
    (he : (z : ZMod q) = 0) : z = 0 := by
  apply abs_eq_zero.mp
  exact Int.eq_zero_of_dvd_of_nonneg_of_lt (abs_nonneg z) hz
    ((dvd_abs _ _).mpr ((ZMod.intCast_zmod_eq_zero_iff_dvd z q).mp he))

/-- Avoiding the explicitly counted marks supplies a nonzero multiplier with
all of the congruence exclusions used in the modeling argument. -/
theorem exists_modeling_multiplier (D : Finset ℤ) (p q : ℕ) [Fact q.Prime]
    (hD : ∀ e ∈ D, |e| < (q : ℤ))
    (hcount : (D.erase 0).card * ((q - 1) / p) < q - 1) :
    ∃ lam : ZMod q, lam ≠ 0 ∧ ∀ e ∈ D, e ≠ 0 →
      ∀ t ∈ Finset.Icc 1 ((q - 1) / p), lam * (e : ZMod q) ≠ (t * p : ℕ) := by
  have hc : (modelingMarks D p q).card <
      ((Finset.univ : Finset (ZMod q)).erase 0).card := by
    rw [Finset.card_erase_of_mem (Finset.mem_univ _), Finset.card_univ, ZMod.card]
    exact (modelingMarks_card_le D p q).trans_lt hcount
  obtain ⟨lam, hlam, hmark⟩ := Finset.exists_mem_not_mem_of_card_lt_card hc
  refine ⟨lam, (Finset.mem_erase.mp hlam).1, ?_⟩
  intro e he he0 t ht hbad
  have heq : (e : ZMod q) ≠ 0 := fun hz => he0 (bounded_intCast_eq_zero (hD e he) hz)
  apply hmark
  apply Finset.mem_image.mpr
  refine ⟨(e, t), Finset.mem_product.mpr ⟨Finset.mem_erase.mpr ⟨he0, he⟩, ht⟩, ?_⟩
  exact ((eq_div_iff heq).mpr hbad).symm

/-- The number of marks is already sufficient when the prime model modulus
exceeds the number of nonzero differences. The manuscript uses a stronger
factor-eight margin. -/
theorem modeling_sieve_count {D : Finset ℤ} {p q : ℕ}
    (hq : 1 < q) (hp : (D.erase 0).card < p) :
    (D.erase 0).card * ((q - 1) / p) < q - 1 := by
  have hm := Nat.div_mul_le_self (q - 1) p
  by_cases ht : (q - 1) / p = 0
  · simp [ht]; omega
  · have ht' : 0 < (q - 1) / p := Nat.pos_of_ne_zero ht
    nlinarith

/-- The factor-eight marking margin in the manuscript, expressed without
division of cardinalities. -/
theorem modelingMarks_eighth_bound (D : Finset ℤ) (p q : ℕ) [Fact q.Prime]
    (hp : 8 * (D.erase 0).card < p) :
    8 * (modelingMarks D p q).card < q - 1 := by
  have hq : 1 < q := (Fact.out : q.Prime).one_lt
  have hc := modelingMarks_card_le D p q
  have hm := Nat.div_mul_le_self (q - 1) p
  by_cases ht : (q - 1) / p = 0
  · simp only [ht, Nat.mul_zero] at hc
    omega
  · have ht' : 0 < (q - 1) / p := Nat.pos_of_ne_zero ht
    nlinarith

/-- Core modeling lemma: `z` is the bounded difference of two residue sums and
`e` the difference of the original sums. Divisibility by `p` reflects precisely
the zero original relation, by excluding both signs of each marked difference. -/
theorem modeling_relation_iff {p q : ℕ} [Fact q.Prime] (hp : 0 < p)
    (D : Finset ℤ) (lam : ZMod q) (hlam : lam ≠ 0)
    (havoid : ∀ e ∈ D, e ≠ 0 → ∀ t ∈ Finset.Icc 1 ((q - 1) / p),
      lam * (e : ZMod q) ≠ (t * p : ℕ))
    {e z : ℤ} (he : e ∈ D) (hne : -e ∈ D)
    (hebound : |e| < (q : ℤ)) (hzbound : |z| < (q : ℤ))
    (hcong : (z : ZMod q) = lam * (e : ZMod q)) :
    (z : ZMod p) = 0 ↔ e = 0 := by
  constructor
  · intro hzmod
    by_contra he0
    have heq : (e : ZMod q) ≠ 0 := fun hz => he0 (bounded_intCast_eq_zero hebound hz)
    have hz0 : z ≠ 0 := by
      intro hz
      rw [hz, Int.cast_zero] at hcong
      exact mul_ne_zero hlam heq hcong.symm
    have hdiv : p ∣ z.natAbs := Int.natCast_dvd.mp
      ((ZMod.intCast_zmod_eq_zero_iff_dvd z p).mp hzmod)
    have hzpos : 0 < z.natAbs := Int.natAbs_pos.mpr hz0
    have hplt : p ≤ z.natAbs := Nat.le_of_dvd hzpos hdiv
    have hzlt : z.natAbs < q := by
      exact_mod_cast (show (z.natAbs : ℤ) < (q : ℤ) by
        simpa only [Int.natCast_natAbs] using hzbound)
    let t := z.natAbs / p
    have ht : t ∈ Finset.Icc 1 ((q - 1) / p) := by
      apply Finset.mem_Icc.mpr
      exact ⟨Nat.div_pos hplt hp, Nat.div_le_div_right (by omega)⟩
    have htp : t * p = z.natAbs := Nat.div_mul_cancel hdiv
    have hcast : ((t * p : ℕ) : ZMod q) = (|z| : ℤ) := by
      rw [htp]
      simpa only [Int.cast_natCast] using
        congrArg (fun a : ℤ => (a : ZMod q)) (Int.natCast_natAbs z)
    by_cases hzsign : 0 ≤ z
    · apply havoid e he he0 t ht
      rw [hcast, abs_of_nonneg hzsign]
      exact hcong.symm
    · apply havoid (-e) hne (neg_ne_zero.mpr he0) t ht
      rw [hcast, abs_of_neg (lt_of_not_ge hzsign), Int.cast_neg, Int.cast_neg, mul_neg]
      exact congrArg Neg.neg hcong.symm
  · intro he0
    have hzq : (z : ZMod q) = 0 := by simpa [he0] using hcong
    have hz0 := bounded_intCast_eq_zero hzbound hzq
    simp [hz0]

/-- The exact finite difference set used for order-`n` modeling. -/
def modelingDifferences (S : Finset ℤ) (n : ℕ) : Finset ℤ := n • S - n • S

private theorem sum_mem_repeated_set {S : Finset ℤ} {n : ℕ}
    (a : Fin n → ℤ) (ha : ∀ i, a i ∈ S) : (∑ i, a i) ∈ n • S := by
  apply Finset.mem_nsmul.mpr
  exact ⟨fun i => ⟨a i, ha i⟩, by simp [List.sum_ofFn]⟩

private theorem sum_difference_mem {S : Finset ℤ} {n : ℕ}
    (a b : Fin n → ℤ) (ha : ∀ i, a i ∈ S) (hb : ∀ i, b i ∈ S) :
    (∑ i, a i) - (∑ i, b i) ∈ modelingDifferences S n :=
  Finset.mem_sub.mpr ⟨_, sum_mem_repeated_set a ha, _, sum_mem_repeated_set b hb, rfl⟩

/-- Differences of `n` sums taken from an interval of width `U-L` have magnitude
at most `n(U-L)`. -/
theorem interval_sum_difference_bound {n : ℕ} (a b : Fin n → ℤ) (L U : ℤ)
    (ha : ∀ i, L ≤ a i ∧ a i ≤ U) (hb : ∀ i, L ≤ b i ∧ b i ≤ U) :
    |(∑ i, a i) - (∑ i, b i)| ≤ n * (U - L) := by
  have haL : (n : ℤ) * L ≤ ∑ i, a i := by
    simpa using Finset.sum_le_sum (fun i (_ : i ∈ Finset.univ) => (ha i).1)
  have haU : (∑ i, a i) ≤ (n : ℤ) * U := by
    simpa using Finset.sum_le_sum (fun i (_ : i ∈ Finset.univ) => (ha i).2)
  have hbL : (n : ℤ) * L ≤ ∑ i, b i := by
    simpa using Finset.sum_le_sum (fun i (_ : i ∈ Finset.univ) => (hb i).1)
  have hbU : (∑ i, b i) ≤ (n : ℤ) * U := by
    simpa using Finset.sum_le_sum (fun i (_ : i ∈ Finset.univ) => (hb i).2)
  apply abs_le.mpr
  constructor <;> nlinarith

/-- The difference set is bounded by the original ambient interval; this
supplies the nonvanishing-modulo-`q` hypothesis in the sieve. -/
theorem modelingDifferences_abs_le (S : Finset ℤ) (n : ℕ) (u : ℤ)
    (hS : ∀ a ∈ S, 0 ≤ a ∧ a ≤ u) :
    ∀ e ∈ modelingDifferences S n, |e| ≤ (n : ℤ) * u := by
  intro e he
  obtain ⟨x, hx, y, hy, rfl⟩ := Finset.mem_sub.mp he
  obtain ⟨a, ha⟩ := Finset.mem_nsmul.mp hx
  obtain ⟨b, hb⟩ := Finset.mem_nsmul.mp hy
  rw [List.sum_ofFn] at ha hb
  rw [← ha, ← hb]
  simpa only [sub_zero] using interval_sum_difference_bound
    (fun i => (a i : ℤ)) (fun i => (b i : ℤ)) 0 u
    (fun i => hS _ (a i).property) (fun i => hS _ (b i).property)

/-- Sieve existence with all bounded-difference assumptions discharged from
the original ambient interval and an explicit modulus/cardinality inequality. -/
theorem exists_modeling_multiplier_of_interval (S : Finset ℤ) (n p q : ℕ)
    [Fact q.Prime] (u : ℤ) (hS : ∀ a ∈ S, 0 ≤ a ∧ a ≤ u)
    (hq : (n : ℤ) * u < q) (hp : ((modelingDifferences S n).erase 0).card < p) :
    ∃ lam : ZMod q, lam ≠ 0 ∧ ∀ e ∈ modelingDifferences S n, e ≠ 0 →
      ∀ t ∈ Finset.Icc 1 ((q - 1) / p), lam * (e : ZMod q) ≠ (t * p : ℕ) := by
  apply exists_modeling_multiplier
  · intro e he
    exact (modelingDifferences_abs_le S n u hS e he).trans_lt hq
  · exact modeling_sieve_count (Fact.out : q.Prime).one_lt hp

/-- The actual Freiman equivalence on any selected part whose residue values
lie in a sufficiently short interval. For `n = 8`, the hypothesis is exactly
that the interval diameter is less than `q/8`. Neither direction of the
Freiman conclusion is assumed. -/
theorem modeling_freiman_iff {p q n : ℕ} [Fact q.Prime] (hp : 0 < p)
    (S : Finset ℤ) (lam : ZMod q) (hlam : lam ≠ 0)
    (hD : ∀ e ∈ modelingDifferences S n, |e| < (q : ℤ))
    (havoid : ∀ e ∈ modelingDifferences S n, e ≠ 0 →
      ∀ t ∈ Finset.Icc 1 ((q - 1) / p), lam * (e : ZMod q) ≠ (t * p : ℕ))
    (r : ℤ → ℤ) (hr : ∀ a ∈ S, (r a : ZMod q) = lam * (a : ZMod q))
    (L U : ℤ) (hwidth : (n : ℤ) * (U - L) < q)
    (a b : Fin n → ℤ) (ha : ∀ i, a i ∈ S) (hb : ∀ i, b i ∈ S)
    (hra : ∀ i, L ≤ r (a i) ∧ r (a i) ≤ U)
    (hrb : ∀ i, L ≤ r (b i) ∧ r (b i) ≤ U) :
    (∑ i, (r (a i) : ZMod p)) = (∑ i, (r (b i) : ZMod p)) ↔
      (∑ i, a i) = (∑ i, b i) := by
  have he := sum_difference_mem a b ha hb
  have hne : -((∑ i, a i) - (∑ i, b i)) ∈ modelingDifferences S n := by
    simpa only [neg_sub] using sum_difference_mem b a hb ha
  have hz := (interval_sum_difference_bound (fun i => r (a i))
    (fun i => r (b i)) L U hra hrb).trans_lt hwidth
  have hcong : (((∑ i, r (a i)) - (∑ i, r (b i)) : ℤ) : ZMod q) =
      lam * (((∑ i, a i) - (∑ i, b i) : ℤ) : ZMod q) := by
    push_cast
    simp only [hr _ (ha _), hr _ (hb _), ← Finset.mul_sum, ← mul_sub]
  have hiff := modeling_relation_iff hp (modelingDifferences S n) lam hlam havoid
    he hne (hD _ he) hz hcong
  simpa only [Int.cast_sub, Int.cast_sum, sub_eq_zero] using hiff

/-- For every positive relation order, the model is injective on the selected
short-interval part. Constant tuples recover injectivity from the equivalence. -/
theorem modeling_injective_on_part {p q n : ℕ} [Fact q.Prime]
    (hp : 0 < p) (hn : 0 < n) (S T : Finset ℤ) (hTS : T ⊆ S)
    (lam : ZMod q) (hlam : lam ≠ 0)
    (hD : ∀ e ∈ modelingDifferences S n, |e| < (q : ℤ))
    (havoid : ∀ e ∈ modelingDifferences S n, e ≠ 0 →
      ∀ t ∈ Finset.Icc 1 ((q - 1) / p), lam * (e : ZMod q) ≠ (t * p : ℕ))
    (r : ℤ → ℤ) (hr : ∀ a ∈ S, (r a : ZMod q) = lam * (a : ZMod q))
    (L U : ℤ) (hwidth : (n : ℤ) * (U - L) < q)
    (hinterval : ∀ a ∈ T, L ≤ r a ∧ r a ≤ U) :
    Set.InjOn (fun a => (r a : ZMod p)) (T : Set ℤ) := by
  intro a ha b hb hab
  have he := (modeling_freiman_iff hp S lam hlam hD havoid r hr L U hwidth
    (fun _ => a) (fun _ => b) (fun _ => hTS ha) (fun _ => hTS hb)
    (fun _ => hinterval a ha) (fun _ => hinterval b hb)).mp (by simp [hab])
  have hn' : (0 : ℤ) < n := by exact_mod_cast hn
  simpa only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul,
    mul_right_inj' (ne_of_gt hn')] using he

/-- The finite modeling conclusion at the manuscript's relation order eight.
The multiplier comes from the explicit sieve, and the map uses actual least
nonnegative representatives. The theorem applies to every short residue
interval part; choosing a large part and the later GAP construction are
separate steps. -/
theorem exists_freiman_eight_model (S : Finset ℤ) (p q : ℕ) [Fact q.Prime]
    (u : ℤ) (hS : ∀ a ∈ S, 0 ≤ a ∧ a ≤ u) (hq : 8 * u < q)
    (hp : ((modelingDifferences S 8).erase 0).card < p) :
    ∃ lam : ZMod q, lam ≠ 0 ∧ ∀ L U : ℤ, 8 * (U - L) < q →
      ∀ a b : Fin 8 → ℤ, (∀ i, a i ∈ S) → (∀ i, b i ∈ S) →
      (∀ i, L ≤ modelingResidue lam (a i) ∧ modelingResidue lam (a i) ≤ U) →
      (∀ i, L ≤ modelingResidue lam (b i) ∧ modelingResidue lam (b i) ≤ U) →
      ((∑ i, (modelingResidue lam (a i) : ZMod p)) =
        (∑ i, (modelingResidue lam (b i) : ZMod p)) ↔
        (∑ i, a i) = (∑ i, b i)) := by
  obtain ⟨lam, hlam, havoid⟩ :=
    exists_modeling_multiplier_of_interval S 8 p q u hS hq hp
  refine ⟨lam, hlam, ?_⟩
  intro L U hwidth a b ha hb hra hrb
  have hp0 : 0 < p := lt_of_le_of_lt (Nat.zero_le _) hp
  exact modeling_freiman_iff hp0 S lam hlam
    (fun e he => (modelingDifferences_abs_le S 8 u hS e he).trans_lt hq)
    havoid (modelingResidue lam) (fun a _ => modelingResidue_congr lam a)
    L U hwidth a b ha hb hra hrb

end Optss
