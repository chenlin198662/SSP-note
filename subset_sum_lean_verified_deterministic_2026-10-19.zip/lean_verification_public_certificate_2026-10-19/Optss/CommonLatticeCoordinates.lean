import Optss.CommonProperFilling

/-!
# Exact item coordinates in the common full lattice

The full-lattice synthesis map has an actual inverse on every retained item.
It preserves labelled subset supports, transfers whole-lattice generation, and
carries real-rank protection through the basis equivalence. Thus the geometric
filling theorem yields actual reserve-coordinate witnesses.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1000000

/-- The unique coefficient vector on the synthesis range, and zero elsewhere. -/
def commonLatticeCoordinate {d : ℕ} {G : Type*} [AddCommGroup G]
    (σ : IntVec d →+ G) (x : G) : IntVec d :=
  if hx : x ∈ σ.range then Classical.choose hx else 0

theorem commonLatticeCoordinate_represents {d : ℕ} {G : Type*} [AddCommGroup G]
    (σ : IntVec d →+ G) (x : G) (hx : x ∈ σ.range) :
    σ (commonLatticeCoordinate σ x) = x := by
  simp only [commonLatticeCoordinate, dif_pos hx]
  exact Classical.choose_spec hx

theorem commonLatticeCoordinate_zero {d : ℕ} {G : Type*} [AddCommGroup G]
    (σ : IntVec d →+ G) (hσ : Function.Injective σ) : commonLatticeCoordinate σ 0 = 0 := by
  apply hσ
  rw [commonLatticeCoordinate_represents σ 0 (σ.range.zero_mem), map_zero]

/-- The integer inverse is precisely the real basis-coordinate map on the
whole subgroup, not only on the span of selected witnesses. -/
theorem commonLatticeCoordinate_cast {d : ℕ} (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (x : IntVec d) (hx : x ∈ Γ) :
    realVector (commonLatticeCoordinate (subgroupBasisSynthesisHom Γ b hΛ) x) = b.equivFun (realVector x) := by
  have hr : x ∈ (subgroupBasisSynthesisHom Γ b hΛ).range := by rwa [subgroupBasisSynthesisHom_range]
  have he := congrArg realVector (commonLatticeCoordinate_represents (subgroupBasisSynthesisHom Γ b hΛ) x hr)
  rw [subgroupBasisSynthesisHom_cast] at he
  have he' := congrArg b.equivFun he
  simpa only [LinearEquiv.apply_symm_apply] using he'

/-- Actual item coordinates lie in the same new integer coefficient box. -/
theorem commonLatticeCoordinate_box {d : ℕ} (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (n : Fin d → ℕ) (x : IntVec d) (hx : x ∈ Γ)
    (hbox : realVector x ∈ basisCoefficientBox b n) :
    InCenteredBox n (commonLatticeCoordinate (subgroupBasisSynthesisHom Γ b hΛ) x) := by
  have he := commonLatticeCoordinate_cast Γ b hΛ x hx
  intro j
  have hb := hbox j
  change |b.equivFun (realVector x) j| ≤ (n j : ℝ) at hb
  rw [← he] at hb
  change |((_ : IntVec d) j : ℝ)| ≤ (n j : ℝ) at hb
  exact_mod_cast hb

/-- Changing to full-lattice coordinates preserves the exact support of every
finite collection of actual labels. -/
theorem labelledSubsetSupport_image_hom {ι G H : Type*} [DecidableEq ι]
    [AddCommGroup G] [AddCommGroup H] [DecidableEq G] [DecidableEq H]
    (σ : G →+ H) (u : ι → G) (v : ι → H) (R : Finset ι)
    (hrepr : ∀ i ∈ R, σ (u i) = v i) :
    (labelledSubsetSupport u R).image σ = labelledSubsetSupport v R := by
  have hsum : ∀ s ⊆ R, σ (∑ i ∈ s, u i) = ∑ i ∈ s, v i := by
    intro s hs
    rw [map_sum]
    exact Finset.sum_congr rfl (fun i hi => hrepr i (hs hi))
  ext x
  constructor
  · intro hx
    obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
    obtain ⟨s, hs, rfl⟩ := (mem_labelledSubsetSupport u R y).mp hy
    exact (mem_labelledSubsetSupport v R _).mpr ⟨s, hs, (hsum s hs).symm⟩
  · intro hx
    obtain ⟨s, hs, rfl⟩ := (mem_labelledSubsetSupport v R x).mp hx
    exact Finset.mem_image.mpr ⟨_, (mem_labelledSubsetSupport u R _).mpr ⟨s, hs, rfl⟩, hsum s hs⟩

/-- Full subgroup generation transfers to the standard coefficient lattice. -/
theorem generatedLattice_eq_top_of_full_image {ι G H : Type*} [DecidableEq ι]
    [AddCommGroup G] [AddCommGroup H] [DecidableEq G] [DecidableEq H]
    (σ : G →+ H) (hσ : Function.Injective σ) (u : ι → G) (v : ι → H) (R : Finset ι)
    (hrepr : ∀ i ∈ R, σ (u i) = v i) (hgen : generatedLattice v R = σ.range) :
    generatedLattice u R = ⊤ := by
  have him : σ '' (u '' (R : Set ι)) = v '' (R : Set ι) := by
    rw [Set.image_image]
    apply Set.image_congr
    intro i hi
    exact hrepr i hi
  have hm : (generatedLattice u R).map σ = σ.range := by
    change (AddSubgroup.closure (u '' (R : Set ι))).map σ = _
    rw [AddMonoidHom.map_closure, him]
    exact hgen
  apply top_unique
  intro x _
  have hx : σ x ∈ (generatedLattice u R).map σ := by rw [hm]; exact ⟨x, rfl⟩
  obtain ⟨y, hy, he⟩ := hx
  exact hσ he ▸ hy

/-- Every surviving full-rank subfamily stays full-rank in the new integer
basis coordinates, including after arbitrary further allowed deletions. -/
theorem commonLatticeCoordinate_full_rank {ι : Type} {d : ℕ}
    (Γ : AddSubgroup (IntVec d)) (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (v : ι → IntVec d) (R : Finset ι) (hΓ : ∀ i ∈ R, v i ∈ Γ)
    (hfull : labelSpan ℝ (fun i => realVector (v i)) R = ⊤) :
    labelSpan ℝ (fun i => realVector (commonLatticeCoordinate (subgroupBasisSynthesisHom Γ b hΛ) (v i))) R = ⊤ := by
  have him : (fun i => realVector (commonLatticeCoordinate (subgroupBasisSynthesisHom Γ b hΛ) (v i))) '' (R : Set ι) =
      b.equivFun '' ((fun i => realVector (v i)) '' (R : Set ι)) := by
    rw [Set.image_image]
    apply Set.image_congr
    intro i hi
    exact commonLatticeCoordinate_cast Γ b hΛ (v i) (hΓ i hi)
  unfold labelSpan
  rw [him, ← Submodule.map_span]
  change (labelSpan ℝ (fun i => realVector (v i)) R).map b.equivFun.toLinearMap = ⊤
  rw [hfull, Submodule.map_top]
  exact LinearMap.range_eq_top.mpr b.equivFun.surjective

/-- A filled image reserve gives actual coefficient witnesses, by injectivity
of the synthesis map and the exact support image identity. -/
theorem labelled_filling_pullback {ι G H : Type*} [DecidableEq ι]
    [AddCommGroup G] [AddCommGroup H] [DecidableEq G] [DecidableEq H]
    (σ : G →+ H) (hσ : Function.Injective σ) (u : ι → G) (v : ι → H) (R : Finset ι)
    (hrepr : ∀ i ∈ R, σ (u i) = v i) (t : G) (W : Set G)
    (hfill : ∀ z ∈ W, σ t+σ z ∈ labelledSubsetSupport v R) :
    ∀ z ∈ W, t+z ∈ labelledSubsetSupport u R := by
  intro z hz
  have hm := hfill z hz
  rw [← labelledSubsetSupport_image_hom σ u v R hrepr] at hm
  obtain ⟨q, hq, he⟩ := Finset.mem_image.mp hm
  have he' : q = t+z := hσ (he.trans (map_add σ t z).symm)
  exact he' ▸ hq

end
end Optss
