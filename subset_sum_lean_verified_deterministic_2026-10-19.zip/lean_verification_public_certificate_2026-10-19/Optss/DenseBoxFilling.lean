import Optss.DenseBoxParameters

/-!
# Dense-box filling, with explicit constants and actual summands

This closes the paper's Lemma 2.D: the special case of Conlon–Fox–Pham
Lemma 2.15 in which every dense input contains zero and generates the
full integer lattice. The proof uses the proved Kneser–Lev interval
chain, actual dense coordinate fibers, disjoint labelled batches, and
actual finite-quotient residue saturation. No filling conclusion is an
input hypothesis.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

/-- Actual coordinate box filling for natural-indexed input labels, using
the explicit density/rank thresholds. The width estimate is retained. -/
theorem dense_box_filling_widths {d : ℕ} (hd : 0 < d) (c : ℝ)
    (hc : 0 < c) (hc1 : c ≤ 1) (N : ℕ) (A : ℕ → Finset (IntVec d))
    (lo : IntVec d) (W : Fin d → ℕ)
    (hN : denseBoxSummandThreshold d c ≤ N)
    (hW : ∀ j, denseBoxWidthThreshold c ≤ W j)
    (hbox : ∀ i < N, A i ⊆ fillingIntegerBox lo (fun j => lo j + W j - 1))
    (hdense : ∀ i < N, c * (fillingIntegerBox lo (fun j => lo j + W j - 1)).card ≤ (A i).card)
    (hzero : ∀ i < N, 0 ∈ A i)
    (hgen : ∀ i < N, AddSubgroup.closure (A i : Set (IntVec d)) = ⊤) :
    ∃ a b t : IntVec d,
      (fillingIntegerBox a b).image (t + ·) ⊆ ∑ i ∈ Finset.range N, A i ∧
      ∀ j, denseBoxDilation d c * N * W j ≤ (b j - a j : ℤ) := by
  let q := N / (2 * d)
  let M := denseBoxReserveSize d c
  let K := denseBoxPeriodCutoff c
  let S : Fin d → Finset ℕ := fillingAxisBatch q
  let T := fillingReserveBatch d q M
  obtain ⟨halloc, hquota, hremain⟩ := denseBoxSummandThreshold_spec d c N hd hc hN
  change d * q + M ≤ N at halloc
  change 20 ≤ c ^ 2 * q at hquota
  change denseBoxDilation d c * N ≤ c ^ 2 * q / 4 - 2 * M at hremain
  have hNpos : 0 < N := by
    by_contra hn
    have hz : N = 0 := Nat.eq_zero_of_not_pos hn
    norm_num [q, hz] at hquota
  have hsub := filling_allocation_subset d q M N halloc
  have hcenter : ∀ j, lo j ≤ 0 ∧ 0 ≤ lo j + W j - 1 := by
    have h0 := (mem_fillingIntegerBox _ _ _).mp (hbox 0 hNpos (hzero 0 hNpos))
    exact h0
  have hSj : ∀ j, (S j).card = q := fun j => fillingAxisBatch_card q j
  have hT : T.card = M := fillingReserveBatch_card d q M
  obtain ⟨a, b, t, hfill, hlen⟩ := dense_box_with_reserve S T A lo W c K hc hc1
    (denseBoxPeriodCutoff_bound c hc)
    (fun j => (denseBoxWidthThreshold_spec c hc (W j) (hW j)).1)
    (fun j => (denseBoxWidthThreshold_spec c hc (W j) (hW j)).2)
    hcenter (fun j => by simpa [hSj] using hquota)
    (by rw [hT]; change K ^ d ≤ K ^ d + 1; omega)
    (fillingAxisBatch_disjoint d q) (fillingReserveBatch_disjoint d q M)
    (fun i hi => hbox i (Finset.mem_range.mp (hsub hi)))
    (fun j i hi => hdense i (Finset.mem_range.mp
      (hsub (Finset.mem_union_left _ (Finset.mem_biUnion.mpr ⟨j, Finset.mem_univ _, hi⟩)))))
    (fun i hi => hzero i (Finset.mem_range.mp (hsub (Finset.mem_union_right _ hi))))
    (fun i hi => hgen i (Finset.mem_range.mp (hsub (Finset.mem_union_right _ hi))))
  refine ⟨a, b, t, hfill.trans (filling_sum_subset_of_subset _ _ A hsub
    (fun i hi => hzero i (Finset.mem_range.mp hi))), ?_⟩
  intro j
  have hh := hlen j
  rw [hSj, hT] at hh
  have hmul := mul_le_mul_of_nonneg_right hremain (show (0 : ℝ) ≤ W j by positivity)
  exact hmul.trans hh

/-- An integer box wide enough in each coordinate contains a translate
of the integer points of the indicated real dilation. -/
theorem integer_box_contains_translated_dilate {d : ℕ}
    (lo : IntVec d) (W : Fin d → ℕ) (a b t : IntVec d) (scale : ℝ) (hscale : 0 ≤ scale)
    (hwidth : ∀ j, scale * W j ≤ (b j - a j : ℤ)) :
    ∃ z : IntVec d, ∀ x : IntVec d,
      (∀ j, scale * lo j ≤ x j ∧ (x j : ℝ) ≤ scale * (lo j + W j - 1)) →
      z + x ∈ (fillingIntegerBox a b).image (t + ·) := by
  let r : IntVec d := fun j => ⌈scale * (lo j : ℝ)⌉
  let z : IntVec d := fun j => t j + a j - r j
  refine ⟨z, ?_⟩
  intro x hx
  let y : IntVec d := fun j => a j + x j - r j
  have hy : y ∈ fillingIntegerBox a b := by
    rw [mem_fillingIntegerBox]
    intro j
    have hlo : r j ≤ x j := Int.ceil_le.mpr (hx j).1
    have hceil : scale * (lo j : ℝ) ≤ (r j : ℝ) := Int.le_ceil _
    have hw := hwidth j
    have hhi := (hx j).2
    constructor
    · dsimp [y]; omega
    · have hh : (y j : ℝ) ≤ b j := by
        dsimp [y]
        push_cast at hw ⊢
        nlinarith
      exact_mod_cast hh
  refine Finset.mem_image.mpr ⟨y, hy, ?_⟩
  funext j
  dsimp [y, z]
  change t j + (a j + x j - r j) = (t j + a j - r j) + x j
  ring

/-- Paper Lemma 2.D, retaining the explicit constants and natural-indexed
summands. The conclusion uses exactly the integer points of the real
dilation of the original box. -/
theorem dense_box_filling_explicit {d : ℕ} (hd : 0 < d) (c : ℝ)
    (hc : 0 < c) (hc1 : c ≤ 1) (N : ℕ) (A : ℕ → Finset (IntVec d))
    (lo hi : IntVec d) (hN : denseBoxSummandThreshold d c ≤ N)
    (hW : ∀ j, (denseBoxWidthThreshold c : ℤ) ≤ hi j - lo j + 1)
    (hbox : ∀ i < N, A i ⊆ fillingIntegerBox lo hi)
    (hdense : ∀ i < N, c * (fillingIntegerBox lo hi).card ≤ (A i).card)
    (hzero : ∀ i < N, 0 ∈ A i)
    (hgen : ∀ i < N, AddSubgroup.closure (A i : Set (IntVec d)) = ⊤) :
    ∃ z : IntVec d, ∀ x : IntVec d,
      (∀ j, denseBoxDilation d c * N * lo j ≤ x j ∧
        (x j : ℝ) ≤ denseBoxDilation d c * N * hi j) →
      z + x ∈ ∑ i ∈ Finset.range N, A i := by
  let W : Fin d → ℕ := fun j => (hi j - lo j + 1).toNat
  have hw0 : 0 < denseBoxWidthThreshold c := (denseBoxWidthThreshold_spec c hc _ le_rfl).1
  have hw : ∀ j, (W j : ℤ) = hi j - lo j + 1 := by
    intro j
    exact Int.toNat_of_nonneg (by have := hW j; omega)
  have hWN : ∀ j, denseBoxWidthThreshold c ≤ W j := by
    intro j
    have h := hW j
    rw [← hw j] at h
    exact_mod_cast h
  have he : (fun j => lo j + (W j : ℤ) - 1) = hi := by
    funext j
    rw [hw]
    ring
  obtain ⟨a, b, t, hfill, hwidth⟩ := dense_box_filling_widths hd c hc hc1 N A lo W hN hWN
    (by simpa only [he] using hbox) (by simpa only [he] using hdense) hzero hgen
  obtain ⟨z, hz⟩ := integer_box_contains_translated_dilate lo W a b t
    (denseBoxDilation d c * N) (by have := denseBoxDilation_pos d c hd hc; positivity) hwidth
  refine ⟨z, fun x hx => hfill (hz x ?_)⟩
  intro j
  refine ⟨(hx j).1, ?_⟩
  have heR : (lo j : ℝ) + W j - 1 = hi j := by exact_mod_cast congrFun he j
  simpa only [heR] using (hx j).2

/-- The exact quantified existence statement of Lemma 2.D for a finite
family of actual integer-vector sets. Only density, bounds, zero
membership, and full integer generation are assumptions. -/
theorem dense_box_filling (d : ℕ) (hd : 0 < d) (c : ℝ) (hc : 0 < c) (hc1 : c ≤ 1) :
    ∃ (γ : ℝ) (N₀ W₀ : ℕ), 0 < γ ∧
      ∀ (N : ℕ) (A : Fin N → Finset (IntVec d)) (lo hi : IntVec d),
        N₀ ≤ N → (∀ j, (W₀ : ℤ) ≤ hi j - lo j + 1) →
        (∀ i, A i ⊆ fillingIntegerBox lo hi) →
        (∀ i, c * (fillingIntegerBox lo hi).card ≤ (A i).card) →
        (∀ i, 0 ∈ A i) → (∀ i, AddSubgroup.closure (A i : Set (IntVec d)) = ⊤) →
        ∃ z : IntVec d, ∀ x : IntVec d,
          (∀ j, γ * N * lo j ≤ x j ∧ (x j : ℝ) ≤ γ * N * hi j) →
          z + x ∈ ∑ i, A i := by
  refine ⟨denseBoxDilation d c, denseBoxSummandThreshold d c, denseBoxWidthThreshold c,
    denseBoxDilation_pos d c hd hc, ?_⟩
  intro N A lo hi hN hW hbox hdense hzero hgen
  let B : ℕ → Finset (IntVec d) := fun i => if h : i < N then A ⟨i, h⟩ else {0}
  have he : (∑ i ∈ Finset.range N, B i) = ∑ i, A i := by
    rw [Finset.sum_range]
    apply Finset.sum_congr rfl
    intro i hi
    simp [B, i.2]
  obtain ⟨z, hz⟩ := dense_box_filling_explicit hd c hc hc1 N B lo hi hN hW
    (fun i hi => by simpa [B, hi] using hbox ⟨i, hi⟩)
    (fun i hi => by simpa [B, hi] using hdense ⟨i, hi⟩)
    (fun i hi => by simpa [B, hi] using hzero ⟨i, hi⟩)
    (fun i hi => by simpa [B, hi] using hgen ⟨i, hi⟩)
  exact ⟨z, fun x hx => he ▸ hz x hx⟩

/-- Paper-exact Lemma 2.D wrapper, using the paper's `ℤ`-linear span
hypothesis. Integer span and additive subgroup generation coincide. -/
theorem lemma2D_dense_box_filling (d : ℕ) (hd : 0 < d) (c : ℝ) (hc : 0 < c) (hc1 : c ≤ 1) :
    ∃ (γ : ℝ) (N₀ W₀ : ℕ), 0 < γ ∧
      ∀ (N : ℕ) (A : Fin N → Finset (IntVec d)) (lo hi : IntVec d),
        N₀ ≤ N → (∀ j, (W₀ : ℤ) ≤ hi j - lo j + 1) →
        (∀ i, A i ⊆ fillingIntegerBox lo hi) →
        (∀ i, c * (fillingIntegerBox lo hi).card ≤ (A i).card) →
        (∀ i, 0 ∈ A i) → (∀ i, Submodule.span ℤ (A i : Set (IntVec d)) = ⊤) →
        ∃ z : IntVec d, ∀ x : IntVec d,
          (∀ j, γ * N * lo j ≤ x j ∧ (x j : ℝ) ≤ γ * N * hi j) →
          z + x ∈ ∑ i, A i := by
  obtain ⟨γ, N₀, W₀, hγ, hfill⟩ := dense_box_filling d hd c hc hc1
  refine ⟨γ, N₀, W₀, hγ, ?_⟩
  intro N A lo hi hN hW hbox hdense hzero hspan
  apply hfill N A lo hi hN hW hbox hdense hzero
  intro i
  rw [← Submodule.span_int_eq_addSubgroup_closure, hspan i]
  rfl

end
end Optss
