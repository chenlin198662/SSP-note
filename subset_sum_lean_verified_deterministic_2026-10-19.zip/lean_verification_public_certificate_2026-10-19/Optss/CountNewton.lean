import Optss.NewtonSupport
import Mathlib.Data.List.GetD

/-!
# Newton tables computed directly from multiplicities

Power sums are prepared from the type capacities. Each successive elementary
coefficient is computed once and stored, so subsequent steps read the previous
table rather than recursively recomputing coefficients or expanding copies.
The proof compares this construction with copy-labelled elementary coefficients.
The table uses lists; this is not yet the paper's array/fast-convolution cost model.
-/

namespace Optss
open scoped BigOperators
noncomputable section

variable {ι σ : Type*} [Fintype ι]

/-- Direct multiplicity formula for a power sum. -/
def countPowerSum (c : ι → ℕ) (a : ι → MvPolynomial σ ℤ) (l : ℕ) :
    MvPolynomial σ ℤ := ∑ i, (c i : MvPolynomial σ ℤ) * a i ^ l

theorem countPowerSum_eq_copies (c : ι → ℕ) (a : ι → MvPolynomial σ ℤ) (l : ℕ) :
    countPowerSum c a l = powerSum (fun p : Σ i, Fin (c i) => a p.1) l :=
  (powerSum_copies c a l).symm

/-- Monomial power preparation needs only exponent scaling and an insertion of
the integer capacity, rather than polynomial exponentiation. -/
theorem countPowerSum_monomial (c : ι → ℕ) (u : ι → σ →₀ ℕ) (l : ℕ) :
    countPowerSum c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l =
      ∑ i, MvPolynomial.monomial (l • u i) (c i : ℤ) := by
  unfold countPowerSum
  apply Finset.sum_congr rfl
  intro i _
  have hc : (c i : MvPolynomial σ ℤ) = MvPolynomial.C (c i : ℤ) := by simp
  simp only [MvPolynomial.monomial_pow, one_pow, hc, MvPolynomial.C_mul_monomial, mul_one]

/-- Prepare the truncated power sums once, including the unused entry at zero. -/
def countPowerTable (Δ : σ →₀ ℕ) (c : ι → ℕ) (a : ι → MvPolynomial σ ℤ)
    (kcap : ℕ) : List (MvPolynomial σ ℤ) :=
  (List.range (kcap + 1)).map (fun l => truncatePolynomial Δ (countPowerSum c a l))

/-- The sparse direct-count preparation used for monomial inputs. -/
def monomialPowerTable (Δ : σ →₀ ℕ) (c : ι → ℕ) (u : ι → σ →₀ ℕ)
    (kcap : ℕ) : List (MvPolynomial σ ℤ) :=
  (List.range (kcap + 1)).map (fun l => truncatePolynomial Δ
    (∑ i, MvPolynomial.monomial (l • u i) (c i : ℤ)))

theorem monomialPowerTable_eq (Δ : σ →₀ ℕ) (c : ι → ℕ) (u : ι → σ →₀ ℕ)
    (kcap : ℕ) : monomialPowerTable Δ c u kcap =
      countPowerTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap := by
  simp only [monomialPowerTable, countPowerTable, countPowerSum_monomial]

theorem countPowerTable_getD (Δ : σ →₀ ℕ) (c : ι → ℕ)
    (a : ι → MvPolynomial σ ℤ) (kcap l : ℕ) (hl : l ≤ kcap) :
    (countPowerTable Δ c a kcap).getD l 0 =
      truncatePolynomial Δ (powerSum (fun p : Σ i, Fin (c i) => a p.1) l) := by
  simp [countPowerTable, List.getD_eq_getElem, hl, countPowerSum_eq_copies,
    show l < kcap + 1 by omega]

/-- One Newton step reads prepared powers and already computed coefficients. -/
def newtonTableStep (Δ : σ →₀ ℕ) (powers previous : List (MvPolynomial σ ℤ))
    (k : ℕ) : MvPolynomial σ ℤ :=
  dividePolynomialCoefficients k (truncatePolynomial Δ
    (∑ l ∈ Finset.Icc 1 k,
      (-1 : MvPolynomial σ ℤ) ^ (l - 1) * powers.getD l 0 * previous.getD (k - l) 0))

/-- Successive Newton coefficients, each appended exactly once. -/
def newtonTable (Δ : σ →₀ ℕ) (powers : List (MvPolynomial σ ℤ)) :
    ℕ → List (MvPolynomial σ ℤ)
  | 0 => [truncatePolynomial Δ 1]
  | n + 1 =>
      let previous := newtonTable Δ powers n
      previous ++ [newtonTableStep Δ powers previous (n + 1)]

@[simp] theorem newtonTable_length (Δ : σ →₀ ℕ) (powers : List (MvPolynomial σ ℤ))
    (n : ℕ) : (newtonTable Δ powers n).length = n + 1 := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [newtonTable, List.length_append, List.length_singleton, ih]

/-- Every table entry is the correct truncated elementary coefficient, provided
the prepared power entries are correct. The next theorem discharges that premise
with the actual direct-count preparation above. -/
theorem newtonTable_getD (Δ : σ →₀ ℕ) (a : ι → MvPolynomial σ ℤ)
    (powers : List (MvPolynomial σ ℤ)) (kcap : ℕ)
    (hpowers : ∀ l ≤ kcap, powers.getD l 0 = truncatePolynomial Δ (powerSum a l))
    (n : ℕ) (hn : n ≤ kcap) (k : ℕ) (hk : k ≤ n) :
    (newtonTable Δ powers n).getD k 0 = truncatePolynomial Δ (elementaryCoefficient a k) := by
  induction n generalizing k with
  | zero =>
      have hk0 : k = 0 := by omega
      subst k
      simp [newtonTable]
  | succ n ih =>
      rw [newtonTable]
      by_cases hkn : k ≤ n
      · rw [List.getD_append _ _ _ _ (by simp; omega)]
        exact ih (by omega) k hkn
      · have hkeq : k = n + 1 := by omega
        subst k
        rw [List.getD_append_right _ _ _ _ (by simp), newtonTable_length]
        simp only [Nat.sub_self, List.getD_cons_zero]
        unfold newtonTableStep
        have hsum :
            (∑ l ∈ Finset.Icc 1 (n + 1),
              (-1 : MvPolynomial σ ℤ) ^ (l - 1) * powers.getD l 0 *
                (newtonTable Δ powers n).getD (n + 1 - l) 0) =
            ∑ l ∈ Finset.Icc 1 (n + 1),
              (-1 : MvPolynomial σ ℤ) ^ (l - 1) *
                truncatePolynomial Δ (powerSum a l) *
                truncatePolynomial Δ (elementaryCoefficient a (n + 1 - l)) := by
          apply Finset.sum_congr rfl
          intro l hl
          have hl' := Finset.mem_Icc.mp hl
          rw [hpowers l (by omega), ih (by omega) (n + 1 - l) (by omega)]
        rw [hsum, truncated_newton_recurrence]
        exact dividePolynomialCoefficients_C_mul (by omega) _

/-- The actual table construction uses type capacities directly throughout. -/
def countNewtonTable (Δ : σ →₀ ℕ) (c : ι → ℕ) (a : ι → MvPolynomial σ ℤ)
    (kcap : ℕ) : List (MvPolynomial σ ℤ) :=
  newtonTable Δ (countPowerTable Δ c a kcap) kcap

theorem countNewtonTable_getD (Δ : σ →₀ ℕ) (c : ι → ℕ)
    (a : ι → MvPolynomial σ ℤ) (kcap k : ℕ) (hk : k ≤ kcap) :
    (countNewtonTable Δ c a kcap).getD k 0 =
      truncatePolynomial Δ (elementaryCoefficient (fun p : Σ i, Fin (c i) => a p.1) k) := by
  exact newtonTable_getD Δ (fun p : Σ i, Fin (c i) => a p.1) _ kcap
    (countPowerTable_getD Δ c a kcap) kcap le_rfl k hk

/-- Exact support of a stored count-based coefficient; no copy expansion is
needed in its definition, while correctness still uses actual available copies. -/
theorem countNewtonTable_coeff_pos_iff (Δ e : σ →₀ ℕ) (c : ι → ℕ)
    (u : ι → σ →₀ ℕ) (kcap k : ℕ) (hk : k ≤ kcap) :
    0 < MvPolynomial.coeff e
      ((countNewtonTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap).getD k 0) ↔
      e ≤ Δ ∧ ∃ s : Finset (Σ i, Fin (c i)), s.card = k ∧ (∑ p ∈ s, u p.1) = e := by
  rw [countNewtonTable_getD _ _ _ _ _ hk, ← newtonTruncatedCoefficient_eq]
  exact newtonTruncatedCoefficient_copies_coeff_pos_iff c u Δ e k

/-- The full cardinality-capped support polynomial read from the computed table. -/
def countNewtonSupport (Δ : σ →₀ ℕ) (c : ι → ℕ) (u : ι → σ →₀ ℕ)
    (kcap : ℕ) : MvPolynomial σ ℤ :=
  let table := newtonTable Δ (monomialPowerTable Δ c u kcap) kcap
  ∑ k ∈ Finset.range (kcap + 1), table.getD k 0

/-- Direct-count table computation is identical to the copy-labelled support
polynomial previously used to prove the signed correction theorem. -/
theorem countNewtonSupport_eq_copies (Δ : σ →₀ ℕ) (c : ι → ℕ)
    (u : ι → σ →₀ ℕ) (kcap : ℕ) :
    countNewtonSupport Δ c u kcap =
      newtonTruncatedSupport (fun p : Σ i, Fin (c i) => u p.1) Δ kcap := by
  unfold countNewtonSupport newtonTruncatedSupport
  rw [monomialPowerTable_eq]
  apply Finset.sum_congr rfl
  intro k hk
  rw [newtonTruncatedCoefficient_eq]
  exact countNewtonTable_getD Δ c _ kcap k (by have := Finset.mem_range.mp hk; omega)

theorem countNewtonSupport_coeff_pos_iff (Δ e : σ →₀ ℕ) (c : ι → ℕ)
    (u : ι → σ →₀ ℕ) (kcap : ℕ) :
    0 < MvPolynomial.coeff e (countNewtonSupport Δ c u kcap) ↔
      e ≤ Δ ∧ ∃ s : Finset (Σ i, Fin (c i)),
        s.card ≤ kcap ∧ (∑ p ∈ s, u p.1) = e := by
  rw [countNewtonSupport_eq_copies]
  exact newtonTruncatedSupport_copies_coeff_pos_iff c u Δ e kcap

/-- Exact number of polynomial-product summands in the stored-table updates.
This is a loop count, not a bit-operation complexity assertion. -/
theorem newton_table_product_summands (kcap : ℕ) :
    (∑ k ∈ Finset.range (kcap + 1), (Finset.Icc 1 k).card) =
      kcap * (kcap + 1) / 2 := by
  simp only [Nat.card_Icc, Nat.add_sub_cancel]
  rw [Finset.sum_range_id]
  simp only [Nat.add_sub_cancel, Nat.mul_comm]

end
end Optss
