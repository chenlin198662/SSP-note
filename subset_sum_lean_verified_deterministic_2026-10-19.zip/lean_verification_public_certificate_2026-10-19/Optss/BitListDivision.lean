import Optss.BitListArithmetic

/-!
# Long division performed directly on Boolean lists

Each input bit is appended to the current remainder. A single ripple-borrow
subtractor both compares with the divisor and supplies the possible difference.
Only Boolean gates, list constructors and high-zero trimming compute the answer.
No natural multiplication, division, or comparison chooses an output bit.
-/

namespace Optss

structure BitListDivisionResult where
  quotient : List Bool
  remainder : List Bool
  deriving Repr, DecidableEq

def bitListDivisionStep (b : Bool) (ds : List Bool) (out : BitListDivisionResult) :
    BitListDivisionResult :=
  let trial := b::out.remainder
  let diff := bitListSubAux false trial ds
  if diff.borrow then
    ⟨false::out.quotient, bitListTrim trial⟩
  else
    ⟨true::out.quotient, bitListTrim diff.digits⟩

def bitListDivisionDigits (ds : List Bool) : List Bool → BitListDivisionResult
  | [] => ⟨[],[]⟩
  | b::bs => bitListDivisionStep b ds (bitListDivisionDigits ds bs)

/-- The public result has canonical quotient and remainder encodings. -/
def bitListDivision (ns ds : List Bool) : BitListDivisionResult :=
  let out := bitListDivisionDigits ds ns
  ⟨bitListTrim out.quotient, out.remainder⟩

theorem bitListDivisionStep_correct (b : Bool) (ds : List Bool) (n : ℕ)
    (out : BitListDivisionResult)
    (he : binaryDigitsValue out.quotient*binaryDigitsValue ds+binaryDigitsValue out.remainder=n)
    (hr : binaryDigitsValue out.remainder < binaryDigitsValue ds) :
    binaryDigitsValue (bitListDivisionStep b ds out).quotient*binaryDigitsValue ds+
        binaryDigitsValue (bitListDivisionStep b ds out).remainder=2*n+b.toNat ∧
      binaryDigitsValue (bitListDivisionStep b ds out).remainder < binaryDigitsValue ds := by
  have hb : b.toNat ≤ 1 := by cases b <;> decide
  have hsub := bitListSubAux_correct (b::out.remainder) ds false
  have hborrow := bitListSub_borrow_iff (b::out.remainder) ds
  unfold bitListDivisionStep
  dsimp only
  split_ifs with h
  · have hlt := hborrow.mp h
    simp only [bitListTrim_value, binaryDigitsValue, Bool.toNat_false, add_zero] at *
    constructor <;> nlinarith
  · have hf : (bitListSubAux false (b::out.remainder) ds).borrow = false := Bool.eq_false_iff.mpr h
    rw [hf] at hsub
    simp only [Bool.toNat_false, mul_zero, add_zero, binaryDigitsValue] at hsub
    simp only [bitListTrim_value, binaryDigitsValue, Bool.toNat_true]
    constructor <;> nlinarith

theorem bitListDivisionDigits_correct (ns ds : List Bool) (hd : 0 < binaryDigitsValue ds) :
    binaryDigitsValue (bitListDivisionDigits ds ns).quotient*binaryDigitsValue ds+
        binaryDigitsValue (bitListDivisionDigits ds ns).remainder=binaryDigitsValue ns ∧
      binaryDigitsValue (bitListDivisionDigits ds ns).remainder < binaryDigitsValue ds := by
  induction ns with
  | nil => simp [bitListDivisionDigits, binaryDigitsValue, hd]
  | cons b bs ih => exact bitListDivisionStep_correct b ds (binaryDigitsValue bs) _ ih.1 ih.2

theorem bitListDivision_correct (ns ds : List Bool) (hd : 0 < binaryDigitsValue ds) :
    binaryDigitsValue (bitListDivision ns ds).quotient = binaryDigitsValue ns/binaryDigitsValue ds ∧
    binaryDigitsValue (bitListDivision ns ds).remainder = binaryDigitsValue ns%binaryDigitsValue ds := by
  have h := bitListDivisionDigits_correct ns ds hd
  simp only [bitListDivision, bitListTrim_value]
  constructor
  · conv_rhs => rw [← h.1]
    simp [Nat.add_div, hd, Nat.div_eq_of_lt h.2, Nat.mod_eq_of_lt h.2, not_le.mpr h.2]
  · conv_rhs => rw [← h.1]
    simp [Nat.add_mod, Nat.mod_eq_of_lt h.2]

theorem bitListDivisionDigits_quotient_length (ns ds : List Bool) :
    (bitListDivisionDigits ds ns).quotient.length = ns.length := by
  induction ns with
  | nil => rfl
  | cons b bs ih =>
    simp only [bitListDivisionDigits, bitListDivisionStep]
    split_ifs <;> simp [ih]

theorem bitListDivisionDigits_remainder_length (ns ds : List Bool) :
    (bitListDivisionDigits ds ns).remainder.length =
      (binaryDigitsValue (bitListDivisionDigits ds ns).remainder).size := by
  cases ns with
  | nil => simp [bitListDivisionDigits, binaryDigitsValue]
  | cons b bs =>
    simp only [bitListDivisionDigits, bitListDivisionStep]
    split_ifs <;> simp [bitListTrim_length, bitListTrim_value]

theorem bitListDivisionDigits_remainder_canonical (ns ds : List Bool) :
    (bitListDivisionDigits ds ns).remainder =
      (binaryDigitsValue (bitListDivisionDigits ds ns).remainder).bits := by
  cases ns with
  | nil => simp [bitListDivisionDigits, binaryDigitsValue]
  | cons b bs =>
    simp only [bitListDivisionDigits, bitListDivisionStep]
    split_ifs <;> simp only [bitListTrim_eq_bits, binaryDigitsValue_bits]

theorem bitListDivision_encodings (ns ds : List Bool) (hd : 0 < binaryDigitsValue ds) :
    (bitListDivision ns ds).quotient = (binaryDigitsValue ns/binaryDigitsValue ds).bits ∧
    (bitListDivision ns ds).remainder = (binaryDigitsValue ns%binaryDigitsValue ds).bits := by
  have h := bitListDivision_correct ns ds hd
  constructor
  · rw [← h.1]
    simpa only [bitListDivision, bitListTrim_value] using
      bitListTrim_eq_bits (bitListDivisionDigits ds ns).quotient
  · rw [← h.2]
    exact bitListDivisionDigits_remainder_canonical ns ds

theorem bitListDivisionDigits_remainder_width (ns ds : List Bool) (hd : 0 < binaryDigitsValue ds) :
    (bitListDivisionDigits ds ns).remainder.length ≤ ds.length := by
  rw [bitListDivisionDigits_remainder_length]
  apply Nat.size_le.mpr
  exact (bitListDivisionDigits_correct ns ds hd).2.trans (binaryDigitsValue_lt_pow ds)

/-- Gate count of the actual borrow circuit at each step. Trimming uses list
control, accounted separately by traversal counts below. -/
def bitListDivisionGates (ds : List Bool) : List Bool → ℕ
  | [] => 0
  | b::bs => bitListDivisionGates ds bs+
      bitListRippleGates 8 (b::(bitListDivisionDigits ds bs).remainder) ds

theorem bitListDivisionGates_bound (ns ds : List Bool) (hd : 0 < binaryDigitsValue ds) :
    bitListDivisionGates ds ns ≤ 8*ns.length*(ds.length+1) := by
  induction ns with
  | nil => simp [bitListDivisionGates]
  | cons b bs ih =>
    have hr := bitListDivisionDigits_remainder_width bs ds hd
    simp only [bitListDivisionGates, bitListRippleGates_eq, List.length_cons]
    have hm : max ((bitListDivisionDigits ds bs).remainder.length+1) ds.length ≤ ds.length+1 := by omega
    nlinarith

/-- One subtraction traversal and one trimming traversal per input bit,
plus the final quotient trim. These are list-cell visits, with terminal tails. -/
def bitListDivisionStepVisits (b : Bool) (ds : List Bool) (out : BitListDivisionResult) : ℕ :=
  let trial := b::out.remainder
  let diff := bitListSubAux false trial ds
  bitListSubVisits trial ds +
    (if diff.borrow then bitListTrimVisits trial else bitListTrimVisits diff.digits) + 2

def bitListDivisionVisits (ds : List Bool) : List Bool → ℕ
  | [] => 1
  | b::bs => bitListDivisionVisits ds bs+bitListDivisionStepVisits b ds (bitListDivisionDigits ds bs)

theorem bitListDivisionStepVisits_bound (b : Bool) (ds : List Bool) (out : BitListDivisionResult)
    (hr : out.remainder.length ≤ ds.length) :
    bitListDivisionStepVisits b ds out ≤ 2*ds.length+6 := by
  unfold bitListDivisionStepVisits
  dsimp only
  split_ifs <;> simp only [bitListSubVisits_eq, bitListTrimVisits_eq,
    bitListSubAux_length, List.length_cons] <;> omega

theorem bitListDivisionVisits_bound (ns ds : List Bool) (hd : 0 < binaryDigitsValue ds) :
    bitListDivisionVisits ds ns+bitListTrimVisits (bitListDivisionDigits ds ns).quotient ≤
      ns.length*(2*ds.length+7)+2 := by
  have hcore : bitListDivisionVisits ds ns ≤ ns.length*(2*ds.length+6)+1 := by
    induction ns with
    | nil => simp [bitListDivisionVisits]
    | cons b bs ih =>
      have hstep := bitListDivisionStepVisits_bound b ds (bitListDivisionDigits ds bs)
        (bitListDivisionDigits_remainder_width bs ds hd)
      simp only [bitListDivisionVisits, List.length_cons]
      nlinarith
  rw [bitListTrimVisits_eq, bitListDivisionDigits_quotient_length]
  nlinarith

/-- Combined gate-node and list-traversal semantics for the answer routine.
These counters are mathematical instrumentation, not part of its execution. -/
def bitListDivisionBitWork (ns ds : List Bool) : ℕ :=
  bitListDivisionGates ds ns+bitListDivisionVisits ds ns+
    bitListTrimVisits (bitListDivisionDigits ds ns).quotient

theorem bitListDivisionBitWork_bound (ns ds : List Bool) (hd : 0 < binaryDigitsValue ds) :
    bitListDivisionBitWork ns ds ≤ 16*(ns.length+1)*(ds.length+1) := by
  have hg := bitListDivisionGates_bound ns ds hd
  have hv := bitListDivisionVisits_bound ns ds hd
  unfold bitListDivisionBitWork
  nlinarith

theorem binaryDivisionDigits_widthWork_lower (d : ℕ) (ns : List Bool) :
    8*ns.length*(d.size+2) ≤ (binaryDivisionDigits d ns).widthWork := by
  induction ns with
  | nil => simp [binaryDivisionDigits]
  | cons b bs ih =>
    simp only [binaryDivisionDigits, binaryDivisionStep]
    split_ifs <;> simp only [List.length_cons] <;> nlinarith

/-- The earlier natural-number width charge bounds the concrete Boolean
division's gates and traversals by a fixed factor, including zero numerator. -/
theorem bitListDivision_refines_widthWork (n d : ℕ) (hd : 0 < d) :
    bitListDivisionBitWork n.bits d.bits ≤ 2*(binaryLongDivision n d).widthWork+2 := by
  have hd' : 0 < binaryDigitsValue d.bits := by simpa [binaryDigitsValue_bits] using hd
  have hg := bitListDivisionGates_bound n.bits d.bits hd'
  have hv := bitListDivisionVisits_bound n.bits d.bits hd'
  have hl := binaryDivisionDigits_widthWork_lower d n.bits
  simp only [Nat.size_eq_bits_len] at hl hg hv
  change 8*n.size*(d.size+2) ≤ (binaryLongDivision n d).widthWork at hl
  unfold bitListDivisionBitWork
  nlinarith

end Optss
