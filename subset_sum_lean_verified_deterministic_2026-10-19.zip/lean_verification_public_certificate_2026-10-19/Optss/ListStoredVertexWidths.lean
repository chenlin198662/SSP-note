import Optss.ListStoredMatrixProduct

/-!
# Actual list-stored coordinate evaluation and vertex-width scans

The input vertex matrix stores vertices as columns. The routine builds and
executes the complete coefficient-matrix product once, then scans each stored
row directly and returns canonical natural bit widths. It is exactly the
finite maximum/ceiling construction already connected to convex-body boxing.
The full construction/read/arithmetic/scan charge is bounded by one explicit
fixed-dimension polynomial in the literal combined framed input size.
-/
namespace Optss
open scoped BigOperators
variable {r m : ℕ}

theorem rectangularListFractionMatrix_row {a b : ℕ} (A : ListBitRationalMatrixData a b) (i : Fin a) (j : Fin b) :
    rectangularListFractionMatrix A i j=((A.toVector.get i).toVector.get j) := by
  simp [rectangularListFractionMatrix,listMatrixVector,Vector.get]

theorem matrixRows_forall {a b : ℕ} (A : ListBitRationalMatrixData a b) (P : BitListFraction → Prop) :
    (∀ row∈A.data,∀ q∈row.data,P q)↔∀ i j,P (rectangularListFractionMatrix A i j) := by
  rw [A.forall_data_iff]
  constructor
  · intro h i j
    rw [rectangularListFractionMatrix_row]
    exact ((A.toVector.get i).forall_data_iff P).mp (h i) j
  · intro h i
    apply ((A.toVector.get i).forall_data_iff P).mpr
    intro j
    rw [← rectangularListFractionMatrix_row]
    exact h i j

def listMatrixWidthScan (P : ListBitRationalMatrixData r m) : BooleanListArray (List Bool) r :=
  ⟨P.data.map (fun row => booleanVertexWidth row.data),by simp [P.length_eq]⟩

def listMatrixWidthScanWork (P : ListBitRationalMatrixData r m) : ℕ :=
  2*r+1+(P.data.map (fun row => booleanVertexWidthWork row.data)).sum

theorem listMatrixWidthScan_get (P : ListBitRationalMatrixData r m) (i : Fin r) :
    (listMatrixWidthScan P).toVector.get i=booleanVertexWidth ((P.toVector.get i).data) := by
  simp [listMatrixWidthScan,BooleanListArray.toVector,Vector.get]

theorem listMatrixWidthScanWork_bound (P : ListBitRationalMatrixData r m)
    (hP : ∀ i j,(rectangularListFractionMatrix P i j).WellFormed) (T : ℕ) (hT : 0<T)
    (hbits : ∀ i j,(rectangularListFractionMatrix P i j).numerator.length≤T ∧
      (rectangularListFractionMatrix P i j).denominator.length≤T) :
    listMatrixWidthScanWork P≤2*r+1+r*(m+2)*1024*(T+1)^2 := by
  have hw := (matrixRows_forall P BitListFraction.WellFormed).mpr hP
  have hb := (matrixRows_forall P (fun q => q.numerator.length≤T ∧ q.denominator.length≤T)).mpr hbits
  unfold listMatrixWidthScanWork
  apply Nat.add_le_add_left
  have hs := List.sum_le_card_nsmul (P.data.map (fun row => booleanVertexWidthWork row.data))
    ((m+2)*1024*(T+1)^2) (by
      intro z hz
      obtain ⟨row,hr,rfl⟩ := List.mem_map.mp hz
      simpa only [row.length_eq] using booleanVertexWidthWork_bound row.data (hw row hr) T hT (hb row hr))
  simpa only [List.length_map,P.length_eq,nsmul_eq_mul,mul_assoc] using hs

def listStoredVertexWidths (C : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m) :
    BooleanListArray (List Bool) r :=
  let coordinates := constructedListMatrixMul C V
  listMatrixWidthScan coordinates

def listStoredVertexWidthsWork (C : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m) : ℕ :=
  let coordinates := constructedListMatrixMul C V
  constructedListMatrixMulWork C V+listMatrixWidthScanWork coordinates+1

/-- Decoded rational vertex family: the stored input columns, not an unrelated set. -/
def storedRationalVertices (V : ListBitRationalMatrixData r m) : Fin m → Fin r → ℚ :=
  fun i j => bitListFractionValue (rectangularListFractionMatrix V j i)

theorem listStoredVertexWidths_value (C : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m)
    (hC : ∀ i j,(rectangularListFractionMatrix C i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) (j : Fin r) :
    binaryDigitsValue ((listStoredVertexWidths C V).toVector.get j)=
      rationalVertexWidth ((rectangularListFractionMatrix C).map bitListFractionValue) (storedRationalVertices V) j := by
  rw [listStoredVertexWidths,listMatrixWidthScan_get,booleanListArray_data_eq_ofFn]
  apply booleanVertexWidth_coordinate_value
  · intro i
    rw [← rectangularListFractionMatrix_row]
    exact constructedListMatrixMul_wellFormed C V hC hV j i
  · intro i
    rw [← rectangularListFractionMatrix_row,constructedListMatrixMul_value C V hC hV]
    rfl

theorem listStoredVertexWidths_canonical (C : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m)
    (hC : ∀ i j,(rectangularListFractionMatrix C i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) (j : Fin r) :
    BitListCanonical ((listStoredVertexWidths C V).toVector.get j) := by
  rw [listStoredVertexWidths,listMatrixWidthScan_get]
  apply booleanVertexWidth_canonical
  apply (((constructedListMatrixMul C V).toVector.get j).forall_data_iff BitListFraction.WellFormed).mpr
  intro i
  rw [← rectangularListFractionMatrix_row]
  exact constructedListMatrixMul_wellFormed C V hC hV j i

noncomputable def storedVertexWidthsPolynomial (r m : ℕ) : Polynomial ℕ :=
  constructedMatrixMulPolynomial r r m+
    Polynomial.C (2*r+2)+
    Polynomial.C (r*(m+2)*1024)*(Polynomial.C (r+1)*(2*Polynomial.X+2)+1)^2

theorem listStoredVertexWidthsWork_input_polynomial (C : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m)
    (hC : ∀ i j,(rectangularListFractionMatrix C i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) :
    listStoredVertexWidthsWork C V≤
      (storedVertexWidthsPolynomial r m).eval (listStoredRationalBits C+listStoredRationalBits V) := by
  let L := listStoredRationalBits C+listStoredRationalBits V
  have hbitsC : ∀ i j,(rectangularListFractionMatrix C i j).numerator.length≤L ∧
      (rectangularListFractionMatrix C i j).denominator.length≤L := by
    intro i j
    have h : (rectangularListFractionMatrix C i j).numerator.length≤listStoredRationalBits C ∧
        (rectangularListFractionMatrix C i j).denominator.length≤listStoredRationalBits C := listStoredRationalBits_cell C i j
    exact ⟨h.1.trans (Nat.le_add_right _ _),h.2.trans (Nat.le_add_right _ _)⟩
  have hbitsV : ∀ i j,(rectangularListFractionMatrix V i j).numerator.length≤L ∧
      (rectangularListFractionMatrix V i j).denominator.length≤L := by
    intro i j
    have h : (rectangularListFractionMatrix V i j).numerator.length≤listStoredRationalBits V ∧
        (rectangularListFractionMatrix V i j).denominator.length≤listStoredRationalBits V := listStoredRationalBits_cell V i j
    exact ⟨h.1.trans (Nat.le_add_left _ _),h.2.trans (Nat.le_add_left _ _)⟩
  have hs := listMatrixWidthScanWork_bound (constructedListMatrixMul C V)
    (constructedListMatrixMul_wellFormed C V hC hV) ((r+1)*(2*L+2)) (by positivity)
    (constructedListMatrixMul_lengths C V hC hV L hbitsC hbitsV)
  have hm := constructedListMatrixMulWork_input_polynomial C V hC hV
  change constructedListMatrixMulWork C V≤(constructedMatrixMulPolynomial r r m).eval L at hm
  unfold listStoredVertexWidthsWork
  simp only [storedVertexWidthsPolynomial,Polynomial.eval_add,Polynomial.eval_C,
    Polynomial.eval_mul,Polynomial.eval_ofNat,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_pow]
  change _≤(constructedMatrixMulPolynomial r r m).eval L+(2*r+2)+r*(m+2)*1024*((r+1)*(2*L+2)+1)^2
  omega
end Optss
