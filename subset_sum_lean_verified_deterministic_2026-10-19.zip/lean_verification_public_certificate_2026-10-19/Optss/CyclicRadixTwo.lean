import Optss.RadixTwoStability
import Optss.RationalCharacterApproximation

/-! The radix-two arithmetic transform computes the standard cyclic DFT,
with the sign convention used by the Bogolyubov argument. -/
namespace Optss
open scoped BigOperators

noncomputable def cyclicFftRoot (N : ℕ) [NeZero N] : ℂ := ZMod.stdAddChar (-1 : ZMod N)

theorem cyclicFftRoot_pow (N : ℕ) [NeZero N] (k : ℕ) :
    cyclicFftRoot N^k=ZMod.stdAddChar (-(k : ZMod N)) := by
  rw [cyclicFftRoot,← AddChar.map_nsmul_eq_pow]
  congr 1
  simp [nsmul_eq_mul]

theorem cyclicFftRoot_period (N : ℕ) [NeZero N] : cyclicFftRoot N^N=1 := by
  rw [cyclicFftRoot_pow,ZMod.natCast_self,neg_zero,AddChar.map_zero_eq_one]

theorem zmod_finEquiv_natCast (N : ℕ) [NeZero N] (j : Fin N) :
    ZMod.finEquiv N j=(j.val : ZMod N) := by
  cases N with
  | zero => exact Fin.elim0 j
  | succ n =>
    change j=(j.val : Fin (n+1))
    apply Fin.ext
    exact (Nat.mod_eq_of_lt j.isLt).symm

def cyclicVectorData (n : ℕ) {R : Type*} (f : ZMod (2^n) → R) : Vector R (2^n) :=
  Vector.ofFn fun j => f (j.val : ZMod (2^n))

theorem radixDft_eq_cyclic_dft (n : ℕ) (f : ZMod (2^n) → ℂ) (k : Fin (2^n)) :
    radixDft n (cyclicFftRoot (2^n)) (cyclicVectorData n f) k.val=
      ZMod.dft f (k.val : ZMod (2^n)) := by
  unfold radixDft
  simp only [cyclicVectorData,vector_get_ofFn,cyclicFftRoot_pow,Nat.cast_mul]
  rw [ZMod.dft_apply]
  apply Fintype.sum_equiv (ZMod.finEquiv (2^n)).toEquiv
  intro j
  rw [smul_eq_mul]
  change f (j.val : ZMod (2^n))*ZMod.stdAddChar (-((j.val : ZMod (2^n))*(k.val : ZMod (2^n))))=
    ZMod.stdAddChar (-(ZMod.finEquiv (2^n) j*(k.val : ZMod (2^n))))*f (ZMod.finEquiv (2^n) j)
  rw [zmod_finEquiv_natCast,mul_comm]

theorem radixTwoFFT_eq_cyclic_dft (n : ℕ) (f : ZMod (2^n) → ℂ) (k : Fin (2^n)) :
    (radixTwoFFT n (cyclicFftRoot (2^n)) (cyclicVectorData n f)).get k=
      ZMod.dft f (k.val : ZMod (2^n)) := by
  rw [radixTwoFFT_correct _ _ _ (cyclicFftRoot_period _),radixDft_eq_cyclic_dft]

/-- A single table of powers of the root supplies all recursive levels. -/
noncomputable def cyclicRadixTwiddle (n l k : ℕ) : ℂ :=
  cyclicFftRoot (2^n)^(2^(n-(l+1))*k)

theorem cyclicRadixTwiddle_character (n l k : ℕ) :
    cyclicRadixTwiddle n l k=
      ZMod.stdAddChar (-(2^(n-(l+1))*k : ℕ) : ZMod (2^n)) := by
  rw [cyclicRadixTwiddle,cyclicFftRoot_pow]

theorem cyclicRadixTwiddle_norm (n l k : ℕ) : ‖cyclicRadixTwiddle n l k‖=1 := by
  rw [cyclicRadixTwiddle_character,AddChar.norm_apply]

theorem radixTwoTransform_eq_cyclic_dft (n : ℕ) (f : ZMod (2^n) → ℂ) (k : Fin (2^n)) :
    (radixTwoTransform (cyclicRadixTwiddle n) n (cyclicVectorData n f)).get k=
      ZMod.dft f (k.val : ZMod (2^n)) := by
  unfold cyclicRadixTwiddle
  rw [radixTwoTransform_exact _ n (cyclicFftRoot (2^n)) _ (fun _ _ _ => rfl)]
  exact radixTwoFFT_eq_cyclic_dft n f k

theorem approximate_radixTwo_cyclic_dft (n : ℕ) (f : ZMod (2^n) → ℂ)
    (T : ℕ → ℕ → ℂ) (B ε : ℝ) (hB : 0≤B) (hε : 0≤ε) (hε₁ : ε≤1)
    (hf : ∀ j, ‖f j‖≤B)
    (hT : ∀ l<n, ∀ k, ‖T l k-cyclicRadixTwiddle n l k‖≤ε) (k : Fin (2^n)) :
    ‖(radixTwoTransform T n (cyclicVectorData n f)).get k-
      ZMod.dft f (k.val : ZMod (2^n))‖≤(n : ℝ)*3^n*ε*B := by
  rw [← radixTwoTransform_eq_cyclic_dft]
  exact radixTwoTransform_error T (cyclicRadixTwiddle n) n _ B ε hB hε hε₁
    (fun j => by simpa only [cyclicVectorData,vector_get_ofFn] using hf (j.val : ZMod (2^n)))
    (fun _ _ _ => (cyclicRadixTwiddle_norm _ _ _).le) hT k

end Optss
