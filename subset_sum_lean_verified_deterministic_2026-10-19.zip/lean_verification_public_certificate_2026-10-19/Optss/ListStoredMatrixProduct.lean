import Optss.BooleanVertexWidths

/-!
# Constructed rational matrix products through list storage

Both factors are nested Boolean list arrays. Every expression leaf executes a
counted deep-copy addressed read. The product expression is actually built,
then interpreted, and each output is materialized once. Construction, scalar,
copy, address and output-list charges form one fixed-dimension polynomial in
the literal combined framed input bits.
-/
namespace Optss
open scoped BigOperators
variable {r d m : ℕ}

def rectangularListFractionMatrix (A : ListBitRationalMatrixData r d) : Matrix (Fin r) (Fin d) BitListFraction :=
  fun i j => ((listMatrixVector A).get i).get j

def buildMatrixMulExpression (r d m : ℕ) (i : Fin r) (j : Fin m) :
    RationalExpression ((Fin r × Fin d) ⊕ (Fin d × Fin m)) × ℕ :=
  let terms := List.ofFn fun k : Fin d =>
    (.binary .mul (.input (.inl (i,k))) (.input (.inr (k,j))),8*(r+d+m+1)+3)
  let result := RationalExpression.buildSum terms
  (result.1,listIndexEnumerationWork d+result.2+2)

def matrixMulBuildBound (r d m : ℕ) : ℕ := 32*(d+1)^3+d*(8*(r+d+m+1)+6)+3

theorem buildMatrixMulExpression_value (r d m : ℕ) (i : Fin r) (j : Fin m) :
    (buildMatrixMulExpression r d m i j).1=rationalMatrixMulExpression r d m i j := by
  simp only [buildMatrixMulExpression,RationalExpression.buildSum_value,List.map_ofFn,
    rationalMatrixMulExpression,Function.comp_def]

theorem buildMatrixMulExpression_work_le (r d m : ℕ) (i : Fin r) (j : Fin m) :
    (buildMatrixMulExpression r d m i j).2≤matrixMulBuildBound r d m := by
  have he := listIndexEnumerationWork_le d
  simp only [buildMatrixMulExpression,RationalExpression.buildSum_work,List.map_ofFn,
    List.sum_ofFn,Function.comp_apply]
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,Nat.cast_id]
  unfold matrixMulBuildBound
  nlinarith

def listStoredProductInputs (A : ListBitRationalMatrixData r d) (B : ListBitRationalMatrixData d m) :
    ((Fin r × Fin d) ⊕ (Fin d × Fin m)) → BitListFraction :=
  Sum.elim (fun p => listMatrixRead listCopyFraction A p.1 p.2)
    (fun p => listMatrixRead listCopyFraction B p.1 p.2)

def listStoredProductLookupWork (A : ListBitRationalMatrixData r d) (B : ListBitRationalMatrixData d m) :
    ((Fin r × Fin d) ⊕ (Fin d × Fin m)) → ℕ :=
  Sum.elim (fun p => listMatrixReadWork listCopyFraction listCopyFractionWork A p.1 p.2)
    (fun p => listMatrixReadWork listCopyFraction listCopyFractionWork B p.1 p.2)

theorem listStoredProductInputs_eq (A : ListBitRationalMatrixData r d) (B : ListBitRationalMatrixData d m) :
    listStoredProductInputs A B=booleanMatrixMulInputs (rectangularListFractionMatrix A) (rectangularListFractionMatrix B) := by
  funext p
  cases p with
  | inl p => exact listMatrixRead_eq listCopyFraction listCopyFraction_eq A p.1 p.2
  | inr p => exact listMatrixRead_eq listCopyFraction listCopyFraction_eq B p.1 p.2

def constructedListMatrixMul (A : ListBitRationalMatrixData r d) (B : ListBitRationalMatrixData d m) :
    ListBitRationalMatrixData r m :=
  BooleanListArray.ofFn fun i => BooleanListArray.ofFn fun j =>
    let expression := buildMatrixMulExpression r d m i j
    expression.1.encoded (listStoredProductInputs A B)

def matrixProductAllocationWork (r m : ℕ) : ℕ :=
  listIndexEnumerationWork r+r*listIndexEnumerationWork m+2*r*m+2*r+1

def constructedListMatrixMulWork (A : ListBitRationalMatrixData r d) (B : ListBitRationalMatrixData d m) : ℕ :=
  matrixProductAllocationWork r m+
    ∑ i : Fin r,∑ j : Fin m,
      let expression := buildMatrixMulExpression r d m i j
      expression.2+expression.1.work (listStoredProductInputs A B)+
        expression.1.lookupWork (listStoredProductLookupWork A B)

theorem constructedListMatrixMul_eq (A : ListBitRationalMatrixData r d) (B : ListBitRationalMatrixData d m) :
    listMatrixVector (constructedListMatrixMul A B)=
      booleanMatrixMul (rectangularListFractionMatrix A) (rectangularListFractionMatrix B) := by
  simp only [constructedListMatrixMul,listMatrixVector_ofFn,BooleanListArray.ofFn_toVector,
    booleanMatrixMul,buildMatrixMulExpression_value,listStoredProductInputs_eq]

theorem constructedListMatrixMul_value (A : ListBitRationalMatrixData r d) (B : ListBitRationalMatrixData d m)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hB : ∀ i j,(rectangularListFractionMatrix B i j).WellFormed) (i : Fin r) (j : Fin m) :
    bitListFractionValue (rectangularListFractionMatrix (constructedListMatrixMul A B) i j)=
      ((rectangularListFractionMatrix A).map bitListFractionValue*
        (rectangularListFractionMatrix B).map bitListFractionValue) i j := by
  simp only [rectangularListFractionMatrix,constructedListMatrixMul_eq]
  exact booleanMatrixMul_value _ _ hA hB i j

theorem constructedListMatrixMul_wellFormed (A : ListBitRationalMatrixData r d) (B : ListBitRationalMatrixData d m)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hB : ∀ i j,(rectangularListFractionMatrix B i j).WellFormed) (i : Fin r) (j : Fin m) :
    (rectangularListFractionMatrix (constructedListMatrixMul A B) i j).WellFormed := by
  simp only [rectangularListFractionMatrix,constructedListMatrixMul_eq]
  exact booleanMatrixMul_wellFormed _ _ hA hB i j

theorem constructedListMatrixMul_lengths (A : ListBitRationalMatrixData r d) (B : ListBitRationalMatrixData d m)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hB : ∀ i j,(rectangularListFractionMatrix B i j).WellFormed) (L : ℕ)
    (hbitsA : ∀ i j,(rectangularListFractionMatrix A i j).numerator.length≤L ∧
      (rectangularListFractionMatrix A i j).denominator.length≤L)
    (hbitsB : ∀ i j,(rectangularListFractionMatrix B i j).numerator.length≤L ∧
      (rectangularListFractionMatrix B i j).denominator.length≤L) (i : Fin r) (j : Fin m) :
    (rectangularListFractionMatrix (constructedListMatrixMul A B) i j).numerator.length≤(d+1)*(2*L+2) ∧
      (rectangularListFractionMatrix (constructedListMatrixMul A B) i j).denominator.length≤(d+1)*(2*L+2) := by
  apply ((rectangularListFractionMatrix (constructedListMatrixMul A B) i j).value_bit_bound_iff
    (constructedListMatrixMul_wellFormed A B hA hB i j) _).mp
  rw [constructedListMatrixMul_value A B hA hB]
  exact rationalMatrixMul_bits _ _ L
    (fun i j => ((rectangularListFractionMatrix A i j).value_bit_bound_iff (hA i j) L).mpr (hbitsA i j))
    (fun i j => ((rectangularListFractionMatrix B i j).value_bit_bound_iff (hB i j) L).mpr (hbitsB i j)) i j

theorem listStoredProductLookupWork_bound (A : ListBitRationalMatrixData r d) (B : ListBitRationalMatrixData d m) (L : ℕ)
    (hbitsA : ∀ i j,(rectangularListFractionMatrix A i j).numerator.length≤L ∧
      (rectangularListFractionMatrix A i j).denominator.length≤L)
    (hbitsB : ∀ i j,(rectangularListFractionMatrix B i j).numerator.length≤L ∧
      (rectangularListFractionMatrix B i j).denominator.length≤L)
    (p : (Fin r × Fin d) ⊕ (Fin d × Fin m)) :
    listStoredProductLookupWork A B p≤(listStorageFactor r d+listStorageFactor d m)*(2*L+1) := by
  cases p with
  | inl p =>
    have h := listFractionReadWork_le A p.1 p.2 (2*L) (by
      intro i j; have hi := hbitsA i j; dsimp only [rectangularListFractionMatrix] at hi; change _+_≤_; omega)
    exact h.trans (Nat.mul_le_mul_right _ (Nat.le_add_right _ _))
  | inr p =>
    have h := listFractionReadWork_le B p.1 p.2 (2*L) (by
      intro i j; have hi := hbitsB i j; dsimp only [rectangularListFractionMatrix] at hi; change _+_≤_; omega)
    exact h.trans (Nat.mul_le_mul_right _ (Nat.le_add_left _ _))

theorem constructedListMatrixMulWork_bound (A : ListBitRationalMatrixData r d) (B : ListBitRationalMatrixData d m)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hB : ∀ i j,(rectangularListFractionMatrix B i j).WellFormed) (L : ℕ)
    (hbitsA : ∀ i j,(rectangularListFractionMatrix A i j).numerator.length≤L ∧
      (rectangularListFractionMatrix A i j).denominator.length≤L)
    (hbitsB : ∀ i j,(rectangularListFractionMatrix B i j).numerator.length≤L ∧
      (rectangularListFractionMatrix B i j).denominator.length≤L) :
    constructedListMatrixMulWork A B≤matrixProductAllocationWork r m+
      r*m*(matrixMulBuildBound r d m+(4*d+1)*
        (RationalExpression.charge (4*d+1) L+(listStorageFactor r d+listStorageFactor d m)*(2*L+1))) := by
  have hw : ∀ p,(listStoredProductInputs A B p).WellFormed := by
    rw [listStoredProductInputs_eq]
    intro p; cases p with
    | inl p => exact hA p.1 p.2
    | inr p => exact hB p.1 p.2
  have hb : ∀ p,RationalBitBound (bitListFractionValue (listStoredProductInputs A B p)) L := by
    rw [listStoredProductInputs_eq]
    intro p; cases p with
    | inl p => exact ((rectangularListFractionMatrix A p.1 p.2).value_bit_bound_iff (hA _ _) L).mpr (hbitsA _ _)
    | inr p => exact ((rectangularListFractionMatrix B p.1 p.2).value_bit_bound_iff (hB _ _) L).mpr (hbitsB _ _)
  unfold constructedListMatrixMulWork
  apply Nat.add_le_add_left
  calc
    _ ≤ ∑ _i : Fin r,∑ _j : Fin m,
        (matrixMulBuildBound r d m+(4*d+1)*
          (RationalExpression.charge (4*d+1) L+(listStorageFactor r d+listStorageFactor d m)*(2*L+1))) := by
      apply Finset.sum_le_sum
      intro i _
      apply Finset.sum_le_sum
      intro j _
      dsimp only
      rw [buildMatrixMulExpression_value]
      have hc := buildMatrixMulExpression_work_le r d m i j
      have hs := (rationalMatrixMulExpression r d m i j).work_le _ hw L hb (4*d+1)
        (rationalMatrixMulExpression_nodes i j).le
      have hl := (rationalMatrixMulExpression r d m i j).lookupWork_le _ _
        (listStoredProductLookupWork_bound A B L hbitsA hbitsB)
      rw [rationalMatrixMulExpression_nodes] at hs hl
      nlinarith
    _ = _ := by simp; ring

noncomputable def constructedMatrixMulPolynomial (r d m : ℕ) : Polynomial ℕ :=
  Polynomial.C (matrixProductAllocationWork r m+r*m*matrixMulBuildBound r d m)+
    matrixScalarWorkPolynomial (r*m) (4*d+1)+
    Polynomial.C (r*m*(4*d+1)*(listStorageFactor r d+listStorageFactor d m))*(2*Polynomial.X+1)

theorem constructedListMatrixMulWork_input_polynomial (A : ListBitRationalMatrixData r d) (B : ListBitRationalMatrixData d m)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hB : ∀ i j,(rectangularListFractionMatrix B i j).WellFormed) :
    constructedListMatrixMulWork A B≤
      (constructedMatrixMulPolynomial r d m).eval (listStoredRationalBits A+listStoredRationalBits B) := by
  let L := listStoredRationalBits A+listStoredRationalBits B
  have hbitsA : ∀ i j,(rectangularListFractionMatrix A i j).numerator.length≤L ∧
      (rectangularListFractionMatrix A i j).denominator.length≤L := by
    intro i j
    have h : (rectangularListFractionMatrix A i j).numerator.length≤listStoredRationalBits A ∧
        (rectangularListFractionMatrix A i j).denominator.length≤listStoredRationalBits A := listStoredRationalBits_cell A i j
    exact ⟨h.1.trans (Nat.le_add_right _ _),h.2.trans (Nat.le_add_right _ _)⟩
  have hbitsB : ∀ i j,(rectangularListFractionMatrix B i j).numerator.length≤L ∧
      (rectangularListFractionMatrix B i j).denominator.length≤L := by
    intro i j
    have h : (rectangularListFractionMatrix B i j).numerator.length≤listStoredRationalBits B ∧
        (rectangularListFractionMatrix B i j).denominator.length≤listStoredRationalBits B := listStoredRationalBits_cell B i j
    exact ⟨h.1.trans (Nat.le_add_left _ _),h.2.trans (Nat.le_add_left _ _)⟩
  have hs := constructedListMatrixMulWork_bound A B hA hB L hbitsA hbitsB
  have hp := expression_charge_le_polynomial (r*m) (4*d+1) L
  simp only [constructedMatrixMulPolynomial,Polynomial.eval_add,Polynomial.eval_C,
    Polynomial.eval_mul,Polynomial.eval_ofNat,Polynomial.eval_X,Polynomial.eval_one]
  change _≤matrixProductAllocationWork r m+r*m*matrixMulBuildBound r d m+
    (matrixScalarWorkPolynomial (r*m) (4*d+1)).eval L+
      r*m*(4*d+1)*(listStorageFactor r d+listStorageFactor d m)*(2*L+1)
  exact hs.trans (by nlinarith)
end Optss
