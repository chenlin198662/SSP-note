import Optss.StoredQuotientVertices

/-!
# Running the verified lattice-box routine on an actual quotient body

The input lattice is the complete standard integer lattice, encoded by its
identity matrix. The polytope input is the explicit list of all mapped box
corners. This connects the executable quotient to the concrete boxing result.
-/
namespace Optss
open scoped BigOperators Pointwise
variable {d e : ℕ}

def storedStandardLattice (e : ℕ) : ListBitRationalMatrixData e e :=
  BooleanListArray.ofFn fun i => BooleanListArray.ofFn fun j => rationalBitRepresentation (if i=j then 1 else 0)

theorem storedStandardLattice_entry (e : ℕ) (i j : Fin e) :
    rectangularListFractionMatrix (storedStandardLattice e) i j=rationalBitRepresentation (if i=j then 1 else 0) := by
  simp [rectangularListFractionMatrix,storedStandardLattice,listMatrixVector,
    BooleanListArray.ofFn,BooleanListArray.toVector,Vector.get]

theorem storedStandardLattice_wellFormed (e : ℕ) :
    ∀ i j,(rectangularListFractionMatrix (storedStandardLattice e) i j).WellFormed := by
  intro i j
  rw [storedStandardLattice_entry]
  exact rationalBitRepresentation_wellFormed _

theorem storedStandardLattice_value (e : ℕ) : storedRationalMatrix (storedStandardLattice e)=1 := by
  ext i j
  simp [storedRationalMatrix,storedStandardLattice_entry,rationalBitRepresentation_value,Matrix.one_apply]

theorem storedStandardLattice_span (e : ℕ) :
    (Submodule.span ℤ (Set.range (fun j i => (storedRationalMatrix (storedStandardLattice e) i j:ℝ))) : Set (Fin e→ℝ))=
      Set.range (@realVector e) := by
  rw [←basisIntegerLattice_standard, basisIntegerLattice_eq_integerSpan]
  have he : (fun j i => (storedRationalMatrix (storedStandardLattice e) i j:ℝ))=
      (Pi.basisFun ℝ (Fin e) : Fin e→(Fin e→ℝ)) := by
    funext j i
    rw [storedStandardLattice_value]
    by_cases h : j=i <;> simp [Matrix.one_apply,Pi.basisFun_apply,Pi.single_apply,h,eq_comm]
  rw [he]

def computedQuotientBox (π : (Fin d→ℤ) →ₗ[ℤ] (Fin e→ℤ)) (β : Fin d→ℕ) :
    Option (BooleanLatticeBoxResult e) :=
  bodySymmetricLatticeBox (storedQuotientVertices π β) (storedStandardLattice e)

theorem computedQuotientBox_spec (he : 0<e)
    (π : (Fin d→ℤ) →ₗ[ℤ] (Fin e→ℤ)) (hπ : Function.Surjective π)
    (β : Fin d→ℕ) (hβ : ∀ j,0<β j) :
    ∃ box,computedQuotientBox π β=some box ∧
      ∃ b : Basis (Fin e) ℝ (Fin e→ℝ),
        (∀ i j,(storedRationalMatrix box.columns i j:ℝ)=b j i) ∧
        basisIntegerLattice b=Set.range (@realVector e) ∧
        (∀ j,1≤decodedLatticeBoxWidths box j) ∧
        integerLinearImageBox π β⊆basisCoefficientBox b (decodedLatticeBoxWidths box) ∧
        basisCoefficientBox b (decodedLatticeBoxWidths box)⊆
          latticeBoxingDilation e ((e.factorial:ℝ)*sharpLatticeDefectBound e) •integerLinearImageBox π β ∧
        ∀ s : ℝ,(integerPoints (s •basisCoefficientBox b (decodedLatticeBoxWidths box))
            ((basisCoefficientBox_compact b _).smul s).isBounded).card≤
          (latticeBoxingResidueModulus e (sharpLatticeDefectBound e))^e*
            (integerPoints (s •integerLinearImageBox π β)
              ((integerLinearImageBox_compact π β).smul s).isBounded).card := by
  obtain ⟨u,hind,hu⟩ := integerLinearImageBox_independent π hπ β (fun j => hβ j)
  have hdet : (storedRationalMatrix (storedStandardLattice e)).det≠0 := by
    rw [storedStandardLattice_value,Matrix.det_one]
    exact one_ne_zero
  have hsym : ∀ x∈storedVertexHull (storedQuotientVertices π β),
      -x∈storedVertexHull (storedQuotientVertices π β) := by
    rw [storedQuotientVertices_hull]
    exact fun _ hx => integerLinearImageBox_symmetric π β hx
  have hΛu : ∀ j,realVector (u j)∈Submodule.span ℤ
      (Set.range (fun j i => (storedRationalMatrix (storedStandardLattice e) i j:ℝ))) := by
    intro j
    change realVector (u j)∈(Submodule.span ℤ
      (Set.range (fun j i => (storedRationalMatrix (storedStandardLattice e) i j:ℝ))) : Set _)
    rw [storedStandardLattice_span]
    exact Set.mem_range_self _
  obtain ⟨_,box,hbox,_,b,hcols,hΛ,_,hpos,hinner,houter,hcount⟩ := bodySymmetricLatticeBox_spec he
    (storedQuotientVertices π β) (storedStandardLattice e) (storedQuotientVertices_wellFormed π β)
    (storedStandardLattice_wellFormed e) hdet hsym (fun j => realVector (u j)) hind
    (by simpa only [storedQuotientVertices_hull] using hu) hΛu
  have hΛ' : basisIntegerLattice b=Set.range (@realVector e) := hΛ.trans (storedStandardLattice_span e)
  refine ⟨box,hbox,b,hcols,hΛ',hpos,?_,?_,?_⟩
  · simpa only [storedQuotientVertices_hull] using hinner
  · simpa only [storedQuotientVertices_hull] using houter
  · intro s
    have h := hcount s
    rw [basisLatticePoints_standard_card b hΛ',basisLatticePoints_standard_card b hΛ'] at h
    simpa only [storedQuotientVertices_hull] using h

/-- The integer columns used by the next GAP are extracted from the returned
rational encodings, with integrality proved from equality of the full lattice. -/
def latticeBoxIntegerColumn (box : BooleanLatticeBoxResult e) (j : Fin e) : Fin e→ℤ :=
  fun i => (storedRationalMatrix box.columns i j).num

theorem latticeBoxIntegerColumn_cast (box : BooleanLatticeBoxResult e)
    (b : Basis (Fin e) ℝ (Fin e→ℝ))
    (hcols : ∀ i j,(storedRationalMatrix box.columns i j:ℝ)=b j i)
    (hΛ : basisIntegerLattice b=Set.range (@realVector e)) (j : Fin e) :
    realVector (latticeBoxIntegerColumn box j)=b j := by
  have hj : b j∈basisIntegerLattice b := by
    rw [basisIntegerLattice_eq_integerSpan]
    exact Submodule.subset_span (Set.mem_range_self _)
  rw [hΛ] at hj
  obtain ⟨z,hz⟩ := hj
  ext i
  have hrat : storedRationalMatrix box.columns i j=(z i:ℚ) := by
    have hi := congrFun hz i
    change (z i:ℝ)=b j i at hi
    have h := (hcols i j).trans hi.symm
    exact_mod_cast h
  change ((storedRationalMatrix box.columns i j).num:ℝ)=b j i
  rw [hrat,Rat.num_intCast]
  exact congrFun hz i
end Optss
