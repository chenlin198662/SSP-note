import Optss.ReserveFilling
import Optss.Copies

/-!
# Reserved-item filling with counted multiplicities

The full conclusion of Lemma 3.5 for natural-valued reserve and remainder
capacities on the same type family. Copy expansion is used only to transport
the geometric theorem; the exported statement uses counts throughout.
-/
namespace Optss
open scoped BigOperators Pointwise
noncomputable section

variable {ι E : Type*} [Fintype ι]

section Algebra
variable [AddCommGroup E] [Module ℝ E]

omit [Module ℝ E] in
/-- The copy-labelled and counted subset-sum supports are the same set. -/
theorem subsetSums_expandedCopy_eq_countSums (v : ι → E) (c : ι → ℕ) :
    subsetSums (expandedCopy v c) = countSums v (fun i => (c i : ℤ)) := by
  ext t
  exact (countSums_iff_expanded_subsetSums v c t).symm

/-- The unit-capacity zonotope is the convex hull of actual subset sums. -/
theorem convexHull_subsetSums (v : ι → E) :
    convexHull ℝ (subsetSums v) = zonotope v (fun _ => 1) := by
  have hs : subsetSums v = countSums v (fun _ => 1) :=
    Set.ext (fun t => mem_subsetSums_iff_binary v t)
  rw [hs]
  simpa using convexHull_countSums v (fun _ => 1) (fun _ => by norm_num)

/-- Expanding integer multiplicities into labelled copies preserves the zonotope. -/
theorem zonotope_expandedCopy (v : ι → E) (c : ι → ℕ) :
    zonotope (expandedCopy v c) (fun _ => 1) = zonotope v (fun i => (c i : ℝ)) := by
  rw [← convexHull_subsetSums, subsetSums_expandedCopy_eq_countSums]
  simpa using convexHull_countSums v (fun i => (c i : ℤ)) (fun _ => by positivity)

omit [Module ℝ E] in
/-- The union of the reserve and remainder copies has exactly the summed capacities. -/
theorem subsetSums_expandedCopy_sum (v : ι → E) (cR cB : ι → ℕ) :
    subsetSums (Sum.elim (expandedCopy v cR) (expandedCopy v cB)) =
      countSums v (fun i => ((cR i + cB i : ℕ) : ℤ)) := by
  rw [subsetSums_sum_type, subsetSums_expandedCopy_eq_countSums,
    subsetSums_expandedCopy_eq_countSums]
  ext t
  symm
  simpa only [Nat.cast_add] using mem_countSums_add_iff v
    (fun i => (cR i : ℤ)) (fun i => (cB i : ℤ)) (fun _ => by positivity)
    (fun _ => by positivity) t

/-- The zonotope of the disjoint copy families has the summed capacities. -/
theorem zonotope_expandedCopy_sum (v : ι → E) (cR cB : ι → ℕ) :
    zonotope (Sum.elim (expandedCopy v cR) (expandedCopy v cB)) (fun _ => 1) =
      zonotope v (fun i => ((cR i + cB i : ℕ) : ℝ)) := by
  rw [← convexHull_subsetSums, subsetSums_expandedCopy_sum]
  simpa using convexHull_countSums v (fun i => ((cR i + cB i : ℕ) : ℤ))
    (fun _ => by positivity)

end Algebra

section FullStatement
variable [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]

/-- Full counted form of Lemma 3.5, including its final interior-containment claim.

`cR` and `cB` are the reserve and remainder multiplicities of each type; the
reserve size is their actual total `∑ i, cR i`, not the number of distinct types.
-/
theorem counted_reserved_zonotope_filling {C : Set E} (hconv : Convex ℝ C)
    (hcompact : IsCompact C) (hne : C.Nonempty) (hsym : ∀ x ∈ C, -x ∈ C)
    (Λ : AddSubgroup E) (v : ι → E) (cR cB : ι → ℕ)
    (hvC : ∀ i, v i ∈ C) (hvΛ : ∀ i, v i ∈ Λ)
    {z₀ : E} (hz₀Λ : z₀ ∈ Λ)
    (hfill : {z₀} + ((Module.finrank ℝ E : ℝ) • C ∩ (Λ : Set E)) ⊆
      countSums v (fun i => (cR i : ℤ))) :
    let K := {z₀} + zonotope v (fun i => (cB i : ℝ))
    let Z := zonotope v (fun i => ((cR i + cB i : ℕ) : ℝ))
    let S := countSums v (fun i => ((cR i + cB i : ℕ) : ℤ))
    let q := ∑ i, cR i
    (K ∩ (Λ : Set E) ⊆ S) ∧ (S ⊆ Z ∩ (Λ : Set E)) ∧
    (K ⊆ Z) ∧ (Z ⊆ K + (q : ℝ) • C) ∧
    (∀ z ∈ Λ, {z} + (q : ℝ) • C ⊆ Z → z ∈ K ∩ (Λ : Set E)) := by
  have hfill' : {z₀} + ((Module.finrank ℝ E : ℝ) • C ∩ (Λ : Set E)) ⊆
      subsetSums (expandedCopy v cR) := by
    rw [subsetSums_expandedCopy_eq_countSums]
    exact hfill
  have h := reserved_zonotope_filling hconv hcompact hne hsym Λ
    (expandedCopy v cR) (expandedCopy v cB)
    (fun i => hvC i.1) (fun i => hvC i.1)
    (fun i => hvΛ i.1) (fun i => hvΛ i.1) hz₀Λ hfill'
  dsimp only at h ⊢
  simpa only [zonotope_expandedCopy, zonotope_expandedCopy_sum,
    subsetSums_expandedCopy_sum, card_copyIndex] using h

end FullStatement
end
end Optss
