import Optss.SievedPrimeWork
import Optss.BitListModularPowerWork

/-!
# The computed modeling multiplier

Each nonzero difference has its inverse computed once by Boolean modular
exponentiation. Its marks are materialized and written to a Boolean array;
the answer is the first surviving positive address.
-/
namespace Optss

def computedModelingInverse (e : ℤ) (q : ℕ) : ℕ :=
  binaryDigitsValue (bitListPrimeInverse ((e : ZMod q).val.bits) q)

theorem computedModelingInverse_correct (e : ℤ) (q : ℕ) [Fact q.Prime]
    (he : |e|<(q:ℤ)) (he0 : e≠0) :
    (computedModelingInverse e q : ZMod q)=(e:ZMod q)⁻¹ := by
  have hx : (e : ZMod q)≠0 := fun h => he0 (bounded_intCast_eq_zero he h)
  simpa only [computedModelingInverse,binaryDigitsValue_bits,ZMod.natCast_zmod_val] using
    bitListPrimeInverse_correct ((e : ZMod q).val.bits) q
      (by simpa only [binaryDigitsValue_bits,ZMod.natCast_zmod_val] using hx)

def computedModelingMarkRow (e : ℤ) (p q : ℕ) : List ℕ :=
  let inv := computedModelingInverse e q
  (List.range ((q-1)/p)).map (fun j =>
    ((((j+1)*p : ℕ) : ZMod q)*(inv : ZMod q)).val)

theorem mem_computedModelingMarkRow (e : ℤ) (p q n : ℕ) [Fact q.Prime]
    (he : |e|<(q:ℤ)) (he0 : e≠0) :
    n∈computedModelingMarkRow e p q ↔
      ∃ t∈Finset.Icc 1 ((q-1)/p), n=(((t*p:ℕ):ZMod q)/(e:ZMod q)).val := by
  simp only [computedModelingMarkRow,List.mem_map,List.mem_range,
    computedModelingInverse_correct e q he he0,←div_eq_mul_inv,Finset.mem_Icc]
  constructor
  · rintro ⟨j,hj,h⟩
    exact ⟨j+1,⟨by omega,by omega⟩,h.symm⟩
  · rintro ⟨t,⟨ht,ht'⟩,h⟩
    refine ⟨t-1,by omega,?_⟩
    simpa only [Nat.sub_add_cancel ht] using h.symm

def computedModelingMarkSchedule (data : List ℤ) (p q : ℕ) : List ℕ :=
  (data.filter (fun e => e≠0)).flatMap (fun e => computedModelingMarkRow e p q)

theorem mem_computedModelingMarkSchedule (data : List ℤ) (p q n : ℕ) [Fact q.Prime]
    (hD : ∀ e∈data, |e|<(q:ℤ)) :
    n∈computedModelingMarkSchedule data p q ↔
      ∃ z∈modelingMarks data.toFinset p q, z.val=n := by
  simp only [computedModelingMarkSchedule,List.mem_flatMap,List.mem_filter,decide_eq_true_eq]
  constructor
  · rintro ⟨e,⟨he,he0⟩,hn⟩
    obtain ⟨t,ht,h⟩ := (mem_computedModelingMarkRow e p q n (hD e he) he0).mp hn
    refine ⟨_,Finset.mem_image.mpr ⟨(e,t),?_,rfl⟩,h.symm⟩
    exact Finset.mem_product.mpr ⟨Finset.mem_erase.mpr ⟨he0,List.mem_toFinset.mpr he⟩,ht⟩
  · rintro ⟨z,hz,hzn⟩
    obtain ⟨⟨e,t⟩,het,rfl⟩ := Finset.mem_image.mp hz
    obtain ⟨he,ht⟩ := Finset.mem_product.mp het
    obtain ⟨he0,he⟩ := Finset.mem_erase.mp he
    have he' := List.mem_toFinset.mp he
    exact ⟨e,⟨he',he0⟩,(mem_computedModelingMarkRow e p q n (hD e he') he0).mpr
      ⟨t,ht,hzn.symm⟩⟩

def computedModelingFlags (data : List ℤ) (p q : ℕ) : Array Bool :=
  markFalseArray (Array.replicate q true) (0::computedModelingMarkSchedule data p q)

@[simp] theorem computedModelingFlags_size (data : List ℤ) (p q : ℕ) :
    (computedModelingFlags data p q).size=q := by simp [computedModelingFlags]

theorem computedModelingFlags_correct (data : List ℤ) (p q n : ℕ) [Fact q.Prime]
    (hD : ∀ e∈data, |e|<(q:ℤ)) (hn : n<q) :
    (computedModelingFlags data p q)[n]?=some true ↔
      n≠0 ∧ (n:ZMod q)∉modelingMarks data.toFinset p q := by
  rw [computedModelingFlags,markFalseArray_read]
  simp only [Array.getElem?_replicate,hn,if_pos,true_and,List.mem_cons,not_or,
    Option.some.injEq,mem_computedModelingMarkSchedule data p q n hD]
  have hz : ∀ z : ZMod q, z.val=n ↔ z=(n:ZMod q) := by
    intro z
    constructor
    · intro h; rw [←h,ZMod.natCast_zmod_val]
    · intro h; rw [h,ZMod.val_natCast_of_lt hn]
  simp only [hz,exists_eq_right]

def computedModelingMultiplier (data : List ℤ) (p q : ℕ) : Option ℕ :=
  scanPrimeFlags (computedModelingFlags data p q) 0 q

theorem computedModelingMultiplier_spec (data : List ℤ) (p q n : ℕ) [Fact q.Prime]
    (hD : ∀ e∈data, |e|<(q:ℤ)) (h : computedModelingMultiplier data p q=some n) :
    0<n ∧ n<q ∧ (n:ZMod q)∉modelingMarks data.toFinset p q := by
  have hp := List.find?_some h
  change (decide (0<n ∧ n<q) && ((computedModelingFlags data p q)[n]? == some true))=true at hp
  simp only [Bool.and_eq_true,decide_eq_true_eq,beq_iff_eq] at hp
  exact ⟨hp.1.1,hp.1.2,((computedModelingFlags_correct data p q n hD hp.1.2).mp hp.2).2⟩

theorem computedModelingMultiplier_exists (data : List ℤ) (p q : ℕ) [Fact q.Prime]
    (hD : ∀ e∈data, |e|<(q:ℤ)) (hp : (data.toFinset.erase 0).card<p) :
    ∃ n : ℕ, computedModelingMultiplier data p q=some n ∧
      0<n ∧ n<q ∧ (n:ZMod q)∉modelingMarks data.toFinset p q := by
  have hc : (modelingMarks data.toFinset p q).card<
      ((Finset.univ : Finset (ZMod q)).erase 0).card := by
    rw [Finset.card_erase_of_mem (Finset.mem_univ _),Finset.card_univ,ZMod.card]
    exact (modelingMarks_card_le _ _ _).trans_lt
      (modeling_sieve_count (Fact.out : q.Prime).one_lt hp)
  obtain ⟨z,hz,hnot⟩ := Finset.exists_mem_not_mem_of_card_lt_card hc
  have hz0 : z≠0 := (Finset.mem_erase.mp hz).1
  have hzv : 0<z.val := by
    apply Nat.pos_of_ne_zero
    intro h
    apply hz0
    simpa only [h,Nat.cast_zero] using (ZMod.natCast_zmod_val z).symm
  have hflag : (computedModelingFlags data p q)[z.val]?=some true :=
    (computedModelingFlags_correct data p q z.val hD (ZMod.val_lt z)).mpr
      ⟨hzv.ne',by simpa only [ZMod.natCast_zmod_val] using hnot⟩
  have hne : computedModelingMultiplier data p q≠none := by
    intro he
    rw [computedModelingMultiplier,scanPrimeFlags,List.find?_eq_none] at he
    have hmem : z.val∈List.range (computedModelingFlags data p q).size := by
      simpa only [List.mem_range,computedModelingFlags_size] using ZMod.val_lt z
    have hh := he z.val hmem
    simp only [hzv,ZMod.val_lt z,and_self,decide_true,Bool.true_and,hflag,
      beq_self_eq_true,not_true_eq_false] at hh
  cases he : computedModelingMultiplier data p q with
  | none => exact False.elim (hne he)
  | some n => exact ⟨n,rfl,computedModelingMultiplier_spec data p q n hD he⟩

end Optss
