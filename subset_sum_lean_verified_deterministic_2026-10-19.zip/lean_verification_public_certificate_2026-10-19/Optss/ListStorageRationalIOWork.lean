import Optss.ListStorageRationalIO

/-!
# Copying and traversal costs of list-stored rational input/output

Every magnitude copy is charged by `bitWordCopyWork`; scalar costs use the
verified Boolean circuits. Recursive list traversal counts branch visits and
constructed list cells. The common denominator is computed once and its
payload is copied explicitly for each clearing or unscaling call.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

def ioCopyFractionWork (q : BitListFraction) : ℕ :=
  bitWordCopyWork q.numerator+bitWordCopyWork q.denominator+1

def ioCopyIntegerWork (z : BitListInteger) : ℕ := bitWordCopyWork z.digits+1

def ioMapWork {α : Type*} (w : α → ℕ) : List α → ℕ
  | [] => 1
  | x::xs => w x+ioMapWork w xs+2

theorem ioMapWork_eq {α : Type*} (w : α → ℕ) (xs : List α) :
    ioMapWork w xs = (xs.map w).sum+2*xs.length+1 := by
  induction xs with
  | nil => simp [ioMapWork]
  | cons x xs ih => simp [ioMapWork,ih]; omega

def ioMatrixMapWork {α : Type*} (w : α → ℕ)
    (A : BooleanListArray (BooleanListArray α d) r) : ℕ :=
  ioMapWork (fun row => ioMapWork w row.data) A.data

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

private theorem listArray_data_eq_ofFn {α : Type*} {n : ℕ} (A : BooleanListArray α n) :
    A.data = List.ofFn A.toVector.get := by
  apply List.ext_getElem
  · simp [A.length_eq]
  · intro i hi hj
    simp only [List.getElem_ofFn,BooleanListArray.toVector,get_ofFn]

theorem ioMatrixMapWork_eq {α : Type*} (w : α → ℕ)
    (A : BooleanListArray (BooleanListArray α d) r) :
    ioMatrixMapWork w A =
      (∑ i : Fin r, ∑ j : Fin d, w (((ioMatrixVector A).get i).get j))+2*r*d+3*r+1 := by
  simp only [ioMatrixMapWork,ioMapWork_eq,listArray_data_eq_ofFn,List.map_ofFn,
    List.sum_ofFn,List.length_ofFn,ioMatrixVector,get_ofFn,Function.comp_apply]
  simp only [Finset.sum_add_distrib,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,Nat.cast_id]
  ring

def ioDenominatorsIntoWork : List BitListFraction → ℕ
  | [] => 1
  | q::qs => ioDenominatorsIntoWork qs+bitWordCopyWork q.denominator+2

def ioRowDenominatorsIntoWork : List (BooleanListArray BitListFraction d) → ℕ
  | [] => 1
  | row::rows => ioRowDenominatorsIntoWork rows+ioDenominatorsIntoWork row.data+2

theorem ioDenominatorsIntoWork_eq (xs : List BitListFraction) :
    ioDenominatorsIntoWork xs = ioMapWork (fun q => bitWordCopyWork q.denominator) xs := by
  induction xs with
  | nil => rfl
  | cons q qs ih => simp only [ioDenominatorsIntoWork,ioMapWork,ih]; omega

theorem ioRowDenominatorsIntoWork_eq (xs : List (BooleanListArray BitListFraction d)) :
    ioRowDenominatorsIntoWork xs = ioMapWork (fun row => ioMapWork
      (fun q => bitWordCopyWork q.denominator) row.data) xs := by
  induction xs with
  | nil => rfl
  | cons row rows ih => simp only [ioRowDenominatorsIntoWork,ioMapWork,ioDenominatorsIntoWork_eq,ih]; omega

def listStoredClearCellWork (D : List Bool) (q : BitListFraction) : ℕ :=
  bitWordCopyWork D+ioCopyFractionWork q+
    bitListClearFractionCost (bitWordCopy D) (ioCopyFraction q)

def listStoredClearRationalInputWork
    (A : BooleanListArray (BooleanListArray BitListFraction d) r) : ℕ :=
  let D := listStoredInputDenominator A
  ioRowDenominatorsIntoWork A.data+bitListProductCost (listStoredDenominators A)+
    ioMatrixMapWork (listStoredClearCellWork D) A

theorem listStoredClearRationalInputWork_eq
    (A : BooleanListArray (BooleanListArray BitListFraction d) r) :
    listStoredClearRationalInputWork A = bitListClearRationalInputCost (ioMatrixVector A)+
      (∑ i : Fin r, ∑ j : Fin d,
        (bitWordCopyWork (((ioMatrixVector A).get i).get j).denominator+
        bitWordCopyWork (listStoredInputDenominator A)+
        ioCopyFractionWork (((ioMatrixVector A).get i).get j)))+4*r*d+6*r+2 := by
  unfold listStoredClearRationalInputWork
  rw [ioRowDenominatorsIntoWork_eq]
  change ioMatrixMapWork (fun q => bitWordCopyWork q.denominator) A+_+_ = _
  simp only [ioMatrixMapWork_eq,listStoredClearCellWork,bitWordCopy_eq,ioCopyFraction_eq,
    listStoredDenominators_eq,listStoredInputDenominator_eq,bitListClearRationalInputCost,
    Finset.sum_add_distrib]
  ring

/-- A uniform bound includes every physical input-payload copy and traversal
in addition to all Boolean arithmetic used to clear denominators. -/
theorem listStoredClearRationalInputWork_bound
    (A : BooleanListArray (BooleanListArray BitListFraction d) r) (L : ℕ)
    (h : ∀ i j, (((ioMatrixVector A).get i).get j).numerator.length ≤ L ∧
      (((ioMatrixVector A).get i).get j).denominator.length ≤ L)
    (hp : ∀ i j, 0 < binaryDigitsValue (((ioMatrixVector A).get i).get j).denominator) :
    listStoredClearRationalInputWork A ≤
      128*(r*d+r+1)*((r*d+1)*(L+1)+1)^2 := by
  let M := (r*d+1)*(L+1)
  have hLM : L ≤ M := by dsimp [M]; nlinarith [Nat.zero_le (r*d*L)]
  have hD : (listStoredInputDenominator A).length ≤ M := by
    rw [listStoredInputDenominator_eq]
    exact (bitRationalInputDenominator_length _ L (fun i j => (h i j).2)).trans (by dsimp [M]; nlinarith)
  have hscalar := bitListClearRationalInputCost_bound (ioMatrixVector A) L h hp
  have hcopy : (∑ i : Fin r, ∑ j : Fin d,
        (bitWordCopyWork (((ioMatrixVector A).get i).get j).denominator+
        bitWordCopyWork (listStoredInputDenominator A)+
        ioCopyFractionWork (((ioMatrixVector A).get i).get j))) ≤ r*d*(8*M+5) := by
    calc
      _ ≤ ∑ _i : Fin r, ∑ _j : Fin d, (8*M+5) := by
        apply Finset.sum_le_sum
        intro i _
        apply Finset.sum_le_sum
        intro j _
        have hn := (h i j).1.trans hLM
        have hd := (h i j).2.trans hLM
        simp only [ioCopyFractionWork,bitWordCopyWork_eq]
        omega
      _ = _ := by simp; ring
  rw [listStoredClearRationalInputWork_eq]
  change _ ≤ 128*(r*d+r+1)*(M+1)^2
  change _ ≤ 105*(r*d)*(M+1)^2+1 at hscalar
  have hsmall : 8*M+9 ≤ 9*(M+1)^2 := by nlinarith
  have hsq : 1 ≤ (M+1)^2 := by nlinarith
  have hc := Nat.mul_le_mul_left (r*d) hsmall
  have hr := Nat.mul_le_mul_left (6*r+3) hsq
  nlinarith

/-- Per-output-cell cost includes copies of both source magnitudes. -/
def listStoredUnscaleCellWork (D : List Bool) (z : BitListInteger) : ℕ :=
  bitWordCopyWork D+ioCopyIntegerWork z+
    bitListNormalizeFractionCost (ioCopyInteger z).digits (bitWordCopy D)

def listStoredUnscaleWork (D : List Bool)
    (A : BooleanListArray (BooleanListArray BitListInteger d) r) : ℕ :=
  ioMatrixMapWork (listStoredUnscaleCellWork D) A

theorem listStoredUnscaleWork_eq (D : List Bool)
    (A : BooleanListArray (BooleanListArray BitListInteger d) r) :
    listStoredUnscaleWork D A =
      (∑ i : Fin r, ∑ j : Fin d,
        (bitWordCopyWork D+ioCopyIntegerWork (((ioMatrixVector A).get i).get j)+
          bitListNormalizeFractionCost (((ioMatrixVector A).get i).get j).digits D))+2*r*d+3*r+1 := by
  simp only [listStoredUnscaleWork,ioMatrixMapWork_eq,listStoredUnscaleCellWork,
    ioCopyInteger_eq,bitWordCopy_eq]

theorem listStoredUnscaleWork_bound (D : List Bool)
    (A : BooleanListArray (BooleanListArray BitListInteger d) r) (L : ℕ)
    (hD : 0 < binaryDigitsValue D) (hDl : D.length ≤ L)
    (h : ∀ i j, (((ioMatrixVector A).get i).get j).digits.length ≤ L) :
    listStoredUnscaleWork D A ≤ 144*(r*d+r+1)*(L+1)^3 := by
  have hcell (i : Fin r) (j : Fin d) :
      bitWordCopyWork D+ioCopyIntegerWork (((ioMatrixVector A).get i).get j)+
        bitListNormalizeFractionCost (((ioMatrixVector A).get i).get j).digits D ≤
      128*(L+1)^3+4*L+3 := by
    have hz := h i j
    have hs := bitListUnscaleInteger_cost D (((ioMatrixVector A).get i).get j) hD L hz hDl
    simp only [ioCopyIntegerWork,bitWordCopyWork_eq]
    omega
  have hsum : (∑ i : Fin r, ∑ j : Fin d,
      (bitWordCopyWork D+ioCopyIntegerWork (((ioMatrixVector A).get i).get j)+
        bitListNormalizeFractionCost (((ioMatrixVector A).get i).get j).digits D)) ≤
      r*d*(128*(L+1)^3+4*L+3) := by
    calc
      _ ≤ ∑ _i : Fin r, ∑ _j : Fin d, (128*(L+1)^3+4*L+3) := by
        exact Finset.sum_le_sum fun i _ => Finset.sum_le_sum fun j _ => hcell i j
      _ = _ := by simp; ring
  rw [listStoredUnscaleWork_eq]
  have hpow : 1 ≤ (L+1)^3 := one_le_pow₀ (by omega)
  have hlin : L+1 ≤ (L+1)^3 := by
    simpa using Nat.pow_le_pow_right (by omega : 1 ≤ L+1) (by omega : 1 ≤ 3)
  have hr := Nat.mul_le_mul_left (3*r+1) hpow
  have hsmall : 128*(L+1)^3+4*L+5 ≤ 136*(L+1)^3 := by omega
  calc
    _ ≤ r*d*(128*(L+1)^3+4*L+3)+2*r*d+3*r+1 := by omega
    _ = r*d*(128*(L+1)^3+4*L+5)+(3*r+1) := by ring
    _ ≤ r*d*(136*(L+1)^3)+(3*r+1)*(L+1)^3 :=
      Nat.add_le_add (Nat.mul_le_mul_left _ hsmall) (by simpa only [Nat.mul_one] using hr)
    _ = (136*(r*d)+3*r+1)*(L+1)^3 := by ring
    _ ≤ 144*(r*d+r+1)*(L+1)^3 := Nat.mul_le_mul_right _ (by omega)

end Optss
