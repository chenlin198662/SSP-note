import Optss.CommonPhaseBudget

/-!
# Uniform logarithmic phase lengths

The actual phase determinant is bounded by a fixed factor times its scalar
potential. Under the paper's nontrivial range `h ≤ 2N`, both logarithmic phase
length and restart count are bounded by a constant times `log₂(N+2)+1`.
-/
namespace Optss
noncomputable section
open scoped BigOperators
set_option maxHeartbeats 1000000

/-- Explicit logarithmic bound, retaining all small and zero determinant cases. -/
theorem common_phase_log_bound (D K M h N : ℕ) (hh : h ≤ 2*N)
    (hM : M ≤ h*N+1) (hD : D ≤ K*(M+2)) :
    Nat.log 2 D+1 ≤ (Nat.log 2 K+5)*(Nat.log 2 (N+2)+1) := by
  have hbasic : D ≤ 4*K*(N+2)^2 := by
    have hm : M+2 ≤ 4*(N+2)^2 := by nlinarith [Nat.mul_le_mul_right N hh]
    exact hD.trans ((Nat.mul_le_mul_left K hm).trans_eq (by ring))
  have hk : K < 2^(Nat.log 2 K+1) := Nat.lt_pow_succ_log_self (by norm_num : 1 < 2) K
  have hn : N+2 < 2^(Nat.log 2 (N+2)+1) := Nat.lt_pow_succ_log_self (by norm_num : 1 < 2) (N+2)
  have hp : 0 < 2^(Nat.log 2 (N+2)+1) := by positivity
  have hsq : (N+2)^2 ≤ (2^(Nat.log 2 (N+2)+1))^2 := Nat.pow_le_pow_left hn.le 2
  have hmul : 4*K*(N+2)^2 < 4*2^(Nat.log 2 K+1)*(2^(Nat.log 2 (N+2)+1))^2 := by
    calc
      _ ≤ 4*K*(2^(Nat.log 2 (N+2)+1))^2 := Nat.mul_le_mul_left _ hsq
      _ < _ := Nat.mul_lt_mul_of_pos_right (Nat.mul_lt_mul_of_pos_left hk (by norm_num)) (by positivity)
  have he : 4*2^(Nat.log 2 K+1)*(2^(Nat.log 2 (N+2)+1))^2 =
      2^(Nat.log 2 K+2*Nat.log 2 (N+2)+5) := by
    have hexp : Nat.log 2 K+2*Nat.log 2 (N+2)+5 = 2+(Nat.log 2 K+1)+(Nat.log 2 (N+2)+1)*2 := by omega
    rw [hexp]
    simp only [pow_add, pow_mul]
    norm_num
  have hbound : D < 2^(Nat.log 2 K+2*Nat.log 2 (N+2)+5) :=
    hbasic.trans_lt (hmul.trans_eq he)
  by_cases hzero : D = 0
  · simp only [hzero, Nat.log_zero_right]
    nlinarith
  · have hl := Nat.log_lt_of_lt_pow hzero hbound
    nlinarith

/-- The initial scalar potential needs only logarithmically many halvings. -/
theorem common_phase_potential_log_bound (M h N : ℕ) (hh : h ≤ 2*N) (hM : M ≤ h*N+1) :
    Nat.log 2 M+1 ≤ 5*(Nat.log 2 (N+2)+1) := by
  simpa using common_phase_log_bound M 1 M h N hh hM (by omega)

end
end Optss
