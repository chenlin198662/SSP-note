import Optss.CommonLatticeBoxing
import Optss.DenseBoxFilling
import Mathlib.Data.Finset.Preimage

/-!
# Dense block filling in one complete integer lattice

Pulling back through an injective synthesis map preserves exact cardinalities
and turns generation of its full range into generation of the standard integer
lattice. Lemma 2.D then applies to an actual finite family of different blocks.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1000000

/-- Exact pullback of a finite set contained in the full synthesis range. -/
theorem whole_lattice_preimage_image {G H : Type*} [AddCommGroup G] [AddCommGroup H]
    [DecidableEq G] [DecidableEq H] (σ : G →+ H) (hσ : Function.Injective σ)
    (S : Finset H) (hS : ∀ x ∈ S, x ∈ σ.range) :
    (S.preimage σ hσ.injOn).image σ = S := by
  ext x
  simp only [Finset.mem_image, Finset.mem_preimage]
  constructor
  · rintro ⟨y, hy, rfl⟩
    exact hy
  · intro hx
    obtain ⟨y, rfl⟩ := hS x hx
    exact ⟨y, hx, rfl⟩

theorem whole_lattice_preimage_card {G H : Type*} [AddCommGroup G] [AddCommGroup H]
    [DecidableEq G] [DecidableEq H] (σ : G →+ H) (hσ : Function.Injective σ)
    (S : Finset H) (hS : ∀ x ∈ S, x ∈ σ.range) :
    (S.preimage σ hσ.injOn).card = S.card := by
  have he := congrArg Finset.card (whole_lattice_preimage_image σ hσ S hS)
  rw [Finset.card_image_of_injective _ hσ] at he
  exact he

/-- Whole-range generation is the precise condition needed by dense-box
filling after changing to the common lattice basis. -/
theorem whole_lattice_preimage_generates {G H : Type*} [AddCommGroup G] [AddCommGroup H]
    [DecidableEq G] [DecidableEq H] (σ : G →+ H) (hσ : Function.Injective σ)
    (S : Finset H) (hgen : AddSubgroup.closure (S : Set H) = σ.range) :
    AddSubgroup.closure ((S.preimage σ hσ.injOn) : Set G) = ⊤ := by
  have hS : ∀ x ∈ S, x ∈ σ.range := fun x hx => hgen ▸ AddSubgroup.subset_closure hx
  have hm : (AddSubgroup.closure ((S.preimage σ hσ.injOn) : Set G)).map σ = σ.range := by
    rw [AddMonoidHom.map_closure, ← Finset.coe_image, whole_lattice_preimage_image σ hσ S hS, hgen]
  apply top_unique
  intro x _
  have hx : σ x ∈ (AddSubgroup.closure ((S.preimage σ hσ.injOn) : Set G)).map σ := by
    rw [hm]
    exact ⟨x, rfl⟩
  obtain ⟨y, hy, he⟩ := hx
  exact hσ he ▸ hy

/-- The symmetric natural-width box has exactly the interval-box semantics
used by the dense filling theorem. -/
theorem integerBudgetBox_eq_symmetric_fillingBox {d : ℕ} (W : Fin d → ℕ) :
    integerBudgetBox W = fillingIntegerBox (fun j => -(W j : ℤ)) (fun j => (W j : ℤ)) := by
  ext x
  rw [mem_integerBudgetBox, mem_fillingIntegerBox]
  exact forall_congr' (fun j => abs_le)

/-- A genuinely reduced finite family in one common lattice fills a translate
of a real dilation in that lattice. All pullback cardinalities and generation
conditions are proved, rather than supplied as extra assumptions. -/
theorem common_lattice_dense_family_filling {d : ℕ} {G : Type*} [AddCommGroup G] [DecidableEq G]
    (hd : 0 < d) (σ : IntVec d →+ G) (hσ : Function.Injective σ)
    (A : ℕ → Finset G) (N : ℕ) (W : Fin d → ℕ) (c : ℝ) (hc : 0 < c) (hc1 : c ≤ 1)
    (hN : denseBoxSummandThreshold d c ≤ N)
    (hW : ∀ j, denseBoxWidthThreshold c ≤ 2*W j+1)
    (hbox : ∀ i < N, ∀ z : IntVec d, σ z ∈ A i → z ∈ integerBudgetBox W)
    (hdense : ∀ i < N, c*(integerBudgetBox W).card ≤ (A i).card)
    (hzero : ∀ i < N, 0 ∈ A i)
    (hgen : ∀ i < N, AddSubgroup.closure (A i : Set G) = σ.range) :
    ∃ t ∈ σ.range, ∀ z : IntVec d,
      (∀ j, |(z j : ℝ)| ≤ denseBoxDilation d c*N*W j) →
      t+σ z ∈ ∑ i ∈ Finset.range N, A i := by
  let C : ℕ → Finset (IntVec d) := fun i => (A i).preimage σ hσ.injOn
  have hrange : ∀ i < N, ∀ x ∈ A i, x ∈ σ.range :=
    fun i hi x hx => (hgen i hi) ▸ AddSubgroup.subset_closure hx
  have hcard : ∀ i < N, (C i).card = (A i).card :=
    fun i hi => whole_lattice_preimage_card σ hσ (A i) (hrange i hi)
  have himage : ∀ i < N, (C i).image σ = A i :=
    fun i hi => whole_lattice_preimage_image σ hσ (A i) (hrange i hi)
  obtain ⟨t, ht⟩ := dense_box_filling_explicit hd c hc hc1 N C
    (fun j => -(W j : ℤ)) (fun j => (W j : ℤ)) hN
    (fun j => by
      have hj : (denseBoxWidthThreshold c : ℤ) ≤ 2*(W j : ℤ)+1 := by exact_mod_cast hW j
      dsimp only
      omega)
    (fun i hi z hz => integerBudgetBox_eq_symmetric_fillingBox W ▸ hbox i hi z (Finset.mem_preimage.mp hz))
    (fun i hi => by rw [← integerBudgetBox_eq_symmetric_fillingBox, hcard i hi]; exact hdense i hi)
    (fun i hi => Finset.mem_preimage.mpr (by simpa only [map_zero] using hzero i hi))
    (fun i hi => whole_lattice_preimage_generates σ hσ (A i) (hgen i hi))
  have hsum : (∑ i ∈ Finset.range N, C i).image σ = ∑ i ∈ Finset.range N, A i := by
    change (Finset.imageAddMonoidHom σ) (∑ i ∈ Finset.range N, C i) = _
    rw [map_sum]
    apply Finset.sum_congr rfl
    intro i hi
    exact himage i (Finset.mem_range.mp hi)
  refine ⟨σ t, ⟨t, rfl⟩, ?_⟩
  intro z hz
  have hmem := ht z (fun j => by
    have hj := abs_le.mp (hz j)
    push_cast
    constructor <;> nlinarith [hj.1, hj.2])
  have him := Finset.mem_image_of_mem σ hmem
  rw [hsum, map_add] at him
  exact him

end
end Optss
