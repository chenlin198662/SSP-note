import Optss.ExecutableRationalReduction
import Optss.ReducedLatticeHeight

/-!
# Rational input encoding and output height

The executable common-denominator conversion has polynomial encoding length.
The actual normalized rational output has a denominator dividing that common
input denominator, and its numerator is no larger than the computed integer
output entry. These are encoding bounds, not a runtime theorem.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

theorem rationalInputDenominator_le (A : Matrix (Fin r) (Fin d) ℚ) (H : ℕ)
    (hden : ∀ i j, (A i j).den ≤ H) :
    rationalInputDenominator A ≤ H^(r*d) := by
  calc
    _ ≤ ∏ _i : Fin r, H^d := by
      apply Finset.prod_le_prod'
      intro i _
      calc
        _ ≤ ∏ _j : Fin d, H := Finset.prod_le_prod' (fun j _ => hden i j)
        _ = _ := by simp
    _ = _ := by simp [← pow_mul, Nat.mul_comm]

theorem clearRationalInput_natAbs_le (A : Matrix (Fin r) (Fin d) ℚ) (H : ℕ)
    (hnum : ∀ i j, (A i j).num.natAbs ≤ H) (hden : ∀ i j, (A i j).den ≤ H)
    (i : Fin r) (j : Fin d) :
    (clearRationalInput A i j).natAbs ≤ H^(r*d+1) := by
  simp only [clearRationalInput, Int.natAbs_mul, Int.natAbs_natCast]
  calc
    _ ≤ rationalInputDenominator A * H :=
      Nat.mul_le_mul (Nat.div_le_self _ _) (hnum i j)
    _ ≤ H^(r*d)*H := Nat.mul_le_mul_right H (rationalInputDenominator_le A H hden)
    _ = _ := (pow_succ _ _).symm

theorem clearRationalInput_height (A : Matrix (Fin r) (Fin d) ℚ) (H : ℕ)
    (hnum : ∀ i j, (A i j).num.natAbs ≤ H) (hden : ∀ i j, (A i j).den ≤ H)
    (i : Fin r) (j : Fin d) :
    |clearRationalInput A i j| ≤ (H^(r*d+1):ℕ) := by
  rw [← Int.natCast_natAbs]
  exact Int.ofNat_le.mpr (clearRationalInput_natAbs_le A H hnum hden i j)

theorem clearRationalInput_bits (A : Matrix (Fin r) (Fin d) ℚ) (H : ℕ)
    (hnum : ∀ i j, (A i j).num.natAbs ≤ H) (hden : ∀ i j, (A i j).den ≤ H)
    (i : Fin r) (j : Fin d) :
    (clearRationalInput A i j).natAbs.size ≤ (r*d+1)*H.size :=
  nat_size_le_of_le_pow (by omega) (clearRationalInput_natAbs_le A H hnum hden i j)

theorem rationalInputDenominator_bits (A : Matrix (Fin r) (Fin d) ℚ) (H : ℕ)
    (hH : 0 < H) (hden : ∀ i j, (A i j).den ≤ H) :
    (rationalInputDenominator A).size ≤ (r*d+1)*H.size := by
  apply nat_size_le_of_le_pow (by omega)
  exact (rationalInputDenominator_le A H hden).trans
    (pow_le_pow_right₀ hH (by omega))

/-- Reducing an integer fraction cannot increase its numerator magnitude or
its positive denominator. -/
theorem integerFraction_normalized_bounds (z : ℤ) (D : ℕ) (hD : 0 < D) :
    ((z:ℚ)/(D:ℚ)).num.natAbs ≤ z.natAbs ∧ ((z:ℚ)/(D:ℚ)).den ≤ D := by
  obtain ⟨c, hn, hd⟩ := Rat.exists_eq_mul_div_num_and_eq_mul_div_den z
    (by exact_mod_cast hD.ne' : (D:ℤ) ≠ 0)
  simp only [Int.cast_natCast] at hn hd
  have hc : 0 < c := by
    have hdpos : (0:ℤ) < ((z:ℚ)/(D:ℚ)).den := by
      exact_mod_cast ((z:ℚ)/(D:ℚ)).den_pos
    have hDpos : (0:ℤ) < D := by exact_mod_cast hD
    nlinarith
  have hcabs : 1 ≤ c.natAbs := Int.natAbs_pos.mpr (ne_of_gt hc)
  have hnum := congrArg Int.natAbs hn
  simp only [Int.natAbs_mul] at hnum
  constructor
  · rw [hnum]
    exact Nat.le_mul_of_pos_left _ (by omega)
  · have hc1 : 1 ≤ c := hc
    have hdenpos := ((z:ℚ)/(D:ℚ)).den_pos
    exact_mod_cast (show (((z:ℚ)/(D:ℚ)).den:ℤ) ≤ D by nlinarith)

theorem integerFraction_den_dvd (z : ℤ) (D : ℕ) :
    ((z:ℚ)/(D:ℚ)).den ∣ D := by
  have h := Rat.den_dvd z (D:ℤ)
  rw [Rat.divInt_eq_div, Int.cast_natCast] at h
  exact_mod_cast h

theorem executableRationalReduction_den_dvd (A : Matrix (Fin r) (Fin d) ℚ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (i : Fin r) (j : Fin d) :
    ((executableRationalReduction A hA).1 i j).den ∣ rationalInputDenominator A :=
  integerFraction_den_dvd _ _

theorem executableRationalReduction_den_bits (A : Matrix (Fin r) (Fin d) ℚ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (H : ℕ)
    (hH : 0 < H) (hden : ∀ i j, (A i j).den ≤ H) (i : Fin r) (j : Fin d) :
    ((executableRationalReduction A hA).1 i j).den.size ≤ (r*d+1)*H.size := by
  exact (Nat.size_le_size (Nat.le_of_dvd (rationalInputDenominator_pos A)
    (executableRationalReduction_den_dvd A hA i j))).trans
    (rationalInputDenominator_bits A H hH hden)

theorem executableRationalReduction_num_bits (A : Matrix (Fin r) (Fin d) ℚ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (H : ℕ)
    (hnum : ∀ i j, (A i j).num.natAbs ≤ H) (hden : ∀ i j, (A i j).den ≤ H)
    (i : Fin r) (j : Fin d) :
    ((executableRationalReduction A hA).1 i j).num.natAbs.size ≤
      (r*(r+1)+1)*(((r+1)*(d+1)*(H^(r*d+1)+1)^2).size) := by
  let out := executableIntegerReduction (clearRationalInput A) (clearRationalInput_independent A hA)
  have hb := integerFraction_normalized_bounds (out.rows i j) (rationalInputDenominator A)
    (rationalInputDenominator_pos A)
  exact (Nat.size_le_size hb.1).trans
    (out.entry_bits_bound _ _ (clearRationalInput_height A H hnum hden) i j)

/-- The remaining power in the height estimate contributes only linearly to
its binary length. -/
theorem rationalClearedHeight_base_bits (r d H : ℕ) :
    ((r+1)*(d+1)*(H^(r*d+1)+1)^2).size ≤
      (2*(r*d+1)+1)*(((r+1)*(d+1)*(H+1)).size) := by
  let B := (r+1)*(d+1)*(H+1)
  have hF : 1 ≤ (r+1)*(d+1) := by nlinarith
  have hFB : (r+1)*(d+1) ≤ B := by dsimp [B]; nlinarith
  have hHB : H+1 ≤ B := by dsimp [B]; nlinarith
  have hpow : H^(r*d+1)+1 ≤ (H+1)^(r*d+1) := by
    simpa using pow_add_pow_le (Nat.zero_le H) (Nat.zero_le 1)
      (by omega : r*d+1 ≠ 0)
  apply nat_size_le_of_le_pow (by omega)
  calc
    _ ≤ B*(B^(r*d+1))^2 :=
      Nat.mul_le_mul hFB (Nat.pow_le_pow_left
        (hpow.trans (Nat.pow_le_pow_left hHB _)) _)
    _ = B^(2*(r*d+1)+1) := by
      rw [← pow_mul, Nat.mul_comm (r*d+1) 2, pow_succ, mul_comm]

/-- An explicit polynomial-in-dimension encoding bound for the actual reduced
rational numerator; its dependence on the input magnitude is logarithmic. -/
theorem executableRationalReduction_num_bits_polynomial (A : Matrix (Fin r) (Fin d) ℚ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (H : ℕ)
    (hnum : ∀ i j, (A i j).num.natAbs ≤ H) (hden : ∀ i j, (A i j).den ≤ H)
    (i : Fin r) (j : Fin d) :
    ((executableRationalReduction A hA).1 i j).num.natAbs.size ≤
      (r*(r+1)+1)*(2*(r*d+1)+1)*(((r+1)*(d+1)*(H+1)).size) := by
  exact (executableRationalReduction_num_bits A hA H hnum hden i j).trans
    (by simpa only [Nat.mul_assoc] using (Nat.mul_le_mul_left (r*(r+1)+1)
      (rationalClearedHeight_base_bits r d H)))

end Optss
