import Optss.TerminatingLatticeReduction
import Mathlib.Data.Rat.Floor

/-!
# Executable rational Gram-Schmidt arithmetic

The recurrence below uses only rational dot products, rational division and
finite sums. Casting it to Euclidean space agrees with mathlib's Gram-Schmidt
process, including dependent or zero rows. Exact rational rounding therefore
makes the same choices as the previously verified real-valued size reduction.
No arithmetic bit-complexity claim is made here.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

/-- Exact rational dot product. -/
def rationalDot (u v : Fin d → ℚ) : ℚ := ∑ j, u j*v j

/-- Computable Gram-Schmidt recurrence. Division by zero follows the field
convention, matching the zero-vector projection in mathlib. -/
def rationalGramSchmidt (A : Matrix (Fin r) (Fin d) ℚ) (k : Fin r) : Fin d → ℚ :=
  A k - ∑ i : Finset.Iio k,
    (rationalDot (rationalGramSchmidt A i) (A k) /
      rationalDot (rationalGramSchmidt A i) (rationalGramSchmidt A i)) •
      rationalGramSchmidt A i
termination_by k.val
decreasing_by
  change (i : Fin r) < k
  exact Finset.mem_Iio.mp i.2

/-- Exact rational coefficient for a projection onto an orthogonalized row. -/
def rationalGsCoefficient (A : Matrix (Fin r) (Fin d) ℚ) (k j : Fin r) : ℚ :=
  rationalDot (rationalGramSchmidt A j) (A k) /
    rationalDot (rationalGramSchmidt A j) (rationalGramSchmidt A j)

/-- Canonical Euclidean interpretation of a rational vector. -/
noncomputable def rationalEuclideanVector : (Fin d → ℚ) →+ EuclideanSpace ℝ (Fin d) where
  toFun u := (WithLp.equiv 2 _).symm (fun j => (u j:ℝ))
  map_zero' := by ext j; simp
  map_add' u v := by ext j; simp

noncomputable def rationalEuclideanRows (A : Matrix (Fin r) (Fin d) ℚ) :
    Fin r → EuclideanSpace ℝ (Fin d) := fun i => rationalEuclideanVector (A i)

theorem rationalEuclideanVector_smul (q : ℚ) (u : Fin d → ℚ) :
    rationalEuclideanVector (q • u) = (q:ℝ) • rationalEuclideanVector u := by
  ext j
  simp [rationalEuclideanVector, PiLp.smul_apply]

theorem rationalDot_cast (u v : Fin d → ℚ) :
    (rationalDot u v:ℝ) =
      @inner ℝ _ _ (rationalEuclideanVector u) (rationalEuclideanVector v) := by
  simp [rationalDot, rationalEuclideanVector, PiLp.inner_apply, mul_comm]

theorem rationalDot_self_cast (u : Fin d → ℚ) :
    (rationalDot u u:ℝ) = ‖rationalEuclideanVector u‖^2 := by
  rw [rationalDot_cast, real_inner_self_eq_norm_sq]

/-- The executable recurrence agrees exactly with the library's geometric
Gram-Schmidt construction; no independence assumption is needed. -/
theorem rationalGramSchmidt_cast (A : Matrix (Fin r) (Fin d) ℚ) (k : Fin r) :
    rationalEuclideanVector (rationalGramSchmidt A k) =
      gramSchmidt ℝ (rationalEuclideanRows A) k := by
  induction k using WellFoundedLT.induction with
  | ind k ih =>
    rw [rationalGramSchmidt, gramSchmidt, map_sub, map_sum]
    congr 1
    apply Finset.sum_congr rfl
    intro i _
    rw [rationalEuclideanVector_smul, Rat.cast_div, rationalDot_cast, rationalDot_self_cast,
      ih i (Finset.mem_Iio.mp i.2)]
    rw [Submodule.orthogonalProjection_singleton]
    rfl

/-- The rational projection coefficient casts to the exact coefficient used
by the already verified real-valued size-reduction algorithm. -/
theorem rationalGsCoefficient_cast (A : Matrix (Fin r) (Fin d) ℚ) (k j : Fin r) :
    (rationalGsCoefficient A k j:ℝ) = gsCoefficient (rationalEuclideanRows A) k j := by
  simp only [rationalGsCoefficient, Rat.cast_div, rationalDot_cast,
    rationalDot_self_cast, rationalGramSchmidt_cast, gsCoefficient, rationalEuclideanRows,
    real_inner_self_eq_norm_sq]

/-- Rational and real nearest-integer rounding agree, including half ties. -/
theorem rationalGsCoefficient_round (A : Matrix (Fin r) (Fin d) ℚ) (k j : Fin r) :
    round (rationalGsCoefficient A k j) = round (gsCoefficient (rationalEuclideanRows A) k j) := by
  rw [← rationalGsCoefficient_cast, Rat.round_cast]

/-- Computable inclusion of integer matrix entries in the rational field. -/
def rationalIntegerRows (A : Matrix (Fin r) (Fin d) ℤ) : Matrix (Fin r) (Fin d) ℚ :=
  fun i j => (A i j:ℚ)

theorem rationalEuclideanRows_integer (A : Matrix (Fin r) (Fin d) ℤ) :
    rationalEuclideanRows (rationalIntegerRows A) = euclideanIntegerRows A := by
  ext i j
  simp [rationalEuclideanRows, rationalIntegerRows, rationalEuclideanVector, euclideanIntegerRows]

/-- The executable rational computation makes precisely the integer choice
used in the old real-valued integer sweep. -/
theorem rationalIntegerCoefficient_round (A : Matrix (Fin r) (Fin d) ℤ) (k j : Fin r) :
    round (rationalGsCoefficient (rationalIntegerRows A) k j) =
      round (gsCoefficient (euclideanIntegerRows A) k j) := by
  rw [rationalGsCoefficient_round, rationalEuclideanRows_integer]

/-- Executable descending size reduction using rational projections and
rational nearest-integer rounding; the output matrix remains integral. -/
def rationalReduceIntegerRow (A : Matrix (Fin r) (Fin d) ℤ)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) : Matrix (Fin r) (Fin d) ℤ :=
  match n with
  | 0 => A
  | n+1 =>
    let j : Fin r := ⟨n, by omega⟩
    let q : ℤ := round (rationalGsCoefficient (rationalIntegerRows A) k j)
    rationalReduceIntegerRow (Function.update A k (A k - q • A j)) k n (by omega)
termination_by n

/-- Every computed row sweep is exactly the previously verified real sweep. -/
theorem rationalReduceIntegerRow_eq (A : Matrix (Fin r) (Fin d) ℤ)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) :
    rationalReduceIntegerRow A k n h = roundReduceIntegerRow A k n h := by
  induction n generalizing A with
  | zero => rw [rationalReduceIntegerRow, roundReduceIntegerRow]
  | succ n ih =>
    rw [rationalReduceIntegerRow, roundReduceIntegerRow, ih, rationalIntegerCoefficient_round]
    rfl

/-- Executable complete size reduction, with exact rational arithmetic. -/
def rationalReduceIntegerAll (A : Matrix (Fin r) (Fin d) ℤ)
    (n : ℕ) (h : n ≤ r) : Matrix (Fin r) (Fin d) ℤ :=
  match n with
  | 0 => A
  | n+1 =>
    let B := rationalReduceIntegerAll A n (by omega)
    let k : Fin r := ⟨n, by omega⟩
    rationalReduceIntegerRow B k n le_rfl
termination_by n

/-- The executable full sweep equals the verified sweep as an actual integer
matrix, so all its lattice, independence and potential guarantees transfer. -/
theorem rationalReduceIntegerAll_eq (A : Matrix (Fin r) (Fin d) ℤ)
    (n : ℕ) (h : n ≤ r) :
    rationalReduceIntegerAll A n h = roundReduceIntegerAll A n h := by
  induction n with
  | zero => rw [rationalReduceIntegerAll, roundReduceIntegerAll]
  | succ n ih =>
    rw [rationalReduceIntegerAll, roundReduceIntegerAll, rationalReduceIntegerRow_eq, ih]

/-- Full certified correctness of the executable rational size-reduction sweep. -/
theorem rationalReduceIntegerAll_spec (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ))) :
    LinearIndependent ℝ (fun i => fun j => (rationalReduceIntegerAll A r le_rfl i j:ℝ)) ∧
    Submodule.span ℤ (Set.range (rationalReduceIntegerAll A r le_rfl)) = Submodule.span ℤ (Set.range A) ∧
    gramPotential (rationalReduceIntegerAll A r le_rfl) = gramPotential A ∧
    ∀ k j : Fin r, j < k →
      |gsCoefficient (euclideanIntegerRows (rationalReduceIntegerAll A r le_rfl)) k j| ≤ 1/2 := by
  rw [rationalReduceIntegerAll_eq]
  exact fullIntegerSweep_spec A hA

end Optss
