import Optss.ComputedQuotientBox
import Optss.IntegerBasisCoordinates

/-!
# Actual smaller GAP generators after computed quotient boxing

The new generators are obtained by evaluating the descended integer encoding
on the integer columns decoded from the returned box. The containment and
coefficient-volume bounds concern those computed generators and widths.
-/
namespace Optss
open scoped BigOperators Pointwise
variable {d e : ℕ}

def latticeBoxIntegerSynthesis (box : BooleanLatticeBoxResult e) : (Fin e→ℤ) →ₗ[ℤ] (Fin e→ℤ) where
  toFun x i := ∑ j,x j*latticeBoxIntegerColumn box j i
  map_add' x y := by ext i; simp [add_mul,Finset.sum_add_distrib]
  map_smul' n x := by ext i; simp [Finset.mul_sum,mul_assoc]

theorem latticeBoxIntegerSynthesis_eq_basis (box : BooleanLatticeBoxResult e)
    (b : Basis (Fin e) ℝ (Fin e→ℝ))
    (hcols : ∀ i j,(storedRationalMatrix box.columns i j:ℝ)=b j i)
    (hΛ : basisIntegerLattice b=Set.range (@realVector e)) (x : Fin e→ℤ) :
    latticeBoxIntegerSynthesis box x=integerBasisEquiv b hΛ x := by
  apply realVector_is_injective
  rw [integerBasisEquiv_cast,Basis.equivFun_symm_apply]
  ext i
  have hc (j : Fin e) : (latticeBoxIntegerColumn box j i:ℝ)=b j i :=
    congrFun (latticeBoxIntegerColumn_cast box b hcols hΛ j) i
  simp [realVector,latticeBoxIntegerSynthesis,Finset.sum_apply,Pi.smul_apply,smul_eq_mul,hc]

def computedReboxedGenerators (a : Fin (d+1)→ℤ) (z : Fin (d+1)→ℤ)
    (box : BooleanLatticeBoxResult d) : Fin d→ℤ :=
  fun j => executableDescendedHom z (progressionLinearEncoding a).toAddMonoidHom
    (latticeBoxIntegerColumn box j)

theorem computedReboxedGenerators_encoding (a : Fin (d+1)→ℤ) (z : Fin (d+1)→ℤ)
    (box : BooleanLatticeBoxResult d) (x : Fin d→ℤ) :
    progressionLinearEncoding (computedReboxedGenerators a z box) x=
      executableDescendedHom z (progressionLinearEncoding a).toAddMonoidHom
        (latticeBoxIntegerSynthesis box x) := by
  have hx : latticeBoxIntegerSynthesis box x=∑ j,x j •latticeBoxIntegerColumn box j := by
    ext i
    simp [latticeBoxIntegerSynthesis,Finset.sum_apply,Pi.smul_apply,smul_eq_mul]
  rw [hx,map_sum]
  change (∑ j,computedReboxedGenerators a z box j*x j)=_
  apply Finset.sum_congr rfl
  intro j _
  rw [map_zsmul]
  change computedReboxedGenerators a z box j*x j=x j*computedReboxedGenerators a z box j
  ring

theorem computedReboxedGenerators_contains (a : Fin (d+1)→ℤ) (z : Fin (d+1)→ℤ)
    (hz : z≠0) (ha : progressionLinearEncoding a z=0)
    (β : Fin (d+1)→ℕ) (box : BooleanLatticeBoxResult d)
    (b : Basis (Fin d) ℝ (Fin d→ℝ))
    (hcols : ∀ i j,(storedRationalMatrix box.columns i j:ℝ)=b j i)
    (hΛ : basisIntegerLattice b=Set.range (@realVector d))
    (hbox : integerLinearImageBox (executablePrimitiveQuotient z) β⊆
      basisCoefficientBox b (decodedLatticeBoxWidths box)) :
    integerProgressionValues (progressionLinearEncoding a).toAddMonoidHom β ⊆
      integerProgressionValues (progressionLinearEncoding (computedReboxedGenerators a z box)).toAddMonoidHom
        (decodedLatticeBoxWidths box) := by
  intro y hy
  obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp hy
  have hq : realVector (executablePrimitiveQuotient z x)∈
      integerLinearImageBox (executablePrimitiveQuotient z) β := by
    refine ⟨realVector x,?_,integerMapRealExtension_cast _ x⟩
    rw [mem_realCoefficientBox]
    intro i
    change |(x i:ℝ)|≤(β i:ℝ)
    have hi : |x i|≤(β i:ℤ) := (mem_integerBudgetBox β x).mp hx i
    exact_mod_cast hi
  refine Finset.mem_image.mpr ⟨(integerBasisEquiv b hΛ).symm (executablePrimitiveQuotient z x),
    (integerBasisEquiv_box b hΛ _ _).mpr (hbox hq),?_⟩
  change progressionLinearEncoding (computedReboxedGenerators a z box) _=progressionLinearEncoding a x
  rw [computedReboxedGenerators_encoding,latticeBoxIntegerSynthesis_eq_basis box b hcols hΛ,
    LinearEquiv.apply_symm_apply]
  exact executableDescendedHom_quotient z hz (progressionLinearEncoding a).toAddMonoidHom ha x

/-- The actual boxing call succeeds and returns a smaller progression with the
paper's dimension-only one-step coefficient-volume factor. -/
theorem computedReboxing_step (hd : 0<d) (a : Fin (d+1)→ℤ)
    (β : Fin (d+1)→ℕ) (hβ : ∀ j,0<β j) (t : ℕ) (ht : 0<t)
    (z : Fin (d+1)→ℤ) (hz : computedShortKernelVector a (fun j => 2*t*β j)=some z) :
    ∃ box,computedQuotientBox (executablePrimitiveQuotient z) β=some box ∧
      (∀ j,0<decodedLatticeBoxWidths box j) ∧
      integerProgressionValues (progressionLinearEncoding a).toAddMonoidHom β ⊆
        integerProgressionValues (progressionLinearEncoding (computedReboxedGenerators a z box)).toAddMonoidHom
          (decodedLatticeBoxWidths box) ∧
      (integerBudgetBox (decodedLatticeBoxWidths box)).card≤
        (latticeBoxingResidueModulus d (sharpLatticeDefectBound d))^d*(1+t)^(d+1)*(integerBudgetBox β).card := by
  have hs := computedShortKernelVector_sound a (fun j => 2*t*β j)
    (by intro j; exact Nat.mul_pos (Nat.mul_pos (by decide) ht) (hβ j)) z hz
  obtain ⟨box,hbox,b,hcols,hΛ,hpos,hinner,_,hcount⟩ := computedQuotientBox_spec hd
    (executablePrimitiveQuotient z) (executablePrimitiveQuotient_surjective z) β hβ
  refine ⟨box,hbox,hpos,computedReboxedGenerators_contains a z hs.2.1 hs.2.2 β box b hcols hΛ hinner,?_⟩
  have hc := hcount 1
  simp only [one_smul] at hc
  rw [←basisLatticePoints_standard_card b hΛ,basisLatticePoints_box_card] at hc
  have hquot := executableQuotient_box_card z hs.2.1 β t hs.1
  rw [integerBudgetBox_card]
  calc
    _≤(latticeBoxingResidueModulus d (sharpLatticeDefectBound d))^d*
        (integerPoints (integerLinearImageBox (executablePrimitiveQuotient z) β)
          (integerLinearImageBox_compact _ β).isBounded).card := hc
    _≤(latticeBoxingResidueModulus d (sharpLatticeDefectBound d))^d*
        ((1+t)^(d+1)*(integerBudgetBox β).card) := Nat.mul_le_mul_left _ hquot
    _=_ := by ring
end Optss
