import Optss.DenseBoxFibers

/-!
# Selecting a genuine common-period subfamily

Each period is obtained from an actual integer fiber. Finite pigeonhole
counting supplies a large set of distinct labels with one common period;
the already proved dense progression theorem then applies to those
actual summands.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

/-- Positive integer periods with `c*v ≤ 2` have a common-value fiber
containing at least a `c/2` fraction of the original labels. -/
theorem bounded_integer_period_cluster {ι : Type*} [DecidableEq ι]
    (S : Finset ι) (v : ι → ℤ) (c : ℝ) (hS : S.Nonempty) (hc : 0 < c)
    (hv : ∀ i ∈ S, 0 < v i) (hbound : ∀ i ∈ S, c * v i ≤ 2) :
    ∃ w : ℤ, ∃ T : Finset ι, T ⊆ S ∧ T.Nonempty ∧
      (∀ i ∈ T, v i = w) ∧ 0 < w ∧ c * w ≤ 2 ∧ c * S.card ≤ 2 * T.card := by
  let K := S.image v
  have hK : K.Nonempty := hS.image v
  let m := K.max' hK
  have hm : m ∈ K := K.max'_mem hK
  obtain ⟨i₀, hi₀, hm₀⟩ := Finset.mem_image.mp hm
  have hmpos : 0 < m := by rw [← hm₀]; exact hv i₀ hi₀
  have hcm : c * m ≤ 2 := by rw [← hm₀]; exact hbound i₀ hi₀
  have hKsub : K ⊆ Finset.Icc 1 m := by
    intro x hx
    obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hx
    exact Finset.mem_Icc.mpr ⟨by have := hv i hi; omega, K.le_max' _ (Finset.mem_image_of_mem _ hi)⟩
  have hKcard : (K.card : ℤ) ≤ m := by
    have hh := Finset.card_le_card hKsub
    rw [Int.card_Icc] at hh
    omega
  have hKcardR : (K.card : ℝ) ≤ m := by exact_mod_cast hKcard
  have hcK : c * K.card ≤ 2 := (mul_le_mul_of_nonneg_left hKcardR hc.le).trans hcm
  have hKpos : (0 : ℝ) < K.card := by exact_mod_cast Finset.card_pos.mpr hK
  obtain ⟨w, hwK, hw⟩ := Finset.exists_le_card_fiber_of_nsmul_le_card_of_maps_to
    (s := S) (t := K) (f := v) (b := (S.card : ℝ) / K.card)
    (fun i hi => Finset.mem_image_of_mem v hi) hK
    (by rw [nsmul_eq_mul]; field_simp)
  let T := S.filter (fun i => v i = w)
  have hmul : (S.card : ℝ) ≤ K.card * T.card := by
    change (S.card : ℝ) / K.card ≤ T.card at hw
    exact (div_le_iff₀ hKpos).mp hw |>.trans_eq (mul_comm _ _)
  have hSpos : (0 : ℝ) < S.card := by exact_mod_cast Finset.card_pos.mpr hS
  have hT : T.Nonempty := by
    apply Finset.card_pos.mp
    by_contra hh
    have hz : T.card = 0 := Nat.eq_zero_of_not_pos hh
    rw [hz, Nat.cast_zero, mul_zero] at hmul
    linarith
  obtain ⟨i, hi, hvw⟩ := Finset.mem_image.mp hwK
  refine ⟨w, T, Finset.filter_subset _ _, hT,
    (fun j hj => (Finset.mem_filter.mp hj).2), ?_, ?_, ?_⟩
  · rw [← hvw]; exact hv i hi
  · rw [← hvw]; exact hbound i hi
  · have h₁ := mul_le_mul_of_nonneg_left hmul hc.le
    have h₂ := mul_le_mul_of_nonneg_right hcK (show (0 : ℝ) ≤ T.card by positivity)
    nlinarith

/-- A genuinely selected subfamily of arbitrary dense integer sets has a
long common-period progression. No aperiodicity is required of the input. -/
theorem dense_integer_subfamily_progression {ι : Type*} [DecidableEq ι]
    (S : Finset ι) (A : ι → Finset ℤ) (N : ℕ) (c : ℝ)
    (hc : 0 < c) (hc1 : c ≤ 1) (hN : 4 ≤ c * N)
    (hcount : 20 ≤ c ^ 2 * S.card)
    (hcard : ∀ i ∈ S, c * N ≤ (A i).card)
    (hbox : ∀ i ∈ S, ∃ u : ℤ, A i ⊆ Finset.Icc u (u + N)) :
    ∃ (T : Finset ι) (v t a b : ℤ), T ⊆ S ∧ T.Nonempty ∧
      0 < v ∧ c * v ≤ 2 ∧ c * S.card ≤ 2 * T.card ∧
      (Finset.Icc a b).image (fun x => t + v * x) ⊆ ∑ i ∈ T, A i ∧
      c ^ 2 * S.card * N / 4 ≤ (b - a : ℤ) := by
  have hS : S.Nonempty := by
    apply Finset.card_pos.mp
    by_contra hh
    have hz : S.card = 0 := by omega
    rw [hz, Nat.cast_zero, mul_zero] at hcount
    norm_num at hcount
  have hp : ∀ i ∈ S, ∃ v : ℤ, 0 < v ∧ c * v ≤ 2 ∧ HasFullIntegerPeriod (A i) v := by
    intro i hi
    obtain ⟨u, hu⟩ := hbox i hi
    exact dense_integer_full_period (A i) u N c hc hN (hcard i hi) hu
  choose v hv using fun i : S => hp i.1 i.2
  let p : ι → ℤ := fun i => if hi : i ∈ S then v ⟨i, hi⟩ else 1
  have hper : ∀ i ∈ S, 0 < p i ∧ c * p i ≤ 2 ∧ HasFullIntegerPeriod (A i) (p i) := by
    intro i hi
    simpa [p, hi] using hv ⟨i, hi⟩
  obtain ⟨w, T, hTS, hT, he, hw, hcw, hsize⟩ := bounded_integer_period_cluster S p c hS hc
    (fun i hi => (hper i hi).1) (fun i hi => (hper i hi).2.1)
  have hcountT : 10 ≤ c * T.card := by
    have hh := mul_le_mul_of_nonneg_left hsize hc.le
    nlinarith
  obtain ⟨t, a, b, hI, hlong⟩ := dense_integer_progression (T.toList.map A) N w c hc hc1 hw hN
    (by simpa using hcountT)
    (by intro B hB; obtain ⟨i, hi, rfl⟩ := List.mem_map.mp hB; exact hcard i (hTS (by simpa using hi)))
    (by intro B hB; obtain ⟨i, hi, rfl⟩ := List.mem_map.mp hB; exact hbox i (hTS (by simpa using hi)))
    (by
      intro B hB
      obtain ⟨i, hi, rfl⟩ := List.mem_map.mp hB
      have hiT : i ∈ T := by simpa using hi
      rw [← he i hiT]
      exact (hper i (hTS hiT)).2.2)
  refine ⟨T, w, t, a, b, hTS, hT, hw, hcw, hsize, ?_, ?_⟩
  · simpa only [Finset.sum_map_toList] using hI
  · simp only [List.length_map, Finset.length_toList] at hlong
    have hh := mul_le_mul_of_nonneg_left hsize (show 0 ≤ c * N by positivity)
    nlinarith

/-- Adding arbitrary actual points from all unselected summands preserves
the progression up to translation. Thus the conclusion holds in the sum
of the full original labelled family. -/
theorem dense_integer_family_progression {ι : Type*} [DecidableEq ι]
    (S : Finset ι) (A : ι → Finset ℤ) (N : ℕ) (c : ℝ)
    (hc : 0 < c) (hc1 : c ≤ 1) (hN : 4 ≤ c * N)
    (hcount : 20 ≤ c ^ 2 * S.card)
    (hcard : ∀ i ∈ S, c * N ≤ (A i).card)
    (hbox : ∀ i ∈ S, ∃ u : ℤ, A i ⊆ Finset.Icc u (u + N)) :
    ∃ v t a b : ℤ, 0 < v ∧ c * v ≤ 2 ∧
      (Finset.Icc a b).image (fun x => t + v * x) ⊆ ∑ i ∈ S, A i ∧
      c ^ 2 * S.card * N / 4 ≤ (b - a : ℤ) := by
  obtain ⟨T, v, t, a, b, hTS, hT, hv, hcv, hsize, hI, hlong⟩ :=
    dense_integer_subfamily_progression S A N c hc hc1 hN hcount hcard hbox
  have hnonempty : (∑ i ∈ S \ T, A i).Nonempty := by
    rw [← Finset.sum_map_toList]
    apply nonempty_list_sum
    intro B hB
    obtain ⟨i, hi, rfl⟩ := List.mem_map.mp hB
    have hiS : i ∈ S := (Finset.mem_sdiff.mp (by simpa using hi)).1
    apply Finset.card_pos.mp
    have hh := hcard i hiS
    have hh' : (0 : ℝ) < (A i).card := by linarith
    exact_mod_cast hh'
  obtain ⟨z, hz⟩ := hnonempty
  refine ⟨v, z + t, a, b, hv, hcv, ?_, hlong⟩
  intro x hx
  obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
  rw [← Finset.sum_sdiff hTS]
  exact Finset.mem_add.mpr ⟨z, hz, t + v * y,
    hI (Finset.mem_image.mpr ⟨y, hy, rfl⟩), by ring⟩

end
end Optss
