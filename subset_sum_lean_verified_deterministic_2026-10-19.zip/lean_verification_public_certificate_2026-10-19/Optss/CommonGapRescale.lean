import Optss.CommonGapUnrestrictedScale

/-! # Restricting a common coordinate output to the requested scale -/
namespace Optss
noncomputable section
open scoped Classical Pointwise

/-- A coordinate model remains valid with fewer permitted deletions and a
smaller actual filled dilation. -/
def CommonReserveCoordinateModel.restrict {ι : Type} [DecidableEq ι] {d : ℕ}
    {scalar : ι → ℤ} {available reserve remainder : Finset ι} {h extra : ℕ} {c : ℝ}
    (model : CommonReserveCoordinateModel d scalar available reserve remainder h extra c)
    (h' extra' : ℕ) (c' : ℝ) (hextra : extra' ≤ extra) (hscale : c'*h' ≤ c*h) :
    CommonReserveCoordinateModel d scalar available reserve remainder h' extra' c' :=
  { model with
    rank_protected := fun D hD => model.rank_protected D (hD.trans hextra)
    proper := fun x y hx hy he => model.proper x y
      (fun j => (hx j).trans (mul_le_mul_of_nonneg_right hscale (Nat.cast_nonneg _)))
      (fun j => (hy j).trans (mul_le_mul_of_nonneg_right hscale (Nat.cast_nonneg _))) he
    filled := by
      obtain ⟨t, ht⟩ := model.filled
      exact ⟨t, fun z hz => ht z (fun j => (hz j).trans
        (mul_le_mul_of_nonneg_right hscale (Nat.cast_nonneg _)))⟩ }

def CommonGapDecomposition.restrict {ι : Type} [DecidableEq ι] {scalar : ι → ℤ}
    {initial : Finset ι} {h extra R Ebound Rbound : ℕ} {c : ℝ}
    (out : CommonGapDecomposition scalar initial h extra R Ebound Rbound c)
    (h' extra' : ℕ) (c' : ℝ) (hextra : extra' ≤ extra) (hscale : c'*h' ≤ c*h) :
    CommonGapDecomposition scalar initial h' extra' R Ebound Rbound c' :=
  { out with model := out.model.restrict h' extra' c' hextra hscale }

end
end Optss
