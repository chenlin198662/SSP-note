import Optss.EncodedCachedReduction
import Optss.BitMatrixFuel

/-!
# Rational lattice reduction entirely on encoded values

The actual answer path clears rational entries through Boolean arithmetic,
constructs polynomial-size list fuel from the stored integer input, executes
the encoded reduction, and unscales by Boolean fraction normalization. Integer
and rational decoders below occur only in correctness specifications.
-/

namespace Optss
variable {r d : ℕ}

/-- The encoded integer algorithm with its actual input-size fuel initializer. -/
def encodedIntegerReduction (D : BitIntegerMatrixData r d) : EncodedLatticeResult r d :=
  encodedReductionFuel (bitMatrixReductionFuel D) D

theorem encodedIntegerReduction_value (D : BitIntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (bitIntegerMatrixValue D i j:ℝ))) :
    (bitIntegerMatrixValue (encodedIntegerReduction D).rows, (encodedIntegerReduction D).swaps) =
      executableReductionFuel (gramPotential (bitIntegerMatrixValue D)) (bitIntegerMatrixValue D) := by
  rw [encodedIntegerReduction, encodedReductionFuel_value, cachedReductionFuel_eq _ _ hD,
    executableReductionFuel_bitMatrixFuel_eq D hD]

theorem encodedIntegerReduction_spec (D : BitIntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (bitIntegerMatrixValue D i j:ℝ))) :
    IntegerReductionSpecification (bitIntegerMatrixValue D)
      (bitIntegerMatrixValue (encodedIntegerReduction D).rows) (encodedIntegerReduction D).swaps := by
  have he := encodedIntegerReduction_value D hD
  have hm := congrArg Prod.fst he
  have hs := congrArg Prod.snd he
  dsimp only [Prod.fst, Prod.snd] at hm hs
  rw [hm,hs]
  exact executableReductionFuel_spec _ _ hD le_rfl

/-- Input and output are genuine arrays of encoded fractions. The input
adapter `bitRationalMatrixRepresentation` is optional and outside this routine. -/
def encodedRationalReduction (A : BitRationalMatrixData r d) : BitRationalMatrixData r d × ℕ :=
  let cleared := bitListClearRationalInput A
  let out := encodedIntegerReduction cleared.2
  (Vector.ofFn fun i => Vector.ofFn fun j =>
      bitListUnscaleInteger cleared.1 ((out.rows.get i).get j), out.swaps)

private theorem outputBits_get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

/-- Exact correspondence to the certified rational reduction, including the
chosen output basis and actual swap count, using only encoded answers. -/
theorem encodedRationalReduction_value (A : Matrix (Fin r) (Fin d) ℚ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) :
    (encodedFractionRows (encodedRationalReduction (bitRationalMatrixRepresentation A)).1,
      (encodedRationalReduction (bitRationalMatrixRepresentation A)).2) =
      executableRationalReduction A hA := by
  let D := (bitListClearRationalInput (bitRationalMatrixRepresentation A)).2
  have hD : bitIntegerMatrixValue D = clearRationalInput A := bitListClearRationalInput_value A
  have hDI : LinearIndependent ℝ (fun i j => (bitIntegerMatrixValue D i j:ℝ)) := by
    rw [hD]
    exact clearRationalInput_independent A hA
  have he := encodedIntegerReduction_value D hDI
  rw [hD] at he
  have hm := congrArg Prod.fst he
  have hs := congrArg Prod.snd he
  dsimp only [Prod.fst, Prod.snd] at hm hs
  have hp : 0 < binaryDigitsValue (bitRationalInputDenominator (bitRationalMatrixRepresentation A)) := by
    rw [bitRationalInputDenominator_value]
    exact rationalInputDenominator_pos A
  apply Prod.ext
  · funext i j
    simp only [encodedRationalReduction, encodedFractionRows, outputBits_get_ofFn]
    change bitListFractionValue (bitListUnscaleInteger
      (bitRationalInputDenominator (bitRationalMatrixRepresentation A))
      (((encodedIntegerReduction D).rows.get i).get j)) = _
    rw [bitListUnscaleInteger_value _ _ hp]
    change (bitIntegerMatrixValue (encodedIntegerReduction D).rows i j:ℚ)/
      (binaryDigitsValue (bitRationalInputDenominator (bitRationalMatrixRepresentation A)):ℚ) = _
    rw [hm, bitRationalInputDenominator_value]
    rfl
  · exact hs

/-- Full mathematical rational-basis guarantee for the actual Boolean-list
implementation. Its cost composition is established separately. -/
theorem encodedRationalReduction_spec (A : Matrix (Fin r) (Fin r) ℚ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) :
    Submodule.span ℤ (Set.range (encodedFractionRows
      (encodedRationalReduction (bitRationalMatrixRepresentation A)).1)) =
      Submodule.span ℤ (Set.range A) ∧
    ∃ b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)),
      (∀ i, b i = rationalEuclideanRows (encodedFractionRows
        (encodedRationalReduction (bitRationalMatrixRepresentation A)).1) i) ∧
      euclideanOrthogonalityDefect b ≤ sharpLatticeDefectBound r := by
  have he := congrArg Prod.fst (encodedRationalReduction_value A hA)
  dsimp only [Prod.fst] at he
  rw [he]
  exact executableRationalReduction_spec A hA

theorem bitListFractionValue_num (q : BitListFraction) (hq : q.WellFormed) :
    (bitListFractionValue q).num = signedBitsValue q.negative q.numerator := by
  rw [← BitListFraction.toRat_value q hq]
  rfl

theorem bitListFractionValue_den (q : BitListFraction) (hq : q.WellFormed) :
    (bitListFractionValue q).den = binaryDigitsValue q.denominator := by
  rw [← BitListFraction.toRat_value q hq]
  rfl

theorem bitRationalInputDenominator_formula (A : BitRationalMatrixData r d) :
    binaryDigitsValue (bitRationalInputDenominator A) =
      ∏ i, ∏ j, binaryDigitsValue ((A.get i).get j).denominator := by
  simp [bitRationalInputDenominator, bitListProduct_value, bitRationalMatrixEntries,
    List.map_flatten, List.map_map, Function.comp_def, List.map_ofFn,
    List.prod_flatten, List.prod_ofFn]

theorem bitRationalInputDenominator_positive (A : BitRationalMatrixData r d)
    (hp : EncodedPositiveDenominators A) : 0 < binaryDigitsValue (bitRationalInputDenominator A) := by
  rw [bitRationalInputDenominator_formula]
  exact Finset.prod_pos (fun i _ => Finset.prod_pos (fun j _ => hp i j))

theorem bitRationalInputDenominator_semantics (A : BitRationalMatrixData r d)
    (hA : ∀ i j, ((A.get i).get j).WellFormed) :
    binaryDigitsValue (bitRationalInputDenominator A) = rationalInputDenominator (encodedFractionRows A) := by
  rw [bitRationalInputDenominator_formula]
  unfold rationalInputDenominator
  apply Finset.prod_congr rfl
  intro i _
  apply Finset.prod_congr rfl
  intro j _
  exact (bitListFractionValue_den _ (hA i j)).symm

theorem bitListClearRationalInput_semantics (A : BitRationalMatrixData r d)
    (hA : ∀ i j, ((A.get i).get j).WellFormed) :
    bitIntegerMatrixValue (bitListClearRationalInput A).2 = clearRationalInput (encodedFractionRows A) := by
  funext i j
  simp only [bitIntegerMatrixValue, bitListClearRationalInput, outputBits_get_ofFn]
  rw [bitListClearFraction_value _ _ (hA i j).2.2.1,
    bitRationalInputDenominator_semantics A hA]
  simp only [clearRationalInput, encodedFractionRows,
    bitListFractionValue_den _ (hA i j), bitListFractionValue_num _ (hA i j)]

/-- Every output cell is a reduced binary fraction whenever all input
stored denominators are positive; no input normalization is needed for this
output invariant. -/
theorem encodedRationalReduction_wellFormed (A : BitRationalMatrixData r d)
    (hp : EncodedPositiveDenominators A) (i : Fin r) (j : Fin d) :
    ((((encodedRationalReduction A).1).get i).get j).WellFormed := by
  simp only [encodedRationalReduction, outputBits_get_ofFn]
  apply bitListNormalizeFraction_wellFormed
  exact bitRationalInputDenominator_positive A hp

/-- Correctness for native well-formed encoded input, including either sign
of zero. No rational encoder is a premise of this theorem. -/
theorem encodedRationalReduction_semantics (A : BitRationalMatrixData r d)
    (hWF : ∀ i j, ((A.get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows A i j:ℝ))) :
    (encodedFractionRows (encodedRationalReduction A).1, (encodedRationalReduction A).2) =
      executableRationalReduction (encodedFractionRows A) hA := by
  let D := (bitListClearRationalInput A).2
  have hD : bitIntegerMatrixValue D = clearRationalInput (encodedFractionRows A) :=
    bitListClearRationalInput_semantics A hWF
  have hDI : LinearIndependent ℝ (fun i j => (bitIntegerMatrixValue D i j:ℝ)) := by
    rw [hD]
    exact clearRationalInput_independent _ hA
  have he := encodedIntegerReduction_value D hDI
  rw [hD] at he
  have hm := congrArg Prod.fst he
  have hs := congrArg Prod.snd he
  dsimp only [Prod.fst, Prod.snd] at hm hs
  have hp := bitRationalInputDenominator_positive A (fun i j => (hWF i j).2.2.1)
  apply Prod.ext
  · funext i j
    simp only [encodedRationalReduction, encodedFractionRows, outputBits_get_ofFn]
    change bitListFractionValue (bitListUnscaleInteger (bitRationalInputDenominator A)
      (((encodedIntegerReduction D).rows.get i).get j)) = _
    rw [bitListUnscaleInteger_value _ _ hp]
    change (bitIntegerMatrixValue (encodedIntegerReduction D).rows i j:ℚ)/
      (binaryDigitsValue (bitRationalInputDenominator A):ℚ) = _
    rw [hm, bitRationalInputDenominator_semantics A hWF]
    rfl
  · exact hs

theorem encodedRationalReduction_native_spec (A : BitRationalMatrixData r r)
    (hWF : ∀ i j, ((A.get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows A i j:ℝ))) :
    Submodule.span ℤ (Set.range (encodedFractionRows (encodedRationalReduction A).1)) =
      Submodule.span ℤ (Set.range (encodedFractionRows A)) ∧
    ∃ b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)),
      (∀ i, b i = rationalEuclideanRows (encodedFractionRows (encodedRationalReduction A).1) i) ∧
      euclideanOrthogonalityDefect b ≤ sharpLatticeDefectBound r := by
  have he := congrArg Prod.fst (encodedRationalReduction_semantics A hWF hA)
  dsimp only [Prod.fst] at he
  rw [he]
  exact executableRationalReduction_spec _ hA

end Optss
