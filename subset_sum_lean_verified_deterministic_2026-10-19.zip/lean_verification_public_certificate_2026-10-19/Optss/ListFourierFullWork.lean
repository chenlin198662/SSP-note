import Optss.ListFourierInitialization
import Optss.ListFourierPolynomial

/-! The structural initializer and the complete list transform satisfy one
explicit N poly(log N) source-work bound. The polynomial below has natural
coefficients and is independent of the input. -/
namespace Optss
set_option maxRecDepth 4096

def listStructuralDyadicDFTWork (input : List Bool) : ℕ :=
  let depth := listFourierDepth input
  let precision := listFourierPrecision depth
  listFourierInitializationWork input+listBluesteinTransformWork depth precision.length input

theorem listStructuralDyadicDFTWork_eq (input : List Bool) (hinput : input≠[]) :
    listStructuralDyadicDFTWork input=
      listFourierInitializationWork input+listCanonicalDyadicDFTWork input := by
  rw [listStructuralDyadicDFTWork,listFourierPrecision_length,listFourierDepth_eq input hinput]
  simp only [List.length_replicate,listCanonicalDyadicDFTWork]

noncomputable def listFourierWorkPolynomial : Polynomial ℕ :=
  let s := Polynomial.X
  let n := s+2
  let p := 5*n+12
  let b := 2*(n*(p+6)+(p+4)+2)+1
  let fft := 12*(320*(n+3)^2+4194304*(n+p+73)^2*(8192*(n+p+73)^4+1)^3+16)+
    4*(p+3)+4+3456*(n+1)*(n*(p+6)+b+3)^2
  5+864*(s+2)^2+
    2*(4194304*(s+1+p+72)^2*(8192*(s+1+p+72)^4+1)^3)+
    3*fft+3072*(n*(p+6)+(p+4)+3)^2+44+
    512*(3*n*(p+6)+2*(p+4)+8)^2+184+
    512*(s+3)^2

theorem listFourierWorkPolynomial_eval (s : ℕ) :
    listFourierWorkPolynomial.eval s=listFourierWorkFactor s+512*(s+3)^2 := by
  simp only [listFourierWorkPolynomial,listFourierWorkFactor,listDyadicWorkFactor,
    Polynomial.eval_add,Polynomial.eval_mul,Polynomial.eval_pow,Polynomial.eval_X,
    Polynomial.eval_ofNat,Polynomial.eval_one]

theorem listStructuralDyadicDFTWork_bound (input : List Bool) (hinput : input≠[]) :
    listStructuralDyadicDFTWork input≤ input.length*listFourierWorkPolynomial.eval input.length.size := by
  have hN : 0 < input.length := List.length_pos_iff.mpr hinput
  have hi := listFourierInitializationWork_bound input
  have ht := listCanonicalDyadicDFTWork_bound input hinput
  rw [listStructuralDyadicDFTWork_eq input hinput,listFourierWorkPolynomial_eval]
  have hh : 256*(input.length+1)*(input.length.size+3)^2≤
      input.length*(512*(input.length.size+3)^2) := by
    have hm := Nat.mul_le_mul_right ((input.length.size+3)^2) (by omega :
      256*(input.length+1)≤512*input.length)
    simpa only [Nat.mul_assoc,Nat.mul_left_comm] using hm
  calc
    _≤ input.length*(512*(input.length.size+3)^2)+input.length*listFourierWorkFactor input.length.size :=
      Nat.add_le_add (hi.trans hh) ht
    _=_ := by rw [← Nat.mul_add,Nat.add_comm]

end Optss
