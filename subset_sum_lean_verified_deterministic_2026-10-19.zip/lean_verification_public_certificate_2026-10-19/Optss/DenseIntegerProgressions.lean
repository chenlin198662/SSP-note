import Optss.LevTranslatedIntervals
import Optss.IntegerFiberPeriods
import Mathlib.Algebra.Order.Floor.Semiring

/-!
# Dense integer fibers contain long arithmetic progressions

This proves the common-period filling step of Conlon–Fox–Pham,
`Homogeneous structures in subset sums and non-averaging sets`, Lemma 2.11.
The density and number-of-summands constants are checked explicitly and
the only sumset input is the already proved Lev interval corollary.
Primary source: https://www.its.caltech.edu/~dconlon/subset_sums_highdim.pdf .
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

/-- The explicit density constants suffice for Lev's actual integer
ceiling parameter. Hypotheses are written without division. -/
theorem dense_lev_parameters (c : ℝ) (N m : ℕ) (hc : 0 < c) (hc1 : c ≤ 1)
    (hN : 4 ≤ c * N) (hm : 10 ≤ c * m) :
    3 ≤ ⌈c * N⌉₊ ∧ 2 ≤ N ∧
      2 * ((N - 2) / (⌈c * N⌉₊ - 2) + 1) ≤ m ∧
      c * N / 2 ≤ (⌈c * N⌉₊ : ℝ) - 1 := by
  let n := ⌈c * N⌉₊
  have hcn : c * N ≤ (n : ℝ) := Nat.le_ceil _
  have hn4 : 4 ≤ n := by have : (4 : ℝ) ≤ n := hN.trans hcn; exact_mod_cast this
  have hN4 : 4 ≤ N := by
    have hNr : (4 : ℝ) ≤ N := by nlinarith [show (0 : ℝ) ≤ N by positivity]
    exact_mod_cast hNr
  let k := (N - 2) / (n - 2)
  have hkdNat : k * (n - 2) ≤ N - 2 := Nat.div_mul_le_self _ _
  have hkd : (k : ℝ) * ((n : ℝ) - 2) ≤ (N : ℝ) - 2 := by
    have h : (k : ℝ) * ((n - 2 : ℕ) : ℝ) ≤ ((N - 2 : ℕ) : ℝ) := by exact_mod_cast hkdNat
    simpa only [Nat.cast_sub (by omega : 2 ≤ n), Nat.cast_sub (by omega : 2 ≤ N), Nat.cast_ofNat] using h
  have hd : c * N ≤ 2 * ((n : ℝ) - 2) := by linarith
  have hNr : (0 : ℝ) < N := by exact_mod_cast (show 0 < N by omega)
  have hck : c * k ≤ 2 := by
    apply (mul_le_mul_left hNr).mp
    nlinarith [mul_nonneg (show (0 : ℝ) ≤ k by positivity) (sub_nonneg.mpr hd)]
  have hkbound : 2 * (k + 1) ≤ m := by
    have hreal : (2 : ℝ) * ((k : ℝ) + 1) ≤ m := by
      apply (mul_le_mul_left hc).mp
      nlinarith
    exact_mod_cast hreal
  exact ⟨by omega, by omega, hkbound, by linarith⟩

private theorem dense_normalize_period_list (L : List (Finset ℤ)) (n N : ℕ) (v : ℤ)
    (hn : 2 ≤ n) (hv : 0 < v)
    (hcard : ∀ A ∈ L, n ≤ A.card)
    (hbox : ∀ A ∈ L, ∃ u : ℤ, A ⊆ Finset.Icc u (u + N))
    (hperiod : ∀ A ∈ L, HasFullIntegerPeriod A v) :
    ∃ D : List (ℤ × (Finset ℤ × ℕ)),
      D.length = L.length ∧
      (∀ p ∈ D, LevNormalized p.2.1 p.2.2 ∧ n ≤ p.2.1.card ∧ p.2.2 ≤ N) ∧
      L.sum = (D.map (fun p : ℤ × (Finset ℤ × ℕ) => p.2.1)).sum.image
        (fun x => (D.map Prod.fst).sum + v * x) := by
  induction L with
  | nil => exact ⟨[], by simp, by simp, by simp; rfl⟩
  | cons A L ih =>
    obtain ⟨D, hlen, hD, hsum⟩ := ih
      (fun B hB => hcard B (by simp [hB])) (fun B hB => hbox B (by simp [hB]))
      (fun B hB => hperiod B (by simp [hB]))
    obtain ⟨u, hu⟩ := hbox A (by simp)
    obtain ⟨a, l, B, hnorm, hBc, hA, hW⟩ := integer_full_period_normalization A u N v
      (hn.trans (hcard A (by simp))) hu hv (hperiod A (by simp))
    have hl : l ≤ N := by
      have hv1 : 1 ≤ v := by omega
      have hh : (l : ℤ) ≤ N := by nlinarith [show (0 : ℤ) ≤ l by positivity]
      exact_mod_cast hh
    refine ⟨(a, B, l) :: D, by simp [hlen], ?_, ?_⟩
    · intro p hp
      rcases List.mem_cons.mp hp with rfl | hp
      · exact ⟨hnorm, by rw [hBc]; exact hcard A (by simp), hl⟩
      · exact hD p hp
    · simp only [List.sum_cons, List.map_cons, hsum, hA]
      exact integer_affine_image_add _ _ _ _ _

/-- CFP Lemma 2.11, in a stronger interval-image form. Each summand may
lie in a different translated ambient interval of diameter `N`; the
common full period is an actual coset-spanning hypothesis. -/
theorem dense_integer_progression (L : List (Finset ℤ)) (N : ℕ) (v : ℤ) (c : ℝ)
    (hc : 0 < c) (hc1 : c ≤ 1) (hv : 0 < v)
    (hN : 4 ≤ c * N) (hcount : 10 ≤ c * L.length)
    (hcard : ∀ A ∈ L, c * N ≤ A.card)
    (hbox : ∀ A ∈ L, ∃ u : ℤ, A ⊆ Finset.Icc u (u + N))
    (hperiod : ∀ A ∈ L, HasFullIntegerPeriod A v) :
    ∃ t a b : ℤ, (Finset.Icc a b).image (fun x => t + v * x) ⊆ L.sum ∧
      c * L.length * N / 2 ≤ (b - a : ℤ) := by
  obtain ⟨hn, hN2, hm, hhalf⟩ := dense_lev_parameters c N L.length hc hc1 hN hcount
  let n := ⌈c * N⌉₊
  have hnc : ∀ A ∈ L, n ≤ A.card := fun A hA => Nat.ceil_le.mpr (hcard A hA)
  obtain ⟨D, hlen, hD, hsum⟩ := dense_normalize_period_list L n N v (by omega) hv hnc hbox hperiod
  obtain ⟨a, b, hI, hlong⟩ := lev_interval_corollary_width (D.map Prod.snd) n N hn hN2
    (by simpa [hlen] using hm)
    (by intro p hp; obtain ⟨q, hq, rfl⟩ := List.mem_map.mp hp; exact (hD q hq).1)
    (by intro p hp; obtain ⟨q, hq, rfl⟩ := List.mem_map.mp hp; exact (hD q hq).2.1)
    (by intro p hp; obtain ⟨q, hq, rfl⟩ := List.mem_map.mp hp; exact (hD q hq).2.2)
  simp only [List.length_map, hlen] at hlong
  simp only [List.map_map, Function.comp_def] at hI
  refine ⟨(D.map Prod.fst).sum, a, b, ?_, ?_⟩
  · rw [hsum]
    exact Finset.image_subset_image hI
  · have hlongR : (L.length : ℝ) * ((n : ℝ) - 1) ≤ ((b - a : ℤ) : ℝ) := by
      exact_mod_cast hlong
    have hh := mul_le_mul_of_nonneg_left hhalf (show (0 : ℝ) ≤ L.length by positivity)
    nlinarith

/-- A literal translate of `v * [1, floor(c*m*N/2)]`, as in the source. -/
theorem dense_integer_progression_initial_segment (L : List (Finset ℤ)) (N : ℕ) (v : ℤ) (c : ℝ)
    (hc : 0 < c) (hc1 : c ≤ 1) (hv : 0 < v)
    (hN : 4 ≤ c * N) (hcount : 10 ≤ c * L.length)
    (hcard : ∀ A ∈ L, c * N ≤ A.card)
    (hbox : ∀ A ∈ L, ∃ u : ℤ, A ⊆ Finset.Icc u (u + N))
    (hperiod : ∀ A ∈ L, HasFullIntegerPeriod A v) :
    ∃ t : ℤ, (Finset.Icc 1 (⌊c * L.length * N / 2⌋₊ : ℤ)).image
      (fun x => t + v * x) ⊆ L.sum := by
  obtain ⟨t, a, b, hI, hlong⟩ := dense_integer_progression L N v c hc hc1 hv hN hcount hcard hbox hperiod
  have hfloor := Nat.floor_le (show 0 ≤ c * L.length * N / 2 by positivity)
  have hfloorZ : (⌊c * L.length * N / 2⌋₊ : ℤ) ≤ b - a := by
    exact_mod_cast hfloor.trans hlong
  refine ⟨t + v * (a - 1), ?_⟩
  intro x hx
  obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
  have hy' := Finset.mem_Icc.mp hy
  apply hI
  refine Finset.mem_image.mpr ⟨a - 1 + y, Finset.mem_Icc.mpr ⟨by omega, by omega⟩, ?_⟩
  ring

end
end Optss
