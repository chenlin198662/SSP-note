import Mathlib.Algebra.Order.BigOperators.Ring.Finset
import Mathlib.Data.Real.Basic
import Mathlib.Tactic

/-!
# Array-size accounting

The first main inequality is exactly the real-valued product inequality in
Appendix A, equation (84). It allows zero-width coordinates and does not replace
the integer convolution implementation or its bit complexity.

The final lemma is a finite accounting fact for nonnegative layer weights whose
successive totals contract by one half. It does not prove that the manuscript's
geometric reductions satisfy this contraction.
-/

namespace Optss

open scoped BigOperators

variable {ι : Type*}

/-- Shrinking nonnegative coordinate widths cannot increase the product array. -/
theorem scaled_array_product_le (s : Finset ι) (e : ι → ℝ) {b : ℝ}
    (hb : 1 ≤ b) (he : ∀ i ∈ s, 0 ≤ e i) :
    (∏ i ∈ s, (1 + e i / b)) ≤ ∏ i ∈ s, (1 + e i) := by
  have hb0 : 0 ≤ b := le_trans zero_le_one hb
  apply Finset.prod_le_prod
  · intro i hi
    exact add_nonneg zero_le_one (div_nonneg (he i hi) hb0)
  · intro i hi
    exact add_le_add_left (div_le_self (he i hi) hb) 1

/-- Product factors include the constant entry even for zero-width coordinates. -/
theorem one_le_array_product (s : Finset ι) (e : ι → ℝ)
    (he : ∀ i ∈ s, 0 ≤ e i) :
    1 ≤ ∏ i ∈ s, (1 + e i) := by
  calc
    1 = ∏ _i ∈ s, (1 : ℝ) := by simp
    _ ≤ ∏ i ∈ s, (1 + e i) := by
      apply Finset.prod_le_prod
      · intro i hi
        exact zero_le_one
      · intro i hi
        exact le_add_of_nonneg_right (he i hi)

/-- The product-array bound of Appendix A, equation (84).

Here `b` is the number of equal-sized nodes at a product-tree level and `e i`
is the total coordinate budget. The theorem is valid for arbitrary real `b ≥ 1`,
so it applies in particular when the node count is a positive integer.
-/
theorem balanced_array_level_bound (s : Finset ι) (e : ι → ℝ) {b : ℝ}
    (hb : 1 ≤ b) (he : ∀ i ∈ s, 0 ≤ e i) :
    b * (∏ i ∈ s, (1 + e i / b)) ≤ b + (∏ i ∈ s, (1 + e i)) - 1 := by
  classical
  have hb0 : 0 < b := lt_of_lt_of_le zero_lt_one hb
  have expand (x y : ℝ) : b * ((1 + x / b) * y) = b * y + x * y := by
    field_simp [ne_of_gt hb0]; ring
  induction s using Finset.induction_on with
  | empty => simp
  | @insert i s hi ih =>
      have hei : 0 ≤ e i := he i (by simp)
      have hes : ∀ j ∈ s, 0 ≤ e j := fun j hj => he j (Finset.mem_insert_of_mem hj)
      have hprev := ih hes
      have hprod := scaled_array_product_le s e hb hes
      rw [Finset.prod_insert hi, Finset.prod_insert hi, expand]
      calc
        b * (∏ j ∈ s, (1 + e j / b)) + e i * (∏ j ∈ s, (1 + e j / b))
            ≤ (b + (∏ j ∈ s, (1 + e j)) - 1) + e i * (∏ j ∈ s, (1 + e j)) :=
          add_le_add hprev (mul_le_mul_of_nonneg_left hprod hei)
        _ = b + (1 + e i) * (∏ j ∈ s, (1 + e j)) - 1 := by ring

/-- Equation (84) with all coordinates of a finite coordinate type. -/
theorem balanced_array_level_bound_univ [Fintype ι] (e : ι → ℝ) {b : ℝ}
    (hb : 1 ≤ b) (he : ∀ i, 0 ≤ e i) :
    b * (∏ i, (1 + e i / b)) ≤ b + (∏ i, (1 + e i)) - 1 :=
  balanced_array_level_bound Finset.univ e hb (fun i _ => he i)

/-- Summing finitely many layer totals that contract by one half costs at most
twice the root weight. All hypotheses are explicit; this is only accounting. -/
theorem sum_of_halving_layers_le (w : ℕ → ℝ) (n : ℕ)
    (hw : ∀ i, 0 ≤ w i) (hstep : ∀ i, w (i + 1) ≤ w i / 2) :
    (∑ i ∈ Finset.range n, w i) ≤ 2 * w 0 := by
  have strong : ∀ m, (∑ i ∈ Finset.range m, w i) + 2 * w m ≤ 2 * w 0 := by
    intro m
    induction m with
    | zero => simp
    | succ m ih =>
        rw [Finset.sum_range_succ]
        have hs := hstep m
        linarith
  have hn := strong n
  have hn0 := hw n
  linarith

end Optss
