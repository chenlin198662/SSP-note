import Optss.TerminatingLatticeReduction
import Optss.LatticeChains

/-!
# Input-height bounds for lattice-reduction potential

The logarithmic swap estimate is related to the actual integer input entries.
These are bounds on the potential and swap count; they do not count the bit
cost of rational Gram-Schmidt evaluation or bound intermediate row sizes.
-/

namespace Optss
noncomputable section
open scoped BigOperators
variable {r d : ℕ}

theorem integerGram_entry_bound (A : Matrix (Fin r) (Fin d) ℤ) (H : ℕ)
    (hA : ∀ i j, |A i j| ≤ (H:ℤ)) (i j : Fin r) :
    |integerGram A i j| ≤ (d*H^2:ℕ) := by
  rw [integerGram_apply]
  calc
    _ ≤ ∑ k : Fin d, |A i k * A j k| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _k : Fin d, (H:ℤ)^2 := by
      apply Finset.sum_le_sum
      intro k _
      rw [abs_mul, pow_two]
      exact mul_le_mul (hA i k) (hA j k) (abs_nonneg _) (Int.natCast_nonneg _)
    _ = _ := by simp [Nat.cast_mul, Nat.cast_pow]

def latticeInputGramBound (r d H : ℕ) : ℕ := r.factorial*(max 1 (d*H^2))^r

theorem latticeInputGramBound_pos (r d H : ℕ) : 0 < latticeInputGramBound r d H := by
  unfold latticeInputGramBound
  exact Nat.mul_pos (Nat.factorial_pos _) (pow_pos (by omega) _)

theorem prefixGramDet_height_bound (A : Matrix (Fin r) (Fin d) ℤ) (H : ℕ)
    (hA : ∀ i j, |A i j| ≤ (H:ℤ)) (t : Fin (r+1)) :
    (prefixGramDet A t).natAbs ≤ latticeInputGramBound r d H := by
  have he : ∀ i j, |integerGram (prefixRows A t) i j| ≤ (max 1 (d*H^2):ℕ) := by
    intro i j
    exact (integerGram_entry_bound (prefixRows A t) H (fun i j => hA _ j) i j).trans
      (by exact_mod_cast (le_max_right 1 (d*H^2)))
  have hb := abs_det_le_factorial_prod (integerGram (prefixRows A t))
    (fun _ => ((max 1 (d*H^2):ℕ):ℤ)) he
  have hb' : (prefixGramDet A t).natAbs ≤ t.val.factorial*(max 1 (d*H^2))^t.val := by
    rw [← Int.natCast_natAbs] at hb
    simpa only [Fintype.card_fin, Finset.prod_const, Finset.card_univ,
      ← Nat.cast_pow, ← Nat.cast_mul, Nat.cast_le] using hb
  apply hb'.trans
  apply Nat.mul_le_mul (Nat.factorial_le (Nat.le_of_lt_succ t.isLt))
  exact pow_le_pow_right₀ (le_max_left _ _) (Nat.le_of_lt_succ t.isLt)

theorem gramPotential_height_bound (A : Matrix (Fin r) (Fin d) ℤ) (H : ℕ)
    (hA : ∀ i j, |A i j| ≤ (H:ℤ)) :
    gramPotential A ≤ (latticeInputGramBound r d H)^(r+1) := by
  unfold gramPotential
  calc
    _ ≤ ∏ _t : Fin (r+1), latticeInputGramBound r d H :=
      Finset.prod_le_prod' (fun t _ => prefixGramDet_height_bound A H hA t)
    _ = _ := by simp

theorem IntegerLLLResult.swapCount_height_bound (A : Matrix (Fin r) (Fin d) ℤ)
    (out : IntegerLLLResult A) (H : ℕ) (hA : ∀ i j, |A i j| ≤ (H:ℤ)) :
    (out.swapCount:ℝ) ≤
      ((r+1:ℕ):ℝ)*Real.log (latticeInputGramBound r d H)/Real.log (4/3:ℝ) := by
  have hpos : (0:ℝ) < gramPotential A := by
    have h := out.swapCount_ratio_le A
    exact (pow_pos (by norm_num : (0:ℝ)<4/3) _).trans_le h
  have hb : (gramPotential A:ℝ) ≤ (latticeInputGramBound r d H:ℝ)^(r+1) := by
    exact_mod_cast gramPotential_height_bound A H hA
  have hl := Real.log_le_log hpos hb
  rw [Real.log_pow] at hl
  exact (out.swapCount_le_log A).trans (div_le_div_of_nonneg_right hl (by positivity))

theorem latticeInputGramBound_le_power (r d H : ℕ) :
    latticeInputGramBound r d H ≤ ((r+1)*(d+1)*(H+1)^2)^r := by
  have hf : r.factorial ≤ (r+1)^r :=
    (Nat.factorial_le_pow r).trans (Nat.pow_le_pow_left (Nat.le_succ r) r)
  have hm : max 1 (d*H^2) ≤ (d+1)*(H+1)^2 := by
    apply max_le
    · have hH : 1 ≤ (H+1)^2 := one_le_pow₀ (by omega)
      nlinarith
    · exact Nat.mul_le_mul (Nat.le_succ _) (Nat.pow_le_pow_left (Nat.le_succ _) _)
  calc
    _ ≤ (r+1)^r*((d+1)*(H+1)^2)^r := Nat.mul_le_mul hf (Nat.pow_le_pow_left hm _)
    _ = _ := by rw [← mul_pow]; congr 1; ring

theorem latticeInputGramBound_log_le (r d H : ℕ) :
    Real.log (latticeInputGramBound r d H) ≤
      (r:ℝ)*(Real.log (r+1)+Real.log (d+1)+2*Real.log (H+1)) := by
  have hp : (0:ℝ) < latticeInputGramBound r d H := by
    exact_mod_cast latticeInputGramBound_pos r d H
  have hb : (latticeInputGramBound r d H:ℝ) ≤
      (((r:ℝ)+1)*((d:ℝ)+1)*((H:ℝ)+1)^2)^r := by
    exact_mod_cast latticeInputGramBound_le_power r d H
  have hl := Real.log_le_log hp hb
  rw [Real.log_pow, Real.log_mul (by positivity) (by positivity),
    Real.log_mul (by positivity) (by positivity), Real.log_pow] at hl
  simpa only [Nat.cast_ofNat] using hl

/-- A polynomial expression in dimension and logarithmic input height bounds
the actual number of swaps. This still excludes the cost per arithmetic step. -/
theorem IntegerLLLResult.swapCount_log_height (A : Matrix (Fin r) (Fin d) ℤ)
    (out : IntegerLLLResult A) (H : ℕ) (hA : ∀ i j, |A i j| ≤ (H:ℤ)) :
    (out.swapCount:ℝ) ≤
      ((r:ℝ)+1)*r*(Real.log (r+1)+Real.log (d+1)+2*Real.log (H+1))/Real.log (4/3:ℝ) := by
  apply (out.swapCount_height_bound A H hA).trans
  apply div_le_div_of_nonneg_right _ (by positivity)
  have h := mul_le_mul_of_nonneg_left (latticeInputGramBound_log_le r d H)
    (by positivity : (0:ℝ) ≤ (r:ℝ)+1)
  push_cast
  nlinarith only [h]

end
end Optss
