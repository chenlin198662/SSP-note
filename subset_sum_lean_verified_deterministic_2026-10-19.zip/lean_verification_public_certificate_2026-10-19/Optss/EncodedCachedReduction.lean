import Optss.ReductionPrimitives
import Optss.BitListRationalInput

/-!
# Cached Gram–Schmidt and lattice reduction on encoded scalar values

Integer and rational cells remain Boolean-list values throughout the answer
routines. Decoding maps occur in theorems only. Arrays store each coefficient,
row and table before later cells consume it.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

private theorem get_ofFn_fun {α : Type*} {n : ℕ} (f : Fin n → α) :
    (Vector.ofFn f).get = f := funext (get_ofFn f)

private theorem get_set {α : Type*} {n : ℕ} (v : Vector α n)
    (k i : Fin n) (a : α) :
    (v.set k.val a k.isLt).get i = if i = k then a else v.get i := by
  change (v.set k.val a k.isLt)[i.val] = _
  rw [Vector.getElem_set]
  split <;> rename_i h
  · have he : i = k := Fin.ext h.symm
    simp [he]
  · have he : i ≠ k := fun he => h (congrArg Fin.val he.symm)
    simp [he]
    rfl

/-- Proof-only matrix interpretation of an encoded rational array. -/
def encodedFractionRows (A : BitRationalMatrixData r d) : Matrix (Fin r) (Fin d) ℚ :=
  fun i j => bitListFractionValue ((A.get i).get j)

/-- Proof-only table interpretation. -/
def encodedFractionTableValue (A : BitRationalMatrixData r d) : RationalGSTable r d :=
  Vector.ofFn fun i => Vector.ofFn (encodedFractionRows A i)

def EncodedPositiveDenominators (A : BitRationalMatrixData r d) : Prop :=
  ∀ i j, 0 < binaryDigitsValue ((A.get i).get j).denominator

/-- Actual right-fold dot accumulator, in the same order as the metered fold. -/
def encodedProductSum {ι : Type*} (u v : ι → BitListFraction) : List ι → BitListFraction
  | [] => bitListFractionZero
  | i::is =>
    let product := bitListFractionMul (u i) (v i)
    let tail := encodedProductSum u v is
    bitListFractionAdd product tail

theorem encodedProductSum_wellFormed {ι : Type*} (u v : ι → BitListFraction)
    (hu : ∀ i, 0 < binaryDigitsValue (u i).denominator)
    (hv : ∀ i, 0 < binaryDigitsValue (v i).denominator) (is : List ι) :
    (encodedProductSum u v is).WellFormed := by
  induction is with
  | nil => exact bitListFractionZero_wellFormed
  | cons i is ih =>
    exact bitListFractionAdd_wellFormed _ _
      (bitListFractionMul_wellFormed _ _ (hu i) (hv i)).2.2.1 ih.2.2.1

theorem encodedProductSum_value {ι : Type*} (u v : ι → BitListFraction)
    (hu : ∀ i, 0 < binaryDigitsValue (u i).denominator)
    (hv : ∀ i, 0 < binaryDigitsValue (v i).denominator) (is : List ι) :
    bitListFractionValue (encodedProductSum u v is) =
      (is.map fun i => bitListFractionValue (u i)*bitListFractionValue (v i)).sum := by
  induction is with
  | nil => exact bitListFractionZero_value
  | cons i is ih =>
    rw [encodedProductSum, bitListFractionAdd_correct _ _
      (bitListFractionMul_wellFormed _ _ (hu i) (hv i)).2.2.1
      (encodedProductSum_wellFormed u v hu hv is).2.2.1,
      bitListFractionMul_correct _ _ (hu i) (hv i), ih, List.map_cons, List.sum_cons]

def encodedRationalDot (u v : Fin d → BitListFraction) : BitListFraction :=
  encodedProductSum u v (List.ofFn id)

theorem encodedRationalDot_wellFormed (u v : Fin d → BitListFraction)
    (hu : ∀ i, 0 < binaryDigitsValue (u i).denominator)
    (hv : ∀ i, 0 < binaryDigitsValue (v i).denominator) :
    (encodedRationalDot u v).WellFormed := encodedProductSum_wellFormed u v hu hv _

theorem encodedRationalDot_value (u v : Fin d → BitListFraction)
    (hu : ∀ i, 0 < binaryDigitsValue (u i).denominator)
    (hv : ∀ i, 0 < binaryDigitsValue (v i).denominator) :
    bitListFractionValue (encodedRationalDot u v) =
      rationalDot (fun i => bitListFractionValue (u i)) (fun i => bitListFractionValue (v i)) := by
  rw [encodedRationalDot, encodedProductSum_value u v hu hv, List.map_ofFn, List.sum_ofFn]
  rfl

def encodedGsCoefficient (A T : BitRationalMatrixData r d) (k j : Fin r) : BitListFraction :=
  let num := encodedRationalDot (T.get j).get (A.get k).get
  let den := encodedRationalDot (T.get j).get (T.get j).get
  bitListFractionDiv num den

theorem encodedGsCoefficient_wellFormed (A T : BitRationalMatrixData r d)
    (hA : EncodedPositiveDenominators A) (hT : EncodedPositiveDenominators T) (k j : Fin r) :
    (encodedGsCoefficient A T k j).WellFormed := by
  exact bitListFractionDiv_wellFormed _ _
    (encodedRationalDot_wellFormed _ _ (hT j) (hA k)).2.2.1

theorem encodedGsCoefficient_value (A T : BitRationalMatrixData r d)
    (hA : EncodedPositiveDenominators A) (hT : EncodedPositiveDenominators T) (k j : Fin r) :
    bitListFractionValue (encodedGsCoefficient A T k j) =
      cachedGsCoefficient (encodedFractionRows A) (encodedFractionTableValue T) k j := by
  rw [encodedGsCoefficient, bitListFractionDiv_correct _ _
    (encodedRationalDot_wellFormed _ _ (hT j) (hA k)).2.2.1
    (encodedRationalDot_wellFormed _ _ (hT j) (hT j)).2.2.1,
    encodedRationalDot_value _ _ (hT j) (hA k), encodedRationalDot_value _ _ (hT j) (hT j)]
  simp only [cachedGsCoefficient, encodedFractionTableValue, get_ofFn, get_ofFn_fun, encodedFractionRows]
  rfl

def encodedGSCoefficients (A T : BitRationalMatrixData r d) (k : Fin r) : Vector BitListFraction r :=
  Vector.ofFn fun i => if i < k then encodedGsCoefficient A T k i else bitListFractionZero

theorem encodedGSCoefficients_positive (A T : BitRationalMatrixData r d)
    (hA : EncodedPositiveDenominators A) (hT : EncodedPositiveDenominators T) (k i : Fin r) :
    0 < binaryDigitsValue ((encodedGSCoefficients A T k).get i).denominator := by
  simp only [encodedGSCoefficients, get_ofFn]
  split_ifs
  · exact (encodedGsCoefficient_wellFormed A T hA hT k i).2.2.1
  · exact bitListFractionZero_wellFormed.2.2.1

def encodedGSRow (A T : BitRationalMatrixData r d) (k : Fin r) : Vector BitListFraction d :=
  let coeff := encodedGSCoefficients A T k
  Vector.ofFn fun l =>
    let acc := encodedProductSum (fun i : Finset.Iio k => coeff.get i)
      (fun i => (T.get i).get l) (List.ofFn (lowerFinEquiv k))
    bitListFractionSub ((A.get k).get l) acc

theorem encodedGSRow_wellFormed (A T : BitRationalMatrixData r d)
    (hA : EncodedPositiveDenominators A) (hT : EncodedPositiveDenominators T) (k : Fin r) (l : Fin d) :
    ((encodedGSRow A T k).get l).WellFormed := by
  simp only [encodedGSRow, get_ofFn]
  exact bitListFractionSub_wellFormed _ _ (hA k l)
    (encodedProductSum_wellFormed _ _
      (fun i : Finset.Iio k => encodedGSCoefficients_positive A T hA hT k i) (fun i : Finset.Iio k => hT i l) _).2.2.1

theorem encodedGSRow_value (A T : BitRationalMatrixData r d)
    (hA : EncodedPositiveDenominators A) (hT : EncodedPositiveDenominators T) (k : Fin r) :
    (fun l => bitListFractionValue ((encodedGSRow A T k).get l)) =
      (cachedGSRow (encodedFractionRows A) (encodedFractionTableValue T) k).get := by
  funext l
  simp only [encodedGSRow, get_ofFn]
  rw [bitListFractionSub_correct _ _ (hA k l)
    (encodedProductSum_wellFormed _ _
      (fun i : Finset.Iio k => encodedGSCoefficients_positive A T hA hT k i) (fun i : Finset.Iio k => hT i l) _).2.2.1,
    encodedProductSum_value _ _
      (fun i : Finset.Iio k => encodedGSCoefficients_positive A T hA hT k i) (fun i : Finset.Iio k => hT i l),
    List.map_ofFn, List.sum_ofFn]
  simp only [cachedGSRow, get_ofFn, encodedGSCoefficients, encodedFractionTableValue]
  congr 1
  simp only [Function.comp_apply]
  rw [Equiv.sum_comp (lowerFinEquiv k) (fun i : Finset.Iio k =>
    bitListFractionValue (if (i:Fin r) < k then encodedGsCoefficient A T k i else bitListFractionZero) *
      bitListFractionValue ((T.get i).get l))]
  apply Finset.sum_congr rfl
  intro i _
  have hi : (i : Fin r) < k := Finset.mem_Iio.mp i.2
  simp only [hi, ↓reduceIte, encodedGsCoefficient_value A T hA hT]
  simp only [cachedGsCoefficient, encodedFractionTableValue, get_ofFn, get_ofFn_fun, encodedFractionRows]

def encodedGSTable (A : BitRationalMatrixData r d) (n : ℕ) (hn : n ≤ r) :
    BitRationalMatrixData r d :=
  match n with
  | 0 => Vector.replicate r (Vector.replicate d bitListFractionZero)
  | n+1 =>
    let T := encodedGSTable A n (by omega)
    let k : Fin r := ⟨n, by omega⟩
    T.set n (encodedGSRow A T k) (by omega)
termination_by n

theorem encodedGSTable_positive (A : BitRationalMatrixData r d)
    (hA : EncodedPositiveDenominators A) (n : ℕ) (hn : n ≤ r) :
    EncodedPositiveDenominators (encodedGSTable A n hn) := by
  induction n with
  | zero =>
    intro i j
    simpa [encodedGSTable, Vector.get] using
      bitListFractionZero_wellFormed.2.2.1
  | succ n ih =>
    intro i j
    rw [encodedGSTable, get_set _ ⟨n, by omega⟩]
    split_ifs
    · exact (encodedGSRow_wellFormed _ _ hA (ih (by omega)) _ _).2.2.1
    · exact ih (by omega) i j

theorem encodedGSTable_value (A : BitRationalMatrixData r d)
    (hA : EncodedPositiveDenominators A) (n : ℕ) (hn : n ≤ r) :
    encodedFractionTableValue (encodedGSTable A n hn) = cachedGSTable (encodedFractionRows A) n hn := by
  induction n with
  | zero =>
    apply Vector.ext
    intro i hi
    apply Vector.ext
    intro j hj
    change ((encodedFractionTableValue (encodedGSTable A 0 hn)).get ⟨i,hi⟩).get ⟨j,hj⟩ =
      ((cachedGSTable (encodedFractionRows A) 0 hn).get ⟨i,hi⟩).get ⟨j,hj⟩
    simp [encodedFractionTableValue, encodedFractionRows, get_ofFn, encodedGSTable, cachedGSTable, bitListFractionZero_value, Vector.get]
  | succ n ih =>
    apply Vector.ext
    intro i hi
    apply Vector.ext
    intro j hj
    change ((encodedFractionTableValue (encodedGSTable A (n+1) hn)).get ⟨i,hi⟩).get ⟨j,hj⟩ =
      ((cachedGSTable (encodedFractionRows A) (n+1) hn).get ⟨i,hi⟩).get ⟨j,hj⟩
    simp only [encodedFractionTableValue, get_ofFn, encodedFractionRows]
    rw [encodedGSTable, cachedGSTable, get_set _ ⟨n, by omega⟩, get_set _ ⟨n, by omega⟩]
    split_ifs
    · rw [congrFun (encodedGSRow_value A _ hA (encodedGSTable_positive A hA n (by omega)) _) ⟨j,hj⟩,
        ih (by omega)]
    · have he := congrArg (fun X : RationalGSTable r d => (X.get ⟨i,hi⟩).get ⟨j,hj⟩) (ih (by omega))
      simpa only [encodedFractionTableValue, get_ofFn, encodedFractionRows] using he

/-- Every computed table cell is normalized, including untouched zero rows. -/
theorem encodedGSTable_wellFormed (A : BitRationalMatrixData r d)
    (hA : EncodedPositiveDenominators A) (n : ℕ) (hn : n ≤ r) (i : Fin r) (j : Fin d) :
    (((encodedGSTable A n hn).get i).get j).WellFormed := by
  induction n with
  | zero => simp [encodedGSTable, Vector.get, bitListFractionZero_wellFormed]
  | succ n ih =>
    rw [encodedGSTable, get_set _ ⟨n, by omega⟩]
    split_ifs
    · exact encodedGSRow_wellFormed _ _ hA (encodedGSTable_positive A hA n (by omega)) _ _
    · exact ih (by omega)

/-- Embed an encoded integer by attaching denominator one, without decoding. -/
def encodedRationalIntegerRows (D : BitIntegerMatrixData r d) : BitRationalMatrixData r d :=
  Vector.ofFn fun i => Vector.ofFn fun j =>
    let z := (D.get i).get j
    ⟨z.negative,z.digits,[true]⟩

theorem encodedRationalIntegerRows_positive (D : BitIntegerMatrixData r d) :
    EncodedPositiveDenominators (encodedRationalIntegerRows D) := by
  intro i j
  norm_num [encodedRationalIntegerRows, get_ofFn, binaryDigitsValue]

theorem encodedRationalIntegerRows_value (D : BitIntegerMatrixData r d) :
    encodedFractionRows (encodedRationalIntegerRows D) = rationalIntegerRows (bitIntegerMatrixValue D) := by
  funext i j
  simp [encodedFractionRows, encodedRationalIntegerRows, get_ofFn, rationalIntegerRows,
    bitIntegerMatrixValue, BitListInteger.value, bitListFractionValue, binaryDigitsValue]

def encodedRoundInteger (q : BitListFraction) : BitListInteger :=
  let result := bitListFractionRound q
  ⟨result.1,result.2⟩

theorem encodedRoundInteger_value (q : BitListFraction)
    (hq : 0 < binaryDigitsValue q.denominator) :
    (encodedRoundInteger q).value = round (bitListFractionValue q) :=
  bitListFractionRound_correct q hq

/-- Descending size reduction keeps all entries encoded. -/
def encodedReduceIntegerRow (D : BitIntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) : BitIntegerMatrixData r d :=
  match n with
  | 0 => D
  | n+1 =>
    let j : Fin r := ⟨n, by omega⟩
    let Q := encodedRationalIntegerRows D
    let T := encodedGSTable Q r le_rfl
    let q := encodedRoundInteger (encodedGsCoefficient Q T k j)
    let W := bitListIntegerRowUpdate D k j q
    encodedReduceIntegerRow W k n (by omega)
termination_by n

theorem encodedReductionCoefficient_value (D : BitIntegerMatrixData r d) (k j : Fin r) :
    (encodedRoundInteger (encodedGsCoefficient (encodedRationalIntegerRows D)
      (encodedGSTable (encodedRationalIntegerRows D) r le_rfl) k j)).value =
    round (cachedGsCoefficient (rationalIntegerRows (bitIntegerMatrixValue D))
      (cachedGSTable (rationalIntegerRows (bitIntegerMatrixValue D)) r le_rfl) k j) := by
  have hD := encodedRationalIntegerRows_positive D
  have hT := encodedGSTable_positive _ hD r le_rfl
  rw [encodedRoundInteger_value _ (encodedGsCoefficient_wellFormed _ _ hD hT k j).2.2.1,
    encodedGsCoefficient_value _ _ hD hT, encodedGSTable_value _ hD,
    encodedRationalIntegerRows_value]

theorem encodedReduceIntegerRow_value (D : BitIntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) :
    bitIntegerMatrixValue (encodedReduceIntegerRow D k n h) =
      cachedReduceIntegerRow (bitIntegerMatrixValue D) k n h := by
  induction n generalizing D with
  | zero => rw [encodedReduceIntegerRow, cachedReduceIntegerRow]
  | succ n ih =>
    rw [encodedReduceIntegerRow, cachedReduceIntegerRow, ih, bitListIntegerRowUpdate_value,
      encodedReductionCoefficient_value, cacheIntegerMatrix_eq]

def encodedReduceIntegerAll (D : BitIntegerMatrixData r d)
    (n : ℕ) (h : n ≤ r) : BitIntegerMatrixData r d :=
  match n with
  | 0 => D
  | n+1 =>
    let C := encodedReduceIntegerAll D n (by omega)
    encodedReduceIntegerRow C ⟨n, by omega⟩ n le_rfl
termination_by n

theorem encodedReduceIntegerAll_value (D : BitIntegerMatrixData r d)
    (n : ℕ) (h : n ≤ r) :
    bitIntegerMatrixValue (encodedReduceIntegerAll D n h) =
      cachedReduceIntegerAll (bitIntegerMatrixValue D) n h := by
  induction n with
  | zero => rw [encodedReduceIntegerAll, cachedReduceIntegerAll, cacheIntegerMatrix_eq]
  | succ n ih =>
    rw [encodedReduceIntegerAll, cachedReduceIntegerAll, encodedReduceIntegerRow_value, ih]

def encodedFractionThree : BitListFraction := ⟨false,[true,true],[true]⟩
def encodedFractionFour : BitListFraction := ⟨false,[false,false,true],[true]⟩

private theorem encodedFractionThree_positive :
    0 < binaryDigitsValue encodedFractionThree.denominator := by
  norm_num [encodedFractionThree, binaryDigitsValue]
private theorem encodedFractionFour_positive :
    0 < binaryDigitsValue encodedFractionFour.denominator := by
  norm_num [encodedFractionFour, binaryDigitsValue]
private theorem encodedFractionThree_value : bitListFractionValue encodedFractionThree = 3 := by
  norm_num [encodedFractionThree, bitListFractionValue, signedBitsValue, binaryDigitsValue]
private theorem encodedFractionFour_value : bitListFractionValue encodedFractionFour = 4 := by
  norm_num [encodedFractionFour, bitListFractionValue, signedBitsValue, binaryDigitsValue]

/-- Direct encoded Lovász test, with shared norm and coefficient results. -/
def encodedLovaszPair (A T : BitRationalMatrixData r d) (j k : Fin r) : Bool :=
  let nk := encodedRationalDot (T.get k).get (T.get k).get
  let nj := encodedRationalDot (T.get j).get (T.get j).get
  let mu := encodedGsCoefficient A T k j
  let square := bitListFractionMul mu mu
  let product := bitListFractionMul square nj
  let total := bitListFractionAdd nk product
  let left := bitListFractionMul encodedFractionFour total
  let right := bitListFractionMul encodedFractionThree nj
  bitListFractionLT left right

theorem encodedLovaszPair_value (A T : BitRationalMatrixData r d)
    (hA : EncodedPositiveDenominators A) (hT : EncodedPositiveDenominators T) (j k : Fin r) :
    encodedLovaszPair A T j k = decide
      (4*(rationalDot (encodedFractionRows T k) (encodedFractionRows T k) +
        (cachedGsCoefficient (encodedFractionRows A) (encodedFractionTableValue T) k j)^2*
          rationalDot (encodedFractionRows T j) (encodedFractionRows T j)) <
        3*rationalDot (encodedFractionRows T j) (encodedFractionRows T j)) := by
  let nk := encodedRationalDot (T.get k).get (T.get k).get
  let nj := encodedRationalDot (T.get j).get (T.get j).get
  let mu := encodedGsCoefficient A T k j
  let square := bitListFractionMul mu mu
  let product := bitListFractionMul square nj
  let total := bitListFractionAdd nk product
  have hnk := (encodedRationalDot_wellFormed _ _ (hT k) (hT k)).2.2.1
  have hnj := (encodedRationalDot_wellFormed _ _ (hT j) (hT j)).2.2.1
  have hmu := (encodedGsCoefficient_wellFormed A T hA hT k j).2.2.1
  have hsq := (bitListFractionMul_wellFormed mu mu hmu hmu).2.2.1
  have hpr := (bitListFractionMul_wellFormed square nj hsq hnj).2.2.1
  have htot := (bitListFractionAdd_wellFormed nk product hnk hpr).2.2.1
  change bitListFractionLT (bitListFractionMul encodedFractionFour total)
    (bitListFractionMul encodedFractionThree nj) = _
  apply Bool.eq_iff_iff.mpr
  rw [bitListFractionLT_correct _ _
    (bitListFractionMul_wellFormed _ _ encodedFractionFour_positive htot).2.2.1
    (bitListFractionMul_wellFormed _ _ encodedFractionThree_positive hnj).2.2.1,
    bitListFractionMul_correct _ _ encodedFractionFour_positive htot,
    bitListFractionMul_correct _ _ encodedFractionThree_positive hnj,
    encodedFractionFour_value, encodedFractionThree_value,
    show bitListFractionValue total = bitListFractionValue nk+bitListFractionValue product from
      bitListFractionAdd_correct nk product hnk hpr,
    show bitListFractionValue product = bitListFractionValue square*bitListFractionValue nj from
      bitListFractionMul_correct square nj hsq hnj,
    show bitListFractionValue square = bitListFractionValue mu*bitListFractionValue mu from
      bitListFractionMul_correct mu mu hmu hmu]
  simp only [nk, nj, mu, encodedRationalDot_value _ _ (hT k) (hT k),
    encodedRationalDot_value _ _ (hT j) (hT j), encodedGsCoefficient_value A T hA hT,
    decide_eq_true_eq, pow_two]
  rfl

def encodedFailingAdjacentPairs (D : BitIntegerMatrixData r d) : Finset (Fin r × Fin r) :=
  let Q := encodedRationalIntegerRows D
  let T := encodedGSTable Q r le_rfl
  let tests : Vector (Vector Bool r) r := Vector.ofFn fun j => Vector.ofFn fun k =>
    if k.val = j.val+1 then encodedLovaszPair Q T j k else false
  Finset.univ.filter fun p => (tests.get p.1).get p.2

theorem encodedFailingAdjacentPairs_value (D : BitIntegerMatrixData r d) :
    encodedFailingAdjacentPairs D = cachedFailingAdjacentPairs (bitIntegerMatrixValue D) := by
  have hD := encodedRationalIntegerRows_positive D
  have hT := encodedGSTable_positive _ hD r le_rfl
  have hrows (i : Fin r) : encodedFractionRows (encodedGSTable (encodedRationalIntegerRows D) r le_rfl) i =
      ((cachedGSTable (rationalIntegerRows (bitIntegerMatrixValue D)) r le_rfl).get i).get := by
    have he := congrArg (fun X : RationalGSTable r d => (X.get i).get)
      (encodedGSTable_value _ hD r le_rfl)
    simpa only [encodedFractionTableValue, get_ofFn, get_ofFn_fun, encodedRationalIntegerRows_value] using he
  ext p
  simp only [encodedFailingAdjacentPairs, cachedFailingAdjacentPairs, Finset.mem_filter,
    Finset.mem_univ, true_and, get_ofFn]
  by_cases h : p.2.val = p.1.val+1
  · simp only [h, ↓reduceIte, encodedLovaszPair_value _ _ hD hT,
      encodedGSTable_value _ hD, encodedRationalIntegerRows_value, hrows,
      decide_eq_true_eq, true_and]
  · simp only [h, ↓reduceIte, Bool.false_eq_true, false_and]

/-- A row permutation copies only row references, retaining encoded cells. -/
def encodedSwapRows (D : BitIntegerMatrixData r d) (j k : Fin r) : BitIntegerMatrixData r d :=
  Vector.ofFn fun i => D.get (Equiv.swap j k i)

theorem encodedSwapRows_value (D : BitIntegerMatrixData r d) (j k : Fin r) :
    bitIntegerMatrixValue (encodedSwapRows D j k) = swapRows (bitIntegerMatrixValue D) j k := by
  funext i l
  simp only [bitIntegerMatrixValue, encodedSwapRows, get_ofFn, swapRows, Function.comp_apply]

structure EncodedLatticeResult (r d : ℕ) where
  rows : BitIntegerMatrixData r d
  swaps : ℕ
  deriving Repr

/-- The answer loop consumes one fuel-list constructor per pass. All scalar
work stays encoded; indices, finite tests and swap counters are administrative. -/
def encodedReductionFuel : List Bool → BitIntegerMatrixData r d → EncodedLatticeResult r d
  | [], D => ⟨D,0⟩
  | _::fuel, D =>
    let C := encodedReduceIntegerAll D r le_rfl
    let tests := encodedFailingAdjacentPairs C
    if h : tests.Nonempty then
      let p := leastPairInFinset tests h
      let W := encodedSwapRows C p.1 p.2
      let tail := encodedReductionFuel fuel W
      ⟨tail.rows,tail.swaps+1⟩
    else ⟨C,0⟩

theorem encodedReductionFuel_value (fuel : List Bool) (D : BitIntegerMatrixData r d) :
    (bitIntegerMatrixValue (encodedReductionFuel fuel D).rows,
      (encodedReductionFuel fuel D).swaps) =
      cachedReductionFuel fuel.length (bitIntegerMatrixValue D) := by
  induction fuel generalizing D with
  | nil => rfl
  | cons b fuel ih =>
    rw [encodedReductionFuel, List.length_cons, cachedReductionFuel]
    simp only [encodedFailingAdjacentPairs_value, encodedReduceIntegerAll_value]
    split_ifs with h
    · simp only [EncodedLatticeResult.rows, EncodedLatticeResult.swaps, leastPairInFinset_cached,
        cacheIntegerMatrix_eq]
      have he := ih (encodedSwapRows (encodedReduceIntegerAll D r le_rfl)
        (cachedLeastFailingAdjacentPair _ h).1 (cachedLeastFailingAdjacentPair _ h).2)
      rw [encodedSwapRows_value, encodedReduceIntegerAll_value] at he
      exact congrArg (fun out : Matrix (Fin r) (Fin d) ℤ × ℕ => (out.1,out.2+1)) he
    · simp only [EncodedLatticeResult.rows, EncodedLatticeResult.swaps, encodedReduceIntegerAll_value]

/-- Exact output and swap-count agreement with the array-valued certified
reference. No scalar encoder or decoder occurs in the executed loop. -/
theorem encodedReductionFuel_materialized_value (fuel : List Bool) (D : BitIntegerMatrixData r d) :
    (bitIntegerMatrixValue (encodedReductionFuel fuel D).rows,
      (encodedReductionFuel fuel D).swaps) =
      (integerMatrixDataRows (materializedReductionFuel fuel.length
        (materializeIntegerMatrix (bitIntegerMatrixValue D))).1,
       (materializedReductionFuel fuel.length (materializeIntegerMatrix (bitIntegerMatrixValue D))).2) := by
  rw [materializedReductionFuel_eq, integerMatrixDataRows_materialize]
  exact encodedReductionFuel_value fuel D

/-- Canonical magnitude invariant for actual stored integer rows. -/
def EncodedIntegerCanonical (D : BitIntegerMatrixData r d) : Prop :=
  ∀ i j, BitListCanonical ((D.get i).get j).digits

theorem encodedRationalIntegerRows_wellFormed (D : BitIntegerMatrixData r d)
    (hD : EncodedIntegerCanonical D) (i : Fin r) (j : Fin d) :
    (((encodedRationalIntegerRows D).get i).get j).WellFormed := by
  simp only [encodedRationalIntegerRows, get_ofFn, BitListFraction.WellFormed]
  exact ⟨hD i j, by simpa [bitListTrim] using bitListTrim_canonical [true], by decide, Nat.coprime_one_right _⟩

theorem encodedRoundInteger_canonical (q : BitListFraction) :
    BitListCanonical (encodedRoundInteger q).digits := by
  unfold encodedRoundInteger bitListFractionRound bitListFractionFloor
  dsimp only
  split_ifs <;> exact bitListTrim_canonical _

theorem encodedGSCoefficients_wellFormed (A T : BitRationalMatrixData r d)
    (hA : EncodedPositiveDenominators A) (hT : EncodedPositiveDenominators T) (k i : Fin r) :
    ((encodedGSCoefficients A T k).get i).WellFormed := by
  simp only [encodedGSCoefficients, get_ofFn]
  split_ifs
  · exact encodedGsCoefficient_wellFormed A T hA hT k i
  · exact bitListFractionZero_wellFormed

theorem bitListIntegerRowUpdate_canonical (D : BitIntegerMatrixData r d)
    (hD : EncodedIntegerCanonical D) (k j : Fin r) (c : BitListInteger) :
    EncodedIntegerCanonical (bitListIntegerRowUpdate D k j c) := by
  intro i l
  rw [bitListIntegerRowUpdate, get_set _ k]
  split_ifs
  · simp only [get_ofFn]
    exact bitListIntegerRowCell_canonical _ _ _
  · exact hD i l

theorem encodedReduceIntegerRow_canonical (D : BitIntegerMatrixData r d)
    (hD : EncodedIntegerCanonical D) (k : Fin r) (n : ℕ) (h : n ≤ k.val) :
    EncodedIntegerCanonical (encodedReduceIntegerRow D k n h) := by
  induction n generalizing D with
  | zero => simpa only [encodedReduceIntegerRow] using hD
  | succ n ih =>
    rw [encodedReduceIntegerRow]
    exact ih _ (bitListIntegerRowUpdate_canonical D hD _ _ _) (by omega)

theorem encodedReduceIntegerAll_canonical (D : BitIntegerMatrixData r d)
    (hD : EncodedIntegerCanonical D) (n : ℕ) (h : n ≤ r) :
    EncodedIntegerCanonical (encodedReduceIntegerAll D n h) := by
  induction n with
  | zero => simpa only [encodedReduceIntegerAll] using hD
  | succ n ih =>
    rw [encodedReduceIntegerAll]
    exact encodedReduceIntegerRow_canonical _ (ih (by omega)) _ _ _

theorem encodedSwapRows_canonical (D : BitIntegerMatrixData r d)
    (hD : EncodedIntegerCanonical D) (j k : Fin r) :
    EncodedIntegerCanonical (encodedSwapRows D j k) := by
  intro i l
  simp only [encodedSwapRows, get_ofFn]
  exact hD _ l

theorem encodedReductionFuel_canonical (fuel : List Bool) (D : BitIntegerMatrixData r d)
    (hD : EncodedIntegerCanonical D) :
    EncodedIntegerCanonical (encodedReductionFuel fuel D).rows := by
  induction fuel generalizing D with
  | nil => exact hD
  | cons b fuel ih =>
    rw [encodedReductionFuel]
    split_ifs
    · exact ih _ (encodedSwapRows_canonical _ (encodedReduceIntegerAll_canonical D hD _ _) _ _)
    · exact encodedReduceIntegerAll_canonical D hD _ _

end Optss
