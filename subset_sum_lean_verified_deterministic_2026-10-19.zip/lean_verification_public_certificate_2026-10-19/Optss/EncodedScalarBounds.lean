import Optss.CachedPrimitiveOperandBounds
import Optss.ReductionPrimitives

/-!
# Direct scalar charges for stored Boolean representations

Semantic bounds become physical list-length bounds only after proving the
representation invariant. These bridges accept either sign for zero and do
not claim that equivalent representations have identical operation charges.
-/

namespace Optss

/-- A normalized fraction's actual lists have precisely the reduced rational
field widths, even when zero is stored with a negative sign. -/
theorem BitListFraction.value_bit_bound_iff (q : BitListFraction)
    (hq : q.WellFormed) (L : ℕ) :
    RationalBitBound (bitListFractionValue q) L ↔
      q.numerator.length ≤ L ∧ q.denominator.length ≤ L := by
  simpa only [q.toRat_value hq] using q.toRat_bits hq L

/-- Canonical integer magnitude lists have the decoded magnitude's bit width. -/
theorem BitListInteger.value_bits_length (z : BitListInteger)
    (hz : BitListCanonical z.digits) : z.value.natAbs.size = z.digits.length := by
  rw [BitListInteger.value, signedBitsValue_natAbs]
  exact hz.length.symm

/-- Direct Boolean fraction operation bounds derived from the decoded
mathematical operands and proved normalization invariant. -/
theorem encodedFraction_scalar_bounds (p q : BitListFraction)
    (hp : p.WellFormed) (hq : q.WellFormed) (L : ℕ)
    (hpbit : RationalBitBound (bitListFractionValue p) L)
    (hqbit : RationalBitBound (bitListFractionValue q) L) :
    bitListFractionAddCost p q ≤ 65536*(L+1)^3 ∧
    bitListFractionSubCost p q ≤ 65536*(L+1)^3 ∧
    bitListFractionMulCost p q ≤ 65536*(L+1)^3 ∧
    bitListFractionDivCost p q ≤ 65536*(L+1)^3 ∧
    bitListFractionLTCost p q ≤ 65536*(L+1)^3 ∧
    bitListFractionRoundCost p ≤ 65536*(L+1)^3 := by
  have hpl := (p.value_bit_bound_iff hp L).mp hpbit
  have hql := (q.value_bit_bound_iff hq L).mp hqbit
  have hm : 2048*(L+1)^3 ≤ 65536*(L+1)^3 := Nat.mul_le_mul_right _ (by decide)
  have hs : 4096*(L+1)^3 ≤ 65536*(L+1)^3 := Nat.mul_le_mul_right _ (by decide)
  have ht : 256*(L+1)^2 ≤ 65536*(L+1)^3 := Nat.mul_le_mul (by decide)
    (Nat.pow_le_pow_right (by omega : 1 ≤ L+1) (by omega : 2 ≤ 3))
  exact ⟨(bitListFractionAddCost_bound p q hp.2.2.1 hq.2.2.1 L hpl hql).trans hm,
    (bitListFractionSubCost_bound p q hp.2.2.1 hq.2.2.1 L hpl hql).trans hs,
    (bitListFractionMulCost_bound p q hp.2.2.1 hq.2.2.1 L hpl hql).trans hm,
    (bitListFractionDivCost_bound p q hp.2.2.1 L hpl hql).trans hm,
    (bitListFractionLTCost_bound p q L hpl hql).trans ht,
    bitListFractionRoundCost_bound p hp.2.2.1 L hpl⟩

/-- The actual stored integer operands obey the same cubic scalar envelope. -/
theorem encodedInteger_rowCell_bound (u c v : BitListInteger)
    (hu : BitListCanonical u.digits) (hc : BitListCanonical c.digits)
    (hv : BitListCanonical v.digits) (L : ℕ)
    (hubit : u.value.natAbs.size ≤ L) (hcbit : c.value.natAbs.size ≤ L)
    (hvbit : v.value.natAbs.size ≤ L) :
    bitListIntegerRowCellCost u c v ≤ 65536*(L+1)^3 := by
  rw [u.value_bits_length hu] at hubit
  rw [c.value_bits_length hc] at hcbit
  rw [v.value_bits_length hv] at hvbit
  exact (bitListIntegerRowCellCost_bound u c v L hubit hcbit hvbit).trans
    (Nat.mul_le_mul (by decide : 128 ≤ 65536)
      (Nat.pow_le_pow_right (by omega : 1 ≤ L+1) (by omega : 2 ≤ 3)))

/-- Specialization to actual matrix-update operands: no size assumption on
those stored lists is needed beyond canonical representation and decoding. -/
theorem encodedCachedRowCell_bound {r d : ℕ} (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k j : Fin r) (l : Fin d)
    (u c v : BitListInteger)
    (hu : BitListCanonical u.digits) (hc : BitListCanonical c.digits)
    (hv : BitListCanonical v.digits)
    (hue : u.value = A k l)
    (hce : c.value = round (rationalGsCoefficient (rationalIntegerRows A) k j))
    (hve : v.value = A j l) :
    bitListIntegerRowCellCost u c v ≤
      65536*(cachedArithmeticBits r d H (gramPotential A)+1)^3 := by
  apply encodedInteger_rowCell_bound u c v hu hc hv
  · rw [hue]
    exact cached_integer_cell_operand_bits A H hH k l
  · rw [hce]
    exact cached_rounded_coefficient_bits A hA H hH k j
  · rw [hve]
    exact cached_integer_cell_operand_bits A H hH j l

end Optss
