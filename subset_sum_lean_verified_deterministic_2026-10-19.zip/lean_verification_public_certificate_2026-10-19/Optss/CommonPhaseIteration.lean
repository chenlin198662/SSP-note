import Optss.CommonPhaseOutcome
import Optss.HalvingPhaseMachine

/-!
# Terminating common-GAP phases and exact accumulated outliers

The phase alternative is executed until success, using its strictly halved
positive scalar potential. The final decomposition is lifted to all original
labels, including every genuine deletion from previous phases.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1200000

namespace CommonGapDecomposition
variable {ι : Type} [DecidableEq ι] {scalar : ι → ℤ} {initial : Finset ι}
  {h extra R Ebound Rbound : ℕ} {c : ℝ}

def weakenBounds (out : CommonGapDecomposition scalar initial h extra R Ebound Rbound c)
    (E' R' : ℕ) (hE : Ebound ≤ E') (hR : Rbound ≤ R') :
    CommonGapDecomposition scalar initial h extra R E' R' c :=
  { out with outlier_bound := out.outlier_bound.trans hE
             reserve_bound := out.reserve_bound.trans hR }

/-- Restore all earlier discarded labels as outliers, preserving the exact
reserve and remainder and their coordinate witnesses. -/
def extendInitial (out : CommonGapDecomposition scalar initial h extra R Ebound Rbound c)
    (original : Finset ι) (hsub : initial ⊆ original) :
    CommonGapDecomposition scalar original h extra R
      ((original \ initial).card+Ebound) Rbound c :=
  { out with
    available_subset := out.available_subset.trans hsub
    outlier_bound := (HalvingPhaseMachine.deleted_card_chain original initial out.available hsub out.available_subset).trans
      (Nat.add_le_add_left out.outlier_bound _) }

end CommonGapDecomposition

/-- A total phase selector built from proved phase alternatives on actual
subsets of the input. Outside that domain it terminates immediately. -/
def commonGapPhaseMachine {ι : Type} [DecidableEq ι]
    (scalar : ι → ℤ) (initial : Finset ι) (h extra R Ebound Rbound : ℕ) (c : ℝ)
    (phase : ∀ s ⊆ initial,
      (∃ next ⊆ s, 2*(h • insert 0 (next.image scalar)).card <
        (h • insert 0 (s.image scalar)).card ∧ (s \ next).card ≤ Ebound) ∨
      Nonempty (CommonGapDecomposition scalar s h extra R Ebound Rbound c)) :
    HalvingPhaseMachine ι (fun s => (h • insert 0 (s.image scalar)).card)
      (fun s => s ⊆ initial → Nonempty (CommonGapDecomposition scalar s h extra R Ebound Rbound c)) Ebound := by
  let step : Finset ι → Option (Finset ι) := fun s =>
    if hs : s ⊆ initial then
      if hf : ∃ next ⊆ s, 2*(h • insert 0 (next.image scalar)).card <
          (h • insert 0 (s.image scalar)).card ∧ (s \ next).card ≤ Ebound then
        some (Classical.choose hf)
      else none
    else none
  refine { step := step
           positive := ?_
           done := ?_
           next_subset := ?_
           decreases := ?_
           deletes := ?_ }
  · intro s
    exact Finset.card_pos.mpr ⟨0, Finset.zero_mem_nsmul (Finset.mem_insert_self _ _)⟩
  · intro s hdone hs
    have hf : ¬∃ next ⊆ s, 2*(h • insert 0 (next.image scalar)).card <
        (h • insert 0 (s.image scalar)).card ∧ (s \ next).card ≤ Ebound := by
      intro hf
      simp only [step, dif_pos hs, dif_pos hf, Option.some_ne_none] at hdone
    exact (phase s hs).resolve_left hf
  · intro s t he
    dsimp only [step] at he
    split_ifs at he with hs hf
    · have ht : Classical.choose hf = t := Option.some.inj he
      exact ht ▸ (Classical.choose_spec hf).1
  · intro s t he
    dsimp only [step] at he
    split_ifs at he with hs hf
    · have ht : Classical.choose hf = t := Option.some.inj he
      exact ht ▸ (Classical.choose_spec hf).2.1
  · intro s t he
    dsimp only [step] at he
    split_ifs at he with hs hf
    · have ht : Classical.choose hf = t := Option.some.inj he
      exact ht ▸ (Classical.choose_spec hf).2.2

/-- The verified finite execution returns the common decomposition; the total
outlier bound includes both all failed phases and the final successful phase. -/
theorem common_gap_iterated_decomposition {ι : Type} [DecidableEq ι]
    (scalar : ι → ℤ) (initial : Finset ι) (h extra R Ebound Rbound : ℕ) (c : ℝ)
    (phase : ∀ s ⊆ initial,
      (∃ next ⊆ s, 2*(h • insert 0 (next.image scalar)).card <
        (h • insert 0 (s.image scalar)).card ∧ (s \ next).card ≤ Ebound) ∨
      Nonempty (CommonGapDecomposition scalar s h extra R Ebound Rbound c)) :
    let machine := commonGapPhaseMachine scalar initial h extra R Ebound Rbound c phase
    let out := machine.finish initial
    out.1 ⊆ initial ∧ out.2 ≤ Nat.log 2 ((h • insert 0 (initial.image scalar)).card)+1 ∧
      Nonempty (CommonGapDecomposition scalar initial h extra R
        ((Nat.log 2 ((h • insert 0 (initial.image scalar)).card)+2)*Ebound) Rbound c) := by
  dsimp only
  let machine := commonGapPhaseMachine scalar initial h extra R Ebound Rbound c phase
  obtain ⟨hsub, hgood, hdeleted, hcalls⟩ := machine.finish_spec initial
  obtain ⟨out⟩ := hgood hsub
  refine ⟨hsub, hcalls, ⟨(out.extendInitial initial hsub).weakenBounds _ Rbound ?_ le_rfl⟩⟩
  exact (Nat.add_le_add_right hdeleted Ebound).trans_eq (by ring)

end
end Optss
