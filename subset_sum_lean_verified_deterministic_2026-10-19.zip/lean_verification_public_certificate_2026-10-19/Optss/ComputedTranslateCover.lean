import Optss.FreimanProgressionCovering

/-!
# Executable greedy selection of disjoint translates

The input list is scanned once. A candidate is accepted precisely when its
translate conflicts with no previously accepted translate. The conflict
predicate is a Boolean lookup; a later stored-table adapter implements it.
-/
namespace Optss
open scoped Pointwise

def greedyTranslateList (conflict : ℤ→Bool) : List ℤ→List ℤ
  | [] => []
  | x::xs =>
    let picked := greedyTranslateList conflict xs
    if picked.any (fun y => conflict (x-y)) then picked else x::picked

theorem greedyTranslateList_subset (conflict : ℤ→Bool) (xs : List ℤ) :
    ∀ x∈greedyTranslateList conflict xs, x∈xs := by
  induction xs with
  | nil => simp [greedyTranslateList]
  | cons x xs ih =>
    simp only [greedyTranslateList]
    split
    · intro y hy; exact List.mem_cons_of_mem x (ih y hy)
    · intro y hy
      rcases List.mem_cons.mp hy with rfl | hy
      · simp
      · exact List.mem_cons_of_mem x (ih y hy)

theorem greedyTranslateList_nodup (conflict : ℤ→Bool) (hzero : conflict 0=true) (xs : List ℤ) :
    (greedyTranslateList conflict xs).Nodup := by
  induction xs with
  | nil => simp [greedyTranslateList]
  | cons x xs ih =>
    simp only [greedyTranslateList]
    split
    · exact ih
    · rename_i h
      apply List.nodup_cons.mpr
      refine ⟨?_,ih⟩
      intro hx
      apply h
      exact List.any_eq_true.mpr ⟨x,hx,by simpa only [sub_self] using hzero⟩

theorem greedyTranslateList_separated (conflict : ℤ→Bool)
    (hsym : ∀ z, conflict (-z)=conflict z) (xs : List ℤ) :
    ∀ x∈greedyTranslateList conflict xs, ∀ y∈greedyTranslateList conflict xs,
      x≠y → conflict (x-y)=false := by
  induction xs with
  | nil => simp [greedyTranslateList]
  | cons a xs ih =>
    simp only [greedyTranslateList]
    split
    · exact ih
    · rename_i h
      have hnone : ∀ y∈greedyTranslateList conflict xs, conflict (a-y)=false := by
        intro y hy
        apply Bool.eq_false_iff.mpr
        intro hh
        exact h (List.any_eq_true.mpr ⟨y,hy,hh⟩)
      intro x hx y hy hxy
      by_cases hxa : x=a
      · subst x
        exact hnone y ((List.mem_cons.mp hy).resolve_left (Ne.symm hxy))
      · by_cases hya : y=a
        · subst y
          have hh := hnone x ((List.mem_cons.mp hx).resolve_left hxa)
          exact (hsym (x-a)).symm.trans (by simpa only [neg_sub] using hh)
        · exact ih x ((List.mem_cons.mp hx).resolve_left hxa)
            y ((List.mem_cons.mp hy).resolve_left hya) hxy

theorem difference_conflict_symm (P : Finset ℤ) (conflict : ℤ→Bool)
    (hc : ∀ z, conflict z=true ↔ z∈P-P) : ∀ z, conflict (-z)=conflict z := by
  intro z
  apply Bool.eq_iff_iff.mpr
  rw [hc,hc]
  constructor <;> intro hz
  · obtain ⟨a,ha,b,hb,he⟩ := Finset.mem_sub.mp hz
    exact Finset.mem_sub.mpr ⟨b,hb,a,ha,by omega⟩
  · obtain ⟨a,ha,b,hb,he⟩ := Finset.mem_sub.mp hz
    exact Finset.mem_sub.mpr ⟨b,hb,a,ha,by omega⟩

theorem greedyTranslateList_covers (P : Finset ℤ) (hP : P.Nonempty) (conflict : ℤ→Bool)
    (hc : ∀ z, conflict z=true ↔ z∈P-P) (xs : List ℤ) :
    xs.toFinset⊆(greedyTranslateList conflict xs).toFinset+(P-P) := by
  have hz : (0:ℤ)∈P-P := by
    obtain ⟨a,ha⟩ := hP
    exact Finset.mem_sub.mpr ⟨a,ha,a,ha,sub_self _⟩
  induction xs with
  | nil => simp
  | cons x xs ih =>
    intro y hy
    have hy' := List.mem_toFinset.mp hy
    simp only [greedyTranslateList]
    split
    · rename_i h
      rcases List.mem_cons.mp hy' with rfl | hy
      · obtain ⟨a,ha,hax⟩ := List.any_eq_true.mp h
        exact Finset.mem_add.mpr ⟨a,List.mem_toFinset.mpr ha,y-a,(hc _).mp hax,by omega⟩
      · exact ih (List.mem_toFinset.mpr hy)
    · rcases List.mem_cons.mp hy' with rfl | hy
      · exact Finset.mem_add.mpr ⟨y,List.mem_toFinset.mpr (by simp),0,hz,by omega⟩
      · exact (Finset.add_subset_add
          (by intro z hz'; exact List.mem_toFinset.mpr (List.mem_cons_of_mem x (List.mem_toFinset.mp hz')))
          (by exact Finset.Subset.refl _)) (ih (List.mem_toFinset.mpr hy))

theorem greedyTranslateList_packing (P : Finset ℤ) (hP : P.Nonempty) (conflict : ℤ→Bool)
    (hc : ∀ z, conflict z=true ↔ z∈P-P) (xs : List ℤ) :
    (greedyTranslateList conflict xs).length*P.card≤(xs.toFinset+P).card := by
  have hz : conflict 0=true := (hc _).mpr (by
    obtain ⟨a,ha⟩ := hP
    exact Finset.mem_sub.mpr ⟨a,ha,a,ha,sub_self _⟩)
  have hnd := greedyTranslateList_nodup conflict hz xs
  have hsep := greedyTranslateList_separated conflict (difference_conflict_symm P conflict hc) xs
  have hcard := Finset.card_le_card_of_injOn (s:=(greedyTranslateList conflict xs).toFinset×ˢP)
    (t:=xs.toFinset+P) (fun (ab : ℤ×ℤ) => ab.1+ab.2) (by
      intro ab hab
      obtain ⟨ha,hb⟩ := Finset.mem_product.mp hab
      exact Finset.mem_add.mpr ⟨ab.1,List.mem_toFinset.mpr
        (greedyTranslateList_subset conflict xs ab.1 (List.mem_toFinset.mp ha)),ab.2,hb,rfl⟩) (by
      intro ab hab cd hcd he
      obtain ⟨ha,hb⟩ := Finset.mem_product.mp hab
      obtain ⟨hc',hd⟩ := Finset.mem_product.mp hcd
      have hfirst : ab.1=cd.1 := by
        by_contra hne
        have hfalse := hsep ab.1 (List.mem_toFinset.mp ha) cd.1 (List.mem_toFinset.mp hc') hne
        have htrue := (hc (ab.1-cd.1)).mpr
          (Finset.mem_sub.mpr ⟨cd.2,hd,ab.2,hb,by dsimp at he; omega⟩)
        rw [hfalse] at htrue
        contradiction
      apply Prod.ext hfirst
      dsimp at he
      omega)
  simpa only [Finset.card_product,List.toFinset_card_of_nodup hnd] using hcard

end Optss
