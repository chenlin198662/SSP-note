import Optss.CachedContainerWork

/-!
# Explicit Boolean-address storage control

The routines below use Boolean addresses and linear scans of stored words.
They require no native natural-number indexing, arithmetic, comparison or
random-access primitive in their executed answer paths. A read copies only the
selected word; a persistent write shares all unchanged word payloads.

Costs count ripple gates, list visits and copied word bits. This supplies a
conservative concrete implementation for storage controls; connecting a full
heap-layout trace of the cached evaluator remains a separate refinement.
-/

namespace Optss

/-- Explicit copying of one pointer/data word. -/
def bitWordCopy : List Bool → List Bool
  | [] => []
  | b::bs => b::bitWordCopy bs

theorem bitWordCopy_eq (bs : List Bool) : bitWordCopy bs = bs := by
  induction bs <;> simp_all [bitWordCopy]

def bitWordCopyWork : List Bool → ℕ
  | [] => 1
  | _::bs => bitWordCopyWork bs+2

theorem bitWordCopyWork_eq (bs : List Bool) : bitWordCopyWork bs = 2*bs.length+1 := by
  induction bs <;> simp_all [bitWordCopyWork]
  omega

theorem bitAddressZero_iff (address : List Bool) :
    (bitListTrim address).isEmpty = true ↔ binaryDigitsValue address = 0 := by
  constructor
  · intro h
    have he := congrArg binaryDigitsValue (List.isEmpty_iff.mp h)
    simpa only [bitListTrim_value, binaryDigitsValue] using he
  · intro h
    rw [List.isEmpty_iff, bitListTrim_eq_bits, h]
    simp

/-- Predecessor is the already verified ripple subtraction of one. -/
def bitAddressPred (address : List Bool) : List Bool := bitListSub address [true]

theorem bitAddressPred_value (address : List Bool) :
    binaryDigitsValue (bitAddressPred address) = binaryDigitsValue address-1 := by
  rw [bitAddressPred, bitListSub_correct]
  rfl

theorem bitAddressPred_length (address : List Bool) (L : ℕ)
    (hL : 1 ≤ L) (ha : address.length ≤ L) : (bitAddressPred address).length ≤ L := by
  exact (bitListSub_length_le address [true]).trans (max_le ha (by simpa))

def bitAddressRead : List Bool → List (List Bool) → Option (List Bool)
  | _, [] => none
  | address, word::words =>
    if (bitListTrim address).isEmpty then some (bitWordCopy word)
    else bitAddressRead (bitAddressPred address) words

/-- Exact indexed read, including out-of-range addresses. -/
theorem bitAddressRead_correct (address : List Bool) (words : List (List Bool)) :
    bitAddressRead address words = words[binaryDigitsValue address]? := by
  induction words generalizing address with
  | nil => simp [bitAddressRead]
  | cons word words ih =>
    simp only [bitAddressRead, List.getElem?_cons, bitAddressZero_iff, bitWordCopy_eq]
    split_ifs
    · rfl
    · rw [ih, bitAddressPred_value]

def bitAddressWrite : List Bool → List Bool → List (List Bool) → List (List Bool)
  | _, _, [] => []
  | address, replacement, word::words =>
    if (bitListTrim address).isEmpty then bitWordCopy replacement::words
    else word::bitAddressWrite (bitAddressPred address) replacement words

/-- Persistent write copies the outer spine, sharing unchanged word payloads. -/
theorem bitAddressWrite_correct (address replacement : List Bool) (words : List (List Bool)) :
    bitAddressWrite address replacement words = words.set (binaryDigitsValue address) replacement := by
  induction words generalizing address with
  | nil => simp [bitAddressWrite]
  | cons word words ih =>
    simp only [bitAddressWrite, bitAddressZero_iff, bitWordCopy_eq]
    split_ifs with h
    · rw [h, List.set_cons_zero]
    · have ha : binaryDigitsValue address = (binaryDigitsValue address-1)+1 := by omega
      rw [ih, bitAddressPred_value, ha, List.set_cons_succ]
      congr 2

theorem bitAddressWrite_length (address replacement : List Bool) (words : List (List Bool)) :
    (bitAddressWrite address replacement words).length = words.length := by
  rw [bitAddressWrite_correct, List.length_set]

def bitAddressPredWork (address : List Bool) : ℕ :=
  bitListRippleGates 8 address [true]+bitListSubVisits address [true]+1

theorem bitAddressPredWork_le (address : List Bool) (L : ℕ)
    (hL : 1 ≤ L) (ha : address.length ≤ L) : bitAddressPredWork address ≤ 9*L+2 := by
  unfold bitAddressPredWork
  rw [bitListRippleGates_eq, bitListSubVisits_eq]
  have hm : max address.length [true].length ≤ L := max_le ha (by simpa)
  omega

/-- The interpretation charges the exact trim and predecessor calls made by
`bitAddressRead`, plus explicit selected-word copying. -/
def bitAddressReadWork : List Bool → List (List Bool) → ℕ
  | _, [] => 1
  | address, word::words =>
    bitListTrimVisits address+word.length+2+
      if (bitListTrim address).isEmpty then bitWordCopyWork word
      else bitAddressPredWork address+bitAddressReadWork (bitAddressPred address) words

theorem bitAddressReadWork_le (address : List Bool) (words : List (List Bool))
    (L W : ℕ) (hL : 1 ≤ L) (ha : address.length ≤ L)
    (hw : ∀ word ∈ words, word.length ≤ W) :
    bitAddressReadWork address words ≤ words.length*(16*(L+W+1))+2*W+1 := by
  induction words generalizing address with
  | nil => simp [bitAddressReadWork]
  | cons word words ih =>
    have hword := hw word (List.mem_cons_self)
    have ht := ih (bitAddressPred address) (bitAddressPred_length address L hL ha)
      (fun w h => hw w (List.mem_cons_of_mem _ h))
    have hp := bitAddressPredWork_le address L hL ha
    rw [bitAddressReadWork]
    simp only [List.length_cons, bitListTrimVisits_eq]
    split_ifs
    · rw [bitWordCopyWork_eq]
      nlinarith
    · nlinarith

def bitAddressWriteWork : List Bool → List Bool → List (List Bool) → ℕ
  | _, _, [] => 1
  | address, replacement, word::words =>
    bitListTrimVisits address+word.length+3+
      if (bitListTrim address).isEmpty then bitWordCopyWork replacement
      else bitAddressPredWork address+bitAddressWriteWork (bitAddressPred address) replacement words

theorem bitAddressWriteWork_le (address replacement : List Bool) (words : List (List Bool))
    (L W : ℕ) (hL : 1 ≤ L) (ha : address.length ≤ L) (hw : replacement.length ≤ W)
    (hwords : ∀ word ∈ words, word.length ≤ W) :
    bitAddressWriteWork address replacement words ≤ words.length*(16*(L+W+1))+2*W+1 := by
  induction words generalizing address with
  | nil => simp [bitAddressWriteWork]
  | cons word words ih =>
    have hword := hwords word (List.mem_cons_self)
    have ht := ih (bitAddressPred address) (bitAddressPred_length address L hL ha)
      (fun w h => hwords w (List.mem_cons_of_mem _ h))
    have hp := bitAddressPredWork_le address L hL ha
    rw [bitAddressWriteWork]
    simp only [List.length_cons, bitListTrimVisits_eq]
    split_ifs
    · rw [bitWordCopyWork_eq]
      nlinarith
    · nlinarith
/-- Sequential word store with an explicit Boolean allocation counter. -/
structure BitWordMemory where
  next : List Bool
  words : List (List Bool)
  deriving Repr

def BitWordMemory.WellFormed (memory : BitWordMemory) : Prop :=
  BitListCanonical memory.next ∧ binaryDigitsValue memory.next = memory.words.length

/-- Allocation returns the old Boolean address and increments it using the
verified Boolean ripple adder. Existing word payloads remain shared. -/
def bitWordAllocate (memory : BitWordMemory) (word : List Bool) : List Bool × BitWordMemory :=
  (memory.next,⟨bitListAdd memory.next [true],memory.words++[bitWordCopy word]⟩)

theorem bitWordAllocate_wellFormed (memory : BitWordMemory) (hm : memory.WellFormed)
    (word : List Bool) : (bitWordAllocate memory word).2.WellFormed := by
  refine ⟨bitListTrim_canonical _, ?_⟩
  change binaryDigitsValue (bitListAdd memory.next [true]) =
    (memory.words++[bitWordCopy word]).length
  rw [bitListAdd_correct, hm.2, List.length_append]
  rfl

theorem bitWordAllocate_address (memory : BitWordMemory) (hm : memory.WellFormed)
    (word : List Bool) : binaryDigitsValue (bitWordAllocate memory word).1 = memory.words.length := hm.2

theorem bitWordAllocate_read (memory : BitWordMemory) (hm : memory.WellFormed)
    (word : List Bool) :
    bitAddressRead (bitWordAllocate memory word).1 (bitWordAllocate memory word).2.words = some word := by
  rw [bitAddressRead_correct, bitWordAllocate_address memory hm]
  simp [bitWordAllocate, bitWordCopy_eq]

/-- Allocation of an actual list of words, retaining every returned address. -/
def bitWordAllocateMany (memory : BitWordMemory) : List (List Bool) → List (List Bool) × BitWordMemory
  | [] => ([],memory)
  | word::words =>
    let first := bitWordAllocate memory word
    let rest := bitWordAllocateMany first.2 words
    (first.1::rest.1,rest.2)

theorem bitWordAllocateMany_length (memory : BitWordMemory) (words : List (List Bool)) :
    (bitWordAllocateMany memory words).2.words.length = memory.words.length+words.length := by
  induction words generalizing memory with
  | nil => simp [bitWordAllocateMany]
  | cons word words ih =>
    rw [bitWordAllocateMany]
    simp only [ih, bitWordAllocate, List.length_append, List.length_cons, List.length_nil]
    omega

theorem bitWordAllocateMany_wellFormed (memory : BitWordMemory) (hm : memory.WellFormed)
    (words : List (List Bool)) : (bitWordAllocateMany memory words).2.WellFormed := by
  induction words generalizing memory with
  | nil => exact hm
  | cons word words ih => exact ih _ (bitWordAllocate_wellFormed memory hm word)

/-- No future-state premise is needed: every actual allocated address is
bounded by the initial store size plus the number of allocation requests. -/
theorem bitWordAllocateMany_address_bound (memory : BitWordMemory) (hm : memory.WellFormed)
    (words : List (List Bool)) (address : List Bool)
    (ha : address ∈ (bitWordAllocateMany memory words).1) :
    BitListCanonical address ∧ binaryDigitsValue address < memory.words.length+words.length := by
  induction words generalizing memory with
  | nil => simp [bitWordAllocateMany] at ha
  | cons word words ih =>
    rw [bitWordAllocateMany] at ha
    rcases List.mem_cons.mp ha with he | ht
    · subst address
      refine ⟨hm.1, ?_⟩
      change binaryDigitsValue memory.next < _
      rw [hm.2, List.length_cons]
      omega
    · obtain ⟨hcan,hbound⟩ := ih (bitWordAllocate memory word).2
        (bitWordAllocate_wellFormed memory hm word) ht
      refine ⟨hcan, ?_⟩
      simp only [bitWordAllocate, List.length_append, List.length_cons, List.length_nil] at hbound ⊢
      omega

/-- Stored address widths depend logarithmically on actual allocated slots. -/
theorem bitWordAllocateMany_address_bits (memory : BitWordMemory) (hm : memory.WellFormed)
    (words : List (List Bool)) (address : List Bool)
    (ha : address ∈ (bitWordAllocateMany memory words).1) :
    address.length ≤ (memory.words.length+words.length).size := by
  obtain ⟨hcan,hbound⟩ := bitWordAllocateMany_address_bound memory hm words address ha
  rw [hcan.length]
  exact Nat.size_le_size hbound.le

/-- One uniform storage-access envelope, expressed in address and payload
widths, covers both actual reads and actual persistent writes. -/
theorem bitAddress_controls_uniform (address replacement : List Bool) (words : List (List Bool))
    (S L : ℕ) (hS : words.length ≤ S) (hL : 1 ≤ L)
    (ha : address.length ≤ L) (hr : replacement.length ≤ L)
    (hw : ∀ word ∈ words, word.length ≤ L) :
    bitAddressReadWork address words ≤ 64*(S+1)*(L+1) ∧
      bitAddressWriteWork address replacement words ≤ 64*(S+1)*(L+1) := by
  have hread := bitAddressReadWork_le address words L L hL ha hw
  have hwrite := bitAddressWriteWork_le address replacement words L L hL ha hr hw
  have hb : words.length*(16*(L+L+1))+2*L+1 ≤ 64*(S+1)*(L+1) := by
    have h := Nat.mul_le_mul_right (16*(L+L+1)) hS
    nlinarith
  exact ⟨hread.trans hb,hwrite.trans hb⟩

end Optss
