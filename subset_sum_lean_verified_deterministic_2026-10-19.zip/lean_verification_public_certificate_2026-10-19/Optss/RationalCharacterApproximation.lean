import Optss.RationalExponentialApproximation

/-! Actual rational cyclic-character approximations with an explicit binary
precision parameter. Only rational arithmetic and bounded natural indices
occur in the answer construction. -/
namespace Optss
open scoped BigOperators
variable {N : ℕ} [NeZero N]

def rationalPhaseAngle (x : ZMod N) (p : ℕ) : ℚ :=
  2*rationalPiApproximation (p+2)*x.val/N

def rationalCharacterApproximation (x : ZMod N) (p : ℕ) : ℚ×ℚ :=
  rationalImaginaryExpPartial (rationalPhaseAngle x p) (68+p)

theorem rationalPhaseAngle_bounds (x : ZMod N) (p : ℕ) :
    0≤rationalPhaseAngle x p ∧ rationalPhaseAngle x p≤8 := by
  have hpi := rationalPiApproximation_bounds (p+2)
  have hN : (0 : ℚ)<N := Nat.cast_pos.mpr (NeZero.pos N)
  have hx : (x.val : ℚ)≤N := by exact_mod_cast x.val_lt.le
  unfold rationalPhaseAngle
  constructor
  · exact div_nonneg (mul_nonneg (mul_nonneg (by norm_num) hpi.1) (by positivity)) hN.le
  · apply (div_le_iff₀ hN).mpr
    have hm := mul_le_mul_of_nonneg_right hpi.2 (show (0 : ℚ)≤x.val by positivity)
    linarith

theorem imaginaryExp_distance (s t : ℝ) (h : |s-t|<1) :
    ‖Complex.exp ((s : ℂ)*Complex.I)-Complex.exp ((t : ℂ)*Complex.I)‖≤2*|s-t| := by
  have hd : ‖(s : ℂ)*Complex.I-(t : ℂ)*Complex.I‖=|s-t| := by
    rw [← sub_mul,← Complex.ofReal_sub,norm_mul,Complex.norm_I,mul_one,Complex.norm_real,Real.norm_eq_abs]
  have he : ‖Complex.exp ((t : ℂ)*Complex.I)‖=1 := by
    simp [Complex.norm_exp]
  simpa only [hd,he,show (1 : ℝ)+1=2 by norm_num,mul_one] using
    Complex.locally_lipschitz_exp (r := 1) (by norm_num) le_rfl
      ((t : ℂ)*Complex.I) ((s : ℂ)*Complex.I) (by rwa [hd])

theorem rationalPhaseAngle_error (x : ZMod N) (p : ℕ) :
    |2*Real.pi*x.val/N-(rationalPhaseAngle x p : ℝ)|≤2*(1/2 : ℝ)^(p+4) := by
  have hN : (0 : ℝ)<N := Nat.cast_pos.mpr (NeZero.pos N)
  have hx : (x.val : ℝ)≤N := by exact_mod_cast x.val_lt.le
  have hfactor : (2 : ℝ)*x.val/N≤2 := (div_le_iff₀ hN).mpr (by linarith)
  have he : 2*Real.pi*x.val/N-(rationalPhaseAngle x p : ℝ)=
      (2*x.val/N)*(Real.pi-(rationalPiApproximation (p+2) : ℝ)) := by
    unfold rationalPhaseAngle
    push_cast
    ring
  rw [he,abs_mul,abs_of_nonneg (by positivity : (0 : ℝ)≤2*x.val/N)]
  exact (mul_le_mul_of_nonneg_right hfactor (abs_nonneg _)).trans
    (mul_le_mul_of_nonneg_left (rationalPiApproximation_precision p) (by norm_num))

/-- 68+p rational Taylor terms and 4(p+2) rational arctangent terms produce
a certified absolute character error at most 2^(-p). -/
theorem rationalCharacterApproximation_error (x : ZMod N) (p : ℕ) :
    ‖rationalComplexValue (rationalCharacterApproximation x p)-ZMod.stdAddChar x‖≤(1/2 : ℝ)^p := by
  let θ : ℝ := 2*Real.pi*x.val/N
  let t : ℚ := rationalPhaseAngle x p
  have he : ZMod.stdAddChar x=Complex.exp ((θ : ℂ)*Complex.I) := by
    have h := ZMod.stdAddChar_coe (N := N) (x.val : ℤ)
    simp only [Int.cast_natCast,ZMod.natCast_zmod_val] at h
    rw [h]
    congr 1
    dsimp [θ]
    push_cast
    ring
  have hphase : |θ-(t : ℝ)|≤2*(1/2 : ℝ)^(p+4) := rationalPhaseAngle_error x p
  have hp : (1/2 : ℝ)^p≤1 := pow_le_one₀ (by norm_num) (by norm_num)
  have hclose : |(t : ℝ)-θ|<1 := by
    rw [abs_sub_comm]
    rw [pow_add] at hphase
    norm_num at hphase
    linarith
  have hExp := imaginaryExp_distance (t : ℝ) θ hclose
  rw [abs_sub_comm] at hExp
  have hTaylor := rationalImaginaryExpPartial_precision t
    (by rw [abs_of_nonneg (rationalPhaseAngle_bounds x p).1]; exact (rationalPhaseAngle_bounds x p).2) (p+2)
  have hn : 66+(p+2)=68+p := by omega
  rw [hn,norm_sub_rev] at hTaylor
  have htri := norm_sub_le_norm_sub_add_norm_sub
    (rationalComplexValue (rationalCharacterApproximation x p))
    (Complex.exp ((t : ℂ)*Complex.I)) (Complex.exp ((θ : ℂ)*Complex.I))
  rw [he]
  have htcast : ((t : ℝ) : ℂ)=(t : ℂ) := by simp
  rw [htcast] at hExp
  change ‖rationalComplexValue (rationalCharacterApproximation x p)-
      Complex.exp ((t : ℂ)*Complex.I)‖≤_ at hTaylor
  rw [pow_add] at hTaylor hphase
  norm_num at hTaylor hphase
  have hpow : (0 : ℝ)≤(1/2)^p := by positivity
  nlinarith

end Optss
