import Optss.ExplicitPhaseLattice
import Optss.ComputedBasisWidths

/-!
# Rational and real basis certificates for the explicit phase columns

The triangular map has a closed-form inverse over every characteristic-zero
field. Its actual integer columns are therefore a rational nonsingular matrix
and a real basis of the entire phase lattice.
-/
namespace Optss
variable {N r : ℕ} [NeZero N]

def phaseScalarEquiv (K : Type) [Field K] [CharZero K]
    (a : Fin r→ZMod N) (base : Fin r) : (Fin r→K)≃ₗ[K](Fin r→K) where
  toFun z i := if i=base then z base else z base*(a i).val+(N:K)*z i
  invFun z i := if i=base then z base else (z i-z base*(a i).val)/(N:K)
  left_inv z := by
    have hN : (N:K)≠0 := Nat.cast_ne_zero.mpr (NeZero.ne N)
    ext i
    by_cases hi : i=base <;> simp [hi,hN]
  right_inv z := by
    have hN : (N:K)≠0 := Nat.cast_ne_zero.mpr (NeZero.ne N)
    ext i
    by_cases hi : i=base <;> simp [hi,hN]
    field_simp
  map_add' x y := by ext i; by_cases hi : i=base <;> simp [hi] <;> ring
  map_smul' c x := by ext i; by_cases hi : i=base <;> simp [hi] <;> ring

noncomputable def phaseScalarBasis (K : Type) [Field K] [CharZero K]
    (a : Fin r→ZMod N) (base : Fin r) : Basis (Fin r) K (Fin r→K) :=
  (Pi.basisFun K (Fin r)).map (phaseScalarEquiv K a base)

theorem phaseScalarBasis_columns (K : Type) [Field K] [CharZero K]
    (a : Fin r→ZMod N) (base i j : Fin r) :
    phaseScalarBasis K a base j i=(phaseIntegerColumns a base j i:K) := by
  rw [phaseIntegerColumns_formula]
  by_cases hj : j=base <;> by_cases hi : i=base <;> by_cases hij : i=j <;>
    simp_all [phaseScalarBasis,Basis.map_apply,phaseScalarEquiv,Pi.single_apply]

theorem phaseScalarBasis_integer_lattice (a : Fin r→ZMod N) (base : Fin r) (ha : a base=1) :
    basisIntegerLattice (phaseScalarBasis ℝ a base)=
      realVector '' (cyclicPhaseLattice a base : Set (IntVec r)) := by
  rw [basisIntegerLattice_eq_integerSpan,←integerSubgroupRealLattice_coe]
  unfold integerSubgroupRealLattice
  rw [←phaseIntegerColumns_span a base ha,Submodule.map_span,←Set.range_comp]
  have hcols : (phaseScalarBasis ℝ a base : Fin r → Fin r → ℝ) =
      realVector.toIntLinearMap ∘ phaseIntegerColumns a base := by
    funext j i
    exact phaseScalarBasis_columns ℝ a base i j
  rw [hcols]

def phaseRationalMatrix (a : Fin r→ZMod N) (base : Fin r) : Matrix (Fin r) (Fin r) ℚ :=
  fun i j => (phaseIntegerColumns a base j i:ℚ)

theorem phaseRationalMatrix_nonsingular (a : Fin r→ZMod N) (base : Fin r) :
    (phaseRationalMatrix a base).det≠0 := by
  exact (rational_basis_inverse (phaseScalarBasis ℝ a base) (phaseRationalMatrix a base)
    (by intro i j; simp only [phaseRationalMatrix,Rat.cast_intCast];
        exact (phaseScalarBasis_columns ℝ a base i j).symm)).1

theorem phaseIntegerColumns_bound (a : Fin r→ZMod N) (base i j : Fin r) :
    |phaseIntegerColumns a base j i|≤(N:ℤ) := by
  rw [phaseIntegerColumns_formula]
  have hN : 0<N := NeZero.pos N
  have hv := ZMod.val_lt (a i)
  split_ifs <;> simp only [abs_one,Int.abs_natCast,abs_zero] <;> omega

end Optss
