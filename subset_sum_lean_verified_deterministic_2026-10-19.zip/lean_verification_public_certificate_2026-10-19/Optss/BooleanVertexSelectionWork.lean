import Optss.BooleanVertexSelection

/-!
# Work of the actual Boolean vertex search

The bounds account for tuple construction, matrix gathering, construction and
execution of each determinant expression, cached-score comparison, and deep
copies of the selected record. Rank is fixed: the candidate count is exactly
`m^r`, so this does not claim a polynomial algorithm in variable rank.
-/
namespace Optss
open scoped BigOperators
variable {r m : ℕ}

def vertexScoreBits (r L : ℕ) : ℕ := r.factorial*(r*L+2)

theorem bitVertexScore_lengths (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) (L : ℕ)
    (hbits : ∀ i j,(rectangularListFractionMatrix V i j).numerator.length≤L ∧
      (rectangularListFractionMatrix V i j).denominator.length≤L)
    {t : BitVertexTuple r} (ht : t∈bitVertexTuples m r) :
    (bitVertexScore V t).numerator.length≤vertexScoreBits r L ∧
      (bitVertexScore V t).denominator.length≤vertexScoreBits r L := by
  simp only [bitVertexScore,bitFractionAbs,listCopyFraction_eq,constructedListMatrixDeterminant_eq,
    listStoredMatrixDeterminant_eq]
  exact booleanMatrixDeterminant_output_bits _ (bitVertexGather_wellFormed V hV ht)
    L (bitVertexGather_lengths V L hbits ht)

noncomputable def vertexScoreWorkBound (r m L : ℕ) : ℕ :=
  matrixProductAllocationWork r r+r*r*vertexGatherCellBound r m L+
    (constructedDeterminantPolynomial r).eval (r+r*r*(1+2*L))+4*vertexScoreBits r L+7

theorem bitVertexScoreWork_bound (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) (L : ℕ)
    (hbits : ∀ i j,(rectangularListFractionMatrix V i j).numerator.length≤L ∧
      (rectangularListFractionMatrix V i j).denominator.length≤L)
    {t : BitVertexTuple r} (ht : t∈bitVertexTuples m r) :
    bitVertexScoreWork V t≤vertexScoreWorkBound r m L := by
  let A := bitVertexGather V t
  have hA := bitVertexGather_wellFormed V hV ht
  have ha := bitVertexGather_lengths V L hbits ht
  have hg := bitVertexGatherWork_bound V t ht L hbits
  have hs := listStoredRationalBits_le_of_lengths A L ha
  have hd := (constructedListMatrixDeterminantWork_input_polynomial A hA).trans
    (natPolynomial_eval_mono (constructedDeterminantPolynomial r) hs)
  have hb := booleanMatrixDeterminant_output_bits (listFractionMatrix A) hA L ha
  have hc : bitFractionAbsWork (constructedListMatrixDeterminant A)≤4*vertexScoreBits r L+4 := by
    simp only [bitFractionAbsWork,listCopyFractionWork_eq,fractionPayload,
      constructedListMatrixDeterminant_eq,listStoredMatrixDeterminant_eq]
    unfold vertexScoreBits
    omega
  change bitVertexGatherWork V t+constructedListMatrixDeterminantWork A+
    bitFractionAbsWork (constructedListMatrixDeterminant A)+3≤_
  unfold vertexScoreWorkBound
  omega

def vertexMaximumStepBound (r m T : ℕ) : ℕ :=
  128*(T+1)^2+r*(2*m+3)+4*T+9

theorem copyScoredVertexWork_bound (p : BitScoredVertex r) (m T : ℕ)
    (ht : ∀ w∈p.1.data,w.length≤m)
    (hs : p.2.numerator.length≤T ∧ p.2.denominator.length≤T) :
    copyScoredVertexWork p≤r*(2*m+3)+4*T+5 := by
  have h := p.1.copyWork_le bitWordCopyWork (2*m+1) (by
    intro w hw; rw [bitWordCopyWork_eq]; have h := ht w hw; omega)
  rw [copyScoredVertexWork,listCopyFractionWork_eq,fractionPayload]
  nlinarith

theorem bitMaximumScoredWork_bound (ps : List (BitScoredVertex r)) (m T : ℕ)
    (hbits : ∀ p∈ps,(∀ w∈p.1.data,w.length≤m) ∧
      p.2.numerator.length≤T ∧ p.2.denominator.length≤T) :
    bitMaximumScoredWork ps≤1+ps.length*vertexMaximumStepBound r m T := by
  induction ps with
  | nil => simp [bitMaximumScoredWork]
  | cons p ps ih =>
    have hp := hbits p List.mem_cons_self
    have ht := fun q hq => hbits q (List.mem_cons_of_mem p hq)
    have hi := ih ht
    have hc := copyScoredVertexWork_bound p m T hp.1 hp.2
    rw [bitMaximumScoredWork,List.length_cons]
    cases he : bitMaximumScored ps with
    | none => simp only [he]; unfold vertexMaximumStepBound at *; nlinarith
    | some q =>
      have hq := ht q (bitMaximumScored_mem ps q he)
      have hqc := copyScoredVertexWork_bound q m T hq.1 hq.2
      have hcmp := bitListFractionLECost_bound p.2 q.2 T hp.2 hq.2
      simp only [he]
      split_ifs <;> unfold vertexMaximumStepBound at * <;> nlinarith

theorem bitScoredVertexTuples_length (V : ListBitRationalMatrixData r m) :
    (bitScoredVertexTuples V).length=m^r := by
  rw [bitScoredVertexTuples,List.length_map,bitVertexTuples_length]

noncomputable def vertexSelectionWorkBound (r m L : ℕ) : ℕ :=
  vertexTupleEnumerationBound m r+
    m^r*(r*(2*m+3)+vertexScoreWorkBound r m L+4+
      vertexMaximumStepBound r m (vertexScoreBits r L))+4

theorem bitSelectVertexTupleWork_bound (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) (L : ℕ)
    (hbits : ∀ i j,(rectangularListFractionMatrix V i j).numerator.length≤L ∧
      (rectangularListFractionMatrix V i j).denominator.length≤L) :
    bitSelectVertexTupleWork V≤vertexSelectionWorkBound r m L := by
  have he := bitVertexTuplesWork_bound m r
  have hscore : ((bitVertexTuples m r).map fun t =>
      t.copyWork bitWordCopyWork+bitVertexScoreWork V t+3).sum≤
      m^r*(r*(2*m+3)+vertexScoreWorkBound r m L+4) := by
    have h := List.sum_le_card_nsmul ((bitVertexTuples m r).map fun t =>
        t.copyWork bitWordCopyWork+bitVertexScoreWork V t+3)
      (r*(2*m+3)+vertexScoreWorkBound r m L+4) (by
        intro z hz
        obtain ⟨t,ht,rfl⟩ := List.mem_map.mp hz
        have hs := bitVertexScoreWork_bound V hV L hbits ht
        have hc := t.copyWork_le bitWordCopyWork (2*m+1) (by
          intro w hw; rw [bitWordCopyWork_eq]
          have h := bitVertexTuples_word_length ht w hw
          omega)
        nlinarith)
    simpa only [List.length_map,bitVertexTuples_length,nsmul_eq_mul] using h
  have hm := bitMaximumScoredWork_bound (bitScoredVertexTuples V) m (vertexScoreBits r L) (by
    intro p hp
    obtain ⟨t,ht,rfl⟩ := List.mem_map.mp hp
    simp only [BooleanListArray.copy_eq bitWordCopy bitWordCopy_eq]
    exact ⟨bitVertexTuples_word_length ht,bitVertexScore_lengths V hV L hbits ht⟩)
  rw [bitScoredVertexTuples_length] at hm
  unfold bitSelectVertexTupleWork bitScoredVertexTuplesWork vertexSelectionWorkBound
  nlinarith

noncomputable def vertexGatherPolynomial (r : ℕ) : Polynomial ℕ :=
  64*Polynomial.C ((r+1)^2)*(2*Polynomial.X+2)+
    64*Polynomial.C ((r+1)^2)*(Polynomial.X*(4*Polynomial.X+5)+2)+
    Polynomial.X*(12*(Polynomial.X+2)+2*(4*Polynomial.X+3))+4

noncomputable def vertexScorePolynomial (r : ℕ) : Polynomial ℕ :=
  Polynomial.C (matrixProductAllocationWork r r)+Polynomial.C (r*r)*vertexGatherPolynomial r+
    (constructedDeterminantPolynomial r).comp
      (Polynomial.C r+Polynomial.C (r*r)*(1+2*Polynomial.X))+
    4*Polynomial.C r.factorial*(Polynomial.C r*Polynomial.X+2)+7

noncomputable def vertexMaximumPolynomial (r : ℕ) : Polynomial ℕ :=
  128*(Polynomial.C r.factorial*(Polynomial.C r*Polynomial.X+2)+1)^2+
    Polynomial.C r*(2*Polynomial.X+3)+
    4*Polynomial.C r.factorial*(Polynomial.C r*Polynomial.X+2)+9

/-- One polynomial for each fixed rank, in vertices plus literal input bits. -/
noncomputable def vertexSelectionPolynomial (r : ℕ) : Polynomial ℕ :=
  vertexTupleEnumerationPolynomial r+Polynomial.X^r*
    (Polynomial.C r*(2*Polynomial.X+3)+vertexScorePolynomial r+4+vertexMaximumPolynomial r)+4

theorem vertexSelectionPolynomial_eval (r N : ℕ) :
    (vertexSelectionPolynomial r).eval N=vertexSelectionWorkBound r N N := by
  simp only [vertexSelectionPolynomial,vertexScorePolynomial,vertexMaximumPolynomial,
    vertexGatherPolynomial,Polynomial.eval_add,Polynomial.eval_mul,Polynomial.eval_pow,
    Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat,
    Polynomial.eval_comp,vertexTupleEnumerationPolynomial_eval,vertexSelectionWorkBound,
    vertexScoreWorkBound,vertexGatherCellBound,vertexMaximumStepBound,vertexScoreBits]
  ring

theorem vertexSelectionWorkBound_mono (r m L N : ℕ) (hm : m≤N) (hL : L≤N) :
    vertexSelectionWorkBound r m L≤vertexSelectionWorkBound r N N := by
  have he : vertexTupleEnumerationBound m r≤vertexTupleEnumerationBound N r := by
    rw [←vertexTupleEnumerationPolynomial_eval,←vertexTupleEnumerationPolynomial_eval]
    exact natPolynomial_eval_mono _ hm
  have hdet : (constructedDeterminantPolynomial r).eval (r+r*r*(1+2*L))≤
      (constructedDeterminantPolynomial r).eval (r+r*r*(1+2*N)) := by
    apply natPolynomial_eval_mono
    gcongr
  have hg : vertexGatherCellBound r m L≤vertexGatherCellBound r N N := by
    unfold vertexGatherCellBound
    gcongr
  have hs : vertexScoreBits r L≤vertexScoreBits r N := by
    unfold vertexScoreBits
    gcongr
  have hscore : vertexScoreWorkBound r m L≤vertexScoreWorkBound r N N := by
    unfold vertexScoreWorkBound
    gcongr
  unfold vertexSelectionWorkBound vertexMaximumStepBound
  gcongr

theorem bitSelectVertexTupleWork_polynomial (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) (N : ℕ)
    (hm : m≤N) (hN : listStoredRationalBits V≤N) :
    bitSelectVertexTupleWork V≤(vertexSelectionPolynomial r).eval N := by
  rw [vertexSelectionPolynomial_eval]
  apply (bitSelectVertexTupleWork_bound V hV (listStoredRationalBits V)
    (listStoredRationalBits_cell V)).trans
  exact vertexSelectionWorkBound_mono r m _ N hm hN

theorem bitSelectVertexTupleWork_vertices_bits (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) :
    bitSelectVertexTupleWork V≤(vertexSelectionPolynomial r).eval (m+listStoredRationalBits V) :=
  bitSelectVertexTupleWork_polynomial V hV _ (by omega) (by omega)

/-- Framing already pays for every input vertex in positive dimension. -/
theorem listStoredRationalBits_vertices (hr : 0<r) (V : ListBitRationalMatrixData r m) :
    m≤listStoredRationalBits V := by
  have hm : m≤r*m := by nlinarith
  rw [listStoredRationalBits_eq,bitRationalMatrixSize]
  omega

/-- For the positive-rank normalization problem, the entire Boolean search
is polynomial in the literal framed input size, with degree depending on rank. -/
theorem bitSelectVertexTupleWork_input_polynomial (hr : 0<r)
    (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) :
    bitSelectVertexTupleWork V≤(vertexSelectionPolynomial r).eval (listStoredRationalBits V) :=
  bitSelectVertexTupleWork_polynomial V hV _ (listStoredRationalBits_vertices hr V) le_rfl
end Optss
