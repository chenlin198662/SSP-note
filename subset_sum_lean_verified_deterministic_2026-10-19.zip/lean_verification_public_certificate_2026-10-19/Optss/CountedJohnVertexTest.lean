import Optss.SignedCountedJohnProjection
import Optss.BoxVertexNormalization

/-!
# Finite corner test for the John correction box

Corollary 1.5 reduces containment of a translated reserve correction box in a
zonotope to membership of its at most `2^d` corners.  This file proves that
convex-geometric reduction independently of any feasibility implementation.
-/

namespace Optss
noncomputable section
open scoped Classical Pointwise

variable {d : ℕ}

/-- The finite corners of `z + q • realCoefficientBox width`. -/
def translatedScaledBoxVertices (z : Fin d → ℝ) (q : ℝ)
    (width : Fin d → ℕ) : Finset (Fin d → ℝ) :=
  (realBoxVertices width).image (fun v => z + q • v)

@[simp] theorem mem_translatedScaledBoxVertices
    (z : Fin d → ℝ) (q : ℝ) (width : Fin d → ℕ) (x : Fin d → ℝ) :
    x ∈ translatedScaledBoxVertices z q width ↔
      ∃ v ∈ realBoxVertices width, z + q • v = x := by
  simp [translatedScaledBoxVertices]

theorem translatedScaledBoxVertices_card_le
    (z : Fin d → ℝ) (q : ℝ) (width : Fin d → ℕ) :
    (translatedScaledBoxVertices z q width).card ≤ 2 ^ d :=
  Finset.card_image_le.trans (realBoxVertices_card_le width)

/-- A translated and scaled coefficient box is exactly the convex hull of its
finite corner test set, including zero widths, zero scale, and dimension zero. -/
theorem convexHull_translatedScaledBoxVertices
    (z : Fin d → ℝ) (q : ℝ) (width : Fin d → ℕ) :
    convexHull ℝ (translatedScaledBoxVertices z q width : Set (Fin d → ℝ)) =
      {z} + q • realCoefficientBox width := by
  have hvertices :
      (translatedScaledBoxVertices z q width : Set (Fin d → ℝ)) =
        {z} + q • (realBoxVertices width : Set (Fin d → ℝ)) := by
    ext x
    constructor
    · intro hx
      rw [Finset.mem_coe] at hx
      obtain ⟨v, hv, rfl⟩ :=
        (mem_translatedScaledBoxVertices z q width x).mp hx
      exact ⟨z, rfl, q • v, ⟨v, hv, rfl⟩, rfl⟩
    · rintro ⟨a, ha, -, ⟨v, hv, rfl⟩, rfl⟩
      have haeq : a = z := ha
      subst a
      rw [Finset.mem_coe]
      exact (mem_translatedScaledBoxVertices z q width _).2 ⟨v, hv, rfl⟩
  rw [hvertices, convexHull_add, convexHull_singleton, convexHull_smul,
    convexHull_realBoxVertices]

/-- Containment in a convex target is equivalent to testing all corners of
the translated correction box. -/
theorem translated_scaled_box_subset_convex_iff
    (Z : Set (Fin d → ℝ)) (hZ : Convex ℝ Z)
    (z : Fin d → ℝ) (q : ℝ) (width : Fin d → ℕ) :
    {z} + q • realCoefficientBox width ⊆ Z ↔
      ∀ v ∈ realBoxVertices width, z + q • v ∈ Z := by
  constructor
  · intro hsubset v hv
    apply hsubset
    have hvbox : v ∈ realCoefficientBox width := by
      rw [← convexHull_realBoxVertices]
      exact subset_convexHull ℝ _ hv
    exact ⟨z, rfl, q • v, ⟨v, hvbox, rfl⟩, rfl⟩
  · intro hcorners
    rw [← convexHull_translatedScaledBoxVertices z q width]
    apply convexHull_min _ hZ
    intro x hx
    rw [Finset.mem_coe] at hx
    obtain ⟨v, hv, rfl⟩ := (mem_translatedScaledBoxVertices z q width x).mp hx
    exact hcorners v hv

/-- The exact corner reduction used for the outer zonotope in Corollary 1.5. -/
theorem translated_scaled_box_subset_zonotope_iff
    {ι : Type*} [Fintype ι] (u : ι → Fin d → ℝ) (capacity : ι → ℝ)
    (z : Fin d → ℝ) (q : ℝ) (width : Fin d → ℕ) :
    {z} + q • realCoefficientBox width ⊆ zonotope u capacity ↔
      ∀ v ∈ realBoxVertices width, z + q • v ∈ zonotope u capacity :=
  translated_scaled_box_subset_convex_iff _ (convex_zonotope u capacity)
    z q width

/-- Corollary 1.5 with its displayed containment replaced by the exact finite
corner test.  The theorem is mathematical: it certifies the returned scalar
sum but does not assign a cost to the zonotope membership tests. -/
theorem counted_john_projected_vertices_reoriented
    {ι : Type*} [Fintype ι]
    (projection : IntVec d →+ ℤ) (u : ι → IntVec d)
    (magnitude scalar : ι → ℤ) (flip : ι → Bool)
    (capacity e r : ι → ℕ) (width : Fin d → ℕ) (t : IntVec d)
    (fillScale : ℝ) (h : ℕ)
    (he : ∀ i, e i ≤ capacity i)
    (hr : ∀ i, r i ≤ capacity i - e i)
    (hu : ∀ i, 0 < capacity i - e i → InCenteredBox width (u i))
    (hprojection : ∀ i, 0 < capacity i - e i →
      projection (u i) = magnitude i)
    (hsign : ∀ i, 0 < capacity i - e i →
      (if flip i then -magnitude i else magnitude i) = scalar i)
    (hfill : ∀ z : IntVec d,
      (∀ j, |(z j : ℝ)| ≤ fillScale * h * width j) →
      t + z ∈ countSums u (fun i => (r i : ℤ)))
    (hdim : (d : ℝ) ≤ fillScale * h)
    (exceptionSum : ℤ)
    (hexception : exceptionSum ∈ countSums scalar (fun i => (e i : ℤ)))
    (z : IntVec d)
    (hvertices : ∀ v ∈ realBoxVertices width,
      realVector z + ((∑ i, r i : ℕ) : ℝ) • v ∈
        zonotope (fun i => realVector (reorientVectors u flip i))
          (fun i => ((r i + (capacity i - e i - r i) : ℕ) : ℝ))) :
    exceptionSum + projection z ∈
      countSums scalar (fun i => (capacity i : ℤ)) := by
  apply counted_john_projected_interior_reoriented projection u magnitude
    scalar flip capacity e r width t fillScale h he hr hu hprojection hsign
    hfill hdim exceptionSum hexception z
  exact (translated_scaled_box_subset_zonotope_iff
    (fun i => realVector (reorientVectors u flip i))
    (fun i => ((r i + (capacity i - e i - r i) : ℕ) : ℝ))
    (realVector z) ((∑ i, r i : ℕ) : ℝ) width).2 hvertices

end
end Optss
