import Optss.BoxVertexNormalization
import Mathlib.LinearAlgebra.Matrix.NonsingularInverse
import Mathlib.Data.Rat.Lemmas

/-!
# Rationality of the actual vertex normalization

The same maximum-determinant vertex basis supplies both the cube inclusions
and the rational coordinate matrix. Its inverse is a genuine rational matrix
inverse. Clearing the finitely many rational denominators produces actual
integer columns for a common positive scaling of the normalized standard
lattice. No unrelated normalization or finite-index sublattice is substituted.
-/

namespace Optss
noncomputable section
open scoped BigOperators Classical
variable {r d : ℕ}

/-- Every finite rational family has a positive common denominator, with
integer numerators constructed by the divisibility witnesses. -/
theorem finite_rational_common_denominator {ι : Type*} [Fintype ι] (q : ι → ℚ) :
    ∃ D : ℕ, 0 < D ∧ ∃ z : ι → ℤ, ∀ i, (D : ℝ) * (q i : ℝ) = (z i : ℝ) := by
  let D : ℕ := ∏ i, (q i).den
  have hD : 0 < D := Finset.prod_pos (fun i _ => (q i).den_pos)
  have hdiv (i : ι) : (q i).den ∣ D := Finset.dvd_prod_of_mem _ (Finset.mem_univ i)
  choose c hc using hdiv
  refine ⟨D, hD, fun i => (c i : ℤ) * (q i).num, ?_⟩
  intro i
  rw [hc i, Nat.cast_mul, Rat.cast_def]
  have hden : ((q i).den : ℝ) ≠ 0 := by exact_mod_cast (q i).den_ne_zero
  push_cast
  field_simp
  ring

/-- An actual basis with rational standard coordinates has a rational inverse
coordinate matrix. The inverse formula is derived from basis reconstruction. -/
theorem rational_basis_inverse (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (A : Matrix (Fin r) (Fin r) ℚ) (hA : ∀ i j, (A i j : ℝ) = b j i) :
    A.det ≠ 0 ∧ A * A⁻¹ = 1 ∧ A⁻¹ * A = 1 ∧
      ∀ x : Fin r → ℝ, b.equivFun x = (A⁻¹.map (fun q : ℚ => (q : ℝ))).mulVec x := by
  let AR : Matrix (Fin r) (Fin r) ℝ := A.map (fun q : ℚ => (q : ℝ))
  have hAR : AR = (Pi.basisFun ℝ (Fin r)).toMatrix b := by
    ext i j
    simpa [AR, Matrix.map_apply, Basis.toMatrix_apply] using hA i j
  have hdetR : AR.det ≠ 0 := by
    rw [hAR]
    exact ((Pi.basisFun ℝ (Fin r)).isUnit_det b).ne_zero
  have hdet : A.det ≠ 0 := by
    intro hz
    have hcast := Rat.cast_det (F := ℝ) A
    rw [hz, Rat.cast_zero] at hcast
    exact hdetR hcast.symm
  have hu : IsUnit A.det := isUnit_iff_ne_zero.mpr hdet
  have hleft := Matrix.nonsing_inv_mul A hu
  have hright := Matrix.mul_nonsing_inv A hu
  refine ⟨hdet, hright, hleft, ?_⟩
  intro x
  have hrec : AR.mulVec (b.equivFun x) = x := by
    ext i
    have h := congrFun (b.sum_repr x) i
    simpa only [Matrix.mulVec, dotProduct, AR, Matrix.map_apply, hA,
      Basis.equivFun_apply, Finset.sum_apply, Pi.smul_apply, smul_eq_mul, mul_comm] using h
  have hinv : A⁻¹.map (fun q : ℚ => (q : ℝ)) * AR = 1 := by
    have h := congrArg (fun M : Matrix (Fin r) (Fin r) ℚ => M.map (Rat.castHom ℝ)) hleft
    dsimp only at h
    rw [Matrix.map_mul, Matrix.map_one _ (map_zero _) (map_one _)] at h
    exact h
  symm
  calc
    _ = (A⁻¹.map (fun q : ℚ => (q : ℝ))).mulVec (AR.mulVec (b.equivFun x)) := by rw [hrec]
    _ = _ := by rw [Matrix.mulVec_mulVec, hinv, Matrix.one_mulVec]

/-- Rational matrix and exact cleared integer columns for one specified
Euclidean normalization. Matrices act on columns; LLL row input is the
transpose of `integerColumns`. -/
structure RationalNormalizationData
    (a : (Fin r → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin r)) where
  matrix : Matrix (Fin r) (Fin r) ℚ
  inverseMatrix : Matrix (Fin r) (Fin r) ℚ
  matrix_mul_inverse : matrix * inverseMatrix = 1
  inverse_mul_matrix : inverseMatrix * matrix = 1
  apply_eq : ∀ x i, a x i = ∑ j, (matrix i j : ℝ) * x j
  denominator : ℕ
  denominator_pos : 0 < denominator
  integerColumns : Matrix (Fin r) (Fin r) ℤ
  cleared_columns : ∀ i j,
    (denominator : ℝ) * a (Pi.single j 1) i = (integerColumns i j : ℝ)

/-- The actual standard-coordinate Euclidean map associated to a basis. -/
def basisEuclideanNormalization (b : Basis (Fin r) ℝ (Fin r → ℝ)) :
    (Fin r → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin r) :=
  b.equivFun.toContinuousLinearEquiv.trans (EuclideanSpace.equiv (Fin r) ℝ).symm

@[simp] theorem basisEuclideanNormalization_apply (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (x : Fin r → ℝ) (i : Fin r) : basisEuclideanNormalization b x i = b.equivFun x i := rfl

/-- Rationality and denominator clearing for the specified basis map, with
no new choice of real normalization. -/
theorem basisEuclideanNormalization_rational
    (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (hb : ∀ i j, ∃ q : ℚ, (q : ℝ) = b j i) :
    Nonempty (RationalNormalizationData (basisEuclideanNormalization b)) := by
  choose Q hQ using hb
  let A : Matrix (Fin r) (Fin r) ℚ := Q
  have hA : ∀ i j, (A i j : ℝ) = b j i := hQ
  obtain ⟨_, hright, hleft, hcoord⟩ := rational_basis_inverse b A hA
  obtain ⟨D, hD, z, hz⟩ := finite_rational_common_denominator
    (fun p : Fin r × Fin r => A⁻¹ p.1 p.2)
  have happly (x : Fin r → ℝ) (i : Fin r) :
      basisEuclideanNormalization b x i = ∑ j, (A⁻¹ i j : ℝ) * x j := by
    rw [basisEuclideanNormalization_apply, hcoord]
    rfl
  refine ⟨⟨A⁻¹, A, hleft, hright, happly, D, hD, fun i j => z (i,j), ?_⟩⟩
  intro i j
  rw [happly]
  simpa [Pi.single_apply] using hz (i,j)


/-- The rational inverse is also the coordinate formula for the actual inverse
of the specified real normalization. -/
theorem RationalNormalizationData.inverse_apply_eq
    {a : (Fin r → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin r)}
    (c : RationalNormalizationData a) (y : EuclideanSpace ℝ (Fin r)) (i : Fin r) :
    a.symm y i = ∑ j, (c.inverseMatrix i j : ℝ) * y j := by
  let M : Matrix (Fin r) (Fin r) ℝ := c.matrix.map (Rat.castHom ℝ)
  let B : Matrix (Fin r) (Fin r) ℝ := c.inverseMatrix.map (Rat.castHom ℝ)
  have hBA : B * M = 1 := by
    have h := congrArg (fun A : Matrix (Fin r) (Fin r) ℚ => A.map (Rat.castHom ℝ))
      c.inverse_mul_matrix
    dsimp only at h
    rw [Matrix.map_mul, Matrix.map_one _ (map_zero _) (map_one _)] at h
    exact h
  have hy : M.mulVec (a.symm y) = fun j => y j := by
    ext j
    exact (c.apply_eq (a.symm y) j).symm.trans (by rw [a.apply_symm_apply])
  have hid : B.mulVec (fun j => y j) = a.symm y := by
    rw [← hy, Matrix.mulVec_mulVec, hBA, Matrix.one_mulVec]
  exact (congrFun hid i).symm



/-- Clearing the same denominator works for every integer lattice vector,
with the full integer matrix image and the same coefficient vector. -/
theorem RationalNormalizationData.cleared_integer_apply
    {a : (Fin r → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin r)}
    (c : RationalNormalizationData a) (x : IntVec r) (i : Fin r) :
    (c.denominator : ℝ) * a (realVector x) i =
      (c.integerColumns.mulVec x i : ℝ) := by
  have hz (j : Fin r) :
      (c.denominator : ℝ) * (c.matrix i j : ℝ) = (c.integerColumns i j : ℝ) := by
    have h := c.cleared_columns i j
    rw [c.apply_eq] at h
    simpa [Pi.single_apply] using h
  rw [c.apply_eq, Finset.mul_sum]
  simp only [Matrix.mulVec, dotProduct, Int.cast_sum, Int.cast_mul]
  apply Finset.sum_congr rfl
  intro j _
  change (c.denominator : ℝ) * ((c.matrix i j : ℝ) * (x j : ℝ)) =
    (c.integerColumns i j : ℝ) * (x j : ℝ)
  rw [← mul_assoc, hz]

/-- The denominator-cleared columns are independent. Transposing
`integerColumns` therefore gives exactly the integer row family accepted by LLL. -/
theorem RationalNormalizationData.integerColumns_linearIndependent
    {a : (Fin r → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin r)}
    (c : RationalNormalizationData a) :
    LinearIndependent ℝ (fun j i => (c.integerColumns i j : ℝ)) := by
  let f : (Fin r → ℝ) ≃ₗ[ℝ] (Fin r → ℝ) :=
    a.toLinearEquiv.trans (EuclideanSpace.equiv (Fin r) ℝ).toLinearEquiv
  have hf : LinearIndependent ℝ (fun j => f (Pi.single j 1)) := by
    simpa only [Function.comp_def, Pi.basisFun_apply] using
      (Pi.basisFun ℝ (Fin r)).linearIndependent.map' f.toLinearMap (LinearEquiv.ker f)
  have hD : (c.denominator : ℝ) ≠ 0 := by exact_mod_cast c.denominator_pos.ne'
  let u : ℝˣ := Units.mk0 (c.denominator : ℝ) hD
  have heq : (fun j i => (c.integerColumns i j : ℝ)) =
      (fun _ : Fin r => u) • (fun j => f (Pi.single j 1)) := by
    funext j i
    change (c.integerColumns i j : ℝ) = (c.denominator : ℝ) * a (Pi.single j 1) i
    exact (c.cleared_columns i j).symm
  rw [heq]
  exact hf.units_smul (fun _ => u)

/-- Rational vertices yield one normalization together with its rationality
certificate. The basis here is exactly the maximizing basis used for the cubes. -/
theorem exists_rational_vertex_normalization (hr : 0 < r)
    (S : Finset (Fin r → ℝ))
    (hspan : Submodule.span ℝ (S : Set (Fin r → ℝ)) = ⊤)
    (hsym : ∀ x ∈ S, -x ∈ S)
    (hrat : ∀ x ∈ S, ∀ i, ∃ q : ℚ, (q : ℝ) = x i) :
    ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
      (∀ j, b j ∈ S) ∧
      (∀ v : Fin r → (Fin r → ℝ), (∀ j, v j ∈ S) →
        |(Pi.basisFun ℝ (Fin r)).det v| ≤ |(Pi.basisFun ℝ (Fin r)).det b|) ∧
      {x : EuclideanSpace ℝ (Fin r) | ∀ j, |x j| ≤ 1/(r:ℝ)} ⊆
        basisEuclideanNormalization b '' convexHull ℝ (S : Set _) ∧
      basisEuclideanNormalization b '' convexHull ℝ (S : Set _) ⊆
        {x | ∀ j, |x j| ≤ 1} ∧
      Nonempty (RationalNormalizationData (basisEuclideanNormalization b)) := by
  obtain ⟨b, hb, _, hmax, hinner, houter⟩ :=
    exists_maximal_determinant_normalization hr (Pi.basisFun ℝ (Fin r)) S hspan hsym
  refine ⟨b, hb, hmax, ?_, ?_, basisEuclideanNormalization_rational b ?_⟩
  · intro x hx
    obtain ⟨y, hy, heq⟩ := hinner (show (fun j => x j) ∈ coordinateCube r (1/(r:ℝ)) from hx)
    refine ⟨y, hy, ?_⟩
    ext j
    exact congrFun heq j
  · rintro _ ⟨x, hx, rfl⟩ j
    exact houter ⟨x, hx, rfl⟩ j
  · intro i j
    exact hrat (b j) (hb j) i

/-- Every real corner is the cast of an actual integer corner. -/
theorem realBoxVertices_integral (β : Fin d → ℕ) {x : Fin d → ℝ}
    (hx : x ∈ realBoxVertices β) : ∃ z : IntVec d, realVector z = x := by
  have hj (j : Fin d) : ∃ z : ℤ, (z : ℝ) = x j := by
    rcases (mem_realBoxVertices β x).mp hx j with h | h
    · exact ⟨-(β j : ℤ), by simpa using h.symm⟩
    · exact ⟨(β j : ℤ), by simpa using h.symm⟩
  choose z hz using hj
  exact ⟨z, funext hz⟩

/-- The actual image corners of an integer matrix still have integer coordinates. -/
theorem integerLinearImageBox_vertices_integral (π : IntVec d →ₗ[ℤ] IntVec r)
    (β : Fin d → ℕ) {x : Fin r → ℝ}
    (hx : x ∈ linearImageBoxVertices (integerMapRealExtension π) β) :
    ∃ z : IntVec r, realVector z = x := by
  simp only [linearImageBoxVertices, Finset.mem_image] at hx
  obtain ⟨y, hy, rfl⟩ := hx
  obtain ⟨z, rfl⟩ := realBoxVertices_integral β hy
  exact ⟨π z, (integerMapRealExtension_cast π z).symm⟩

/-- One actual normalization of the quotient body simultaneously supplies the
cube containments, rational inverse matrices, and the common integer denominator. -/
theorem integerLinearImageBox_rational_normalization (hr : 0 < r)
    (π : IntVec d →ₗ[ℤ] IntVec r) (hπ : Function.Surjective π)
    (β : Fin d → ℕ) (hβ : ∀ j, 1 ≤ β j) :
    ∃ a : (Fin r → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin r),
      {x | ∀ j, |x j| ≤ 1/(r:ℝ)} ⊆ a '' integerLinearImageBox π β ∧
      a '' integerLinearImageBox π β ⊆ {x | ∀ j, |x j| ≤ 1} ∧
      Nonempty (RationalNormalizationData a) := by
  have hrat : ∀ x ∈ linearImageBoxVertices (integerMapRealExtension π) β,
      ∀ i, ∃ q : ℚ, (q : ℝ) = x i := by
    intro x hx i
    obtain ⟨z, rfl⟩ := integerLinearImageBox_vertices_integral π β hx
    exact ⟨(z i : ℚ), by simp [realVector]⟩
  obtain ⟨b, _, _, hinner, houter, hc⟩ := exists_rational_vertex_normalization hr
    (linearImageBoxVertices (integerMapRealExtension π) β)
    (linearImageBoxVertices_span _ (integerMapRealExtension_surjective π hπ) β hβ)
    (fun x hx => linearImageBoxVertices_symmetric _ β hx) hrat
  rw [← integerLinearImageBox_eq_convexHull] at hinner houter
  exact ⟨basisEuclideanNormalization b, hinner, houter, hc⟩

/-- The primitive quotient construction automatically meets the surjectivity
input of rational normalization. -/
theorem primitiveQuotientBox_rational_normalization (hd : 1 < d)
    (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1)
    (β : Fin d → ℕ) (hβ : ∀ j, 1 ≤ β j) :
    ∃ a : (Fin (d-1) → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin (d-1)),
      {x | ∀ j, |x j| ≤ 1/((d-1:ℕ):ℝ)} ⊆
        a '' integerLinearImageBox (primitiveQuotientMap p ℓ hp) β ∧
      a '' integerLinearImageBox (primitiveQuotientMap p ℓ hp) β ⊆
        {x | ∀ j, |x j| ≤ 1} ∧ Nonempty (RationalNormalizationData a) :=
  integerLinearImageBox_rational_normalization (by omega) (primitiveQuotientMap p ℓ hp)
    (primitiveQuotientMap_surjective p ℓ hp) β hβ

end
end Optss
