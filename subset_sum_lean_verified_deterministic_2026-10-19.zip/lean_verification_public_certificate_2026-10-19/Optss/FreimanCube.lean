import Optss.FreimanCubeGeometry
import Mathlib.Analysis.Convex.Combination

/-!
# Finite vertex descriptions of possibly degenerate Freiman cubes

Repeated segment extension retains the actual vertices and equals their
convex hull. Degenerate directions are permitted, as required in Bilu's
cube lemma when many input points lie in a lower-dimensional subspace.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {E : Type*} [AddCommGroup E] [Module ℝ E]

def freimanCubeBody : List E → Set E
  | [] => {0}
  | a :: v => cubeAxisExtension a (freimanCubeBody v)

def freimanCubeVertices : List E → Finset E
  | [] => {0}
  | a :: v => {-a, a} + freimanCubeVertices v

theorem cubeAxisExtension_eq_segment_add (a : E) (D : Set E) :
    cubeAxisExtension a D = segment ℝ (-a) a + D := by
  ext x
  constructor
  · rintro ⟨s, hs, q, hq, rfl⟩
    refine Set.mem_add.mpr ⟨s • a, ?_, q, hq, rfl⟩
    rw [segment_eq_image]
    refine ⟨(s+1)/2, ?_, ?_⟩
    · obtain ⟨hl, hu⟩ := abs_le.mp hs
      exact ⟨by linarith, by linarith⟩
    · module
  · rintro ⟨y, hy, q, hq, rfl⟩
    rw [segment_eq_image] at hy
    obtain ⟨t, ⟨ht0, ht1⟩, rfl⟩ := hy
    exact ⟨2*t-1, abs_le.mpr ⟨by linarith, by linarith⟩, q, hq, by module⟩

theorem freimanCubeBody_eq_convexHull (v : List E) :
    freimanCubeBody v = convexHull ℝ (freimanCubeVertices v : Set E) := by
  induction v with
  | nil => simp [freimanCubeBody, freimanCubeVertices]
  | cons a v ih =>
    simp only [freimanCubeBody, freimanCubeVertices, cubeAxisExtension_eq_segment_add,
      Finset.coe_add, Finset.coe_pair, convexHull_add, convexHull_pair, ih]

theorem freimanCubeVertices_subset_body (v : List E) :
    (freimanCubeVertices v : Set E) ⊆ freimanCubeBody v := by
  rw [freimanCubeBody_eq_convexHull]
  exact subset_convexHull ℝ _

theorem freimanCubeBody_symmetric (v : List E) :
    ∀ x ∈ freimanCubeBody v, -x ∈ freimanCubeBody v := by
  induction v with
  | nil => simp [freimanCubeBody]
  | cons a v ih => exact cubeAxisExtension_symmetric a _ ih

theorem freimanCubeBody_zero (v : List E) : (0 : E) ∈ freimanCubeBody v := by
  induction v with
  | nil => simp [freimanCubeBody]
  | cons a v ih => exact ⟨0, by norm_num, 0, ih, by simp⟩

theorem freimanCubeBody_zero_cons (v : List E) :
    freimanCubeBody (0 :: v) = freimanCubeBody v := by
  ext x
  simp only [freimanCubeBody, cubeAxisExtension, smul_zero, zero_add, Set.mem_setOf_eq]
  constructor
  · rintro ⟨_, _, q, hq, rfl⟩
    exact hq
  · intro hx
    exact ⟨0, by norm_num, x, hx, rfl⟩

omit [Module ℝ E] in
theorem freimanCubeVertices_zero_cons (v : List E) :
    freimanCubeVertices (0 :: v) = freimanCubeVertices v := by
  simp only [freimanCubeVertices, neg_zero, Finset.insert_eq_of_mem (Finset.mem_singleton_self _)]
  exact zero_add _

omit [Module ℝ E] in
theorem freimanCubeVertices_symmetric (v : List E) :
    ∀ x ∈ freimanCubeVertices v, -x ∈ freimanCubeVertices v := by
  induction v with
  | nil => simp [freimanCubeVertices]
  | cons a v ih =>
    intro x hx
    obtain ⟨p, hp, q, hq, rfl⟩ := Finset.mem_add.mp hx
    apply Finset.mem_add.mpr
    refine ⟨-p, ?_, -q, ih q hq, by abel⟩
    have hp' : p = -a ∨ p = a := by simpa using hp
    rcases hp' with rfl | rfl <;> simp

/-- Strict inequalities on the genuine finite vertex set hold on every
point of the cube. -/
theorem freimanCubeBody_halfspace (v : List E) (f : E →ₗ[ℝ] ℝ) (r : ℝ)
    (h : ∀ x ∈ freimanCubeVertices v, r < f x) :
    ∀ x ∈ freimanCubeBody v, r < f x := by
  rw [freimanCubeBody_eq_convexHull]
  exact convexHull_min h (convex_halfSpace_gt f.isLinear r)

end
end Optss
