import Optss.BitConvolutionSupport

/-! Actual sequential Boolean sumset convolution. The transform stores signed
integer digits throughout and support extraction calls the pure Boolean
rounding/comparison routine, with no decoded arithmetic in the answer. -/
namespace Optss
open scoped Pointwise
set_option maxRecDepth 4096

def listBooleanConvolution (depth : List Bool) (f g : List Bool) : List Bool :=
  let p := dyadicDFTPrecision depth.length
  let den := listConvolutionDenominator depth p
  let C := listCyclicConvolution depth p (f.map bitFourierBoolean) (g.map bitFourierBoolean)
  C.map (bitConvolutionPositive den)

theorem listBooleanConvolution_eq (depth : List Bool) (f g : Vector Bool (2^depth.length)) :
    listBooleanConvolution depth (List.ofFn f.get) (List.ofFn g.get)=
      List.ofFn (fun k : Fin (2^depth.length) => decide (0<cyclicNatConvolution
        (cyclicBooleanNat depth.length f) (cyclicBooleanNat depth.length g) (k.val : ZMod (2^depth.length)))) := by
  let p := dyadicDFTPrecision depth.length
  let den := listConvolutionDenominator depth p
  let A := (List.ofFn f.get).map bitFourierBoolean
  let B := (List.ofFn g.get).map bitFourierBoolean
  let C := listCyclicConvolution depth p A B
  let V := dyadicCyclicConvolution depth.length p (fourierBooleanData depth.length f) (fourierBooleanData depth.length g)
  have ha : A.map BitFourierInteger.value=List.ofFn (fourierBooleanData depth.length f).get := by
    simp only [A,List.map_map,List.map_ofFn,Function.comp_def,bitFourierBoolean_value,fourierBooleanData]
    apply congrArg List.ofFn
    funext i
    rw [vector_get_ofFn]
  have hb : B.map BitFourierInteger.value=List.ofFn (fourierBooleanData depth.length g).get := by
    simp only [B,List.map_map,List.map_ofFn,Function.comp_def,bitFourierBoolean_value,fourierBooleanData]
    apply congrArg List.ofFn
    funext i
    rw [vector_get_ofFn]
  have hc : C.map BitFourierInteger.value=List.ofFn V.get :=
    listCyclicConvolution_values depth p A B _ _ ha hb
  have hlen : C.length=2^depth.length := by
    have h := congrArg List.length hc
    simpa only [List.length_map,List.length_ofFn] using h
  have hden : binaryDigitsValue den=cyclicConvolutionDenominator depth.length p :=
    listConvolutionDenominator_value depth p
  have hpos : 0<binaryDigitsValue den := by rw [hden]; exact cyclicConvolutionDenominator_pos _ _
  change C.map (bitConvolutionPositive den)=_
  apply List.ext_getElem
  · simp only [List.length_map,hlen,List.length_ofFn]
  · intro i hi hi'
    have hil : i < 2^depth.length := by simpa only [List.length_ofFn] using hi'
    have hiC : i < C.length := by omega
    have hh := congrArg (fun xs => xs[i]?) hc
    simp only [List.getElem?_map,List.getElem?_ofFn,hil,↓reduceDIte,List.getElem?_eq_getElem hiC] at hh
    have he : C[i].value=V.get ⟨i,hil⟩ := Option.some.inj hh
    simp only [List.getElem_map,List.getElem_ofFn]
    apply Bool.eq_iff_iff.mpr
    rw [bitConvolutionPositive_correct den _ hpos,hden,he]
    have hr := dyadicBooleanConvolution_round depth.length f g ⟨i,hil⟩
    change round ((V.get ⟨i,hil⟩).re/(cyclicConvolutionDenominator depth.length p : ℚ))=_ at hr
    rw [hr,decide_eq_true_eq]
    exact Int.natCast_pos

theorem listBooleanConvolution_length (depth : List Bool) (f g : List Bool)
    (hf : f.length=2^depth.length) (hg : g.length=2^depth.length) :
    (listBooleanConvolution depth f g).length=2^depth.length := by
  obtain ⟨F,rfl⟩ := fourier_exists_vector f _ hf
  obtain ⟨G,rfl⟩ := fourier_exists_vector g _ hg
  rw [listBooleanConvolution_eq,List.length_ofFn]

/-- A semantic support predicate for a stored Boolean array. -/
def cyclicBooleanSupport (n : ℕ) (f : Vector Bool (2^n)) : Finset (ZMod (2^n)) :=
  Finset.univ.filter fun x => f.get (cyclicArrayIndex n x)

theorem cyclicBooleanNat_indicator (n : ℕ) (f : Vector Bool (2^n)) :
    cyclicBooleanNat n f=cyclicNatIndicator (cyclicBooleanSupport n f) := by
  funext x
  simp only [cyclicBooleanNat,cyclicNatIndicator,cyclicBooleanSupport,Finset.mem_filter,
    Finset.mem_univ,true_and]
  cases f.get (cyclicArrayIndex n x) <;> rfl

theorem listBooleanConvolution_support (depth : List Bool) (f g : Vector Bool (2^depth.length)) :
    listBooleanConvolution depth (List.ofFn f.get) (List.ofFn g.get)=
      List.ofFn (fun k : Fin (2^depth.length) => decide ((k.val : ZMod (2^depth.length))∈
        cyclicBooleanSupport depth.length f+cyclicBooleanSupport depth.length g)) := by
  rw [listBooleanConvolution_eq]
  simp only [cyclicBooleanNat_indicator,cyclicNatConvolution_indicator_pos_iff]

end Optss
