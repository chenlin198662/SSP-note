import Optss.CountNewton
import Optss.AbsoluteEncoding
import Mathlib.Data.Nat.Choose.Bounds
import Mathlib.Data.Nat.Size

/-!
# Exact coefficient and type-count bounds

These are the combinatorial size estimates used in §10.1: elementary
coefficients count labelled selections and are bounded by binomial coefficients;
an orthant contains at most the product-box volume many distinct surviving
types. This file does not assert the cost of integer multiplication/convolution.
-/

namespace Optss
open scoped BigOperators
noncomputable section

variable {ι σ : Type*} [Fintype ι]

/-- A coefficient counts only some of the `k`-element selections. -/
theorem fixedCardinalityWitnesses_card_le_choose (u : ι → σ →₀ ℕ) (k : ℕ)
    (e : σ →₀ ℕ) :
    (fixedCardinalityWitnesses u k e).card ≤ (Fintype.card ι).choose k := by
  classical
  exact (Finset.card_filter_le _ _).trans_eq (by simp)

theorem elementaryCoefficient_monomial_coeff_le (u : ι → σ →₀ ℕ) (k : ℕ)
    (e : σ →₀ ℕ) :
    MvPolynomial.coeff e
        (elementaryCoefficient (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) k) ≤
      (Fintype.card ι : ℤ) ^ k := by
  rw [elementaryCoefficient_monomial_coeff]
  exact_mod_cast (fixedCardinalityWitnesses_card_le_choose u k e).trans
    (Nat.choose_le_pow (Fintype.card ι) k)

/-- The stored coefficient obeys the same bound after truncation. -/
theorem newtonTruncatedCoefficient_monomial_coeff_le (u : ι → σ →₀ ℕ)
    (Δ e : σ →₀ ℕ) (k : ℕ) :
    MvPolynomial.coeff e
      (newtonTruncatedCoefficient Δ (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) k) ≤
      (Fintype.card ι : ℤ) ^ k := by
  classical
  rw [newtonTruncatedCoefficient_eq, coeff_truncatePolynomial]
  split_ifs
  · exact elementaryCoefficient_monomial_coeff_le u k e
  · positivity

/-- Distinct bounded nonnegative exponent vectors fit in the full product box,
including zero-width coordinates. -/
theorem card_types_le_exponent_box {d : ℕ} (u : ι → Fin d →₀ ℕ)
    (hinj : Function.Injective u) (Δ : Fin d →₀ ℕ) (hΔ : ∀ i, u i ≤ Δ) :
    Fintype.card ι ≤ ∏ j, (Δ j + 1) := by
  let f : ι → ∀ j : Fin d, Fin (Δ j + 1) := fun i j =>
    ⟨u i j, Nat.lt_succ_of_le (hΔ i j)⟩
  have hf : Function.Injective f := by
    intro i k h
    apply hinj
    ext j
    exact congrArg Fin.val (congrFun h j)
  simpa using Fintype.card_le_of_injective f hf

/-- Within one orthant the absolute-value encoding is injective on distinct
signed types. Thus the manuscript's product-box bound applies before expansion. -/
theorem card_types_le_orthant_box {d : ℕ} (v : ι → IntVec d)
    (hinj : Function.Injective v) (ε : Fin d → Bool) (hv : ∀ i, InOrthant ε (v i))
    (Δ : Fin d →₀ ℕ) (hΔ : ∀ i, absoluteExponent (v i) ≤ Δ) :
    Fintype.card ι ≤ ∏ j, (Δ j + 1) := by
  apply card_types_le_exponent_box (fun i => absoluteExponent (v i)) _ Δ hΔ
  intro i k h
  apply hinj
  have he := congrArg (orthantDecode ε) h
  simpa only [orthantDecode_absoluteExponent ε (v i) (hv i),
    orthantDecode_absoluteExponent ε (v k) (hv k)] using he

/-- Capping every surviving type controls the total number of labelled copies
used only in the analysis, without constructing those labels in the algorithm. -/
theorem capped_total_le (c : ι → ℕ) (kcap V : ℕ)
    (hc : ∀ i, c i ≤ kcap) (hV : Fintype.card ι ≤ V) :
    (∑ i, c i) ≤ kcap * V := by
  calc
    _ ≤ ∑ _i : ι, kcap := Finset.sum_le_sum (fun i _ => hc i)
    _ = Fintype.card ι * kcap := by simp
    _ ≤ V * kcap := Nat.mul_le_mul_right _ hV
    _ = kcap * V := Nat.mul_comm _ _

/-- Uniform version of the paper's `(kcap * V)^kcap` coefficient bound.
The positive cap and volume assumptions also cover a zero-copy input. -/
theorem countNewtonTable_coeff_bound (c : ι → ℕ) (u : ι → σ →₀ ℕ)
    (Δ e : σ →₀ ℕ) (kcap V k : ℕ) (hkcap : 0 < kcap) (hVpos : 0 < V)
    (hc : ∀ i, c i ≤ kcap) (hV : Fintype.card ι ≤ V) (hk : k ≤ kcap) :
    0 ≤ MvPolynomial.coeff e
      ((countNewtonTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap).getD k 0) ∧
    MvPolynomial.coeff e
      ((countNewtonTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap).getD k 0) ≤
      ((kcap * V : ℕ) : ℤ) ^ kcap := by
  rw [countNewtonTable_getD _ _ _ _ _ hk, ← newtonTruncatedCoefficient_eq]
  refine ⟨newtonTruncatedCoefficient_monomial_coeff_nonneg _ Δ e k, ?_⟩
  have htotal : Fintype.card (Σ i, Fin (c i)) ≤ kcap * V := by
    simpa using capped_total_le c kcap V hc hV
  calc
    _ ≤ (Fintype.card (Σ i, Fin (c i)) : ℤ) ^ k :=
      newtonTruncatedCoefficient_monomial_coeff_le _ Δ e k
    _ ≤ ((kcap * V : ℕ) : ℤ) ^ k := by
      exact_mod_cast Nat.pow_le_pow_left htotal k
    _ ≤ ((kcap * V : ℕ) : ℤ) ^ kcap := by
      apply pow_le_pow_right₀ _ hk
      have hpos : 0 < kcap * V := Nat.mul_pos hkcap hVpos
      exact_mod_cast hpos

/-- An explicit binary magnitude bound, avoiding asymptotic notation. -/
theorem nat_size_le_of_le_pow {z B k : ℕ} (hk : 0 < k) (hz : z ≤ B ^ k) :
    z.size ≤ k * B.size := by
  apply Nat.size_le.mpr
  have hb : B < 2 ^ B.size := Nat.lt_size_self B
  calc
    z ≤ B ^ k := hz
    _ < (2 ^ B.size) ^ k := Nat.pow_lt_pow_left hb (Nat.ne_of_gt hk)
    _ = 2 ^ (k * B.size) := by rw [← pow_mul, Nat.mul_comm]

/-- Stored integer coefficients have at most `kcap * size(kcap*V)` magnitude
bits. A signed encoding needs at most one additional sign bit. -/
theorem countNewtonTable_coeff_bits (c : ι → ℕ) (u : ι → σ →₀ ℕ)
    (Δ e : σ →₀ ℕ) (kcap V k : ℕ) (hkcap : 0 < kcap) (hVpos : 0 < V)
    (hc : ∀ i, c i ≤ kcap) (hV : Fintype.card ι ≤ V) (hk : k ≤ kcap) :
    (MvPolynomial.coeff e
      ((countNewtonTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap).getD k 0)).natAbs.size ≤
      kcap * (kcap * V).size := by
  obtain ⟨hnonneg, hbound⟩ := countNewtonTable_coeff_bound c u Δ e kcap V k hkcap hVpos hc hV hk
  apply nat_size_le_of_le_pow hkcap
  exact_mod_cast (show ((MvPolynomial.coeff e
    ((countNewtonTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap).getD k 0)).natAbs : ℤ) ≤
      ((kcap * V : ℕ) : ℤ) ^ kcap by
        rw [Int.natCast_natAbs, abs_of_nonneg hnonneg]
        exact hbound)

end
end Optss
