import Optss.FlooredDyadicBoxes

/-!
# Outer dyadic scale assembly for long sumsets

This module turns the genuine filled progression at the selected scale
into a progression containing the original input, with a proper filled
dilate proportional to the requested number of summands.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 1600000
local instance longSumsetScaleAssemblyDecEqInt : DecidableEq ℤ := Classical.decEq _
variable {d : ℕ}

/-- Rescale the coefficient box while retaining its actual integer map. -/
def rescaledCenteredProgression (P : CenteredProgression (Fin d) ℤ) (s : ℝ) (hs : 0 ≤ s) :
    CenteredProgression (Fin d) ℤ where
  lowerRadius j := s*P.lowerRadius j
  upperRadius j := s*P.upperRadius j
  lower_nonneg j := mul_nonneg hs (P.lower_nonneg j)
  upper_nonneg j := mul_nonneg hs (P.upper_nonneg j)
  map := P.map

theorem rescaledCenteredProgression_box (P : CenteredProgression (Fin d) ℤ)
    (s : ℝ) (hs : 0 ≤ s) (t : ℝ) :
    (rescaledCenteredProgression P s hs).coefficientBox t = P.coefficientBox (t*s) := by
  ext z
  simp only [CenteredProgression.mem_coefficientBox, rescaledCenteredProgression, mul_assoc]

theorem rescaledCenteredProgression_values (P : CenteredProgression (Fin d) ℤ)
    (s : ℝ) (hs : 0 ≤ s) (t : ℝ) :
    (rescaledCenteredProgression P s hs).values t = P.values (t*s) := by
  unfold CenteredProgression.values
  rw [rescaledCenteredProgression_box]
  rfl

theorem rescaledCenteredProgression_proper (P : CenteredProgression (Fin d) ℤ)
    (s : ℝ) (hs : 0 ≤ s) (t : ℝ) :
    (rescaledCenteredProgression P s hs).Proper t ↔ P.Proper (t*s) := by
  unfold CenteredProgression.Proper
  rw [rescaledCenteredProgression_box]
  rfl

/-- Repeated addition gives containment in the corresponding geometric
scale, without claiming equality for nonintegral endpoints. -/
theorem repeatedSumset_subset_scaled_progression (P : CenteredProgression (Fin d) ℤ)
    (A : Finset ℤ) (s : ℝ) (hs : 0 ≤ s) (hA : A ⊆ P.values s) (k : ℕ) :
    k • A ⊆ P.values ((k:ℝ)*s) := by
  let Q := rescaledCenteredProgression P s hs
  have hQ : A ⊆ Q.values 1 := by simpa only [Q, rescaledCenteredProgression_values, one_mul] using hA
  simpa only [Q, rescaledCenteredProgression_values] using Q.repeatedSumset_subset A hQ k

/-- Coercion to sets removes irrelevant choices of integer equality tests
from the concrete dyadic definition. -/
theorem dyadicSumset_eq_classical_nsmul (A : Finset ℤ) (j : ℕ) :
    dyadicSumset A j = (2^j:ℕ) • A := by
  apply Finset.coe_injective
  simp only [dyadicSumset, Finset.coe_nsmul]

/-- The entire containing profile follows from the single original-input
containment, at an exact reciprocal dyadic starting scale. -/
theorem dyadic_progression_containing_profile (P : CenteredProgression (Fin d) ℤ)
    (A : Finset ℤ) (j v : ℕ) (hvj : v ≤ j)
    (hA : A ⊆ P.values ((2:ℝ)^j)⁻¹) :
    ∀ k, dyadicSumset A (j-v+k) ⊆ P.values ((2:ℝ)^k*((2:ℝ)^v)⁻¹) := by
  intro k
  have hh := repeatedSumset_subset_scaled_progression P A ((2:ℝ)^j)⁻¹ (by positivity) hA
    (2^(j-v+k))
  rw [← dyadicSumset_eq_classical_nsmul] at hh
  have he : ((2^(j-v+k):ℕ):ℝ)*((2:ℝ)^j)⁻¹ = (2:ℝ)^k*((2:ℝ)^v)⁻¹ := by
    push_cast
    have hj : j = j-v+v := by omega
    conv_lhs => rw [hj]
    simp only [pow_add]
    field_simp
    ring
  simpa only [he] using hh

/-- All-scale filling gives a fixed additive offset between dyadic input
scales and the geometric progression scales. -/
theorem dyadic_progression_filling_profile (P : CenteredProgression (Fin d) ℤ)
    (A : Finset ℤ) (j v w N₀ : ℕ) (hvj : v ≤ j) (γ : ℝ)
    (hN : N₀ ≤ 2^w) (hs : ((2:ℝ)^v)⁻¹ ≤ γ*(2:ℝ)^w)
    (hfill : ∀ N : ℕ, N₀ ≤ N → ∃ z : ℤ,
      (P.values (γ*N)).image (z+·) ⊆ N • ((2^j:ℕ) • A)) :
    ∀ k, ∃ z : ℤ, (P.values ((2:ℝ)^k*((2:ℝ)^v)⁻¹)).image (z+·) ⊆
      dyadicSumset A (j-v+k+(v+w)) := by
  intro k
  have hN' : N₀ ≤ 2^(w+k) := hN.trans (Nat.pow_le_pow_right (by decide) (by omega))
  obtain ⟨z, hz⟩ := hfill (2^(w+k)) hN'
  refine ⟨z, ?_⟩
  have hscale : (2:ℝ)^k*((2:ℝ)^v)⁻¹ ≤ γ*(2^(w+k):ℕ) := by
    have hh := mul_le_mul_of_nonneg_left hs (show (0:ℝ) ≤ 2^k by positivity)
    push_cast
    rw [pow_add]
    nlinarith
  have hsub := (Finset.image_subset_image (P.values_mono hscale)).trans hz
  have he : (2^(w+k):ℕ) • ((2^j:ℕ) • A) = dyadicSumset A (j-v+k+(v+w)) := by
    rw [dyadicSumset_eq_classical_nsmul, ← mul_nsmul, ← pow_add]
    congr 2
    omega
  simpa only [he] using hsub

/-- Properness at the final window scale follows from the single original
containment and the actual all-summand filling family. -/
theorem filled_progression_proper_window
    (A : Finset ℤ) (hzero : 0 ∈ A) (a b q : ℕ) (hq : 0 < q) (hdq : d ≤ q)
    (hminimal : ∀ p < q, ∀ i, a ≤ i → i ≤ b →
      (3/2:ℝ)*2^p*(dyadicSumset A i).card < (dyadicSumset A (i+1)).card)
    (P : CenteredProgression (Fin d) ℤ) (hsym : P.lowerRadius = P.upperRadius)
    (j v w L N₀ : ℕ) (haj : a ≤ j) (hvj : v ≤ j)
    (hwidth : ∀ i, (2:ℝ)^j ≤ P.upperRadius i)
    (hproper : P.Proper ((2:ℝ)^v)⁻¹)
    (hA : A ⊆ P.values ((2:ℝ)^j)⁻¹) (γ : ℝ)
    (hN : N₀ ≤ 2^w) (hγ : 1 ≤ γ*(2:ℝ)^w)
    (hfill : ∀ N : ℕ, N₀ ≤ N → ∃ z : ℤ,
      (P.values (γ*N)).image (z+·) ⊆ N • ((2^j:ℕ) • A))
    (hlong : 2*(properizationIterationFactor latticeReductionDefectBound 3 d : ℝ)*
      (2:ℝ)^((v+w)*(d-1)) ≤ L) :
    P.Proper ((2:ℝ)^(b+1)/(2:ℝ)^(j+v+w+L)) := by
  have hs : 0 ≤ ((2:ℝ)^v)⁻¹ := by positivity
  have hwide : ∀ i, 1 ≤ ((2:ℝ)^v)⁻¹*P.upperRadius i := by
    intro i
    have hh := (pow_le_pow_right₀ (by norm_num : (1:ℝ) ≤ 2) hvj).trans (hwidth i)
    have hm := mul_le_mul_of_nonneg_left hh hs
    simpa only [inv_mul_cancel₀ (by positivity : (2:ℝ)^v ≠ 0)] using hm
  have hsmall : ((2:ℝ)^v)⁻¹ ≤ γ*(2:ℝ)^w :=
    (inv_le_one_of_one_le₀ (one_le_pow₀ (by norm_num))).trans hγ
  have hp := dyadic_progression_proper_endpoint A hzero a b q hq hdq hminimal P hsym
    (((2:ℝ)^v)⁻¹) hs hwide hproper (j-v) (v+w) L (by omega)
    (dyadic_progression_containing_profile P A j v hvj hA)
    (dyadic_progression_filling_profile P A j v w N₀ hvj γ hN hsmall hfill) hlong
  have he : ((2:ℝ)^(b+1)/(2:ℝ)^(j-v+(v+w)+L))*((2:ℝ)^v)⁻¹ =
      (2:ℝ)^(b+1)/(2:ℝ)^(j+v+w+L) := by
    have hje : j-v+(v+w)+L = j+w+L := by omega
    rw [hje]
    simp only [pow_add]
    field_simp
    ring
  simpa only [he] using hp

/-- Floor division loses at most a factor of two once one full block fits. -/
theorem nat_div_half_bound (h H : ℕ) (hH : 0 < H) (hHh : H ≤ h) :
    h ≤ 2*H*(h/H) := by
  have hN : 1 ≤ h/H := Nat.div_pos hHh hH
  have hh := Nat.lt_mul_div_succ h hH
  nlinarith

/-- Fill the final requested sumset using the actual integer quotient of
its summand budget by the selected dyadic block size. -/
theorem filled_progression_final_sumset (P : CenteredProgression (Fin d) ℤ)
    (A : Finset ℤ) (hzero : 0 ∈ A) (H h N₀ : ℕ) (hH : 0 < H) (hHh : H ≤ h)
    (hN : N₀*H ≤ h) (γ c : ℝ) (hγ : 0 ≤ γ) (hc : c ≤ γ/2)
    (hfill : ∀ N : ℕ, N₀ ≤ N → ∃ z : ℤ,
      (P.values (γ*N)).image (z+·) ⊆ N • (H • A)) :
    ∃ z : ℤ, (P.values ((c*h)*(H:ℝ)⁻¹)).image (z+·) ⊆ h • A := by
  let N := h/H
  have hN₀ : N₀ ≤ N := (Nat.le_div_iff_mul_le hH).mpr hN
  obtain ⟨z, hz⟩ := hfill N hN₀
  refine ⟨z, ?_⟩
  have hHreal : (0:ℝ) < H := by exact_mod_cast hH
  have hquot : (h:ℝ)/(H:ℝ) ≤ 2*N := by
    apply (div_le_iff₀ hHreal).mpr
    have hh : (h:ℝ) ≤ 2*H*N := by exact_mod_cast nat_div_half_bound h H hH hHh
    nlinarith
  have hscale : (c*h)*(H:ℝ)⁻¹ ≤ γ*N := by
    calc
      _ = c*((h:ℝ)/(H:ℝ)) := by rw [div_eq_mul_inv]; ring
      _ ≤ (γ/2)*((h:ℝ)/(H:ℝ)) := mul_le_mul_of_nonneg_right hc (by positivity)
      _ ≤ (γ/2)*(2*N) := mul_le_mul_of_nonneg_left hquot (by positivity)
      _ = _ := by ring
  have hsub := (Finset.image_subset_image (P.values_mono hscale)).trans hz
  have hbudget : N • (H • A) ⊆ h • A := by
    rw [← mul_nsmul]
    exact Finset.nsmul_subset_nsmul_right hzero (Nat.mul_div_le h H)
  exact hsub.trans hbudget

/-- Exact power arithmetic translating the proper window endpoint into a
constant fraction of the final summand budget. -/
theorem long_sumset_final_scale_le (j b m v w L h : ℕ) (c : ℝ)
    (hc : c ≤ ((2:ℝ)^(m+1+v+w+L))⁻¹)
    (hh : (h:ℝ) ≤ (2:ℝ)^(b+m+2)) :
    (c*h)*((2:ℝ)^j)⁻¹ ≤ (2:ℝ)^(b+1)/(2:ℝ)^(j+v+w+L) := by
  calc
    _ ≤ (((2:ℝ)^(m+1+v+w+L))⁻¹*h)*((2:ℝ)^j)⁻¹ :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hc (by positivity)) (by positivity)
    _ ≤ (((2:ℝ)^(m+1+v+w+L))⁻¹*(2:ℝ)^(b+m+2))*((2:ℝ)^j)⁻¹ :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hh (by positivity)) (by positivity)
    _ = _ := by
      simp only [pow_add]
      norm_num
      field_simp
      ring

end
end Optss
