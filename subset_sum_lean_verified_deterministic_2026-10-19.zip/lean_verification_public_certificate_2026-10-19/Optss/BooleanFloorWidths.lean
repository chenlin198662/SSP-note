import Optss.BooleanVertexWidths
import Optss.ThinLatticeBoxing

/-!
# Boolean floor widths for thin lattice bodies

Floor widths may vanish. They retain exactly the coordinate bounds needed
for lattice points even when the body contains no independent lattice family.
The finite maximum, signed division, and payload copying are actual Boolean
list operations; their complete source charges depend only on stored inputs.
-/
namespace Optss
variable {r m : ℕ}

def bitFractionNatFloor (p : BitListFraction) : List Bool :=
  let out := bitListFractionFloor (listCopyFraction p)
  if out.1 then [] else bitWordCopy out.2

def bitFractionNatFloorWork (p : BitListFraction) : ℕ :=
  let q := listCopyFraction p
  let out := bitListFractionFloor q
  listCopyFractionWork p+bitListFractionFloorCost q+
    (if out.1 then 1 else bitWordCopyWork out.2)+3

theorem bitFractionNatFloor_value (p : BitListFraction)
    (hp : 0<binaryDigitsValue p.denominator) :
    binaryDigitsValue (bitFractionNatFloor p)=⌊bitListFractionValue p⌋₊ := by
  have hf := bitListFractionFloor_correct p hp
  rw [←Int.floor_toNat,←hf]
  simp only [bitFractionNatFloor,listCopyFraction_eq]
  split_ifs with hs <;> simp [signedBitsValue,hs,bitWordCopy_eq,binaryDigitsValue]

theorem bitFractionNatFloor_canonical (p : BitListFraction)
    (hp : 0<binaryDigitsValue p.denominator) : BitListCanonical (bitFractionNatFloor p) := by
  simp only [bitFractionNatFloor,listCopyFraction_eq]
  split_ifs
  · simp [BitListCanonical,binaryDigitsValue]
  · rw [bitWordCopy_eq]
    exact bitListFractionFloor_canonical p hp

theorem bitFractionNatFloor_length (p : BitListFraction) (hp : p.WellFormed) :
    (bitFractionNatFloor p).length≤p.numerator.length := by
  have hval : (bitListFractionValue p).num.natAbs.size=p.numerator.length := by
    rw [←p.toRat_value hp]
    change (signedBitsValue p.negative p.numerator).natAbs.size=p.numerator.length
    rw [signedBitsValue_natAbs]
    exact hp.1.length.symm
  rw [(bitFractionNatFloor_canonical p hp.2.2.1).length,bitFractionNatFloor_value p hp.2.2.1]
  exact (Nat.size_le_size ((Nat.floor_le_ceil _).trans (rationalNatCeil_le_num _))).trans_eq hval

theorem bitFractionNatFloorWork_bound (p : BitListFraction)
    (hp : 0<binaryDigitsValue p.denominator) (L : ℕ)
    (hbits : p.numerator.length≤L ∧ p.denominator.length≤L) :
    bitFractionNatFloorWork p≤128*(L+1)^2 := by
  have hf := bitListFractionFloorCost_bound p hp L hbits
  have hl := (bitListFractionFloor_length p).trans (Nat.add_le_add_right hbits.1 2)
  unfold bitFractionNatFloorWork
  simp only [listCopyFraction_eq]
  split_ifs <;> simp only [listCopyFractionWork_eq,fractionPayload,bitWordCopyWork_eq] <;> nlinarith

def booleanVertexFloorWidth (ps : List BitListFraction) : List Bool :=
  bitFractionNatFloor (booleanAbsoluteMaximum ps)

def booleanVertexFloorWidthWork (ps : List BitListFraction) : ℕ :=
  booleanAbsoluteMaximumWork ps+bitFractionNatFloorWork (booleanAbsoluteMaximum ps)+1

theorem booleanVertexFloorWidth_value (ps : List BitListFraction)
    (hp : ∀ p∈ps,p.WellFormed) :
    binaryDigitsValue (booleanVertexFloorWidth ps)=
      ⌊rationalMaximum (ps.map fun p => |bitListFractionValue p|)⌋₊ := by
  rw [booleanVertexFloorWidth,bitFractionNatFloor_value _
    (booleanAbsoluteMaximum_wellFormed ps hp).2.2.1,booleanAbsoluteMaximum_value ps hp]

theorem booleanVertexFloorWidth_canonical (ps : List BitListFraction)
    (hp : ∀ p∈ps,p.WellFormed) : BitListCanonical (booleanVertexFloorWidth ps) :=
  bitFractionNatFloor_canonical _ (booleanAbsoluteMaximum_wellFormed ps hp).2.2.1

theorem booleanVertexFloorWidth_length (ps : List BitListFraction)
    (hp : ∀ p∈ps,p.WellFormed) (L : ℕ) (hL : 0<L)
    (hbits : ∀ p∈ps,p.numerator.length≤L ∧ p.denominator.length≤L) :
    (booleanVertexFloorWidth ps).length≤L :=
  (bitFractionNatFloor_length _ (booleanAbsoluteMaximum_wellFormed ps hp)).trans
    (booleanAbsoluteMaximum_lengths ps L hL hbits).1

theorem booleanVertexFloorWidthWork_bound (ps : List BitListFraction)
    (hp : ∀ p∈ps,p.WellFormed) (L : ℕ) (hL : 0<L)
    (hbits : ∀ p∈ps,p.numerator.length≤L ∧ p.denominator.length≤L) :
    booleanVertexFloorWidthWork ps≤(ps.length+2)*1024*(L+1)^2 := by
  have hm := booleanAbsoluteMaximumWork_bound ps L hL hbits
  have hc := bitFractionNatFloorWork_bound _ (booleanAbsoluteMaximum_wellFormed ps hp).2.2.1
    L (booleanAbsoluteMaximum_lengths ps L hL hbits)
  unfold booleanVertexFloorWidthWork
  nlinarith

def rationalVertexFloorWidth (M : Matrix (Fin r) (Fin r) ℚ)
    (V : Fin m → Fin r → ℚ) (j : Fin r) : ℕ := ⌊rationalVertexRadius M V j⌋₊

theorem booleanVertexFloorWidth_coordinate_value
    (M : Matrix (Fin r) (Fin r) ℚ) (V : Fin m → Fin r → ℚ)
    (C : Fin m → BitListFraction) (hC : ∀ i,(C i).WellFormed) (j : Fin r)
    (hvalue : ∀ i,bitListFractionValue (C i)=(M.mulVec (V i)) j) :
    binaryDigitsValue (booleanVertexFloorWidth (List.ofFn C))=rationalVertexFloorWidth M V j := by
  rw [booleanVertexFloorWidth_value _ (by
    intro q hq; obtain ⟨i,rfl⟩ := List.mem_ofFn.mp hq; exact hC i)]
  simp only [List.map_ofFn,Function.comp_def,hvalue,rationalVertexFloorWidth,rationalVertexRadius]

theorem rationalNatFloor_cast (q : ℚ) : ⌊(q:ℝ)⌋₊=⌊q⌋₊ := by
  by_cases hq : 0≤q
  · apply le_antisymm
    · apply Nat.le_floor
      exact_mod_cast Nat.floor_le (show 0≤(q:ℝ) by exact_mod_cast hq)
    · apply Nat.le_floor
      exact_mod_cast Nat.floor_le hq
  · rw [Nat.floor_of_nonpos (le_of_not_ge hq),Nat.floor_of_nonpos]
    exact_mod_cast le_of_not_ge hq

theorem rationalCofactor_floorWidth_eq_basisFloorWidth
    (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (A : Matrix (Fin r) (Fin r) ℚ) (hA : ∀ i j,(A i j:ℝ)=b j i)
    (V : Fin m → Fin r → ℚ) (hm : 0<m)
    (hK : IsCompact (convexHull ℝ (rationalVertexSet V : Set (Fin r → ℝ))))
    (hne : (convexHull ℝ (rationalVertexSet V : Set (Fin r → ℝ))).Nonempty)
    (j : Fin r) :
    rationalVertexFloorWidth (rationalCofactorInverse A) V j=
      basisFloorWidth b (convexHull ℝ (rationalVertexSet V : Set _)) hK hne j := by
  unfold basisFloorWidth
  rw [←rationalVertexRadius_eq_basisCoordinateRadius b _ V hm
    (rationalCofactorInverse_basis_coordinates b A hA V) hK hne j,rationalNatFloor_cast]
  rfl
end Optss
