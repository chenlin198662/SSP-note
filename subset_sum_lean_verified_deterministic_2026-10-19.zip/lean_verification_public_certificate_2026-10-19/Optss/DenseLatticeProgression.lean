import Optss.DenseLatticeBoxing
import Optss.Progression

/-!
# Dense generated-lattice filling as an actual proper GAP

The progression has one fixed integer additive encoding, generating exactly
the input subgroup. Its real geometric dilates, including all floor effects,
are contained in actual repeated sumsets after translation.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 800000
variable {d : ℕ}

def subgroupBasisProgression (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (n : Fin d → ℕ) : CenteredProgression (Fin d) (IntVec d) where
  lowerRadius j := n j
  upperRadius j := n j
  lower_nonneg j := Nat.cast_nonneg _
  upper_nonneg j := Nat.cast_nonneg _
  map := subgroupBasisSynthesisHom Γ b hΛ

theorem mem_smul_basisCoefficientBox_iff (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (n : Fin d → ℕ) (a : ℝ) (ha : 0 < a) (x : Fin d → ℝ) :
    x ∈ a • basisCoefficientBox b n ↔ ∀ j, |b.equivFun x j| ≤ a * n j := by
  constructor
  · rintro ⟨y, hy, rfl⟩ j
    change ∀ j, |b.equivFun y j| ≤ (n j : ℝ) at hy
    simpa only [map_smul, Pi.smul_apply, smul_eq_mul, abs_mul, abs_of_pos ha] using
      mul_le_mul_of_nonneg_left (hy j) ha.le
  · intro hx
    refine ⟨a⁻¹ • x, ?_, ?_⟩
    · change ∀ j, |b.equivFun (a⁻¹ • x) j| ≤ (n j : ℝ)
      intro j
      simp only [map_smul, Pi.smul_apply, smul_eq_mul, abs_mul, abs_inv, abs_of_pos ha]
      exact (inv_mul_le_iff₀ ha).mpr (hx j)
    · change a • (a⁻¹ • x) = x
      rw [smul_smul, mul_inv_cancel₀ ha.ne', one_smul]

/-- Exact real-dilation semantics, using the entire subgroup rather than a
possibly smaller generated sublattice. -/
theorem subgroupBasisProgression_mem (Γ : AddSubgroup (IntVec d))
    (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (n : Fin d → ℕ) (a : ℝ) (ha : 0 < a) (x : IntVec d) :
    x ∈ (subgroupBasisProgression Γ b hΛ n).values a ↔
      x ∈ Γ ∧ realVector x ∈ a • basisCoefficientBox b n := by
  rw [CenteredProgression.mem_values]
  constructor
  · rintro ⟨z, hz, rfl⟩
    refine ⟨subgroupBasisSynthesis_mem Γ b hΛ z, ?_⟩
    rw [mem_smul_basisCoefficientBox_iff b n a ha]
    rw [CenteredProgression.mem_coefficientBox] at hz
    intro j
    change |b.equivFun (realVector (subgroupBasisSynthesisHom Γ b hΛ z)) j| ≤ _
    rw [subgroupBasisSynthesisHom_cast, LinearEquiv.apply_symm_apply]
    exact abs_le.mpr (hz j)
  · rintro ⟨hx, hxbox⟩
    have hrange : x ∈ (subgroupBasisSynthesisHom Γ b hΛ).range := by
      rwa [subgroupBasisSynthesisHom_range]
    obtain ⟨z, rfl⟩ := hrange
    refine ⟨z, ?_, rfl⟩
    rw [CenteredProgression.mem_coefficientBox]
    rw [mem_smul_basisCoefficientBox_iff b n a ha,
      subgroupBasisSynthesisHom_cast, LinearEquiv.apply_symm_apply] at hxbox
    intro j
    exact abs_le.mp (hxbox j)

def denseLatticeOuterScale (d : ℕ) : ℕ := 4 * ⌈denseLatticeBoxingConstant d⌉₊

theorem denseLatticeOuterScale_pos (hd : 0 < d) : 0 < denseLatticeOuterScale d := by
  have h := Nat.ceil_pos.mpr (denseLatticeBoxingConstant_pos hd)
  unfold denseLatticeOuterScale
  omega

/-- A centered bounded set fits in an actual integer translate of the
specified dilation of the original box, including endpoint rounding. -/
theorem centered_set_subset_translated_box (C : ℝ) (hC : 0 < C)
    (W : Fin d → ℕ) (hW : ∀ j, 2 ≤ W j) (lo : IntVec d)
    (P : Finset (IntVec d)) (hP : ∀ x ∈ P, ∀ j, |(x j : ℝ)| ≤ C * W j) :
    ∃ t : IntVec d, P ⊆ fillingIntegerBox
      (fun j => t j + (4 * ⌈C⌉₊ : ℕ) * lo j)
      (fun j => t j + (4 * ⌈C⌉₊ : ℕ) * (lo j + W j - 1)) := by
  let K := ⌈C⌉₊
  refine ⟨fun j => -(K : ℤ) * W j - (4 * K : ℕ) * lo j, ?_⟩
  intro x hx
  rw [mem_fillingIntegerBox]
  intro j
  have hreal : |(x j : ℝ)| ≤ (K : ℝ) * W j := (hP x hx j).trans
    (mul_le_mul_of_nonneg_right (Nat.le_ceil C) (Nat.cast_nonneg _))
  have hint : |x j| ≤ (K : ℤ) * W j := by exact_mod_cast hreal
  obtain ⟨hl, hu⟩ := abs_le.mp hint
  have hw : (2 : ℤ) ≤ W j := by exact_mod_cast hW j
  have hK : (0 : ℤ) ≤ K := by positivity
  dsimp
  change -(K : ℤ) * W j - (4 * K : ℕ) * lo j + (4 * K : ℕ) * lo j ≤ x j ∧
    x j ≤ -(K : ℤ) * W j - (4 * K : ℕ) * lo j +
      (4 * K : ℕ) * (lo j + W j - 1)
  push_cast
  constructor <;> nlinarith

/-- CFP Lemma 2.16, with explicit uniform constants, the original box
intersection, an injective integer encoding, and every large geometric dilate.
The original widths here count integer positions, so their endpoint difference
is `W j - 1`. -/
theorem dense_generated_lattice_progression (hd : 0 < d) (c : ℝ)
    (hc : 0 < c) (hc1 : c ≤ 1) (A : Finset (IntVec d))
    (lo : IntVec d) (W : Fin d → ℕ)
    (hW : ∀ j, denseBoxWidthThreshold c ≤ W j)
    (hbox : A ⊆ fillingIntegerBox lo (fun j => lo j + W j - 1))
    (hdense : c * (fillingIntegerBox lo (fun j => lo j + W j - 1)).card ≤ A.card)
    (hzero : 0 ∈ A) :
    ∃ P : CenteredProgression (Fin d) (IntVec d),
      Function.Injective P.map ∧ P.map.range = AddSubgroup.closure (A : Set (IntVec d)) ∧
      (∀ j, P.lowerRadius j = P.upperRadius j ∧ 1 ≤ P.lowerRadius j) ∧
      (∀ x ∈ fillingIntegerBox lo (fun j => lo j + W j - 1),
        x ∈ AddSubgroup.closure (A : Set (IntVec d)) → x ∈ P.values 1) ∧
      (∃ t : IntVec d, P.values 1 ⊆ fillingIntegerBox
        (fun j => t j + (denseLatticeOuterScale d : ℤ) * lo j)
        (fun j => t j + (denseLatticeOuterScale d : ℤ) * (lo j + W j - 1))) ∧
      ∀ N : ℕ, denseBoxSummandThreshold d c ≤ N →
        ∃ z ∈ AddSubgroup.closure (A : Set (IntVec d)),
          (P.values (denseLatticeFillingDilation d c * N)).image (z + ·) ⊆ N • A := by
  obtain ⟨b, hb, n, hn, hinner, houter, hfill⟩ := dense_generated_lattice_boxing hd c hc hc1
    A lo W hW hbox hdense hzero
  let Γ := AddSubgroup.closure (A : Set (IntVec d))
  let P := subgroupBasisProgression Γ b hb n
  have hmem := subgroupBasisProgression_mem Γ b hb n
  have hW2 : ∀ j, 2 ≤ W j := by
    intro j
    have hw := (denseBoxWidthThreshold_spec c hc _ (hW j)).2
    have hmul := mul_le_mul_of_nonneg_right hc1 (Nat.cast_nonneg (W j) : (0 : ℝ) ≤ W j)
    have hh : (2 : ℝ) ≤ W j := by linarith
    exact_mod_cast hh
  refine ⟨P, subgroupBasisSynthesisHom_injective Γ b hb,
    subgroupBasisSynthesisHom_range Γ b hb,
    fun j => ⟨rfl, by
      change (1 : ℝ) ≤ (n j : ℝ)
      exact_mod_cast hn j⟩, ?_, ?_, ?_⟩
  · intro x hx hxΓ
    apply (hmem 1 zero_lt_one x).mpr
    refine ⟨hxΓ, ?_⟩
    rw [one_smul]
    apply hinner
    rw [mem_realCoefficientBox]
    intro j
    have hj := (mem_fillingIntegerBox _ _ _).mp hx j
    have hz := (mem_fillingIntegerBox _ _ _).mp (hbox hzero) j
    simp only [Pi.zero_apply] at hz
    have ha : |x j| ≤ (W j : ℤ) := by rw [abs_le]; constructor <;> omega
    change |(x j : ℝ)| ≤ (W j : ℝ)
    exact_mod_cast ha
  · apply centered_set_subset_translated_box _ (denseLatticeBoxingConstant_pos hd) W hW2 lo
    intro x hx
    have hh := (hmem 1 zero_lt_one x).mp hx
    rw [one_smul] at hh
    exact mem_smul_realCoefficientBox_bound W _ (denseLatticeBoxingConstant_pos hd).le _
      (houter hh.2)
  · intro N hN
    obtain ⟨z, hz, hfillN⟩ := hfill N hN
    refine ⟨z, hz, ?_⟩
    intro y hy
    obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hy
    have hNpos : 0 < N := by
      apply Nat.pos_of_ne_zero
      intro hNzero
      have hh := denseBoxSummandThreshold_dilation_lower d hd c hc N hN
      simp only [hNzero, Nat.cast_zero, mul_zero] at hh
      have hp : (0 : ℝ) < 2 * ((denseBoxReserveSize d c : ℝ) + 1) := by positivity
      linarith
    obtain ⟨hxΓ, hxbox⟩ := (hmem _ (mul_pos (denseLatticeFillingDilation_pos hd c hc)
      (by exact_mod_cast hNpos)) x).mp hx
    exact hfillN x hxΓ hxbox

end
end Optss
