import Optss.LongSumsetScales
import Mathlib.Tactic

/-!
# Minimal dyadic growth rank and its lower growth profile

The rank is selected from the actual sumset cardinalities. The threshold
`(3/2) * 2^q` lies strictly between adjacent powers of two, so minimality
forces a fixed growth factor above degree `q-1` throughout the window.
This supplies the rank-adaptive step of CFP Lemma 2.22.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 1000000

/-- A rank candidate is witnessed by one actual adjacent dyadic sumset. -/
def dyadicRankCandidate (A : Finset ℤ) (a b q : ℕ) : Prop :=
  ∃ j, a ≤ j ∧ j ≤ b ∧
    ((dyadicSumset A (j+1)).card:ℝ) ≤ (3/2:ℝ)*2^q*(dyadicSumset A j).card

/-- A rough small-doubling witness produces a least rank candidate and
strict lower growth at every scale for all smaller ranks. -/
theorem dyadic_minimal_rank_selection (A : Finset ℤ) (a b R : ℕ)
    (hrough : ∃ j, a ≤ j ∧ j ≤ b ∧
      ((dyadicSumset A (j+1)).card:ℝ) ≤ (2:ℝ)^R*(dyadicSumset A j).card) :
    ∃ q ≤ R, ∃ j, a ≤ j ∧ j ≤ b ∧
      ((dyadicSumset A (j+1)).card:ℝ) ≤ (3/2:ℝ)*2^q*(dyadicSumset A j).card ∧
      (∀ p < q, ∀ i, a ≤ i → i ≤ b →
        (3/2:ℝ)*2^p*(dyadicSumset A i).card < (dyadicSumset A (i+1)).card) := by
  have hR : dyadicRankCandidate A a b R := by
    obtain ⟨j, haj, hjb, hj⟩ := hrough
    refine ⟨j, haj, hjb, hj.trans ?_⟩
    have hp : (0:ℝ) ≤ 2^R*(dyadicSumset A j).card := by positivity
    nlinarith
  have hex : ∃ q, dyadicRankCandidate A a b q := ⟨R, hR⟩
  let q := Nat.find hex
  obtain ⟨j, haj, hjb, hstep⟩ := Nat.find_spec hex
  refine ⟨q, Nat.find_min' hex hR, j, haj, hjb, hstep, ?_⟩
  intro p hp i hai hib
  apply lt_of_not_ge
  intro hbad
  exact Nat.find_min hex hp ⟨i, hai, hib, hbad⟩

/-- Telescoping strict real growth. This uses actual sequence values, with
no assumption about an eventual geometric growth consequence. -/
theorem real_step_growth_product (f : ℕ → ℝ) (κ : ℝ) (hκ : 0 < κ) (a L : ℕ)
    (hstep : ∀ i, a ≤ i → i < a+L → κ*f i < f (i+1)) :
    κ^L*f a ≤ f (a+L) ∧ (0 < L → κ^L*f a < f (a+L)) := by
  induction L with
  | zero => simp
  | succ L ih =>
    obtain ⟨hprev, _⟩ := ih (fun i hi hi' => hstep i hi (by omega))
    have hlast := hstep (a+L) (by omega) (by omega)
    have hmul := mul_le_mul_of_nonneg_left hprev hκ.le
    have hstrict : κ^(L+1)*f a < f (a+(L+1)) := by
      simpa only [pow_succ, Nat.add_assoc, mul_assoc, mul_left_comm, mul_comm]
        using hmul.trans_lt hlast
    exact ⟨hstrict.le, fun _ => hstrict⟩

/-- The selected positive rank yields the lower profile used to exclude
loss of properness at a substantially earlier scale. -/
theorem dyadic_minimal_rank_growth (A : Finset ℤ) (a b q : ℕ) (hq : 0 < q)
    (hminimal : ∀ p < q, ∀ i, a ≤ i → i ≤ b →
      (3/2:ℝ)*2^p*(dyadicSumset A i).card < (dyadicSumset A (i+1)).card)
    (u k : ℕ) (hau : a ≤ u) (huk : u+k ≤ b+1) :
    ((3/2:ℝ)*2^(q-1))^k*(dyadicSumset A u).card ≤ (dyadicSumset A (u+k)).card := by
  exact (real_step_growth_product (fun i => (dyadicSumset A i).card)
    ((3/2:ℝ)*2^(q-1)) (by positivity) u k
    (fun i hui hik => hminimal (q-1) (by omega) i (by omega) (by omega))).1

/-- The chosen upper ratio leaves a definite gap below `2^(q+1)`, as
required by the genuine refined-rank theorem. -/
theorem dyadic_selected_rank_strict_gap (A : Finset ℤ) (hzero : 0 ∈ A) (q j : ℕ)
    (hstep : ((dyadicSumset A (j+1)).card:ℝ) ≤ (3/2:ℝ)*2^q*(dyadicSumset A j).card) :
    ((dyadicSumset A j + dyadicSumset A j).card:ℝ) <
      ((2:ℝ)^(q+1)-(2:ℝ)^q/4)*(dyadicSumset A j).card := by
  have hpos : (0:ℝ) < (dyadicSumset A j).card := by
    exact_mod_cast (Finset.card_pos.mpr ⟨0, zero_mem_integer_repeated_sumset A hzero _⟩)
  rw [dyadicSumset_succ] at hstep
  have hp : (0:ℝ) < 2^q := by positivity
  rw [pow_succ]
  nlinarith

/-- Polynomial-scale inputs admit a minimal rank over the full logarithmic
window, so the lower growth profile extends to a scale comparable to `h`. -/
theorem dyadic_minimal_rank_at_polynomial_scale (A : Finset ℤ) (N h B a : ℕ)
    (hA : A ⊆ Finset.Icc 0 (N:ℤ)) (hzero : 0 ∈ A)
    (hpoly : N+1 ≤ h^B) (hlarge : 2^(2*max 1 a) ≤ h) :
    ∃ q ≤ 4*B+2, ∃ j, a ≤ j ∧ j+1 ≤ Nat.log 2 h ∧
      ((dyadicSumset A (j+1)).card:ℝ) ≤ (3/2:ℝ)*2^q*(dyadicSumset A j).card ∧
      (∀ p < q, ∀ i, a ≤ i → i+1 ≤ Nat.log 2 h →
        (3/2:ℝ)*2^p*(dyadicSumset A i).card < (dyadicSumset A (i+1)).card) := by
  obtain ⟨j, haj, hjh, hstep⟩ := exists_polynomial_scale_small_doubling A N h B a hA hzero hpoly hlarge
  have hjlog : j+1 ≤ Nat.log 2 h := Nat.le_log_of_pow_le (by decide) hjh
  have hbpos : 1 ≤ Nat.log 2 h := by omega
  have hrough : ∃ j, a ≤ j ∧ j ≤ Nat.log 2 h-1 ∧
      ((dyadicSumset A (j+1)).card:ℝ) ≤ (2:ℝ)^(4*B+2)*(dyadicSumset A j).card := by
    refine ⟨j, haj, by omega, ?_⟩
    rw [dyadicSumset_succ]
    exact_mod_cast hstep
  obtain ⟨q, hq, j, haj, hjb, hstep, hmin⟩ :=
    dyadic_minimal_rank_selection A a (Nat.log 2 h-1) (4*B+2) hrough
  exact ⟨q, hq, j, haj, by omega, hstep, fun p hp i hai hi => hmin p hp i hai (by omega)⟩

/-- A fixed margin at the end of the window reserves enough summands for
the final filling step. The margin changes only the largeness threshold. -/
theorem dyadic_minimal_rank_at_polynomial_scale_margin (A : Finset ℤ) (N h B a m : ℕ)
    (hA : A ⊆ Finset.Icc 0 (N:ℤ)) (hzero : 0 ∈ A)
    (hpoly : N+1 ≤ h^B) (hlarge : 2^(2*max 1 (a+m)) ≤ h) :
    ∃ q ≤ 4*B+2, ∃ j, a ≤ j ∧ j+1+m ≤ Nat.log 2 h ∧
      ((dyadicSumset A (j+1)).card:ℝ) ≤ (3/2:ℝ)*2^q*(dyadicSumset A j).card ∧
      (∀ p < q, ∀ i, a ≤ i → i+1+m ≤ Nat.log 2 h →
        (3/2:ℝ)*2^p*(dyadicSumset A i).card < (dyadicSumset A (i+1)).card) := by
  let L := Nat.log 2 h / 2
  have hh : h ≠ 0 := by have := Nat.two_pow_pos (2*max 1 (a+m)); omega
  have hlog : 2*max 1 (a+m) ≤ Nat.log 2 h := Nat.le_log_of_pow_le (by decide) hlarge
  have hL : 1 ≤ L := by dsimp [L]; omega
  have ham : a+m ≤ L := by dsimp [L]; omega
  have hlogL : Nat.log 2 h+1 ≤ 4*L := by dsimp [L]; omega
  have hN : N+1 ≤ 2^((4*B)*L) := by
    calc
      N+1 ≤ h^B := hpoly
      _ ≤ (2^(Nat.log 2 h+1))^B := Nat.pow_le_pow_left (Nat.lt_pow_succ_log_self (by decide) h).le _
      _ = 2^((Nat.log 2 h+1)*B) := (pow_mul _ _ _).symm
      _ ≤ 2^((4*B)*L) := Nat.pow_le_pow_right (by decide) (by nlinarith)
  obtain ⟨j, haj, hj, hstep⟩ := exists_dyadic_small_doubling A N a L (4*B)
    hA hzero (by omega) (by omega) hN
  have hjlog : j+1+m ≤ Nat.log 2 h := by dsimp [L] at *; omega
  have hrough : ∃ j, a ≤ j ∧ j ≤ Nat.log 2 h-m-1 ∧
      ((dyadicSumset A (j+1)).card:ℝ) ≤ (2:ℝ)^(4*B+2)*(dyadicSumset A j).card := by
    refine ⟨j, haj, by omega, ?_⟩
    rw [dyadicSumset_succ]
    exact_mod_cast hstep
  obtain ⟨q, hq, j, haj, hjb, hstep, hmin⟩ :=
    dyadic_minimal_rank_selection A a (Nat.log 2 h-m-1) (4*B+2) hrough
  have hm : m+1 ≤ Nat.log 2 h := by omega
  exact ⟨q, hq, j, haj, by omega, hstep,
    fun p hp i hai hi => hmin p hp i hai (by omega)⟩

end
end Optss
