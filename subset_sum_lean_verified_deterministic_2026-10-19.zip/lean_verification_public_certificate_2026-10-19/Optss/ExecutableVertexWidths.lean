import Optss.RationalMatrixBounds
import Optss.LatticeBoxingGeometry
import Mathlib.Data.Rat.Floor

/-!
# Finite rational vertex scans compute the geometric boxing widths

The routines scan the actual rational vertices, take absolute coordinate
maxima and then natural ceilings. For an actual basis-coordinate matrix,
these values equal the compact convex hull maxima and integer widths used
by the lattice-boxing geometry. The empty input scan is defined as zero;
attainment and equality to the nonempty-body construction require a vertex.
-/
namespace Optss
open scoped BigOperators
variable {r m : ℕ}

/-- Deterministic finite maximum with a zero initial value. -/
def rationalMaximum : List ℚ → ℚ
  | [] => 0
  | q::qs => max q (rationalMaximum qs)

theorem rationalMaximum_nonneg (qs : List ℚ) : 0≤rationalMaximum qs := by
  induction qs with
  | nil => rfl
  | cons q qs ih => exact ih.trans (le_max_right _ _)

theorem rationalMaximum_mem_le (qs : List ℚ) {q : ℚ} (hq : q∈qs) :
    q≤rationalMaximum qs := by
  induction qs with
  | nil => simp at hq
  | cons a qs ih =>
    rcases List.mem_cons.mp hq with hq | hq
    · subst q; exact le_max_left _ _
    · exact (ih hq).trans (le_max_right _ _)

theorem rationalMaximum_mem (qs : List ℚ) (hne : qs≠[])
    (hq : ∀ q∈qs,0≤q) : rationalMaximum qs∈qs := by
  induction qs with
  | nil => exact False.elim (hne rfl)
  | cons q qs ih =>
    by_cases he : qs=[]
    · subst qs
      simp [rationalMaximum,max_eq_left (hq q (by simp))]
    · have ht := ih he (fun a ha => hq a (List.mem_cons_of_mem _ ha))
      rw [rationalMaximum]
      by_cases hc : q≤rationalMaximum qs
      · rw [max_eq_right hc]; exact List.mem_cons_of_mem _ ht
      · rw [max_eq_left (le_of_not_ge hc)]; exact List.mem_cons_self

theorem RationalBitBound.abs {q : ℚ} {L : ℕ} (h : RationalBitBound q L) :
    RationalBitBound |q| L := by
  rcases le_total 0 q with hq | hq
  · simpa only [abs_of_nonneg hq] using h
  · simpa only [abs_of_nonpos hq] using h.neg

theorem rationalMaximum_bits (qs : List ℚ) (L : ℕ) (hL : 0<L)
    (hqs : ∀ q∈qs,RationalBitBound q L) :
    RationalBitBound (rationalMaximum qs) L := by
  induction qs with
  | nil => simpa [rationalMaximum,RationalBitBound] using hL
  | cons q qs ih =>
    rw [rationalMaximum]
    by_cases hc : q≤rationalMaximum qs
    · rw [max_eq_right hc]
      exact ih (fun a ha => hqs a (List.mem_cons_of_mem _ ha))
    · rw [max_eq_left (le_of_not_ge hc)]
      exact hqs q (List.mem_cons_self)

/-- Rational basis-coordinate radius from the actual finite vertex family. -/
def rationalVertexRadius (M : Matrix (Fin r) (Fin r) ℚ)
    (V : Fin m → Fin r → ℚ) (j : Fin r) : ℚ :=
  rationalMaximum (List.ofFn fun i : Fin m => |(M.mulVec (V i)) j|)

def rationalVertexWidth (M : Matrix (Fin r) (Fin r) ℚ)
    (V : Fin m → Fin r → ℚ) (j : Fin r) : ℕ :=
  ⌈rationalVertexRadius M V j⌉₊

theorem rationalVertexRadius_nonneg (M : Matrix (Fin r) (Fin r) ℚ)
    (V : Fin m → Fin r → ℚ) (j : Fin r) : 0≤rationalVertexRadius M V j :=
  rationalMaximum_nonneg _

theorem rationalVertexRadius_le (M : Matrix (Fin r) (Fin r) ℚ)
    (V : Fin m → Fin r → ℚ) (i : Fin m) (j : Fin r) :
    |(M.mulVec (V i)) j|≤rationalVertexRadius M V j :=
  rationalMaximum_mem_le _ (List.mem_ofFn.mpr ⟨i,rfl⟩)

theorem rationalVertexRadius_attained (M : Matrix (Fin r) (Fin r) ℚ)
    (V : Fin m → Fin r → ℚ) (hm : 0<m) (j : Fin r) :
    ∃ i,|(M.mulVec (V i)) j|=rationalVertexRadius M V j := by
  have hmem := rationalMaximum_mem (List.ofFn fun i : Fin m => |(M.mulVec (V i)) j|)
    (by intro he; have h := congrArg List.length he; simp at h; omega)
    (by intro q hq; obtain ⟨i,rfl⟩ := List.mem_ofFn.mp hq; exact abs_nonneg _)
  exact List.mem_ofFn.mp hmem

theorem rationalVertexRadius_bits (M : Matrix (Fin r) (Fin r) ℚ)
    (V : Fin m → Fin r → ℚ) (L : ℕ)
    (hM : ∀ i j,RationalBitBound (M i j) L)
    (hV : ∀ i j,RationalBitBound (V i j) L) (j : Fin r) :
    RationalBitBound (rationalVertexRadius M V j) ((r+1)*(2*L+2)) := by
  apply rationalMaximum_bits _ _ (by positivity)
  intro q hq
  obtain ⟨i,rfl⟩ := List.mem_ofFn.mp hq
  apply RationalBitBound.abs
  have h := rationalMatrixMul_partial_bits M (fun k (_ : Fin 1) => V i k) L hM
    (fun k _ => hV i k) Finset.univ j 0
  simpa [Matrix.mulVec,dotProduct] using h

/-- Natural ceiling never needs more bits than the rational numerator's magnitude. -/
theorem rationalNatCeil_le_num (q : ℚ) : ⌈q⌉₊≤q.num.natAbs := by
  apply Nat.ceil_le.mpr
  have hn : (q.num:ℚ)≤q.num.natAbs := by
    have hh : ((q.num:ℤ):ℚ)≤((q.num.natAbs:ℤ):ℚ) := Int.cast_le.mpr Int.le_natAbs
    simpa only [Int.cast_natCast] using hh
  have hd : (1:ℚ)≤q.den := by exact_mod_cast q.den_pos
  calc
    q = (q.num:ℚ)/(q.den:ℚ) := (Rat.num_div_den q).symm
    _ ≤ (q.num.natAbs:ℚ)/(q.den:ℚ) := div_le_div_of_nonneg_right hn (Nat.cast_nonneg _)
    _ ≤ (q.num.natAbs:ℚ) := div_le_self (Nat.cast_nonneg _) hd

theorem rationalVertexWidth_bits (M : Matrix (Fin r) (Fin r) ℚ)
    (V : Fin m → Fin r → ℚ) (L : ℕ)
    (hM : ∀ i j,RationalBitBound (M i j) L)
    (hV : ∀ i j,RationalBitBound (V i j) L) (j : Fin r) :
    (rationalVertexWidth M V j).size≤(r+1)*(2*L+2) :=
  (Nat.size_le_size (rationalNatCeil_le_num _)).trans (rationalVertexRadius_bits M V L hM hV j).1

/-- Rational and real natural ceilings agree exactly. -/
theorem rationalNatCeil_cast (q : ℚ) : ⌈(q:ℝ)⌉₊=⌈q⌉₊ := by
  apply le_antisymm
  · apply Nat.ceil_le.mpr
    exact_mod_cast Nat.le_ceil q
  · apply Nat.ceil_le.mpr
    exact_mod_cast Nat.le_ceil (q:ℝ)

/-- A finite rational coordinate scan bounds the entire convex hull. -/
theorem rationalVertexRadius_convexHull (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (M : Matrix (Fin r) (Fin r) ℚ) (V : Fin m → Fin r → ℚ)
    (hcoord : ∀ i j,b.repr (realVertex V i) j=((M.mulVec (V i)) j:ℝ))
    (j : Fin r) {x : Fin r → ℝ}
    (hx : x∈convexHull ℝ (rationalVertexSet V : Set (Fin r → ℝ))) :
    |b.repr x j|≤(rationalVertexRadius M V j:ℝ) := by
  have hc : Convex ℝ {x : Fin r → ℝ | |b.repr x j|≤(rationalVertexRadius M V j:ℝ)} := by
    have he : {x : Fin r → ℝ | |b.repr x j|≤(rationalVertexRadius M V j:ℝ)} =
        (b.coord j) ⁻¹' Set.Icc (-(rationalVertexRadius M V j:ℝ)) (rationalVertexRadius M V j:ℝ) := by
      apply Set.ext
      intro x
      change |b.repr x j|≤(rationalVertexRadius M V j:ℝ) ↔
        -(rationalVertexRadius M V j:ℝ)≤b.repr x j ∧ b.repr x j≤(rationalVertexRadius M V j:ℝ)
      exact abs_le
    rw [he]
    exact (convex_Icc (𝕜:=ℝ) (-(rationalVertexRadius M V j:ℝ))
      (rationalVertexRadius M V j:ℝ)).linear_preimage (b.coord j)
  apply convexHull_min _ hc hx
  intro y hy
  obtain ⟨i,rfl⟩ := (mem_rationalVertexSet V y).mp hy
  change |b.repr (realVertex V i) j|≤_
  rw [hcoord]
  exact_mod_cast rationalVertexRadius_le M V i j

/-- The executable finite maximum equals the attained compact-body maximum. -/
theorem rationalVertexRadius_eq_basisCoordinateRadius
    (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (M : Matrix (Fin r) (Fin r) ℚ) (V : Fin m → Fin r → ℚ) (hm : 0<m)
    (hcoord : ∀ i j,b.repr (realVertex V i) j=((M.mulVec (V i)) j:ℝ))
    (hK : IsCompact (convexHull ℝ (rationalVertexSet V : Set (Fin r → ℝ))))
    (hne : (convexHull ℝ (rationalVertexSet V : Set (Fin r → ℝ))).Nonempty)
    (j : Fin r) :
    (rationalVertexRadius M V j:ℝ)=
      basisCoordinateRadius b (convexHull ℝ (rationalVertexSet V : Set _)) hK hne j := by
  apply le_antisymm
  · obtain ⟨i,hi⟩ := rationalVertexRadius_attained M V hm j
    have hx : realVertex V i∈convexHull ℝ (rationalVertexSet V : Set (Fin r → ℝ)) :=
      subset_convexHull ℝ _ ((mem_rationalVertexSet V _).mpr ⟨i,rfl⟩)
    have h := basisCoordinate_le_radius b _ hK hne j hx
    rw [hcoord,← Rat.cast_abs,hi] at h
    exact h
  · exact rationalVertexRadius_convexHull b M V hcoord j
      (basisCoordinateMaximizer_mem b _ hK hne j)

/-- The computed integer widths are literally the widths used by boxing. -/
theorem rationalVertexWidth_eq_basisIntegerWidth
    (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (M : Matrix (Fin r) (Fin r) ℚ) (V : Fin m → Fin r → ℚ) (hm : 0<m)
    (hcoord : ∀ i j,b.repr (realVertex V i) j=((M.mulVec (V i)) j:ℝ))
    (hK : IsCompact (convexHull ℝ (rationalVertexSet V : Set (Fin r → ℝ))))
    (hne : (convexHull ℝ (rationalVertexSet V : Set (Fin r → ℝ))).Nonempty)
    (j : Fin r) :
    rationalVertexWidth M V j=
      basisIntegerWidth b (convexHull ℝ (rationalVertexSet V : Set _)) hK hne j := by
  unfold basisIntegerWidth
  rw [← rationalVertexRadius_eq_basisCoordinateRadius b M V hm hcoord hK hne j,
    rationalNatCeil_cast]
  rfl

/-- Rational columns of a genuine real basis determine the exact coefficient
matrix used by the executable width scan. -/
theorem rationalCofactorInverse_basis_coordinates
    (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (A : Matrix (Fin r) (Fin r) ℚ) (hA : ∀ i j,(A i j:ℝ)=b j i)
    (V : Fin m → Fin r → ℚ) (i : Fin m) (j : Fin r) :
    b.repr (realVertex V i) j=
      (((rationalCofactorInverse A).mulVec (V i)) j:ℝ) := by
  obtain ⟨_,_,_,hcoord⟩ := rational_basis_inverse b A hA
  have h := congrFun (hcoord (realVertex V i)) j
  rw [← rationalCofactorInverse_eq] at h
  simpa only [Basis.equivFun_apply,Matrix.mulVec,dotProduct,Matrix.map_apply,
    realVertex,Rat.cast_sum,Rat.cast_mul] using h

/-- For an actual rational basis no coordinate-oracle assumption is needed:
the explicit cofactor inverse computes exactly the geometric integer widths. -/
theorem rationalCofactor_width_eq_basisIntegerWidth
    (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (A : Matrix (Fin r) (Fin r) ℚ) (hA : ∀ i j,(A i j:ℝ)=b j i)
    (V : Fin m → Fin r → ℚ) (hm : 0<m)
    (hK : IsCompact (convexHull ℝ (rationalVertexSet V : Set (Fin r → ℝ))))
    (hne : (convexHull ℝ (rationalVertexSet V : Set (Fin r → ℝ))).Nonempty)
    (j : Fin r) :
    rationalVertexWidth (rationalCofactorInverse A) V j=
      basisIntegerWidth b (convexHull ℝ (rationalVertexSet V : Set _)) hK hne j :=
  rationalVertexWidth_eq_basisIntegerWidth b _ V hm
    (rationalCofactorInverse_basis_coordinates b A hA V) hK hne j

/-- An independent lattice family forces positivity of these computed widths,
with the same factor-two ceiling overhead as the geometric construction. -/
theorem rationalCofactor_width_bounds
    (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (A : Matrix (Fin r) (Fin r) ℚ) (hA : ∀ i j,(A i j:ℝ)=b j i)
    (V : Fin m → Fin r → ℚ) (hm : 0<m)
    (hK : IsCompact (convexHull ℝ (rationalVertexSet V : Set (Fin r → ℝ))))
    (hne : (convexHull ℝ (rationalVertexSet V : Set (Fin r → ℝ))).Nonempty)
    (x : Fin r → (Fin r → ℝ)) (hind : LinearIndependent ℝ x)
    (hxK : ∀ i,x i∈convexHull ℝ (rationalVertexSet V : Set _))
    (hxΛ : ∀ i,x i∈basisIntegerLattice b) (j : Fin r) :
    1≤rationalVertexWidth (rationalCofactorInverse A) V j ∧
      (rationalVertexWidth (rationalCofactorInverse A) V j:ℚ)≤
        2*rationalVertexRadius (rationalCofactorInverse A) V j := by
  have hr := basisCoordinateRadius_ge_one b _ hK hne x hind hxK hxΛ j
  have hb := basisIntegerWidth_bounds b _ hK hne j hr
  have hw := rationalCofactor_width_eq_basisIntegerWidth b A hA V hm hK hne j
  have he := rationalVertexRadius_eq_basisCoordinateRadius b _ V hm
    (rationalCofactorInverse_basis_coordinates b A hA V) hK hne j
  rw [← hw,← he] at hb
  exact ⟨hb.1,by exact_mod_cast hb.2⟩

end Optss
