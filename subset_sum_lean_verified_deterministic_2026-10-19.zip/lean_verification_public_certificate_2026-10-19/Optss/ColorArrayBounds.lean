import Optss.BalancedProducts
import Optss.ColorSupport
import Optss.ColorParameters
import Optss.OneClassColorCoding
import Optss.MultivariateConvolution

/-!
# Actual color-coding supports and their allocated arrays

Color factors, repeated bucket unions, and the final bucket product are the
supports from Appendix A.2. Balanced trees allocate their arrays using the
proved coordinate bounds. Equation (84) sums across buckets as well as tree
levels, so the target-box term is paid only once up to explicit factors.
These are cell and merge counts; no arithmetic running-time premise is used.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {ι : Type*} {d : ℕ}

/-- Coordinate radii add when the actual finite supports are convolved. -/
theorem indexedSupportSum_radius {n : ℕ} (A : Fin n → Finset (IntVec d))
    (a : Fin d → ℝ) (hA : ∀ p x, x ∈ A p → ∀ j, |(x j : ℝ)| ≤ a j)
    (t : IntVec d) (ht : t ∈ indexedSupportSum A) (j : Fin d) :
    |(t j : ℝ)| ≤ (n:ℝ)*a j := by
  obtain ⟨x, hx, he⟩ := (mem_indexedSupportSum A t).mp ht
  subst t
  simp only [Finset.sum_apply, Int.cast_sum]
  calc
    |∑ p, (x p j : ℝ)| ≤ ∑ p, |(x p j : ℝ)| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _p : Fin n, a j := Finset.sum_le_sum (fun p _ => hA p (x p) (hx p) j)
    _ = _ := by simp

/-- Every color factor is contained in the original small-vector box. -/
theorem colorFactor_radius {q : ℕ} (v : ι → IntVec d) (S : Finset ι) (color : ι → Fin q)
    (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j)
    (hv : ∀ i ∈ S, ∀ j, |(v i j : ℝ)| ≤ a j)
    (p : Fin q) (x : IntVec d) (hx : x ∈ colorFactor v S color p) (j : Fin d) :
    |(x j : ℝ)| ≤ a j := by
  rcases (mem_colorFactor v S color p x).mp hx with rfl | ⟨i, hi, _, rfl⟩
  · simpa using ha j
  · exact hv i hi j

/-- One actual bucket/color repetition has radius `q*a`. -/
theorem colorSupport_radius {q : ℕ} (v : ι → IntVec d) (S : Finset ι) (color : ι → Fin q)
    (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j)
    (hv : ∀ i ∈ S, ∀ j, |(v i j : ℝ)| ≤ a j)
    (x : IntVec d) (hx : x ∈ colorSupport v S color) (j : Fin d) :
    |(x j : ℝ)| ≤ (q:ℝ)*a j :=
  indexedSupportSum_radius _ a (colorFactor_radius v S color a ha hv) x hx j

/-- Unioning the independently repeated bucket supports does not enlarge the
proved bucket radius. -/
theorem repeatedColorSupport_radius {R q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (color : Fin R → ι → Fin q) (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j)
    (hv : ∀ i ∈ S, ∀ j, |(v i j : ℝ)| ≤ a j)
    (x : IntVec d) (hx : x ∈ repeatedColorSupport v S color) (j : Fin d) :
    |(x j : ℝ)| ≤ (q:ℝ)*a j := by
  obtain ⟨r, _, hr⟩ := Finset.mem_biUnion.mp hx
  exact colorSupport_radius v S (color r) a ha hv x hr j

/-- The actual final bucket product has radius `b*q*a`, before final clipping. -/
theorem bucketColorSupport_radius {b R q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin R → ι → Fin q)
    (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j)
    (hv : ∀ i ∈ S, ∀ j, |(v i j : ℝ)| ≤ a j)
    (x : IntVec d) (hx : x ∈ bucketColorSupport v S bucket color) (j : Fin d) :
    |(x j : ℝ)| ≤ (b:ℝ)*(q:ℝ)*a j := by
  have h := indexedSupportSum_radius _ (fun j => (q:ℝ)*a j)
    (fun p y hy j => repeatedColorSupport_radius v _ (color p) a ha
      (fun i hi => hv i (Finset.mem_filter.mp hi).1) y hy j) x hx j
  simpa only [mul_assoc] using h

/-- The color-factor tree uses the actual factors from the support algorithm. -/
def colorFactorTree {q : ℕ} (v : ι → IntVec d) (S : Finset ι) (color : ι → Fin q) :=
  balancedProduct (List.ofFn (colorFactor v S color))

@[simp] theorem colorFactorTree_support {q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (color : ι → Fin q) : (colorFactorTree v S color).support = colorSupport v S color :=
  balancedProduct_support _

/-- The final tree has one actual repeated-union support for each bucket. -/
def bucketSupportTree {b R q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin R → ι → Fin q) :=
  balancedProduct (List.ofFn (fun p =>
    repeatedColorSupport v (S.filter (fun i => bucket i=p)) (color p)))

@[simp] theorem bucketSupportTree_support {b R q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin R → ι → Fin q) :
    (bucketSupportTree v S bucket color).support = bucketColorSupport v S bucket color :=
  balancedProduct_support _

/-- All color-tree intermediate arrays are valid for the original radii. -/
theorem colorFactorTree_factorsInBox {q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (color : ι → Fin q) (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j)
    (hv : ∀ i ∈ S, ∀ j, |(v i j : ℝ)| ≤ a j) :
    (colorFactorTree v S color).FactorsInBox (fun j => ⌊a j⌋₊) := by
  apply balancedProduct_factorsInRealBox _ a ha
  intro A hA x hx j
  obtain ⟨p, rfl⟩ := List.mem_ofFn.mp hA
  exact colorFactor_radius v S color a ha hv p x hx j

/-- All final-product intermediate arrays are valid for the union radii. -/
theorem bucketSupportTree_factorsInBox {b R q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin R → ι → Fin q)
    (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j)
    (hv : ∀ i ∈ S, ∀ j, |(v i j : ℝ)| ≤ a j) :
    (bucketSupportTree v S bucket color).FactorsInBox (fun j => ⌊(q:ℝ)*a j⌋₊) := by
  apply balancedProduct_factorsInRealBox _ (fun j => (q:ℝ)*a j) (fun j => mul_nonneg (Nat.cast_nonneg _) (ha j))
  intro A hA x hx j
  obtain ⟨p, rfl⟩ := List.mem_ofFn.mp hA
  exact repeatedColorSupport_radius v _ (color p) a ha
    (fun i hi => hv i (Finset.mem_filter.mp hi).1) x hx j

/-- Allocated cells of one actual color-factor tree, including intermediate arrays. -/
def colorTreeCells {q : ℕ} (v : ι → IntVec d) (S : Finset ι) (color : ι → Fin q)
    (a : Fin d → ℝ) : ℕ :=
  (colorFactorTree v S color).totalCells (fun j => ⌊a j⌋₊)

/-- Count the actual color trees over every bucket and repetition. -/
def colorForestCells {b R q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin R → ι → Fin q) (a : Fin d → ℝ) : ℕ :=
  ∑ p, ∑ r, colorTreeCells v (S.filter (fun i => bucket i=p)) (color p r) a

/-- Cells for one materialized repeated-support union per bucket. -/
def bucketUnionCells (b q : ℕ) (a : Fin d → ℝ) : ℕ :=
  b * (balancedArrayBox (fun j => ⌊(q:ℝ)*a j⌋₊) 1).card

/-- Complete retained array allocation for the two-stage support construction. -/
def bucketColorArrayCells {b R q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin R → ι → Fin q) (a : Fin d → ℝ) : ℕ :=
  colorForestCells v S bucket color a + bucketUnionCells b q a +
    (bucketSupportTree v S bucket color).totalCells (fun j => ⌊(q:ℝ)*a j⌋₊)

theorem colorTreeCells_le {q : ℕ} (v : ι → IntVec d) (S : Finset ι) (color : ι → Fin q)
    (hq : 0 < q) (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j) :
    (colorTreeCells v S color a : ℝ) ≤ (Nat.clog 2 q + 1 : ℕ) *
      (2*(q:ℝ) + (4:ℝ)^d * ∏ j, (1+(q:ℝ)*a j)) := by
  simpa only [colorTreeCells, colorFactorTree, List.length_ofFn] using
    balancedProduct_total_cells_le (List.ofFn (colorFactor v S color)) (by simpa using hq) a ha

/-- Equation (84) across buckets pays for the large target box once. -/
theorem bucket_product_array_bound (b : ℕ) (hb : 0 < b) (a : Fin d → ℝ)
    (ha : ∀ j, 0 ≤ a j) :
    (b:ℝ) * (∏ j, (1+a j)) ≤ b + (∏ j, (1+(b:ℝ)*a j)) - 1 := by
  have hbR : (1:ℝ) ≤ b := by exact_mod_cast hb
  have h := balanced_array_level_bound_univ (fun j => (b:ℝ)*a j) hbR
    (fun j => mul_nonneg (Nat.cast_nonneg _) (ha j))
  simpa only [mul_div_cancel_left₀ _ (by positivity : (b:ℝ) ≠ 0)] using h

/-- Summed color-tree allocation over buckets and repetitions. -/
theorem colorForestCells_le {b R q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin R → ι → Fin q)
    (hb : 0 < b) (hq : 0 < q) (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j) :
    (colorForestCells v S bucket color a : ℝ) ≤
      (R:ℝ)*(Nat.clog 2 q + 1 : ℕ) *
        (2*(b:ℝ)*q + (4:ℝ)^d * (b + ∏ j, (1+(b:ℝ)*q*a j))) := by
  have hprod := bucket_product_array_bound b hb (fun j => (q:ℝ)*a j) (fun j => mul_nonneg (Nat.cast_nonneg _) (ha j))
  have hsum : (colorForestCells v S bucket color a : ℝ) ≤
      (b:ℝ)*R*(Nat.clog 2 q+1:ℕ) * (2*(q:ℝ)+(4:ℝ)^d*∏ j, (1+(q:ℝ)*a j)) := by
    unfold colorForestCells
    push_cast
    calc
      _ ≤ ∑ _p : Fin b, ∑ _r : Fin R,
          (Nat.clog 2 q+1:ℕ)*(2*(q:ℝ)+(4:ℝ)^d*∏ j, (1+(q:ℝ)*a j)) := by
        apply Finset.sum_le_sum
        intro p _
        apply Finset.sum_le_sum
        intro r _
        exact colorTreeCells_le v _ (color p r) hq a ha
      _ = _ := by simp; ring
  apply hsum.trans
  have hp : (b:ℝ) * (∏ j, (1+(q:ℝ)*a j)) ≤ b + ∏ j, (1+(b:ℝ)*q*a j) := by
    simp only [← mul_assoc] at hprod
    linarith
  have hh := mul_le_mul_of_nonneg_left hp (by positivity : (0:ℝ) ≤
    (R:ℝ)*(Nat.clog 2 q+1:ℕ)*(4:ℝ)^d)
  nlinarith [hh]

/-- One materialized union array includes constant cells in narrow coordinates. -/
theorem rounded_box_cells_le (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j) :
    ((balancedArrayBox (fun j => ⌊a j⌋₊) 1).card : ℝ) ≤
      (4:ℝ)^d * ∏ j, (1+a j) := by
  rw [balancedArrayBox_card]
  push_cast
  calc
    _ ≤ ∏ j, (4*(1+a j)) := by
      apply Finset.prod_le_prod
      · intro j _
        positivity
      · intro j _
        have hf := Nat.floor_le (ha j)
        have ha' := ha j
        nlinarith
    _ = _ := by rw [Finset.prod_mul_distrib]; simp

/-- All bucket union arrays satisfy the same summed-box accounting. -/
theorem bucketUnionCells_le (b q : ℕ) (hb : 0 < b) (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j) :
    (bucketUnionCells b q a : ℝ) ≤ (4:ℝ)^d * (b + ∏ j, (1+(b:ℝ)*q*a j)) := by
  have hc := rounded_box_cells_le (fun j => (q:ℝ)*a j)
    (fun j => mul_nonneg (Nat.cast_nonneg _) (ha j))
  have hp := bucket_product_array_bound b hb (fun j => (q:ℝ)*a j)
    (fun j => mul_nonneg (Nat.cast_nonneg _) (ha j))
  simp only [← mul_assoc] at hp
  have hp' : (b:ℝ)*(∏ j, (1+(q:ℝ)*a j)) ≤ b + ∏ j, (1+(b:ℝ)*q*a j) := by linarith
  have h₁ := mul_le_mul_of_nonneg_left hc (Nat.cast_nonneg b : (0:ℝ) ≤ b)
  have h₂ := mul_le_mul_of_nonneg_left hp' (by positivity : (0:ℝ) ≤ (4:ℝ)^d)
  unfold bucketUnionCells
  push_cast
  nlinarith [h₁, h₂]

theorem bucketSupportTree_cells_le {b R q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin R → ι → Fin q)
    (hb : 0 < b) (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j) :
    ((bucketSupportTree v S bucket color).totalCells (fun j => ⌊(q:ℝ)*a j⌋₊) : ℝ) ≤
      (Nat.clog 2 b+1:ℕ) * (2*(b:ℝ)+(4:ℝ)^d*∏ j, (1+(b:ℝ)*q*a j)) := by
  simpa only [bucketSupportTree, List.length_ofFn, ← mul_assoc] using
    balancedProduct_total_cells_le
      (List.ofFn (fun p => repeatedColorSupport v (S.filter (fun i => bucket i=p)) (color p)))
      (by simpa using hb) (fun j => (q:ℝ)*a j) (fun j => mul_nonneg (Nat.cast_nonneg _) (ha j))

/-- All arrays retained by the actual two-stage construction, including color
trees, bucket unions, and the final bucket tree. The large product-box term
appears once inside an explicit logarithmic multiplier. -/
theorem bucketColorArrayCells_le {b R q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin R → ι → Fin q)
    (hb : 0 < b) (hq : 0 < q) (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j) :
    (bucketColorArrayCells v S bucket color a : ℝ) ≤
      ((R:ℝ)*(Nat.clog 2 q+1:ℕ) + (Nat.clog 2 b+2:ℕ)) * (2+(4:ℝ)^d) *
        ((b:ℝ)*q + (4:ℝ)^d*∏ j, (1+(b:ℝ)*q*a j)) := by
  let C : ℝ := (4:ℝ)^d
  let P : ℝ := ∏ j, (1+(b:ℝ)*q*a j)
  let D : ℝ := (b:ℝ)*q + C*P
  have hC : 0 ≤ C := by dsimp [C]; positivity
  have hP : 0 ≤ P := Finset.prod_nonneg (fun j _ => by
    have := ha j
    positivity)
  have hbq : (b:ℝ) ≤ (b:ℝ)*q := by
    have hqR : (1:ℝ) ≤ q := by exact_mod_cast hq
    nlinarith [mul_le_mul_of_nonneg_left hqR (Nat.cast_nonneg b : (0:ℝ) ≤ b)]
  have hCP : 0 ≤ C*P := mul_nonneg hC hP
  have hmain : 2*(b:ℝ)*q+C*(b+P) ≤ (2+C)*D := by
    dsimp [D]
    have h₁ := mul_le_mul_of_nonneg_left hbq hC
    have h₂ := mul_nonneg (show 0 ≤ 1+C by linarith) hCP
    nlinarith [h₁,h₂]
  have hunion : C*(b+P) ≤ (2+C)*D := by nlinarith
  have hfinal : 2*(b:ℝ)+C*P ≤ (2+C)*D := by
    have hCb := mul_nonneg hC (Nat.cast_nonneg b : (0:ℝ) ≤ b)
    nlinarith
  have hf := colorForestCells_le v S bucket color hb hq a ha
  have hu := bucketUnionCells_le b q hb a ha
  have hb' := bucketSupportTree_cells_le v S bucket color hb a ha
  change (colorForestCells v S bucket color a : ℝ) ≤
    (R:ℝ)*(Nat.clog 2 q+1:ℕ)*(2*(b:ℝ)*q+C*(b+P)) at hf
  change (bucketUnionCells b q a : ℝ) ≤ C*(b+P) at hu
  change ((bucketSupportTree v S bucket color).totalCells _ : ℝ) ≤
    (Nat.clog 2 b+1:ℕ)*(2*(b:ℝ)+C*P) at hb'
  have hf' := hf.trans (mul_le_mul_of_nonneg_left hmain (by positivity :
    (0:ℝ) ≤ (R:ℝ)*(Nat.clog 2 q+1:ℕ)))
  have hu' := hu.trans hunion
  have hb'' := hb'.trans (mul_le_mul_of_nonneg_left hfinal (by positivity :
    (0:ℝ) ≤ (Nat.clog 2 b+1:ℕ)))
  unfold bucketColorArrayCells
  push_cast
  change _ ≤ ((R:ℝ)*((Nat.clog 2 q:ℝ)+1)+((Nat.clog 2 b:ℝ)+2))*(2+C)*D
  push_cast at hf' hb''
  nlinarith [hf', hu', hb'']

/-- Integer-box products remain controlled in every narrow or zero-width
coordinate, with an explicit scalar enlargement. -/
theorem scaled_integer_box_product_le (Δ : Fin d → ℕ) (c M : ℝ)
    (hc : 0 ≤ c) (hM : 0 ≤ M) (hcM : c ≤ M) :
    (∏ j, (1+c*Δ j)) ≤ (1+M)^d * (boxVolume Δ : ℝ) := by
  calc
    _ ≤ ∏ j, ((1+M)*(1+(Δ j:ℝ))) := by
      apply Finset.prod_le_prod
      · intro j _
        positivity
      · intro j _
        have h := mul_le_mul_of_nonneg_right hcM (Nat.cast_nonneg (Δ j) : (0:ℝ) ≤ Δ j)
        nlinarith
    _ = _ := by
      rw [Finset.prod_mul_distrib]
      simp only [Finset.prod_const, Finset.card_univ, Fintype.card_fin, boxVolume,
        Nat.cast_prod, Nat.cast_add, Nat.cast_one]
      congr 1
      apply Finset.prod_congr rfl
      intro j _
      ring

/-- Substituting the explicit palette/bucket formulas and the small-vector
quota bounds the sole large-box term by a polynomial in `L` times its true
integer array volume. -/
theorem color_parameter_box_product_le (k L : ℕ) (Δ : Fin d → ℕ) (α : ℝ)
    (hα : 0 ≤ α) (hα1 : α ≤ 1) (hkα : (k:ℝ)*α ≤ 2*d) :
    (∏ j, (1+(colorBucketCount k L:ℝ)*colorPaletteSize L*(α*Δ j))) ≤
      (1+128*(2*(d:ℝ)*L+(L:ℝ)^2))^d * (boxVolume Δ:ℝ) := by
  have hc := color_parameter_scaled_width k L d α hα hα1 hkα
  have hh := scaled_integer_box_product_le Δ
    ((colorBucketCount k L:ℝ)*colorPaletteSize L*α) (128*(2*(d:ℝ)*L+(L:ℝ)^2))
    (by positivity) (by positivity) (by simpa only [Nat.cast_mul] using hc)
  simpa only [mul_assoc] using hh

/-- The paper's two-stage array accounting, with all constants explicit.
The `k*L` term is at most `m*L` when `k≤m`; the remaining large term is a
fixed-dimensional polynomial in `L` times the target integer-box volume. -/
theorem configured_bucketColorArrayCells_le (k L R : ℕ) (hL : 0 < L)
    (v : ι → IntVec d) (S : Finset ι)
    (bucket : ι → Fin (colorBucketCount k L))
    (color : Fin (colorBucketCount k L) → Fin R → ι → Fin (colorPaletteSize L))
    (Δ : Fin d → ℕ) (α : ℝ) (hα : 0 ≤ α) (hα1 : α ≤ 1)
    (hkα : (k:ℝ)*α ≤ 2*d) :
    (bucketColorArrayCells v S bucket color (fun j => α*Δ j) : ℝ) ≤
      ((R:ℝ)*(Nat.clog 2 (colorPaletteSize L)+1:ℕ) +
        (Nat.clog 2 (colorBucketCount k L)+2:ℕ)) * (2+(4:ℝ)^d) *
      (128*((k:ℝ)*L+(L:ℝ)^2) +
        (4:ℝ)^d*(1+128*(2*(d:ℝ)*L+(L:ℝ)^2))^d*(boxVolume Δ:ℝ)) := by
  have hb : 0 < colorBucketCount k L := by unfold colorBucketCount; omega
  have hq := colorPaletteSize_pos L hL
  apply (bucketColorArrayCells_le v S bucket color hb hq (fun j => α*Δ j)
    (fun j => mul_nonneg hα (Nat.cast_nonneg _))).trans
  have hf : (colorBucketCount k L:ℝ)*colorPaletteSize L ≤ 128*((k:ℝ)*L+(L:ℝ)^2) := by
    exact_mod_cast color_parameter_factor_count k L
  have hp := color_parameter_box_product_le k L Δ α hα hα1 hkα
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  have hp' := mul_le_mul_of_nonneg_left hp (by positivity : (0:ℝ) ≤ (4:ℝ)^d)
  nlinarith

/-- The same explicit accounting with the input class size in place of its
witness cap, as in the `m + vbox` statement of A.2. -/
theorem configured_bucketColorArrayCells_le_input (k L R : ℕ) (hL : 0 < L)
    (v : ι → IntVec d) (S : Finset ι) (hk : k ≤ S.card)
    (bucket : ι → Fin (colorBucketCount k L))
    (color : Fin (colorBucketCount k L) → Fin R → ι → Fin (colorPaletteSize L))
    (Δ : Fin d → ℕ) (α : ℝ) (hα : 0 ≤ α) (hα1 : α ≤ 1)
    (hkα : (k:ℝ)*α ≤ 2*d) :
    (bucketColorArrayCells v S bucket color (fun j => α*Δ j) : ℝ) ≤
      ((R:ℝ)*(Nat.clog 2 (colorPaletteSize L)+1:ℕ) +
        (Nat.clog 2 (colorBucketCount k L)+2:ℕ)) * (2+(4:ℝ)^d) *
      (128*((S.card:ℝ)*L+(L:ℝ)^2) +
        (4:ℝ)^d*(1+128*(2*(d:ℝ)*L+(L:ℝ)^2))^d*(boxVolume Δ:ℝ)) := by
  apply (configured_bucketColorArrayCells_le k L R hL v S bucket color Δ α hα hα1 hkα).trans
  have hkR : (k:ℝ) ≤ S.card := by exact_mod_cast hk
  have hs := mul_le_mul_of_nonneg_right hkR (Nat.cast_nonneg L : (0:ℝ) ≤ L)
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  linarith

/-- Actual arrays associated with the one-class hash/color sample. -/
def oneClassColorArrayCells (v : ι → IntVec d) (S : Finset ι) (a : Fin d → ℝ)
    {b L R : ℕ} (sample : HashColorSample ι b L R) : ℕ :=
  bucketColorArrayCells v S sample.1 sample.2 a

/-- The balanced final tree followed by the same final filter realizes exactly
`oneClassColorSupport`; the counted arrays therefore belong to that support
construction, not to a hypothetical collection of equal-sized nodes. -/
theorem oneClassColorSupport_eq_balanced (v : ι → IntVec d) (S : Finset ι)
    (B : Set (IntVec d)) [DecidablePred B] {b L R : ℕ} (sample : HashColorSample ι b L R) :
    oneClassColorSupport v S B sample = (bucketSupportTree v S sample.1 sample.2).support.filter B := by
  rw [bucketSupportTree_support]
  rfl

/-- The array counted for a bucket union really contains every retained entry. -/
theorem repeatedColorSupport_subset_unionArray {R q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (color : Fin R → ι → Fin q) (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j)
    (hv : ∀ i ∈ S, ∀ j, |(v i j : ℝ)| ≤ a j) :
    repeatedColorSupport v S color ⊆ balancedArrayBox (fun j => ⌊(q:ℝ)*a j⌋₊) 1 := by
  intro x hx
  apply (mem_balancedArrayBox _ _ _).mpr
  intro j
  have hr := repeatedColorSupport_radius v S color a ha hv x hx j
  have hn : ((x j).natAbs : ℝ) ≤ (q:ℝ)*a j := by
    simpa only [Int.cast_natAbs, Int.cast_abs] using hr
  have hf := (Nat.le_floor_iff (mul_nonneg (Nat.cast_nonneg q) (ha j))).mpr hn
  have hi : ((x j).natAbs : ℤ) ≤ (⌊(q:ℝ)*a j⌋₊:ℤ) := by exact_mod_cast hf
  simpa only [Nat.one_mul, Int.natCast_natAbs] using hi

/-- Number of explicitly listed factor entries in one bucket/color repetition. -/
def colorFactorEntries {q : ℕ} (v : ι → IntVec d) (S : Finset ι) (color : ι → Fin q) : ℕ :=
  ∑ p, (colorFactor v S color p).card

theorem colorFactorEntries_le {q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (color : ι → Fin q) : colorFactorEntries v S color ≤ S.card+q := by
  have hf : (∑ p, (S.filter (fun i => color i=p)).card) = S.card := by
    simpa using Finset.sum_card_fiberwise_eq_card_filter S Finset.univ color
  calc
    _ ≤ ∑ p : Fin q, ((S.filter (fun i => color i=p)).card+1) := by
      apply Finset.sum_le_sum
      intro p _
      exact (Finset.card_insert_le 0 _).trans (Nat.add_le_add_right (Finset.card_image_le) 1)
    _ = _ := by rw [Finset.sum_add_distrib, hf]; simp

/-- Total original factor-entry traffic across buckets and repetitions. -/
def colorForestEntries {b R q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin R → ι → Fin q) : ℕ :=
  ∑ p, ∑ r, colorFactorEntries v (S.filter (fun i => bucket i=p)) (color p r)

/-- Partitioning labels among buckets prevents an extra factor of `b` on the
original input size. Each repetition lists at most `m+bq` factor entries. -/
theorem colorForestEntries_le {b R q : ℕ} (v : ι → IntVec d) (S : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin R → ι → Fin q) :
    colorForestEntries v S bucket color ≤ R*(S.card+b*q) := by
  have hf : (∑ p, (S.filter (fun i => bucket i=p)).card) = S.card := by
    simpa using Finset.sum_card_fiberwise_eq_card_filter S Finset.univ bucket
  calc
    _ ≤ ∑ p : Fin b, ∑ _r : Fin R, ((S.filter (fun i => bucket i=p)).card+q) := by
      apply Finset.sum_le_sum
      intro p _
      apply Finset.sum_le_sum
      intro r _
      exact colorFactorEntries_le v _ (color p r)
    _ = _ := by
      simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
      rw [← Finset.mul_sum, Finset.sum_add_distrib, hf]
      simp

end
end Optss
