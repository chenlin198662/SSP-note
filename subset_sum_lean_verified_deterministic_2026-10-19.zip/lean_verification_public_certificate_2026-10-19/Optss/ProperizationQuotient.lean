import Optss.PrimitiveQuotient
import Optss.ProperizationStep
import Optss.LatticeDilationCounting
import Optss.LatticeChains

/-!
# Actual lower-rank quotient bodies for properization

A primitive kernel direction gives an actual integer quotient, its real
extension, a compact symmetric convex image body, and the enlarged-box
integer-representative count in Appendix B.2. With positive input widths the
quotient body contains a full independent set of quotient lattice points.
The subsequent full-lattice boxing and iterative bit-cost proof are separate.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {G : Type*} [AddCommGroup G]
variable {d e : ℕ}

def realCoefficientBox (β : Fin d → ℕ) : Set (Fin d → ℝ) :=
  Set.Icc (fun j => -(β j : ℝ)) (fun j => (β j : ℝ))

@[simp] theorem mem_realCoefficientBox (β : Fin d → ℕ) (x : Fin d → ℝ) :
    x ∈ realCoefficientBox β ↔ ∀ j, |x j| ≤ (β j : ℝ) := by
  simp only [realCoefficientBox, Set.mem_Icc, Pi.le_def, abs_le, forall_and]

theorem realCoefficientBox_compact (β : Fin d → ℕ) : IsCompact (realCoefficientBox β) :=
  isCompact_Icc

theorem realCoefficientBox_convex (β : Fin d → ℕ) : Convex ℝ (realCoefficientBox β) := convex_Icc _ _

theorem realCoefficientBox_symmetric (β : Fin d → ℕ) {x : Fin d → ℝ}
    (hx : x ∈ realCoefficientBox β) : -x ∈ realCoefficientBox β := by
  simpa only [mem_realCoefficientBox, Pi.neg_apply, abs_neg] using hx

def integerLinearImageBox (π : IntVec d →ₗ[ℤ] IntVec e) (β : Fin d → ℕ) : Set (Fin e → ℝ) :=
  integerMapRealExtension π '' realCoefficientBox β

theorem integerLinearImageBox_compact (π : IntVec d →ₗ[ℤ] IntVec e) (β : Fin d → ℕ) :
    IsCompact (integerLinearImageBox π β) :=
  (realCoefficientBox_compact β).image (integerMapRealExtension π).continuous_of_finiteDimensional

theorem integerLinearImageBox_convex (π : IntVec d →ₗ[ℤ] IntVec e) (β : Fin d → ℕ) :
    Convex ℝ (integerLinearImageBox π β) := (realCoefficientBox_convex β).linear_image _

theorem integerLinearImageBox_symmetric (π : IntVec d →ₗ[ℤ] IntVec e) (β : Fin d → ℕ)
    {x : Fin e → ℝ} (hx : x ∈ integerLinearImageBox π β) : -x ∈ integerLinearImageBox π β := by
  obtain ⟨y, hy, rfl⟩ := hx
  exact ⟨-y, realCoefficientBox_symmetric β hy, map_neg _ _⟩

theorem integerLinearImageBox_zero (π : IntVec d →ₗ[ℤ] IntVec e) (β : Fin d → ℕ) :
    0 ∈ integerLinearImageBox π β := by
  exact ⟨0, by simp [mem_realCoefficientBox], map_zero _⟩

/-- Surjectivity of the actual integer matrix forces its real integer columns
to span the entire quotient coordinate space. -/
theorem integerMap_columns_span (π : IntVec d →ₗ[ℤ] IntVec e) (hπ : Function.Surjective π) :
    labelSpan ℝ (fun j : Fin d => realVector (π (Pi.single j 1))) Finset.univ = ⊤ := by
  apply top_unique
  intro x _
  obtain ⟨y, rfl⟩ := integerMapRealExtension_surjective π hπ x
  have he : integerMapRealExtension π y = ∑ j : Fin d, y j • realVector (π (Pi.single j 1)) := by
    ext i
    simp [integerMapRealExtension, realVector, Finset.sum_apply, Pi.smul_apply]
  rw [he]
  apply Submodule.sum_mem
  intro j _
  apply Submodule.smul_mem
  apply Submodule.subset_span
  exact ⟨j, Finset.mem_univ _, rfl⟩

/-- Positive active widths put all standard coordinate directions in the
original box, so their quotient images supply an actual independent lattice set. -/
theorem integerLinearImageBox_independent (π : IntVec d →ₗ[ℤ] IntVec e)
    (hπ : Function.Surjective π) (β : Fin d → ℕ) (hβ : ∀ j, 1 ≤ β j) :
    ∃ u : Fin e → IntVec e, LinearIndependent ℝ (fun j => realVector (u j)) ∧
      ∀ j, realVector (u j) ∈ integerLinearImageBox π β := by
  obtain ⟨labels, _, hli⟩ := exists_full_rank_labels (fun j : Fin d => π (Pi.single j 1))
    Finset.univ (integerMap_columns_span π hπ)
  refine ⟨fun j => π (Pi.single (labels j) 1), hli, ?_⟩
  intro j
  refine ⟨realVector (Pi.single (labels j) 1), ?_, integerMapRealExtension_cast π _⟩
  rw [realVector_single, mem_realCoefficientBox]
  intro i
  by_cases hi : i=labels j
  · subst i
    simp only [Pi.single_eq_same, abs_one]
    exact_mod_cast hβ (labels j)
  · simp [Pi.single_apply, hi, Ne.symm hi]

/-- Every integer point of the actual primitive quotient body has a bounded
integer lift. All quotient hypotheses are supplied by the proved construction. -/
theorem primitiveQuotient_box_representative (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ)
    (hp : ℓ p=1) (β : Fin d → ℕ) (t : ℕ)
    (hbound : InBox (fun j => ((2*t*β j : ℕ) : ℤ)) p)
    (q : IntVec (d-1))
    (hq : realVector q ∈ integerLinearImageBox (primitiveQuotientMap p ℓ hp) β) :
    ∃ x ∈ integerBudgetBox (fun j => (1+t)*β j), primitiveQuotientMap p ℓ hp x=q := by
  obtain ⟨y, hy, hFy⟩ := hq
  apply quotient_integer_representative β t p hbound
    (primitiveQuotientMap p ℓ hp).toAddMonoidHom (primitiveRealQuotientMap p ℓ hp)
    (primitiveQuotientMap_surjective p ℓ hp)
    (fun x => (integerMapRealExtension_cast (primitiveQuotientMap p ℓ hp) x).symm) ?_ ?_ q y
    ((mem_realCoefficientBox β y).mp hy) hFy
  · change primitiveQuotientMap p ℓ hp p = 0
    apply LinearMap.mem_ker.mp
    rw [primitiveQuotientMap_ker]
    exact Submodule.subset_span (Set.mem_singleton p)
  · intro x hx
    have hm : x ∈ Submodule.span ℝ {realVector p} := by
      rw [← primitiveRealQuotientMap_ker p ℓ hp, LinearMap.mem_ker]
      exact hx
    obtain ⟨a, ha⟩ := Submodule.mem_span_singleton.mp hm
    exact ⟨a, ha.symm⟩

/-- The quotient body's entire lattice-point set obeys the factor stated in
Appendix B.2, not just a preselected finite subset. -/
theorem primitiveQuotient_box_card (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ)
    (hp : ℓ p=1) (β : Fin d → ℕ) (t : ℕ)
    (hbound : InBox (fun j => ((2*t*β j : ℕ) : ℤ)) p) :
    (integerPoints (integerLinearImageBox (primitiveQuotientMap p ℓ hp) β)
      (integerLinearImageBox_compact _ β).isBounded).card ≤
      (1+t)^d*(integerBudgetBox β).card := by
  have hsub : integerPoints (integerLinearImageBox (primitiveQuotientMap p ℓ hp) β)
      (integerLinearImageBox_compact _ β).isBounded ⊆
      (integerBudgetBox (fun j => (1+t)*β j)).image (primitiveQuotientMap p ℓ hp) := by
    intro q hq
    exact Finset.mem_image.mpr (primitiveQuotient_box_representative p ℓ hp β t hbound q
      ((mem_integerPoints _ _ q).mp hq))
  exact (Finset.card_le_card hsub).trans
    ((Finset.card_image_le).trans (integerBudgetBox_dilation_card_le β t))

/-- Starting from the detected short relation, construct every algebraic part
of the actual smaller-rank quotient step. Primitive division, scalar descent
and quotient-body counting are all discharged by the preceding proofs. -/
theorem exists_properization_quotient_step [IsAddTorsionFree G] (ρ : IntVec d →+ G) (β : Fin d → ℕ)
    (t : ℕ) (z : IntVec d) (hz : z ≠ 0)
    (hzbox : z ∈ integerBudgetBox (fun j => 2*t*β j)) (hzker : ρ z=0) :
    d-1 < d ∧ ∃ p : IntVec d, ∃ ℓ : IntVec d →ₗ[ℤ] ℤ, ∃ hp : ℓ p=1,
      ρ p=0 ∧ InBox (fun j => ((2*t*β j : ℕ) : ℤ)) p ∧
      (∀ x, primitiveDescendedHom p ℓ hp ρ (primitiveQuotientMap p ℓ hp x)=ρ x) ∧
      (integerPoints (integerLinearImageBox (primitiveQuotientMap p ℓ hp) β)
        (integerLinearImageBox_compact _ β).isBounded).card ≤
          (1+t)^d*(integerBudgetBox β).card := by
  have hd : 0 < d := by
    by_contra hn
    have hd0 : d=0 := by omega
    subst d
    exact hz (Subsingleton.elim _ _)
  refine ⟨by omega, ?_⟩
  obtain ⟨p, ℓ, hg, hgp, _, hp, hsmall⟩ := exists_primitive_divisor z hz
  have hρ := primitive_divisor_mem_add_kernel ρ z p _ hg hgp hzker
  have hb : InBox (fun j => ((2*t*β j : ℕ) : ℤ)) p := fun j =>
    (hsmall j).trans ((mem_integerBudgetBox _ z).mp hzbox j)
  exact ⟨p, ℓ, hp, hρ, hb, primitiveDescendedHom_quotient p ℓ hp ρ hρ,
    primitiveQuotient_box_card p ℓ hp β t hb⟩

/-- Quotienting a genuine scalar relation preserves every value of the input
progression in the new real body with its descended integer encoding. -/
theorem primitiveQuotient_preserves_progression (ρ : IntVec d →+ G)
    (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p=1) (hρ : ρ p=0)
    (β : Fin d → ℕ) (x : IntVec d) (hx : x ∈ integerBudgetBox β) :
    realVector (primitiveQuotientMap p ℓ hp x) ∈
      integerLinearImageBox (primitiveQuotientMap p ℓ hp) β ∧
    primitiveDescendedHom p ℓ hp ρ (primitiveQuotientMap p ℓ hp x) = ρ x := by
  refine ⟨⟨realVector x, ?_, integerMapRealExtension_cast _ x⟩,
    primitiveDescendedHom_quotient p ℓ hp ρ hρ x⟩
  rw [mem_realCoefficientBox]
  intro j
  have h := (mem_integerBudgetBox β x).mp hx j
  dsimp only at h
  change |(x j : ℝ)| ≤ (β j : ℝ)
  exact_mod_cast h

end
end Optss
