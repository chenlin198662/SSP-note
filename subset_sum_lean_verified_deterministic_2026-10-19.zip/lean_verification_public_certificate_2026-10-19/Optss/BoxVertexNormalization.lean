import Optss.MaximalDeterminantNormalization
import Optss.ProperizationQuotient

/-!
# Actual corner vertices and normalization of quotient boxes

A coefficient box is exactly the convex hull of its finite corner set. Zero
widths are permitted in this identity; with positive widths there are exactly
`2^d` corners and they span the original coordinate space. A surjective linear
image therefore has a finite symmetric spanning vertex set, and the proved
maximum-determinant construction supplies its Euclidean normalization.
-/

namespace Optss
noncomputable section
open scoped BigOperators Classical
variable {d e : ℕ}

/-- All corner vectors, with duplicate endpoints removed when a width is zero. -/
def realBoxVertices (β : Fin d → ℕ) : Finset (Fin d → ℝ) :=
  Fintype.piFinset (fun j => {-(β j : ℝ), (β j : ℝ)})

@[simp] theorem mem_realBoxVertices (β : Fin d → ℕ) (x : Fin d → ℝ) :
    x ∈ realBoxVertices β ↔ ∀ j, x j = -(β j : ℝ) ∨ x j = (β j : ℝ) := by
  simp [realBoxVertices]

/-- Degenerate widths can identify corners but never create extra ones. -/
theorem realBoxVertices_card_le (β : Fin d → ℕ) : (realBoxVertices β).card ≤ 2^d := by
  rw [realBoxVertices, Fintype.card_piFinset]
  calc
    _ ≤ ∏ _j : Fin d, 2 := by
      apply Finset.prod_le_prod (fun _ _ => Nat.zero_le _)
      intro j _
      simpa using Finset.card_insert_le (-(β j : ℝ)) ({(β j : ℝ)} : Finset ℝ)
    _ = _ := by simp

/-- Positive widths give all `2^d` distinct corners. -/
theorem realBoxVertices_card (β : Fin d → ℕ) (hβ : ∀ j, 1 ≤ β j) :
    (realBoxVertices β).card = 2^d := by
  rw [realBoxVertices, Fintype.card_piFinset]
  have hne (j : Fin d) : -(β j : ℝ) ≠ (β j : ℝ) := by
    have hj : (0 : ℝ) < β j := by exact_mod_cast (hβ j)
    linarith
  simp [hne]

/-- Taking all products of interval endpoints gives exactly the entire box
under convex hull, including zero widths and the zero-dimensional case. -/
theorem convexHull_realBoxVertices (β : Fin d → ℕ) :
    convexHull ℝ (realBoxVertices β : Set (Fin d → ℝ)) = realCoefficientBox β := by
  rw [realBoxVertices, Fintype.coe_piFinset, convexHull_pi]
  have hj (j : Fin d) :
      convexHull ℝ ({-(β j : ℝ), (β j : ℝ)} : Set ℝ) =
        Set.Icc (-(β j : ℝ)) (β j : ℝ) := by
    rw [convexHull_pair, segment_eq_Icc]
    exact (neg_nonpos.mpr (Nat.cast_nonneg _)).trans (Nat.cast_nonneg _)
  simp_rw [Finset.coe_pair, hj]
  ext x
  simp [realCoefficientBox, Set.mem_pi, Pi.le_def, forall_and]

theorem realBoxVertices_symmetric (β : Fin d → ℕ) {x : Fin d → ℝ}
    (hx : x ∈ realBoxVertices β) : -x ∈ realBoxVertices β := by
  rw [mem_realBoxVertices] at hx ⊢
  intro j
  rcases hx j with hj | hj
  · exact Or.inr (by simp [hj])
  · exact Or.inl (by simp [hj])

/-- The coordinate basis is inside every box whose active integer widths are positive. -/
theorem realCoefficientBox_span (β : Fin d → ℕ) (hβ : ∀ j, 1 ≤ β j) :
    Submodule.span ℝ (realCoefficientBox β) = ⊤ := by
  apply top_unique
  rw [← (Pi.basisFun ℝ (Fin d)).span_eq]
  apply Submodule.span_le.mpr
  rintro _ ⟨j, rfl⟩
  apply Submodule.subset_span
  rw [Pi.basisFun_apply, mem_realCoefficientBox]
  intro i
  by_cases hij : i = j
  · subst i
    simpa using (show (1 : ℝ) ≤ β j by exact_mod_cast hβ j)
  · simp [Pi.single_apply, hij, Ne.symm hij]

/-- The finite corner set itself spans; the box hull is not an extra hypothesis. -/
theorem realBoxVertices_span (β : Fin d → ℕ) (hβ : ∀ j, 1 ≤ β j) :
    Submodule.span ℝ (realBoxVertices β : Set (Fin d → ℝ)) = ⊤ := by
  apply top_unique
  rw [← realCoefficientBox_span β hβ]
  apply Submodule.span_le.mpr
  rw [← convexHull_realBoxVertices]
  exact convexHull_min Submodule.subset_span (Submodule.convex _)

section LinearImage
variable {E : Type*} [AddCommGroup E] [Module ℝ E]

/-- Images of the actual corners; these need not all remain extreme points. -/
def linearImageBoxVertices (F : (Fin d → ℝ) →ₗ[ℝ] E) (β : Fin d → ℕ) : Finset E :=
  (realBoxVertices β).image F

theorem linearImageBoxVertices_card_le (F : (Fin d → ℝ) →ₗ[ℝ] E) (β : Fin d → ℕ) :
    (linearImageBoxVertices F β).card ≤ 2^d :=
  Finset.card_image_le.trans (realBoxVertices_card_le β)

/-- Linear images commute with this exact finite corner hull. -/
theorem convexHull_linearImageBoxVertices (F : (Fin d → ℝ) →ₗ[ℝ] E) (β : Fin d → ℕ) :
    convexHull ℝ (linearImageBoxVertices F β : Set E) = F '' realCoefficientBox β := by
  rw [linearImageBoxVertices, Finset.coe_image, ← F.image_convexHull,
    convexHull_realBoxVertices]

theorem linearImageBoxVertices_symmetric (F : (Fin d → ℝ) →ₗ[ℝ] E) (β : Fin d → ℕ)
    {x : E} (hx : x ∈ linearImageBoxVertices F β) : -x ∈ linearImageBoxVertices F β := by
  obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
  exact Finset.mem_image.mpr ⟨-y, realBoxVertices_symmetric β hy, map_neg F y⟩

/-- Surjectivity and positive widths force the actual image corners to span. -/
theorem linearImageBoxVertices_span (F : (Fin d → ℝ) →ₗ[ℝ] E)
    (hF : Function.Surjective F) (β : Fin d → ℕ) (hβ : ∀ j, 1 ≤ β j) :
    Submodule.span ℝ (linearImageBoxVertices F β : Set E) = ⊤ := by
  rw [linearImageBoxVertices, Finset.coe_image, Submodule.span_image,
    realBoxVertices_span β hβ, Submodule.map_top]
  exact LinearMap.range_eq_top.mpr hF

end LinearImage

section Normalization
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] {r : ℕ}

/-- The normalization of any surjective image of a positive-width coefficient
box is constructed from its finite image corners. -/
theorem linearImageBox_normalization (hr : 0 < r) (b : Basis (Fin r) ℝ E)
    (F : (Fin d → ℝ) →ₗ[ℝ] E) (hF : Function.Surjective F)
    (β : Fin d → ℕ) (hβ : ∀ j, 1 ≤ β j) :
    ∃ a : E ≃L[ℝ] EuclideanSpace ℝ (Fin r),
      {x | ∀ j, |x j| ≤ 1/(r:ℝ)} ⊆ a '' (F '' realCoefficientBox β) ∧
      a '' (F '' realCoefficientBox β) ⊆ {x | ∀ j, |x j| ≤ 1} := by
  obtain ⟨a, hinner, houter, _⟩ := exists_euclidean_vertex_normalization hr b
    (linearImageBoxVertices F β) (linearImageBoxVertices_span F hF β hβ)
    (fun x hx => linearImageBoxVertices_symmetric F β hx)
  rw [convexHull_linearImageBoxVertices] at hinner houter
  exact ⟨a, hinner, houter⟩

end Normalization

/-- The finite integer quotient body is exactly the hull of the real images
of the original corners. -/
theorem integerLinearImageBox_eq_convexHull (π : IntVec d →ₗ[ℤ] IntVec e) (β : Fin d → ℕ) :
    integerLinearImageBox π β =
      convexHull ℝ (linearImageBoxVertices (integerMapRealExtension π) β : Set (Fin e → ℝ)) :=
  (convexHull_linearImageBoxVertices (integerMapRealExtension π) β).symm

/-- All normalization assumptions for the actual quotient body follow from
its integer surjectivity and positive active widths. -/
theorem integerLinearImageBox_normalization (he : 0 < e)
    (π : IntVec d →ₗ[ℤ] IntVec e) (hπ : Function.Surjective π)
    (β : Fin d → ℕ) (hβ : ∀ j, 1 ≤ β j) :
    ∃ a : (Fin e → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin e),
      {x | ∀ j, |x j| ≤ 1/(e:ℝ)} ⊆ a '' integerLinearImageBox π β ∧
      a '' integerLinearImageBox π β ⊆ {x | ∀ j, |x j| ≤ 1} :=
  linearImageBox_normalization he (Pi.basisFun ℝ (Fin e))
    (integerMapRealExtension π) (integerMapRealExtension_surjective π hπ) β hβ

/-- In the primitive properization step, even quotient surjectivity is supplied
by the constructed splitting. Dimension zero is handled separately. -/
theorem primitiveQuotientBox_normalization (hd : 1 < d)
    (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1)
    (β : Fin d → ℕ) (hβ : ∀ j, 1 ≤ β j) :
    ∃ a : (Fin (d-1) → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin (d-1)),
      {x | ∀ j, |x j| ≤ 1/((d-1:ℕ):ℝ)} ⊆
        a '' integerLinearImageBox (primitiveQuotientMap p ℓ hp) β ∧
      a '' integerLinearImageBox (primitiveQuotientMap p ℓ hp) β ⊆
        {x | ∀ j, |x j| ≤ 1} :=
  integerLinearImageBox_normalization (by omega) (primitiveQuotientMap p ℓ hp)
    (primitiveQuotientMap_surjective p ℓ hp) β hβ

end
end Optss
