import Optss.FreimanDifferenceLift
import Optss.OldVectorDecoder
import Optss.ProgressionCoordinates

/-!
# Linear extension of a Freiman map on an integer box

Vanishing local second differences yield an actual integer homomorphism.
The centered origin fixes its constant term; zero-width coordinates require
no special nondegeneracy assumption.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {G H : Type*} [AddCommGroup G] [AddCommGroup H] [DecidableEq G] [DecidableEq H] {r : ℕ}

theorem centeredGridPoint_mem (β : Fin r → ℕ) (x : Fin r → ℕ)
    (hx : x ≤ fun j => 2*β j) :
    integerGridPoint (fun j => -(β j : ℤ)) x ∈ integerBudgetBox β := by
  rw [mem_integerBudgetBox]
  intro j
  have h := hx j
  dsimp only at h
  simp only [integerGridPoint,Pi.add_apply]
  exact abs_le.mpr ⟨by omega,by omega⟩

theorem exists_centeredGridPoint (β : Fin r → ℕ) (z : IntVec r)
    (hz : z ∈ integerBudgetBox β) :
    ∃ x : Fin r → ℕ, x ≤ (fun j => 2*β j) ∧
      integerGridPoint (fun j => -(β j : ℤ)) x=z := by
  refine ⟨fun j => (z j+β j).toNat,?_,?_⟩
  · intro j
    have h := abs_le.mp ((mem_integerBudgetBox β z).mp hz j)
    dsimp only at h ⊢
    omega
  · ext j
    have h := abs_le.mp ((mem_integerBudgetBox β z).mp hz j)
    dsimp only [integerGridPoint,Pi.add_apply] at h ⊢
    omega

/-- Every zero-preserving two-term Freiman map on a centered integer box
agrees there with an integer linear map. -/
theorem integerBox_freiman_linear (β : Fin r → ℕ) (ψ : IntVec r → G)
    (hzero : ψ 0=0)
    (hψ : ∀ x∈integerBudgetBox β, ∀ y∈integerBudgetBox β,
      ∀ z∈integerBudgetBox β, ∀ w∈integerBudgetBox β,
        x+y=z+w → ψ x+ψ y=ψ z+ψ w) :
    ∃ F : IntVec r →+ G, ∀ z∈integerBudgetBox β, F z=ψ z := by
  let origin : IntVec r := fun j => -(β j : ℤ)
  let m : Fin r → ℕ := fun j => 2*β j
  let f : (Fin r → ℕ) → G := fun x => ψ (integerGridPoint origin x)
  have hlocal : GridSecondDifferences f m := by
    intro x i j hdouble
    have hi : gridStep x i ≤ m := fun k => (Nat.le_add_right _ _).trans (hdouble k)
    have hj : gridStep x j ≤ m := by
      intro k
      have h := hdouble k
      rw [gridStep_comm] at h
      exact (Nat.le_add_right _ _).trans h
    have hx : x ≤ m := fun k => (Nat.le_add_right _ _).trans (hi k)
    apply hψ _ (centeredGridPoint_mem β x hx) _ (centeredGridPoint_mem β _ hdouble)
      _ (centeredGridPoint_mem β _ hi) _ (centeredGridPoint_mem β _ hj)
    simp only [integerGridPoint_step]
    abel
  let F := gridLinearPart (fun i => f (gridStep 0 i)-f 0)
  have haff : ∀ x, x≤m → f x=f 0+F (fun j => (x j : ℤ)) :=
    fun x hx => grid_affine_integer_formula f m hlocal x hx
  have hβ : β ≤ m := fun j => by dsimp only [m]; omega
  have hcenter : integerGridPoint origin β=0 := by ext j; simp [integerGridPoint,origin]
  have hc : f 0+F (fun j => (β j : ℤ))=0 := by
    rw [← haff β hβ]
    change ψ (integerGridPoint origin β)=0
    rwa [hcenter]
  refine ⟨F,?_⟩
  intro z hz
  obtain ⟨x,hx,hxz⟩ := exists_centeredGridPoint β z hz
  have he : (fun j => (x j : ℤ)) = z+(fun j => (β j : ℤ)) := by
    ext j
    have hj := congrFun hxz j
    dsimp only [integerGridPoint,Pi.add_apply] at hj ⊢
    omega
  have ha := haff x hx
  change ψ (integerGridPoint origin x)=_ at ha
  rw [hxz,he,map_add] at ha
  have : ψ z = F z+(f 0+F (fun j => (β j : ℤ))) := by rw [ha]; abel
  simpa only [hc,add_zero] using this.symm

/-- A proper GAP in the model's double difference lifts to an actual GAP
of exactly the same rank, widths and coefficient cardinality in the original
double difference. The inverse Freiman map is proved linear on the box. -/
theorem lift_model_progression (A : Finset G) (hA : A.Nonempty) (f : G → H)
    (hf : FreimanEight A f) (ρ : IntVec r →+ H) (β : Fin r → ℕ)
    (hP : integerProgressionValues ρ β ⊆
      (A.image f+A.image f)-(A.image f+A.image f))
    (hproper : Set.InjOn ρ (integerBudgetBox β)) :
    ∃ ρ' : IntVec r →+ G,
      (∀ z∈integerBudgetBox β, ρ' z=modelDifferenceLift A f (ρ z)) ∧
      integerProgressionValues ρ' β ⊆ (A+A)-(A+A) ∧
      Set.InjOn ρ' (integerBudgetBox β) ∧
      (integerProgressionValues ρ' β).card=(integerProgressionValues ρ β).card := by
  have hm (z : IntVec r) (hz : z∈integerBudgetBox β) :
      ρ z∈(A.image f+A.image f)-(A.image f+A.image f) :=
    hP (Finset.mem_image.mpr ⟨z,hz,rfl⟩)
  obtain ⟨ρ',hρ'⟩ := integerBox_freiman_linear β (fun z => modelDifferenceLift A f (ρ z))
    (by simpa only [map_zero] using modelDifferenceLift_zero hf hA) (by
      intro x hx y hy z hz w hw he
      apply (modelDifferenceLift_add_iff hf (hm x hx) (hm y hy) (hm z hz) (hm w hw)).mpr
      simpa only [map_add] using congrArg ρ he)
  have hinj : Set.InjOn ρ' (integerBudgetBox β) := by
    intro x hx y hy he
    rw [hρ' x hx,hρ' y hy] at he
    exact hproper hx hy (modelDifferenceLift_injective hf (hm x hx) (hm y hy) he)
  refine ⟨ρ',hρ',?_,hinj,?_⟩
  · intro x hx
    obtain ⟨z,hz,rfl⟩ := Finset.mem_image.mp hx
    rw [hρ' z hz]
    exact modelDifferenceLift_mem hf (hm z hz)
  · change ((integerBudgetBox β).image ρ').card=((integerBudgetBox β).image ρ).card
    rw [Finset.card_image_iff.mpr hinj,Finset.card_image_iff.mpr hproper]

end
end Optss
