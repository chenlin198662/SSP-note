import Optss.DyadicRankSelection
import Optss.NonproperProgressionGrowth

/-!
# Degree-gap obstruction to loss of properness

The least dyadic growth rank forces a growth factor strictly above the
largest degree allowed after a genuine progression relation. The bounds
below combine actual finite-set containments with the verified rank-drop
construction; no polynomial growth conclusion is assumed.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 1000000
local instance dyadicPropernessGrowthDecEqInt : DecidableEq ℤ := Classical.decEq _

/-- The fixed surplus `3/2` eventually exceeds any prescribed constant;
this explicit linear cutoff is sufficient for existence arguments. -/
theorem three_halves_pow_gt (C : ℝ) (k : ℕ) (hk : 2*C ≤ k) : C < (3/2:ℝ)^k := by
  have hh := one_add_mul_le_pow (by norm_num : (-2:ℝ) ≤ 1/2) k
  norm_num at hh
  nlinarith

/-- Compare the selected lower growth degree with an actual smaller-degree
upper bound, allowing a fixed shift between the two reference scales. -/
theorem dyadic_growth_degree_gap (q d t L : ℕ) (hdq : d ≤ q)
    (C x y : ℝ) (hx : 0 < x)
    (hlower : ((3/2:ℝ)*2^(q-1))^L*x ≤ y)
    (hupper : y ≤ C*(2:ℝ)^((t+L)*(d-1))*x) :
    (3/2:ℝ)^L ≤ C*(2:ℝ)^(t*(d-1)) := by
  have hexp : d-1 ≤ q-1 := Nat.sub_le_sub_right hdq 1
  have hp := pow_le_pow_right₀ (by norm_num : (1:ℝ) ≤ 2) hexp
  have hpk := pow_le_pow_left₀ (by positivity : (0:ℝ) ≤ 2^(d-1)) hp L
  have hlower' : (3/2:ℝ)^L*(2:ℝ)^(L*(d-1))*x ≤ y := by
    apply le_trans ?_ hlower
    rw [mul_pow, Nat.mul_comm L (d-1), pow_mul]
    exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hpk (by positivity)) hx.le
  have hu : y ≤ (C*(2:ℝ)^(t*(d-1)))*(2:ℝ)^(L*(d-1))*x := by
    convert hupper using 1
    simp only [Nat.add_mul, pow_add]
    ring
  have hpos : (0:ℝ) < (2:ℝ)^(L*(d-1))*x := mul_pos (by positivity) hx
  apply (mul_le_mul_right hpos).mp
  nlinarith

/-- The set identity behind all multiplicative dyadic scale changes. -/
theorem dyadicSumset_add_scale (A : Finset ℤ) (u k : ℕ) :
    dyadicSumset A (u+k) = (2^k) • dyadicSumset A u := by
  apply Finset.coe_injective
  simp only [dyadicSumset, Finset.coe_nsmul, pow_add, mul_nsmul]

/-- If a proper rank-`d` progression contains a dyadic sumset and is filled
at a bounded later scale, a sufficiently long rank-`q` growth window
forces its triple coefficient box to stay proper. -/
theorem progression_triple_proper_of_dyadic_growth {d : ℕ}
    (A : Finset ℤ) (hzero : 0 ∈ A) (a b q : ℕ) (hq : 0 < q) (hdq : d ≤ q)
    (hminimal : ∀ p < q, ∀ i, a ≤ i → i ≤ b →
      (3/2:ℝ)*2^p*(dyadicSumset A i).card < (dyadicSumset A (i+1)).card)
    (ρ : IntVec d →+ ℤ) (β : Fin d → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox β))
    (u t L : ℕ) (hau : a ≤ u+t) (hwindow : u+t+L ≤ b+1)
    (hcontain : dyadicSumset A u ⊆ integerProgressionValues ρ β)
    (hfill : ∃ z : ℤ, (integerProgressionValues ρ β).image (z+·) ⊆ dyadicSumset A (u+t))
    (hlong : 2*(properizationIterationFactor latticeReductionDefectBound 3 d : ℝ)*
      (2:ℝ)^(t*(d-1)) ≤ L) :
    Set.InjOn ρ (integerBudgetBox (fun j => 3*β j)) := by
  by_contra hbad
  let P := integerProgressionValues ρ β
  let C := properizationIterationFactor latticeReductionDefectBound 3 d
  have hupp := nonproper_integerProgression_growth ρ β 3 (2^(t+L))
    (Nat.one_le_pow _ _ (by decide)) hproper hbad
  have hsub : dyadicSumset A (u+(t+L)) ⊆ (2^(t+L):ℕ) • P := by
    rw [dyadicSumset_add_scale]
    exact Finset.nsmul_subset_nsmul_left hcontain
  obtain ⟨z, hz⟩ := hfill
  have hPcard : P.card ≤ (dyadicSumset A (u+t)).card := by
    have hh := Finset.card_le_card hz
    rwa [Finset.card_image_of_injective _ (add_right_injective _)] at hh
  have hupperNat : (dyadicSumset A (u+(t+L))).card ≤
      C * 2^((t+L)*(d-1)) * (dyadicSumset A (u+t)).card := by
    calc
      _ ≤ ((2^(t+L):ℕ) • P).card := Finset.card_le_card hsub
      _ ≤ (2^(t+L))^(d-1)*C*P.card := by simpa only [P, C] using hupp
      _ ≤ (2^(t+L))^(d-1)*C*(dyadicSumset A (u+t)).card :=
        Nat.mul_le_mul_left _ hPcard
      _ = _ := by rw [← pow_mul]; ring
  have hupper : ((dyadicSumset A ((u+t)+L)).card:ℝ) ≤
      C*(2:ℝ)^((t+L)*(d-1))*(dyadicSumset A (u+t)).card := by
    simpa only [Nat.add_assoc] using (show ((dyadicSumset A (u+(t+L))).card:ℝ) ≤
      C*(2:ℝ)^((t+L)*(d-1))*(dyadicSumset A (u+t)).card by exact_mod_cast hupperNat)
  have hlower := dyadic_minimal_rank_growth A a b q hq hminimal (u+t) L hau hwindow
  have hpos : (0:ℝ) < (dyadicSumset A (u+t)).card := by
    exact_mod_cast (Finset.card_pos.mpr ⟨0, zero_mem_integer_repeated_sumset A hzero _⟩)
  have hgap := dyadic_growth_degree_gap q d t L hdq (C:ℝ) _ _ hpos hlower hupper
  exact (not_lt_of_ge hgap) (three_halves_pow_gt _ L (by simpa only [C, mul_assoc] using hlong))

end
end Optss
