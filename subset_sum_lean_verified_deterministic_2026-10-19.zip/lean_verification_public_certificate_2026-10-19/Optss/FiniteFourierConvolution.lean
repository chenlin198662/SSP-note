import Mathlib.Analysis.Fourier.ZMod
import Mathlib.Analysis.Fourier.FiniteAbelian.Orthogonality
import Optss.Basic

/-!
# Finite cyclic convolution and its Fourier transform

These exact identities are the Fourier input to the finite Bogolyubov step
in the Freiman construction. Counting-measure normalization agrees with
mathlib's discrete Fourier transform: inversion divides by the group order.
-/

namespace Optss
noncomputable section
open scoped BigOperators ComplexConjugate
variable {N : ℕ} [NeZero N]

def cyclicConvolution (f g : ZMod N → ℂ) (x : ZMod N) : ℂ :=
  ∑ y, f y * g (x-y)

theorem cyclicConvolution_comm (f g : ZMod N → ℂ) :
    cyclicConvolution f g = cyclicConvolution g f := by
  funext x
  unfold cyclicConvolution
  apply Fintype.sum_equiv (Equiv.subLeft x)
  intro y
  simp only [Equiv.subLeft_apply,sub_sub_cancel]
  ring

theorem cyclic_dft_translation (g : ZMod N → ℂ) (a k : ZMod N) :
    ZMod.dft (fun x => g (x-a)) k =
      ZMod.stdAddChar (-(a*k)) * ZMod.dft g k := by
  simp only [ZMod.dft_apply,smul_eq_mul,Finset.mul_sum]
  apply Fintype.sum_equiv (Equiv.subRight a)
  intro x
  simp only [Equiv.subRight_apply]
  have he : -(x*k) = -(a*k) + -((x-a)*k) := by ring
  rw [he,AddChar.map_add_eq_mul]
  ring

theorem cyclic_dft_convolution (f g : ZMod N → ℂ) :
    ZMod.dft (cyclicConvolution f g) = fun k => ZMod.dft f k * ZMod.dft g k := by
  funext k
  rw [ZMod.dft_apply]
  simp only [cyclicConvolution,smul_eq_mul,Finset.mul_sum]
  rw [Finset.sum_comm]
  calc
    (∑ y, ∑ x, ZMod.stdAddChar (-(x*k)) * (f y * g (x-y))) =
        ∑ y, f y * ZMod.dft (fun x => g (x-y)) k := by
      apply Finset.sum_congr rfl
      intro y _
      simp only [ZMod.dft_apply,smul_eq_mul,Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro x _
      ring
    _ = ∑ y, f y * (ZMod.stdAddChar (-(y*k)) * ZMod.dft g k) := by
      simp only [cyclic_dft_translation]
    _ = ZMod.dft f k * ZMod.dft g k := by
      simp only [ZMod.dft_apply,smul_eq_mul,Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro y _
      ring

def cyclicAdjoint (f : ZMod N → ℂ) (x : ZMod N) : ℂ := conj (f (-x))

theorem cyclic_dft_adjoint (f : ZMod N → ℂ) :
    ZMod.dft (cyclicAdjoint f) = fun k => conj (ZMod.dft f k) := by
  funext k
  simp only [ZMod.dft_apply,cyclicAdjoint,smul_eq_mul,map_sum,map_mul]
  apply Fintype.sum_equiv (Equiv.neg _)
  intro x
  simp only [Equiv.neg_apply,neg_mul,neg_neg]
  rw [← AddChar.inv_apply_eq_conj, ← AddChar.map_neg_eq_inv]

/-- Counting-measure inversion, with the group order moved to the left. -/
theorem cyclic_fourier_inversion (f : ZMod N → ℂ) (x : ZMod N) :
    (N : ℂ) * f x = ∑ k, ZMod.stdAddChar (k*x) * ZMod.dft f k := by
  have h := congrFun (ZMod.dft_dft f) (-x)
  simpa only [ZMod.dft_apply,smul_eq_mul,mul_neg,neg_neg] using h.symm

theorem cyclicConvolution_adjoint_zero (f : ZMod N → ℂ) :
    cyclicConvolution f (cyclicAdjoint f) 0 = ∑ x, (Complex.normSq (f x) : ℂ) := by
  simp only [cyclicConvolution,cyclicAdjoint,zero_sub,neg_neg,Complex.mul_conj]

/-- Parseval's identity with the exact normalization used by `ZMod.dft`. -/
theorem cyclic_parseval (f : ZMod N → ℂ) :
    ∑ k, Complex.normSq (ZMod.dft f k) = (N : ℝ) * ∑ x, Complex.normSq (f x) := by
  have h := cyclic_fourier_inversion (cyclicConvolution f (cyclicAdjoint f)) 0
  simp only [mul_zero,AddChar.map_zero_eq_one,one_mul,cyclic_dft_convolution,
    cyclic_dft_adjoint,Complex.mul_conj,cyclicConvolution_adjoint_zero] at h
  exact_mod_cast h.symm

end
end Optss
