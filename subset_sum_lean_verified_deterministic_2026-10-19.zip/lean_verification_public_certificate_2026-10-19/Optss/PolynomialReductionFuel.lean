import Optss.ReductionFuelStability
import Optss.LatticeArithmeticInputBits

/-!
# Polynomial-size fuel for the actual reduction

A completed deterministic run is unchanged by any new fuel exceeding its
actual swap count. The proved logarithmic potential bound therefore gives
polynomial-size unary fuel directly from input bit lengths. No huge potential
or height power needs to be constructed by the executed fuel initializer.
-/

namespace Optss
variable {r d : ℕ}

/-- Sufficient potential fuel always reaches the stopping branch before fuel
exhaustion, rather than merely returning a well-formed truncated state. -/
theorem executableReductionFuel_swaps_lt (fuel : ℕ) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (hf : gramPotential A ≤ fuel) : (executableReductionFuel fuel A).2 < fuel := by
  induction fuel generalizing A with
  | zero => exact False.elim (by have := gramPotential_pos A hA; omega)
  | succ n ih =>
    let C := executableSizeSweep A
    obtain ⟨hC, _, hpotC, _⟩ := executableSizeSweep_spec A hA
    change LinearIndependent ℝ (fun i j => (C i j:ℝ)) at hC
    change gramPotential C = gramPotential A at hpotC
    letI : Decidable (failingAdjacentPairs C).Nonempty := decidableFailingAdjacentPairs C
    by_cases hfail : (failingAdjacentPairs C).Nonempty
    · let p := leastFailingAdjacentPair C hfail
      have hbad := (mem_failingAdjacentPairs C p).mp (leastFailingAdjacentPair_mem C hfail)
      have hswap : LinearIndependent ℝ (fun i j => (swapRows C p.1 p.2 i j:ℝ)) :=
        hC.comp (Equiv.swap p.1 p.2) (Equiv.swap p.1 p.2).injective
      have hcontract : 4*gramPotential (swapRows C p.1 p.2) < 3*gramPotential A := by
        rw [← hpotC]
        exact gramPotential_swap_three_quarters C hC p.1 p.2 hbad.1 hbad.2
      have hi := ih (swapRows C p.1 p.2) hswap (by omega)
      simpa only [executableReductionFuel, show executableSizeSweep A = C from rfl,
        dif_pos hfail, p] using Nat.succ_lt_succ hi
    · simp only [executableReductionFuel, show executableSizeSweep A = C from rfl,
        dif_neg hfail, Prod.snd, Nat.zero_lt_succ]

/-- Pure deterministic stability: any completed reference run gives the same
answer with fuel strictly greater than its observed number of swaps. -/
theorem executableReductionFuel_stable_of_stopped (fuel other : ℕ)
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hf : (executableReductionFuel fuel A).2 < fuel)
    (ho : (executableReductionFuel fuel A).2 < other) :
    executableReductionFuel fuel A = executableReductionFuel other A := by
  induction fuel generalizing A other with
  | zero => exact False.elim (Nat.not_lt_zero _ hf)
  | succ n ih =>
    cases other with
    | zero => exact False.elim (Nat.not_lt_zero _ ho)
    | succ m =>
      let C := executableSizeSweep A
      letI : Decidable (failingAdjacentPairs C).Nonempty := decidableFailingAdjacentPairs C
      by_cases hfail : (failingAdjacentPairs C).Nonempty
      · let p := leastFailingAdjacentPair C hfail
        have hs : executableReductionFuel (n+1) A =
            ((executableReductionFuel n (swapRows C p.1 p.2)).1,
             (executableReductionFuel n (swapRows C p.1 p.2)).2+1) := by
          simp only [executableReductionFuel, show executableSizeSweep A = C from rfl, dif_pos hfail, p]
        rw [hs] at hf ho
        have he := ih m (swapRows C p.1 p.2) (by exact Nat.lt_of_succ_lt_succ hf)
          (by exact Nat.lt_of_succ_lt_succ ho)
        rw [hs, executableReductionFuel]
        simp only [show executableSizeSweep A = C from rfl, dif_pos hfail]
        exact congrArg (fun out : Matrix (Fin r) (Fin d) ℤ × ℕ => (out.1,out.2+1)) he
      · simp only [executableReductionFuel, show executableSizeSweep A = C from rfl, dif_neg hfail]

def polynomialReductionFuel (r d H : ℕ) : ℕ :=
  3*(r*(r+1)+1)*(r.size+d.size+2*H.size+4)

theorem executableReductionFuel_polynomial_eq (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) :
    executableReductionFuel (polynomialReductionFuel r d H) A =
      executableReductionFuel (gramPotential A) A := by
  have hf := executableReductionFuel_swaps_lt (gramPotential A) A hA le_rfl
  have hb := (executableIntegerReduction A hA).swapCount_input_bits A H hH
  change (executableReductionFuel (gramPotential A) A).2+1 ≤ polynomialReductionFuel r d H at hb
  exact (executableReductionFuel_stable_of_stopped _ _ A hf (by omega)).symm

/-- Explicit unary loop fuel; allocation is polynomial in original bit size. -/
def polynomialReductionFuelList (r d H : ℕ) : List Bool :=
  List.replicate (polynomialReductionFuel r d H) false

theorem polynomialReductionFuelList_length (r d H : ℕ) :
    (polynomialReductionFuelList r d H).length =
      3*(r*(r+1)+1)*(r.size+d.size+2*H.size+4) := by
  simp only [polynomialReductionFuelList, List.length_replicate, polynomialReductionFuel]

/-- This initializer uses only dimensions and the observed bit width; the
exponential height `2^L` is confined to the proof. -/
def bitLengthReductionFuel (r d L : ℕ) : ℕ :=
  3*(r*(r+1)+1)*(r.size+d.size+2*(L+1)+4)

def bitLengthReductionFuelList (r d L : ℕ) : List Bool :=
  List.replicate (bitLengthReductionFuel r d L) false

theorem bitLengthReductionFuelList_length (r d L : ℕ) :
    (bitLengthReductionFuelList r d L).length = bitLengthReductionFuel r d L := by
  simp only [bitLengthReductionFuelList, List.length_replicate]

theorem executableReductionFuel_bit_length_eq (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (L : ℕ) (hL : ∀ i j, (A i j).natAbs.size ≤ L) :
    executableReductionFuel (bitLengthReductionFuel r d L) A =
      executableReductionFuel (gramPotential A) A := by
  have hH : ∀ i j, |A i j| ≤ (2^L:ℕ) := by
    intro i j
    rw [← Int.natCast_natAbs]
    exact Int.ofNat_le.mpr (Nat.size_le.mp (hL i j)).le
  have he := executableReductionFuel_polynomial_eq A hA (2^L) hH
  simpa only [polynomialReductionFuel, Nat.size_pow, bitLengthReductionFuel] using he

/-- Polynomial-bit fuel reaches the same certified materialized output. This
is the semantic interface used by the loop on an actual fuel list. -/
theorem materializedReductionFuel_bit_length_eq (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ)))
    (L : ℕ) (hL : ∀ i j, (integerMatrixDataRows D i j).natAbs.size ≤ L) :
    (integerMatrixDataRows (materializedReductionFuel (bitLengthReductionFuel r d L) D).1,
      (materializedReductionFuel (bitLengthReductionFuel r d L) D).2) =
      (integerMatrixDataRows (cachedReductionData (integerMatrixDataRows D)).1,
        (cachedReductionData (integerMatrixDataRows D)).2) := by
  rw [materializedReductionFuel_eq, cachedReductionFuel_eq _ _ hD,
    executableReductionFuel_bit_length_eq _ hD L hL]
  exact (cachedIntegerReduction_data_eq (integerMatrixDataRows D) hD).symm

theorem materializedReductionFuel_bit_length_spec (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ)))
    (L : ℕ) (hL : ∀ i j, (integerMatrixDataRows D i j).natAbs.size ≤ L) :
    IntegerReductionSpecification (integerMatrixDataRows D)
      (integerMatrixDataRows (materializedReductionFuel (bitLengthReductionFuel r d L) D).1)
      (materializedReductionFuel (bitLengthReductionFuel r d L) D).2 := by
  have h := cachedIntegerReduction_spec (integerMatrixDataRows D) hD
  have he := materializedReductionFuel_bit_length_eq D hD L hL
  have hm := congrArg Prod.fst he
  have hs := congrArg Prod.snd he
  dsimp only [Prod.fst, Prod.snd] at hm hs
  rw [hm,hs]
  exact h

end Optss
