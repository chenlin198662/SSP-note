import Optss.ListStoredReductionLoop
import Optss.ListStoredRationalSize
import Optss.StructuralRationalReduction
import Optss.ListStorageFuel

/-!
# Rational reduction on actual list storage

Input clearing, reduction, and normalized output all run on nested lists of
Boolean payloads. The vector projection below belongs solely to the proof;
it is not called by the answer routine.
-/

namespace Optss
variable {r d : ℕ}

theorem listMatrixVector_eq_ioMatrixVector {α : Type*}
    (A : BooleanListArray (BooleanListArray α d) r) :
    listMatrixVector A = ioMatrixVector A := rfl

/-- Full rational answer path with externally supplied structural fuel. -/
def listStoredRationalReductionFuel (fuel : List Bool) (A : ListBitRationalMatrixData r d) :
    ListBitRationalMatrixData r d × List Bool :=
  let cleared := listStoredClearRationalInput A
  let out := listStoredReductionFuel fuel cleared.2
  (listStoredUnscale cleared.1 out.rows,out.swapTicks)

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

theorem listStoredUnscale_eq (D : List Bool) (B : ListBitIntegerMatrixData r d) :
    ioMatrixVector (listStoredUnscale D B) =
      Vector.ofFn fun i => Vector.ofFn fun j =>
        bitListUnscaleInteger D (((ioMatrixVector B).get i).get j) := by
  apply Vector.ext
  intro i hi
  apply Vector.ext
  intro j hj
  change ((ioMatrixVector (listStoredUnscale D B)).get ⟨i,hi⟩).get ⟨j,hj⟩ = _
  rw [listStoredUnscale_get]
  simp only [Vector.getElem_ofFn]

/-- Exact encoded result and swap count, without any normalization or
independence premise, for every supplied fuel list. -/
theorem listStoredRationalReductionFuel_eq (fuel : List Bool) (A : ListBitRationalMatrixData r d) :
    (ioMatrixVector (listStoredRationalReductionFuel fuel A).1,
      (listStoredRationalReductionFuel fuel A).2.length) =
    let cleared := bitListClearRationalInput (ioMatrixVector A)
    let out := encodedReductionFuel fuel cleared.2
    (Vector.ofFn (fun i => Vector.ofFn fun j =>
      bitListUnscaleInteger cleared.1 ((out.rows.get i).get j)),out.swaps) := by
  have hc := listStoredClearRationalInput_eq A
  have hc₁ := congrArg Prod.fst hc
  have hc₂ := congrArg Prod.snd hc
  have hl := listStoredReductionFuel_eq fuel (listStoredClearRationalInput A).2
  simp only [listMatrixVector_eq_ioMatrixVector] at hl
  have hl₁ := congrArg Prod.fst hl
  have hl₂ := congrArg Prod.snd hl
  dsimp only at hc₁ hc₂ hl₁ hl₂
  simp only [listStoredRationalReductionFuel,listStoredUnscale_eq,hl₁,hl₂,hc₁,hc₂]

/-- Final rational routine. The denominator is computed once, the sufficient
fuel is constructed from the cleared input lists, and swaps are list ticks. -/
def listStoredRationalReduction (A : ListBitRationalMatrixData r d) :
    ListBitRationalMatrixData r d × List Bool :=
  let cleared := listStoredClearRationalInput A
  let out := listStoredReductionFuel (listStoredStructuralFuel cleared.2) cleared.2
  (listStoredUnscale cleared.1 out.rows,out.swapTicks)

/-- Literal equality of output encodings with the structurally initialized
reference algorithm, including the exact swap count. -/
theorem listStoredRationalReduction_eq (A : ListBitRationalMatrixData r d) :
    (ioMatrixVector (listStoredRationalReduction A).1,
      (listStoredRationalReduction A).2.length) =
      structuralEncodedRationalReduction (ioMatrixVector A) := by
  change (ioMatrixVector (listStoredRationalReductionFuel
    (listStoredStructuralFuel (listStoredClearRationalInput A).2) A).1,
    (listStoredRationalReductionFuel
    (listStoredStructuralFuel (listStoredClearRationalInput A).2) A).2.length) = _
  rw [listStoredRationalReductionFuel_eq,listStoredStructuralFuel_eq]
  have hc := congrArg Prod.snd (listStoredClearRationalInput_eq A)
  dsimp only at hc
  rw [hc]
  rfl

/-- Native list-encoded rational input gives a reduced basis of exactly the
same entire lattice, with the paper's sharp orthogonality-defect bound. -/
theorem listStoredRationalReduction_spec (A : ListBitRationalMatrixData r r)
    (hWF : ∀ i j, (((ioMatrixVector A).get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows (ioMatrixVector A) i j : ℝ))) :
    Submodule.span ℤ (Set.range (encodedFractionRows
      (ioMatrixVector (listStoredRationalReduction A).1))) =
      Submodule.span ℤ (Set.range (encodedFractionRows (ioMatrixVector A))) ∧
    ∃ b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)),
      (∀ i, b i = rationalEuclideanRows (encodedFractionRows
        (ioMatrixVector (listStoredRationalReduction A).1)) i) ∧
      euclideanOrthogonalityDefect b ≤ sharpLatticeDefectBound r := by
  have he := congrArg Prod.fst (listStoredRationalReduction_eq A)
  dsimp only at he
  rw [he]
  exact structuralEncodedRationalReduction_spec _ hWF hA

/-- Every returned Boolean fraction is normalized, including signed zero. -/
theorem listStoredRationalReduction_wellFormed (A : ListBitRationalMatrixData r d)
    (hWF : ∀ i j, (((ioMatrixVector A).get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows (ioMatrixVector A) i j : ℝ))) :
    ∀ i j, (((ioMatrixVector (listStoredRationalReduction A).1).get i).get j).WellFormed := by
  have he := congrArg Prod.fst (listStoredRationalReduction_eq A)
  dsimp only at he
  rw [he,structuralEncodedRationalReduction_eq _ hWF hA]
  exact encodedRationalReduction_wellFormed _ (fun i j => (hWF i j).2.2.1)

end Optss
