import Mathlib.Algebra.Polynomial.Inductions
import Mathlib.Algebra.Polynomial.Eval.Degree
import Mathlib.Algebra.Polynomial.BigOperators
import Mathlib.Data.Nat.Size
import Mathlib.Tactic

/-!
# Exact convolution by packing nonnegative coefficients

Evaluation at a sufficiently large natural base packs a coefficient array into
one integer. Multiplication of the packed integers and digit extraction recover
the exact convolution. Explicit coefficient bounds rule out carries. This
formalizes the arithmetic correctness of the packing primitive, without a
running-time claim for integer multiplication.
-/

namespace Optss
open scoped BigOperators
open Polynomial

/-- Splitting off the constant coefficient is the arithmetic base expansion. -/
theorem polynomial_eval_divX (p : Polynomial ℕ) (b : ℕ) :
    p.eval b = p.coeff 0 + b * p.divX.eval b := by
  have h := congrArg (Polynomial.eval b) (Polynomial.X_mul_divX_add p)
  simpa [Nat.add_comm] using h.symm

/-- For coefficients smaller than the base, one integer division removes
exactly the constant coefficient. -/
theorem polynomial_eval_div_base (p : Polynomial ℕ) (b : ℕ) (hb : 0 < b)
    (hp : p.coeff 0 < b) : p.eval b / b = p.divX.eval b := by
  rw [polynomial_eval_divX, Nat.add_mul_div_left _ _ hb, Nat.div_eq_of_lt hp]
  simp

/-- Extracting digit `i` of the packed evaluation gives coefficient `i`.
The result includes indices beyond the polynomial's degree. -/
theorem polynomial_coeff_eq_packed_digit (p : Polynomial ℕ) (b : ℕ)
    (hb : 0 < b) (hp : ∀ i, p.coeff i < b) (i : ℕ) :
    p.eval b / b ^ i % b = p.coeff i := by
  induction i generalizing p with
  | zero =>
    simp only [pow_zero, Nat.div_one]
    rw [polynomial_eval_divX]
    simp [Nat.add_mod, Nat.mod_eq_of_lt (hp 0)]
  | succ i ih =>
    rw [pow_succ', ← Nat.div_div_eq_div_mul, polynomial_eval_div_base p b hb (hp 0)]
    simpa using ih p.divX (fun j => by simpa using hp (j + 1))

/-- Under a no-carry coefficient bound, one packed integer multiplication
recovers every coefficient of the polynomial product. -/
theorem packed_convolution_of_coeff_lt (p q : Polynomial ℕ) (b : ℕ)
    (hb : 0 < b) (hcoeff : ∀ i, (p * q).coeff i < b) (i : ℕ) :
    (p.eval b * q.eval b) / b ^ i % b = (p * q).coeff i := by
  rw [← Polynomial.eval_mul]
  exact polynomial_coeff_eq_packed_digit (p * q) b hb hcoeff i

/-- A shifted scalar multiple of a bounded coefficient array stays bounded
by the scalar times the same bound. -/
theorem monomial_mul_coeff_le (q : Polynomial ℕ) (n a C : ℕ)
    (hq : ∀ j, q.coeff j ≤ C) (i : ℕ) :
    (Polynomial.monomial n a * q).coeff i ≤ a * C := by
  rw [← Polynomial.C_mul_X_pow_eq_monomial, mul_assoc,
    Polynomial.coeff_C_mul, Polynomial.coeff_X_pow_mul']
  split_ifs
  · exact Nat.mul_le_mul_left a (hq _)
  · simp

/-- Length and coefficient maxima give a uniform bound on all output
coefficients. At most `n` input coefficients contribute to any one output. -/
theorem polynomial_mul_coeff_le_length (p q : Polynomial ℕ) (n A C : ℕ)
    (hpdeg : p.natDegree < n) (hp : ∀ j, p.coeff j ≤ A)
    (hq : ∀ j, q.coeff j ≤ C) (i : ℕ) :
    (p * q).coeff i ≤ n * A * C := by
  classical
  calc
    (p * q).coeff i =
        (∑ j ∈ Finset.range n, Polynomial.monomial j (p.coeff j) * q).coeff i := by
      rw [← Finset.sum_mul, ← Polynomial.as_sum_range' p n hpdeg]
    _ = ∑ j ∈ Finset.range n, (Polynomial.monomial j (p.coeff j) * q).coeff i := by
      rw [Polynomial.finset_sum_coeff]
    _ ≤ ∑ _j ∈ Finset.range n, A * C := by
      apply Finset.sum_le_sum
      intro j _
      exact (monomial_mul_coeff_le q j (p.coeff j) C hq i).trans
        (Nat.mul_le_mul_right C (hp j))
    _ = n * A * C := by simp [Nat.mul_assoc]

/-- Exact packed convolution with the explicit carry-free base `n*A*C+1`.
The output includes its exact integer counts, not merely Boolean support. -/
theorem packed_convolution (p q : Polynomial ℕ) (n A C : ℕ)
    (hpdeg : p.natDegree < n) (hp : ∀ j, p.coeff j ≤ A)
    (hq : ∀ j, q.coeff j ≤ C) (i : ℕ) :
    (p.eval (n * A * C + 1) * q.eval (n * A * C + 1)) /
      (n * A * C + 1) ^ i % (n * A * C + 1) = (p * q).coeff i := by
  apply packed_convolution_of_coeff_lt p q _ (by omega)
  intro j
  exact Nat.lt_succ_of_le (polynomial_mul_coeff_le_length p q n A C hpdeg hp hq j)

/-- The exact extracted count is the standard discrete convolution sum. -/
theorem packed_convolution_sum (p q : Polynomial ℕ) (n A C : ℕ)
    (hpdeg : p.natDegree < n) (hp : ∀ j, p.coeff j ≤ A)
    (hq : ∀ j, q.coeff j ≤ C) (i : ℕ) :
    (p.eval (n * A * C + 1) * q.eval (n * A * C + 1)) /
      (n * A * C + 1) ^ i % (n * A * C + 1) =
      ∑ ab ∈ Finset.antidiagonal i, p.coeff ab.1 * q.coeff ab.2 := by
  rw [packed_convolution p q n A C hpdeg hp hq, Polynomial.coeff_mul]

/-- Boolean convolution can use the small base `n+1`, and an extracted
positive digit is exactly a pair of positive input entries at matching indices. -/
theorem packed_boolean_convolution_pos_iff (p q : Polynomial ℕ) (n : ℕ)
    (hpdeg : p.natDegree < n) (hp : ∀ j, p.coeff j ≤ 1)
    (hq : ∀ j, q.coeff j ≤ 1) (i : ℕ) :
    0 < (p.eval (n + 1) * q.eval (n + 1)) / (n + 1) ^ i % (n + 1) ↔
      ∃ a b, a + b = i ∧ 0 < p.coeff a ∧ 0 < q.coeff b := by
  have h := packed_convolution p q n 1 1 hpdeg hp hq i
  simp only [Nat.mul_one] at h
  rw [h, Polynomial.coeff_mul]
  constructor
  · intro hs
    by_contra hn
    push_neg at hn
    have hz : ∑ ab ∈ Finset.antidiagonal i, p.coeff ab.1 * q.coeff ab.2 = 0 := by
      apply Finset.sum_eq_zero
      intro ab hab
      have hne := hn ab.1 ab.2 (Finset.mem_antidiagonal.mp hab)
      by_cases hp0 : 0 < p.coeff ab.1
      · have hq0 := hne hp0
        have : q.coeff ab.2 = 0 := by omega
        simp [this]
      · have : p.coeff ab.1 = 0 := by omega
        simp [this]
    omega
  · rintro ⟨a, b, hab, ha, hb⟩
    exact Finset.sum_pos' (fun _ _ => Nat.zero_le _)
      ⟨(a, b), Finset.mem_antidiagonal.mpr hab, Nat.mul_pos ha hb⟩

/-- An `n`-digit packing is strictly below the `n`th power of its base,
including leading zero coefficients and the degenerate base one. -/
theorem packed_sum_lt_pow (a : ℕ → ℕ) (b n : ℕ) (hb : 0 < b)
    (ha : ∀ i < n, a i < b) :
    (∑ i ∈ Finset.range n, a i * b ^ i) < b ^ n := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hprev := ih (fun i hi => ha i (by omega))
    have hlast := ha n (by omega)
    rw [Finset.sum_range_succ, pow_succ]
    have hpow : 0 < b ^ n := pow_pos hb n
    nlinarith

/-- The packed representation occupies at most `n` base-`b` digits. -/
theorem polynomial_eval_lt_pow (p : Polynomial ℕ) (b n : ℕ)
    (hb : 0 < b) (hpdeg : p.natDegree < n) (hp : ∀ i, p.coeff i < b) :
    p.eval b < b ^ n := by
  rw [Polynomial.eval_eq_sum_range' hpdeg]
  exact packed_sum_lt_pow p.coeff b n hb (fun i _ => hp i)

/-- Explicit bit length of a packed coefficient array. This is an encoding
size bound, independent of any implementation of large integer multiplication. -/
theorem packed_polynomial_bits (p : Polynomial ℕ) (b n : ℕ)
    (hb : 0 < b) (hpdeg : p.natDegree < n) (hp : ∀ i, p.coeff i < b) :
    (p.eval b).size ≤ n * b.size := by
  apply Nat.size_le.mpr
  calc
    p.eval b < b ^ n := polynomial_eval_lt_pow p b n hb hpdeg hp
    _ ≤ (2 ^ b.size) ^ n := Nat.pow_le_pow_left (Nat.lt_size_self b).le n
    _ = _ := by rw [← pow_mul, Nat.mul_comm]

/-- A slightly enlarged base simultaneously controls both input encodings
and prevents output carries, even when one coefficient bound is zero. -/
theorem packed_convolution_with_encoding_bounds (p q : Polynomial ℕ)
    (n m A C : ℕ) (hpdeg : p.natDegree < n) (hqdeg : q.natDegree < m)
    (hp : ∀ j, p.coeff j ≤ A) (hq : ∀ j, q.coeff j ≤ C) :
    let b := n * (A + 1) * (C + 1) + 1
    (p.eval b).size ≤ n * b.size ∧
    (q.eval b).size ≤ m * b.size ∧
    ∀ i, (p.eval b * q.eval b) / b ^ i % b = (p * q).coeff i := by
  dsimp only
  have hn : 1 ≤ n := by omega
  have hna : 1 ≤ n * (A + 1) := by nlinarith
  have hA : A < n * (A + 1) * (C + 1) + 1 := by
    have h₁ : A + 1 ≤ n * (A + 1) := by
      simpa using Nat.mul_le_mul_right (A + 1) hn
    have h₂ : n * (A + 1) ≤ n * (A + 1) * (C + 1) := by
      simpa using Nat.mul_le_mul_left (n * (A + 1)) (show 1 ≤ C + 1 by omega)
    omega
  have hC : C < n * (A + 1) * (C + 1) + 1 := by
    have h : C + 1 ≤ n * (A + 1) * (C + 1) := by
      simpa using Nat.mul_le_mul_right (C + 1) hna
    omega
  refine ⟨packed_polynomial_bits p _ n (by omega) hpdeg (fun i => (hp i).trans_lt hA),
    packed_polynomial_bits q _ m (by omega) hqdeg (fun i => (hq i).trans_lt hC), ?_⟩
  intro i
  apply packed_convolution_of_coeff_lt p q _ (by omega)
  intro j
  have hcoeff := polynomial_mul_coeff_le_length p q n A C hpdeg hp hq j
  have hbound : n * A * C ≤ n * (A + 1) * (C + 1) :=
    Nat.mul_le_mul (Nat.mul_le_mul_left n (by omega)) (by omega)
  omega

end Optss
