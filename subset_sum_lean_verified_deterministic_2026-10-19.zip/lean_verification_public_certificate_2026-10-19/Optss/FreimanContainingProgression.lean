import Optss.FreimanUniformBounds
import Optss.BohrProgression
import Optss.ModelingParameters

/-!
# A containing progression from small doubling in a bounded integer interval

All existence inputs are discharged: bounded dense modeling, the finite
Fourier argument, the actual phase lattice and inner progression, inverse
Freiman lifting, Ruzsa covering, and properization. The constants below depend
only on the doubling bound and requested properness. This is the mathematical
existence part of the Freiman construction; its deterministic time and short
description claims are separate obligations.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical

def freimanModelDensity (C : ℚ≥0) : ℚ≥0 := 1/(128*(C^16+1))

theorem freimanModelDensity_pos (C : ℚ≥0) : 0<freimanModelDensity C := by
  unfold freimanModelDensity
  positivity

def freimanInitialRank (C : ℚ≥0) : ℕ := bohrRankBound (freimanModelDensity C : ℝ)
def freimanModelLoss (C : ℚ≥0) : ℕ := uniformBohrProgressionLoss (freimanInitialRank C)
def freimanTranslateBound (C : ℚ≥0) : ℕ :=
  ⌈((C^5/((1/(freimanModelLoss C : ℚ≥0))/8) : ℚ≥0) : ℝ)⌉₊
def freimanContainingRank (C : ℚ≥0) : ℕ := freimanInitialRank C+freimanTranslateBound C
def freimanContainingVolume (C : ℚ≥0) (t : ℝ) : ℚ≥0 :=
  (uniformFreimanCoveringFactor (freimanInitialRank C) (freimanTranslateBound C) t : ℕ)*C^4

/-- Full mathematical containing-GAP existence for nonempty bounded integer
input, with a uniform rank and coefficient-volume bound. The final GAP is
proper on any requested real dilation, and zero-width coordinates are valid. -/
theorem exists_bounded_interval_containing_progression
    (S : Finset ℤ) (hS : S.Nonempty) (u : ℕ)
    (hbound : ∀ a∈S, 0≤a ∧ a≤u) (C : ℚ≥0)
    (hC : ((S+S).card : ℚ≥0)≤C*S.card) (t : ℝ) :
    ∃ d≤freimanContainingRank C, ∃ (ρ : IntVec d →+ ℤ) (β : Fin d → ℕ),
      S⊆integerProgressionValues ρ β ∧
      Set.InjOn ρ (realDilatedIntegerBox β t) ∧
      ((integerBudgetBox β).card : ℚ≥0)≤freimanContainingVolume C t*S.card := by
  obtain ⟨p,q,hp,_,_,_,lam,T,_,hTS,hcard,hdensity,hinj,hrel⟩ :=
    exists_dense_freiman_model S hS u hbound C hC
  letI : NeZero p := ⟨hp.ne_zero⟩
  let f : ℤ → ZMod p := fun a => (modelingResidue lam a : ZMod p)
  let A : Finset (ZMod p) := T.image f
  have hT : T.Nonempty := by
    have hs := Finset.card_pos.mpr hS
    apply Finset.card_pos.mp
    omega
  have hA : A.Nonempty := hT.image f
  have hAc : A.card=T.card := Finset.card_image_iff.mpr hinj
  have hη : (0 : ℝ)<freimanModelDensity C := by exact_mod_cast freimanModelDensity_pos C
  have hd : (freimanModelDensity C : ℝ)≤(A.card : ℝ)/p := by
    rw [hAc]
    change (freimanModelDensity C : ℚ≥0)≤(T.card : ℚ≥0)/p at hdensity
    have hd' := (NNRat.cast_le (K := ℝ)).mpr hdensity
    simpa only [NNRat.cast_div,NNRat.cast_natCast] using hd'
  have hr : (bogolyubovSpectrum A).card+1≤freimanInitialRank C :=
    bogolyubov_rank_le_of_density A hA _ hη hd
  obtain ⟨ρ,β,hproper,hP,hsize,_⟩ := bogolyubov_contains_progression A hA
  have hfull : Fintype.card (ZMod p)≤
      freimanModelLoss C*(integerProgressionValues ρ β).card := by
    rw [ZMod.card]
    exact hsize.trans (Nat.mul_le_mul_right _ (bohrProgressionLoss_le_uniform hr))
  have hfinal := freiman_finite_model_covering_uniform S T hS hTS hcard f hrel hinj
    C (by simpa using hC) (freimanInitialRank C) hr ρ β hproper hP (freimanModelLoss C)
    (uniformBohrProgressionLoss_pos _) hfull t
  simpa only [freimanContainingRank,freimanContainingVolume,freimanTranslateBound] using hfinal

end
end Optss
