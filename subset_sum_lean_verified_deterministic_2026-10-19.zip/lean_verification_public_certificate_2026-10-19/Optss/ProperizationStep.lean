import Optss.ProgressionCoordinates
import Optss.HyperplaneCounting
import Mathlib.Algebra.Order.Round

/-!
# Short-kernel certificates and rounding in one-dimensional quotient fibers

These are exact mathematical steps in Appendix B.2. Properness of an integer
box is equivalent to the absence of a nonzero kernel vector in its doubled
box. A real quotient representative can be rounded along an integer kernel
direction while enlarging the box by the claimed factor. Constructing a
primitive relation/unimodular quotient and its bit complexity remain separate.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {G : Type*} [AddCommGroup G]
variable {d e : ℕ}

theorem inBox_sub_double (β : Fin d → ℕ) {x y : IntVec d}
    (hx : InBox (fun j => (β j : ℤ)) x) (hy : InBox (fun j => (β j : ℤ)) y) :
    InBox (fun j => ((2*β j : ℕ) : ℤ)) (x-y) := by
  apply inBox_add_double β hx
  intro j
  simpa only [Pi.neg_apply, abs_neg] using hy j

/-- Every integer point of the doubled box is the difference of two integer
points in the original box, including zero-width coordinates. -/
theorem integer_double_box_decompose (β : Fin d → ℕ) (z : IntVec d)
    (hz : z ∈ integerBudgetBox (fun j => 2*β j)) :
    ∃ x ∈ integerBudgetBox β, ∃ y ∈ integerBudgetBox β, x-y=z := by
  have hz' := (mem_integerBudgetBox _ _).mp hz
  -- Clamping into the original interval handles both signs.
  let x' : IntVec d := fun j => max (-(β j : ℤ)) (min (β j : ℤ) (z j))
  let y' := x'-z
  refine ⟨x', ?_, y', ?_, by dsimp [y']; abel⟩
  · apply (mem_integerBudgetBox _ _).mpr
    intro j
    dsimp [x']
    rw [abs_le]
    constructor
    · exact le_max_left _ _
    · apply max_le
      · omega
      · exact min_le_left _ _
  · apply (mem_integerBudgetBox _ _).mpr
    intro j
    have h := abs_le.mp (hz' j)
    simp only [Nat.cast_mul, Nat.cast_ofNat] at h
    dsimp [y', x']
    rw [abs_le]
    omega

/-- This is the exact certificate checked by the finite-dimensional integer
feasibility calls in properization. -/
theorem integerBox_proper_iff_no_short_kernel (ρ : IntVec d →+ G) (β : Fin d → ℕ) :
    Set.InjOn ρ (integerBudgetBox β) ↔
      ∀ z ∈ integerBudgetBox (fun j => 2*β j), ρ z=0 → z=0 := by
  constructor
  · intro hp z hz hker
    obtain ⟨x, hx, y, hy, he⟩ := integer_double_box_decompose β z hz
    have hr : ρ x=ρ y := by
      rw [← he, map_sub, sub_eq_zero] at hker
      exact hker
    rw [← he, hp hx hy hr, sub_self]
  · intro hk x hx y hy he
    have hxy := inBox_sub_double β ((mem_integerBudgetBox β x).mp hx)
      ((mem_integerBudgetBox β y).mp hy)
    have hz := hk (x-y) ((mem_integerBudgetBox _ _).mpr hxy) (by rw [map_sub, he, sub_self])
    exact sub_eq_zero.mp hz

/-- Nonzero integer relations are precisely a union of `2d` one-sided
coordinate conditions, without excluding a relation by a nonlinear constraint. -/
theorem integerVector_ne_zero_iff (z : IntVec d) :
    z ≠ 0 ↔ ∃ j, 1 ≤ z j ∨ z j ≤ -1 := by
  constructor
  · intro hz
    have hj : ∃ j, z j ≠ 0 := by
      by_contra hn
      push_neg at hn
      exact hz (funext hn)
    obtain ⟨j, hj⟩ := hj
    exact ⟨j, by omega⟩
  · rintro ⟨j, hj⟩ hz
    have h := congrFun hz j
    simp only [Pi.zero_apply] at h
    omega

/-- Rounding the real displacement along an integer direction gives an actual
integer representative within the enlarged coordinate box. -/
theorem round_kernel_representative (β : Fin d → ℕ) (t : ℕ)
    (z x₀ : IntVec d) (y : Fin d → ℝ) (a : ℝ)
    (hz : InBox (fun j => ((2*t*β j : ℕ) : ℤ)) z)
    (hy : ∀ j, |y j| ≤ (β j : ℝ)) (hfiber : y = realVector x₀ + a • realVector z) :
    let x := x₀ + (round a) • z
    InBox (fun j => (((1+t)*β j : ℕ) : ℤ)) x := by
  intro x j
  have hround : |(round a : ℝ)-a| ≤ 1/2 := by simpa [abs_sub_comm] using abs_sub_round a
  have hz' : |(z j : ℝ)| ≤ 2*(t : ℝ)*(β j : ℝ) := by exact_mod_cast hz j
  have hf := congrFun hfiber j
  change y j = (x₀ j : ℝ) + a*(z j : ℝ) at hf
  have hx : (x j : ℝ) = y j + ((round a : ℝ)-a)*(z j : ℝ) := by
    dsimp [x]
    simp only [Pi.add_apply, Pi.smul_apply, zsmul_eq_mul, Int.cast_add, Int.cast_mul]
    rw [hf]
    ring
  have he := abs_add (y j) (((round a : ℝ)-a)*(z j : ℝ))
  rw [abs_mul] at he
  have herr := mul_le_mul hround hz' (abs_nonneg _) (by norm_num : (0:ℝ) ≤ 1/2)
  have hbound : |(x j : ℝ)| ≤ ((1+t : ℕ) : ℝ)*(β j : ℝ) := by
    rw [hx]
    push_cast
    nlinarith [hy j]
  exact_mod_cast hbound

/-- Given an actual integer quotient and its one-dimensional real kernel,
each quotient lattice point with a real representative in the box has an
integer representative in the `(1+t)`-enlargement. -/
theorem quotient_integer_representative (β : Fin d → ℕ) (t : ℕ) (z : IntVec d)
    (hz : InBox (fun j => ((2*t*β j : ℕ) : ℤ)) z)
    (π : IntVec d →+ IntVec e) (F : (Fin d → ℝ) →ₗ[ℝ] (Fin e → ℝ))
    (hπ : Function.Surjective π) (hcompat : ∀ x, realVector (π x) = F (realVector x))
    (hker : π z=0) (hline : ∀ x, F x=0 → ∃ a : ℝ, x=a • realVector z)
    (q : IntVec e) (y : Fin d → ℝ) (hy : ∀ j, |y j| ≤ (β j : ℝ))
    (hFy : F y=realVector q) :
    ∃ x ∈ integerBudgetBox (fun j => (1+t)*β j), π x=q := by
  obtain ⟨x₀, hx₀⟩ := hπ q
  have hfzero : F (y-realVector x₀) = 0 := by
    rw [map_sub, hFy, ← hcompat, hx₀, sub_self]
  obtain ⟨a, ha⟩ := hline _ hfzero
  have hfiber : y=realVector x₀+a • realVector z := by rw [← ha]; abel
  refine ⟨x₀+(round a) • z,
    (mem_integerBudgetBox _ _).mpr (round_kernel_representative β t z x₀ y a hz hy hfiber), ?_⟩
  rw [map_add, map_zsmul, hx₀, hker, smul_zero, add_zero]

theorem integerBudgetBox_dilation_card_le (β : Fin d → ℕ) (t : ℕ) :
    (integerBudgetBox (fun j => (1+t)*β j)).card ≤
      (1+t)^d*(integerBudgetBox β).card := by
  rw [integerBudgetBox_card, integerBudgetBox_card]
  calc
    _ ≤ ∏ j : Fin d, ((1+t)*(2*β j+1)) := by
      apply Finset.prod_le_prod'
      intro j _
      nlinarith
    _ = _ := by simp [Finset.prod_mul_distrib]

/-- Cardinality estimate for the quotient body, derived from actual integer
representatives and the coordinate box, rather than a quotient counting axiom. -/
theorem quotient_integer_box_card_le (β : Fin d → ℕ) (t : ℕ) (z : IntVec d)
    (hz : InBox (fun j => ((2*t*β j : ℕ) : ℤ)) z)
    (π : IntVec d →+ IntVec e) (F : (Fin d → ℝ) →ₗ[ℝ] (Fin e → ℝ))
    (hπ : Function.Surjective π) (hcompat : ∀ x, realVector (π x) = F (realVector x))
    (hker : π z=0) (hline : ∀ x, F x=0 → ∃ a : ℝ, x=a • realVector z)
    (T : Finset (IntVec e))
    (hT : ∀ q ∈ T, ∃ y : Fin d → ℝ, (∀ j, |y j| ≤ (β j : ℝ)) ∧ F y=realVector q) :
    T.card ≤ (1+t)^d*(integerBudgetBox β).card := by
  have hsub : T ⊆ (integerBudgetBox (fun j => (1+t)*β j)).image π := by
    intro q hq
    obtain ⟨y, hy, hFy⟩ := hT q hq
    exact Finset.mem_image.mpr
      (quotient_integer_representative β t z hz π F hπ hcompat hker hline q y hy hFy)
  exact (Finset.card_le_card hsub).trans
    ((Finset.card_image_le).trans (integerBudgetBox_dilation_card_le β t))

end
end Optss
