import Optss.ListTwiddleTables
import Optss.DyadicRadixDFT

/-! End-to-end power-of-two DFT on Boolean-list coefficients: the answer
constructs its own modulus, loop fuel, and twiddle rows, and performs the
sequential-list FFT. All native integer/complex interpretations are proofs. -/
namespace Optss
set_option maxHeartbeats 800000
set_option maxRecDepth 4096

theorem radixTwiddleLists_congr (T S : ℕ → ℕ → BitFourierInteger) (n : ℕ)
    (h : ∀ l<n, ∀ k, T l k=S l k) : radixTwiddleLists T n=radixTwiddleLists S n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [radixTwiddleLists]
    congr 1
    · exact congrArg List.ofFn (funext fun k => h n (by omega) k.val)
    · exact ih (fun l hl k => h l (by omega) k)

theorem negativeTwiddleSpecification_eq (ms : List Bool) (p s n : ℕ) :
    negativeTwiddleSpecification ms p s n=radixTwiddleLists
      (fun l k => bitNegativeCharacter (s*2^(n-(l+1))*k).bits ms p) n := by
  induction n generalizing s with
  | zero => rfl
  | succ n ih =>
    rw [negativeTwiddleSpecification,radixTwiddleLists,ih]
    apply congrArg₂ List.cons
    · apply congrArg List.ofFn
      funext k
      simp only [Nat.sub_self,pow_zero,mul_one]
    · apply radixTwiddleLists_congr
      intro l hl k
      have he : n+1-(l+1)=n-(l+1)+1 := by omega
      rw [he,pow_succ]
      congr 2
      ring

def listDyadicTwiddleFunction (ms : List Bool) (n p l k : ℕ) : BitFourierInteger :=
  bitNegativeCharacter (2^(n-(l+1))*k).bits ms p

theorem listDyadicTwiddleRows_eq (depth : List Bool) (p : ℕ) :
    listDyadicTwiddleRows depth p=radixTwiddleLists
      (listDyadicTwiddleFunction (radixModulusDigits depth) depth.length p) depth.length := by
  rw [listDyadicTwiddleRows,bitTwiddleRows_eq _ _ _ _ _ (radixListFuel_length depth),
    negativeTwiddleSpecification_eq]
  simp only [binaryDigitsValue,Bool.toNat_true,mul_zero,zero_add,one_mul,listDyadicTwiddleFunction]
  rfl

theorem listDyadicTwiddleFunction_value (depth : List Bool) (p l k : ℕ) :
    (listDyadicTwiddleFunction (radixModulusDigits depth) depth.length p l k).value=
      dyadicTwiddleFromTable depth.length (dyadicCharacterTable depth.length p) l k := by
  rw [listDyadicTwiddleFunction,bitNegativeCharacter_value _ _ (radixModulusDigits_value depth),
    binaryDigitsValue_bits,dyadicTwiddleFromTable_character]

def listDyadicDenominator (p : ℕ) : BitListInteger :=
  ⟨false,bitListTrim (fourierPowTwoDigits (p+2))⟩

theorem listDyadicDenominator_value (p : ℕ) :
    (listDyadicDenominator p).value=(dyadicFourierDenominator p : ℤ) := by
  simp only [listDyadicDenominator,BitListInteger.value,signedBitsValue,Bool.false_eq_true,↓reduceIte,
    bitListTrim_value,fourierPowTwoDigits_value,dyadicFourierDenominator]

theorem listDyadicDenominator_canonical (p : ℕ) : BitListCanonical (listDyadicDenominator p).digits :=
  bitListTrim_canonical _

def listDyadicTransform (depth : List Bool) (p : ℕ) (A : List BitFourierInteger) : List BitFourierInteger :=
  let D := listDyadicDenominator p
  let T := listDyadicTwiddleRows depth p
  listBitRadixTwo D T A

theorem listDyadicTransform_eq (depth : List Bool) (p : ℕ)
    (A : Vector BitFourierInteger (2^depth.length)) :
    (listDyadicTransform depth p (List.ofFn A.get)).map BitFourierInteger.value=
      List.ofFn (dyadicRadixDFT depth.length p (bitFourierVectorValue A)).get := by
  rw [listDyadicTransform,listDyadicTwiddleRows_eq,listBitRadixTwo_eq,List.map_ofFn]
  have h := bitFixedPointRadixTwo_value (listDyadicDenominator p)
    (listDyadicTwiddleFunction (radixModulusDigits depth) depth.length p) depth.length A
  rw [listDyadicDenominator_value] at h
  have he : (fun l k => (listDyadicTwiddleFunction (radixModulusDigits depth) depth.length p l k).value)=
      dyadicTwiddleFromTable depth.length (dyadicCharacterTable depth.length p) := by
    funext l k
    exact listDyadicTwiddleFunction_value depth p l k
  rw [he] at h
  apply congrArg List.ofFn
  funext k
  have hk := congrArg (fun V => V.get k) h
  simpa only [bitFourierVectorValue,vector_get_ofFn,dyadicRadixDFT,Function.comp_apply] using hk


def listDyadicTransformWork (depth : List Bool) (p : ℕ) (A : List BitFourierInteger) : ℕ :=
  let D := listDyadicDenominator p
  let T := listDyadicTwiddleRows depth p
  listDyadicTwiddleRowsWork depth p+4*(p+3)+4+
    listBitRadixTwoScalarWork D T A+listBitRadixTwoAdministration D T A

theorem listDyadicTransformWork_bound (depth : List Bool) (p B : ℕ)
    (A : Vector BitFourierInteger (2^depth.length))
    (hAc : ∀ j, (A.get j).Canonical) (hA : ∀ j, FourierIntegerBound (A.get j).value B) :
    listDyadicTransformWork depth p (List.ofFn A.get)≤
      2^(depth.length+1)*(320*(depth.length+3)^2+
        4194304*(depth.length+p+73)^2*(8192*(depth.length+p+73)^4+1)^3+16)+4*(p+3)+4+
      576*(depth.length+1)*2^depth.length*(depth.length*(p+6)+B.size+2)^2 := by
  have ht := listDyadicTwiddleRowsWork_bound depth p
  have htc : ∀ l<depth.length, ∀ k,
      (listDyadicTwiddleFunction (radixModulusDigits depth) depth.length p l k).Canonical :=
    fun _ _ _ => bitNegativeCharacter_canonical _ _ _
  have htbound : ∀ l<depth.length, ∀ k,
      FourierIntegerBound (listDyadicTwiddleFunction (radixModulusDigits depth) depth.length p l k).value
        (2*dyadicFourierDenominator p) := by
    intro l _ k
    rw [listDyadicTwiddleFunction_value]
    exact dyadicTwiddleFromTable_bound _ _ _ _
  have hfft := listBitRadixTwo_combined_bound (listDyadicDenominator p)
    (dyadicFourierDenominator p) B (listDyadicDenominator_value p)
    (listDyadicDenominator_canonical p)
    (listDyadicTwiddleFunction (radixModulusDigits depth) depth.length p)
    depth.length A hAc hA htc htbound
  simp only [dyadicFourierDenominator_size] at hfft
  simp only [Nat.size_pow,characterWorkBits] at ht
  have ht' : listDyadicTwiddleRowsWork depth p≤
      2^(depth.length+1)*(320*(depth.length+3)^2+
        4194304*(depth.length+p+73)^2*(8192*(depth.length+p+73)^4+1)^3+16) := by
    simpa only [show depth.length+1+p+72=depth.length+p+73 by omega,
      show depth.length+1+(p+2)+70=depth.length+p+73 by omega] using ht
  unfold listDyadicTransformWork
  rw [listDyadicTwiddleRows_eq]
  dsimp only
  have he : p+3+3=p+6 := by omega
  rw [he] at hfft
  omega


theorem BitFourierInteger.bound_of_width (z : BitFourierInteger) (b : ℕ) (hz : z.Width b) :
    FourierIntegerBound z.value (2^b) := by
  have hre : z.re.value.natAbs≤2^b := by
    rw [BitListInteger.value,signedBitsValue_natAbs]
    exact (binaryDigitsValue_lt_pow z.re.digits).le.trans (Nat.pow_le_pow_right (by decide) hz.1)
  have him : z.im.value.natAbs≤2^b := by
    rw [BitListInteger.value,signedBitsValue_natAbs]
    exact (binaryDigitsValue_lt_pow z.im.digits).le.trans (Nat.pow_le_pow_right (by decide) hz.2)
  change |z.re.value|≤((2^b : ℕ) : ℤ) ∧ |z.im.value|≤((2^b : ℕ) : ℤ)
  constructor
  · simpa only [Int.natCast_natAbs] using (Int.ofNat_le.mpr hre)
  · simpa only [Int.natCast_natAbs] using (Int.ofNat_le.mpr him)

/-- The final work bound is stated using actual stored coefficient lengths;
no intermediate-size hypothesis remains. -/
theorem listDyadicTransformWork_bits (depth : List Bool) (p b : ℕ)
    (A : Vector BitFourierInteger (2^depth.length))
    (hAc : ∀ j, (A.get j).Canonical) (hA : ∀ j, (A.get j).Width b) :
    listDyadicTransformWork depth p (List.ofFn A.get)≤
      2^(depth.length+1)*(320*(depth.length+3)^2+
        4194304*(depth.length+p+73)^2*(8192*(depth.length+p+73)^4+1)^3+16)+4*(p+3)+4+
      576*(depth.length+1)*2^depth.length*(depth.length*(p+6)+b+3)^2 := by
  have h := listDyadicTransformWork_bound depth p (2^b) A hAc (fun j => (A.get j).bound_of_width b (hA j))
  simpa only [Nat.size_pow,Nat.add_assoc] using h


theorem listDyadicTransform_storage (depth : List Bool) (p : ℕ)
    (A : Vector BitFourierInteger (2^depth.length)) :
    listDyadicTransform depth p (List.ofFn A.get)=List.ofFn
      (bitFixedPointRadixTwo (listDyadicDenominator p)
        (listDyadicTwiddleFunction (radixModulusDigits depth) depth.length p) depth.length A).get := by
  rw [listDyadicTransform,listDyadicTwiddleRows_eq,listBitRadixTwo_eq]

theorem listDyadicTransform_length (depth : List Bool) (p : ℕ)
    (A : Vector BitFourierInteger (2^depth.length)) :
    (listDyadicTransform depth p (List.ofFn A.get)).length=2^depth.length := by
  rw [listDyadicTransform_storage,List.length_ofFn]

theorem listDyadicTransform_canonical (depth : List Bool) (p : ℕ)
    (A : Vector BitFourierInteger (2^depth.length)) (hAc : ∀ j, (A.get j).Canonical)
    (z : BitFourierInteger) (hz : z∈listDyadicTransform depth p (List.ofFn A.get)) : z.Canonical := by
  rw [listDyadicTransform_storage,List.mem_ofFn] at hz
  obtain ⟨k,rfl⟩ := hz
  exact bitFixedPointRadixTwo_canonical _ _ _ _ hAc k

theorem listDyadicTransform_width (depth : List Bool) (p b : ℕ)
    (A : Vector BitFourierInteger (2^depth.length))
    (hAc : ∀ j, (A.get j).Canonical) (hA : ∀ j, (A.get j).Width b)
    (z : BitFourierInteger) (hz : z∈listDyadicTransform depth p (List.ofFn A.get)) :
    z.Width (depth.length*(p+6)+b+2) := by
  rw [listDyadicTransform_storage,List.mem_ofFn] at hz
  obtain ⟨k,rfl⟩ := hz
  have hT : ∀ l<depth.length, ∀ k,
      FourierIntegerBound (listDyadicTwiddleFunction (radixModulusDigits depth) depth.length p l k).value
        (2*dyadicFourierDenominator p) := by
    intro l _ k
    rw [listDyadicTwiddleFunction_value]
    exact dyadicTwiddleFromTable_bound _ _ _ _
  have h := bitFixedPointRadixTwo_width (listDyadicDenominator p) (dyadicFourierDenominator p) (2^b)
    (listDyadicDenominator_value p) _ depth.length A hAc
    (fun j => (A.get j).bound_of_width b (hA j)) hT k
  simpa only [dyadicFourierDenominator_size,Nat.size_pow,Nat.add_assoc] using h

end Optss
