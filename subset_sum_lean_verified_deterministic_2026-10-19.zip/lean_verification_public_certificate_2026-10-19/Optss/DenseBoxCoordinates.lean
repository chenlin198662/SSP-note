import Optss.DenseCoordinateProgressions
import Optss.DenseBoxFillingResidues

/-!
# Coordinate progressions in actual integer boxes

An explicit additive equivalence splits off any selected coordinate.
It preserves all input cardinalities and sumsets, so the product-fiber
argument yields a coordinate-axis progression inside the original
integer-vector sumset.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

/-- Split off coordinate `j`, retaining every other coordinate exactly. -/
def fillingCoordinateSplit {d : ℕ} (j : Fin d) :
    IntVec d ≃+ (ℤ × ({k : Fin d // k ≠ j} → ℤ)) where
  toFun x := (x j, fun k => x k.1)
  invFun p k := if h : k = j then p.1 else p.2 ⟨k, h⟩
  left_inv x := by funext k; dsimp only; split_ifs with hk <;> simp_all
  right_inv p := by
    apply Prod.ext
    · simp
    · funext k; simp [k.2]
  map_add' x y := rfl

/-- The coordinate line through `t` with step `v` on axis `j`. -/
def fillingCoordinateLine {d : ℕ} (j : Fin d) (t : IntVec d) (v x : ℤ) : IntVec d :=
  fun k => t k + if k = j then v * x else 0

/-- Splitting the actual box yields an exact product box. -/
theorem fillingCoordinateSplit_box {d : ℕ} (j : Fin d) (lo hi : IntVec d) :
    (fillingIntegerBox lo hi).image (fillingCoordinateSplit j) =
      Finset.Icc (lo j) (hi j) ×ˢ
        Fintype.piFinset (fun k : {k : Fin d // k ≠ j} => Finset.Icc (lo k.1) (hi k.1)) := by
  ext p
  constructor
  · intro hp
    obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hp
    have hh := (mem_fillingIntegerBox _ _ _).mp hx
    exact Finset.mem_product.mpr ⟨Finset.mem_Icc.mpr (hh j), by
      rw [Fintype.mem_piFinset]
      intro k
      exact Finset.mem_Icc.mpr (hh k.1)⟩
  · intro hp
    obtain ⟨hp₁, hp₂⟩ := Finset.mem_product.mp hp
    refine Finset.mem_image.mpr ⟨(fillingCoordinateSplit j).symm p, ?_, (fillingCoordinateSplit j).apply_symm_apply p⟩
    rw [mem_fillingIntegerBox]
    intro k
    change lo k ≤ (if h : k = j then p.1 else p.2 ⟨k, h⟩) ∧
      (if h : k = j then p.1 else p.2 ⟨k, h⟩) ≤ hi k
    split_ifs with hk
    · subst k; exact Finset.mem_Icc.mp hp₁
    · exact Finset.mem_Icc.mp (Fintype.mem_piFinset.mp hp₂ ⟨k, hk⟩)

/-- For any chosen coordinate, a sufficiently long full family of dense
sets contains a long coordinate progression; every point is an actual sum. -/
theorem dense_box_coordinate_progression {d ι : Type*} [Fintype d] [DecidableEq d]
    [DecidableEq ι] (S : Finset ι) (A : ι → Finset (d → ℤ))
    (j : d) (lo : d → ℤ) (W : d → ℕ) (c : ℝ)
    (hc : 0 < c) (hc1 : c ≤ 1) (hW : ∀ k, 0 < W k)
    (hNj : 4 ≤ c * W j) (hcount : 20 ≤ c ^ 2 * S.card)
    (hbox : ∀ i ∈ S, A i ⊆ Fintype.piFinset (fun k => Finset.Icc (lo k) (lo k + W k - 1)))
    (hdense : ∀ i ∈ S, c * (Fintype.piFinset (fun k => Finset.Icc (lo k) (lo k + W k - 1))).card ≤ (A i).card) :
    ∃ (v a b : ℤ) (t : d → ℤ), 0 < v ∧ c * v ≤ 2 ∧
      (Finset.Icc a b).image (fun x k => t k + if k = j then v * x else 0) ⊆ ∑ i ∈ S, A i ∧
      c ^ 2 * S.card * W j / 4 ≤ (b - a : ℤ) := by
  let e : (d → ℤ) ≃+ (ℤ × ({k : d // k ≠ j} → ℤ)) :=
    { toFun := fun x => (x j, fun k => x k.1)
      invFun := fun p k => if h : k = j then p.1 else p.2 ⟨k, h⟩
      left_inv := by intro x; funext k; dsimp only; split_ifs with hk <;> simp_all
      right_inv := by intro p; apply Prod.ext; simp; funext k; simp [k.2]
      map_add' := fun _ _ => rfl }
  let Q := Fintype.piFinset (fun k => Finset.Icc (lo k) (lo k + W k - 1))
  let V := Fintype.piFinset (fun k : {k : d // k ≠ j} => Finset.Icc (lo k.1) (lo k.1 + W k.1 - 1))
  have hV : V.Nonempty := by
    apply Fintype.piFinset_nonempty.mpr
    intro k
    exact ⟨lo k.1, Finset.mem_Icc.mpr ⟨le_rfl, by have := hW k.1; omega⟩⟩
  have hQ : Q.image e = Finset.Icc (lo j) (lo j + W j - 1) ×ˢ V := by
    ext p
    constructor
    · intro hp
      obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hp
      have hh := Fintype.mem_piFinset.mp hx
      exact Finset.mem_product.mpr ⟨hh j, by
        rw [Fintype.mem_piFinset]
        intro k
        exact hh k.1⟩
    · intro hp
      obtain ⟨hp₁, hp₂⟩ := Finset.mem_product.mp hp
      refine Finset.mem_image.mpr ⟨e.symm p, ?_, e.apply_symm_apply p⟩
      rw [Fintype.mem_piFinset]
      intro k
      change (if h : k = j then p.1 else p.2 ⟨k, h⟩) ∈ Finset.Icc (lo k) (lo k + W k - 1)
      split_ifs with hk
      · subst k; exact hp₁
      · exact Fintype.mem_piFinset.mp hp₂ ⟨k, hk⟩
  have hQc : Q.card = W j * V.card := by
    rw [← Finset.card_image_of_injective Q e.injective, hQ, Finset.card_product, Int.card_Icc]
    congr 1
    omega
  have hAe : ∀ i, ((A i).image e).card = (A i).card := fun i => Finset.card_image_of_injective _ e.injective
  obtain ⟨v, t₀, a, b, z, hv, hcv, hI, hlong⟩ := dense_product_family_progression S
    (fun i => (A i).image e) (lo j) (W j) V c hc hc1 hNj hV hcount
    (fun i hi => by rw [← hQ]; exact Finset.image_subset_image (hbox i hi))
    (fun i hi => by
      have hh := hdense i hi
      change c * Q.card ≤ (A i).card at hh
      rw [hQc, Nat.cast_mul] at hh
      simpa [hAe, mul_assoc] using hh)
  let t := e.symm (t₀, z)
  refine ⟨v, a, b, t, hv, hcv, ?_, hlong⟩
  intro x hx
  obtain ⟨q, hq, rfl⟩ := Finset.mem_image.mp hx
  have hq' := hI (Finset.mem_image.mpr ⟨q, hq, rfl⟩)
  have hsum : (∑ i ∈ S, A i).image e = ∑ i ∈ S, (A i).image e :=
    map_sum (Finset.imageAddMonoidHom e.toAddMonoidHom) _ _
  rw [← hsum] at hq'
  obtain ⟨x, hx, hex⟩ := Finset.mem_image.mp hq'
  have heq : (fun k => t k + if k = j then v * q else 0) = x := by
    apply e.injective
    rw [hex]
    apply Prod.ext
    · simp [e, t]
    · funext k
      simp [e, t, k.2]
  rwa [heq]

end
end Optss
