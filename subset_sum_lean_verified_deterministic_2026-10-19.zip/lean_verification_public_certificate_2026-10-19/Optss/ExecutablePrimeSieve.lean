import Optss.ModelingParameters
import Mathlib.Data.Array.Defs
import Mathlib.Tactic

/-!
# An executable bounded prime sieve

The routine initializes a Boolean array, writes false at every nontrivial
product, and reads the resulting prime flags. The marking schedule enumerates
all divisors, including composite divisors; this simplifies verification and
still permits the harmonic O(U log U) word-operation bound.
-/
namespace Optss
open scoped BigOperators

/-- Execute the actual array writes in order. -/
def markFalseArray (a : Array Bool) : List ℕ → Array Bool
  | [] => a
  | i::is => markFalseArray (a.setIfInBounds i false) is

@[simp] theorem markFalseArray_size (a : Array Bool) (is : List ℕ) :
    (markFalseArray a is).size=a.size := by
  induction is generalizing a with
  | nil => rfl
  | cons i is ih => simp [markFalseArray,ih]

theorem markFalseArray_read (a : Array Bool) (is : List ℕ) (i : ℕ) :
    (markFalseArray a is)[i]?=some true ↔ a[i]?=some true ∧ i∉is := by
  induction is generalizing a with
  | nil => simp [markFalseArray]
  | cons j js ih =>
    rw [markFalseArray,ih,Array.getElem?_setIfInBounds]
    by_cases hij : j=i
    · subst j
      simp
    · simp [hij,Ne.symm hij,and_assoc]

/-- Materialized addresses of all nontrivial products at most U. -/
def primeSieveSchedule (U : ℕ) : List ℕ :=
  ((List.range (U+1)).filter (fun d => 2≤d)).flatMap (fun d =>
    ((List.range (U/d+1)).filter (fun t => 2≤t)).map (fun t => d*t))

theorem mem_primeSieveSchedule (U n : ℕ) :
    n∈primeSieveSchedule U ↔ ∃ d t : ℕ, 2≤d ∧ 2≤t ∧ n=d*t ∧ n≤U := by
  simp only [primeSieveSchedule,List.mem_flatMap,List.mem_filter,List.mem_range,
    decide_eq_true_eq,List.mem_map]
  constructor
  · rintro ⟨d,⟨hdU,hd⟩,t,⟨htU,ht⟩,rfl⟩
    refine ⟨d,t,hd,ht,rfl,?_⟩
    have hh : t*d≤U := (Nat.le_div_iff_mul_le (by omega : 0<d)).mp (by omega)
    simpa only [mul_comm] using hh
  · rintro ⟨d,t,hd,ht,rfl,hU⟩
    have hdU : d<U+1 := by nlinarith
    have htU : t<U/d+1 := by
      have hh := (Nat.le_div_iff_mul_le (by omega : 0<d)).mpr (by simpa only [mul_comm] using hU)
      omega
    exact ⟨d,⟨hdU,hd⟩,t,⟨htU,ht⟩,rfl⟩

theorem prime_iff_not_mem_primeSieveSchedule (U n : ℕ) (hnU : n≤U) :
    n.Prime ↔ 2≤n ∧ n∉primeSieveSchedule U := by
  constructor
  · intro hp
    refine ⟨hp.two_le,?_⟩
    rintro hmem
    obtain ⟨d,t,hd,ht,he,_⟩ := (mem_primeSieveSchedule U n).mp hmem
    rcases hp.eq_one_or_self_of_dvd d ⟨t,he⟩ with he1 | hed
    · omega
    · nlinarith
  · rintro ⟨hn,hnot⟩
    apply Nat.prime_def_lt'.mpr
    refine ⟨hn,?_⟩
    intro d hd hdn hdiv
    obtain ⟨t,he⟩ := hdiv
    have ht : 2≤t := by by_contra h; interval_cases t <;> simp_all
    exact hnot ((mem_primeSieveSchedule U n).mpr ⟨d,t,hd,ht,he,hnU⟩)

/-- Boolean prime flags for every index in [0,U]. -/
def primeSieveArray (U : ℕ) : Array Bool :=
  markFalseArray (Array.replicate (U+1) true) (0::1::primeSieveSchedule U)

@[simp] theorem primeSieveArray_size (U : ℕ) : (primeSieveArray U).size=U+1 := by
  simp [primeSieveArray]

theorem primeSieveArray_correct (U n : ℕ) (hn : n≤U) :
    (primeSieveArray U)[n]?=some true ↔ n.Prime := by
  rw [primeSieveArray,markFalseArray_read,prime_iff_not_mem_primeSieveSchedule U n hn]
  simp only [Array.getElem?_replicate,show n<U+1 by omega,if_pos,List.mem_cons,List.not_mem_nil,
    or_false,not_or]
  simp only [true_and,Option.some.injEq]
  constructor
  · rintro ⟨hn0,hn1,hs⟩
    exact ⟨by omega,hs⟩
  · rintro ⟨hn2,hs⟩
    exact ⟨by omega,by omega,hs⟩

end Optss
