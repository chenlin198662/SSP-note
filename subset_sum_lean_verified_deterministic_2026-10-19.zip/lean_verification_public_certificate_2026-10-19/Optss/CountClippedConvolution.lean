import Optss.CountCorrectionSupport
import Optss.ClippedConvolution

/-!
# Counted Newton support with iterative clipped convolution

The computation uses original input types and their multiplicities. It never
expands copies: expansion occurs only in the proof equating each local support
with labelled-copy semantics. The resulting finite supports are merged in order
and clipped after every merge. Preprocessing discards unusable types and caps
multiplicities without losing any required cardinality/absolute-budget witness.
-/

namespace Optss
open scoped BigOperators Pointwise
noncomputable section
variable {ι : Type*} [Fintype ι] {d : ℕ}

/-- The actual decoded local array computed from type multiplicities. -/
def decodedCountOrthantSupport (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool) : Finset (IntVec d) := by
  classical
  exact (countNewtonSupport Δ
    (fun i : {i // coordinateOrthant (v i) = ε} => c i)
    (fun i => absoluteExponent (v i)) kcap).support.image (orthantDecode ε)

/-- Local arrays computed on types agree with the expanded mathematical model. -/
theorem decodedCountOrthantSupport_eq_copies (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool) :
    decodedCountOrthantSupport v c Δ kcap ε =
      decodedOrthantSupport (expandedCopy v c) Δ kcap ε := by
  classical
  unfold decodedCountOrthantSupport decodedOrthantSupport
  rw [countOrthantPolynomial_eq_copies]

/-- Iterate exact Boolean convolutions over the direct-count local arrays,
filtering to the output box after every stage. -/
def iteratedCountCorrectionSupport (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) : Finset (IntVec d) := by
  classical
  exact clippedConvolution {t | InBox (fun j => (Δ j : ℤ)) t}
    ((orthantOrder d).map (decodedCountOrthantSupport v c Δ kcap))

/-- Copy expansion is a proof device only; the actual folded arrays are equal. -/
theorem iteratedCountCorrectionSupport_eq_copies (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) :
    iteratedCountCorrectionSupport v c Δ kcap =
      iteratedBoundedCorrectionSupport (expandedCopy v c) Δ kcap := by
  classical
  unfold iteratedCountCorrectionSupport iteratedBoundedCorrectionSupport
  congr 1
  apply List.map_congr_left
  intro ε _
  exact decodedCountOrthantSupport_eq_copies v c Δ kcap ε

/-- Every output respects original capacities and is in the clipping box. -/
theorem iteratedCountCorrectionSupport_sound (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) {t : IntVec d}
    (ht : t ∈ iteratedCountCorrectionSupport v c Δ kcap) :
    t ∈ countSums v (fun i => (c i : ℤ)) ∧ InBox (fun j => (Δ j : ℤ)) t := by
  rw [iteratedCountCorrectionSupport_eq_copies] at ht
  obtain ⟨hs, hb⟩ := (iteratedBoundedCorrectionSupport_correct (expandedCopy v c) Δ kcap).1 t ht
  exact ⟨(countSums_iff_expanded_subsetSums v c t).mpr hs, hb⟩

/-- Every required counted witness survives all intermediate filters. -/
theorem iteratedCountCorrectionSupport_complete (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (x : ι → ℤ)
    (hx : BoundedCounts (fun i => (c i : ℤ)) x) (hcard : (∑ i, x i) ≤ kcap)
    (hbudget : CountAbsoluteBudget v x (fun j => (Δ j : ℤ))) :
    weightedSum v x ∈ iteratedCountCorrectionSupport v c Δ kcap := by
  obtain ⟨s, hs, hb, hsum⟩ := exists_budgeted_copy_selection v c _ kcap x hx hcard hbudget
  rw [iteratedCountCorrectionSupport_eq_copies, ← hsum]
  exact iteratedBoundedCorrectionSupport_complete (expandedCopy v c) Δ kcap s hs hb

/-- Lemma 10.1's counted-input correctness guarantee for the actual operational
construction: safe preprocessing, direct-count Newton tables, and iterative
clipped convolution. There are exactly `2^d` merge/filter stages. -/
theorem iteratedCountCorrectionSupport_correct (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) :
    let c' := correctionCapacity v c (fun j => (Δ j : ℤ)) kcap
    let S := iteratedCountCorrectionSupport v c' Δ kcap
    (∀ t ∈ S, t ∈ countSums v (fun i => (c i : ℤ)) ∧ InBox (fun j => (Δ j : ℤ)) t) ∧
    (∀ x, BoundedCounts (fun i => (c i : ℤ)) x → (∑ i, x i) ≤ kcap →
      CountAbsoluteBudget v x (fun j => (Δ j : ℤ)) → weightedSum v x ∈ S) ∧
    ((orthantOrder d).map (decodedCountOrthantSupport v c' Δ kcap)).length = 2 ^ d := by
  dsimp only
  let c' := correctionCapacity v c (fun j => (Δ j : ℤ)) kcap
  refine ⟨?_, ?_, ?_⟩
  · intro t ht
    obtain ⟨hs, hb⟩ := iteratedCountCorrectionSupport_sound v c' Δ kcap ht
    exact ⟨correctionCapacity_countSums_subset v c _ kcap hs, hb⟩
  · intro x hx hcard hbudget
    have hx' := required_counts_bounded_correctionCapacity v c _ kcap x hx hcard hbudget
    exact iteratedCountCorrectionSupport_complete v c' Δ kcap x hx' hcard hbudget
  · simpa only [List.length_map] using orthantOrder_length d

end
end Optss
