import Optss.ArrayBounds
import Optss.Basic
import Mathlib.Algebra.Group.Pointwise.Finset.Basic
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Int.Interval
import Mathlib.Data.Nat.Log

/-!
# Balanced Boolean support products and exact array accounting

A height-indexed binary tree has exactly a power-of-two number of listed
factors. Every internal node performs a finite Minkowski addition, which is
Boolean convolution of its children. No signed sum is truncated. Integer boxes
bound the actual intermediate supports, and their cardinalities count allocated
array cells, including zero-width coordinates. Bit-operation complexity of fast
integer multiplication is not asserted here.
-/

namespace Optss
open scoped BigOperators Pointwise

/-- A full balanced binary product tree; leaves are the actual input factors. -/
inductive BalancedProductTree (G : Type*) : ℕ → Type _
  | leaf : Finset G → BalancedProductTree G 0
  | branch {h : ℕ} : BalancedProductTree G h → BalancedProductTree G h →
      BalancedProductTree G (h+1)

namespace BalancedProductTree
variable {G : Type*}

def leaves : {h : ℕ} → BalancedProductTree G h → List (Finset G)
  | _, .leaf A => [A]
  | _, .branch l r => l.leaves ++ r.leaves

def merges : {h : ℕ} → BalancedProductTree G h → ℕ
  | _, .leaf _ => 0
  | _, .branch l r => 1 + l.merges + r.merges

@[simp] theorem leaves_length {h : ℕ} (t : BalancedProductTree G h) :
    t.leaves.length = 2^h := by
  induction t with
  | leaf A => simp [leaves]
  | @branch h l r ihl ihr => simp [leaves, ihl, ihr, pow_succ]; omega

@[simp] theorem merges_add_one {h : ℕ} (t : BalancedProductTree G h) :
    t.merges + 1 = 2^h := by
  induction t with
  | leaf A => simp [merges]
  | @branch h l r ihl ihr => simp only [merges, pow_succ]; omega

theorem merges_eq {h : ℕ} (t : BalancedProductTree G h) : t.merges = 2^h - 1 := by
  have := t.merges_add_one
  omega

/-- Build the balanced tree by splitting the actual list into equal halves. -/
def ofList : (h : ℕ) → (A : List (Finset G)) → A.length = 2^h → BalancedProductTree G h
  | 0, A, _ => .leaf (A.headD ∅)
  | h+1, A, hA => .branch
      (ofList h (A.take (2^h)) (by rw [List.length_take, hA, pow_succ]; omega))
      (ofList h (A.drop (2^h)) (by rw [List.length_drop, hA, pow_succ]; omega))

@[simp] theorem ofList_leaves (h : ℕ) (A : List (Finset G)) (hA : A.length = 2^h) :
    (ofList h A hA).leaves = A := by
  induction h generalizing A with
  | zero =>
    have hA1 : A.length = 1 := by simpa using hA
    obtain ⟨B, rfl⟩ := List.length_eq_one_iff.mp hA1
    rfl
  | succ h ih => simp only [ofList, leaves, ih, List.take_append_drop]

variable [DecidableEq G] [AddCommGroup G]

/-- Actual supports are computed recursively by finite Boolean convolution. -/
def support : {h : ℕ} → BalancedProductTree G h → Finset G
  | _, .leaf A => A
  | _, .branch l r => l.support + r.support

/-- Balanced multiplication computes exactly the sum of the listed factors. -/
theorem support_eq_sum {h : ℕ} (t : BalancedProductTree G h) : t.support = t.leaves.sum := by
  induction t with
  | leaf A => simp [support, leaves]
  | branch l r ihl ihr => simp [support, leaves, ihl, ihr]

/-- All actual node supports at depth `k`, root at depth zero. -/
def levelSupports : {h : ℕ} → BalancedProductTree G h → ℕ → List (Finset G)
  | _, t, 0 => [t.support]
  | _, .leaf _, _+1 => []
  | _, .branch l r, k+1 => l.levelSupports k ++ r.levelSupports k

theorem levelSupports_length {h : ℕ} (t : BalancedProductTree G h) (k : ℕ) (hk : k ≤ h) :
    (t.levelSupports k).length = 2^k := by
  induction t generalizing k with
  | leaf A =>
    have hk0 : k=0 := by omega
    simp [hk0, levelSupports]
  | @branch h l r ihl ihr =>
    cases k with
    | zero => simp [levelSupports]
    | succ k => simp [levelSupports, ihl k (by omega), ihr k (by omega), pow_succ]; omega

end BalancedProductTree

/-- Padding with zero factors does not change the full Minkowski sum. -/
theorem support_sum_zero_padding {G : Type*} [DecidableEq G] [AddCommGroup G]
    (A : List (Finset G)) (n : ℕ) :
    (A ++ List.replicate n ({0} : Finset G)).sum = A.sum := by
  simp [Finset.singleton_zero]

/-- Zero-padding to the next power of two, including the empty list. -/
def padSupportFactors {G : Type*} [Zero G] (A : List (Finset G)) : List (Finset G) :=
  A ++ List.replicate (2^(Nat.clog 2 A.length)-A.length) {0}

@[simp] theorem padSupportFactors_length {G : Type*} [Zero G] (A : List (Finset G)) :
    (padSupportFactors A).length = 2^(Nat.clog 2 A.length) := by
  have h := Nat.le_pow_clog (by decide : 1 < 2) A.length
  simp only [padSupportFactors, List.length_append, List.length_replicate]
  omega

theorem padSupportFactors_sum {G : Type*} [DecidableEq G] [AddCommGroup G]
    (A : List (Finset G)) : (padSupportFactors A).sum = A.sum :=
  support_sum_zero_padding A _

/-- Padding increases a nonempty factor count by at most a factor of two. -/
theorem padSupportFactors_length_le {G : Type*} [Zero G] (A : List (Finset G))
    (hA : 0 < A.length) : (padSupportFactors A).length ≤ 2*A.length := by
  rw [padSupportFactors_length]
  by_cases hA1 : A.length = 1
  · simp [hA1]
  · have hq : 1 < A.length := by omega
    have hh := Nat.clog_pos (by decide : 1 < 2) hq
    have hp := Nat.pow_pred_clog_lt_self (by decide : 1 < 2) hq
    simp only [Nat.pred_eq_sub_one] at hp
    rw [show Nat.clog 2 A.length = (Nat.clog 2 A.length - 1)+1 by omega, pow_succ]
    omega

/-- Balanced convolution construction for an arbitrary list of factors. -/
def balancedProduct {G : Type*} [Zero G] (A : List (Finset G)) :
    BalancedProductTree G (Nat.clog 2 A.length) :=
  BalancedProductTree.ofList _ (padSupportFactors A) (padSupportFactors_length A)

theorem balancedProduct_support {G : Type*} [DecidableEq G] [AddCommGroup G]
    (A : List (Finset G)) : (balancedProduct A).support = A.sum := by
  rw [BalancedProductTree.support_eq_sum, balancedProduct, BalancedProductTree.ofList_leaves,
    padSupportFactors_sum]

/-- Ordinary integer convolution of two indicator functions at one output.
The finite filter counts exactly the contributing first summands. -/
def booleanConvolutionCoefficient {G : Type*} [DecidableEq G] [AddCommGroup G]
    (A B : Finset G) (x : G) : ℕ := (A.filter (fun u => x-u ∈ B)).card

/-- Replacing every positive convolution coefficient by one computes the
Minkowski support used at each internal balanced-tree node. -/
theorem booleanConvolutionCoefficient_pos_iff {G : Type*} [DecidableEq G] [AddCommGroup G]
    (A B : Finset G) (x : G) :
    0 < booleanConvolutionCoefficient A B x ↔ x ∈ A+B := by
  rw [booleanConvolutionCoefficient, Finset.card_pos]
  constructor
  · rintro ⟨u, hu⟩
    obtain ⟨huA, huB⟩ := Finset.mem_filter.mp hu
    exact Finset.mem_add.mpr ⟨u, huA, x-u, huB, by abel⟩
  · intro hx
    obtain ⟨u, hu, v, hv, rfl⟩ := Finset.mem_add.mp hx
    exact ⟨u, Finset.mem_filter.mpr ⟨hu, by simpa using hv⟩⟩

/-- Booleanized inputs bound every intermediate integer coefficient by the
number of entries of one input support. -/
theorem booleanConvolutionCoefficient_le {G : Type*} [DecidableEq G] [AddCommGroup G]
    (A B : Finset G) (x : G) : booleanConvolutionCoefficient A B x ≤ A.card :=
  Finset.card_filter_le _ _

/-- Number of explicitly listed entries, including the added singleton zeros. -/
theorem padSupportFactors_entries {G : Type*} [Zero G] (A : List (Finset G)) :
    ((padSupportFactors A).map Finset.card).sum =
      (A.map Finset.card).sum + (2^(Nat.clog 2 A.length)-A.length) := by
  simp [padSupportFactors]

/-- The integer array box allocated to a block of `n` factors. -/
def balancedArrayBox {d : ℕ} (a : Fin d → ℕ) (n : ℕ) : Finset (IntVec d) :=
  Fintype.piFinset (fun j => Finset.Icc (-(n*a j : ℕ) : ℤ) (n*a j : ℕ))

@[simp] theorem mem_balancedArrayBox {d : ℕ} (a : Fin d → ℕ) (n : ℕ) (x : IntVec d) :
    x ∈ balancedArrayBox a n ↔ ∀ j, |x j| ≤ (n*a j : ℕ) := by
  simp only [balancedArrayBox, Fintype.mem_piFinset, Finset.mem_Icc, abs_le]

theorem balancedArrayBox_card {d : ℕ} (a : Fin d → ℕ) (n : ℕ) :
    (balancedArrayBox a n).card = ∏ j, (2*(n*a j)+1) := by
  rw [balancedArrayBox, Fintype.card_piFinset]
  apply Finset.prod_congr rfl
  intro j _
  rw [Int.card_Icc]
  have h : ((n*a j : ℕ) : ℤ) + 1 - -((n*a j : ℕ) : ℤ) = ((2*(n*a j)+1 : ℕ) : ℤ) := by
    push_cast
    ring
  rw [h, Int.toNat_natCast]

/-- The Minkowski sum of two block arrays fits their combined block array. -/
theorem balancedArrayBox_add_subset {d : ℕ} (a : Fin d → ℕ) (m n : ℕ) :
    balancedArrayBox a m + balancedArrayBox a n ⊆ balancedArrayBox a (m+n) := by
  intro x hx
  obtain ⟨u, hu, v, hv, rfl⟩ := Finset.mem_add.mp hx
  apply (mem_balancedArrayBox a (m+n) _).mpr
  intro j
  have huj := (mem_balancedArrayBox a m u).mp hu j
  have hvj := (mem_balancedArrayBox a n v).mp hv j
  calc
    |(u+v) j| ≤ |u j| + |v j| := abs_add _ _
    _ ≤ ((m*a j : ℕ) : ℤ) + ((n*a j : ℕ) : ℤ) := add_le_add huj hvj
    _ = _ := by push_cast; ring

namespace BalancedProductTree

/-- Input factors fit the same coordinatewise radius, which may be zero. -/
def FactorsInBox {d h : ℕ} (t : BalancedProductTree (IntVec d) h) (a : Fin d → ℕ) : Prop :=
  ∀ A ∈ t.leaves, A ⊆ balancedArrayBox a 1

theorem support_subset_box {d h : ℕ} (t : BalancedProductTree (IntVec d) h)
    (a : Fin d → ℕ) (ha : t.FactorsInBox a) : t.support ⊆ balancedArrayBox a (2^h) := by
  induction t with
  | leaf A => simpa [support] using ha A (by simp [leaves])
  | @branch h l r ihl ihr =>
    have hl : l.FactorsInBox a := fun A hA => ha A (by simp only [leaves, List.mem_append]; exact Or.inl hA)
    have hr : r.FactorsInBox a := fun A hA => ha A (by simp only [leaves, List.mem_append]; exact Or.inr hA)
    calc
      l.support + r.support ⊆ balancedArrayBox a (2^h) + balancedArrayBox a (2^h) :=
        Finset.add_subset_add (ihl hl) (ihr hr)
      _ ⊆ balancedArrayBox a (2^h+2^h) := balancedArrayBox_add_subset a _ _
      _ = balancedArrayBox a (2^(h+1)) := by congr 1; rw [pow_succ]; omega

/-- Every actual intermediate support at depth `k` fits the array for its
`2^(h-k)` descendant input factors. -/
theorem levelSupports_subset_box {d h : ℕ} (t : BalancedProductTree (IntVec d) h)
    (a : Fin d → ℕ) (ha : t.FactorsInBox a) (k : ℕ) (hk : k ≤ h)
    (S : Finset (IntVec d)) (hS : S ∈ t.levelSupports k) :
    S ⊆ balancedArrayBox a (2^(h-k)) := by
  induction t generalizing k with
  | leaf A =>
    have hk0 : k=0 := by omega
    simp only [hk0, levelSupports, List.mem_singleton] at hS
    subst S
    simpa only [hk0, Nat.sub_zero] using support_subset_box (.leaf A) a ha
  | @branch h l r ihl ihr =>
    cases k with
    | zero =>
      simp only [levelSupports, List.mem_singleton] at hS
      subst S
      simpa only [Nat.sub_zero] using support_subset_box (.branch l r) a ha
    | succ k =>
      simp only [levelSupports, List.mem_append] at hS
      have hl : l.FactorsInBox a := fun A hA => ha A (by simp only [leaves, List.mem_append]; exact Or.inl hA)
      have hr : r.FactorsInBox a := fun A hA => ha A (by simp only [leaves, List.mem_append]; exact Or.inr hA)
      rcases hS with hS | hS
      · simpa only [Nat.add_sub_add_right] using ihl hl k (by omega) hS
      · simpa only [Nat.add_sub_add_right] using ihr hr k (by omega) hS

/-- The allocated cells of each actual level, obtained by traversing the tree. -/
def levelCells {d : ℕ} (a : Fin d → ℕ) :
    {h : ℕ} → BalancedProductTree (IntVec d) h → ℕ → ℕ
  | h, _, 0 => (balancedArrayBox a (2^h)).card
  | _, .leaf _, _+1 => 0
  | _, .branch l r, k+1 => l.levelCells a k + r.levelCells a k

theorem levelCells_eq {d h : ℕ} (t : BalancedProductTree (IntVec d) h)
    (a : Fin d → ℕ) (k : ℕ) (hk : k ≤ h) :
    t.levelCells a k = 2^k * (balancedArrayBox a (2^(h-k))).card := by
  induction t generalizing k with
  | leaf A =>
    have hk0 : k=0 := by omega
    simp [hk0, levelCells]
  | @branch h l r ihl ihr =>
    cases k with
    | zero => simp [levelCells]
    | succ k =>
      simp only [levelCells, ihl k (by omega), ihr k (by omega), Nat.add_sub_add_right, pow_succ]
      ring

/-- Equation (84) applied to the boxes allocated by the actual tree at depth
`k`. The factor two accounts for both signs of each integer coordinate. -/
theorem levelCells_le {d h : ℕ} (t : BalancedProductTree (IntVec d) h)
    (a : Fin d → ℕ) (k : ℕ) (hk : k ≤ h) :
    (t.levelCells a k : ℝ) ≤ (2:ℝ)^k + (balancedArrayBox a (2^h)).card - 1 := by
  have hp : (2:ℝ)^k * (2:ℝ)^(h-k) = (2:ℝ)^h := by
    rw [← pow_add, Nat.add_sub_of_le hk]
  have he (j : Fin d) : 2*(2:ℝ)^(h-k)*a j = (2*(2:ℝ)^h*a j)/(2:ℝ)^k := by
    apply (eq_div_iff (by positivity : (2:ℝ)^k ≠ 0)).mpr
    rw [← hp]
    ring
  have hc (n : ℕ) : ((balancedArrayBox a n).card : ℝ) = ∏ j, (1+2*(n:ℝ)*a j) := by
    rw [balancedArrayBox_card]
    push_cast
    apply Finset.prod_congr rfl
    intro j _
    ring
  calc
    (t.levelCells a k : ℝ) = (2:ℝ)^k * ∏ j, (1+(2*(2:ℝ)^h*a j)/(2:ℝ)^k) := by
      rw [levelCells_eq t a k hk]
      push_cast
      rw [hc]
      push_cast
      simp only [he]
    _ ≤ (2:ℝ)^k + (∏ j, (1+2*(2:ℝ)^h*a j)) - 1 :=
      balanced_array_level_bound_univ (fun j => 2*(2:ℝ)^h*a j)
        (one_le_pow₀ (by norm_num)) (fun j => by positivity)
    _ = _ := by rw [hc]; push_cast; rfl

/-- All allocated cells, retaining every internal array and every leaf array. -/
def totalCells {d : ℕ} (a : Fin d → ℕ) : {h : ℕ} → BalancedProductTree (IntVec d) h → ℕ
  | 0, .leaf _ => (balancedArrayBox a 1).card
  | h+1, .branch l r => (balancedArrayBox a (2^(h+1))).card + l.totalCells a + r.totalCells a

theorem totalCells_eq_sum_levels {d h : ℕ} (t : BalancedProductTree (IntVec d) h)
    (a : Fin d → ℕ) : t.totalCells a = ∑ k ∈ Finset.range (h+1), t.levelCells a k := by
  induction t with
  | leaf A => simp [totalCells, levelCells]
  | @branch h l r ihl ihr =>
    conv_rhs => rw [Finset.sum_range_succ']
    rw [totalCells, ihl, ihr]
    simp only [levelCells, Finset.sum_add_distrib]
    omega

/-- Summing equation (84) over the actual logarithmic number of levels.
This is a cell count, independent of any claim about fast arithmetic runtime. -/
theorem totalCells_le {d h : ℕ} (t : BalancedProductTree (IntVec d) h) (a : Fin d → ℕ) :
    (t.totalCells a : ℝ) ≤ (h+1:ℕ) *
      ((2:ℝ)^h + (balancedArrayBox a (2^h)).card - 1) := by
  rw [totalCells_eq_sum_levels]
  push_cast
  calc
    _ ≤ ∑ _k ∈ Finset.range (h+1), ((2:ℝ)^h + (balancedArrayBox a (2^h)).card - 1) := by
      apply Finset.sum_le_sum
      intro k hk
      have hkh : k ≤ h := by have := Finset.mem_range.mp hk; omega
      apply (levelCells_le t a k hkh).trans
      have hp : (2:ℝ)^k ≤ (2:ℝ)^h := pow_le_pow_right₀ (by norm_num) hkh
      linarith
    _ = _ := by simp; ring

end BalancedProductTree
/-- The actual padded construction inherits all bounds on original factors. -/
theorem balancedProduct_factorsInBox {d : ℕ} (A : List (Finset (IntVec d)))
    (a : Fin d → ℕ) (hA : ∀ S ∈ A, S ⊆ balancedArrayBox a 1) :
    (balancedProduct A).FactorsInBox a := by
  intro S hS
  simp only [balancedProduct, BalancedProductTree.ofList_leaves, padSupportFactors,
    List.mem_append, List.mem_replicate] at hS
  rcases hS with hS | ⟨_, rfl⟩
  · exact hA S hS
  · intro x hx
    have hx0 := Finset.mem_singleton.mp hx
    subst x
    simp [mem_balancedArrayBox]

/-- Integer factors with arbitrary nonnegative real radii fit the rounded-down
integer arrays. This includes narrow and zero-width coordinates exactly. -/
theorem balancedProduct_factorsInRealBox {d : ℕ} (A : List (Finset (IntVec d)))
    (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j)
    (hA : ∀ S ∈ A, ∀ x ∈ S, ∀ j, |(x j : ℝ)| ≤ a j) :
    (balancedProduct A).FactorsInBox (fun j => ⌊a j⌋₊) := by
  apply balancedProduct_factorsInBox
  intro S hS x hx
  apply (mem_balancedArrayBox _ _ _).mpr
  intro j
  have hn : ((x j).natAbs : ℝ) ≤ a j := by
    simpa only [Int.cast_natAbs, Int.cast_abs] using hA S hS x hx j
  have hf := (Nat.le_floor_iff (ha j)).mpr hn
  have hi : ((x j).natAbs : ℤ) ≤ (⌊a j⌋₊ : ℤ) := by exact_mod_cast hf
  simpa only [Nat.one_mul, Int.natCast_natAbs] using hi

/-- The enclosing integer array for the padded root has the volume bound used
in A.1, with an explicit dimension factor accounting for signs and padding. -/
theorem balancedProduct_root_cells_le {d : ℕ} (A : List (Finset (IntVec d)))
    (hA : 0 < A.length) (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j) :
    ((balancedArrayBox (fun j => ⌊a j⌋₊) (2^(Nat.clog 2 A.length))).card : ℝ) ≤
      (4:ℝ)^d * ∏ j, (1+(A.length:ℝ)*a j) := by
  have hpad : (2:ℝ)^(Nat.clog 2 A.length) ≤ 2*(A.length:ℝ) := by
    exact_mod_cast (show 2^(Nat.clog 2 A.length) ≤ 2*A.length by
      simpa only [padSupportFactors_length] using padSupportFactors_length_le A hA)
  rw [balancedArrayBox_card]
  push_cast
  calc
    _ ≤ ∏ j, (4*(1+(A.length:ℝ)*a j)) := by
      apply Finset.prod_le_prod
      · intro j _
        positivity
      · intro j _
        have h₁ := mul_le_mul_of_nonneg_right hpad (Nat.cast_nonneg ⌊a j⌋₊)
        have h₂ := mul_le_mul_of_nonneg_left (Nat.floor_le (ha j))
          (by positivity : (0:ℝ) ≤ 2*(A.length:ℝ))
        nlinarith
    _ = _ := by rw [Finset.prod_mul_distrib]; simp

/-- Explicit logarithmic total-array bound for any nonempty input list and any
nonnegative real radii. Together with the verified support/containment results,
this is the combinatorial array accounting of Lemma A.1. -/
theorem balancedProduct_total_cells_le {d : ℕ} (A : List (Finset (IntVec d)))
    (hA : 0 < A.length) (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j) :
    ((balancedProduct A).totalCells (fun j => ⌊a j⌋₊) : ℝ) ≤
      (Nat.clog 2 A.length + 1 : ℕ) *
        (2*(A.length:ℝ) + (4:ℝ)^d * ∏ j, (1+(A.length:ℝ)*a j)) := by
  apply ((balancedProduct A).totalCells_le (fun j => ⌊a j⌋₊)).trans
  have hpad : (2:ℝ)^(Nat.clog 2 A.length) ≤ 2*(A.length:ℝ) := by
    exact_mod_cast (show 2^(Nat.clog 2 A.length) ≤ 2*A.length by
      simpa only [padSupportFactors_length] using padSupportFactors_length_le A hA)
  have hroot := balancedProduct_root_cells_le A hA a ha
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  linarith

/-- Every actual intermediate support has the real coordinate bounds in A.1;
its block size is determined by the tree depth, not an assigned layer weight. -/
theorem balancedProduct_level_mem_real_box {d : ℕ} (A : List (Finset (IntVec d)))
    (a : Fin d → ℝ) (ha : ∀ j, 0 ≤ a j)
    (hA : ∀ S ∈ A, ∀ x ∈ S, ∀ j, |(x j : ℝ)| ≤ a j)
    (k : ℕ) (hk : k ≤ Nat.clog 2 A.length)
    (S : Finset (IntVec d)) (hS : S ∈ (balancedProduct A).levelSupports k)
    (x : IntVec d) (hx : x ∈ S) (j : Fin d) :
    |(x j : ℝ)| ≤ (2:ℝ)^(Nat.clog 2 A.length-k)*a j := by
  have hbox := (balancedProduct A).levelSupports_subset_box (fun j => ⌊a j⌋₊)
    (balancedProduct_factorsInRealBox A a ha hA) k hk S hS hx
  have hb := (mem_balancedArrayBox _ _ _).mp hbox j
  have hbR : |(x j : ℝ)| ≤ (2:ℝ)^(Nat.clog 2 A.length-k)*(⌊a j⌋₊:ℝ) := by
    exact_mod_cast hb
  exact hbR.trans (mul_le_mul_of_nonneg_left (Nat.floor_le (ha j)) (by positivity))

/-- The actual merge count is linear in the original nonempty factor count. -/
theorem balancedProduct_merges_le {G : Type*} [Zero G] (A : List (Finset G))
    (hA : 0 < A.length) : (balancedProduct A).merges + 1 ≤ 2*A.length := by
  rw [BalancedProductTree.merges_add_one]
  simpa only [padSupportFactors_length] using padSupportFactors_length_le A hA

end Optss
