import Optss.ExecutablePrimeSieve
import Mathlib.NumberTheory.Harmonic.Bounds

/-!
# Harmonic work bound for the executable prime sieve

The source word-operation charge includes array initialization and writes,
materialization/filtering of the two loops, products, and a final flag scan.
Array indexed writes and word arithmetic are the word-RAM primitives of this
model. This is not a claim about Lean heap copying or compiler wall time.
-/
namespace Optss
open scoped BigOperators

theorem primeSieve_sum_map_filter_le {α : Type*} (xs : List α) (p : α → Bool) (f : α → ℕ) :
    ((xs.filter p).map f).sum≤(xs.map f).sum := by
  induction xs with
  | nil => simp
  | cons x xs ih =>
    by_cases hp : p x=true <;> simp [List.filter_cons,hp]
    · exact ih
    · omega

theorem primeSieve_sum_map_mono {α : Type*} (xs : List α) (f g : α → ℕ)
    (h : ∀ x∈xs, f x≤g x) : (xs.map f).sum≤(xs.map g).sum := by
  induction xs with
  | nil => simp
  | cons x xs ih =>
    simp only [List.map_cons,List.sum_cons]
    exact Nat.add_le_add (h x (by simp)) (ih (fun y hy => h y (by simp [hy])))

theorem primeSieve_sum_range (U : ℕ) (f : ℕ → ℕ) :
    ((List.range U).map f).sum=∑ d∈Finset.range U, f d := by
  induction U with
  | zero => simp
  | succ U ih => simp only [List.sum_range_succ,Finset.sum_range_succ,ih]

theorem primeSieveSchedule_length_le (U : ℕ) :
    (primeSieveSchedule U).length≤∑ d∈Finset.range (U+1), (U/d+1) := by
  rw [primeSieveSchedule,List.length_flatMap]
  apply le_trans (primeSieve_sum_map_mono _ _ (fun d => U/d+1) ?_)
  · exact (primeSieve_sum_map_filter_le _ _ _).trans_eq (primeSieve_sum_range _ _)
  · intro d hd
    simpa only [List.length_map,List.length_range] using
      (List.length_filter_le (fun t => decide (2≤t)) (List.range (U/d+1)))

/-- Actual divisor-loop visits obey the harmonic bound, including U=0. -/
theorem primeSieve_division_sum_bound (U : ℕ) :
    ((∑ d∈Finset.range (U+1), U/d : ℕ):ℝ)≤(U:ℝ)*(1+Real.log U) := by
  rw [Finset.sum_range_succ']
  simp only [Nat.div_zero,add_zero]
  have hs : ((∑ d∈Finset.range U, U/(d+1):ℕ):ℝ)≤(U:ℝ)*(harmonic U:ℝ) := by
    simp only [Nat.cast_sum,harmonic,Rat.cast_sum,Rat.cast_inv,Rat.cast_natCast,Finset.mul_sum]
    apply Finset.sum_le_sum
    intro d hd
    simpa only [div_eq_mul_inv] using (Nat.cast_div_le (m := U) (n := d+1) (α := ℝ))
  exact hs.trans (mul_le_mul_of_nonneg_left (harmonic_le_one_add_log U) (Nat.cast_nonneg U))

/-- Charge for one outer candidate: comparison/control plus the actually
materialized inner range, its filter/product cells and append traversal. -/
def primeSieveInnerWordWork (U d : ℕ) : ℕ :=
  if 2≤d then 6+12*(U/d+1) else 2

/-- A conservative source word charge for the complete executable sieve,
including initialization, schedule construction, writes and output scan. -/
def primeSieveWordWork (U : ℕ) : ℕ :=
  6*(U+1)+((List.range (U+1)).map (primeSieveInnerWordWork U)).sum+
    3*((primeSieveSchedule U).length+2)+4

theorem primeSieveWordWork_discrete_bound (U : ℕ) :
    primeSieveWordWork U≤64*((U+1)+∑ d∈Finset.range (U+1), U/d) := by
  have hinner : ((List.range (U+1)).map (primeSieveInnerWordWork U)).sum≤
      ∑ d∈Finset.range (U+1), (6+12*(U/d+1)) := by
    rw [← primeSieve_sum_range]
    apply primeSieve_sum_map_mono
    intro d hd
    unfold primeSieveInnerWordWork
    split_ifs <;> omega
  have hlen := primeSieveSchedule_length_le U
  simp only [mul_add,mul_one,Finset.sum_add_distrib,Finset.sum_mul,← Finset.mul_sum,
    Finset.sum_const,Finset.card_range,smul_eq_mul,mul_one] at hinner hlen
  unfold primeSieveWordWork
  omega

/-- Nearlinear deterministic word work of the actual array sieve. -/
theorem primeSieveWordWork_harmonic_bound (U : ℕ) :
    (primeSieveWordWork U:ℝ)≤64*((U+1:ℕ)+(U:ℝ)*(1+Real.log U)) := by
  have hd : (primeSieveWordWork U:ℝ)≤
      64*((U+1:ℕ)+((∑ d∈Finset.range (U+1), U/d:ℕ):ℝ)) := by
    exact_mod_cast primeSieveWordWork_discrete_bound U
  have hh := primeSieve_division_sum_bound U
  linarith

end Optss
