import Optss.BooleanDyadicTwiddles

/-! Literal work recurrences for Boolean character preparation. Scalar gate
and list-traversal charges follow the stored-fraction answer routines. The
recurrences intentionally include repeated powers/factorials actually used
by the two Taylor sums, instead of assuming unimplemented sharing. -/
namespace Optss

def fourierUnaryDigitsWork : ℕ → ℕ
  | 0 => 1
  | n+1 => fourierUnaryDigitsWork n+
    bitListSignedAddCost false false (fourierUnaryDigits n) [true]+1

def fourierNatFractionWork (n : ℕ) : ℕ := fourierUnaryDigitsWork n+3

theorem fourierUnaryDigitsWork_bound (n : ℕ) : fourierUnaryDigitsWork n≤64*(n+1)^2 := by
  induction n with
  | zero => simp [fourierUnaryDigitsWork]
  | succ n ih =>
    have hlen : (fourierUnaryDigits n).length≤n+1 := by
      rw [(fourierUnaryDigits_canonical n).length,fourierUnaryDigits_value]
      exact (nat_size_le_value n).trans (Nat.le_succ _)
    have h := bitListSignedAddCost_bound false false (fourierUnaryDigits n) [true] (n+1) hlen (by simp)
    rw [fourierUnaryDigitsWork]
    nlinarith

theorem fourierNatFractionWork_bound (n : ℕ) : fourierNatFractionWork n≤64*(n+1)^2+3 :=
  Nat.add_le_add_right (fourierUnaryDigitsWork_bound n) 3

theorem FourierFraction.width_of_bitBound (q : FourierFraction) (L : ℕ)
    (hq : RationalBitBound q.value L) : q.val.numerator.length≤L ∧ q.val.denominator.length≤L := by
  apply (q.val.toRat_bits q.property L).mp
  simpa only [BitListFraction.toRat_value,FourierFraction.value] using hq

theorem FourierFraction.mulWork_bound (q r : FourierFraction) (L : ℕ)
    (hq : RationalBitBound q.value L) (hr : RationalBitBound r.value L) :
    bitListFractionMulCost q.val r.val≤2048*(L+1)^3 :=
  bitListFractionMulCost_bound _ _ q.property.2.2.1 r.property.2.2.1 L
    (q.width_of_bitBound L hq) (r.width_of_bitBound L hr)

theorem FourierFraction.addWork_bound (q r : FourierFraction) (L : ℕ)
    (hq : RationalBitBound q.value L) (hr : RationalBitBound r.value L) :
    bitListFractionAddCost q.val r.val≤2048*(L+1)^3 :=
  bitListFractionAddCost_bound _ _ q.property.2.2.1 r.property.2.2.1 L
    (q.width_of_bitBound L hq) (r.width_of_bitBound L hr)

theorem FourierFraction.divWork_bound (q r : FourierFraction) (L : ℕ)
    (hq : RationalBitBound q.value L) (hr : RationalBitBound r.value L) :
    bitListFractionDivCost q.val r.val≤2048*(L+1)^3 :=
  bitListFractionDivCost_bound _ _ q.property.2.2.1 L
    (q.width_of_bitBound L hq) (r.width_of_bitBound L hr)

def fourierFractionPowWork (q : FourierFraction) : ℕ → ℕ
  | 0 => fourierNatFractionWork 1
  | n+1 => fourierFractionPowWork q n+bitListFractionMulCost (q.pow n).val q.val+1

theorem fourierFractionPowWork_uniform (q : FourierFraction) (n L : ℕ)
    (hq : RationalBitBound q.value L) (hp : ∀ i≤n, RationalBitBound (q.pow i).value L) :
    fourierFractionPowWork q n≤fourierNatFractionWork 1+n*(2048*(L+1)^3+1) := by
  induction n with
  | zero => simp [fourierFractionPowWork]
  | succ n ih =>
    have hi := ih (fun i h => hp i (by omega))
    have hm := (q.pow n).mulWork_bound q L (hp n (by omega)) hq
    rw [fourierFractionPowWork]
    nlinarith

theorem fourierFractionPowWork_height (q : FourierFraction) (B n : ℕ)
    (hq : RationalSizeBound q.value B) :
    fourierFractionPowWork q n≤259+n*(2048*((n+1)*(B.size+1)+1)^3+1) := by
  let L := (n+1)*(B.size+1)
  have hqL : RationalBitBound q.value L := by
    have h := hq.bitBound
    exact ⟨h.1.trans (by dsimp [L]; nlinarith),h.2.trans (by dsimp [L]; nlinarith)⟩
  have hp : ∀ i≤n, RationalBitBound (q.pow i).value L := by
    intro i hi
    rw [FourierFraction.pow_value]
    have h := (hq.pow i).bitBound
    have hs : (B^i).size≤L := (nat_power_size_le B i).trans (by dsimp [L]; nlinarith)
    exact ⟨h.1.trans hs,h.2.trans hs⟩
  have h := fourierFractionPowWork_uniform q n L hqL hp
  have h₁ := fourierNatFractionWork_bound 1
  dsimp [L] at h
  exact h.trans (by norm_num at h₁; omega)

def fourierFractionSumWork (f : ℕ → FourierFraction) (w : ℕ → ℕ) : ℕ → ℕ
  | 0 => fourierNatFractionWork 0
  | n+1 => fourierFractionSumWork f w n+w n+
    bitListFractionAddCost (fourierFractionSum f n).val (f n).val+1

theorem fourierFractionSumWork_uniform (f : ℕ → FourierFraction) (w : ℕ → ℕ) (n L W : ℕ)
    (hw : ∀ i<n, w i≤W) (hf : ∀ i<n, RationalBitBound (f i).value L)
    (hs : ∀ i≤n, RationalBitBound (fourierFractionSum f i).value L) :
    fourierFractionSumWork f w n≤fourierNatFractionWork 0+n*(W+2048*(L+1)^3+1) := by
  induction n with
  | zero => simp [fourierFractionSumWork]
  | succ n ih =>
    have hi := ih (fun i h => hw i (by omega)) (fun i h => hf i (by omega)) (fun i h => hs i (by omega))
    have ha := (fourierFractionSum f n).addWork_bound (f n) L (hs n (by omega)) (hf n (by omega))
    have hn := hw n (by omega)
    rw [fourierFractionSumWork]
    nlinarith

def bitArctanTermWork (x : FourierFraction) (i : ℕ) : ℕ :=
  let s := (FourierFraction.nat 1).neg.pow i
  let q := x.pow (2*i+1)
  let d := FourierFraction.nat (2*i+1)
  fourierNatFractionWork 1+1+fourierFractionPowWork (FourierFraction.nat 1).neg i+
    fourierFractionPowWork x (2*i+1)+bitListFractionMulCost s.val q.val+
    fourierNatFractionWork (2*i+1)+bitListFractionDivCost (s.mul q).val d.val+1

def bitArctanPartialWork (x : FourierFraction) (n : ℕ) : ℕ :=
  fourierFractionSumWork (bitArctanTerm x) (bitArctanTermWork x) (2*n)

def bitPiApproximationWork (n : ℕ) : ℕ :=
  let one := FourierFraction.nat 1
  let two := FourierFraction.nat 2
  let three := FourierFraction.nat 3
  let four := FourierFraction.nat 4
  let a := bitArctanPartial (one.div two) n
  let b := bitArctanPartial (one.div three) n
  2*fourierNatFractionWork 1+fourierNatFractionWork 2+fourierNatFractionWork 3+
    fourierNatFractionWork 4+bitListFractionDivCost one.val two.val+bitListFractionDivCost one.val three.val+
    bitArctanPartialWork (one.div two) n+bitArctanPartialWork (one.div three) n+
    bitListFractionAddCost a.val b.val+bitListFractionMulCost four.val (a.add b).val+1

def bitFourierPhaseAngleWork (X M : FourierFraction) (p : ℕ) : ℕ :=
  let two := FourierFraction.nat 2
  let pi := bitPiApproximation (p+2)
  fourierNatFractionWork 2+bitPiApproximationWork (p+2)+
    bitListFractionMulCost two.val pi.val+bitListFractionMulCost (two.mul pi).val X.val+
    bitListFractionDivCost ((two.mul pi).mul X).val M.val+1

def bitImaginaryPowerWork (t : FourierFraction) : ℕ → ℕ
  | 0 => fourierNatFractionWork 1+fourierNatFractionWork 0
  | n+1 =>
    let z := bitImaginaryPower t n
    bitImaginaryPowerWork t n+bitListFractionMulCost t.neg.val z.2.val+
      bitListFractionMulCost t.val z.1.val+2

def bitFourierFactorialWork : ℕ → ℕ
  | 0 => fourierNatFractionWork 1
  | n+1 => fourierNatFractionWork (n+1)+bitFourierFactorialWork n+
    bitListFractionMulCost (FourierFraction.nat (n+1)).val (bitFourierFactorial n).val+1

def bitImaginaryTermWork (t : FourierFraction) (imaginary : Bool) (j : ℕ) : ℕ :=
  let z := bitImaginaryPower t j
  let c := if imaginary then z.2 else z.1
  bitImaginaryPowerWork t j+bitFourierFactorialWork j+
    bitListFractionDivCost c.val (bitFourierFactorial j).val+1

def bitImaginaryExpPartialWork (t : FourierFraction) (n : ℕ) : ℕ :=
  fourierFractionSumWork (fun j => (bitImaginaryPower t j).1.div (bitFourierFactorial j))
    (bitImaginaryTermWork t false) n+
  fourierFractionSumWork (fun j => (bitImaginaryPower t j).2.div (bitFourierFactorial j))
    (bitImaginaryTermWork t true) n+1

def bitRationalCharacterWork (X M : FourierFraction) (p : ℕ) : ℕ :=
  bitFourierPhaseAngleWork X M p+bitImaginaryExpPartialWork (bitFourierPhaseAngle X M p) (68+p)+1

def bitFourierRoundedFractionWork (q : FourierFraction) : ℕ :=
  bitListFractionRoundCost q.val+bitListTrimVisits (bitListFractionRound q.val).2+1

def bitDyadicCharacterWork (X M : FourierFraction) (p : ℕ) : ℕ :=
  let q := bitRationalCharacter X M (p+2)
  let D := bitFourierDyadicDenominator p
  bitRationalCharacterWork X M (p+2)+2*(p+3)+4+
    bitListFractionMulCost D.val q.1.val+bitListFractionMulCost D.val q.2.val+
    bitFourierRoundedFractionWork (D.mul q.1)+bitFourierRoundedFractionWork (D.mul q.2)+1

def bitModularDyadicCharacterWork (as ms : List Bool) (p : ℕ) : ℕ :=
  let rem := (bitListDivision as ms).remainder
  bitListDivisionBitWork as ms+bitListTrimVisits rem+bitListTrimVisits ms+6+
    bitDyadicCharacterWork (FourierFraction.ofNatDigits rem) (FourierFraction.ofNatDigits ms) p

end Optss
