import Optss.NormalizedKernelLattice
import Optss.RationalShortVectorSearch
import Optss.EncodedRationalReduction

/-!
# Actual lattice-reduction search for a short integer kernel vector

The congruence basis is computed by extended gcd, normalized by the searched
box widths, reduced by the verified Boolean LLL routine, and searched through
a rank-only coefficient box. This stage proves exact answers; its additional
extended-gcd and search bit-cost refinements are not asserted here.
-/
namespace Optss
open scoped BigOperators
variable {d : ℕ}

theorem rational_basis_lattice_image (B : Matrix (Fin d) (Fin d) ℚ)
    (b : Basis (Fin d) ℝ (EuclideanSpace ℝ (Fin d)))
    (hb : ∀ j,b j=rationalEuclideanRows B j) (x : EuclideanSpace ℝ (Fin d)) :
    x∈basisIntegerLattice b ↔ ∃ u∈Submodule.span ℤ (Set.range B),rationalEuclideanVector u=x := by
  constructor
  · intro hx
    obtain ⟨z,hz⟩ := (mem_basisIntegerLattice_iff b x).mp hx
    refine ⟨∑ j,z j •B j,(Submodule.mem_span_range_iff_exists_fun ℤ).mpr ⟨z,rfl⟩,?_⟩
    rw [←hz,map_sum]
    apply Finset.sum_congr rfl
    intro j _
    rw [map_zsmul,hb]
    ext i
    simp [rationalEuclideanRows,rationalEuclideanVector,PiLp.smul_apply]
  · rintro ⟨u,hu,rfl⟩
    exact (rational_basis_mem_integer_lattice B b hb u).mpr hu

theorem normalizedKernelMap_injective (a : Fin d→ℤ) (β : Fin d→ℕ) (hβ : ∀ i,0<β i) :
    Function.Injective (normalizedKernelMap a β) := by
  intro x y h
  apply congruenceLatticeMap_injective a _ (ne_of_gt (shortKernelModulus_pos a β))
  ext i
  have hi := congrFun h i
  change (congruenceLatticeMap a (shortKernelModulus a β) x i:ℚ)/(β i:ℚ)=
    (congruenceLatticeMap a (shortKernelModulus a β) y i:ℚ)/(β i:ℚ) at hi
  have hn : (β i:ℚ)≠0 := by exact_mod_cast (ne_of_gt (hβ i))
  have he := (div_left_inj' hn).mp hi
  exact_mod_cast he

theorem normalized_short_kernel_basis_iff (a : Fin d→ℤ) (β : Fin d→ℕ) (hβ : ∀ i,0<β i)
    (B : Matrix (Fin d) (Fin d) ℚ)
    (b : Basis (Fin d) ℝ (EuclideanSpace ℝ (Fin d)))
    (hb : ∀ j,b j=rationalEuclideanRows B j)
    (hspan : Submodule.span ℤ (Set.range B)=Submodule.span ℤ (Set.range (normalizedKernelRows a β))) :
    (∃ x∈basisIntegerLattice b,x≠0 ∧ x∈euclideanCoordinateCube d 1) ↔
      ∃ z∈integerBudgetBox β,z≠0 ∧ (∑ j,a j*z j)=0 := by
  constructor
  · rintro ⟨x,hxΛ,hxn,hxK⟩
    obtain ⟨u,hu,hux⟩ := (rational_basis_lattice_image B b hb x).mp hxΛ
    rw [hspan,normalizedKernelRows_mem_span] at hu
    obtain ⟨w,rfl⟩ := hu
    let z := congruenceLatticeMap a (shortKernelModulus a β) w
    have hzK : z∈integerBudgetBox β := (normalizedKernelMap_cube_iff a β hβ w).mp (hux ▸ hxK)
    refine ⟨z,hzK,?_,(short_kernel_full_lattice_iff a β z hzK).mp ⟨w,rfl⟩⟩
    intro hz0
    apply hxn
    rw [←hux]
    have hu0 : normalizedKernelMap a β w=0 := by
      ext i
      change (z i:ℚ)/(β i:ℚ)=0
      rw [hz0]
      simp
    rw [hu0,map_zero]
  · rintro ⟨z,hzK,hzn,hzker⟩
    obtain ⟨w,hw⟩ := (short_kernel_full_lattice_iff a β z hzK).mpr hzker
    let u := normalizedKernelMap a β w
    have hu : u∈Submodule.span ℤ (Set.range B) := by
      rw [hspan,normalizedKernelRows_mem_span]
      exact ⟨w,rfl⟩
    refine ⟨rationalEuclideanVector u,(rational_basis_mem_integer_lattice B b hb u).mpr hu,?_,?_⟩
    · intro hu0
      have hu0' : normalizedKernelMap a β w=0 := rationalEuclideanVector_injective
        (hu0.trans (map_zero _).symm)
      have hw0 : w=0 := normalizedKernelMap_injective a β hβ (hu0'.trans (map_zero _).symm)
      exact hzn (hw.symm.trans (by rw [hw0,map_zero]))
    · apply (normalizedKernelMap_cube_iff a β hβ w).mpr
      rwa [hw]

def computedShortKernelRows (a : Fin d→ℤ) (β : Fin d→ℕ) : Matrix (Fin d) (Fin d) ℚ :=
  encodedFractionRows (encodedRationalReduction (bitRationalMatrixRepresentation (normalizedKernelRows a β))).1

def computedShortKernelCoefficients (a : Fin d→ℤ) (β : Fin d→ℕ) : Option (Fin d→ℤ) :=
  let data := (encodedRationalReduction (bitRationalMatrixRepresentation (normalizedKernelRows a β))).1
  rationalShortVectorSearch (encodedFractionRows data)

theorem computedShortKernelCoefficients_complete (hd : 0<d)
    (a : Fin d→ℤ) (β : Fin d→ℕ) (hβ : ∀ i,0<β i) :
    computedShortKernelCoefficients a β≠none ↔
      ∃ z∈integerBudgetBox β,z≠0 ∧ (∑ j,a j*z j)=0 := by
  obtain ⟨hspan,b,hb,hdefect⟩ := encodedRationalReduction_spec (normalizedKernelRows a β)
    (normalizedKernelRows_independent a β hβ)
  exact (rationalShortVectorSearch_ne_none_iff hd _ b hb hdefect).trans
    (normalized_short_kernel_basis_iff a β hβ _ b hb hspan)

def unscaleKernelRational (β : Fin d→ℕ) (u : Fin d→ℚ) : Fin d→ℤ :=
  fun i => ((β i:ℚ)*u i).num

theorem unscaleKernelRational_normalized (a : Fin d→ℤ) (β : Fin d→ℕ) (hβ : ∀ i,0<β i)
    (w : Fin d→ℤ) :
    unscaleKernelRational β (normalizedKernelMap a β w)=congruenceLatticeMap a (shortKernelModulus a β) w := by
  ext i
  have hn : (β i:ℚ)≠0 := by exact_mod_cast (ne_of_gt (hβ i))
  change (((β i:ℚ)*((congruenceLatticeMap a (shortKernelModulus a β) w i:ℚ)/(β i:ℚ))):ℚ).num=_
  have he : (β i:ℚ)*((congruenceLatticeMap a (shortKernelModulus a β) w i:ℚ)/(β i:ℚ))=
      (congruenceLatticeMap a (shortKernelModulus a β) w i:ℚ) := by field_simp
  rw [he]
  simp

def computedShortKernelVector (a : Fin d→ℤ) (β : Fin d→ℕ) : Option (Fin d→ℤ) :=
  let data := (encodedRationalReduction (bitRationalMatrixRepresentation (normalizedKernelRows a β))).1
  let B := encodedFractionRows data
  (rationalShortVectorSearch B).map fun z => unscaleKernelRational β (rationalIntegerSynthesis B z)

theorem computedShortKernelVector_eq (a : Fin d→ℤ) (β : Fin d→ℕ) :
    computedShortKernelVector a β=(computedShortKernelCoefficients a β).map (fun z =>
      unscaleKernelRational β (rationalIntegerSynthesis (computedShortKernelRows a β) z)) := rfl

theorem computedShortKernelVector_sound (a : Fin d→ℤ) (β : Fin d→ℕ) (hβ : ∀ i,0<β i)
    (z : Fin d→ℤ) (hz : computedShortKernelVector a β=some z) :
    z∈integerBudgetBox β ∧ z≠0 ∧ (∑ j,a j*z j)=0 := by
  obtain ⟨hspan,b,hb,hdefect⟩ := encodedRationalReduction_spec (normalizedKernelRows a β)
    (normalizedKernelRows_independent a β hβ)
  cases hc : computedShortKernelCoefficients a β with
  | none => simp [computedShortKernelVector_eq,hc] at hz
  | some c =>
    have hcs := rationalShortVectorSearch_sound (computedShortKernelRows a β) c hc
    have hu : rationalIntegerSynthesis (computedShortKernelRows a β) c∈
        Submodule.span ℤ (Set.range (normalizedKernelRows a β)) := by
      rw [←hspan,Submodule.mem_span_range_iff_exists_fun]
      refine ⟨c,?_⟩
      ext i
      simp [rationalIntegerSynthesis,Finset.sum_apply,computedShortKernelRows]
    obtain ⟨w,hw⟩ := (normalizedKernelRows_mem_span a β _).mp hu
    simp only [computedShortKernelVector_eq,hc,Option.map_some] at hz
    replace hz := Option.some.inj hz
    change unscaleKernelRational β (rationalIntegerSynthesis (computedShortKernelRows a β) c)=z at hz
    have hz' : congruenceLatticeMap a (shortKernelModulus a β) w=z := by
      rw [←hz,←hw,unscaleKernelRational_normalized a β hβ]
    have hreal : latticeIntegerSynthesis b c=rationalEuclideanVector (normalizedKernelMap a β w) := by
      ext i
      rw [rationalIntegerSynthesis_real _ b hb]
      rw [hw]
      rfl
    have hcK := (rationalShortCoefficient_iff _ b hb c).mp (show rationalShortCoefficient _ c=true from by
      simp only [rationalShortCoefficient,decide_eq_true_eq]
      exact hcs)
    have hwK := (normalizedKernelMap_cube_iff a β hβ w).mp (hreal ▸ hcK.2)
    have hzK : z∈integerBudgetBox β := hz' ▸ hwK
    refine ⟨hzK,?_,(short_kernel_full_lattice_iff a β z hzK).mp ⟨w,hz'⟩⟩
    intro hz0
    have hu0 : normalizedKernelMap a β w=0 := by
      ext i
      change (congruenceLatticeMap a (shortKernelModulus a β) w i:ℚ)/(β i:ℚ)=0
      rw [hz',hz0]
      simp
    have hzero : latticeIntegerSynthesis b c=0 := by rw [hreal,hu0,map_zero]
    exact hcs.1 ((latticeIntegerSynthesis_eq_zero_iff b c).mp hzero)

theorem computedShortKernelVector_complete (hd : 0<d)
    (a : Fin d→ℤ) (β : Fin d→ℕ) (hβ : ∀ i,0<β i) :
    computedShortKernelVector a β≠none ↔
      ∃ z∈integerBudgetBox β,z≠0 ∧ (∑ j,a j*z j)=0 := by
  simpa only [computedShortKernelVector_eq,ne_eq,Option.map_eq_none_iff] using
    computedShortKernelCoefficients_complete hd a β hβ
end Optss
