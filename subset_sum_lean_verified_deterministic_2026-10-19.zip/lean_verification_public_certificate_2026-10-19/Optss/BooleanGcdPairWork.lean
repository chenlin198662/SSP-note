import Optss.BooleanGcdPairNative

/-! Polynomial scalar/list work and payload bounds for the stored unimodular
pair. The matrix entries are shared immutably after their one-time computation;
external matrix lookup/update and copying are separate container operations. -/
namespace Optss

theorem bitListXgcdFuel_gcd_length (fuel as bs : List Bool) (s t s' t' : BitListInteger)
    (ha : BitListCanonical as) (hb : BitListCanonical bs) (L : ℕ)
    (hal : as.length≤L) (hbl : bs.length≤L) :
    (bitListXgcdFuel fuel as s t bs s' t').gcdDigits.length≤L := by
  induction fuel generalizing as bs s t s' t' with
  | nil => exact hbl
  | cons b fuel ih =>
    rw [bitListXgcdFuel]
    dsimp only
    split_ifs with haz hrz
    · exact hbl
    · exact hal
    · have hap := ha.pos_of_not_empty haz
      have hrc := bitListDivision_remainder_canonical bs as hap
      have hrp := hrc.pos_of_not_empty hrz
      have hsc := bitListDivision_remainder_canonical as (bitListDivision bs as).remainder hrp
      have hrl : (bitListDivision bs as).remainder.length≤L :=
        (bitListDivisionDigits_remainder_width bs as hap).trans hal
      have hsl : (bitListDivision as (bitListDivision bs as).remainder).remainder.length≤L :=
        (bitListDivisionDigits_remainder_width _ _ hrp).trans hrl
      exact ih _ _ _ _ _ _ hsc hrc hsl hrl

theorem bitListIntegerXgcd_gcd_length (x y : BitListInteger) (L : ℕ)
    (hx : x.digits.length≤L) (hy : y.digits.length≤L) :
    (bitListIntegerXgcd x y).gcdDigits.length≤L := by
  exact bitListXgcdFuel_gcd_length _ _ _ _ _ _ _ (bitListTrim_canonical _) (bitListTrim_canonical _) L
    ((bitListTrim_length_le _).trans hx) ((bitListTrim_length_le _).trans hy)

def BitListGcdPairMatrix.Bounded (M : BitListGcdPairMatrix) (W : ℕ) : Prop :=
  M.a.digits.length≤W ∧ M.b.digits.length≤W ∧ M.c.digits.length≤W ∧ M.d.digits.length≤W

theorem bitListGcdPairMatrix_lengths (x y : BitListInteger) (L : ℕ)
    (hx : x.digits.length≤L) (hy : y.digits.length≤L) :
    (bitListGcdPairMatrix x y).Bounded (1+2*L*(L+1)) := by
  have hc := bitListIntegerXgcd_lengths x y L hx hy
  have hL : L≤1+2*L*(L+1) := by nlinarith
  unfold bitListGcdPairMatrix
  dsimp only
  split_ifs
  · simp [BitListGcdPairMatrix.Bounded,bitListNonnegativeInteger]
  · refine ⟨hc.1,hc.2,?_,?_⟩
    · exact ((bitListDivision_quotient_length_le _ _).trans hy).trans hL
    · exact ((bitListDivision_quotient_length_le _ _).trans hx).trans hL

def bitListGcdPairMatrixWork (x y : BitListInteger) : ℕ :=
  let out := bitListIntegerXgcd x y
  let gs := bitListTrim out.gcdDigits
  bitListIntegerXgcdWork x y+bitListTrimVisits out.gcdDigits+
    if gs.isEmpty then 6 else 8+bitListDivisionCost x.digits gs+bitListDivisionCost y.digits gs

theorem bitListGcdPairMatrixWork_bound (x y : BitListInteger) (L : ℕ)
    (hx : x.digits.length≤L) (hy : y.digits.length≤L) :
    bitListGcdPairMatrixWork x y≤11000*(L+1)^5 := by
  have hc := bitListIntegerXgcdWork_bound x y L hx hy
  have hgl := bitListIntegerXgcd_gcd_length x y L hx hy
  let gs := bitListTrim (bitListIntegerXgcd x y).gcdDigits
  have hgs : gs.length≤L := (bitListTrim_length_le _).trans hgl
  have hp : 1≤(L+1)^5 := Nat.one_le_pow _ _ (Nat.succ_le_succ (Nat.zero_le L))
  have hlp : L+1≤(L+1)^5 := Nat.le_self_pow (by decide) _
  have hsq : (L+1)^2≤(L+1)^5 := pow_le_pow_right₀ (by omega) (by decide)
  unfold bitListGcdPairMatrixWork
  dsimp only
  split_ifs with hz
  · rw [bitListTrimVisits_eq]
    nlinarith only [hc,hgl,hp,hlp]
  · have hgp : 0<binaryDigitsValue gs := (bitListTrim_canonical _).pos_of_not_empty hz
    have hxdiv := bitListDivisionCost_uniform x.digits gs hgp L hx hgs
    have hydiv := bitListDivisionCost_uniform y.digits gs hgp L hy hgs
    rw [bitListTrimVisits_eq]
    nlinarith only [hc,hgl,hp,hlp,hsq,hxdiv,hydiv]

def bitListGcdPairApplyWork (M : BitListGcdPairMatrix) (u v : BitListInteger) : ℕ :=
  bitListIntegerMulCost M.a u+bitListIntegerMulCost M.b v+
    bitListIntegerMulCost M.c u+bitListIntegerMulCost M.d v+
    bitListIntegerAddCost (bitListIntegerMul M.a u) (bitListIntegerMul M.b v)+
    bitListIntegerAddCost (bitListIntegerMul M.c u) (bitListIntegerMul M.d v)+8

def bitListGcdPairInverseApplyWork (M : BitListGcdPairMatrix) (u v : BitListInteger) : ℕ :=
  bitListIntegerMulCost M.d u+bitListIntegerMulCost M.b v+
    bitListIntegerMulCost M.a v+bitListIntegerMulCost M.c u+
    bitListIntegerSubCost (bitListIntegerMul M.d u) (bitListIntegerMul M.b v)+
    bitListIntegerSubCost (bitListIntegerMul M.a v) (bitListIntegerMul M.c u)+8

theorem bitListGcdPairApplyWork_bound (M : BitListGcdPairMatrix) (u v : BitListInteger)
    (W : ℕ) (hM : M.Bounded W) (hu : u.digits.length≤W) (hv : v.digits.length≤W) :
    bitListGcdPairApplyWork M u v≤512*(W+1)^2 := by
  obtain ⟨ha,hb,hc,hd⟩ := hM
  have h1 := bitListIntegerMulCost_bound M.a u W ha hu
  have h2 := bitListIntegerMulCost_bound M.b v W hb hv
  have h3 := bitListIntegerMulCost_bound M.c u W hc hu
  have h4 := bitListIntegerMulCost_bound M.d v W hd hv
  have h5 := bitListIntegerAddCost_bound (bitListIntegerMul M.a u) (bitListIntegerMul M.b v) (2*W)
    ((bitListIntegerMul_length _ _).trans (by omega)) ((bitListIntegerMul_length _ _).trans (by omega))
  have h6 := bitListIntegerAddCost_bound (bitListIntegerMul M.c u) (bitListIntegerMul M.d v) (2*W)
    ((bitListIntegerMul_length _ _).trans (by omega)) ((bitListIntegerMul_length _ _).trans (by omega))
  unfold bitListGcdPairApplyWork
  nlinarith only [h1,h2,h3,h4,h5,h6]

theorem bitListGcdPairInverseApplyWork_bound (M : BitListGcdPairMatrix) (u v : BitListInteger)
    (W : ℕ) (hM : M.Bounded W) (hu : u.digits.length≤W) (hv : v.digits.length≤W) :
    bitListGcdPairInverseApplyWork M u v≤512*(W+1)^2 := by
  obtain ⟨ha,hb,hc,hd⟩ := hM
  have h1 := bitListIntegerMulCost_bound M.d u W hd hu
  have h2 := bitListIntegerMulCost_bound M.b v W hb hv
  have h3 := bitListIntegerMulCost_bound M.a v W ha hv
  have h4 := bitListIntegerMulCost_bound M.c u W hc hu
  have h5 := bitListIntegerSubCost_bound (bitListIntegerMul M.d u) (bitListIntegerMul M.b v) (2*W)
    ((bitListIntegerMul_length _ _).trans (by omega)) ((bitListIntegerMul_length _ _).trans (by omega))
  have h6 := bitListIntegerSubCost_bound (bitListIntegerMul M.a v) (bitListIntegerMul M.c u) (2*W)
    ((bitListIntegerMul_length _ _).trans (by omega)) ((bitListIntegerMul_length _ _).trans (by omega))
  unfold bitListGcdPairInverseApplyWork
  nlinarith only [h1,h2,h3,h4,h5,h6]

/-- Payload growth is additive in the matrix and argument bit bounds. -/
theorem bitListGcdPairApply_lengths (M : BitListGcdPairMatrix) (u v : BitListInteger)
    (W C : ℕ) (hM : M.Bounded W) (hu : u.digits.length≤C) (hv : v.digits.length≤C) :
    (bitListGcdPairApply M u v).1.digits.length≤W+C+1 ∧
    (bitListGcdPairApply M u v).2.digits.length≤W+C+1 := by
  obtain ⟨ha,hb,hc,hd⟩ := hM
  constructor
  · exact (bitListIntegerAdd_length _ _).trans (by
      have h1 := bitListIntegerMul_length M.a u
      have h2 := bitListIntegerMul_length M.b v
      omega)
  · exact (bitListIntegerAdd_length _ _).trans (by
      have h1 := bitListIntegerMul_length M.c u
      have h2 := bitListIntegerMul_length M.d v
      omega)
end Optss
