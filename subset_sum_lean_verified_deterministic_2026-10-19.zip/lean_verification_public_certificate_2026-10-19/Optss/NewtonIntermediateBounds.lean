import Optss.CoefficientBounds

/-!
# Coefficients before Newton division

This file bounds each product and every signed partial numerator in §10.1,
including products of truncated operands. The bounds apply before exact
integer division, so cancellation is not needed to control intermediate
integer sizes. No convolution cost or machine arithmetic model is assumed.
-/

namespace Optss
open scoped BigOperators
noncomputable section
variable {ι σ : Type*} [Fintype ι]

/-- A Newton product has one monomial for each pair of a label and a
`j`-element selection; the power-sum label may also lie in that selection. -/
theorem powerSum_mul_elementary_monomial_expand (u : ι → σ →₀ ℕ) (l j : ℕ) :
    powerSum (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l *
      elementaryCoefficient (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) j =
    ∑ i, ∑ s ∈ (Finset.univ : Finset ι).powersetCard j,
      MvPolynomial.monomial (l • u i + ∑ a ∈ s, u a) (1 : ℤ) := by
  classical
  rw [powerSum, elementaryCoefficient_monomial_expand, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro i _
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro s _
  simp [MvPolynomial.monomial_pow, MvPolynomial.monomial_mul]

/-- Every coefficient in a Newton product is a nonnegative count of at most
`n * choose(n,j)` label/selection pairs. -/
theorem powerSum_mul_elementary_monomial_coeff_bounds
    (u : ι → σ →₀ ℕ) (l j : ℕ) (e : σ →₀ ℕ) :
    0 ≤ MvPolynomial.coeff e
      (powerSum (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l *
        elementaryCoefficient (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) j) ∧
    MvPolynomial.coeff e
      (powerSum (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l *
        elementaryCoefficient (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) j) ≤
      (Fintype.card ι : ℤ) * ((Fintype.card ι).choose j : ℤ) := by
  classical
  rw [powerSum_mul_elementary_monomial_expand, MvPolynomial.coeff_sum]
  simp_rw [MvPolynomial.coeff_sum]
  constructor
  · apply Finset.sum_nonneg
    intro i _
    apply Finset.sum_nonneg
    intro s _
    simp only [MvPolynomial.coeff_monomial]
    split_ifs <;> norm_num
  · calc
      _ ≤ ∑ _i : ι, ∑ _s ∈ (Finset.univ : Finset ι).powersetCard j, (1 : ℤ) := by
        apply Finset.sum_le_sum
        intro i _
        apply Finset.sum_le_sum
        intro s _
        simp only [MvPolynomial.coeff_monomial]
        split_ifs <;> norm_num
      _ = _ := by simp

theorem powerSum_mul_elementary_monomial_coeff_le_pow
    (u : ι → σ →₀ ℕ) (l j : ℕ) (e : σ →₀ ℕ) :
    MvPolynomial.coeff e
      (powerSum (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l *
        elementaryCoefficient (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) j) ≤
      (Fintype.card ι : ℤ) ^ (j + 1) := by
  calc
    _ ≤ (Fintype.card ι : ℤ) * ((Fintype.card ι).choose j : ℤ) :=
      (powerSum_mul_elementary_monomial_coeff_bounds u l j e).2
    _ ≤ (Fintype.card ι : ℤ) * (Fintype.card ι : ℤ) ^ j := by
      exact_mod_cast Nat.mul_le_mul_left (Fintype.card ι)
        (Nat.choose_le_pow (Fintype.card ι) j)
    _ = _ := by ring

/-- A nonnegative coefficient can only decrease when it is truncated. -/
theorem coeff_truncatePolynomial_nonneg_le (Δ e : σ →₀ ℕ)
    (p : MvPolynomial σ ℤ) (hp : ∀ d, 0 ≤ MvPolynomial.coeff d p) :
    0 ≤ MvPolynomial.coeff e (truncatePolynomial Δ p) ∧
      MvPolynomial.coeff e (truncatePolynomial Δ p) ≤ MvPolynomial.coeff e p := by
  classical
  rw [coeff_truncatePolynomial]
  split_ifs
  · exact ⟨hp e, le_rfl⟩
  · exact ⟨le_rfl, hp e⟩

/-- Truncating either operand cannot increase any coefficient of a product
with nonnegative integer coefficients, even outside the retained box. -/
theorem coeff_mul_truncatePolynomial_nonneg_le (Δ e : σ →₀ ℕ)
    (p q : MvPolynomial σ ℤ)
    (hp : ∀ d, 0 ≤ MvPolynomial.coeff d p)
    (hq : ∀ d, 0 ≤ MvPolynomial.coeff d q) :
    0 ≤ MvPolynomial.coeff e (truncatePolynomial Δ p * truncatePolynomial Δ q) ∧
      MvPolynomial.coeff e (truncatePolynomial Δ p * truncatePolynomial Δ q) ≤
        MvPolynomial.coeff e (p * q) := by
  classical
  rw [MvPolynomial.coeff_mul, MvPolynomial.coeff_mul]
  constructor
  · apply Finset.sum_nonneg
    intro ab _
    exact mul_nonneg (coeff_truncatePolynomial_nonneg_le Δ ab.1 p hp).1
      (coeff_truncatePolynomial_nonneg_le Δ ab.2 q hq).1
  · apply Finset.sum_le_sum
    intro ab _
    exact mul_le_mul (coeff_truncatePolynomial_nonneg_le Δ ab.1 p hp).2
      (coeff_truncatePolynomial_nonneg_le Δ ab.2 q hq).2
      (coeff_truncatePolynomial_nonneg_le Δ ab.2 q hq).1 (hp ab.1)

theorem powerSum_monomial_coeff_nonneg (u : ι → σ →₀ ℕ) (l : ℕ)
    (e : σ →₀ ℕ) :
    0 ≤ MvPolynomial.coeff e
      (powerSum (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l) := by
  classical
  rw [powerSum, MvPolynomial.coeff_sum]
  apply Finset.sum_nonneg
  intro i _
  simp only [MvPolynomial.monomial_pow, one_pow, MvPolynomial.coeff_monomial]
  split_ifs <;> norm_num

/-- Every multiplication in the truncated Newton numerator is bounded by
`B^k`, uniformly for `1 ≤ l ≤ k`, where `B ≥ max(1,n)`. -/
theorem truncated_newton_product_coeff_bound (u : ι → σ →₀ ℕ)
    (Δ e : σ →₀ ℕ) (k l B : ℕ) (hB : 1 ≤ B)
    (hnB : Fintype.card ι ≤ B) (hl : l ∈ Finset.Icc 1 k) :
    0 ≤ MvPolynomial.coeff e
      (truncatePolynomial Δ (powerSum (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l) *
       truncatePolynomial Δ (elementaryCoefficient
         (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) (k - l))) ∧
    MvPolynomial.coeff e
      (truncatePolynomial Δ (powerSum (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l) *
       truncatePolynomial Δ (elementaryCoefficient
         (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) (k - l))) ≤ (B : ℤ) ^ k := by
  have htr := coeff_mul_truncatePolynomial_nonneg_le Δ e _ _
    (powerSum_monomial_coeff_nonneg u l)
    (elementaryCoefficient_monomial_coeff_nonneg u (k - l))
  refine ⟨htr.1, htr.2.trans ?_⟩
  calc
    _ ≤ (Fintype.card ι : ℤ) ^ (k - l + 1) :=
      powerSum_mul_elementary_monomial_coeff_le_pow u l (k - l) e
    _ ≤ (B : ℤ) ^ (k - l + 1) := by
      exact_mod_cast Nat.pow_le_pow_left hnB (k - l + 1)
    _ ≤ (B : ℤ) ^ k := by
      apply pow_le_pow_right₀ (by exact_mod_cast hB)
      obtain ⟨hl1, hlk⟩ := Finset.mem_Icc.mp hl
      omega

/-- Every partial signed sum during one Newton update has coefficient
magnitude at most `|L| * B^k`, so cancellation is unnecessary for its bound. -/
theorem truncated_newton_partial_numerator_coeff_bound (u : ι → σ →₀ ℕ)
    (Δ e : σ →₀ ℕ) (k B : ℕ) (hB : 1 ≤ B) (hnB : Fintype.card ι ≤ B)
    (L : Finset ℕ) (hL : L ⊆ Finset.Icc 1 k) :
    |MvPolynomial.coeff e (∑ l ∈ L,
      (-1 : MvPolynomial σ ℤ) ^ (l - 1) *
        truncatePolynomial Δ (powerSum (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l) *
        truncatePolynomial Δ (elementaryCoefficient
          (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) (k - l)))| ≤
      (L.card : ℤ) * (B : ℤ) ^ k := by
  classical
  rw [MvPolynomial.coeff_sum]
  calc
    _ ≤ ∑ l ∈ L, |MvPolynomial.coeff e
        ((-1 : MvPolynomial σ ℤ) ^ (l - 1) *
          truncatePolynomial Δ (powerSum (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l) *
          truncatePolynomial Δ (elementaryCoefficient
            (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) (k - l)))| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _l ∈ L, (B : ℤ) ^ k := by
      apply Finset.sum_le_sum
      intro l hl
      have hs : (-1 : MvPolynomial σ ℤ) ^ (l - 1) =
          MvPolynomial.C ((-1 : ℤ) ^ (l - 1)) := by simp
      rw [hs, mul_assoc, MvPolynomial.coeff_C_mul, abs_mul, abs_pow]
      simp only [abs_neg, abs_one, one_pow, one_mul]
      have hb := truncated_newton_product_coeff_bound u Δ e k l B hB hnB (hL hl)
      rw [abs_of_nonneg hb.1]
      exact hb.2
    _ = _ := by simp

/-- The complete pre-division numerator obeys the explicit `k * B^k` bound. -/
theorem truncated_newton_numerator_coeff_bound (u : ι → σ →₀ ℕ)
    (Δ e : σ →₀ ℕ) (k B : ℕ) (hB : 1 ≤ B) (hnB : Fintype.card ι ≤ B) :
    |MvPolynomial.coeff e (∑ l ∈ Finset.Icc 1 k,
      (-1 : MvPolynomial σ ℤ) ^ (l - 1) *
        truncatePolynomial Δ (powerSum (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l) *
        truncatePolynomial Δ (elementaryCoefficient
          (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) (k - l)))| ≤
      (k : ℤ) * (B : ℤ) ^ k := by
  simpa using truncated_newton_partial_numerator_coeff_bound u Δ e k B hB hnB
    (Finset.Icc 1 k) (by rfl)

/-- Multiplication by the number of Newton terms costs at most its binary
magnitude size in addition to the product's `k * size(B)` magnitude bits. -/
theorem nat_size_le_of_le_mul_pow {z B k : ℕ} (hz : z ≤ k * B ^ k) :
    z.size ≤ k.size + k * B.size := by
  apply Nat.size_le.mpr
  have hpow : B ^ k ≤ 2 ^ (k * B.size) := by
    calc
      B ^ k ≤ (2 ^ B.size) ^ k := Nat.pow_le_pow_left (Nat.lt_size_self B).le k
      _ = _ := by rw [← pow_mul, Nat.mul_comm]
  calc
    z ≤ k * B ^ k := hz
    _ ≤ k * 2 ^ (k * B.size) := Nat.mul_le_mul_left _ hpow
    _ < 2 ^ k.size * 2 ^ (k * B.size) :=
      Nat.mul_lt_mul_of_pos_right (Nat.lt_size_self k) (by positivity)
    _ = _ := by rw [pow_add]

/-- Explicit magnitude-bit bound on the signed Newton numerator before
truncation or division. A signed encoding uses at most one more sign bit. -/
theorem truncated_newton_numerator_coeff_bits (u : ι → σ →₀ ℕ)
    (Δ e : σ →₀ ℕ) (k B : ℕ) (hB : 1 ≤ B) (hnB : Fintype.card ι ≤ B) :
    (MvPolynomial.coeff e (∑ l ∈ Finset.Icc 1 k,
      (-1 : MvPolynomial σ ℤ) ^ (l - 1) *
        truncatePolynomial Δ (powerSum (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) l) *
        truncatePolynomial Δ (elementaryCoefficient
          (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) (k - l)))).natAbs.size ≤
      k.size + k * B.size := by
  apply nat_size_le_of_le_mul_pow
  have h := truncated_newton_numerator_coeff_bound u Δ e k B hB hnB
  rw [← Int.natCast_natAbs] at h
  exact_mod_cast h

/-- The same bound applies to the actual count-based table reads. Only the
proof uses copy labels; preparation and the Newton tables use capacities. -/
theorem countNewton_partial_numerator_coeff_bound (c : ι → ℕ)
    (u : ι → σ →₀ ℕ) (Δ e : σ →₀ ℕ) (kcap k B : ℕ)
    (hk : 1 ≤ k) (hkk : k ≤ kcap) (hB : 1 ≤ B) (hcB : ∑ i, c i ≤ B)
    (L : Finset ℕ) (hL : L ⊆ Finset.Icc 1 k) :
    let powers := countPowerTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap
    let previous := newtonTable Δ powers (k - 1)
    |MvPolynomial.coeff e (∑ l ∈ L,
      (-1 : MvPolynomial σ ℤ) ^ (l - 1) * powers.getD l 0 * previous.getD (k - l) 0)| ≤
      (L.card : ℤ) * (B : ℤ) ^ k := by
  classical
  dsimp only
  have hsum :
      (∑ l ∈ L, (-1 : MvPolynomial σ ℤ) ^ (l - 1) *
        (countPowerTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap).getD l 0 *
        (newtonTable Δ
          (countPowerTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap)
          (k - 1)).getD (k - l) 0) =
      ∑ l ∈ L, (-1 : MvPolynomial σ ℤ) ^ (l - 1) *
        truncatePolynomial Δ (powerSum
          (fun p : Σ i, Fin (c i) => MvPolynomial.monomial (u p.1) (1 : ℤ)) l) *
        truncatePolynomial Δ (elementaryCoefficient
          (fun p : Σ i, Fin (c i) => MvPolynomial.monomial (u p.1) (1 : ℤ)) (k - l)) := by
    apply Finset.sum_congr rfl
    intro l hl
    obtain ⟨hl1, hlk⟩ := Finset.mem_Icc.mp (hL hl)
    rw [countPowerTable_getD _ _ _ _ _ (by omega)]
    rw [newtonTable_getD Δ
      (fun p : Σ i, Fin (c i) => MvPolynomial.monomial (u p.1) (1 : ℤ)) _ kcap
      (countPowerTable_getD Δ c _ kcap) (k - 1) (by omega) (k - l) (by omega)]
  rw [hsum]
  apply truncated_newton_partial_numerator_coeff_bound _ Δ e k B hB _ L hL
  simpa only [Fintype.card_sigma, Fintype.card_fin] using hcB

/-- Output truncation cannot increase a coefficient magnitude, even when
Newton's alternating signs have made some coefficients negative. -/
theorem coeff_truncatePolynomial_abs_le (Δ e : σ →₀ ℕ) (p : MvPolynomial σ ℤ) :
    |MvPolynomial.coeff e (truncatePolynomial Δ p)| ≤ |MvPolynomial.coeff e p| := by
  classical
  rw [coeff_truncatePolynomial]
  split_ifs
  · exact le_rfl
  · simp only [abs_zero]
    exact abs_nonneg (MvPolynomial.coeff e p)

/-- Binary magnitude sizes for the actual numerator that `newtonTableStep`
divides. This also bounds the accumulator before its final truncation. -/
theorem countNewton_numerator_coeff_bits (c : ι → ℕ)
    (u : ι → σ →₀ ℕ) (Δ e : σ →₀ ℕ) (kcap k B : ℕ)
    (hk : 1 ≤ k) (hkk : k ≤ kcap) (hB : 1 ≤ B) (hcB : ∑ i, c i ≤ B) :
    let powers := countPowerTable Δ c (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) kcap
    let previous := newtonTable Δ powers (k - 1)
    (MvPolynomial.coeff e (truncatePolynomial Δ (∑ l ∈ Finset.Icc 1 k,
      (-1 : MvPolynomial σ ℤ) ^ (l - 1) * powers.getD l 0 *
        previous.getD (k - l) 0))).natAbs.size ≤ k.size + k * B.size := by
  classical
  dsimp only
  apply nat_size_le_of_le_mul_pow
  have h := countNewton_partial_numerator_coeff_bound c u Δ e kcap k B hk hkk hB hcB
    (Finset.Icc 1 k) (by rfl)
  dsimp only at h
  have h' := (coeff_truncatePolynomial_abs_le Δ e _).trans h
  simp only [Nat.card_Icc, Nat.add_sub_cancel] at h'
  rw [← Int.natCast_natAbs] at h'
  exact_mod_cast h'

end
end Optss
