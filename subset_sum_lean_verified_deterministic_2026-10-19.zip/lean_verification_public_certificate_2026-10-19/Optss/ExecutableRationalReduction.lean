import Optss.ExecutableLatticeReduction
import Optss.SharpLatticeDefect

/-!
# Executable lattice reduction from a rational input matrix

The common denominator and every cleared integer entry are computed directly.
The executable integer loop is then unscaled by that same positive denominator.
Exact full-lattice and sharp defect guarantees are transported to the actual
rational output. Arithmetic bit complexity is a separate obligation.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

def rationalInputDenominator (A : Matrix (Fin r) (Fin d) ℚ) : ℕ :=
  ∏ i, ∏ j, (A i j).den

theorem rationalInputDenominator_pos (A : Matrix (Fin r) (Fin d) ℚ) :
    0 < rationalInputDenominator A := by
  apply Finset.prod_pos
  intro i _
  exact Finset.prod_pos (fun j _ => (A i j).den_pos)

theorem rationalInputDenominator_dvd (A : Matrix (Fin r) (Fin d) ℚ) (i : Fin r) (j : Fin d) :
    (A i j).den ∣ rationalInputDenominator A :=
  (Finset.dvd_prod_of_mem (fun j => (A i j).den) (Finset.mem_univ j)).trans
    (Finset.dvd_prod_of_mem (fun i => ∏ j, (A i j).den) (Finset.mem_univ i))

def clearRationalInput (A : Matrix (Fin r) (Fin d) ℚ) : Matrix (Fin r) (Fin d) ℤ :=
  fun i j => ((rationalInputDenominator A / (A i j).den : ℕ):ℤ)*(A i j).num

theorem clearRationalInput_cast (A : Matrix (Fin r) (Fin d) ℚ) (i : Fin r) (j : Fin d) :
    (clearRationalInput A i j : ℚ) = (rationalInputDenominator A:ℚ)*A i j := by
  have hc : (A i j).den*(rationalInputDenominator A/(A i j).den) = rationalInputDenominator A :=
    Nat.mul_div_cancel' (rationalInputDenominator_dvd A i j)
  have hcQ : ((A i j).den:ℚ)*(rationalInputDenominator A/(A i j).den:ℕ) =
      rationalInputDenominator A := by exact_mod_cast hc
  have hden : ((A i j).den:ℚ) ≠ 0 := by exact_mod_cast (A i j).den_ne_zero
  unfold clearRationalInput
  rw [Int.cast_mul, Int.cast_natCast]
  conv_rhs => rw [← Rat.num_div_den (A i j)]
  field_simp
  rw [← hcQ]
  ring

theorem clearRationalInput_real (A : Matrix (Fin r) (Fin d) ℚ) (i : Fin r) (j : Fin d) :
    (clearRationalInput A i j : ℝ) = (rationalInputDenominator A:ℝ)*(A i j:ℝ) := by
  exact_mod_cast clearRationalInput_cast A i j

theorem clearRationalInput_independent (A : Matrix (Fin r) (Fin d) ℚ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) :
    LinearIndependent ℝ (fun i j => (clearRationalInput A i j:ℝ)) := by
  let u : ℝˣ := Units.mk0 (rationalInputDenominator A:ℝ)
    (by exact_mod_cast (rationalInputDenominator_pos A).ne')
  have he : (fun i j => (clearRationalInput A i j:ℝ)) =
      (fun _ : Fin r => u) • (fun i j => (A i j:ℝ)) := by
    funext i j
    exact clearRationalInput_real A i j
  rw [he]
  exact hA.units_smul (fun _ => u)

/-- The actual rational output data and number of performed swaps. -/
def executableRationalReduction (A : Matrix (Fin r) (Fin d) ℚ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) :
    Matrix (Fin r) (Fin d) ℚ × ℕ :=
  let out := executableIntegerReduction (clearRationalInput A) (clearRationalInput_independent A hA)
  (fun i j => (out.rows i j:ℚ)/(rationalInputDenominator A:ℚ), out.swapCount)

def unscaleIntegerRows (D : ℕ) : (Fin d → ℤ) →ₗ[ℤ] (Fin d → ℚ) where
  toFun x j := (x j:ℚ)/(D:ℚ)
  map_add' x y := by ext j; simp [add_div]
  map_smul' c x := by ext j; simp [mul_div_assoc]

theorem unscale_clearRationalInput (A : Matrix (Fin r) (Fin d) ℚ) (i : Fin r) :
    unscaleIntegerRows (rationalInputDenominator A) (clearRationalInput A i) = A i := by
  ext j
  change (clearRationalInput A i j:ℚ)/(rationalInputDenominator A:ℚ) = A i j
  rw [clearRationalInput_cast]
  have hD : (rationalInputDenominator A:ℚ) ≠ 0 := by
    exact_mod_cast (rationalInputDenominator_pos A).ne'
  exact mul_div_cancel_left₀ _ hD

/-- The computed rational output generates exactly the original rational
lattice over the integers, not a lattice of merely finite index. -/
theorem executableRationalReduction_same_lattice (A : Matrix (Fin r) (Fin d) ℚ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) :
    Submodule.span ℤ (Set.range (executableRationalReduction A hA).1) =
      Submodule.span ℤ (Set.range A) := by
  let out := executableIntegerReduction (clearRationalInput A) (clearRationalInput_independent A hA)
  have he := congrArg (Submodule.map (unscaleIntegerRows (rationalInputDenominator A))) out.sameLattice
  simp only [Submodule.map_span, ← Set.range_comp] at he
  have hinput : unscaleIntegerRows (rationalInputDenominator A) ∘ clearRationalInput A = A := by
    funext i
    exact unscale_clearRationalInput A i
  rw [hinput] at he
  exact he

/-- Package the actual rational output rows as a Euclidean basis. Only this
proof-side real vector-space packaging is noncomputable; output data above are
computed over integers and rationals. -/
noncomputable def executableRationalBasis (A : Matrix (Fin r) (Fin r) ℚ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) :
    Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)) :=
  let out := executableIntegerReduction (clearRationalInput A) (clearRationalInput_independent A hA)
  (basisOfEuclideanIntegerRows out.rows out.independent).map
    (LinearEquiv.smulOfNeZero ℝ (EuclideanSpace ℝ (Fin r))
      (rationalInputDenominator A:ℝ)⁻¹
      (inv_ne_zero (by exact_mod_cast (rationalInputDenominator_pos A).ne')))

theorem executableRationalBasis_apply (A : Matrix (Fin r) (Fin r) ℚ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (i : Fin r) :
    executableRationalBasis A hA i = rationalEuclideanRows (executableRationalReduction A hA).1 i := by
  let out := executableIntegerReduction (clearRationalInput A) (clearRationalInput_independent A hA)
  have he : executableRationalBasis A hA i =
      (rationalInputDenominator A:ℝ)⁻¹ • euclideanIntegerRows out.rows i := by
    simp only [executableRationalBasis, Basis.map_apply, basisOfEuclideanIntegerRows_apply]
    rfl
  rw [he]
  ext j
  simp only [PiLp.smul_apply, euclideanIntegerRows, rationalEuclideanRows,
    rationalEuclideanVector, executableRationalReduction]
  change (rationalInputDenominator A:ℝ)⁻¹*(out.rows i j:ℝ) =
    Rat.cast ((out.rows i j:ℚ)/(rationalInputDenominator A:ℚ))
  rw [Rat.cast_div, Rat.cast_intCast, Rat.cast_natCast]
  ring

theorem executableRationalReduction_sharp_defect (A : Matrix (Fin r) (Fin r) ℚ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) :
    euclideanOrthogonalityDefect (executableRationalBasis A hA) ≤ sharpLatticeDefectBound r := by
  let out := executableIntegerReduction (clearRationalInput A) (clearRationalInput_independent A hA)
  let b := basisOfEuclideanIntegerRows out.rows out.independent
  have hD : (rationalInputDenominator A:ℝ) ≠ 0 := by
    exact_mod_cast (rationalInputDenominator_pos A).ne'
  have hscale (i : Fin r) : executableRationalBasis A hA i =
      (rationalInputDenominator A:ℝ)⁻¹ • b i := by
    simp only [executableRationalBasis, Basis.map_apply]
    rfl
  rw [euclideanOrthogonalityDefect_uniform_scale b (executableRationalBasis A hA)
    _ (inv_ne_zero hD) hscale]
  exact out.sharp_defect_le _ b (basisOfEuclideanIntegerRows_apply _ _)

/-- The computed output is a basis of the complete input rational lattice and
satisfies exactly the numerical defect bound stated in Theorem 2.G. -/
theorem executableRationalReduction_spec (A : Matrix (Fin r) (Fin r) ℚ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) :
    Submodule.span ℤ (Set.range (executableRationalReduction A hA).1) =
      Submodule.span ℤ (Set.range A) ∧
    ∃ b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)),
      (∀ i, b i = rationalEuclideanRows (executableRationalReduction A hA).1 i) ∧
      euclideanOrthogonalityDefect b ≤ sharpLatticeDefectBound r :=
  ⟨executableRationalReduction_same_lattice A hA,
    executableRationalBasis A hA, executableRationalBasis_apply A hA,
    executableRationalReduction_sharp_defect A hA⟩

end Optss
