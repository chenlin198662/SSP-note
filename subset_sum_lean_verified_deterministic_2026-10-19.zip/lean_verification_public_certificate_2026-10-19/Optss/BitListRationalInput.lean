import Optss.BitListIntegerOperations
import Optss.ExecutableRationalReduction
import Optss.BitListRationalOrderRound

/-!
# Rational denominator clearing on Boolean lists

The common denominator is an actual list product. Each integer entry is
obtained by exact Boolean division and multiplication; unscaling uses the
already verified Boolean fraction normalizer. Work counts the scalar gates and
list traversals. Matrix storage and input/output representation costs are kept
separate.
-/

namespace Optss
open scoped BigOperators

/-- Shared recursive multiplication of an actual list of binary magnitudes. -/
def bitListProduct : List (List Bool) → List Bool
  | [] => [true]
  | x::xs => bitListMultiplication x (bitListProduct xs)

theorem bitListProduct_value (xs : List (List Bool)) :
    binaryDigitsValue (bitListProduct xs) = (xs.map binaryDigitsValue).prod := by
  induction xs with
  | nil => simp [bitListProduct, binaryDigitsValue]
  | cons x xs ih => simp only [bitListProduct, bitListMultiplication_correct, ih, List.map_cons, List.prod_cons]

theorem bitListProduct_length (xs : List (List Bool)) (L : ℕ)
    (h : ∀ x ∈ xs, x.length ≤ L) : (bitListProduct xs).length ≤ xs.length*L+1 := by
  induction xs with
  | nil => simp [bitListProduct]
  | cons x xs ih =>
    have hx := h x (List.mem_cons_self)
    have ht := ih (fun y hy => h y (List.mem_cons_of_mem _ hy))
    exact (bitListMultiplication_length_le x (bitListProduct xs)).trans (by simp only [List.length_cons]; nlinarith)

def bitListProductCost : List (List Bool) → ℕ
  | [] => 1
  | x::xs => bitListProductCost xs+bitListProductWork x (bitListProduct xs)+1

theorem bitListProductCost_bound (xs : List (List Bool)) (L : ℕ)
    (h : ∀ x ∈ xs, x.length ≤ L) :
    bitListProductCost xs ≤ 41*xs.length*((xs.length+1)*(L+1)+1)^2+1 := by
  induction xs with
  | nil => simp [bitListProductCost]
  | cons x xs ih =>
    have hx := h x (List.mem_cons_self)
    have ht : ∀ y ∈ xs, y.length ≤ L := fun y hy => h y (List.mem_cons_of_mem _ hy)
    have hi := ih ht
    have hp := bitListProduct_length xs L ht
    let M := ((x::xs).length+1)*(L+1)
    have hxM : x.length ≤ M := by dsimp [M]; nlinarith
    have hpM : (bitListProduct xs).length ≤ M := by dsimp [M]; nlinarith
    have hm := bitListMultiplication_uniform_cost x (bitListProduct xs) M hxM hpM
    have hM : ((xs.length+1)*(L+1)+1)^2 ≤ (M+1)^2 := by
      apply Nat.pow_le_pow_left
      dsimp [M]
      nlinarith
    have hi' : bitListProductCost xs ≤ 41*xs.length*(M+1)^2+1 :=
      hi.trans (Nat.add_le_add_right (Nat.mul_le_mul_left _ hM) 1)
    have hm' : bitListProductWork x (bitListProduct xs)+1 ≤ 41*(M+1)^2 := by
      unfold bitListProductWork
      nlinarith [show 1 ≤ (M+1)^2 by nlinarith]
    change bitListProductCost xs+bitListProductWork x (bitListProduct xs)+1 ≤ _
    calc
      _ ≤ 41*xs.length*(M+1)^2+1+41*(M+1)^2 := by omega
      _ = _ := by change _ = 41*(xs.length+1)*(M+1)^2+1; ring

/-- Division of the common denominator followed by the signed numerator
product. The original sign is retained, including signed zero. -/
def bitListClearFraction (D : List Bool) (q : BitListFraction) : BitListInteger :=
  let scale := (bitListDivision D q.denominator).quotient
  ⟨q.negative, bitListMultiplication q.numerator scale⟩

theorem bitListClearFraction_value (D : List Bool) (q : BitListFraction)
    (hq : 0 < binaryDigitsValue q.denominator) :
    (bitListClearFraction D q).value =
      (binaryDigitsValue D/binaryDigitsValue q.denominator:ℕ)*
        signedBitsValue q.negative q.numerator := by
  change signedBitsValue q.negative (bitListMultiplication q.numerator _) = _
  rw [signedBitsValue_mul_right, (bitListDivision_correct D q.denominator hq).1]
  ring

theorem bitListClearFraction_length (D : List Bool) (q : BitListFraction) :
    (bitListClearFraction D q).digits.length ≤ q.numerator.length+D.length :=
  (bitListMultiplication_length_le _ _).trans
    (Nat.add_le_add_left (bitListDivision_quotient_length_le _ _) _)

def bitListClearFractionCost (D : List Bool) (q : BitListFraction) : ℕ :=
  bitListDivisionBitWork D q.denominator+
    bitListProductWork q.numerator (bitListDivision D q.denominator).quotient+1

theorem bitListClearFractionCost_bound (D : List Bool) (q : BitListFraction)
    (hq : 0 < binaryDigitsValue q.denominator) (L : ℕ)
    (hD : D.length ≤ L) (hn : q.numerator.length ≤ L) (hd : q.denominator.length ≤ L) :
    bitListClearFractionCost D q ≤ 64*(L+1)^2 := by
  have hdiv := bitListDivisionBitWork_bound D q.denominator hq
  have hl := (bitListDivision_quotient_length_le D q.denominator).trans hD
  have hm := bitListMultiplication_uniform_cost q.numerator
    (bitListDivision D q.denominator).quotient L hn hl
  have hdiv' : bitListDivisionBitWork D q.denominator ≤ 16*(L+1)^2 := by
    apply hdiv.trans
    calc
      _ ≤ 16*(L+1)*(L+1) := Nat.mul_le_mul
        (Nat.mul_le_mul_left 16 (Nat.add_le_add_right hD 1)) (Nat.add_le_add_right hd 1)
      _ = _ := by ring
  unfold bitListClearFractionCost bitListProductWork
  nlinarith [show 1 ≤ (L+1)^2 by nlinarith]

abbrev BitRationalMatrixData (r d : ℕ) := Vector (Vector BitListFraction d) r

def bitRationalMatrixEntries {r d : ℕ} (A : BitRationalMatrixData r d) : List BitListFraction :=
  (List.ofFn fun i => List.ofFn fun j => (A.get i).get j).flatten

def bitRationalInputDenominator {r d : ℕ} (A : BitRationalMatrixData r d) : List Bool :=
  bitListProduct ((bitRationalMatrixEntries A).map BitListFraction.denominator)

def bitRationalMatrixRepresentation {r d : ℕ} (A : Matrix (Fin r) (Fin d) ℚ) :
    BitRationalMatrixData r d :=
  Vector.ofFn fun i => Vector.ofFn fun j => rationalBitRepresentation (A i j)

private theorem inputBits_get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

theorem bitRationalMatrixEntries_length {r d : ℕ} (A : BitRationalMatrixData r d) :
    (bitRationalMatrixEntries A).length = r*d := by
  simp [bitRationalMatrixEntries, Function.comp_def]

theorem bitRationalInputDenominator_value {r d : ℕ} (A : Matrix (Fin r) (Fin d) ℚ) :
    binaryDigitsValue (bitRationalInputDenominator (bitRationalMatrixRepresentation A)) =
      rationalInputDenominator A := by
  simp [bitRationalInputDenominator, bitListProduct_value, bitRationalMatrixEntries,
    bitRationalMatrixRepresentation, List.map_flatten, List.map_map, Function.comp_def,
    List.map_ofFn, inputBits_get_ofFn, rationalBitRepresentation,
    binaryDigitsValue_bits, List.prod_flatten, List.prod_ofFn, rationalInputDenominator]

/-- The product is computed once and shared across every cleared entry. -/
def bitListClearRationalInput {r d : ℕ} (A : BitRationalMatrixData r d) :
    List Bool × BitIntegerMatrixData r d :=
  let D := bitRationalInputDenominator A
  (D, Vector.ofFn fun i => Vector.ofFn fun j => bitListClearFraction D ((A.get i).get j))

theorem bitListClearRationalInput_value {r d : ℕ} (A : Matrix (Fin r) (Fin d) ℚ) :
    bitIntegerMatrixValue (bitListClearRationalInput (bitRationalMatrixRepresentation A)).2 =
      clearRationalInput A := by
  funext i j
  simp only [bitIntegerMatrixValue, bitListClearRationalInput, inputBits_get_ofFn,
    bitRationalMatrixRepresentation]
  rw [bitListClearFraction_value _ _ (by
    simp only [rationalBitRepresentation, binaryDigitsValue_bits]
    exact (A i j).den_pos), rationalBitRepresentation_signed]
  change (binaryDigitsValue (bitRationalInputDenominator (bitRationalMatrixRepresentation A)) /
    binaryDigitsValue (rationalBitRepresentation (A i j)).denominator : ℕ) * (A i j).num = _
  rw [bitRationalInputDenominator_value]
  simp only [rationalBitRepresentation, binaryDigitsValue_bits, clearRationalInput]

/-- Unscale a stored signed integer by the shared denominator, normalizing
through the verified Boolean gcd and division routines. -/
def bitListUnscaleInteger (D : List Bool) (z : BitListInteger) : BitListFraction :=
  bitListNormalizeFraction z.negative z.digits D

theorem bitListUnscaleInteger_value (D : List Bool) (z : BitListInteger)
    (hD : 0 < binaryDigitsValue D) :
    bitListFractionValue (bitListUnscaleInteger D z) = (z.value:ℚ)/(binaryDigitsValue D:ℚ) :=
  bitListNormalizeFraction_correct _ _ _ hD

theorem bitRationalMatrixEntries_forall {r d : ℕ} (A : BitRationalMatrixData r d)
    (P : BitListFraction → Prop) (h : ∀ i j, P ((A.get i).get j)) :
    ∀ q ∈ bitRationalMatrixEntries A, P q := by
  intro q hq
  obtain ⟨row, hrow, hq⟩ := List.mem_flatten.mp hq
  obtain ⟨i, rfl⟩ := List.mem_ofFn.mp hrow
  obtain ⟨j, rfl⟩ := List.mem_ofFn.mp hq
  exact h i j

theorem bitRationalInputDenominator_length {r d : ℕ} (A : BitRationalMatrixData r d)
    (L : ℕ) (h : ∀ i j, ((A.get i).get j).denominator.length ≤ L) :
    (bitRationalInputDenominator A).length ≤ r*d*L+1 := by
  have ht := bitRationalMatrixEntries_forall A (fun q => q.denominator.length ≤ L) h
  have hb := bitListProduct_length ((bitRationalMatrixEntries A).map BitListFraction.denominator) L
    (by intro x hx; obtain ⟨q,hq,rfl⟩ := List.mem_map.mp hx; exact ht q hq)
  simpa only [List.length_map, bitRationalMatrixEntries_length] using hb

def bitListClearRationalInputCost {r d : ℕ} (A : BitRationalMatrixData r d) : ℕ :=
  bitListProductCost ((bitRationalMatrixEntries A).map BitListFraction.denominator)+
    ∑ i : Fin r, ∑ j : Fin d,
      bitListClearFractionCost (bitRationalInputDenominator A) ((A.get i).get j)

/-- Complete scalar gate/list work for shared denominator construction and
all cleared entries, polynomial in the original encoded entry lengths. -/
theorem bitListClearRationalInputCost_bound {r d : ℕ} (A : BitRationalMatrixData r d)
    (L : ℕ)
    (h : ∀ i j, ((A.get i).get j).numerator.length ≤ L ∧
      ((A.get i).get j).denominator.length ≤ L)
    (hp : ∀ i j, 0 < binaryDigitsValue ((A.get i).get j).denominator) :
    bitListClearRationalInputCost A ≤ 105*(r*d)*((r*d+1)*(L+1)+1)^2+1 := by
  let M := (r*d+1)*(L+1)
  have hLM : L ≤ M := by
    calc
      L ≤ L+1 := by omega
      _ = 1*(L+1) := by omega
      _ ≤ M := Nat.mul_le_mul_right _ (by omega)
  have hD : (bitRationalInputDenominator A).length ≤ M :=
    (bitRationalInputDenominator_length A L (fun i j => (h i j).2)).trans (by dsimp [M]; nlinarith)
  have ht := bitRationalMatrixEntries_forall A (fun q => q.denominator.length ≤ L)
    (fun i j => (h i j).2)
  have hprod := bitListProductCost_bound ((bitRationalMatrixEntries A).map BitListFraction.denominator) L
    (by intro x hx; obtain ⟨q,hq,rfl⟩ := List.mem_map.mp hx; exact ht q hq)
  simp only [List.length_map, bitRationalMatrixEntries_length] at hprod
  have hc : (∑ i : Fin r, ∑ j : Fin d,
      bitListClearFractionCost (bitRationalInputDenominator A) ((A.get i).get j)) ≤
      r*d*(64*(M+1)^2) := by
    calc
      _ ≤ ∑ _i : Fin r, ∑ _j : Fin d, 64*(M+1)^2 := by
        apply Finset.sum_le_sum
        intro i _
        apply Finset.sum_le_sum
        intro j _
        exact bitListClearFractionCost_bound _ _ (hp i j) M hD
          ((h i j).1.trans hLM) ((h i j).2.trans hLM)
      _ = _ := by simp; ring
  unfold bitListClearRationalInputCost
  change _ ≤ 105*(r*d)*(M+1)^2+1
  change _ ≤ 41*(r*d)*(M+1)^2+1 at hprod
  nlinarith

/-- The clearing data represent exactly the previous rational input routine,
with all integer cell widths polynomial in the original encoded width. -/
theorem bitListClearRationalInput_lengths {r d : ℕ} (A : BitRationalMatrixData r d)
    (L : ℕ) (h : ∀ i j, ((A.get i).get j).numerator.length ≤ L ∧
      ((A.get i).get j).denominator.length ≤ L) (i : Fin r) (j : Fin d) :
    (((bitListClearRationalInput A).2.get i).get j).digits.length ≤ (r*d+1)*L+1 := by
  simp only [bitListClearRationalInput, inputBits_get_ofFn]
  have hD := bitRationalInputDenominator_length A L (fun i j => (h i j).2)
  have hc := bitListClearFraction_length (bitRationalInputDenominator A) ((A.get i).get j)
  have hn := (h i j).1
  nlinarith

/-- Cost of one output unscaling, including actual normalization. -/
theorem bitListUnscaleInteger_cost (D : List Bool) (z : BitListInteger)
    (hD : 0 < binaryDigitsValue D) (L : ℕ)
    (hz : z.digits.length ≤ L) (hDl : D.length ≤ L) :
    bitListNormalizeFractionCost z.digits D ≤ 128*(L+1)^3 :=
  bitListNormalizeFractionCost_bound z.digits D hD L hz hDl

end Optss
