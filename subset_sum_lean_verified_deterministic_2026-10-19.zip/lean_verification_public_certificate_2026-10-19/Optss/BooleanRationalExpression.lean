import Optss.RationalMatrixBounds
import Optss.EncodedScalarBounds
import Optss.ListStoredArrayWork

/-!
# Boolean evaluation of finite rational arithmetic expressions

This evaluator keeps every scalar as a normalized Boolean-list fraction and
uses the verified Boolean arithmetic directly. Every expression input and
negation explicitly copies its payload. The work model counts these copies,
scalar Boolean gates/list visits, and expression-node visits. Input address
lookup, expression construction and storage of the expression tree remain
separate; matrix specializations account for their fixed-rank structure.
-/
namespace Optss

inductive RationalBinaryOp where
  | add | sub | mul | div
  deriving DecidableEq

namespace RationalBinaryOp

def rational : RationalBinaryOp → ℚ → ℚ → ℚ
  | .add => (·+·) | .sub => (·-·) | .mul => (·*·) | .div => (·/·)

def encoded : RationalBinaryOp → BitListFraction → BitListFraction → BitListFraction
  | .add => bitListFractionAdd | .sub => bitListFractionSub
  | .mul => bitListFractionMul | .div => bitListFractionDiv

def work : RationalBinaryOp → BitListFraction → BitListFraction → ℕ
  | .add => bitListFractionAddCost | .sub => bitListFractionSubCost
  | .mul => bitListFractionMulCost | .div => bitListFractionDivCost

theorem wellFormed (op : RationalBinaryOp) (p q : BitListFraction)
    (hp : p.WellFormed) (hq : q.WellFormed) : (op.encoded p q).WellFormed := by
  cases op
  · exact bitListFractionAdd_wellFormed p q hp.2.2.1 hq.2.2.1
  · exact bitListFractionSub_wellFormed p q hp.2.2.1 hq.2.2.1
  · exact bitListFractionMul_wellFormed p q hp.2.2.1 hq.2.2.1
  · exact bitListFractionDiv_wellFormed p q hp.2.2.1

theorem value (op : RationalBinaryOp) (p q : BitListFraction)
    (hp : p.WellFormed) (hq : q.WellFormed) :
    bitListFractionValue (op.encoded p q)=op.rational (bitListFractionValue p) (bitListFractionValue q) := by
  cases op
  · exact bitListFractionAdd_correct p q hp.2.2.1 hq.2.2.1
  · exact bitListFractionSub_correct p q hp.2.2.1 hq.2.2.1
  · exact bitListFractionMul_correct p q hp.2.2.1 hq.2.2.1
  · exact bitListFractionDiv_correct p q hp.2.2.1 hq.2.2.1

theorem size (op : RationalBinaryOp) {p q : ℚ} {B C : ℕ}
    (hp : RationalSizeBound p B) (hq : RationalSizeBound q C) :
    RationalSizeBound (op.rational p q) (2*B*C) := by
  cases op
  · exact hp.add hq
  · exact hp.sub hq
  · exact (hp.mul hq).mono (by nlinarith)
  · exact (hp.div hq).mono (by nlinarith)

theorem work_le (op : RationalBinaryOp) (p q : BitListFraction)
    (hp : p.WellFormed) (hq : q.WellFormed) (L : ℕ)
    (hpbit : RationalBitBound (bitListFractionValue p) L)
    (hqbit : RationalBitBound (bitListFractionValue q) L) :
    op.work p q≤65536*(L+1)^3 := by
  have h := encodedFraction_scalar_bounds p q hp hq L hpbit hqbit
  cases op
  · exact h.1
  · exact h.2.1
  · exact h.2.2.1
  · exact h.2.2.2.1
end RationalBinaryOp

inductive RationalExpression (ι : Type*) where
  | input : ι → RationalExpression ι
  | zero : RationalExpression ι
  | one : RationalExpression ι
  | neg : RationalExpression ι → RationalExpression ι
  | binary : RationalBinaryOp → RationalExpression ι → RationalExpression ι → RationalExpression ι

namespace RationalExpression
variable {ι : Type*}

def nodes : RationalExpression ι → ℕ
  | .input _ | .zero | .one => 1
  | .neg a => a.nodes+1
  | .binary _ a b => a.nodes+b.nodes+1

theorem nodes_pos (e : RationalExpression ι) : 0<e.nodes := by cases e <;> simp [nodes]

def rational (x : ι → ℚ) : RationalExpression ι → ℚ
  | .input i => x i | .zero => 0 | .one => 1
  | .neg a => -a.rational x
  | .binary op a b => op.rational (a.rational x) (b.rational x)

def encoded (x : ι → BitListFraction) : RationalExpression ι → BitListFraction
  | .input i => listCopyFraction (x i)
  | .zero => bitListFractionZero
  | .one => ⟨false,[true],[true]⟩
  | .neg a => bitListFractionNeg (listCopyFraction (a.encoded x))
  | .binary op a b =>
      let p := a.encoded x
      let q := b.encoded x
      op.encoded p q

def work (x : ι → BitListFraction) : RationalExpression ι → ℕ
  | .input i => listCopyFractionWork (x i)+1
  | .zero => 3
  | .one => 4
  | .neg a => a.work x+listCopyFractionWork (a.encoded x)+2
  | .binary op a b =>
      let p := a.encoded x
      let q := b.encoded x
      a.work x+b.work x+op.work p q+1

theorem wellFormed (x : ι → BitListFraction) (hx : ∀ i,(x i).WellFormed)
    (e : RationalExpression ι) : (e.encoded x).WellFormed := by
  induction e with
  | input i => simpa [encoded] using hx i
  | zero => exact bitListFractionZero_wellFormed
  | one =>
    change (⟨false,[true],[true]⟩ : BitListFraction).WellFormed
    simpa [rationalBitRepresentation] using rationalBitRepresentation_wellFormed 1
  | neg a ih => simpa only [encoded,listCopyFraction_eq] using bitListFractionNeg_wellFormed _ ih
  | binary op a b iha ihb => exact op.wellFormed _ _ iha ihb

theorem value (x : ι → BitListFraction) (hx : ∀ i,(x i).WellFormed)
    (e : RationalExpression ι) :
    bitListFractionValue (e.encoded x)=e.rational (fun i => bitListFractionValue (x i)) := by
  induction e with
  | input i => simp [encoded,rational]
  | zero => exact bitListFractionZero_value
  | one => simp [encoded,rational,bitListFractionValue,signedBitsValue,binaryDigitsValue]
  | neg a ih => simp only [encoded,listCopyFraction_eq,bitListFractionNeg_correct,rational,ih]
  | binary op a b iha ihb =>
    simp only [encoded,rational,op.value _ _ (a.wellFormed x hx) (b.wellFormed x hx),iha,ihb]

theorem size (x : ι → ℚ) (B : ℕ) (hB : 2≤B)
    (hx : ∀ i,RationalSizeBound (x i) B) (e : RationalExpression ι) :
    RationalSizeBound (e.rational x) (B^e.nodes) := by
  induction e with
  | input i => simpa [rational,nodes] using hx i
  | zero => exact RationalSizeBound.zero.mono (by simpa [nodes] using (show 1≤B by omega))
  | one => exact RationalSizeBound.one.mono (by simpa [nodes] using (show 1≤B by omega))
  | neg a ih =>
    exact ih.neg.mono (Nat.pow_le_pow_right (by omega) (by simp [nodes]))
  | binary op a b iha ihb =>
    apply (op.size iha ihb).mono
    calc
      2*B^a.nodes*B^b.nodes = 2*B^(a.nodes+b.nodes) := by ring
      _ ≤ B*B^(a.nodes+b.nodes) := Nat.mul_le_mul_right _ hB
      _ = B^(.binary op a b : RationalExpression ι).nodes := by simp [nodes,pow_succ']

theorem bits (x : ι → ℚ) (L : ℕ) (hx : ∀ i,RationalBitBound (x i) L)
    (e : RationalExpression ι) : RationalBitBound (e.rational x) (e.nodes*(L+2)) := by
  have hheight (i : ι) : RationalSizeBound (x i) (2^(L+1)) :=
    (hx i).height.mono (Nat.pow_le_pow_right (by decide) (by omega))
  have ht := (e.size x (2^(L+1)) (by
    simpa using Nat.pow_le_pow_right (by decide : 1≤2) (by omega : 1≤L+1)) hheight).bits e.nodes_pos
  simpa only [Nat.size_pow,show L+1+1=L+2 by omega] using ht

/-- One conservative charge includes each scalar call or payload copy plus
its node administration. It is cubic in the actual input field width. -/
def charge (n L : ℕ) : ℕ := 131072*(n*(L+2)+1)^3

private theorem charge_dominates (n L : ℕ) :
    65536*(n*(L+2)+1)^3+8*(n*(L+2)+1)≤charge n L := by
  have hcube : n*(L+2)+1≤(n*(L+2)+1)^3 := by
    simpa using Nat.pow_le_pow_right (by omega : 1≤n*(L+2)+1) (by omega : 1≤3)
  unfold charge
  omega

/-- Every intermediate width is derived from the expression and input bits;
there is no assumed bound on evaluation intermediates. -/
theorem work_le (x : ι → BitListFraction) (hx : ∀ i,(x i).WellFormed)
    (L : ℕ) (hbits : ∀ i,RationalBitBound (bitListFractionValue (x i)) L)
    (e : RationalExpression ι) (n : ℕ) (hn : e.nodes≤n) :
    e.work x≤e.nodes*charge n L := by
  have nodebits (a : RationalExpression ι) (ha : a.nodes≤n) :
      RationalBitBound (bitListFractionValue (a.encoded x)) (n*(L+2)) := by
    rw [a.value x hx]
    have hb := a.bits _ L hbits
    exact ⟨hb.1.trans (Nat.mul_le_mul_right _ ha),hb.2.trans (Nat.mul_le_mul_right _ ha)⟩
  have hdom := charge_dominates n L
  induction e with
  | input i =>
    have hi := ((x i).value_bit_bound_iff (hx i) L).mp (hbits i)
    have hn' : 1≤n := hn
    have hL : L≤n*(L+2) := by nlinarith
    simp only [work,nodes,one_mul,listCopyFractionWork_eq,fractionPayload]
    omega
  | zero => simp only [work,nodes,one_mul]; omega
  | one => simp only [work,nodes,one_mul]; omega
  | neg a ih =>
    have ha : a.nodes≤n := by simp only [nodes] at hn; omega
    have hw := ih ha
    have hb := ((a.encoded x).value_bit_bound_iff (a.wellFormed x hx) _).mp (nodebits a ha)
    simp only [work,nodes,listCopyFractionWork_eq,fractionPayload]
    have hp : 2*((a.encoded x).numerator.length+(a.encoded x).denominator.length)+5≤charge n L := by omega
    calc
      _ ≤ a.nodes*charge n L+charge n L := by omega
      _ = _ := by ring
  | binary op a b iha ihb =>
    have ha : a.nodes≤n := by simp only [nodes] at hn; omega
    have hb : b.nodes≤n := by simp only [nodes] at hn; omega
    have hwa := iha ha
    have hwb := ihb hb
    have hop := op.work_le _ _ (a.wellFormed x hx) (b.wellFormed x hx) _ (nodebits a ha) (nodebits b hb)
    have hone : op.work (a.encoded x) (b.encoded x)+1≤charge n L := by omega
    simp only [work,nodes]
    calc
      _ ≤ a.nodes*charge n L+b.nodes*charge n L+charge n L := by omega
      _ = _ := by ring
end RationalExpression
end Optss
