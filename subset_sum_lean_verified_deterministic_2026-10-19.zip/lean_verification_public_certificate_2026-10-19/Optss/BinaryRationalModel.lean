import Optss.BinaryRationalCost
import Optss.CachedReductionCost

/-!
# Binary arithmetic implementation of the cached evaluator interface

The cached computation can now execute using the proved shift/add, binary
long-division and gcd rational operations. Its actual matrix/swap outputs are
unchanged. The recorded work uses their operand-width charges; integer updates,
rounding, comparisons, containers and input fuel still need their refinements.
-/

namespace Optss
variable {r d : ℕ}

def binaryRationalArithmetic : RationalArithmetic where
  add := binaryRatAdd
  sub := binaryRatSub
  mul := binaryRatMul
  div := binaryRatDiv
  add_value := binaryRatAdd_correct
  sub_value := binaryRatSub_correct
  mul_value := binaryRatMul_correct
  div_value := binaryRatDiv_correct

theorem binaryRationalArithmetic_cubic (p q : ℚ) (L : ℕ)
    (hp : RationalBitBound p L) (hq : RationalBitBound q L) :
    (binaryRationalArithmetic.add p q).2 ≤ 2048*(L+1)^3 ∧
    (binaryRationalArithmetic.sub p q).2 ≤ 2048*(L+1)^3 ∧
    (binaryRationalArithmetic.mul p q).2 ≤ 2048*(L+1)^3 ∧
    (binaryRationalArithmetic.div p q).2 ≤ 2048*(L+1)^3 :=
  binaryRatOperations_cubic p q L hp hq

theorem binaryMeteredCachedData_value (A : Matrix (Fin r) (Fin d) ℤ) :
    ((meteredCachedData binaryRationalArithmetic A).rows,
      (meteredCachedData binaryRationalArithmetic A).swaps) = cachedReductionData A :=
  meteredCachedData_value binaryRationalArithmetic A

/-- Actual binary rational execution has the complete integer-reduction
specification; no arithmetic oracle is a premise of this theorem. -/
theorem binaryMeteredCachedData_spec (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) :
    IntegerReductionSpecification A
      (integerMatrixDataRows (meteredCachedData binaryRationalArithmetic A).rows)
      (meteredCachedData binaryRationalArithmetic A).swaps := by
  have he := binaryMeteredCachedData_value A
  have h := cachedIntegerReduction_spec A hA
  rw [← he] at h
  exact h

end Optss
