import Optss.BooleanMatrixPolynomials
import Optss.ListStoredAccessBounds

/-!
# Rational matrix arithmetic with concrete nested-list reads and outputs

Every input expression leaf executes the existing Boolean addressed list
reader, which copies the selected row and cell. Returned inverse rows and
cells are explicitly materialized as list arrays. The work below adds all
actual addressed reads and output-list enumeration/allocation to the Boolean
arithmetic/expression trace. Building the finite expression itself is handled
separately from executing it.
-/
namespace Optss
open scoped BigOperators
namespace RationalExpression
variable {ι : Type*}

/-- Actual external lookup callbacks invoked by the expression interpreter. -/
def lookupWork (w : ι → ℕ) : RationalExpression ι → ℕ
  | .input i => w i
  | .zero | .one => 0
  | .neg a => a.lookupWork w
  | .binary _ a b => a.lookupWork w+b.lookupWork w

theorem lookupWork_le (w : ι → ℕ) (W : ℕ) (hw : ∀ i,w i≤W)
    (e : RationalExpression ι) : e.lookupWork w≤e.nodes*W := by
  induction e with
  | input i => simpa [lookupWork,nodes] using hw i
  | zero => simp [lookupWork,nodes]
  | one => simp [lookupWork,nodes]
  | neg a ih => simp only [lookupWork,nodes]; nlinarith
  | binary op a b iha ihb => simp only [lookupWork,nodes]; nlinarith
end RationalExpression
variable {r : ℕ}

/-- Proof-only matrix view of the stored lists. -/
def listFractionMatrix (A : ListBitRationalMatrixData r r) : Matrix (Fin r) (Fin r) BitListFraction :=
  fun i j => ((listMatrixVector A).get i).get j

def listStoredMatrixInputs (A : ListBitRationalMatrixData r r) (p : Fin r × Fin r) : BitListFraction :=
  listMatrixRead listCopyFraction A p.1 p.2

def listStoredMatrixLookupWork (A : ListBitRationalMatrixData r r) (p : Fin r × Fin r) : ℕ :=
  listMatrixReadWork listCopyFraction listCopyFractionWork A p.1 p.2

theorem listStoredMatrixInputs_eq (A : ListBitRationalMatrixData r r) :
    listStoredMatrixInputs A=(fun p => listFractionMatrix A p.1 p.2) := by
  funext p
  exact listMatrixRead_eq listCopyFraction listCopyFraction_eq A p.1 p.2

def listStoredMatrixDeterminant (A : ListBitRationalMatrixData r r) : BitListFraction :=
  (rationalMatrixDeterminantExpression r).encoded (listStoredMatrixInputs A)

def listStoredMatrixDeterminantWork (A : ListBitRationalMatrixData r r) : ℕ :=
  (rationalMatrixDeterminantExpression r).work (listStoredMatrixInputs A)+
    (rationalMatrixDeterminantExpression r).lookupWork (listStoredMatrixLookupWork A)

def listStoredMatrixInverse (A : ListBitRationalMatrixData r r) : ListBitRationalMatrixData r r :=
  BooleanListArray.ofFn fun i => BooleanListArray.ofFn fun j =>
    (rationalMatrixInverseExpression r i j).encoded (listStoredMatrixInputs A)

/-- Index enumeration and output cons/record constructors are charged, in
addition to the exact arithmetic and leaf-lookup traces. -/
def listStoredMatrixInverseWork (A : ListBitRationalMatrixData r r) : ℕ :=
  listIndexEnumerationWork r+r*listIndexEnumerationWork r+2*r*r+2*r+1+
    ∑ i : Fin r,∑ j : Fin r,
      ((rationalMatrixInverseExpression r i j).work (listStoredMatrixInputs A)+
       (rationalMatrixInverseExpression r i j).lookupWork (listStoredMatrixLookupWork A))

theorem listStoredMatrixDeterminant_eq (A : ListBitRationalMatrixData r r) :
    listStoredMatrixDeterminant A=booleanMatrixDeterminant (listFractionMatrix A) := by
  rw [listStoredMatrixDeterminant,listStoredMatrixInputs_eq]
  rfl

theorem listStoredMatrixInverse_eq (A : ListBitRationalMatrixData r r) :
    listMatrixVector (listStoredMatrixInverse A)=booleanMatrixInverse (listFractionMatrix A) := by
  simp only [listStoredMatrixInverse,listMatrixVector_ofFn,BooleanListArray.ofFn_toVector,
    booleanMatrixInverse,listStoredMatrixInputs_eq]

theorem listStoredMatrixLookupWork_le (A : ListBitRationalMatrixData r r) (L : ℕ)
    (hbits : ∀ i j,(listFractionMatrix A i j).numerator.length≤L ∧
      (listFractionMatrix A i j).denominator.length≤L) (p : Fin r × Fin r) :
    listStoredMatrixLookupWork A p≤listStorageFactor r r*(2*L+1) := by
  apply listFractionReadWork_le A p.1 p.2 (2*L)
  intro i j
  have hi := hbits i j
  change (listFractionMatrix A i j).numerator.length+(listFractionMatrix A i j).denominator.length≤2*L
  omega

theorem listStoredMatrixDeterminantWork_bound (A : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(listFractionMatrix A i j).WellFormed) (L : ℕ)
    (hbits : ∀ i j,(listFractionMatrix A i j).numerator.length≤L ∧
      (listFractionMatrix A i j).denominator.length≤L) :
    listStoredMatrixDeterminantWork A≤RationalExpression.determinantNodes r 1*
      (RationalExpression.charge (RationalExpression.determinantNodes r 1) L+
        listStorageFactor r r*(2*L+1)) := by
  have hs := booleanMatrixDeterminantWork_bound (listFractionMatrix A) hA L hbits
  have hl := (rationalMatrixDeterminantExpression r).lookupWork_le
    (listStoredMatrixLookupWork A) (listStorageFactor r r*(2*L+1)) (listStoredMatrixLookupWork_le A L hbits)
  have hn := rationalMatrixDeterminantExpression_nodes r
  have hl' := hl.trans (Nat.mul_le_mul_right _ hn)
  unfold listStoredMatrixDeterminantWork
  rw [listStoredMatrixInputs_eq]
  change booleanMatrixDeterminantWork (listFractionMatrix A)+_≤_
  calc
    _ ≤ RationalExpression.determinantNodes r 1*RationalExpression.charge
        (RationalExpression.determinantNodes r 1) L+
        RationalExpression.determinantNodes r 1*(listStorageFactor r r*(2*L+1)) := Nat.add_le_add hs hl'
    _ = _ := by ring

theorem listStoredMatrixInverseWork_bound (A : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(listFractionMatrix A i j).WellFormed) (L : ℕ)
    (hbits : ∀ i j,(listFractionMatrix A i j).numerator.length≤L ∧
      (listFractionMatrix A i j).denominator.length≤L) :
    listStoredMatrixInverseWork A≤
      64*(r+1)^4+2*r*r+2*r+1+
      r*r*(2*RationalExpression.determinantNodes r 1+1)*
        (RationalExpression.charge (2*RationalExpression.determinantNodes r 1+1) L+
          listStorageFactor r r*(2*L+1)) := by
  have henum := listIndexEnumerationWork_le r
  have he : listIndexEnumerationWork r+r*listIndexEnumerationWork r≤64*(r+1)^4 := by
    calc
      _ ≤ (r+1)*(32*(r+1)^3) := by nlinarith
      _ ≤ _ := by nlinarith [show (r+1)*(r+1)^3=(r+1)^4 by ring]
  unfold listStoredMatrixInverseWork
  apply Nat.add_le_add (by omega)
  calc
    _ ≤ ∑ _i : Fin r,∑ _j : Fin r,
        (2*RationalExpression.determinantNodes r 1+1)*
          (RationalExpression.charge (2*RationalExpression.determinantNodes r 1+1) L+
            listStorageFactor r r*(2*L+1)) := by
      apply Finset.sum_le_sum
      intro i _
      apply Finset.sum_le_sum
      intro j _
      have hn := rationalMatrixInverseExpression_nodes r i j
      have hwf : ∀ p,(listStoredMatrixInputs A p).WellFormed := by
        rw [listStoredMatrixInputs_eq]
        exact fun p => hA p.1 p.2
      have hbit : ∀ p,RationalBitBound (bitListFractionValue (listStoredMatrixInputs A p)) L := by
        rw [listStoredMatrixInputs_eq]
        exact fun p => ((listFractionMatrix A p.1 p.2).value_bit_bound_iff (hA _ _) L).mpr (hbits _ _)
      have hs := ((rationalMatrixInverseExpression r i j).work_le _ hwf L hbit _ hn).trans
        (Nat.mul_le_mul_right _ hn)
      have hl := ((rationalMatrixInverseExpression r i j).lookupWork_le _ _
        (listStoredMatrixLookupWork_le A L hbits)).trans (Nat.mul_le_mul_right _ hn)
      calc
        _ ≤ (2*RationalExpression.determinantNodes r 1+1)*
            RationalExpression.charge (2*RationalExpression.determinantNodes r 1+1) L+
            (2*RationalExpression.determinantNodes r 1+1)*(listStorageFactor r r*(2*L+1)) :=
          Nat.add_le_add hs hl
        _ = _ := by ring
    _ = _ := by simp; ring
end Optss
