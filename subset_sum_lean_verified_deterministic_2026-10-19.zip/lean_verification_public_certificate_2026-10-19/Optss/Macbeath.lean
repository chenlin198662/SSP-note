import Optss.ConvexGeometry
import Mathlib.Topology.Algebra.Group.Pointwise

/-!
# Macbeath regions and the overlap theorem

The centered body is written using its two membership conditions, so its
region is exactly `x + α ((K - x) ∩ (x - K))`.  Lemma 2.H holds in every real
vector space: neither full dimensionality, boundedness, nor closedness is
needed. All statements below also apply to empty and lower-dimensional sets.
-/
namespace Optss
noncomputable section
open scoped Pointwise

variable {E : Type*} [AddCommGroup E] [Module ℝ E]

/-- The origin-symmetric intersection defining the Macbeath region at `x`. -/
def macbeathCore (K : Set E) (x : E) : Set E :=
  {v | x + v ∈ K ∧ x - v ∈ K}

/-- Macbeath region at scale `α`, as defined on page 15. -/
def macbeathRegion (K : Set E) (x : E) (α : ℝ) : Set E :=
  (fun v => x + α • v) '' macbeathCore K x

omit [Module ℝ E] in
@[simp] theorem mem_macbeathCore {K : Set E} {x v : E} :
    v ∈ macbeathCore K x ↔ x + v ∈ K ∧ x - v ∈ K := Iff.rfl

omit [Module ℝ E] in
@[simp] theorem zero_mem_macbeathCore {K : Set E} {x : E} :
    (0 : E) ∈ macbeathCore K x ↔ x ∈ K := by simp

omit [Module ℝ E] in
@[simp] theorem neg_mem_macbeathCore {K : Set E} {x v : E} :
    -v ∈ macbeathCore K x ↔ v ∈ macbeathCore K x := by
  simp only [mem_macbeathCore, sub_eq_add_neg, neg_neg, and_comm]

theorem convex_macbeathCore {K : Set E} (hK : Convex ℝ K) (x : E) :
    Convex ℝ (macbeathCore K x) := by
  intro u hu v hv a b ha hb hab
  constructor
  · convert hK hu.1 hv.1 ha hb hab using 1
    match_scalars <;> nlinarith
  · convert hK hu.2 hv.2 ha hb hab using 1
    match_scalars <;> nlinarith

theorem center_mem_macbeathRegion {K : Set E} {x : E} (hx : x ∈ K) (α : ℝ) :
    x ∈ macbeathRegion K x α := ⟨0, by simpa, by simp⟩

theorem macbeathRegion_subset {K : Set E} (hK : Convex ℝ K) {x : E}
    (hx : x ∈ K) {α : ℝ} (hα : α ∈ Set.Icc (0 : ℝ) 1) :
    macbeathRegion K x α ⊆ K := by
  rintro z ⟨v, hv, rfl⟩
  exact hK.add_smul_mem hx hv.1 hα

theorem macbeathRegion_mono_scale {K : Set E} (hK : Convex ℝ K) {x : E}
    (hx : x ∈ K) {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) :
    macbeathRegion K x a ⊆ macbeathRegion K x b := by
  rintro z ⟨v, hv, rfl⟩
  have h : a • v ∈ b • macbeathCore K x :=
    smul_set_mono_scale (convex_macbeathCore hK x) (by simpa) ha hab
      ⟨v, hv, rfl⟩
  rcases h with ⟨w, hw, he⟩
  exact ⟨w, hw, congrArg (x + ·) he⟩

@[simp] theorem mem_macbeathRegion_one {K : Set E} {x z : E} :
    z ∈ macbeathRegion K x 1 ↔ z ∈ K ∧ (2 : ℝ) • x - z ∈ K := by
  constructor
  · rintro ⟨v, hv, rfl⟩
    simp only [one_smul]
    refine ⟨hv.1, ?_⟩
    convert hv.2 using 1
    match_scalars <;> norm_num
  · rintro ⟨hz, hreflect⟩
    refine ⟨z - x, ⟨by simpa using hz, ?_⟩, by simp⟩
    convert hreflect using 1
    match_scalars <;> norm_num

/-- Lemma 2.H, including its exact `1/5` and `1` scales. An overlap witness
supplies `y = x + u/5 - v/5`. Reflecting any point of the second region through
`x` is a convex combination of `x-u`, `x`, `y+v`, and `y-w`. -/
theorem macbeath_overlap {K : Set E} (hK : Convex ℝ K) {x y : E}
    (hx : x ∈ K) (hy : y ∈ K)
    (hoverlap : (macbeathRegion K x (1/5) ∩ macbeathRegion K y (1/5)).Nonempty) :
    macbeathRegion K y (1/5) ⊆ macbeathRegion K x 1 := by
  obtain ⟨p, ⟨u, hu, hup⟩, ⟨v, hv, hvp⟩⟩ := hoverlap
  have hyx : y = x + (1/5 : ℝ) • u - (1/5 : ℝ) • v := by
    apply eq_sub_of_add_eq
    exact hvp.trans hup.symm
  rintro z ⟨w, hw, rfl⟩
  apply mem_macbeathRegion_one.mpr
  constructor
  · exact hK.add_smul_mem hy hw.1 ⟨by norm_num, by norm_num⟩
  · have h₁ := hK hu.2 hx (show (0 : ℝ) ≤ 3/5 by norm_num)
      (show (0 : ℝ) ≤ 2/5 by norm_num) (by norm_num)
    have h₂ := hK hv.1 hw.2 (show (0 : ℝ) ≤ 3/5 by norm_num)
      (show (0 : ℝ) ≤ 2/5 by norm_num) (by norm_num)
    have h := hK h₁ h₂ (show (0 : ℝ) ≤ 1/2 by norm_num)
      (show (0 : ℝ) ≤ 1/2 by norm_num) (by norm_num)
    convert h using 1
    rw [hyx]
    match_scalars <;> norm_num

omit [Module ℝ E] in
/-- The coefficient-body definition agrees with the two translated set
intersections in the paper. -/
theorem macbeathCore_eq_inter (K : Set E) (x : E) :
    macbeathCore K x = (K - {x}) ∩ ({x} - K) := by
  ext v
  constructor
  · rintro ⟨hp, hm⟩
    exact ⟨⟨x + v, hp, x, rfl, by dsimp; abel⟩,
      ⟨x, rfl, x - v, hm, by dsimp; abel⟩⟩
  · rintro ⟨⟨a, ha, b, hb, hab⟩, ⟨c, hc, d, hd, hcd⟩⟩
    have hb' : b = x := hb
    have hc' : c = x := hc
    subst b c
    constructor
    · rw [← hab]
      simpa using ha
    · rw [← hcd]
      simpa using hd

theorem convex_macbeathRegion {K : Set E} (hK : Convex ℝ K) (x : E) (α : ℝ) :
    Convex ℝ (macbeathRegion K x α) := by
  simpa [macbeathRegion, Set.image_image] using
    ((convex_macbeathCore hK x).linear_image (α • LinearMap.id)).translate x

/-- Macbeath regions are centrally symmetric about their designated center. -/
theorem macbeathRegion_reflection {K : Set E} {x z : E} {α : ℝ}
    (hz : z ∈ macbeathRegion K x α) :
    (2 : ℝ) • x - z ∈ macbeathRegion K x α := by
  rcases hz with ⟨v, hv, rfl⟩
  refine ⟨-v, neg_mem_macbeathCore.mpr hv, ?_⟩
  dsimp only
  match_scalars <;> ring

/-- The support-deficit estimate used after (10): every small region remains
in a correspondingly enlarged supporting slab. -/
theorem macbeath_support_deficit {K : Set E} {x y : E} {α H : ℝ}
    (f : E →ₗ[ℝ] ℝ) (hH : ∀ z ∈ K, f z ≤ H) (hα : 0 ≤ α)
    (hy : y ∈ macbeathRegion K x α) :
    H - f y ≤ (1 + α) * (H - f x) := by
  rcases hy with ⟨v, hv, rfl⟩
  have hm := hH _ hv.2
  simp only [map_sub] at hm
  simp only [map_add, map_smul, smul_eq_mul]
  nlinarith

/-- A finite greedy packing exists and its regions enlarged to scale one
cover every candidate small region. Disjointness is of the whole small
regions, a sufficient condition for their interiors to be disjoint. -/
theorem exists_finite_macbeath_cover {K : Set E} (hK : Convex ℝ K)
    (S : Finset E) (hS : ∀ x ∈ S, x ∈ K) :
    ∃ T : Finset E, T ⊆ S ∧
      (∀ x ∈ T, ∀ y ∈ T, x ≠ y →
        Disjoint (macbeathRegion K x (1/5)) (macbeathRegion K y (1/5))) ∧
      ∀ x ∈ S, ∃ y ∈ T, macbeathRegion K x (1/5) ⊆ macbeathRegion K y 1 := by
  classical
  revert hS
  induction S using Finset.induction_on with
  | empty =>
      intro _
      exact ⟨∅, by simp, by simp, by simp⟩
  | @insert a S ha ih =>
      intro hS
      have hSK : ∀ x ∈ S, x ∈ K := fun x hx => hS x (Finset.mem_insert_of_mem hx)
      obtain ⟨T, hTS, hTdis, hTcover⟩ := ih hSK
      have haK := hS a (Finset.mem_insert_self a S)
      by_cases hover : ∃ b ∈ T,
          ¬ Disjoint (macbeathRegion K a (1/5)) (macbeathRegion K b (1/5))
      · obtain ⟨b, hb, hnot⟩ := hover
        refine ⟨T, fun x hx => Finset.mem_insert_of_mem (hTS hx), hTdis, ?_⟩
        intro x hx
        rcases Finset.mem_insert.mp hx with rfl | hx
        · refine ⟨b, hb, macbeath_overlap hK (hSK b (hTS hb)) haK ?_⟩
          obtain ⟨p, hp, hpb⟩ := Set.not_disjoint_iff.mp hnot
          exact ⟨p, hpb, hp⟩
        · exact hTcover x hx
      · push_neg at hover
        refine ⟨insert a T, ?_, ?_, ?_⟩
        · exact Finset.insert_subset_insert a hTS
        · intro x hx y hy hxy
          rcases Finset.mem_insert.mp hx with hxa | hxT
          · subst x
            rcases Finset.mem_insert.mp hy with hya | hyT
            · exact (hxy hya.symm).elim
            · exact hover y hyT
          · rcases Finset.mem_insert.mp hy with hya | hyT
            · subst y
              exact (hover x hxT).symm
            · exact hTdis x hxT y hyT hxy
        · intro x hx
          rcases Finset.mem_insert.mp hx with hxa | hx
          · subst x
            exact ⟨a, Finset.mem_insert_self a T,
              macbeathRegion_mono_scale hK haK (by norm_num) (by norm_num)⟩
          · obtain ⟨b, hb, hbcover⟩ := hTcover x hx
            exact ⟨b, Finset.mem_insert_of_mem hb, hbcover⟩

section Topology
variable [TopologicalSpace E] [IsTopologicalAddGroup E] [ContinuousSMul ℝ E] [T2Space E]

omit [Module ℝ E] [ContinuousSMul ℝ E] in
/-- Compactness is preserved by the centered intersection. -/
theorem isCompact_macbeathCore {K : Set E} (hK : IsCompact K) (x : E) :
    IsCompact (macbeathCore K x) := by
  rw [macbeathCore_eq_inter]
  simp only [sub_eq_add_neg]
  exact (hK.add isCompact_singleton.neg).inter (isCompact_singleton.add hK.neg)

/-- A compact set has compact Macbeath regions at every scale. -/
theorem isCompact_macbeathRegion {K : Set E} (hK : IsCompact K) (x : E) (α : ℝ) :
    IsCompact (macbeathRegion K x α) := by
  exact (isCompact_macbeathCore hK x).image (continuous_const.add (continuous_const.smul continuous_id))

end Topology
end
end Optss
