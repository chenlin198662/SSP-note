import Optss.Zonotope
import Mathlib.Analysis.Convex.KreinMilman
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.LinearAlgebra.Dimension.Finite

/-!
# Few fractional coordinates in a bounded linear system

The extreme-point step in Lemma 3.5: a point in a zonotope has a box
representation whose strictly interior vectors are linearly independent.
-/

namespace Optss
open scoped BigOperators Topology

noncomputable section

variable {ι E : Type*} [Fintype ι] [AddCommGroup E] [Module ℝ E]

/-- A direction supported on the interior coordinates permits motion in both directions. -/
private theorem exists_box_perturbation (c y d : ι → ℝ)
    (hy : y ∈ Set.Icc (0 : ι → ℝ) c)
    (hd : ∀ i, d i ≠ 0 → 0 < y i ∧ y i < c i) :
    ∃ t : ℝ, 0 < t ∧ y + t • d ∈ Set.Icc (0 : ι → ℝ) c ∧
      y - t • d ∈ Set.Icc (0 : ι → ℝ) c := by
  have hnear : ∀ᶠ t : ℝ in 𝓝 0, ∀ i, 0 ≤ y i + t * d i ∧ y i + t * d i ≤ c i := by
    apply Filter.eventually_all.2
    intro i
    by_cases hdi : d i = 0
    · exact Filter.Eventually.of_forall (fun t => by simpa [hdi] using ⟨hy.1 i, hy.2 i⟩)
    · have hi := hd i hdi
      have hcont : Continuous (fun t : ℝ => y i + t * d i) := by fun_prop
      have ht : ∀ᶠ t : ℝ in 𝓝 0, y i + t * d i ∈ Set.Ioo 0 (c i) := by
        exact (hcont.tendsto 0).eventually
          (show Set.Ioo 0 (c i) ∈ 𝓝 (y i + 0 * d i) by
            simpa only [zero_mul, add_zero] using Ioo_mem_nhds hi.1 hi.2)
      exact ht.mono (fun t ht => ⟨ht.1.le, ht.2.le⟩)
  obtain ⟨ε, hε, hball⟩ := Metric.mem_nhds_iff.1 hnear
  have hp : ε / 2 ∈ Metric.ball (0 : ℝ) ε := by
    rw [Metric.mem_ball, Real.dist_eq, sub_zero, abs_of_pos (by positivity : 0 < ε / 2)]
    linarith
  have hm : -(ε / 2) ∈ Metric.ball (0 : ℝ) ε := by
    rw [Metric.mem_ball, Real.dist_eq, sub_zero, abs_neg,
      abs_of_pos (by positivity : 0 < ε / 2)]
    linarith
  refine ⟨ε / 2, by positivity, ?_, ?_⟩
  · exact ⟨fun i => (hball hp i).1, fun i => (hball hp i).2⟩
  · constructor <;> intro i
    · simpa [sub_eq_add_neg, neg_mul] using (hball hm i).1
    · simpa [sub_eq_add_neg, neg_mul] using (hball hm i).2

/-- The fiber of the vector-sum map is closed even when no topology on `E` is chosen. -/
private theorem isClosed_combination_fiber (v : ι → E) (x : ι → ℝ) :
    IsClosed {y : ι → ℝ | combinationMap v y = combinationMap v x} := by
  have hclosed := (combinationMap v).ker.closed_of_finiteDimensional
  have hpre := hclosed.preimage (continuous_id.sub continuous_const :
    Continuous (fun y : ι → ℝ => y - x))
  convert hpre using 1
  ext y
  change (combinationMap v y = combinationMap v x) ↔
    combinationMap v (y - x) = 0
  rw [map_sub, sub_eq_zero]

/-- Every feasible box representation can be chosen so that the vectors at its
strictly interior coordinates are linearly independent. -/
theorem exists_box_representation_independent_interior (v : ι → E) (c x : ι → ℝ)
    (hx : x ∈ Set.Icc (0 : ι → ℝ) c) :
    ∃ y ∈ Set.Icc (0 : ι → ℝ) c,
      combinationMap v y = combinationMap v x ∧
      LinearIndependent ℝ (fun i : {i // 0 < y i ∧ y i < c i} => v i) := by
  classical
  let S : Set (ι → ℝ) := Set.Icc 0 c ∩ {y | combinationMap v y = combinationMap v x}
  have hS : IsCompact S := isCompact_Icc.inter_right (isClosed_combination_fiber v x)
  obtain ⟨y, hy⟩ := hS.extremePoints_nonempty ⟨x, hx, rfl⟩
  refine ⟨y, hy.1.1, hy.1.2, Fintype.linearIndependent_iff.2 ?_⟩
  intro w hw j
  let d : ι → ℝ := fun i => if hi : 0 < y i ∧ y i < c i then w ⟨i, hi⟩ else 0
  have hd : ∀ i, d i ≠ 0 → 0 < y i ∧ y i < c i := by
    intro i hi
    by_contra h
    exact hi (dif_neg h)
  have hsum : combinationMap v d = 0 := by
    rw [combinationMap_apply]
    calc
      (∑ i, d i • v i) = ∑ i ∈ Finset.univ.filter (fun i => 0 < y i ∧ y i < c i),
          d i • v i := by
        apply (Finset.sum_subset (Finset.filter_subset _ _) ?_).symm
        intro i _ hi
        have h : ¬ (0 < y i ∧ y i < c i) := by simpa using hi
        simp [d, h]
      _ = ∑ i : {i // 0 < y i ∧ y i < c i}, w i • v i := by
        rw [Finset.sum_subtype _ (p := fun i => 0 < y i ∧ y i < c i) (by simp)]
        apply Finset.sum_congr rfl
        intro i _
        simp [d, i.property]
      _ = 0 := hw
  obtain ⟨t, ht, hp, hm⟩ := exists_box_perturbation c y d hy.1.1 hd
  have hpS : y + t • d ∈ S := by
    refine ⟨hp, ?_⟩
    simp only [Set.mem_setOf_eq, map_add, map_smul, hsum, smul_zero, add_zero]
    exact hy.1.2
  have hmS : y - t • d ∈ S := by
    refine ⟨hm, ?_⟩
    simp only [Set.mem_setOf_eq, map_sub, map_smul, hsum, smul_zero, sub_zero]
    exact hy.1.2
  have hseg : y ∈ openSegment ℝ (y + t • d) (y - t • d) := by
    refine ⟨(1 / 2 : ℝ), (1 / 2 : ℝ), by norm_num, by norm_num, by norm_num, ?_⟩
    ext i
    simp only [Pi.add_apply, Pi.sub_apply, Pi.smul_apply, smul_eq_mul]
    ring
  have heq : y + t • d = y := (hy.2 hpS hmS hseg).1
  have hj := congrFun heq j.val
  simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul, d, dif_pos j.property] at hj
  exact (mul_eq_zero.mp (by linarith : t * w j = 0)).resolve_left ht.ne'

/-- The extreme-point rounding bound: at most `finrank ℝ E` coordinates are strictly
between their prescribed endpoints, while the represented vector is unchanged. -/
theorem exists_box_representation_few_interior [FiniteDimensional ℝ E]
    (v : ι → E) (c x : ι → ℝ) (hx : x ∈ Set.Icc (0 : ι → ℝ) c) :
    ∃ y ∈ Set.Icc (0 : ι → ℝ) c,
      combinationMap v y = combinationMap v x ∧
      (Finset.univ.filter (fun i => 0 < y i ∧ y i < c i)).card ≤ Module.finrank ℝ E := by
  classical
  obtain ⟨y, hy, heq, hind⟩ := exists_box_representation_independent_interior v c x hx
  refine ⟨y, hy, heq, ?_⟩
  simpa only [Fintype.card_subtype] using hind.fintype_card_le_finrank

/-- Counted-capacity rounding without expanding repeated copies. The rounding error
has fewer than one unit per active type and is supported on at most `finrank ℝ E`
types. -/
theorem exists_count_rounding [FiniteDimensional ℝ E] (v : ι → E)
    (c : ι → ℤ) (x : ι → ℝ)
    (hx : x ∈ Set.Icc (0 : ι → ℝ) (fun i => (c i : ℝ))) :
    ∃ n : ι → ℤ, BoundedCounts c n ∧ ∃ e : ι → ℝ,
      (∀ i, 0 ≤ e i ∧ e i < 1) ∧
      (Finset.univ.filter (fun i => e i ≠ 0)).card ≤ Module.finrank ℝ E ∧
      combinationMap v x = weightedSum v n + ∑ i, e i • v i := by
  classical
  obtain ⟨y, hy, heq, hcard⟩ :=
    exists_box_representation_few_interior v (fun i => (c i : ℝ)) x hx
  refine ⟨fun i => ⌊y i⌋, ?_, fun i => Int.fract (y i), ?_, ?_, ?_⟩
  · intro i
    refine ⟨Int.floor_nonneg.2 (hy.1 i), ?_⟩
    exact Int.cast_le.1 ((Int.floor_le (y i)).trans (hy.2 i))
  · exact fun i => ⟨Int.fract_nonneg _, Int.fract_lt_one _⟩
  · apply le_trans (Finset.card_le_card ?_) hcard
    intro i hi
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hi ⊢
    constructor
    · refine lt_of_le_of_ne (hy.1 i) ?_
      intro h
      exact hi (by simp [← h])
    · refine lt_of_le_of_ne (hy.2 i) ?_
      intro h
      exact hi (by simp [h])
  · rw [← heq, ← combinationMap_int, combinationMap_apply, combinationMap_apply,
      ← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro i _
    rw [← add_smul, Int.floor_add_fract]

end
end Optss
