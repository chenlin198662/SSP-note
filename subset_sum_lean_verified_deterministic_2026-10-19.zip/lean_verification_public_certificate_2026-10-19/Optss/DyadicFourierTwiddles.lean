import Optss.FixedPointRadixBounds
import Optss.CyclicRadixTwo

/-! Actual integer twiddles, obtained by rounding the proved rational
character approximations to a common dyadic denominator. All real and
complex values in this file are proof-side interpretations. -/
namespace Optss

def roundedFourierInteger (D : ℕ) (q : ℚ×ℚ) : FourierInteger :=
  ⟨round ((D : ℚ)*q.1),round ((D : ℚ)*q.2)⟩

theorem roundedFourierInteger_coordinate_error (D : ℕ) (hD : 0<D) (q : ℚ) :
    |(round ((D : ℚ)*q) : ℝ)/(D : ℝ)-(q : ℝ)|≤1/(2*(D : ℝ)) := by
  have h : |(D : ℝ)*(q : ℝ)-(round ((D : ℚ)*q) : ℝ)|≤1/2 := by
    have hh := (Rat.cast_le (K := ℝ)).mpr (abs_sub_round ((D : ℚ)*q))
    simpa only [Rat.cast_abs,Rat.cast_sub,Rat.cast_mul,Rat.cast_natCast,Rat.cast_intCast,
      Rat.cast_div,Rat.cast_one,Rat.cast_ofNat] using hh
  have hDR : (0 : ℝ)<D := Nat.cast_pos.mpr hD
  rw [abs_sub_comm] at h
  have he : (round ((D : ℚ)*q) : ℝ)/(D : ℝ)-(q : ℝ)=
      ((round ((D : ℚ)*q) : ℝ)-(D : ℝ)*(q : ℝ))/(D : ℝ) := by
    field_simp
  rw [he,abs_div,abs_of_pos hDR]
  apply (div_le_iff₀ hDR).mpr
  calc
    _ ≤ 1/2 := h
    _ = 1/(2*(D : ℝ))*(D : ℝ) := by field_simp

theorem roundedFourierInteger_error (D : ℕ) (hD : 0<D) (q : ℚ×ℚ) :
    ‖fourierIntegerValue (roundedFourierInteger D q)/(D : ℂ)-
      rationalComplexValue q‖≤1/(D : ℝ) := by
  have hDR : (D : ℝ)≠0 := Nat.cast_ne_zero.mpr (Nat.ne_of_gt hD)
  have hre := roundedFourierInteger_coordinate_error D hD q.1
  have him := roundedFourierInteger_coordinate_error D hD q.2
  have hr : (fourierIntegerValue (roundedFourierInteger D q)/(D : ℂ)-
      rationalComplexValue q).re=(round ((D : ℚ)*q.1) : ℝ)/(D : ℝ)-(q.1 : ℝ) := by
    simp [roundedFourierInteger,fourierIntegerValue,rationalComplexValue,
      Complex.div_re,Complex.normSq]
    field_simp
    ring
  have hi : (fourierIntegerValue (roundedFourierInteger D q)/(D : ℂ)-
      rationalComplexValue q).im=(round ((D : ℚ)*q.2) : ℝ)/(D : ℝ)-(q.2 : ℝ) := by
    simp [roundedFourierInteger,fourierIntegerValue,rationalComplexValue,
      Complex.div_im,Complex.normSq]
    field_simp
    ring
  have hh := Complex.norm_le_abs_re_add_abs_im
    (fourierIntegerValue (roundedFourierInteger D q)/(D : ℂ)-rationalComplexValue q)
  rw [hr,hi] at hh
  have he : 1/(2*(D : ℝ))+1/(2*(D : ℝ))=1/(D : ℝ) := by ring
  linarith

def dyadicFourierDenominator (p : ℕ) : ℕ := 2^(p+2)

def dyadicCharacterInteger {N : ℕ} [NeZero N] (x : ZMod N) (p : ℕ) : FourierInteger :=
  roundedFourierInteger (dyadicFourierDenominator p)
    (rationalCharacterApproximation x (p+2))

theorem dyadicFourierDenominator_pos (p : ℕ) : 0<dyadicFourierDenominator p := by
  exact pow_pos (by decide) _

theorem dyadicCharacterInteger_error {N : ℕ} [NeZero N] (x : ZMod N) (p : ℕ) :
    ‖fourierIntegerValue (dyadicCharacterInteger x p)/(dyadicFourierDenominator p : ℂ)-
      ZMod.stdAddChar x‖≤(1/2 : ℝ)^p := by
  have hround := roundedFourierInteger_error (dyadicFourierDenominator p)
    (dyadicFourierDenominator_pos p) (rationalCharacterApproximation x (p+2))
  have hchar := rationalCharacterApproximation_error x (p+2)
  have htri := norm_sub_le_norm_sub_add_norm_sub
    (fourierIntegerValue (dyadicCharacterInteger x p)/(dyadicFourierDenominator p : ℂ))
    (rationalComplexValue (rationalCharacterApproximation x (p+2))) (ZMod.stdAddChar x)
  change ‖fourierIntegerValue (dyadicCharacterInteger x p)/(dyadicFourierDenominator p : ℂ)-
    rationalComplexValue (rationalCharacterApproximation x (p+2))‖≤_ at hround
  have hden : 1/(dyadicFourierDenominator p : ℝ)=(1/2 : ℝ)^(p+2) := by
    simp [dyadicFourierDenominator,one_div_pow]
  rw [hden] at hround
  rw [pow_add] at hround hchar
  norm_num at hround hchar
  have hp : (0 : ℝ)≤(1/2)^p := by positivity
  linarith

theorem dyadicCharacterInteger_bound {N : ℕ} [NeZero N] (x : ZMod N) (p : ℕ) :
    FourierIntegerBound (dyadicCharacterInteger x p) (2*dyadicFourierDenominator p) := by
  let z := dyadicCharacterInteger x p
  let D := dyadicFourierDenominator p
  have hD : (0 : ℝ)<D := Nat.cast_pos.mpr (dyadicFourierDenominator_pos p)
  have he := dyadicCharacterInteger_error x p
  have hp : (1/2 : ℝ)^p≤1 := pow_le_one₀ (by norm_num) (by norm_num)
  have hn : ‖fourierIntegerValue z/(D : ℂ)‖≤2 := by
    have ht := norm_sub_norm_le (fourierIntegerValue z/(D : ℂ)) (ZMod.stdAddChar x)
    rw [AddChar.norm_apply] at ht
    dsimp [z,D] at ht ⊢
    linarith
  rw [norm_div,Complex.norm_natCast] at hn
  have hv : ‖fourierIntegerValue z‖≤2*(D : ℝ) := (div_le_iff₀ hD).mp hn
  have hre := (Complex.abs_re_le_norm (fourierIntegerValue z)).trans hv
  have him := (Complex.abs_im_le_norm (fourierIntegerValue z)).trans hv
  simp only [fourierIntegerValue,Complex.add_re,Complex.intCast_re,Complex.mul_re,
    Complex.I_re,Complex.intCast_im,Complex.I_im,mul_zero,zero_mul,sub_zero,add_zero,
    Complex.add_im,Complex.mul_im,mul_one,zero_add] at hre him
  constructor
  · exact_mod_cast hre
  · exact_mod_cast him

/-- Materialize each approximate root power once; recursive butterflies
only read this array. -/
def dyadicCharacterTable (n p : ℕ) : Vector FourierInteger (2^n) :=
  Vector.ofFn fun j => dyadicCharacterInteger (-(j.val : ZMod (2^n))) p

def dyadicTwiddleIndex (n l k : ℕ) : Fin (2^n) :=
  ⟨(2^(n-(l+1))*k)%(2^n),Nat.mod_lt _ (pow_pos (by decide) _)⟩

def dyadicTwiddleFromTable (n : ℕ) (V : Vector FourierInteger (2^n))
    (l k : ℕ) : FourierInteger := V.get (dyadicTwiddleIndex n l k)

theorem dyadicTwiddleFromTable_character (n p l k : ℕ) :
    dyadicTwiddleFromTable n (dyadicCharacterTable n p) l k=
      dyadicCharacterInteger (-(2^(n-(l+1))*k : ℕ) : ZMod (2^n)) p := by
  simp only [dyadicTwiddleFromTable,dyadicCharacterTable,vector_get_ofFn,
    dyadicTwiddleIndex,ZMod.natCast_mod]

theorem dyadicTwiddleFromTable_error (n p l k : ℕ) :
    ‖fourierIntegerValue (dyadicTwiddleFromTable n (dyadicCharacterTable n p) l k)/
      (dyadicFourierDenominator p : ℂ)-cyclicRadixTwiddle n l k‖≤(1/2 : ℝ)^p := by
  rw [dyadicTwiddleFromTable_character,cyclicRadixTwiddle_character]
  exact dyadicCharacterInteger_error _ p

theorem dyadicTwiddleFromTable_bound (n p l k : ℕ) :
    FourierIntegerBound (dyadicTwiddleFromTable n (dyadicCharacterTable n p) l k)
      (2*dyadicFourierDenominator p) := by
  rw [dyadicTwiddleFromTable_character]
  exact dyadicCharacterInteger_bound _ p

end Optss
