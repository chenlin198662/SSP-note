import Optss.LongSumsetGrowth
import Optss.WideCoordinateModel
import Optss.HyperplaneCounting

/-!
# The actual containing progression at the beginning of a common-GAP phase

Uniform long-sumset growth supplies small doubling of `10*h • X`. The proved
Freiman theorem then supplies a twice-proper container with coefficient
volume bounded by a constant times `|h • X|`. Constants depend only on the
ambient growth exponent; no supplied doubling or progression premise occurs.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1000000

/-- Uniform bounded doubling and size of the tenfold phase sumset. -/
theorem common_gap_phase_doubling (η : ℝ) (hη : 0 < η) :
    ∃ N₀ K : ℕ, 1 ≤ K ∧ ∀ (N h : ℕ) (X : Finset ℤ),
      N₀ ≤ N → X ⊆ Finset.Icc 0 (N : ℤ) → 0 ∈ X → (N : ℝ)^η ≤ h →
      (((10*h) • X + (10*h) • X).card ≤ K*((10*h) • X).card) ∧
      ((10*h) • X).card ≤ K*(h • X).card := by
  obtain ⟨R, N₀, C, hC, hgrowth⟩ := long_sumset_growth_fixed_factor η hη
  let K := max 1 ⌈C*(20 : ℝ)^R⌉₊
  refine ⟨N₀, K, le_max_left _ _, ?_⟩
  intro N h X hN hX hzero hscale
  have hbig₀ := hgrowth N h 20 X hN hX hzero hscale (by norm_num)
  have hbig : (((20*h) • X).card : ℝ) ≤ C*20^R*(h • X).card := by
    simpa only [← Set.ncard_coe_Finset, Finset.coe_nsmul] using hbig₀
  have hK : C*(20 : ℝ)^R ≤ K := (Nat.le_ceil _).trans
    (Nat.cast_le.mpr (le_max_right 1 ⌈C*(20 : ℝ)^R⌉₊))
  have hcount : ((20*h) • X).card ≤ K*(h • X).card := by
    exact_mod_cast hbig.trans (mul_le_mul_of_nonneg_right hK (Nat.cast_nonneg _))
  have hsmall : (h • X).card ≤ ((10*h) • X).card :=
    Finset.card_le_card (Finset.nsmul_subset_nsmul_right hzero (by omega))
  have hmid : ((10*h) • X).card ≤ ((20*h) • X).card :=
    Finset.card_le_card (Finset.nsmul_subset_nsmul_right hzero (by omega))
  refine ⟨?_, hmid.trans hcount⟩
  have he : (10*h) • X + (10*h) • X = (20*h) • X := by
    rw [← add_nsmul]
    congr 1
    omega
  rw [he]
  exact hcount.trans (Nat.mul_le_mul_left K hsmall)

/-- The actual phase container, of rank and coefficient volume bounded only
in terms of the fixed exponent. -/
theorem common_gap_phase_container (η : ℝ) (hη : 0 < η) :
    ∃ N₀ R : ℕ, ∃ V : ℚ≥0, ∀ (N h : ℕ) (X : Finset ℤ),
      N₀ ≤ N → X ⊆ Finset.Icc 0 (N : ℤ) → 0 ∈ X → (N : ℝ)^η ≤ h →
      ∃ d ≤ R, ∃ (ρ : IntVec d →+ ℤ) (β : Fin d → ℕ),
        (10*h) • X ⊆ integerProgressionValues ρ β ∧
        Set.InjOn ρ (integerBudgetBox (fun j => 2*β j)) ∧
        ((integerBudgetBox β).card : ℚ≥0) ≤ V*(h • X).card := by
  obtain ⟨N₀, K, _, hgrowth⟩ := common_gap_phase_doubling η hη
  refine ⟨N₀, freimanContainingRank K, freimanContainingVolume K 2*K, ?_⟩
  intro N h X hN hX hzero hscale
  obtain ⟨hdouble, hsize⟩ := hgrowth N h X hN hX hzero hscale
  let Y := (10*h) • X
  have hY : Y.Nonempty := ⟨0, zero_mem_integer_repeated_sumset X hzero (10*h)⟩
  have hbound : ∀ x ∈ Y, 0 ≤ x ∧ x ≤ (10*h*N : ℕ) := by
    intro x hx
    exact Finset.mem_Icc.mp (integer_repeated_sumset_subset_interval X N hX (10*h) hx)
  have hC : ((Y+Y).card : ℚ≥0) ≤ (K : ℚ≥0)*Y.card := by exact_mod_cast hdouble
  obtain ⟨d, hd, ρ, β, hcont, hproper, hvol⟩ :=
    exists_bounded_interval_containing_progression Y hY (10*h*N) hbound K hC 2
  refine ⟨d, hd, ρ, β, hcont, ?_, ?_⟩
  · apply hproper.mono
    intro z hz j
    have hj := (mem_integerBudgetBox _ z).mp hz j
    change |(z j : ℝ)| ≤ (2 : ℝ)*(β j : ℝ)
    exact_mod_cast hj
  · calc
      _ ≤ freimanContainingVolume K 2*Y.card := hvol
      _ ≤ freimanContainingVolume K 2*((K : ℚ≥0)*(h • X).card) :=
        mul_le_mul_left' (by exact_mod_cast hsize) _
      _ = _ := by ring


/-- Exact phase coordinates after shrinking by `10*h` and deleting zero
widths. Their full real rank follows from their actual repeated-sumset density,
and every sum through `20*h` retains its exact scalar cardinality. -/
theorem common_gap_phase_coordinates (η : ℝ) (hη : 0 < η) :
    ∃ N₀ H₀ R : ℕ, ∃ C : ℝ, ∀ (N h : ℕ) (X : Finset ℤ),
      N₀ ≤ N → H₀ ≤ h → X ⊆ Finset.Icc 0 (N : ℤ) → 0 ∈ X → (N : ℝ)^η ≤ h →
      ∃ d ≤ R, ∃ (ρ : IntVec d →+ ℤ) (w : Fin d → ℕ) (U : Finset (IntVec d)),
        (∀ j, 1 ≤ w j) ∧ 0 ∈ U ∧ (∀ x ∈ U, InCenteredBox w x) ∧ U.image ρ = X ∧
        Set.InjOn ρ (integerBudgetBox (fun j => 20*h*w j)) ∧
        (∀ k ≤ 20*h, (k • U).card = (k • X).card) ∧
        labelSpan ℝ realVector U = ⊤ ∧
        ((integerBudgetBox (fun j => h*w j)).card : ℝ) ≤ C*(h • X).card := by
  obtain ⟨N₀, R, C, hcontainer⟩ := common_gap_phase_container η hη
  refine ⟨N₀, max 1 ⌈(C : ℝ)⌉₊, R, C, ?_⟩
  intro N h X hN hh hX hzero hscale
  have hh1 : 1 ≤ h := (le_max_left _ _).trans hh
  have hH : 0 < 10*h := by omega
  have hClt : (C : ℝ) < (2*h+1 : ℕ) := by
    have hC : (C : ℝ) ≤ h := (Nat.le_ceil _).trans (Nat.cast_le.mpr ((le_max_right _ _).trans hh))
    have hhR : (0 : ℝ) ≤ h := Nat.cast_nonneg _
    push_cast
    linarith
  obtain ⟨d, hd, ρ, β, hcont, hproper, hvol⟩ := hcontainer N h X hN hX hzero hscale
  let γ := shrunkProgressionWidths β (10*h)
  let e := Fintype.card (PositiveCoordinate γ)
  let w := positiveBudget γ
  let U := (liftedProgressionInputs ρ β X).image (restrictPositiveHom γ)
  let ρ' := positiveProgressionHom ρ γ
  obtain ⟨_, _, hwidevol, hU, _, himage, _⟩ :=
    repeated_set_wide_coordinate_model X hzero (10*h) hH ρ β hproper hcont
  have hbox : ∀ x ∈ U, InCenteredBox w x := fun x hx => (mem_integerBudgetBox _ x).mp (hU x hx)
  have hzL : (0 : IntVec d) ∈ liftedProgressionInputs ρ β X := by
    have hz := Finset.mem_image_of_mem (integerProgressionCoordinates ρ β) hzero
    simpa only [integerProgressionCoordinates_zero ρ β hproper] using hz
  have hzU : (0 : IntVec e) ∈ U := Finset.mem_image.mpr ⟨0, hzL, map_zero _⟩
  have hcard : ∀ k ≤ 20*h, (k • U).card = (k • X).card := by
    intro k hk
    exact repeated_set_wide_coordinate_card X hzero (10*h) hH ρ β hproper hcont k (by omega)
  have hboxvol : (integerBudgetBox (fun j => h*w j)).card ≤ (integerBudgetBox β).card := by
    apply le_trans _ hwidevol
    apply Finset.card_le_card
    intro z hz
    apply (mem_integerBudgetBox _ z).mpr
    intro j
    exact ((mem_integerBudgetBox _ z).mp hz j).trans (by
      dsimp only
      exact_mod_cast (Nat.mul_le_mul_right (w j) (show h ≤ 10*h by omega)))
  have hvolume : ((integerBudgetBox (fun j => h*w j)).card : ℝ) ≤ (C : ℝ)*(h • X).card := by
    exact (Nat.cast_le.mpr hboxvol).trans (by exact_mod_cast hvol)
  have hfull : labelSpan ℝ realVector U = ⊤ := by
    apply repeatedSumset_span_eq_top_of_box_density U w (positiveBudget_pos γ) hbox h C hClt
    · rw [hcard h (by omega)]
      exact Finset.card_pos.mpr ⟨0, zero_mem_integer_repeated_sumset X hzero h⟩
    · rw [hcard h (by omega)]
      simpa only [integerBudgetBox_card, mul_assoc] using hvolume
  refine ⟨e, (positiveCoordinate_count_le γ).trans hd, ρ', w, U,
    positiveBudget_pos γ, hzU, hbox, himage, ?_, hcard, hfull, hvolume⟩
  have hp := repeated_set_wide_coordinate_double_proper (10*h) ρ β hproper
  have he : (fun j => 20*h*w j) = (fun j => 2*(10*h*positiveBudget γ j)) := by
    funext j
    dsimp only [w]
    ring
  rw [he]
  exact hp

end
end Optss
