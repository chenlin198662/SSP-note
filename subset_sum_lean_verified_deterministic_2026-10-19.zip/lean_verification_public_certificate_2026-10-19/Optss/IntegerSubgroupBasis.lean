import Optss.PolytopeLatticeBoxing
import Mathlib.Algebra.Module.ZLattice.Basic

/-!
# A basis of the entire full-rank integer subgroup

Positive coordinate-axis periods give full real span. Discreteness comes from
integral coordinates. Mathlib's lattice-basis theorem then supplies a basis of
the whole subgroup, with integral standard coordinates. No basis-replacement
shortcut or basis of a proper sublattice is used.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {d : ℕ}

def integerSubgroupRealLattice (Γ : AddSubgroup (IntVec d)) :
    Submodule ℤ (Fin d → ℝ) :=
  Γ.toIntSubmodule.map realVector.toIntLinearMap

theorem integerSubgroupRealLattice_coe (Γ : AddSubgroup (IntVec d)) :
    (integerSubgroupRealLattice Γ : Set (Fin d → ℝ)) =
      realVector '' (Γ : Set (IntVec d)) := by
  rfl

instance integerSubgroupRealLattice_discrete (Γ : AddSubgroup (IntVec d)) :
    DiscreteTopology (integerSubgroupRealLattice Γ) := by
  refine discreteTopology_iff_isOpen_singleton_zero.mpr
    ⟨Metric.ball 0 1, Metric.isOpen_ball, ?_⟩
  ext x
  rw [Set.mem_preimage, mem_ball_zero_iff, pi_norm_lt_iff zero_lt_one,
    Set.mem_singleton_iff]
  obtain ⟨z, _, hz⟩ := x.property
  have hx : (x : Fin d → ℝ) = realVector z := hz.symm
  simp only [← Subtype.coe_inj, Submodule.coe_zero, funext_iff, Pi.zero_apply,
    Real.norm_eq_abs, hx]
  apply forall_congr'
  intro j
  change |(z j : ℝ)| < 1 ↔ (z j : ℝ) = 0
  rw [← Int.cast_abs, ← Int.cast_one, Int.cast_lt, Int.abs_lt_one_iff,
    Int.cast_eq_zero]

theorem integerSubgroupRealLattice_span (Γ : AddSubgroup (IntVec d))
    (v : Fin d → ℤ) (hv : ∀ j, 0 < v j)
    (haxes : ∀ j, Pi.single j (v j) ∈ Γ) :
    Submodule.span ℝ (integerSubgroupRealLattice Γ : Set (Fin d → ℝ)) = ⊤ := by
  apply top_unique
  rw [← (Pi.basisFun ℝ (Fin d)).span_eq]
  apply Submodule.span_le.mpr
  rintro _ ⟨j, rfl⟩
  have hmem : realVector (Pi.single j (v j)) ∈
      Submodule.span ℝ (integerSubgroupRealLattice Γ : Set (Fin d → ℝ)) :=
    Submodule.subset_span ⟨Pi.single j (v j), haxes j, rfl⟩
  have hcast : (v j : ℝ) ≠ 0 := by exact_mod_cast ne_of_gt (hv j)
  convert Submodule.smul_mem _ (v j : ℝ)⁻¹ hmem using 1
  ext i
  by_cases hij : i = j
  · subst i
    simp [realVector, hcast]
  · simp [realVector, hij, Ne.symm hij]

 /-- The entire subgroup has an integral-coordinate real basis, including in
dimension zero. The coordinate periods are used only to establish full rank. -/
theorem integer_subgroup_full_basis (Γ : AddSubgroup (IntVec d))
    (v : Fin d → ℤ) (hv : ∀ j, 0 < v j)
    (haxes : ∀ j, Pi.single j (v j) ∈ Γ) :
    ∃ b : Basis (Fin d) ℝ (Fin d → ℝ),
      basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)) ∧
      ∀ i j, ∃ z : ℤ, (z : ℝ) = b j i := by
  let L := integerSubgroupRealLattice Γ
  letI : IsZLattice ℝ L := ⟨integerSubgroupRealLattice_span Γ v hv haxes⟩
  have hrank : Module.finrank ℤ L = d := by
    rw [ZLattice.rank ℝ L]
    simp
  let bZ : Basis (Fin d) ℤ L := Module.finBasisOfFinrankEq ℤ L hrank
  let b := bZ.ofZLatticeBasis ℝ L
  refine ⟨b, ?_, ?_⟩
  · rw [basisIntegerLattice_eq_integerSpan, Basis.ofZLatticeBasis_span]
    exact integerSubgroupRealLattice_coe Γ
  · intro i j
    obtain ⟨z, _, hz⟩ := (bZ j).property
    refine ⟨z i, ?_⟩
    change realVector z i = bZ.ofZLatticeBasis ℝ L j i
    rw [Basis.ofZLatticeBasis_apply]
    exact congrFun hz i

/-- Rational-coordinate form for the rational-polytope boxing adapter. -/
theorem integer_subgroup_rational_basis (Γ : AddSubgroup (IntVec d))
    (v : Fin d → ℤ) (hv : ∀ j, 0 < v j)
    (haxes : ∀ j, Pi.single j (v j) ∈ Γ) :
    ∃ b : Basis (Fin d) ℝ (Fin d → ℝ),
      basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)) ∧
      ∀ i j, ∃ q : ℚ, (q : ℝ) = b j i := by
  obtain ⟨b, hb, hint⟩ := integer_subgroup_full_basis Γ v hv haxes
  refine ⟨b, hb, fun i j => ?_⟩
  obtain ⟨z, hz⟩ := hint i j
  exact ⟨z, by simpa only [Rat.cast_intCast] using hz⟩

end
end Optss
