import Optss.CachedRationalReduction
import Optss.ExecutableRationalReduction

/-!
# Independence of sufficient reduction fuel

Deterministic reduction produces the same matrix and swap count for any fuel
at least its positive initial Gram potential. Consequently the materialized,
determinant-free implementation has exactly the rational adapter's output.
-/

namespace Optss
variable {r d : ℕ}

theorem executableReductionFuel_stable (fuel other : ℕ) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (hf : gramPotential A ≤ fuel) (ho : gramPotential A ≤ other) :
    executableReductionFuel fuel A = executableReductionFuel other A := by
  induction fuel generalizing A other with
  | zero => exact False.elim (by have := gramPotential_pos A hA; omega)
  | succ n ih =>
    cases other with
    | zero => exact False.elim (by have := gramPotential_pos A hA; omega)
    | succ m =>
      let C := executableSizeSweep A
      obtain ⟨hC, _, hpotC, _⟩ := executableSizeSweep_spec A hA
      change LinearIndependent ℝ (fun i j => (C i j:ℝ)) at hC
      change gramPotential C = gramPotential A at hpotC
      letI : Decidable (failingAdjacentPairs C).Nonempty := decidableFailingAdjacentPairs C
      rw [executableReductionFuel, executableReductionFuel]
      dsimp only
      by_cases hfail : (failingAdjacentPairs C).Nonempty
      · simp only [show executableSizeSweep A = C from rfl, dif_pos hfail]
        let p := leastFailingAdjacentPair C hfail
        have hbad := (mem_failingAdjacentPairs C p).mp (leastFailingAdjacentPair_mem C hfail)
        have hswap : LinearIndependent ℝ (fun i j => ((swapRows C p.1 p.2) i j:ℝ)) :=
          hC.comp (Equiv.swap p.1 p.2) (Equiv.swap p.1 p.2).injective
        have hcontract : 4*gramPotential (swapRows C p.1 p.2) < 3*gramPotential A := by
          rw [← hpotC]
          exact gramPotential_swap_three_quarters C hC p.1 p.2 hbad.1 hbad.2
        have he := ih m (swapRows C p.1 p.2) hswap (by omega) (by omega)
        exact congrArg (fun out : Matrix (Fin r) (Fin d) ℤ × ℕ => (out.1,out.2+1)) he
      · simp only [show executableSizeSweep A = C from rfl, dif_neg hfail]

/-- Actual cached output data match the original exact arithmetic loop, even
though their sufficient fuel values are computed differently. -/
theorem cachedIntegerReduction_data_eq (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) :
    ((cachedIntegerReduction A hA).rows, (cachedIntegerReduction A hA).swapCount) =
      ((executableIntegerReduction A hA).rows, (executableIntegerReduction A hA).swapCount) := by
  change (integerMatrixDataRows (cachedReductionData A).1, (cachedReductionData A).2) =
    executableReductionFuel (gramPotential A) A
  rw [cachedReductionData_def, materializedReductionFuel_eq, integerMatrixDataRows_materialize,
    cachedReductionFuel_eq _ _ hA]
  exact executableReductionFuel_stable _ _ A hA
    (gramPotential_le_cachedReductionInitialFuel A) le_rfl

end Optss
