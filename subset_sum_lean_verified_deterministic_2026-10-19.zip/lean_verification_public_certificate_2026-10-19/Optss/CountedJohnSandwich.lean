import Optss.CountReserveFilling
import Optss.CommonCountedOutput
import Optss.ProperizationQuotient

/-!
# Counted John-type zonotope sandwich

This file packages the mathematical implication used in Theorem 1.4 and
Corollary 1.5.  The input is the exact counted common-reserve output: a box
containing every live coordinate vector and an actual reserve-count filling
of the dimension-sized integer box.  The conclusion is the paper's inner and
outer zonotope sandwich, together with the interior lattice-point certificate.

No construction-time or query-time assertion is made here.
-/

namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators

variable {ι : Type*} [Fintype ι]

/-- The standard integer lattice embedded in real coordinate space. -/
def realIntegerLattice (d : ℕ) : AddSubgroup (Fin d → ℝ) :=
  AddMonoidHom.range (realVector (d := d))

@[simp] theorem mem_realIntegerLattice_iff {d : ℕ} (x : Fin d → ℝ) :
    x ∈ realIntegerLattice d ↔ ∃ z : IntVec d, realVector z = x := by
  rfl

theorem realVector_injective {d : ℕ} : Function.Injective (realVector (d := d)) := by
  intro x y h
  ext j
  have hj := congrFun h j
  change (x j : ℝ) = (y j : ℝ) at hj
  exact_mod_cast hj

@[simp] theorem realVector_weightedSum {d : ℕ} (u : ι → IntVec d) (a : ι → ℤ) :
    realVector (weightedSum u a) = weightedSum (fun i => realVector (u i)) a := by
  simp only [weightedSum, map_sum, map_zsmul]

/-- Embedding integer coordinates into reals preserves counted subset sums
exactly, rather than merely in the forward direction. -/
theorem realVector_mem_countSums_iff {d : ℕ} (u : ι → IntVec d) (c : ι → ℤ)
    (z : IntVec d) :
    realVector z ∈ countSums (fun i => realVector (u i)) c ↔ z ∈ countSums u c := by
  constructor
  · rintro ⟨a, ha, hsum⟩
    exact ⟨a, ha, realVector_injective (by simpa only [realVector_weightedSum] using hsum)⟩
  · rintro ⟨a, ha, rfl⟩
    exact ⟨a, ha, (realVector_weightedSum u a).symm⟩

/-- Counted reserved-item filling only needs the body and lattice hypotheses
for types with a positive reserve-or-remainder multiplicity.  This support
form avoids imposing artificial conditions on zero-capacity types. -/
theorem counted_reserved_zonotope_filling_on_support
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    {C : Set E} (hconv : Convex ℝ C) (hcompact : IsCompact C) (hne : C.Nonempty)
    (hsym : ∀ x ∈ C, -x ∈ C) (Λ : AddSubgroup E)
    (v : ι → E) (cR cB : ι → ℕ)
    (hvC : ∀ i, 0 < cR i + cB i → v i ∈ C)
    (hvΛ : ∀ i, 0 < cR i + cB i → v i ∈ Λ)
    {z₀ : E} (hz₀Λ : z₀ ∈ Λ)
    (hfill : {z₀} + ((Module.finrank ℝ E : ℝ) • C ∩ (Λ : Set E)) ⊆
      countSums v (fun i => (cR i : ℤ))) :
    let K := {z₀} + zonotope v (fun i => (cB i : ℝ))
    let Z := zonotope v (fun i => ((cR i + cB i : ℕ) : ℝ))
    let S := countSums v (fun i => ((cR i + cB i : ℕ) : ℤ))
    let q := ∑ i, cR i
    (K ∩ (Λ : Set E) ⊆ S) ∧ (S ⊆ Z ∩ (Λ : Set E)) ∧
    (K ⊆ Z) ∧ (Z ⊆ K + (q : ℝ) • C) ∧
    (∀ z ∈ Λ, {z} + (q : ℝ) • C ⊆ Z → z ∈ K ∩ (Λ : Set E)) := by
  have hfill' : {z₀} + ((Module.finrank ℝ E : ℝ) • C ∩ (Λ : Set E)) ⊆
      subsetSums (expandedCopy v cR) := by
    rw [subsetSums_expandedCopy_eq_countSums]
    exact hfill
  have h := reserved_zonotope_filling hconv hcompact hne hsym Λ
    (expandedCopy v cR) (expandedCopy v cB)
    (fun q => hvC q.1 (by have hq := q.2.isLt; omega))
    (fun q => hvC q.1 (by have hq := q.2.isLt; omega))
    (fun q => hvΛ q.1 (by have hq := q.2.isLt; omega))
    (fun q => hvΛ q.1 (by have hq := q.2.isLt; omega)) hz₀Λ hfill'
  dsimp only at h ⊢
  simpa only [zonotope_expandedCopy, zonotope_expandedCopy_sum,
    subsetSums_expandedCopy_sum, card_copyIndex] using h

section CoordinateConclusion

variable {d : ℕ}

/-- The five simultaneous set-theoretic conclusions in the John-type
zonotope sandwich, stated for compressed per-type multiplicities. -/
def CountedJohnGeometry
    (capacity e r : ι → ℕ) (u : ι → IntVec d) (width : Fin d → ℕ)
    (t : IntVec d) : Prop :=
  let b := fun i => capacity i - e i - r i
  let K := {realVector t} +
    zonotope (fun i => realVector (u i)) (fun i => (b i : ℝ))
  let Z := zonotope (fun i => realVector (u i))
    (fun i => ((r i + b i : ℕ) : ℝ))
  let S := countSums (fun i => realVector (u i))
    (fun i => ((r i + b i : ℕ) : ℤ))
  let q := ∑ i, r i
  (K ∩ (realIntegerLattice d : Set (Fin d → ℝ)) ⊆ S) ∧
  (S ⊆ Z ∩ (realIntegerLattice d : Set (Fin d → ℝ))) ∧
  (K ⊆ Z) ∧
  (Z ⊆ K + (q : ℝ) • realCoefficientBox width) ∧
  (∀ z : IntVec d,
    {realVector z} + (q : ℝ) • realCoefficientBox width ⊆ Z →
    realVector z ∈ K ∩ (realIntegerLattice d : Set (Fin d → ℝ)))

/-- The exact geometric conclusion of the John-type argument for counted
coordinate vectors.  `e` are exceptional counts, `r` reserve counts, and the
remaining multiplicity is `capacity - e - r`.

The sole scale premise is the manuscript's requirement that the filled box
have radius at least the coordinate dimension. -/
theorem counted_john_zonotope_sandwich
    (capacity e r : ι → ℕ) (u : ι → IntVec d) (width : Fin d → ℕ)
    (t : IntVec d) (fillScale : ℝ) (h : ℕ)
    (he : ∀ i, e i ≤ capacity i)
    (hr : ∀ i, r i ≤ capacity i - e i)
    (hu : ∀ i, 0 < capacity i - e i → InCenteredBox width (u i))
    (hfill : ∀ z : IntVec d,
      (∀ j, |(z j : ℝ)| ≤ fillScale * h * width j) →
      t + z ∈ countSums u (fun i => (r i : ℤ)))
    (hdim : (d : ℝ) ≤ fillScale * h) :
    CountedJohnGeometry capacity e r u width t := by
  dsimp only [CountedJohnGeometry]
  let b := fun i => capacity i - e i - r i
  have htotal (i : ι) : r i + b i = capacity i - e i := by
    dsimp only [b]
    have hri := hr i
    omega
  have hvC : ∀ i, 0 < r i + b i → realVector (u i) ∈ realCoefficientBox width := by
    intro i hi
    rw [mem_realCoefficientBox]
    intro j
    change |(u i j : ℝ)| ≤ (width j : ℝ)
    exact_mod_cast hu i (by rwa [htotal i] at hi) j
  have hvΛ : ∀ i, 0 < r i + b i → realVector (u i) ∈ realIntegerLattice d := by
    intro i _
    exact ⟨u i, rfl⟩
  have htΛ : realVector t ∈ realIntegerLattice d := ⟨t, rfl⟩
  have hfillReal :
      {realVector t} +
        ((Module.finrank ℝ (Fin d → ℝ) : ℝ) • realCoefficientBox width ∩
          (realIntegerLattice d : Set (Fin d → ℝ))) ⊆
        countSums (fun i => realVector (u i)) (fun i => (r i : ℤ)) := by
    rintro y ⟨a, ha, x, ⟨hxbox, hxΛ⟩, hax⟩
    have haeq : a = realVector t := ha
    subst a
    obtain ⟨z, hz⟩ := hxΛ
    have hdimfin : Module.finrank ℝ (Fin d → ℝ) = d := by simp
    have hzbound : ∀ j, |(z j : ℝ)| ≤ fillScale * h * width j := by
      have hxbound := mem_smul_realCoefficientBox_bound width
        (Module.finrank ℝ (Fin d → ℝ) : ℝ)
        (by positivity) x hxbox
      intro j
      have heq := congrFun hz j
      change (z j : ℝ) = x j at heq
      rw [hdimfin] at hxbound
      calc
        |(z j : ℝ)| = |x j| := congrArg abs heq
        _ ≤ (d : ℝ) * width j := hxbound j
        _ ≤ fillScale * h * width j := mul_le_mul_of_nonneg_right hdim
          (Nat.cast_nonneg (width j))
    have hs := hfill z hzbound
    have hsReal : realVector (t + z) ∈
        countSums (fun i => realVector (u i)) (fun i => (r i : ℤ)) :=
      (realVector_mem_countSums_iff u _ _).2 hs
    have hy : y = realVector (t + z) := by
      rw [← hax, ← hz]
      simp
    rwa [hy]
  have hsandwich := counted_reserved_zonotope_filling_on_support
    (realCoefficientBox_convex width) (realCoefficientBox_compact width)
    ⟨0, by simp [mem_realCoefficientBox]⟩
    (fun _ hx => realCoefficientBox_symmetric width hx)
    (realIntegerLattice d) (fun i => realVector (u i)) r b hvC hvΛ htΛ hfillReal
  dsimp only at hsandwich
  refine ⟨hsandwich.1, hsandwich.2.1, hsandwich.2.2.1,
    hsandwich.2.2.2.1, ?_⟩
  intro z hinterior
  exact hsandwich.2.2.2.2 (realVector z) ⟨z, rfl⟩ hinterior

/-- Corollary 1.5's mathematical certification: every integer point whose
reserve-sized translated box lies in the outer zonotope is an actual counted
subset sum. -/
theorem counted_john_interior_point
    (capacity e r : ι → ℕ) (u : ι → IntVec d) (width : Fin d → ℕ)
    (t : IntVec d) (fillScale : ℝ) (h : ℕ)
    (he : ∀ i, e i ≤ capacity i)
    (hr : ∀ i, r i ≤ capacity i - e i)
    (hu : ∀ i, 0 < capacity i - e i → InCenteredBox width (u i))
    (hfill : ∀ z : IntVec d,
      (∀ j, |(z j : ℝ)| ≤ fillScale * h * width j) →
      t + z ∈ countSums u (fun i => (r i : ℤ)))
    (hdim : (d : ℝ) ≤ fillScale * h)
    (z : IntVec d)
    (hinterior :
      {realVector z} + ((∑ i, r i : ℕ) : ℝ) • realCoefficientBox width ⊆
        zonotope (fun i => realVector (u i))
          (fun i => ((r i + (capacity i - e i - r i) : ℕ) : ℝ))) :
    z ∈ countSums u (fun i => ((capacity i - e i : ℕ) : ℤ)) := by
  have hs := counted_john_zonotope_sandwich capacity e r u width t fillScale h
    he hr hu hfill hdim
  dsimp only [CountedJohnGeometry] at hs
  have hzK := hs.2.2.2.2 z hinterior
  have hzS := hs.1 hzK
  have htot : (fun i => ((r i + (capacity i - e i - r i) : ℕ) : ℤ)) =
      fun i => ((capacity i - e i : ℕ) : ℤ) := by
    funext i
    have := hr i
    congr 1
    omega
  rw [htot] at hzS
  exact (realVector_mem_countSums_iff u _ z).1 hzS

end CoordinateConclusion
end
end Optss
