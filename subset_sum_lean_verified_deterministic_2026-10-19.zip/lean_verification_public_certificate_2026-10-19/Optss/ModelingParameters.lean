import Optss.ModelingPart
import Mathlib.Combinatorics.Additive.PluenneckeRuzsa
import Mathlib.NumberTheory.Bertrand
import Mathlib.Data.Int.Interval

/-!
# Modeling cardinalities and bounded prime parameters

The Plünnecke–Ruzsa input is discharged by mathlib's proved inequality.
Bertrand's postulate supplies actual primes with the manuscript's separation
conditions and explicit bounds in the ambient interval. These are mathematical
existence bounds; a prime-sieve implementation and its cost are separate.
-/

namespace Optss
open scoped BigOperators Pointwise

/-- The difference-set estimate in Lemma 10.2, directly from the verified
Plünnecke–Ruzsa inequality. The doubling factor may be any nonnegative rational. -/
theorem modelingDifferences_card_le (S : Finset ℤ) (hS : S.Nonempty)
    (C : ℚ≥0) (hC : ((S + S).card : ℚ≥0) ≤ C * S.card) :
    ((modelingDifferences S 8).card : ℚ≥0) ≤ C ^ 16 * S.card := by
  have h := Finset.pluennecke_ruzsa_inequality_nsmul_sub_nsmul_add hS S 8 8
  have hpos : (0 : ℚ≥0) < S.card := by exact_mod_cast Finset.card_pos.mpr hS
  have hratio : ((S + S).card : ℚ≥0) / S.card ≤ C := (div_le_iff₀ hpos).mpr hC
  change ((modelingDifferences S 8).card : ℚ≥0) ≤
    (((S + S).card : ℚ≥0) / S.card) ^ 16 * S.card at h
  exact h.trans (mul_le_mul_of_nonneg_right (pow_le_pow_left₀ (by positivity) hratio 16)
    (by positivity))

/-- Ambient-interval cardinality, independent of the small-doubling estimate. -/
theorem modelingDifferences_card_ambient (S : Finset ℤ) (u : ℕ)
    (hS : ∀ a ∈ S, 0 ≤ a ∧ a ≤ u) :
    (modelingDifferences S 8).card ≤ 16 * u + 1 := by
  have hsub : modelingDifferences S 8 ⊆ Finset.Icc (-(8 * (u : ℤ))) (8 * (u : ℤ)) := by
    intro e he
    exact Finset.mem_Icc.mpr (abs_le.mp (modelingDifferences_abs_le S 8 u hS e he))
  have hcard := Finset.card_le_card hsub
  rw [Int.card_Icc] at hcard
  omega

/-- Prime parameters exist in a linear-size ambient range, with the exact
strict separation conditions in the manuscript. -/
theorem exists_modeling_primes (S : Finset ℤ) (u : ℕ)
    (hS : ∀ a ∈ S, 0 ≤ a ∧ a ≤ u) :
    ∃ p q : ℕ, p.Prime ∧ q.Prime ∧
      8 * ((modelingDifferences S 8).card + 1) < p ∧
      p < 16 * ((modelingDifferences S 8).card + 1) ∧
      max (16 * u) (2 * p) < q ∧
      p ≤ 256 * (u + 1) ∧ q ≤ 1024 * (u + 1) := by
  let n := 8 * ((modelingDifferences S 8).card + 1)
  have hn : 0 < n := by dsimp [n]; positivity
  obtain ⟨p, hp, hnp, hp2n⟩ := Nat.exists_prime_lt_and_le_two_mul n (Nat.ne_of_gt hn)
  have hpstrict : p < 2 * n := by
    have hpne : p ≠ 2 * n := by
      intro he
      have hdiv : 2 ∣ p := ⟨n, he⟩
      have htwo := (hp.eq_one_or_self_of_dvd 2 hdiv).resolve_left (by decide)
      have hn8 : 8 ≤ n := by dsimp [n]; omega
      omega
    omega
  have hbound : p ≤ 256 * (u + 1) := by
    have hD := modelingDifferences_card_ambient S u hS
    dsimp [n] at hpstrict
    omega
  let m := max (16 * u) (2 * p)
  have hm : 0 < m := lt_of_lt_of_le (by have := hp.pos; omega) (le_max_right _ _)
  obtain ⟨q, hq, hmq, hq2m⟩ := Nat.exists_prime_lt_and_le_two_mul m (Nat.ne_of_gt hm)
  refine ⟨p, q, hp, hq, hnp, ?_, hmq, hbound, ?_⟩
  · dsimp [n] at hpstrict
    omega
  · have hmBound : m ≤ 512 * (u + 1) := by
      apply max_le <;> omega
    omega

/-- All finite modeling hypotheses can be discharged from an actual bounded
integer input. The small-doubling assumption is needed later for density/GAP
bounds, not for the existence of this finite Freiman-eight model. -/
theorem exists_bounded_large_freiman_model (S : Finset ℤ) (u : ℕ)
    (hS : ∀ a ∈ S, 0 ≤ a ∧ a ≤ u) :
    ∃ p q : ℕ, p.Prime ∧ q.Prime ∧ p ≤ 256 * (u + 1) ∧ q ≤ 1024 * (u + 1) ∧
      ∃ (lam : ZMod q) (T : Finset ℤ), lam ≠ 0 ∧ T ⊆ S ∧ S.card ≤ 8 * T.card ∧
        Set.InjOn (fun a => (modelingResidue lam a : ZMod p)) (T : Set ℤ) ∧
        (∀ a b : Fin 8 → ℤ, (∀ i, a i ∈ T) → (∀ i, b i ∈ T) →
          ((∑ i, (modelingResidue lam (a i) : ZMod p)) =
            (∑ i, (modelingResidue lam (b i) : ZMod p)) ↔
            (∑ i, a i) = (∑ i, b i))) := by
  obtain ⟨p, q, hp, hq, hplower, _, hqmin, hpbound, hqbound⟩ := exists_modeling_primes S u hS
  letI : Fact q.Prime := ⟨hq⟩
  have hqu : 8 * (u : ℤ) < q := by
    have h := (le_max_left (16 * u) (2 * p)).trans_lt hqmin
    omega
  have hpcard : ((modelingDifferences S 8).erase 0).card < p :=
    (Finset.card_erase_le).trans_lt (by omega)
  obtain ⟨lam, T, L, U, hlam, hTS, hcard, _, _, hinj, hmodel⟩ :=
    exists_large_freiman_eight_model S p q u hS hqu hpcard
  exact ⟨p, q, hp, hq, hpbound, hqbound, lam, T, hlam, hTS, hcard, hinj, hmodel⟩

/-- Small doubling supplies a uniform positive model density, with all prime
and large-part choices discharged. This is the input to the later Fourier
construction, which is not assumed or proved by this theorem. -/
theorem exists_dense_freiman_model (S : Finset ℤ) (hne : S.Nonempty) (u : ℕ)
    (hS : ∀ a ∈ S, 0 ≤ a ∧ a ≤ u) (C : ℚ≥0)
    (hC : ((S + S).card : ℚ≥0) ≤ C * S.card) :
    ∃ p q : ℕ, p.Prime ∧ q.Prime ∧ p ≤ 256 * (u + 1) ∧ q ≤ 1024 * (u + 1) ∧
      ∃ (lam : ZMod q) (T : Finset ℤ), lam ≠ 0 ∧ T ⊆ S ∧ S.card ≤ 8 * T.card ∧
        (1 / (128 * (C ^ 16 + 1)) : ℚ≥0) ≤ (T.card : ℚ≥0) / p ∧
        Set.InjOn (fun a => (modelingResidue lam a : ZMod p)) (T : Set ℤ) ∧
        (∀ a b : Fin 8 → ℤ, (∀ i, a i ∈ T) → (∀ i, b i ∈ T) →
          ((∑ i, (modelingResidue lam (a i) : ZMod p)) =
            (∑ i, (modelingResidue lam (b i) : ZMod p)) ↔
            (∑ i, a i) = (∑ i, b i))) := by
  obtain ⟨p, q, hp, hq, hplower, hpupper, hqmin, hpbound, hqbound⟩ :=
    exists_modeling_primes S u hS
  letI : Fact q.Prime := ⟨hq⟩
  have hqu : 8 * (u : ℤ) < q := by
    have h := (le_max_left (16 * u) (2 * p)).trans_lt hqmin
    omega
  have hpcard : ((modelingDifferences S 8).erase 0).card < p :=
    (Finset.card_erase_le).trans_lt (by omega)
  obtain ⟨lam, T, L, U, hlam, hTS, hcard, _, _, hinj, hmodel⟩ :=
    exists_large_freiman_eight_model S p q u hS hqu hpcard
  refine ⟨p, q, hp, hq, hpbound, hqbound, lam, T, hlam, hTS, hcard, ?_, hinj, hmodel⟩
  have hD := modelingDifferences_card_le S hne C hC
  have hS1 : (1 : ℚ≥0) ≤ S.card := by exact_mod_cast Finset.card_pos.mpr hne
  have hpU : (p : ℚ≥0) ≤ 16 * ((modelingDifferences S 8).card + 1) := by
    exact_mod_cast hpupper.le
  have hST : (S.card : ℚ≥0) ≤ 8 * T.card := by exact_mod_cast hcard
  have hdensity : (p : ℚ≥0) ≤ 128 * (C ^ 16 + 1) * T.card := by
    calc
      (p : ℚ≥0) ≤ 16 * ((modelingDifferences S 8).card + 1) := hpU
      _ ≤ 16 * (C ^ 16 * S.card + 1) := by gcongr
      _ ≤ 16 * ((C ^ 16 + 1) * S.card) := by
        apply mul_le_mul_of_nonneg_left _ (by norm_num)
        calc
          C ^ 16 * S.card + 1 ≤ C ^ 16 * S.card + S.card := add_le_add_left hS1 _
          _ = (C ^ 16 + 1) * S.card := by ring
      _ ≤ 16 * ((C ^ 16 + 1) * (8 * T.card)) := by gcongr
      _ = _ := by ring
  apply (div_le_div_iff₀ (by positivity) (by exact_mod_cast hp.pos)).mpr
  simpa only [one_mul, mul_one, mul_comm] using hdensity

end Optss
