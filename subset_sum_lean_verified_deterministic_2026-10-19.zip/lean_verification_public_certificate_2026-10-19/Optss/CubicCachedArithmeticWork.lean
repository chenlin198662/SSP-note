import Optss.BinaryCachedArithmeticWork

/-!
# Backend-independent cubic charge for cached lattice reduction

This lifts the actual fold, materialized table, sweep and loop accounting to
any exact rational backend whose four arithmetic operations satisfy a proved
cubic operand-bit bound. The backend law concerns elementary arithmetic only;
all matrix and intermediate-operand conditions are derived inside the proof.
Rounding, comparison and integer updates retain their explicitly counted
primitive costs, and container/fuel administration remain outside this charge.
-/

namespace Optss

/-- An actual exact rational evaluator together with its proved elementary
charge law. This is an interface, not an assumed lattice-reduction bound. -/
structure CubicRationalBackend where
  arithmetic : RationalArithmetic
  constant : ℕ
  positive : 0 < constant
  charge_le : ∀ (p q : ℚ) (L : ℕ), RationalBitBound p L → RationalBitBound q L →
    (arithmetic.add p q).2 ≤ constant*(L+1)^3 ∧
    (arithmetic.sub p q).2 ≤ constant*(L+1)^3 ∧
    (arithmetic.mul p q).2 ≤ constant*(L+1)^3 ∧
    (arithmetic.div p q).2 ≤ constant*(L+1)^3

/-- The already verified shift/add, division and gcd rational backend is a
concrete inhabitant of the generic charge interface. -/
def binaryCubicBackend : CubicRationalBackend where
  arithmetic := binaryRationalArithmetic
  constant := 2048
  positive := by decide
  charge_le := binaryRationalArithmetic_cubic

namespace CubicWork
open scoped BigOperators
variable {r d : ℕ}

theorem meteredProductSum_cubic_work_of_bits (backend : CubicRationalBackend) {ι : Type*} [DecidableEq ι]
    (u v : ι → ℚ) (xs : List ι) (hxs : xs.Nodup) (L : ℕ)
    (hvals : ∀ i ∈ xs, RationalBitBound (u i) L ∧ RationalBitBound (v i) L ∧
      RationalBitBound (u i*v i) L)
    (hacc : ∀ s : Finset ι, s ⊆ xs.toFinset → RationalBitBound (∑ i ∈ s, u i*v i) L) :
    (meteredProductSum backend.arithmetic u v xs).2 ≤
      2*xs.length*(backend.constant*(L+1)^3) := by
  induction xs with
  | nil => simp [meteredProductSum]
  | cons i xs ih =>
    have hhead := hvals i (List.mem_cons_self)
    have htail : xs.toFinset ⊆ (i::xs).toFinset := by
      intro j hj
      simp only [List.toFinset_cons, Finset.mem_insert]
      exact Or.inr hj
    have htailval : RationalBitBound (meteredProductSum backend.arithmetic u v xs).1 L := by
      rw [meteredProductSum_value, ← List.sum_toFinset _ (show xs.Nodup from hxs.tail)]
      exact hacc xs.toFinset htail
    have hm := (backend.charge_le (u i) (v i) L hhead.1 hhead.2.1).2.2.1
    have hp : RationalBitBound (backend.arithmetic.mul (u i) (v i)).1 L := by
      rw [backend.arithmetic.mul_value]
      exact hhead.2.2
    have ha := (backend.charge_le
      (backend.arithmetic.mul (u i) (v i)).1
      (meteredProductSum backend.arithmetic u v xs).1 L hp htailval).1
    have hi := ih hxs.tail (fun j hj => hvals j (List.mem_cons_of_mem _ hj))
      (fun s hs => hacc s (hs.trans htail))
    rw [meteredProductSum]
    simp only [List.length_cons]
    nlinarith

theorem meteredCrossDot_cubic_work (backend : CubicRationalBackend) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k j : Fin r) :
    let K := gsArithmeticBase d H (gramPotential A)
    let L := (8*(2*(r+d)+10))*K.size
    (meteredRationalDot backend.arithmetic
      (rationalGramSchmidt (rationalIntegerRows A) j) (rationalIntegerRows A k)).2 ≤
        2*d*(backend.constant*(L+1)^3) := by
  let K := gsArithmeticBase d H (gramPotential A)
  have hK : 4 ≤ K := by unfold K gsArithmeticBase; omega
  have hc : ∀ q, RationalSizeBound q (cachedOperandMagnitude r d K) →
      RationalBitBound q ((8*(2*(r+d)+10))*K.size) :=
    fun q hq => cachedOperandMagnitude_to_bits r d K hK hq
  have hvals : ∀ l ∈ (List.ofFn (id : Fin d → Fin d)),
      RationalBitBound (rationalGramSchmidt (rationalIntegerRows A) j l) ((8*(2*(r+d)+10))*K.size) ∧
      RationalBitBound (rationalIntegerRows A k l) ((8*(2*(r+d)+10))*K.size) ∧
      RationalBitBound (rationalGramSchmidt (rationalIntegerRows A) j l*rationalIntegerRows A k l)
        ((8*(2*(r+d)+10))*K.size) := by
    intro l _
    refine ⟨hc _ ((rationalGramSchmidt_size A hA H j l).mono ?_),
      hc _ ((rationalIntegerRows_size A H hH k l).mono ?_),
      hc _ ((rationalDotTerm_sizes A hA H hH k j l).1.mono ?_)⟩
    all_goals exact cachedOperandMagnitude_ge_pow r d K _ (by omega) (by omega)
  have hacc : ∀ s : Finset (Fin d), s ⊆ (List.ofFn (id : Fin d → Fin d)).toFinset →
      RationalBitBound (∑ l ∈ s, rationalGramSchmidt (rationalIntegerRows A) j l*rationalIntegerRows A k l)
        ((8*(2*(r+d)+10))*K.size) := by
    intro s _
    exact hc _ ((rationalPartialDot_cross_size A hA H hH k j s).mono
      (cachedOperandMagnitude_ge_dot r d K (by omega)))
  have hb := meteredProductSum_cubic_work_of_bits backend
    (rationalGramSchmidt (rationalIntegerRows A) j) (rationalIntegerRows A k)
    (List.ofFn id) (List.nodup_ofFn_ofInjective Function.injective_id)
    ((8*(2*(r+d)+10))*K.size) hvals hacc
  simpa only [meteredRationalDot, List.length_ofFn] using hb

def cachedWorkBound (backend : CubicRationalBackend) (r d H P : ℕ) : ℕ :=
  backend.constant*(cachedArithmeticBits r d H P+1)^3

theorem meteredSelfDot_cubic_work (backend : CubicRationalBackend) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (H : ℕ) (j : Fin r) :
    (meteredRationalDot backend.arithmetic
      (rationalGramSchmidt (rationalIntegerRows A) j) (rationalGramSchmidt (rationalIntegerRows A) j)).2 ≤
        2*d*cachedWorkBound backend r d H (gramPotential A) := by
  let K := gsArithmeticBase d H (gramPotential A)
  have hK : 4 ≤ K := by unfold K gsArithmeticBase; omega
  have hc : ∀ q, RationalSizeBound q (cachedOperandMagnitude r d K) →
      RationalBitBound q (cachedArithmeticBits r d H (gramPotential A)) :=
    fun q hq => cachedOperandMagnitude_to_bits r d K hK hq
  have hvals : ∀ l ∈ (List.ofFn (id : Fin d → Fin d)),
      RationalBitBound (rationalGramSchmidt (rationalIntegerRows A) j l) (cachedArithmeticBits r d H (gramPotential A)) ∧
      RationalBitBound (rationalGramSchmidt (rationalIntegerRows A) j l) (cachedArithmeticBits r d H (gramPotential A)) ∧
      RationalBitBound (rationalGramSchmidt (rationalIntegerRows A) j l*rationalGramSchmidt (rationalIntegerRows A) j l)
        (cachedArithmeticBits r d H (gramPotential A)) := by
    intro l _
    have hg := rationalGramSchmidt_size A hA H j l
    have hb := hc _ (hg.mono (cachedOperandMagnitude_ge_pow r d K 2 (by omega) (by omega)))
    refine ⟨hb, hb, hc _ ((hg.mul hg).mono ?_)⟩
    simpa only [← pow_add] using cachedOperandMagnitude_ge_pow r d K 4 (by omega) (by omega)
  have hacc : ∀ s : Finset (Fin d), s ⊆ (List.ofFn (id : Fin d → Fin d)).toFinset →
      RationalBitBound (∑ l ∈ s, rationalGramSchmidt (rationalIntegerRows A) j l*rationalGramSchmidt (rationalIntegerRows A) j l)
        (cachedArithmeticBits r d H (gramPotential A)) := by
    intro s _
    exact hc _ ((rationalPartialDot_self_size A hA H j s).mono
      (cachedOperandMagnitude_ge_dot r d K (by omega)))
  have hb := meteredProductSum_cubic_work_of_bits backend
    (rationalGramSchmidt (rationalIntegerRows A) j) (rationalGramSchmidt (rationalIntegerRows A) j)
    (List.ofFn id) (List.nodup_ofFn_ofInjective Function.injective_id)
    (cachedArithmeticBits r d H (gramPotential A)) hvals hacc
  simpa only [meteredRationalDot, List.length_ofFn, cachedWorkBound] using hb

theorem meteredGsCoefficient_cubic_work (backend : CubicRationalBackend) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ))
    (T : RationalGSTable r d) (k j : Fin r)
    (hT : (T.get j).get = rationalGramSchmidt (rationalIntegerRows A) j) :
    (meteredGsCoefficient backend.arithmetic (rationalIntegerRows A) T k j).2 ≤
      (4*d+1)*cachedWorkBound backend r d H (gramPotential A) := by
  rw [meteredGsCoefficient]
  simp only [hT, meteredRationalDot_value]
  have hx := meteredCrossDot_cubic_work backend A hA H hH k j
  have hy := meteredSelfDot_cubic_work backend A hA H j
  obtain ⟨hxbit,hybit⟩ := cachedDot_operands_bits A hA H hH k j
  have hdiv := (backend.charge_le _ _ _ hxbit hybit).2.2.2
  change _ ≤ (4*d+1)*cachedWorkBound backend r d H (gramPotential A)
  change _ ≤ cachedWorkBound backend r d H (gramPotential A) at hdiv
  change _ ≤ 2*d*cachedWorkBound backend r d H (gramPotential A) at hx
  nlinarith

theorem meteredProjection_cubic_work (backend : CubicRationalBackend) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r) (l : Fin d) :
    (meteredProductSum backend.arithmetic
      (fun i : Finset.Iio k => rationalGsCoefficient (rationalIntegerRows A) k i)
      (fun i => rationalGramSchmidt (rationalIntegerRows A) i l)
      (List.ofFn (lowerFinEquiv k))).2 ≤ 2*k.val*cachedWorkBound backend r d H (gramPotential A) := by
  let K := gsArithmeticBase d H (gramPotential A)
  have hK : 4 ≤ K := by unfold K gsArithmeticBase; omega
  have hvals : ∀ i ∈ List.ofFn (lowerFinEquiv k),
      RationalBitBound (rationalGsCoefficient (rationalIntegerRows A) k i)
        (cachedArithmeticBits r d H (gramPotential A)) ∧
      RationalBitBound (rationalGramSchmidt (rationalIntegerRows A) i l)
        (cachedArithmeticBits r d H (gramPotential A)) ∧
      RationalBitBound (rationalGsCoefficient (rationalIntegerRows A) k i *
        rationalGramSchmidt (rationalIntegerRows A) i l)
        (cachedArithmeticBits r d H (gramPotential A)) := by
    intro i _
    refine ⟨cachedOperandMagnitude_to_bits r d K hK
        ((rationalGsCoefficient_size A hA H hH k i).mono ?_),
      cachedOperandMagnitude_to_bits r d K hK
        ((rationalGramSchmidt_size A hA H i l).mono ?_),
      cachedOperandMagnitude_to_bits r d K hK
        ((rationalProjectionTerm_size A hA H hH k i l).mono ?_)⟩
    all_goals exact cachedOperandMagnitude_ge_pow r d K _ (by omega) (by omega)
  have hb := meteredProductSum_cubic_work_of_bits backend _ _ _
    (List.nodup_ofFn_ofInjective (lowerFinEquiv k).injective)
    (cachedArithmeticBits r d H (gramPotential A)) hvals
    (fun s _ => projectionSubtype_operands_bits A hA H hH k l s)
  simpa only [List.length_ofFn, cachedWorkBound] using hb

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

theorem meteredGSRow_cubic_work (backend : CubicRationalBackend) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (T : RationalGSTable r d) (k : Fin r)
    (hT : ∀ i : Fin r, i < k → (T.get i).get = rationalGramSchmidt (rationalIntegerRows A) i) :
    (meteredGSRow backend.arithmetic (rationalIntegerRows A) T k).2 ≤
      (k.val*(4*d+1)+d*(2*k.val+1))*cachedWorkBound backend r d H (gramPotential A) := by
  let Q := rationalIntegerRows A
  let W := cachedWorkBound backend r d H (gramPotential A)
  let coeff : Vector (ℚ × ℕ) r := Vector.ofFn fun i =>
    if i < k then meteredGsCoefficient backend.arithmetic Q T k i else (0,0)
  have hcv : ∀ i : Finset.Iio k, (coeff.get i).1 = rationalGsCoefficient Q k i := by
    intro i
    have hi : (i:Fin r) < k := Finset.mem_Iio.mp i.2
    simp only [coeff, get_ofFn, hi, ↓reduceIte, meteredGsCoefficient_value, cachedGsCoefficient,
      hT i hi, rationalGsCoefficient]
    rfl
  have htv : (fun i : Finset.Iio k => (T.get i).get) =
      (fun i : Finset.Iio k => rationalGramSchmidt Q i) := funext fun i => hT i (Finset.mem_Iio.mp i.2)
  have hc : (∑ i : Fin r, (coeff.get i).2) ≤ k.val*(4*d+1)*W := by
    calc
      _ ≤ ∑ i : Fin r, if i < k then (4*d+1)*W else 0 := by
        apply Finset.sum_le_sum
        intro i _
        simp only [coeff, get_ofFn]
        split_ifs with hi
        · exact meteredGsCoefficient_cubic_work backend A hA H hH T k i (hT i hi)
        · exact le_rfl
      _ = _ := by
        rw [← Finset.sum_filter]
        have he : Finset.univ.filter (fun i : Fin r => i < k) = Finset.Iio k := by ext i; simp
        rw [he]
        simp [Nat.mul_assoc]
  have hrow : ∀ l : Fin d,
      let acc := meteredProductSum backend.arithmetic (fun i : Finset.Iio k => (coeff.get i).1)
        (fun i => (T.get i).get l) (List.ofFn (lowerFinEquiv k))
      acc.2+(backend.arithmetic.sub (Q k l) acc.1).2 ≤ (2*k.val+1)*W := by
    intro l
    have heCoeff : (fun i : Finset.Iio k => (coeff.get i).1) =
        (fun i : Finset.Iio k => rationalGsCoefficient Q k i) := funext hcv
    have heRows : (fun i : Finset.Iio k => (T.get i).get l) =
        (fun i : Finset.Iio k => rationalGramSchmidt Q i l) := by
      funext i
      exact congrFun (congrFun htv i) l
    simp only [heCoeff, heRows]
    have hp := meteredProjection_cubic_work backend A hA H hH k l
    have hacc : RationalBitBound
        (meteredProductSum backend.arithmetic
          (fun i : Finset.Iio k => rationalGsCoefficient Q k i)
          (fun i => rationalGramSchmidt Q i l) (List.ofFn (lowerFinEquiv k))).1
        (cachedArithmeticBits r d H (gramPotential A)) := by
      rw [meteredProductSum_value, List.map_ofFn, List.sum_ofFn]
      simp only [Function.comp_apply]
      rw [Equiv.sum_comp (lowerFinEquiv k) (fun i : Finset.Iio k =>
        rationalGsCoefficient Q k i*rationalGramSchmidt Q i l)]
      exact projectionSubtype_operands_bits A hA H hH k l Finset.univ
    have hK : 4 ≤ gsArithmeticBase d H (gramPotential A) := by unfold gsArithmeticBase; omega
    have hin := cachedOperandMagnitude_to_bits r d _ hK
      ((rationalIntegerRows_size A H hH k l).mono
        (cachedOperandMagnitude_ge_pow r d _ 2 (by omega) (by omega)))
    have hsub := (backend.charge_le _ _ _ hin hacc).2.1
    change _ ≤ W at hsub
    change _ ≤ 2*k.val*W at hp
    dsimp only [Q] at *
    nlinarith
  change (∑ i : Fin r, (coeff.get i).2) + _ ≤ _
  have hr : (∑ l : Fin d,
      let acc := meteredProductSum backend.arithmetic (fun i : Finset.Iio k => (coeff.get i).1)
        (fun i => (T.get i).get l) (List.ofFn (lowerFinEquiv k))
      acc.2+(backend.arithmetic.sub (Q k l) acc.1).2) ≤ d*((2*k.val+1)*W) := by
    calc
      _ ≤ ∑ _l : Fin d, ((2*k.val+1)*W) := Finset.sum_le_sum (fun l _ => hrow l)
      _ = _ := by simp
  calc
    _ ≤ k.val*(4*d+1)*W+d*((2*k.val+1)*W) := by
      simpa only [coeff, Q, get_ofFn] using Nat.add_le_add hc hr
    _ = _ := by ring

theorem meteredGSTable_cubic_work (backend : CubicRationalBackend) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (n : ℕ) (hn : n ≤ r) :
    (meteredGSTable backend.arithmetic (rationalIntegerRows A) n hn).2 ≤
      n*(r*(4*d+1)+d*(2*r+1))*cachedWorkBound backend r d H (gramPotential A) := by
  induction n with
  | zero => simp [meteredGSTable]
  | succ n ih =>
    rw [meteredGSTable]
    have hT : ∀ i : Fin r, i < (⟨n, by omega⟩ : Fin r) →
        ((meteredGSTable backend.arithmetic (rationalIntegerRows A) n (by omega)).1.get i).get =
          rationalGramSchmidt (rationalIntegerRows A) i := by
      intro i hi
      rw [meteredGSTable_value]
      exact cachedGSTable_correct _ n (by omega) i hi
    have hr := meteredGSRow_cubic_work backend A hA H hH
      (meteredGSTable backend.arithmetic (rationalIntegerRows A) n (by omega)).1
      ⟨n, by omega⟩ hT
    have hi := ih (by omega)
    have hn' : n ≤ r := by omega
    have hm : n*(4*d+1)+d*(2*n+1) ≤ r*(4*d+1)+d*(2*r+1) := by gcongr
    have hr' := hr.trans (Nat.mul_le_mul_right (cachedWorkBound backend r d H (gramPotential A)) hm)
    nlinarith

theorem cachedWorkBound_pos (backend : CubicRationalBackend) (r d H P : ℕ) : 0 < cachedWorkBound backend r d H P := by
  unfold cachedWorkBound
  have hp := backend.positive
  positivity

theorem cachedWorkBound_mono (backend : CubicRationalBackend) (r d : ℕ) {H H' P P' : ℕ}
    (hH : H ≤ H') (hP : P ≤ P') :
    cachedWorkBound backend r d H P ≤ cachedWorkBound backend r d H' P' := by
  have hb : gsArithmeticBase d H P ≤ gsArithmeticBase d H' P' := by
    unfold gsArithmeticBase
    gcongr
  have hs := Nat.size_le_size hb
  unfold cachedWorkBound cachedArithmeticBits
  gcongr

theorem meteredReduceIntegerRow_cubic_work_of_states (backend : CubicRationalBackend) (D : IntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (hn : n ≤ k.val) (H P : ℕ)
    (hstates : ∀ B ∈ integerRowSweepTrace (integerMatrixDataRows D) k n hn,
      LinearIndependent ℝ (fun i j => (B i j:ℝ)) ∧ gramPotential B ≤ P ∧
        (∀ i j, |B i j| ≤ (H:ℤ))) :
    (meteredReduceIntegerRow backend.arithmetic D k n hn).2 ≤
      n*cachedInnerArithmeticBound r d*cachedWorkBound backend r d H P := by
  induction n generalizing D with
  | zero => simp [meteredReduceIntegerRow]
  | succ n ih =>
    let A := integerMatrixDataRows D
    have hmem : A ∈ integerRowSweepTrace A k (n+1) hn := by
      rw [integerRowSweepTrace]
      exact List.mem_cons_self
    obtain ⟨hA,hP,hH⟩ := hstates A hmem
    let j : Fin r := ⟨n, by omega⟩
    let T := (meteredGSTable backend.arithmetic (rationalIntegerRows A) r le_rfl).1
    let q := round (meteredGsCoefficient backend.arithmetic (rationalIntegerRows A) T k j).1
    let W := (meteredIntegerRowUpdate D k j q).1
    have hq : q = round (rationalGsCoefficient (rationalIntegerRows A) k j) := by
      dsimp only [q, T]
      rw [meteredGsCoefficient_value, meteredGSTable_value, cachedGsCoefficient_correct]
    have hW : integerMatrixDataRows W = Function.update A k (A k - q • A j) := by
      dsimp only [W]
      rw [meteredIntegerRowUpdate_value, integerMatrixDataRows_materialize]
    have htail : ∀ B ∈ integerRowSweepTrace (integerMatrixDataRows W) k n (by omega),
        LinearIndependent ℝ (fun i j => (B i j:ℝ)) ∧ gramPotential B ≤ P ∧
          (∀ i j, |B i j| ≤ (H:ℤ)) := by
      intro B hB
      apply hstates B
      rw [integerRowSweepTrace]
      apply List.mem_cons_of_mem
      simpa only [hW, hq] using hB
    have ht := ih W (by omega) htail
    have htable := meteredGSTable_cubic_work backend A hA H hH r le_rfl
    have hT : (T.get j).get = rationalGramSchmidt (rationalIntegerRows A) j := by
      dsimp only [T]
      rw [meteredGSTable_value]
      exact cachedGSTable_full_correct _ j
    have hc := meteredGsCoefficient_cubic_work backend A hA H hH T k j hT
    have hmono := cachedWorkBound_mono backend r d (H := H) (H' := H) le_rfl hP
    have htable' := htable.trans (Nat.mul_le_mul_left (r*(r*(4*d+1)+d*(2*r+1))) hmono)
    have hc' := hc.trans (Nat.mul_le_mul_left (4*d+1) hmono)
    have hone : 1 ≤ cachedWorkBound backend r d H P := cachedWorkBound_pos backend r d H P
    have hround : 1+2*d ≤ (1+2*d)*cachedWorkBound backend r d H P :=
      Nat.le_mul_of_pos_right _ hone
    rw [meteredReduceIntegerRow]
    simp only [meteredIntegerRowUpdate_work]
    change (meteredGSTable backend.arithmetic (rationalIntegerRows A) r le_rfl).2 +
      (meteredGsCoefficient backend.arithmetic (rationalIntegerRows A) T k j).2 + 1 + 2*d +
      (meteredReduceIntegerRow backend.arithmetic W k n (by omega)).2 ≤ _
    calc
      _ = (meteredGSTable backend.arithmetic (rationalIntegerRows A) r le_rfl).2 +
          (meteredGsCoefficient backend.arithmetic (rationalIntegerRows A) T k j).2 + (1+2*d) +
          (meteredReduceIntegerRow backend.arithmetic W k n (by omega)).2 := by omega
      _ ≤ (r*(r*(4*d+1)+d*(2*r+1)))*cachedWorkBound backend r d H P +
          (4*d+1)*cachedWorkBound backend r d H P + (1+2*d)*cachedWorkBound backend r d H P +
          n*cachedInnerArithmeticBound r d*cachedWorkBound backend r d H P :=
        Nat.add_le_add (Nat.add_le_add (Nat.add_le_add htable' hc') hround) ht
      _ = _ := by unfold cachedInnerArithmeticBound; ring

theorem meteredReduceIntegerAll_cubic_work_of_states (backend : CubicRationalBackend) (D : IntegerMatrixData r d)
    (n : ℕ) (hn : n ≤ r) (H P : ℕ)
    (hstates : ∀ (k : Fin r), k.val < n → ∀ B ∈ integerRowSweepTrace
      (rationalReduceIntegerAll (integerMatrixDataRows D) k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl,
      LinearIndependent ℝ (fun i j => (B i j:ℝ)) ∧ gramPotential B ≤ P ∧
        (∀ i j, |B i j| ≤ (H:ℤ))) :
    (meteredReduceIntegerAll backend.arithmetic D n hn).2 ≤
      n*r*cachedInnerArithmeticBound r d*cachedWorkBound backend r d H P := by
  induction n with
  | zero => simp [meteredReduceIntegerAll]
  | succ n ih =>
    have hi := ih (by omega) (fun k hk => hstates k (by omega))
    let C := (meteredReduceIntegerAll backend.arithmetic D n (by omega)).1
    have hC : integerMatrixDataRows C =
        rationalReduceIntegerAll (integerMatrixDataRows D) n (by omega) := by
      dsimp only [C]
      rw [meteredReduceIntegerAll_value, materializedReduceIntegerAll_eq,
        cachedReduceIntegerAll_eq]
    have hc := meteredReduceIntegerRow_cubic_work_of_states backend C ⟨n, by omega⟩ n le_rfl H P
      (by intro B hB; exact hstates ⟨n, by omega⟩ (by change n < n+1; omega) B (by simpa only [hC] using hB))
    have hnr : n ≤ r := by omega
    have hc' := hc.trans (Nat.mul_le_mul_right (cachedWorkBound backend r d H P)
      (Nat.mul_le_mul_right (cachedInnerArithmeticBound r d) hnr))
    rw [meteredReduceIntegerAll]
    change (meteredReduceIntegerAll backend.arithmetic D n (by omega)).2 +
      (meteredReduceIntegerRow backend.arithmetic C ⟨n, by omega⟩ n le_rfl).2 ≤ _
    calc
      _ ≤ n*r*cachedInnerArithmeticBound r d*cachedWorkBound backend r d H P +
          r*cachedInnerArithmeticBound r d*cachedWorkBound backend r d H P := Nat.add_le_add hi hc'
      _ = _ := by ring

theorem meteredReduceIntegerAll_cubic_work (backend : CubicRationalBackend) (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ)))
    (H P : ℕ) (hP : gramPotential (integerMatrixDataRows D) ≤ P)
    (hH : ∀ i j, |integerMatrixDataRows D i j| ≤ (H:ℤ)) (n : ℕ) (hn : n ≤ r) :
    (meteredReduceIntegerAll backend.arithmetic D n hn).2 ≤
      n*r*cachedInnerArithmeticBound r d*
        cachedWorkBound backend r d (sweepArithmeticHeight r d H P) P := by
  apply meteredReduceIntegerAll_cubic_work_of_states backend
  intro k hk B hB
  obtain ⟨hind,hp⟩ := outerSweep_innerTrace_independent_potential
    (integerMatrixDataRows D) hD k B hB
  refine ⟨hind, hp ▸ hP, ?_⟩
  intro i j
  have hb := outerSweep_innerTrace_all_entries (integerMatrixDataRows D) hD H hH k B hB i j
  have hm := sweepArithmeticHeight_mono r d (H := H) (H' := H) le_rfl hP
  have hbound : (B i j).natAbs ≤ sweepArithmeticHeight r d H P := hb.trans hm
  simpa only [Int.natCast_natAbs] using (show ((B i j).natAbs:ℤ) ≤ (sweepArithmeticHeight r d H P:ℤ) by exact_mod_cast hbound)

theorem meteredLovaszPair_cubic_work (backend : CubicRationalBackend) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (T : RationalGSTable r d)
    (j k : Fin r)
    (hT : ∀ i, (T.get i).get = rationalGramSchmidt (rationalIntegerRows A) i) :
    (meteredLovaszPair backend.arithmetic (rationalIntegerRows A) T j k).2 ≤
      (8*d+7)*cachedWorkBound backend r d H (gramPotential A) := by
  let Q := rationalIntegerRows A
  let K := gsArithmeticBase d H (gramPotential A)
  let L := cachedArithmeticBits r d H (gramPotential A)
  let W := cachedWorkBound backend r d H (gramPotential A)
  let u := rationalGsCoefficient Q k j
  let x := rationalDot (rationalGramSchmidt Q k) (rationalGramSchmidt Q k)
  let y := rationalDot (rationalGramSchmidt Q j) (rationalGramSchmidt Q j)
  have hK : 4 ≤ K := by unfold K gsArithmeticBase; omega
  have hc : ∀ q, RationalSizeBound q (cachedOperandMagnitude r d K) → RationalBitBound q L :=
    fun q hq => cachedOperandMagnitude_to_bits r d K hK hq
  have hu : RationalBitBound u L := hc _ ((rationalGsCoefficient_size A hA H hH k j).mono
    (cachedOperandMagnitude_ge_pow r d K 4 (by omega) (by omega)))
  have hx : RationalBitBound x L := (cachedDot_operands_bits A hA H hH k k).2
  have hy : RationalBitBound y L := (cachedDot_operands_bits A hA H hH k j).2
  have hconst : ∀ z : ℚ, RationalSizeBound z 4 → RationalBitBound z L := by
    intro z hz
    apply hc z (hz.mono _)
    exact hK.trans (by simpa only [pow_one] using
      cachedOperandMagnitude_ge_pow r d K 1 (by omega) (by omega))
  have hfour : RationalBitBound 4 L := hconst _ (by norm_num [RationalSizeBound])
  have hthree : RationalBitBound 3 L := hconst _ (by norm_num [RationalSizeBound])
  obtain ⟨huu,huy,hxy,_,_⟩ := rationalLovasz_intermediate_sizes A hA H hH j k
  have hm := cachedOperandMagnitude_ge_lovasz r d K (by omega)
  have huu' : RationalBitBound (u*u) L := hc _ (huu.mono hm)
  have huy' : RationalBitBound (u*u*y) L := hc _ (huy.mono hm)
  have hxy' : RationalBitBound (x+u*u*y) L := hc _ (hxy.mono hm)
  have c1 : (backend.arithmetic.mul u u).2 ≤ W :=
    (backend.charge_le _ _ L hu hu).2.2.1
  have c2 : (backend.arithmetic.mul (u*u) y).2 ≤ W :=
    (backend.charge_le _ _ L huu' hy).2.2.1
  have c3 : (backend.arithmetic.add x (u*u*y)).2 ≤ W :=
    (backend.charge_le _ _ L hx huy').1
  have c4 : (backend.arithmetic.mul 4 (x+u*u*y)).2 ≤ W :=
    (backend.charge_le _ _ L hfour hxy').2.2.1
  have c5 : (backend.arithmetic.mul 3 y).2 ≤ W :=
    (backend.charge_le _ _ L hthree hy).2.2.1
  have nx := meteredSelfDot_cubic_work backend A hA H k
  have ny := meteredSelfDot_cubic_work backend A hA H j
  have nc := meteredGsCoefficient_cubic_work backend A hA H hH T k j (hT j)
  have hcval : cachedGsCoefficient (rationalIntegerRows A) T k j = u := by
    dsimp only [u, Q, cachedGsCoefficient, rationalGsCoefficient]
    rw [hT j]
  rw [meteredLovaszPair]
  simp only [meteredRationalDot_value, meteredGsCoefficient_value,
    backend.arithmetic.mul_value, backend.arithmetic.add_value]
  simp only [hcval, hT]
  change _ ≤ (8*d+7)*W
  have hone : 1 ≤ W := cachedWorkBound_pos backend r d H (gramPotential A)
  have hnx : (meteredRationalDot backend.arithmetic
      (rationalGramSchmidt Q k) (rationalGramSchmidt Q k)).2 ≤ 2*d*W := nx
  have hny : (meteredRationalDot backend.arithmetic
      (rationalGramSchmidt Q j) (rationalGramSchmidt Q j)).2 ≤ 2*d*W := ny
  have hnc : (meteredGsCoefficient backend.arithmetic Q T k j).2 ≤ (4*d+1)*W := nc
  calc
    _ ≤ 2*d*W+2*d*W+(4*d+1)*W+W+W+W+W+W+W :=
      Nat.add_le_add (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add
        (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add hnx hny) hnc) c1) c2) c3) c4) c5) hone
    _ = _ := by ring

theorem meteredFailingAdjacentPairs_cubic_work (backend : CubicRationalBackend) (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |integerMatrixDataRows D i j| ≤ (H:ℤ)) :
    (meteredFailingAdjacentPairs backend.arithmetic D).2 ≤
      cachedSearchArithmeticBound r d*
        cachedWorkBound backend r d H (gramPotential (integerMatrixDataRows D)) := by
  let A := integerMatrixDataRows D
  let T := (meteredGSTable backend.arithmetic (rationalIntegerRows A) r le_rfl).1
  let W := cachedWorkBound backend r d H (gramPotential A)
  have hT : ∀ i, (T.get i).get = rationalGramSchmidt (rationalIntegerRows A) i := by
    intro i
    dsimp only [T]
    rw [meteredGSTable_value]
    exact cachedGSTable_full_correct _ i
  have ht := meteredGSTable_cubic_work backend A hD H hH r le_rfl
  have hs : (∑ j : Fin r, ∑ k : Fin r,
      if k.val = j.val+1 then
        (meteredLovaszPair backend.arithmetic (rationalIntegerRows A) T j k).2
      else 0) ≤ r*r*(8*d+7)*W := by
    calc
      _ ≤ ∑ _j : Fin r, ∑ _k : Fin r, (8*d+7)*W := by
        apply Finset.sum_le_sum
        intro j _
        apply Finset.sum_le_sum
        intro k _
        split_ifs
        · exact meteredLovaszPair_cubic_work backend A hD H hH T j k hT
        · exact Nat.zero_le _
      _ = _ := by simp; ring
  unfold meteredFailingAdjacentPairs
  simp only [get_ofFn, apply_ite Prod.snd]
  calc
    _ ≤ r*(r*(4*d+1)+d*(2*r+1))*W + r*r*(8*d+7)*W := Nat.add_le_add ht hs
    _ = _ := by unfold cachedSearchArithmeticBound; ring

theorem meteredReductionFuel_cubic_work (backend : CubicRationalBackend) (fuel : ℕ) (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ)))
    (H P : ℕ) (hP : gramPotential (integerMatrixDataRows D) ≤ P)
    (hH : ∀ i j, |integerMatrixDataRows D i j| ≤ (H:ℤ)) (hcover : r*P ≤ H) :
    (meteredReductionFuel backend.arithmetic fuel D).work ≤
      ((meteredReductionFuel backend.arithmetic fuel D).swaps+1)*
        cachedPassArithmeticBound r d*
        cachedWorkBound backend r d (sweepArithmeticHeight r d H P) P := by
  induction fuel generalizing D with
  | zero => simp [meteredReductionFuel]
  | succ n ih =>
    let C := (meteredReduceIntegerAll backend.arithmetic D r le_rfl).1
    let A := integerMatrixDataRows C
    let tests := meteredFailingAdjacentPairs backend.arithmetic C
    let W := cachedWorkBound backend r d (sweepArithmeticHeight r d H P) P
    have hCeq : C = materializedReduceIntegerAll D r le_rfl := meteredReduceIntegerAll_value _ _ _ _
    obtain ⟨hC, hpC, hhC⟩ := materializedFullSweep_invariants D hD
    rw [← hCeq] at hC hpC hhC
    have hCA : LinearIndependent ℝ (fun i j => (A i j:ℝ)) := hC
    have hpA : gramPotential A ≤ P := hpC ▸ hP
    have hHA : ∀ i j, |A i j| ≤ (H:ℤ) := by
      intro i j
      exact (hhC i j).trans (by exact_mod_cast (Nat.mul_le_mul_left r hP).trans hcover)
    have hs := meteredReduceIntegerAll_cubic_work backend D hD H P hP hH r le_rfl
    have ht := meteredFailingAdjacentPairs_cubic_work backend C hCA H hHA
    have hmono := cachedWorkBound_mono backend r d (le_sweepArithmeticHeight r d H P) hpA
    have ht' : tests.2 ≤ cachedSearchArithmeticBound r d*W :=
      ht.trans (Nat.mul_le_mul_left _ hmono)
    have hpass : (meteredReduceIntegerAll backend.arithmetic D r le_rfl).2+tests.2 ≤
        cachedPassArithmeticBound r d*W := by
      calc
        _ ≤ r*r*cachedInnerArithmeticBound r d*W+cachedSearchArithmeticBound r d*W :=
          Nat.add_le_add hs ht'
        _ = _ := by unfold cachedPassArithmeticBound; ring
    rw [meteredReductionFuel]
    split_ifs with hbad
    · let p := leastPairInFinset tests.1 hbad
      have hp : p ∈ failingAdjacentPairs A := by
        have hm := leastPairInFinset_mem tests.1 hbad
        change p ∈ tests.1 at hm
        dsimp only [tests] at hm
        rw [meteredFailingAdjacentPairs_value, cachedFailingAdjacentPairs_eq A hCA] at hm
        exact hm
      have hpair := (mem_failingAdjacentPairs A p).mp hp
      have hdec : gramPotential (swapRows A p.1 p.2) < gramPotential A :=
        gramPotential_swap_lt_of_three_quarters A hCA p.1 p.2 hpair.1 hpair.2
      have hind : LinearIndependent ℝ (fun i j => (swapRows A p.1 p.2 i j:ℝ)) :=
        hCA.comp (Equiv.swap p.1 p.2) (Equiv.swap p.1 p.2).injective
      let E := materializeIntegerMatrix (swapRows A p.1 p.2)
      have hE : LinearIndependent ℝ (fun i j => (integerMatrixDataRows E i j:ℝ)) := by
        simpa only [E, integerMatrixDataRows_materialize] using hind
      have hpE : gramPotential (integerMatrixDataRows E) ≤ P := by
        simpa only [E, integerMatrixDataRows_materialize] using hdec.le.trans hpA
      have hhE : ∀ i j, |integerMatrixDataRows E i j| ≤ (H:ℤ) := by
        intro i j
        simpa only [E, integerMatrixDataRows_materialize, swapRows] using
          hHA ((Equiv.swap p.1 p.2) i) j
      have hi := ih E hE hpE hhE
      change _ + tests.2 + (meteredReductionFuel backend.arithmetic n E).work ≤
        ((meteredReductionFuel backend.arithmetic n E).swaps+1+1)*cachedPassArithmeticBound r d*W
      calc
        _ ≤ cachedPassArithmeticBound r d*W +
            ((meteredReductionFuel backend.arithmetic n E).swaps+1)*cachedPassArithmeticBound r d*W :=
          Nat.add_le_add hpass hi
        _ = _ := by ring
    · simpa only [MeteredLatticeResult.work, MeteredLatticeResult.swaps, zero_add, one_mul] using hpass

theorem sweep_cachedWorkBound_le (backend : CubicRationalBackend) (r d H P : ℕ) :
    cachedWorkBound backend r d (sweepArithmeticHeight r d H P) P ≤
      backend.constant*(8*(2*(r+d)+10)*(2*r+4)*(sweepArithmeticBase r d H P).size+1)^3 := by
  have hs : (gsArithmeticBase d (sweepArithmeticHeight r d H P) P).size ≤
      (2*r+4)*(sweepArithmeticBase r d H P).size :=
    nat_size_le_of_le_pow (by omega) (sweepGSArithmeticBase_le_pow r d H P)
  have hb : cachedArithmeticBits r d (sweepArithmeticHeight r d H P) P ≤
      8*(2*(r+d)+10)*(2*r+4)*(sweepArithmeticBase r d H P).size := by
    unfold cachedArithmeticBits
    exact (Nat.mul_le_mul_left (8*(2*(r+d)+10)) hs).trans_eq (by ring)
  unfold cachedWorkBound
  exact Nat.mul_le_mul_left backend.constant (Nat.pow_le_pow_left (Nat.add_le_add_right hb 1) 3)

theorem meteredReductionFuel_cubic_initial_work (backend : CubicRationalBackend) (fuel : ℕ)
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) :
    (meteredReductionFuel backend.arithmetic fuel (materializeIntegerMatrix A)).work ≤
      ((materializedReductionFuel fuel (materializeIntegerMatrix A)).2+1)*
        (32*(r+1)^4*(d+1))*
        (backend.constant*(8*(2*(r+d)+10)*(2*r+4)*(loopArithmeticBase r d H (gramPotential A)).size+1)^3) := by
  have hind : LinearIndependent ℝ (fun i j =>
      (integerMatrixDataRows (materializeIntegerMatrix A) i j:ℝ)) := by
    simpa only [integerMatrixDataRows_materialize] using hA
  have hh : ∀ i j, |integerMatrixDataRows (materializeIntegerMatrix A) i j| ≤
      (max H (r*gramPotential A):ℕ) := by
    intro i j
    rw [integerMatrixDataRows_materialize]
    exact (hH i j).trans (by exact_mod_cast le_max_left H (r*gramPotential A))
  have hb := meteredReductionFuel_cubic_work backend fuel (materializeIntegerMatrix A) hind
    (max H (r*gramPotential A)) (gramPotential A)
    (by rw [integerMatrixDataRows_materialize]) hh (le_max_right _ _)
  have he := congrArg Prod.snd (meteredReductionFuel_value backend.arithmetic fuel
    (materializeIntegerMatrix A))
  change (meteredReductionFuel backend.arithmetic fuel (materializeIntegerMatrix A)).swaps =
    (materializedReductionFuel fuel (materializeIntegerMatrix A)).2 at he
  rw [he] at hb
  exact hb.trans (Nat.mul_le_mul
    (Nat.mul_le_mul_left _ (cachedPassArithmeticBound_le r d))
    (sweep_cachedWorkBound_le backend r d (max H (r*gramPotential A)) (gramPotential A)))

theorem meteredCachedData_work_le (backend : CubicRationalBackend) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) :
    (meteredCachedData backend.arithmetic A).work ≤
      ((cachedReductionData A).2+1)*(32*(r+1)^4*(d+1))*
        (backend.constant*(8*(2*(r+d)+10)*(2*r+4)*(loopArithmeticBase r d H (gramPotential A)).size+1)^3) := by
  rw [meteredCachedData_def, cachedReductionData_def]
  exact meteredReductionFuel_cubic_initial_work backend _ A hA H hH

theorem meteredCachedData_input_polynomial (backend : CubicRationalBackend) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) :
    (meteredCachedData backend.arithmetic A).work ≤
      (3*(r*(r+1)+1)*(r.size+d.size+2*H.size+4))*(32*(r+1)^4*(d+1))*
        (backend.constant*(8*(2*(r+d)+10)*(2*r+4)*
          (3*H.size+5*r.size+2*d.size+
            8*(r*(r+1)+1)*(r.size+d.size+2*H.size+4)+12)+1)^3) := by
  have hb := meteredCachedData_work_le backend A hA H hH
  have hs := (cachedIntegerReduction A hA).swapCount_input_bits A H hH
  have hbits := globalSweepArithmeticBase_input_bits A H hH
  change (cachedReductionData A).2+1 ≤ _ at hs
  change (loopArithmeticBase r d H (gramPotential A)).size ≤ _ at hbits
  apply hb.trans
  apply Nat.mul_le_mul
  · exact Nat.mul_le_mul_right _ hs
  · exact Nat.mul_le_mul_left backend.constant (Nat.pow_le_pow_left
      (Nat.add_le_add_right (Nat.mul_le_mul_left _ hbits) 1) 3)

end CubicWork
end Optss
