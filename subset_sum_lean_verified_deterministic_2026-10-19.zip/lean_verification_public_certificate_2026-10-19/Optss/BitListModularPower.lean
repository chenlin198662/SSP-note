import Optss.BitListMultiplication
import Optss.BitListDivision
import Mathlib.FieldTheory.Finite.Basic

/-!
# Modular exponentiation on Boolean lists

The exponent is consumed one bit at a time. Each recursive answer is squared,
reduced with Boolean long division, and conditionally multiplied by the input.
All arithmetic answers are computed by the existing Boolean circuits.
-/
namespace Optss

def bitListModMul (xs ys qs : List Bool) : List Bool :=
  (bitListDivision (bitListMultiplication xs ys) qs).remainder

theorem bitListModMul_correct (xs ys qs : List Bool) (hq : 0<binaryDigitsValue qs) :
    binaryDigitsValue (bitListModMul xs ys qs)=
      binaryDigitsValue xs*binaryDigitsValue ys%binaryDigitsValue qs := by
  rw [bitListModMul,(bitListDivision_correct _ _ hq).2,bitListMultiplication_correct]

theorem bitListModMul_encoding (xs ys qs : List Bool) (hq : 0<binaryDigitsValue qs) :
    bitListModMul xs ys qs=
      (binaryDigitsValue xs*binaryDigitsValue ys%binaryDigitsValue qs).bits := by
  rw [bitListModMul,(bitListDivision_encodings _ _ hq).2,bitListMultiplication_correct]

theorem bitListModMul_width (xs ys qs : List Bool) (hq : 0<binaryDigitsValue qs) :
    (bitListModMul xs ys qs).length≤qs.length := by
  rw [bitListModMul_encoding xs ys qs hq,Nat.size_eq_bits_len]
  exact (Nat.size_le_size (Nat.mod_lt _ hq).le).trans
    (Nat.size_le.mpr (binaryDigitsValue_lt_pow qs))

def bitListModPow (xs qs : List Bool) : List Bool → List Bool
  | [] => (bitListDivision [true] qs).remainder
  | b::bs =>
    let prev := bitListModPow xs qs bs
    let sq := bitListModMul prev prev qs
    if b then bitListModMul sq xs qs else sq

theorem bitListModPow_correct (xs qs es : List Bool) (hq : 0<binaryDigitsValue qs) :
    binaryDigitsValue (bitListModPow xs qs es)=
      binaryDigitsValue xs^binaryDigitsValue es%binaryDigitsValue qs := by
  induction es with
  | nil => simp [bitListModPow,(bitListDivision_correct _ _ hq).2,binaryDigitsValue]
  | cons b bs ih =>
    cases b <;> simp only [bitListModPow,Bool.false_eq_true,if_false,if_true,
      bitListModMul_correct _ _ _ hq,ih,binaryDigitsValue,Bool.toNat_false,
      Bool.toNat_true,add_zero,pow_add,pow_one]
    all_goals
      rw [show 2*binaryDigitsValue bs=binaryDigitsValue bs+binaryDigitsValue bs by omega,
        pow_add]
      simp only [Nat.mul_mod,Nat.mod_mod]

theorem bitListModPow_width (xs qs es : List Bool) (hq : 0<binaryDigitsValue qs) :
    (bitListModPow xs qs es).length≤qs.length := by
  cases es with
  | nil =>
    rw [bitListModPow,(bitListDivision_encodings _ _ hq).2,Nat.size_eq_bits_len]
    exact (Nat.size_le_size (Nat.mod_lt _ hq).le).trans
      (Nat.size_le.mpr (binaryDigitsValue_lt_pow qs))
  | cons b bs =>
    cases b <;> simp only [bitListModPow,Bool.false_eq_true,if_false,if_true] <;>
      exact bitListModMul_width _ _ _ hq

/-- Fermat inversion uses a logarithmic-length exponent; no search over residues. -/
def bitListPrimeInverse (xs : List Bool) (q : ℕ) : List Bool :=
  bitListModPow xs q.bits (q-2).bits

theorem bitListPrimeInverse_correct (xs : List Bool) (q : ℕ) [Fact q.Prime]
    (hx : (binaryDigitsValue xs : ZMod q)≠0) :
    (binaryDigitsValue (bitListPrimeInverse xs q) : ZMod q)=
      (binaryDigitsValue xs : ZMod q)⁻¹ := by
  have hq := (Fact.out : q.Prime).pos
  have hq2 := (Fact.out : q.Prime).two_le
  have hv := bitListModPow_correct xs q.bits (q-2).bits
    (by simpa only [binaryDigitsValue_bits] using hq)
  simp only [binaryDigitsValue_bits] at hv
  rw [bitListPrimeInverse,hv,ZMod.natCast_mod,Nat.cast_pow]
  apply (mul_left_cancel₀ hx)
  rw [mul_inv_cancel₀ hx,←pow_succ']
  convert ZMod.pow_card_sub_one_eq_one hx using 1 <;> congr 1 <;> omega

end Optss
