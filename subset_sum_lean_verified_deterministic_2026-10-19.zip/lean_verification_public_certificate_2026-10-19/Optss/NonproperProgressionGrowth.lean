import Optss.ProperizationExistence

/-!
# A growth-degree drop when a progression loses properness

A genuine short integer relation produces a containing progression of smaller
rank by the already proved primitive quotient and lattice-boxing construction.
Consequently a proper symmetric integer GAP whose double is not proper has
repeated-sumset growth of degree at most `rank - 1`.

This is the symmetric integer-box case of Conlon--Fox--Pham, Corollary 2.21:
https://www.its.caltech.edu/~dconlon/subset_sums_highdim.pdf.
The proof uses the verified lattice quotient directly, without assuming
Bilu's theorem or any unproved progression-existence assertion.
-/
namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {G : Type*} [AddCommGroup G] [IsAddTorsionFree G]

/-- One failed properness test gives actual smaller-rank containing data,
including zero-width coordinate removal and a dimension-only volume factor. -/
theorem exists_smaller_progression_of_nonproper {d : ℕ} (ρ : IntVec d →+ G)
    (β : Fin d → ℕ) (t : ℕ)
    (hbad : ¬ Set.InjOn ρ (integerBudgetBox (fun j => t * β j))) :
    ∃ r < d, ∃ (ρ' : IntVec r →+ G) (γ : Fin r → ℕ),
      integerProgressionValues ρ β ⊆ integerProgressionValues ρ' γ ∧
      (integerBudgetBox γ).card ≤
        properizationIterationFactor latticeReductionDefectBound t d *
          (integerBudgetBox β).card := by
  let e := Fintype.card (PositiveCoordinate β)
  let ρ₀ := positiveProgressionHom ρ β
  let β₀ := positiveBudget β
  have he : e ≤ d := positiveCoordinate_count_le β
  have hβ₀ : ∀ j, 1 ≤ β₀ j := fun j => positiveBudget_pos β j
  have hvalues : integerProgressionValues ρ β = integerProgressionValues ρ₀ β₀ := by
    simpa only [one_mul] using positiveProgression_values ρ β 1
  have hcard₀ : (integerBudgetBox β₀).card = (integerBudgetBox β).card := by
    simpa only [one_mul] using (scaledBox_positive_card β 1).symm
  have hbad₀ : ¬ Set.InjOn ρ₀ (integerBudgetBox (fun j => t * β₀ j)) := by
    intro hg
    exact hbad ((positiveProgression_proper_iff ρ β t).mpr hg)
  obtain ⟨ρ', γ, hdrop, hcont, hcard⟩ := positiveProgression_rank_step
    latticeReductionDefectBound t d latticeReductionDefectBound_pos
    (fun k _ => rationalReductionProperty_bounded k) he ρ₀ β₀ hβ₀ hbad₀
  exact ⟨e-1, hdrop.trans_le he, ρ', γ, hvalues ▸ hcont, hcard₀ ▸ hcard⟩

/-- Repeated sums of coefficient vectors stay in the integer dilation. -/
theorem nsmul_integerBudgetBox_subset {d : ℕ} (β : Fin d → ℕ) (k : ℕ) :
    k • integerBudgetBox β ⊆ integerBudgetBox (fun j => k * β j) := by
  intro x hx
  apply (mem_integerBudgetBox _ x).mpr
  exact repeatedSumset_in_box β (integerBudgetBox β)
    (fun y hy => (mem_integerBudgetBox β y).mp hy) k x hx

omit [IsAddTorsionFree G] in
/-- The image bound needs no properness at the larger scale. -/
theorem nsmul_integerProgression_card_le {d : ℕ} (ρ : IntVec d →+ G)
    (β : Fin d → ℕ) (k : ℕ) (hk : 1 ≤ k) :
    (k • integerProgressionValues ρ β).card ≤ k ^ d * (integerBudgetBox β).card := by
  have hsub : k • integerProgressionValues ρ β ⊆
      integerProgressionValues ρ (fun j => k * β j) := by
    unfold integerProgressionValues
    rw [← Finset.image_nsmul]
    exact Finset.image_subset_image (nsmul_integerBudgetBox_subset β k)
  calc
    (k • integerProgressionValues ρ β).card ≤
        (integerProgressionValues ρ (fun j => k * β j)).card := Finset.card_le_card hsub
    _ ≤ (integerBudgetBox (fun j => k * β j)).card := Finset.card_image_le
    _ ≤ k ^ d * (integerBudgetBox β).card := by
      rw [integerBudgetBox_card, integerBudgetBox_card]
      calc
        (∏ j : Fin d, (2 * (k * β j) + 1)) ≤ ∏ j : Fin d, (k * (2 * β j + 1)) := by
          apply Finset.prod_le_prod'
          intro j _
          nlinarith
        _ = _ := by simp [Finset.prod_mul_distrib]

/-- The exact growth-degree drop, with all smaller-rank existence hypotheses
discharged. This works for any torsion-free additive commutative target. -/
theorem nonproper_integerProgression_growth {d : ℕ} (ρ : IntVec d →+ G)
    (β : Fin d → ℕ) (t k : ℕ) (hk : 1 ≤ k)
    (hproper : Set.InjOn ρ (integerBudgetBox β))
    (hbad : ¬ Set.InjOn ρ (integerBudgetBox (fun j => t * β j))) :
    (k • integerProgressionValues ρ β).card ≤
      k ^ (d - 1) * properizationIterationFactor latticeReductionDefectBound t d *
        (integerProgressionValues ρ β).card := by
  obtain ⟨r, hr, ρ', γ, hcont, hvol⟩ := exists_smaller_progression_of_nonproper ρ β t hbad
  have hcard : (integerBudgetBox β).card = (integerProgressionValues ρ β).card :=
    (Finset.card_image_of_injOn hproper).symm
  calc
    (k • integerProgressionValues ρ β).card ≤
        (k • integerProgressionValues ρ' γ).card :=
      Finset.card_le_card (Finset.nsmul_subset_nsmul_left hcont)
    _ ≤ k ^ r * (integerBudgetBox γ).card := nsmul_integerProgression_card_le ρ' γ k hk
    _ ≤ k ^ r * (properizationIterationFactor latticeReductionDefectBound t d *
        (integerBudgetBox β).card) := Nat.mul_le_mul_left _ hvol
    _ ≤ k ^ (d - 1) * (properizationIterationFactor latticeReductionDefectBound t d *
        (integerBudgetBox β).card) := by
      apply Nat.mul_le_mul_right
      exact Nat.pow_le_pow_right (by omega) (by omega)
    _ = _ := by rw [hcard, mul_assoc]

/-- A uniform constant for every proper symmetric rank-`d` integer GAP whose
geometric double fails properness. It also covers zero coordinates and rank
zero (where the failure hypothesis cannot hold). -/
theorem exists_nonproper_progression_growth_constant (d : ℕ) :
    ∃ C : ℕ, 0 < C ∧ ∀ (ρ : IntVec d →+ G) (β : Fin d → ℕ),
      Set.InjOn ρ (integerBudgetBox β) →
      (¬ Set.InjOn ρ (integerBudgetBox (fun j => 2 * β j))) →
      ∀ k : ℕ, 1 ≤ k → (k • integerProgressionValues ρ β).card ≤
        C * k ^ (d - 1) * (integerProgressionValues ρ β).card := by
  refine ⟨properizationIterationFactor latticeReductionDefectBound 2 d,
    by have := properizationIterationFactor_pos latticeReductionDefectBound 2 d; omega, ?_⟩
  intro ρ β hproper hbad k hk
  simpa only [mul_comm, mul_left_comm, mul_assoc] using
    nonproper_integerProgression_growth ρ β 2 k hk hproper hbad

/-- The coefficient box `[0, β₁] × ... × [0, β_d]` used in a general
translated GAP. Its side cardinalities are `β_j + 1`. -/
def nonnegativeIntegerBox {d : ℕ} (β : Fin d → ℕ) : Finset (IntVec d) :=
  Fintype.piFinset (fun j => Finset.Icc 0 (β j : ℤ))

@[simp] theorem mem_nonnegativeIntegerBox {d : ℕ} (β : Fin d → ℕ) (x : IntVec d) :
    x ∈ nonnegativeIntegerBox β ↔ ∀ j, 0 ≤ x j ∧ x j ≤ (β j : ℤ) := by
  simp [nonnegativeIntegerBox, Fintype.mem_piFinset]

theorem nonnegativeIntegerBox_card {d : ℕ} (β : Fin d → ℕ) :
    (nonnegativeIntegerBox β).card = ∏ j, (β j + 1) := by
  rw [nonnegativeIntegerBox, Fintype.card_piFinset]
  apply Finset.prod_congr rfl
  intro j _
  rw [Int.card_Icc]
  omega

/-- Symmetric enclosure costs at most `2^d` in coefficient volume. -/
theorem symmetricBox_card_le_nonnegative {d : ℕ} (β : Fin d → ℕ) :
    (integerBudgetBox β).card ≤ 2 ^ d * (nonnegativeIntegerBox β).card := by
  rw [integerBudgetBox_card, nonnegativeIntegerBox_card]
  calc
    (∏ j : Fin d, (2 * β j + 1)) ≤ ∏ j : Fin d, (2 * (β j + 1)) := by
      apply Finset.prod_le_prod'
      intro j _
      omega
    _ = _ := by simp [Finset.prod_mul_distrib]

omit [IsAddTorsionFree G] in
/-- A collision in the doubled nonnegative box is a short kernel vector for
its symmetric enclosure. This is an actual relation, not a rank assumption. -/
theorem nonnegative_double_nonproper_symmetric {d : ℕ} (ρ : IntVec d →+ G)
    (β : Fin d → ℕ)
    (hbad : ¬ Set.InjOn ρ (nonnegativeIntegerBox (fun j => 2 * β j))) :
    ¬ Set.InjOn ρ (integerBudgetBox β) := by
  intro hp
  apply hbad
  intro x hx y hy he
  have hx' := (mem_nonnegativeIntegerBox _ x).mp hx
  have hy' := (mem_nonnegativeIntegerBox _ y).mp hy
  have hker := (integerBox_proper_iff_no_short_kernel ρ β).mp hp
  have hzero : x - y = 0 := by
    apply hker
    · rw [mem_integerBudgetBox]
      intro j
      have hxi := hx' j
      have hyi := hy' j
      simp only [Pi.sub_apply, Nat.cast_mul, Nat.cast_ofNat] at *
      rw [abs_le]
      omega
    · rw [map_sub, he, sub_self]
  exact sub_eq_zero.mp hzero

/-- General translated GAPs, with arbitrary generators and side lengths.
This notation separates the affine translation from the additive encoding. -/
def affineIntegerProgression {d : ℕ} (ρ : IntVec d →+ G) (z : G)
    (β : Fin d → ℕ) : Finset G := {z} + (nonnegativeIntegerBox β).image ρ

omit [IsAddTorsionFree G] in
theorem affineIntegerProgression_card {d : ℕ} (ρ : IntVec d →+ G) (z : G)
    (β : Fin d → ℕ) (hp : Set.InjOn ρ (nonnegativeIntegerBox β)) :
    (affineIntegerProgression ρ z β).card = (nonnegativeIntegerBox β).card := by
  rw [affineIntegerProgression, Finset.card_singleton_add, Finset.card_image_of_injOn hp]

/-- The full translated integer-box form of the growth drop in CFP 2.21.
There is no symmetry or minimum-width assumption on the input progression. -/
theorem nonproper_affineIntegerProgression_growth {d : ℕ} (ρ : IntVec d →+ G)
    (z : G) (β : Fin d → ℕ) (k : ℕ) (hk : 1 ≤ k)
    (hproper : Set.InjOn ρ (nonnegativeIntegerBox β))
    (hbad : ¬ Set.InjOn ρ (nonnegativeIntegerBox (fun j => 2 * β j))) :
    (k • affineIntegerProgression ρ z β).card ≤
      (2 ^ d * properizationIterationFactor latticeReductionDefectBound 1 d) *
        k ^ (d - 1) * (affineIntegerProgression ρ z β).card := by
  have hb := nonnegative_double_nonproper_symmetric ρ β hbad
  obtain ⟨r, hr, ρ', γ, hcont, hvol⟩ := exists_smaller_progression_of_nonproper ρ β 1
    (by simpa only [one_mul] using hb)
  have hsub : (nonnegativeIntegerBox β).image ρ ⊆ integerProgressionValues ρ' γ := by
    apply Finset.Subset.trans _ hcont
    apply Finset.image_subset_image
    intro x hx
    have hxi := (mem_nonnegativeIntegerBox β x).mp hx
    rw [mem_integerBudgetBox]
    intro j
    rw [abs_of_nonneg (hxi j).1]
    exact (hxi j).2
  have hcard := symmetricBox_card_le_nonnegative β
  have hpower : k ^ r ≤ k ^ (d - 1) := Nat.pow_le_pow_right (by omega) (by omega)
  calc
    (k • affineIntegerProgression ρ z β).card =
        (k • (nonnegativeIntegerBox β).image ρ).card := by
      rw [affineIntegerProgression, nsmul_add, Finset.nsmul_singleton,
        Finset.card_singleton_add]
    _ ≤ (k • integerProgressionValues ρ' γ).card :=
      Finset.card_le_card (Finset.nsmul_subset_nsmul_left hsub)
    _ ≤ k ^ r * (integerBudgetBox γ).card := nsmul_integerProgression_card_le ρ' γ k hk
    _ ≤ k ^ (d - 1) *
        (properizationIterationFactor latticeReductionDefectBound 1 d *
          (2 ^ d * (nonnegativeIntegerBox β).card)) :=
      Nat.mul_le_mul hpower (hvol.trans (Nat.mul_le_mul_left _ hcard))
    _ = _ := by rw [affineIntegerProgression_card ρ z β hproper]; ring

/-- Uniformly quantified version for every rank-`d` translated integer GAP. -/
theorem exists_nonproper_affine_growth_constant (d : ℕ) :
    ∃ C : ℕ, 0 < C ∧ ∀ (ρ : IntVec d →+ G) (z : G) (β : Fin d → ℕ),
      Set.InjOn ρ (nonnegativeIntegerBox β) →
      (¬ Set.InjOn ρ (nonnegativeIntegerBox (fun j => 2 * β j))) →
      ∀ k : ℕ, 1 ≤ k → (k • affineIntegerProgression ρ z β).card ≤
        C * k ^ (d - 1) * (affineIntegerProgression ρ z β).card := by
  refine ⟨2 ^ d * properizationIterationFactor latticeReductionDefectBound 1 d, ?_, ?_⟩
  · have := properizationIterationFactor_pos latticeReductionDefectBound 1 d
    positivity
  · intro ρ z β hp hb k hk
    exact nonproper_affineIntegerProgression_growth ρ z β k hk hp hb

end
end Optss
