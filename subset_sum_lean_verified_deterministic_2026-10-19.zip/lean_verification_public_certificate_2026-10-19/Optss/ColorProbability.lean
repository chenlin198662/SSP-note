import Optss.Basic
import Mathlib.Probability.Distributions.Uniform
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Nat.Choose.Cast
import Mathlib.Analysis.SpecialFunctions.Log.Base

/-!
# Finite uniform color-coding probabilities

The sample space consists of all functions from labelled items to colors.
Every such function has equal probability. Product/cylinder counting below
verifies the independence of coordinate colors and of repeated experiments.
-/
namespace Optss
noncomputable section
open scoped BigOperators
open MeasureTheory

/-- Probability of an event under uniform sampling of a finite nonempty space.
The PMF identification below supplies its conventional probability semantics. -/
def uniformProbability {Ω : Type*} [Fintype Ω] (A : Finset Ω) : ℝ :=
  (A.card : ℝ) / Fintype.card Ω

theorem uniformProbability_eq_uniformPMF {Ω : Type*} [Fintype Ω] [Nonempty Ω]
    (A : Finset Ω) : uniformProbability A =
      ((PMF.uniformOfFintype Ω).toOuterMeasure (A : Set Ω)).toReal := by
  rw [PMF.toOuterMeasure_uniformOfFintype_apply]
  simp [uniformProbability, ENNReal.toReal_div]

theorem uniformProbability_nonneg {Ω : Type*} [Fintype Ω] (A : Finset Ω) :
    0 ≤ uniformProbability A := by unfold uniformProbability; positivity

theorem uniformProbability_mono {Ω : Type*} [Fintype Ω] {A B : Finset Ω} (h : A ⊆ B) :
    uniformProbability A ≤ uniformProbability B := by
  apply div_le_div_of_nonneg_right _ (by positivity)
  exact_mod_cast Finset.card_le_card h

@[simp] theorem uniformProbability_univ {Ω : Type*} [Fintype Ω] [Nonempty Ω] :
    uniformProbability (Finset.univ : Finset Ω) = 1 := by
  simp [uniformProbability, Fintype.card_ne_zero]

theorem uniformProbability_biUnion_le {Ω ι : Type*} [Fintype Ω] [DecidableEq Ω]
    (S : Finset ι) (A : ι → Finset Ω) :
    uniformProbability (S.biUnion A) ≤ ∑ i ∈ S, uniformProbability (A i) := by
  unfold uniformProbability
  rw [← Finset.sum_div]
  apply div_le_div_of_nonneg_right _ (by positivity)
  exact_mod_cast (Finset.card_biUnion_le (s := S) (t := A))

/-- Under the uniform distribution on all functions, coordinate events have
product probabilities. This proves independence, rather than postulating it. -/
theorem uniformProbability_pi {ι : Type*} {Ω : ι → Type*} [Fintype ι]
    [∀ i, Fintype (Ω i)] [DecidableEq ι] (A : ∀ i, Finset (Ω i)) :
    uniformProbability (Fintype.piFinset A) = ∏ i, uniformProbability (A i) := by
  simp only [uniformProbability, Fintype.card_piFinset, Fintype.card_pi,
    Nat.cast_prod, Finset.prod_div_distrib]

/-- The exact product rule for independent repetitions of one finite event. -/
theorem uniformProbability_repetitions {Ω : Type*} [Fintype Ω] (A : Finset Ω) (R : ℕ) :
    uniformProbability (Fintype.piFinset (fun _ : Fin R => A)) = (uniformProbability A)^R := by
  rw [uniformProbability_pi]
  simp

/-- Removing the second coordinate of a prescribed collision gives a bijection
with arbitrary colorings of the remaining labels. -/
def collisionEquiv {ι κ : Type*} [DecidableEq ι] (i j : ι) (hij : i ≠ j) :
    {f : ι → κ // f i = f j} ≃ ({x : ι // x ≠ j} → κ) where
  toFun f x := f.1 x.1
  invFun g := ⟨fun x => if h : x = j then g ⟨i,hij⟩ else g ⟨x,h⟩, by simp [hij]⟩
  left_inv f := by
    apply Subtype.ext
    funext x
    by_cases hx : x = j
    · subst x
      simpa using f.2
    · simp [hx]
  right_inv g := by
    funext x
    simp [x.property]

/-- A prescribed pair collision has exactly `q^(m-1)` samples. -/
theorem card_pair_collision {ι κ : Type*} [Fintype ι] [Fintype κ] [DecidableEq κ] [DecidableEq ι]
    (i j : ι) (hij : i ≠ j) :
    Fintype.card {f : ι → κ // f i = f j} = Fintype.card κ ^ (Fintype.card ι - 1) := by
  classical
  rw [Fintype.card_congr (collisionEquiv i j hij), Fintype.card_fun]
  have hc : Fintype.card {x : ι // x ≠ j} = Fintype.card ι - 1 := by
    simp [Fintype.card_subtype_compl (fun x : ι => x = j)]
  rw [hc]

/-- Pair-collision probability is exactly `1/q` under the actual uniform
function sample space. -/
theorem uniform_pair_collision {ι : Type*} [Fintype ι] [DecidableEq ι]
    (q : ℕ) (hq : 0 < q) (i j : ι) (hij : i ≠ j) :
    uniformProbability (Finset.univ.filter (fun f : ι → Fin q => f i = f j)) = 1 / q := by
  classical
  unfold uniformProbability
  rw [← Fintype.card_subtype, card_pair_collision i j hij, Fintype.card_fin,
    Fintype.card_fun, Fintype.card_fin]
  have hm : 0 < Fintype.card ι := Fintype.card_pos_iff.mpr ⟨i⟩
  have he : Fintype.card ι = (Fintype.card ι - 1)+1 := by omega
  rw [he, pow_succ]
  have hq' : (q : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hq)
  push_cast
  field_simp


/-- Colorings in which the fixed labelled witness suffers a collision. -/
def collisionEvent {ι : Type*} [Fintype ι] (S : Finset ι) (q : ℕ) : Finset (ι → Fin q) := by
  classical
  exact Finset.univ.filter (fun f => ¬ Set.InjOn f (S : Set ι))

@[simp] theorem mem_collisionEvent {ι : Type*} [Fintype ι] (S : Finset ι) (q : ℕ) (f : ι → Fin q) :
    f ∈ collisionEvent S q ↔ ¬ Set.InjOn f (S : Set ι) := by
  classical
  simp [collisionEvent]

/-- Exact birthday union bound for any fixed witness among the labelled items. -/
theorem uniform_collision_bound {ι : Type*} [Fintype ι] [DecidableEq ι]
    (S : Finset ι) (q : ℕ) (hq : 0 < q) :
    uniformProbability (collisionEvent S q) ≤ (S.card.choose 2 : ℝ) / q := by
  classical
  have hsub : collisionEvent S q ⊆ (S.powersetCard 2).biUnion (fun P => collisionEvent P q) := by
    intro f hf
    have hnot := (mem_collisionEvent S q f).mp hf
    unfold Set.InjOn at hnot
    push_neg at hnot
    obtain ⟨i, hi, j, hj, he, hne⟩ := hnot
    apply Finset.mem_biUnion.mpr
    refine ⟨{i,j}, Finset.mem_powersetCard.mpr ⟨?_, by simp [hne]⟩, ?_⟩
    · rw [Finset.insert_subset_iff, Finset.singleton_subset_iff]
      exact ⟨hi,hj⟩
    · simpa [collisionEvent, hne] using he
  have hp : ∀ P ∈ S.powersetCard 2, uniformProbability (collisionEvent P q) = 1/q := by
    intro P hP
    obtain ⟨i,j,hij,rfl⟩ := Finset.card_eq_two.mp (Finset.mem_powersetCard.mp hP).2
    have hevent : collisionEvent {i,j} q = Finset.univ.filter (fun f : ι → Fin q => f i = f j) := by
      ext f
      simp [collisionEvent, hij]
    rw [hevent]
    exact uniform_pair_collision q hq i j hij
  calc
    uniformProbability (collisionEvent S q) ≤
        uniformProbability ((S.powersetCard 2).biUnion (fun P => collisionEvent P q)) :=
      uniformProbability_mono hsub
    _ ≤ ∑ P ∈ S.powersetCard 2, uniformProbability (collisionEvent P q) :=
      uniformProbability_biUnion_le _ _
    _ = _ := by simp_rw [Finset.sum_congr rfl hp]; simp [Finset.card_powersetCard, div_eq_mul_inv]

/-- The numeric specialization in Appendix A.2: at most `8L` witness items
and exactly `128L²` colors give collision probability at most `1/4`. -/
theorem uniform_collision_quarter {ι : Type*} [Fintype ι] [DecidableEq ι]
    (S : Finset ι) (L : ℕ) (hL : 0 < L) (hS : S.card ≤ 8*L) :
    uniformProbability (collisionEvent S (128*L^2)) ≤ 1/4 := by
  have hq : 0 < 128*L^2 := by positivity
  apply (uniform_collision_bound S _ hq).trans
  have hL' : (0 : ℝ) < L := by exact_mod_cast hL
  have hS' : (S.card : ℝ) ≤ 8*L := by exact_mod_cast hS
  rw [Nat.cast_choose_two]
  push_cast
  apply (div_le_iff₀ (by positivity : (0 : ℝ) < 128*(L : ℝ)^2)).mpr
  have hsquare := mul_self_le_mul_self (by positivity : (0 : ℝ) ≤ S.card) hS'
  nlinarith

/-- All independent color repetitions fail with probability at most `4⁻ᴿ`. -/
theorem uniform_repeated_collision_bound {ι : Type*} [Fintype ι] [DecidableEq ι]
    (S : Finset ι) (L R : ℕ) (hL : 0 < L) (hS : S.card ≤ 8*L) :
    uniformProbability (Fintype.piFinset (fun _ : Fin R => collisionEvent S (128*L^2))) ≤
      (1/4 : ℝ)^R := by
  rw [uniformProbability_repetitions]
  exact pow_le_pow_left₀ (uniformProbability_nonneg _) (uniform_collision_quarter S L hL hS) R

/-- A cylinder event in the independent uniform product sample space. -/
def coordinateEvent {ρ Ω : Type*} [Fintype ρ] [Fintype Ω] (i : ρ) (A : Finset Ω) :
    Finset (ρ → Ω) := by
  classical
  exact Finset.univ.filter (fun f => f i ∈ A)

/-- A single coordinate has its original uniform distribution inside the
uniform function sample space. -/
theorem uniformProbability_coordinateEvent {ρ Ω : Type*} [Fintype ρ] [Fintype Ω]
    [DecidableEq ρ] [Nonempty Ω] (i : ρ) (A : Finset Ω) :
    uniformProbability (coordinateEvent i A) = uniformProbability A := by
  classical
  have he : coordinateEvent i A = Fintype.piFinset (fun j => if j=i then A else Finset.univ) := by
    ext f
    simp only [coordinateEvent, Finset.mem_filter, Finset.mem_univ, true_and, Fintype.mem_piFinset]
    constructor
    · intro hf j
      by_cases hji : j=i
      · subst j
        simpa using hf
      · simp [hji]
    · intro hf
      simpa using hf i
  rw [he, uniformProbability_pi]
  simp_rw [apply_ite uniformProbability, uniformProbability_univ]
  simp

/-- The event that at least one coordinate belongs to its prescribed event. -/
def anyCoordinateEvent {ρ Ω : Type*} [Fintype ρ] [Fintype Ω]
    (A : ρ → Finset Ω) : Finset (ρ → Ω) := by
  classical
  exact Finset.univ.biUnion (fun i => coordinateEvent i (A i))

@[simp] theorem mem_anyCoordinateEvent {ρ Ω : Type*} [Fintype ρ] [Fintype Ω]
    (A : ρ → Finset Ω) (f : ρ → Ω) :
    f ∈ anyCoordinateEvent A ↔ ∃ i, f i ∈ A i := by
  classical
  simp [anyCoordinateEvent, coordinateEvent]

theorem uniformProbability_anyCoordinateEvent_le {ρ Ω : Type*}
    [Fintype ρ] [Fintype Ω] [DecidableEq ρ] [Nonempty Ω] (A : ρ → Finset Ω) :
    uniformProbability (anyCoordinateEvent A) ≤ ∑ i, uniformProbability (A i) := by
  classical
  calc
    _ ≤ ∑ i, uniformProbability (coordinateEvent i (A i)) :=
      uniformProbability_biUnion_le _ _
    _ = _ := by simp_rw [uniformProbability_coordinateEvent]

/-- The failure event: some bucket has a collision in every repetition. -/
def bucketCollisionEvent {ι : Type*} [Fintype ι] [DecidableEq ι]
    (b L R : ℕ) (S : Fin b → Finset ι) :
    Finset (Fin b → Fin R → ι → Fin (128*L^2)) := by
  classical
  exact anyCoordinateEvent (fun j : Fin b =>
    Fintype.piFinset (fun _ : Fin R => collisionEvent (S j) (128*L^2)))

@[simp] theorem mem_bucketCollisionEvent {ι : Type*} [Fintype ι] [DecidableEq ι]
    (b L R : ℕ) (S : Fin b → Finset ι) (f : Fin b → Fin R → ι → Fin (128*L^2)) :
    f ∈ bucketCollisionEvent b L R S ↔ ∃ j, ∀ r, ¬ Set.InjOn (f j r) (S j : Set ι) := by
  classical
  simp only [bucketCollisionEvent, mem_anyCoordinateEvent, Fintype.mem_piFinset,
    mem_collisionEvent]

/-- Union bound over buckets, each with fresh independent repeated colorings.
The sample is a uniformly chosen function from bucket labels to repetition
colorings, so both layers of random choices are actual finite product samples. -/
theorem uniform_bucket_collision_bound {ι : Type*} [Fintype ι] [DecidableEq ι]
    (b L R : ℕ) (S : Fin b → Finset ι) (hL : 0 < L) (hS : ∀ j, (S j).card ≤ 8*L) :
    uniformProbability (bucketCollisionEvent b L R S) ≤ b * (1/4 : ℝ)^R := by
  classical
  have hq : 0 < 128*L^2 := by positivity
  letI : Nonempty (Fin (128*L^2)) := ⟨⟨0,hq⟩⟩
  refine (uniformProbability_anyCoordinateEvent_le _).trans ?_
  calc
    _ ≤ ∑ _j : Fin b, (1/4 : ℝ)^R :=
      Finset.sum_le_sum (fun j _ => uniform_repeated_collision_bound (S j) L R hL (hS j))
    _ = _ := by simp

/-- Binary logarithmic amplification is sufficient for the stronger quarter
failure bound from each repetition. -/
theorem bucket_collision_amplification (b R : ℕ) (ζ : ℝ)
    (hR : 2*(b : ℝ) ≤ ζ*2^R) :
    (b : ℝ)*(1/4 : ℝ)^R ≤ ζ/2 := by
  calc
    _ ≤ (b : ℝ)*(1/2 : ℝ)^R := by
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      exact pow_le_pow_left₀ (by norm_num) (by norm_num) R
    _ = (b : ℝ)/2^R := by rw [div_pow]; simp [div_eq_mul_inv]
    _ ≤ ζ/2 := by
      apply (div_le_iff₀ (by positivity : (0 : ℝ) < 2^R)).mpr
      nlinarith

/-- The paper's exact repetition count meets the numerical amplification
condition, with a natural ceiling and real base-two logarithm. -/
theorem ceil_log_repetitions_sufficient (b : ℕ) (hb : 0 < b) (ζ : ℝ) (hζ : 0 < ζ) :
    2*(b : ℝ) ≤ ζ*2^⌈Real.logb 2 (2*(b : ℝ)/ζ)⌉₊ := by
  have hx : 0 < 2*(b : ℝ)/ζ := by positivity
  have hlog := Nat.le_ceil (Real.logb 2 (2*(b : ℝ)/ζ))
  have hpow := (Real.logb_le_iff_le_rpow (by norm_num : (1 : ℝ) < 2) hx).mp hlog
  rw [Real.rpow_natCast] at hpow
  have he := (div_le_iff₀ hζ).mp hpow
  nlinarith

/-- With the repetition count in Appendix A.2, color coding fails in some
bucket with probability at most half the specified failure budget. -/
theorem uniform_bucket_collision_half_budget {ι : Type*} [Fintype ι] [DecidableEq ι]
    (b L : ℕ) (S : Fin b → Finset ι) (hb : 0 < b) (hL : 0 < L)
    (hS : ∀ j, (S j).card ≤ 8*L) (ζ : ℝ) (hζ : 0 < ζ) :
    uniformProbability (bucketCollisionEvent b L ⌈Real.logb 2 (2*(b : ℝ)/ζ)⌉₊ S) ≤ ζ/2 := by
  apply (uniform_bucket_collision_bound b L _ S hL hS).trans
  exact bucket_collision_amplification b _ ζ (ceil_log_repetitions_sufficient b hb ζ hζ)

end
end Optss
