import Optss.ListBooleanConvolutionWork

/-! Retain all exact cyclic convolution counts, rather than just support.
This stored-integer frontend shares the same cached three-transform path and
is suitable for an autocorrelation score table. -/
namespace Optss
set_option maxRecDepth 4096

def bitConvolutionInteger (den : List Bool) (z : BitFourierInteger) : BitListInteger :=
  let r := bitListFractionRound ⟨z.re.negative,z.re.digits,den⟩
  ⟨r.1,bitListTrim r.2⟩

theorem bitConvolutionInteger_value (den : List Bool) (z : BitFourierInteger)
    (hden : 0<binaryDigitsValue den) :
    (bitConvolutionInteger den z).value=round (z.value.re/(binaryDigitsValue den : ℚ)) := by
  have h := bitListFractionRound_correct (⟨z.re.negative,z.re.digits,den⟩ : BitListFraction) hden
  change signedBitsValue _ (bitListTrim _)=_
  simpa only [signedBitsValue,bitListTrim_value] using h

theorem bitConvolutionInteger_canonical (den : List Bool) (z : BitFourierInteger) :
    BitListCanonical (bitConvolutionInteger den z).digits := bitListTrim_canonical _

def bitConvolutionIntegerWork (den : List Bool) (z : BitFourierInteger) : ℕ :=
  let q : BitListFraction := ⟨z.re.negative,z.re.digits,den⟩
  bitListFractionRoundCost q+bitListTrimVisits (bitListFractionRound q).2+2

theorem bitConvolutionIntegerWork_le_positive (den : List Bool) (z : BitFourierInteger) :
    bitConvolutionIntegerWork den z≤bitConvolutionPositiveWork den z := by
  unfold bitConvolutionIntegerWork bitConvolutionPositiveWork
  dsimp only
  rw [bitListTrimVisits_eq,bitListRippleGates_eq,bitListSubVisits_eq,List.length_nil,Nat.max_zero]
  omega

def listIntegerConvolution (depth : List Bool) (f g : List Bool) : List BitListInteger :=
  let p := dyadicDFTPrecision depth.length
  let den := listConvolutionDenominator depth p
  let C := listCyclicConvolution depth p (f.map bitFourierBoolean) (g.map bitFourierBoolean)
  C.map (bitConvolutionInteger den)

theorem listCyclicConvolution_boolean_values (depth : List Bool) (p : ℕ)
    (f g : Vector Bool (2^depth.length)) :
    (listCyclicConvolution depth p ((List.ofFn f.get).map bitFourierBoolean)
      ((List.ofFn g.get).map bitFourierBoolean)).map BitFourierInteger.value=
      List.ofFn (dyadicCyclicConvolution depth.length p
        (fourierBooleanData depth.length f) (fourierBooleanData depth.length g)).get := by
  apply listCyclicConvolution_values
  · simp only [List.map_map,List.map_ofFn,Function.comp_def,bitFourierBoolean_value,fourierBooleanData]
    apply congrArg List.ofFn
    funext i
    rw [vector_get_ofFn]
  · simp only [List.map_map,List.map_ofFn,Function.comp_def,bitFourierBoolean_value,fourierBooleanData]
    apply congrArg List.ofFn
    funext i
    rw [vector_get_ofFn]

theorem listIntegerConvolution_eq (depth : List Bool) (f g : Vector Bool (2^depth.length)) :
    (listIntegerConvolution depth (List.ofFn f.get) (List.ofFn g.get)).map BitListInteger.value=
      List.ofFn (fun k : Fin (2^depth.length) =>
        (cyclicNatConvolution (cyclicBooleanNat depth.length f) (cyclicBooleanNat depth.length g)
          (k.val : ZMod (2^depth.length)) : ℤ)) := by
  let p := dyadicDFTPrecision depth.length
  let den := listConvolutionDenominator depth p
  let C := listCyclicConvolution depth p ((List.ofFn f.get).map bitFourierBoolean)
    ((List.ofFn g.get).map bitFourierBoolean)
  have hc := listCyclicConvolution_boolean_values depth p f g
  have hden : binaryDigitsValue den=cyclicConvolutionDenominator depth.length p := listConvolutionDenominator_value depth p
  have hpos : 0<binaryDigitsValue den := by rw [hden]; exact cyclicConvolutionDenominator_pos _ _
  have hm : (C.map (bitConvolutionInteger den)).map BitListInteger.value=
      (C.map BitFourierInteger.value).map (fun z => round (z.re/(binaryDigitsValue den : ℚ))) := by
    simp only [List.map_map,Function.comp_def,bitConvolutionInteger_value den _ hpos]
  change (C.map (bitConvolutionInteger den)).map BitListInteger.value=_
  rw [hm,hc,List.map_ofFn]
  apply congrArg List.ofFn
  funext k
  simp only [Function.comp_def,hden]
  exact dyadicBooleanConvolution_round depth.length f g k

theorem listIntegerConvolution_canonical (depth : List Bool) (f g : List Bool) :
    ∀ z∈listIntegerConvolution depth f g,BitListCanonical z.digits := by
  intro z hz
  obtain ⟨w,hw,rfl⟩ := List.mem_map.mp hz
  exact bitConvolutionInteger_canonical _ _

def listIntegerConvolutionWork (depth : List Bool) (f g : List Bool) : ℕ :=
  let p := dyadicDFTPrecision depth.length
  let den := listConvolutionDenominator depth p
  let A := f.map bitFourierBoolean
  let B := g.map bitFourierBoolean
  let C := listCyclicConvolution depth p A B
  listCyclicConvolutionWork depth p A B+(C.map (bitConvolutionIntegerWork den)).sum+
    listConvolutionDenominatorWork depth p+16*(f.length+g.length)+8*C.length+32

theorem listIntegerConvolutionWork_le_boolean (depth : List Bool) (f g : List Bool) :
    listIntegerConvolutionWork depth f g≤listBooleanConvolutionWork depth f g := by
  dsimp only [listIntegerConvolutionWork,listBooleanConvolutionWork]
  gcongr
  induction (listCyclicConvolution depth (dyadicDFTPrecision depth.length)
      (f.map bitFourierBoolean) (g.map bitFourierBoolean)) with
  | nil => rfl
  | cons z zs ih =>
    simp only [List.map_cons,List.sum_cons]
    exact Nat.add_le_add (bitConvolutionIntegerWork_le_positive _ z) ih

theorem listIntegerConvolutionWork_bound (depth : List Bool) (f g : List Bool)
    (hf : f.length=2^depth.length) (hg : g.length=2^depth.length) :
    listIntegerConvolutionWork depth f g≤2^depth.length*listBooleanConvolutionWorkFactor depth.length :=
  (listIntegerConvolutionWork_le_boolean depth f g).trans (listBooleanConvolutionWork_nearlinear depth f g hf hg)

theorem cyclicBooleanConvolution_count_le (n : ℕ) (f g : Vector Bool (2^n)) (x : ZMod (2^n)) :
    cyclicNatConvolution (cyclicBooleanNat n f) (cyclicBooleanNat n g) x≤2^n := by
  unfold cyclicNatConvolution
  calc
    _≤∑ _y : ZMod (2^n), (1 : ℕ) := by
      apply Finset.sum_le_sum
      intro y hy
      have hf : cyclicBooleanNat n f y≤1 := by
        unfold cyclicBooleanNat
        cases f.get (cyclicArrayIndex n y) <;> decide
      have hg : cyclicBooleanNat n g (x-y)≤1 := by
        unfold cyclicBooleanNat
        cases g.get (cyclicArrayIndex n (x-y)) <;> decide
      exact (Nat.mul_le_mul hf hg).trans_eq (by decide)
    _=_ := by simp

theorem listIntegerConvolution_length (depth : List Bool) (f g : List Bool)
    (hf : f.length=2^depth.length) (hg : g.length=2^depth.length) :
    (listIntegerConvolution depth f g).length=2^depth.length := by
  obtain ⟨F,rfl⟩ := fourier_exists_vector f _ hf
  obtain ⟨G,rfl⟩ := fourier_exists_vector g _ hg
  have h := congrArg List.length (listIntegerConvolution_eq depth F G)
  simpa only [List.length_map,List.length_ofFn] using h

theorem listIntegerConvolution_output_width (depth : List Bool) (f g : Vector Bool (2^depth.length)) :
    ∀ z∈listIntegerConvolution depth (List.ofFn f.get) (List.ofFn g.get),z.digits.length≤depth.length+1 := by
  intro z hz
  have hc := listIntegerConvolution_canonical depth (List.ofFn f.get) (List.ofFn g.get) z hz
  have hm : z.value∈(listIntegerConvolution depth (List.ofFn f.get) (List.ofFn g.get)).map BitListInteger.value :=
    List.mem_map.mpr ⟨z,hz,rfl⟩
  rw [listIntegerConvolution_eq] at hm
  obtain ⟨k,hk⟩ := List.mem_ofFn.mp hm
  have hbound := cyclicBooleanConvolution_count_le depth.length f g (k.val : ZMod (2^depth.length))
  have hlen : z.digits.length=z.value.natAbs.size := by
    rw [BitListInteger.value,signedBitsValue_natAbs]
    exact hc.length
  rw [hlen,←hk,Int.natAbs_natCast]
  exact (Nat.size_le_size hbound).trans_eq Nat.size_pow

end Optss
