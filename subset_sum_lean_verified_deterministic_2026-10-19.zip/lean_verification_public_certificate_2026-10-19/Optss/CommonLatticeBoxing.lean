import Optss.DenseProgressionTransfer
import Optss.DisjointBlockSupports

/-!
# Boxing the actual common lattice of surviving labels

The bounded independent input vectors certify full rank. They produce a basis
of the entire generated subgroup and allow full-lattice boxing directly, without
requiring coordinate-axis periods to lie in the original box. The counting
bound is uniform over all positive integer dilations.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1000000
variable {d : ℕ}

/-- Finite index supplies positive axis periods for the full-lattice basis
adapter, with no claim that those periods fit in the input box. -/
theorem integer_subgroup_basis_of_finite_index (Γ : AddSubgroup (IntVec d)) (hΓ : Γ.index ≠ 0) :
    ∃ b : Basis (Fin d) ℝ (Fin d → ℝ),
      basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)) ∧
      ∀ i j, ∃ q : ℚ, (q : ℝ) = b j i := by
  have haxes : ∀ j : Fin d, ∃ n : ℕ, 0 < n ∧ Pi.single j (n : ℤ) ∈ Γ := by
    intro j
    obtain ⟨n, hn, _, hm⟩ := Γ.exists_nsmul_mem_of_index_ne_zero hΓ (Pi.single j (1 : ℤ))
    refine ⟨n, hn, ?_⟩
    convert hm using 1
    ext i
    by_cases hi : i = j
    · subst i; simp
    · simp [Pi.single_apply, hi, Ne.symm hi]
  choose n hn hm using haxes
  exact integer_subgroup_rational_basis Γ (fun j => n j) (fun j => by dsimp only; exact_mod_cast hn j) hm

/-- Counting integral points of an arbitrary integer subgroup inside a natural
dilate of the standard box loses no more than the whole standard box count. -/
theorem basisLatticePoints_integer_box_card_le
    (Γ : AddSubgroup (IntVec d)) (b : Basis (Fin d) ℝ (Fin d → ℝ))
    (hΛ : basisIntegerLattice b = realVector '' (Γ : Set (IntVec d)))
    (w : Fin d → ℕ) (s : ℕ) :
    (basisLatticePoints b ((s : ℝ) • realCoefficientBox w)
      ((realCoefficientBox_compact w).smul (s : ℝ))).card ≤
      (integerBudgetBox (fun j => s*w j)).card := by
  have hsub : basisLatticePoints b ((s : ℝ) • realCoefficientBox w)
      ((realCoefficientBox_compact w).smul (s : ℝ)) ⊆
      (integerBudgetBox (fun j => s*w j)).image realVector := by
    intro x hx
    obtain ⟨hbox, hlat⟩ := (mem_basisLatticePoints _ _ _ _).mp hx
    rw [hΛ] at hlat
    obtain ⟨z, _, rfl⟩ := hlat
    refine Finset.mem_image.mpr ⟨z, (mem_integerBudgetBox _ _).mpr ?_, rfl⟩
    intro j
    have hz := mem_smul_realCoefficientBox_bound w (s : ℝ) (Nat.cast_nonneg _) (realVector z) hbox j
    change |(z j : ℝ)| ≤ (s : ℝ)*w j at hz
    dsimp only
    exact_mod_cast hz
  exact (Finset.card_le_card hsub).trans (Finset.card_image_le)

/-- Full-lattice boxing for the common generated lattice of actual surviving
labels, including its uniform cardinality bound at every positive integer
scale. No supplied lattice basis or dense-filling consequence is assumed. -/
theorem common_generated_lattice_boxing {ι : Type} (hd : 0 < d)
    (v : ι → IntVec d) (available : Finset ι)
    (hfull : labelSpan ℝ (fun i => realVector (v i)) available = ⊤)
    (w : Fin d → ℕ) (hbox : ∀ i ∈ available, InCenteredBox w (v i)) :
    ∃ b : Basis (Fin d) ℝ (Fin d → ℝ),
      basisIntegerLattice b = realVector '' (generatedLattice v available : Set (IntVec d)) ∧
      ∃ n : Fin d → ℕ, (∀ j, 1 ≤ n j) ∧
        realCoefficientBox w ⊆ basisCoefficientBox b n ∧
        basisCoefficientBox b n ⊆ denseLatticeBoxingConstant d • realCoefficientBox w ∧
        ∀ s : ℕ, 1 ≤ s → (integerBudgetBox (fun j => s*n j)).card ≤
          (latticeBoxingResidueModulus d (latticeReductionDefectBound d))^d *
            (integerBudgetBox (fun j => s*w j)).card := by
  let Γ := generatedLattice v available
  have hindex := (generatedLattice_index_of_full_real_span v available hfull w hbox).1
  obtain ⟨b₀, hb₀, hrat₀⟩ := integer_subgroup_basis_of_finite_index Γ hindex
  have hrat : ∀ x ∈ realBoxVertices w, ∀ i, ∃ q : ℚ, (q : ℝ) = b₀.equivFun x i := by
    intro x hx
    apply rational_basis_coordinates b₀ hrat₀ x
    intro i
    rcases (mem_realBoxVertices w x).mp hx i with hi | hi
    · exact ⟨-(w i : ℚ), by simpa using hi.symm⟩
    · exact ⟨(w i : ℚ), by simpa using hi.symm⟩
  obtain ⟨labels, hlabels, hli⟩ := exists_full_rank_labels v available hfull
  have hxS : ∀ j, realVector (v (labels j)) ∈ convexHull ℝ (realBoxVertices w : Set (Fin d → ℝ)) := by
    intro j
    rw [convexHull_realBoxVertices, mem_realCoefficientBox]
    intro i
    have hb := hbox (labels j) (hlabels j) i
    change |((v (labels j)) i : ℝ)| ≤ (w i : ℝ)
    exact_mod_cast hb
  have hxΛ : ∀ j, realVector (v (labels j)) ∈ basisIntegerLattice b₀ := by
    intro j
    rw [hb₀]
    exact ⟨v (labels j), AddSubgroup.subset_closure ⟨labels j, hlabels j, rfl⟩, rfl⟩
  obtain ⟨b, hb, n, hn, hinner, houter, hcount⟩ := rational_polytope_full_lattice_boxing hd
    b₀ (realBoxVertices w) (fun _ hx => realBoxVertices_symmetric w hx) hrat
    (fun j => realVector (v (labels j))) hli hxS hxΛ
  simp only [convexHull_realBoxVertices] at hinner houter hcount
  refine ⟨b, hb.trans hb₀, n, hn, hinner, houter, ?_⟩
  intro s hs
  have hsR : (0 : ℝ) < s := by exact_mod_cast (show 0 < s by omega)
  have he : (s : ℝ) • basisCoefficientBox b n = basisCoefficientBox b (fun j => s*n j) := by
    ext x
    rw [mem_smul_basisCoefficientBox_iff _ _ _ hsR]
    change (∀ j, |b.equivFun x j| ≤ (s : ℝ)*n j) ↔ ∀ j, |b.equivFun x j| ≤ ((s*n j : ℕ) : ℝ)
    simp only [Nat.cast_mul]
  have hc := hcount (s : ℝ)
  have hleft : (basisLatticePoints b₀ ((s : ℝ) • basisCoefficientBox b n)
      ((basisCoefficientBox_compact b n).smul (s : ℝ))).card =
      (integerBudgetBox (fun j => s*n j)).card := by
    simp only [← basisLatticePoints_eq_of_lattice_eq b b₀ hb, he,
      basisLatticePoints_box_card, integerBudgetBox_card]
  rw [hleft] at hc
  exact hc.trans (Nat.mul_le_mul_left _ (basisLatticePoints_integer_box_card_le Γ b₀ hb₀ w s))

end
end Optss
