import Optss.ColorPreprocessing
import Optss.MixedRadix

/-!
# Shrinking a twice-proper containing progression

At the start of a common-GAP phase, a twice-proper integer coefficient box
contains every multiple `0,a,...,M*a` of each surviving item. Its actual chosen
coordinates must therefore be `n` times the coordinates of `a`, which lie in
the integer box of widths `β/M`. This proves the coordinate-shrinking step;
existence and efficient construction of the containing GAP remain separate.
-/

namespace Optss
open scoped BigOperators Classical Pointwise
noncomputable section
variable {d : ℕ}

def integerProgressionValues {G : Type*} [AddCommGroup G] [DecidableEq G]
    (ρ : IntVec d →+ G) (β : Fin d → ℕ) : Finset G :=
  (integerBudgetBox β).image ρ

def integerProgressionCoordinates (ρ : IntVec d →+ ℤ) (β : Fin d → ℕ) (x : ℤ) : IntVec d :=
  if h : x ∈ integerProgressionValues ρ β then Classical.choose (Finset.mem_image.mp h) else 0

theorem integerProgressionCoordinates_spec (ρ : IntVec d →+ ℤ) (β : Fin d → ℕ)
    {x : ℤ} (hx : x ∈ integerProgressionValues ρ β) :
    InBox (fun j => (β j : ℤ)) (integerProgressionCoordinates ρ β x) ∧
      ρ (integerProgressionCoordinates ρ β x) = x := by
  unfold integerProgressionCoordinates
  rw [dif_pos hx]
  have h := Classical.choose_spec (Finset.mem_image.mp hx)
  exact ⟨(mem_integerBudgetBox β _).mp h.1, h.2⟩

theorem inBox_double (β : Fin d → ℕ) {x : IntVec d}
    (hx : InBox (fun j => (β j : ℤ)) x) :
    InBox (fun j => ((2*β j : ℕ) : ℤ)) x := by
  intro j
  have h := hx j
  dsimp only at h ⊢
  push_cast
  omega

theorem inBox_add_double (β : Fin d → ℕ) {x y : IntVec d}
    (hx : InBox (fun j => (β j : ℤ)) x) (hy : InBox (fun j => (β j : ℤ)) y) :
    InBox (fun j => ((2*β j : ℕ) : ℤ)) (x+y) := by
  intro j
  have h := (abs_add (x j) (y j)).trans (add_le_add (hx j) (hy j))
  simpa only [Pi.add_apply, Nat.cast_mul, Nat.cast_ofNat, two_mul] using h

theorem integerProgressionCoordinates_zero (ρ : IntVec d →+ ℤ) (β : Fin d → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox (fun j => 2*β j))) :
    integerProgressionCoordinates ρ β 0 = 0 := by
  have hzero : (0 : IntVec d) ∈ integerBudgetBox β := by simp [InBox]
  have hz : (0 : ℤ) ∈ integerProgressionValues ρ β :=
    Finset.mem_image.mpr ⟨0, hzero, map_zero ρ⟩
  obtain ⟨hb, hr⟩ := integerProgressionCoordinates_spec ρ β hz
  apply hproper ((mem_integerBudgetBox _ _).mpr (inBox_double β hb))
    (by simp [InBox])
  simpa using hr

/-- Two-properness turns every available scalar addition into coordinate
addition. Only the sum of the two coordinate representatives needs doubling. -/
theorem integerProgressionCoordinates_add (ρ : IntVec d →+ ℤ) (β : Fin d → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox (fun j => 2*β j)))
    {x y : ℤ} (hx : x ∈ integerProgressionValues ρ β)
    (hy : y ∈ integerProgressionValues ρ β) (hxy : x+y ∈ integerProgressionValues ρ β) :
    integerProgressionCoordinates ρ β (x+y) =
      integerProgressionCoordinates ρ β x + integerProgressionCoordinates ρ β y := by
  obtain ⟨hbx, hrx⟩ := integerProgressionCoordinates_spec ρ β hx
  obtain ⟨hby, hry⟩ := integerProgressionCoordinates_spec ρ β hy
  obtain ⟨hbxy, hrxy⟩ := integerProgressionCoordinates_spec ρ β hxy
  apply hproper ((mem_integerBudgetBox _ _).mpr (inBox_double β hbxy))
    ((mem_integerBudgetBox _ _).mpr (inBox_add_double β hbx hby))
  rw [hrxy, map_add, hrx, hry]

/-- No linearity of the chosen inverse is assumed: it follows along every
available string of multiples from twice-properness. -/
theorem integerProgressionCoordinates_multiple (ρ : IntVec d →+ ℤ) (β : Fin d → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox (fun j => 2*β j)))
    (a : ℤ) (M : ℕ) (hM : 0 < M)
    (hmultiples : ∀ n ≤ M, (n : ℤ)*a ∈ integerProgressionValues ρ β)
    (n : ℕ) (hn : n ≤ M) :
    integerProgressionCoordinates ρ β ((n : ℤ)*a) = n • integerProgressionCoordinates ρ β a := by
  induction n with
  | zero => simpa only [Nat.cast_zero, zero_mul, zero_smul] using integerProgressionCoordinates_zero ρ β hproper
  | succ n ih =>
    have ha : a ∈ integerProgressionValues ρ β := by simpa using hmultiples 1 hM
    have hadd : ((n : ℤ)*a+a) ∈ integerProgressionValues ρ β := by
      simpa only [Nat.cast_add, Nat.cast_one, add_mul, one_mul] using hmultiples (n+1) hn
    have h := integerProgressionCoordinates_add ρ β hproper (hmultiples n (by omega)) ha hadd
    simpa only [Nat.cast_add, Nat.cast_one, add_mul, one_mul, ih (by omega), add_smul,
      one_smul] using h

def shrunkProgressionWidths (β : Fin d → ℕ) (M : ℕ) : Fin d → ℕ := fun j => β j / M

/-- The exact integer floor widths, including coordinates that become zero. -/
theorem integerProgressionCoordinates_shrunk (ρ : IntVec d →+ ℤ) (β : Fin d → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox (fun j => 2*β j)))
    (a : ℤ) (M : ℕ) (hM : 0 < M)
    (hmultiples : ∀ n ≤ M, (n : ℤ)*a ∈ integerProgressionValues ρ β) :
    InBox (fun j => (shrunkProgressionWidths β M j : ℤ)) (integerProgressionCoordinates ρ β a) := by
  have hb := (integerProgressionCoordinates_spec ρ β (hmultiples M le_rfl)).1
  rw [integerProgressionCoordinates_multiple ρ β hproper a M hM hmultiples M le_rfl] at hb
  intro j
  have hj := hb j
  simp only [Pi.smul_apply, nsmul_eq_mul, abs_mul, Int.abs_natCast] at hj
  rw [← Int.natCast_natAbs] at hj
  have hnat : M * (integerProgressionCoordinates ρ β a j).natAbs ≤ β j := by exact_mod_cast hj
  have hdiv := (Nat.le_div_iff_mul_le hM).mpr (by simpa [mul_comm] using hnat)
  change |integerProgressionCoordinates ρ β a j| ≤ ((β j / M : ℕ) : ℤ)
  rw [← Int.natCast_natAbs]
  exact_mod_cast hdiv

theorem scaled_shrunk_box_subset (β : Fin d → ℕ) (M : ℕ) :
    integerBudgetBox (fun j => M * shrunkProgressionWidths β M j) ⊆ integerBudgetBox β := by
  intro x hx
  apply (mem_integerBudgetBox β x).mpr
  have h := (mem_integerBudgetBox _ x).mp hx
  intro j
  apply (h j).trans
  change ((M * (β j / M) : ℕ) : ℤ) ≤ (β j : ℤ)
  exact_mod_cast Nat.mul_div_le (β j) M

/-- Properness is inherited at the full shrinking scale. -/
theorem scaled_shrunk_box_proper (ρ : IntVec d →+ ℤ) (β : Fin d → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox (fun j => 2*β j))) (M : ℕ) :
    Set.InjOn ρ (integerBudgetBox (fun j => M*shrunkProgressionWidths β M j)) := by
  apply hproper.mono
  intro x hx
  exact (mem_integerBudgetBox _ x).mpr (inBox_double β
    ((mem_integerBudgetBox _ x).mp (scaled_shrunk_box_subset β M hx)))

theorem scaled_shrunk_box_card_le (β : Fin d → ℕ) (M : ℕ) :
    (integerBudgetBox (fun j => M*shrunkProgressionWidths β M j)).card ≤
      (integerBudgetBox β).card := Finset.card_le_card (scaled_shrunk_box_subset β M)

def liftedProgressionInputs (ρ : IntVec d →+ ℤ) (β : Fin d → ℕ) (S : Finset ℤ) :
    Finset (IntVec d) := S.image (integerProgressionCoordinates ρ β)

theorem liftedProgressionInputs_image (ρ : IntVec d →+ ℤ) (β : Fin d → ℕ)
    (S : Finset ℤ) (hS : S ⊆ integerProgressionValues ρ β) :
    (liftedProgressionInputs ρ β S).image ρ = S := by
  ext a
  simp only [liftedProgressionInputs, Finset.mem_image]
  constructor
  · rintro ⟨x, ⟨y, hy, rfl⟩, he⟩
    rw [(integerProgressionCoordinates_spec ρ β (hS hy)).2] at he
    exact he ▸ hy
  · intro ha
    exact ⟨integerProgressionCoordinates ρ β a, ⟨a, ha, rfl⟩,
      (integerProgressionCoordinates_spec ρ β (hS ha)).2⟩

theorem liftedProgressionInputs_shrunk (ρ : IntVec d →+ ℤ) (β : Fin d → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox (fun j => 2*β j)))
    (S : Finset ℤ) (M : ℕ) (hM : 0 < M)
    (hmultiples : ∀ a ∈ S, ∀ n ≤ M, (n : ℤ)*a ∈ integerProgressionValues ρ β) :
    ∀ x ∈ liftedProgressionInputs ρ β S, InCenteredBox (shrunkProgressionWidths β M) x := by
  intro x hx
  obtain ⟨a, ha, rfl⟩ := Finset.mem_image.mp hx
  exact integerProgressionCoordinates_shrunk ρ β hproper a M hM (hmultiples a ha)

/-- Proper shrinking preserves the actual repeated-sumset cardinalities,
including all smaller scales used in the greedy block argument. -/
theorem liftedProgressionInputs_repeated_card (ρ : IntVec d →+ ℤ) (β : Fin d → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox (fun j => 2*β j)))
    (S : Finset ℤ) (M : ℕ) (hM : 0 < M)
    (hmultiples : ∀ a ∈ S, ∀ n ≤ M, (n : ℤ)*a ∈ integerProgressionValues ρ β)
    (k : ℕ) (hk : k ≤ M) :
    (k • liftedProgressionInputs ρ β S).card = (k • S).card := by
  have hS : S ⊆ integerProgressionValues ρ β := by
    intro a ha
    simpa using hmultiples a ha 1 hM
  have hbox := repeatedSumset_in_box (shrunkProgressionWidths β M)
    (liftedProgressionInputs ρ β S) (liftedProgressionInputs_shrunk ρ β hproper S M hM hmultiples) k
  have hwide : ∀ x ∈ k • liftedProgressionInputs ρ β S,
      x ∈ integerBudgetBox (fun j => M*shrunkProgressionWidths β M j) := by
    intro x hx
    apply (mem_integerBudgetBox _ x).mpr
    intro j
    apply (hbox x hx j).trans
    dsimp only
    exact_mod_cast Nat.mul_le_mul_right (shrunkProgressionWidths β M j) hk
  have hc : ((k • liftedProgressionInputs ρ β S).image ρ).card =
      (k • liftedProgressionInputs ρ β S).card := Finset.card_image_iff.mpr (by
    intro x hx y hy he
    exact scaled_shrunk_box_proper ρ β hproper M (hwide x hx) (hwide y hy) he)
  rw [Finset.image_nsmul, liftedProgressionInputs_image ρ β S hS] at hc
  exact hc.symm

end
end Optss
