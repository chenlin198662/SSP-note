import Optss.ComputedModelingPart

/-!
# Correctness of the computed finite Freiman model

Prime search, Boolean inverse/marking, multiplier scan and largest-part
selection all return the values appearing in the Freiman-eight certificate.
The input difference list must still be supplied by an exact difference-set
computation; its fast convolution construction is a separate stage.
-/
namespace Optss
open scoped BigOperators

theorem computed_freiman_eight_model (input differences : List ℤ) (u : ℕ)
    (hinput : input.Nodup) (hdiff : differences.Nodup)
    (hS : ∀ a∈input, 0≤a ∧ a≤u)
    (hdata : differences.toFinset=modelingDifferences input.toFinset 8) :
    ∃ p q n : ℕ, computedModelingParameters differences u=some (p,q,n) ∧
      p.Prime ∧ q.Prime ∧ p≤256*(u+1) ∧ q≤modelingPrimeTableLimit u ∧
      let T := computedModelingPart input n q
      T.Nodup ∧ T.toFinset⊆input.toFinset ∧ input.length≤8*T.length ∧
      Set.InjOn (fun a => (modelingResidue (n:ZMod q) a : ZMod p)) (T.toFinset : Set ℤ) ∧
      (∀ a b : Fin 8→ℤ, (∀ i, a i∈T) → (∀ i, b i∈T) →
        ((∑ i, (modelingResidue (n:ZMod q) (a i):ZMod p))=
          (∑ i, (modelingResidue (n:ZMod q) (b i):ZMod p)) ↔
          (∑ i, a i)=(∑ i, b i))) := by
  have hS' : ∀ a∈input.toFinset, 0≤a ∧ a≤u := fun a ha => hS a (List.mem_toFinset.mp ha)
  obtain ⟨p,q,n,hparams,hp,hq,_,_,hql,hpb,hqb,_,_,hn0,havoid⟩ :=
    computedModelingParameters_correct input.toFinset u differences hS' hdiff hdata
  letI : Fact q.Prime := ⟨hq⟩
  let T := computedModelingPart input n q
  have hTsub := computedModelingPart_subset input n q
  have hT (x : ℤ) (hx : x∈T) : x∈input.toFinset := hTsub (List.mem_toFinset.mpr hx)
  obtain ⟨L,U,hinterval,hwidth⟩ := computedModelingPart_interval input n q hq.pos
  have hD : ∀ e∈modelingDifferences input.toFinset 8, |e|<(q:ℤ) := by
    intro e he
    apply (modelingDifferences_abs_le input.toFinset 8 u hS' e he).trans_lt
    have hh := (le_max_left (16*u) (2*p)).trans_lt hql
    exact_mod_cast (show 8*u<q by omega)
  have hrel (a b : Fin 8→ℤ) (ha : ∀ i, a i∈T) (hb : ∀ i, b i∈T) :
      ((∑ i, (modelingResidue (n:ZMod q) (a i):ZMod p))=
        (∑ i, (modelingResidue (n:ZMod q) (b i):ZMod p)) ↔
        (∑ i, a i)=(∑ i, b i)) :=
    modeling_freiman_iff hp.pos input.toFinset (n:ZMod q) hn0 hD havoid
      (modelingResidue (n:ZMod q)) (fun a _ => modelingResidue_congr _ a)
      L U hwidth a b (fun i => hT _ (ha i)) (fun i => hT _ (hb i))
      (fun i => hinterval _ (ha i)) (fun i => hinterval _ (hb i))
  refine ⟨p,q,n,hparams,hp,hq,hpb,hqb,computedModelingPart_nodup input n q hinput,
    hTsub,computedModelingPart_card input n q hq.pos hinput,?_,hrel⟩
  intro a ha b hb hab
  have he := (hrel (fun _ => a) (fun _ => b)
    (fun _ => List.mem_toFinset.mp ha) (fun _ => List.mem_toFinset.mp hb)).mp (by simp [hab])
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at he
  omega

end Optss
