import Optss.StoredDifferenceList

/-! Fully instantiated cyclic padding for bounded signed integer inputs.
No supplied difference list or no-wrap certificate remains: the actual depth
initializer chooses a modulus between 6k(U+1) and 12k(U+1), where k is the
number of summands produced by the structural doubling schedule. -/
namespace Optss
open scoped Pointwise
set_option maxRecDepth 4096

def integerDifferenceDepth (steps : List Bool) (U : ℕ) : List Bool :=
  listFourierDepth (List.replicate (U+1) false)++false::steps.map (fun _ => false)

def boundedIntegerDifferenceList (steps : List Bool) (U : ℕ) (input : List ℤ) : List ℤ :=
  computedIntegerDifferenceList (integerDifferenceDepth steps U) steps input

theorem integerDifferenceDepth_length (steps : List Bool) (U : ℕ) :
    (integerDifferenceDepth steps U).length=bluesteinPadExponent (U+1)+steps.length+1 := by
  rw [integerDifferenceDepth,listFourierDepth_eq _ (by simp)]
  simp only [List.length_append,List.length_replicate,List.length_cons,List.length_map]
  omega

theorem integerDifferenceDepth_modulus (steps : List Bool) (U : ℕ) :
    6*(2^steps.length)*(U+1)≤2^(integerDifferenceDepth steps U).length ∧
      2^(integerDifferenceDepth steps U).length<12*(2^steps.length)*(U+1) := by
  haveI : NeZero (U+1) := ⟨by omega⟩
  have hlo : 3*(U+1)≤2^bluesteinPadExponent (U+1) :=
    Nat.le_pow_clog (by decide : 1 < 2) _
  have hhi := (bluesteinPadExponent_bounds (U+1)).2
  rw [integerDifferenceDepth_length,pow_succ,pow_add]
  constructor
  · nlinarith only [Nat.mul_le_mul_right (2^steps.length*2) hlo]
  · nlinarith only [Nat.mul_lt_mul_of_pos_right hhi (by positivity : 0 < 2^steps.length*2)]

theorem integerDifferenceDepth_length_bound (steps : List Bool) (U : ℕ) :
    (integerDifferenceDepth steps U).length≤(U+1).size+steps.length+3 := by
  have hlog : bluesteinPadExponent (U+1)≤(U+1).size+2 := by
    apply (Nat.le_pow_iff_clog_le (by decide : 1 < 2)).mp
    rw [pow_add]
    norm_num
    have h := Nat.lt_size_self (U+1)
    omega
  rw [integerDifferenceDepth_length]
  omega

theorem boundedIntegerDifferenceList_eq (steps : List Bool) (U : ℕ) (input : List ℤ)
    (hinput : ∀ z∈input, |z|≤(U : ℤ)) :
    (boundedIntegerDifferenceList steps U input).toFinset=modelingDifferences input.toFinset (2^steps.length) := by
  apply computedIntegerDifferenceList_eq _ steps input (-(U : ℤ)) U
  · intro z hz
    exact abs_le.mp (hinput z hz)
  · have hlo := (integerDifferenceDepth_modulus steps U).1
    have hk : 0 < (2^steps.length : ℕ) := pow_pos (by decide) _
    have hcast : (6 : ℤ)*(2^steps.length : ℕ)*(U+1)≤(2^(integerDifferenceDepth steps U).length : ℕ) := by
      exact_mod_cast hlo
    have hk' : (0 : ℤ)<(2^steps.length : ℕ) := by exact_mod_cast hk
    nlinarith only [hcast,hk']

theorem boundedIntegerDifferenceList_nodup (steps : List Bool) (U : ℕ) (input : List ℤ) :
    (boundedIntegerDifferenceList steps U input).Nodup :=
  computedIntegerDifferenceList_nodup _ _ _

def computedEightDifferenceList (U : ℕ) (input : List ℤ) : List ℤ :=
  boundedIntegerDifferenceList [false,false,false] U input

def computedFourDifferenceList (U : ℕ) (input : List ℤ) : List ℤ :=
  boundedIntegerDifferenceList [false] U input

def computedPairDifferenceList (U : ℕ) (input : List ℤ) : List ℤ :=
  boundedIntegerDifferenceList [] U input

theorem computedEightDifferenceList_eq (U : ℕ) (input : List ℤ) (hinput : ∀ z∈input, |z|≤(U : ℤ)) :
    (computedEightDifferenceList U input).toFinset=modelingDifferences input.toFinset 8 := by
  exact boundedIntegerDifferenceList_eq [false,false,false] U input hinput

theorem computedFourDifferenceList_eq (U : ℕ) (input : List ℤ) (hinput : ∀ z∈input, |z|≤(U : ℤ)) :
    (computedFourDifferenceList U input).toFinset=modelingDifferences input.toFinset 2 := by
  exact boundedIntegerDifferenceList_eq [false] U input hinput

theorem computedPairDifferenceList_eq (U : ℕ) (input : List ℤ) (hinput : ∀ z∈input, |z|≤(U : ℤ)) :
    (computedPairDifferenceList U input).toFinset=input.toFinset-input.toFinset := by
  simpa only [List.length_nil,pow_zero,modelingDifferences,one_nsmul] using
    boundedIntegerDifferenceList_eq [] U input hinput

end Optss
