import Optss.ComputedReboxedProgression
import Optss.ProperizationIteration

/-!
# Executable rank descent for positive-width integer GAPs

The answer repeatedly computes a short relation, takes its explicit primitive
quotient, boxes the actual quotient body, and recurses on the returned smaller
GAP. The recursion is structural in rank. Every output and every unsuccessful
search branch is connected to its exact mathematical specification.
-/
namespace Optss
open scoped BigOperators

structure ExecutableIntegerGAP where
  rank : ℕ
  generators : Fin rank→ℤ
  widths : Fin rank→ℕ

def zeroExecutableIntegerGAP : ExecutableIntegerGAP := ⟨0,Fin.elim0,Fin.elim0⟩

noncomputable def executableGAPValues (g : ExecutableIntegerGAP) : Finset ℤ :=
  integerProgressionValues (progressionLinearEncoding g.generators).toAddMonoidHom g.widths

def properizePositiveGAP (t : ℕ) : (r : ℕ) → (Fin r→ℤ) → (Fin r→ℕ) → ExecutableIntegerGAP
  | 0,a,β => ⟨0,a,β⟩
  | 1,a,β => match computedShortKernelVector a (fun j => 2*t*β j) with
    | none => ⟨1,a,β⟩
    | some _ => zeroExecutableIntegerGAP
  | n+2,a,β => match computedShortKernelVector a (fun j => 2*t*β j) with
    | none => ⟨n+2,a,β⟩
    | some z => match computedQuotientBox (executablePrimitiveQuotient z) β with
      | none => ⟨n+2,a,β⟩
      | some box => properizePositiveGAP t (n+1)
          (computedReboxedGenerators a z box) (decodedLatticeBoxWidths box)

@[simp] theorem properizePositiveGAP_zero (t : ℕ) (a : Fin 0→ℤ) (β : Fin 0→ℕ) :
    properizePositiveGAP t 0 a β=⟨0,a,β⟩ := rfl

theorem properizePositiveGAP_one_none (t : ℕ) (a : Fin 1→ℤ) (β : Fin 1→ℕ)
    (h : computedShortKernelVector a (fun j => 2*t*β j)=none) :
    properizePositiveGAP t 1 a β=⟨1,a,β⟩ := by
  change (match computedShortKernelVector a (fun j => 2*t*β j) with
    | none => (⟨1,a,β⟩ : ExecutableIntegerGAP) | some _ => zeroExecutableIntegerGAP)=_
  rw [h]

theorem properizePositiveGAP_one_some (t : ℕ) (a : Fin 1→ℤ) (β : Fin 1→ℕ)
    (z : Fin 1→ℤ) (h : computedShortKernelVector a (fun j => 2*t*β j)=some z) :
    properizePositiveGAP t 1 a β=zeroExecutableIntegerGAP := by
  change (match computedShortKernelVector a (fun j => 2*t*β j) with
    | none => (⟨1,a,β⟩ : ExecutableIntegerGAP) | some _ => zeroExecutableIntegerGAP)=_
  rw [h]

theorem properizePositiveGAP_succ_none (n t : ℕ) (a : Fin (n+2)→ℤ) (β : Fin (n+2)→ℕ)
    (h : computedShortKernelVector a (fun j => 2*t*β j)=none) :
    properizePositiveGAP t (n+2) a β=⟨n+2,a,β⟩ := by
  change (match computedShortKernelVector a (fun j => 2*t*β j) with
    | none => (⟨n+2,a,β⟩ : ExecutableIntegerGAP)
    | some z => match computedQuotientBox (executablePrimitiveQuotient z) β with
      | none => ⟨n+2,a,β⟩
      | some box => properizePositiveGAP t (n+1)
          (computedReboxedGenerators a z box) (decodedLatticeBoxWidths box))=_
  rw [h]

theorem properizePositiveGAP_succ_some (n t : ℕ) (a : Fin (n+2)→ℤ) (β : Fin (n+2)→ℕ)
    (z : Fin (n+2)→ℤ) (h : computedShortKernelVector a (fun j => 2*t*β j)=some z)
    (box : BooleanLatticeBoxResult (n+1))
    (hb : computedQuotientBox (executablePrimitiveQuotient z) β=some box) :
    properizePositiveGAP t (n+2) a β=
      properizePositiveGAP t (n+1) (computedReboxedGenerators a z box) (decodedLatticeBoxWidths box) := by
  change (match computedShortKernelVector a (fun j => 2*t*β j) with
    | none => (⟨n+2,a,β⟩ : ExecutableIntegerGAP)
    | some z => match computedQuotientBox (executablePrimitiveQuotient z) β with
      | none => ⟨n+2,a,β⟩
      | some box => properizePositiveGAP t (n+1)
          (computedReboxedGenerators a z box) (decodedLatticeBoxWidths box))=_
  simp only [h,hb]

theorem shortKernel_none_tproper {r : ℕ} (hr : 0<r) (a : Fin r→ℤ) (β : Fin r→ℕ)
    (hβ : ∀ j,0<β j) (t : ℕ) (ht : 0<t)
    (hn : computedShortKernelVector a (fun j => 2*t*β j)=none) :
    Set.InjOn (progressionLinearEncoding a) (integerBudgetBox (fun j => t*β j)) := by
  apply (integerBox_proper_iff_no_short_kernel (progressionLinearEncoding a).toAddMonoidHom _).mpr
  intro z hz hker
  by_contra hzn
  have hmem : z∈integerBudgetBox (fun j => 2*t*β j) := by simpa only [Nat.mul_assoc] using hz
  have hs := (computedShortKernelVector_complete hr a (fun j => 2*t*β j)
    (by intro j; exact Nat.mul_pos (Nat.mul_pos (by decide) ht) (hβ j))).mpr ⟨z,hmem,hzn,hker⟩
  exact hs hn

theorem executableGAPValues_zero : executableGAPValues zeroExecutableIntegerGAP={0} := by
  ext y
  constructor
  · intro hy
    obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp hy
    simp [zeroExecutableIntegerGAP,progressionLinearEncoding]
  · intro hy
    have hy0 : y=0 := Finset.mem_singleton.mp hy
    subst y
    exact Finset.mem_image.mpr ⟨0,by simp [mem_integerBudgetBox,InBox],by simp⟩

theorem rankOne_relation_values_zero (a : Fin 1→ℤ) (β : Fin 1→ℕ)
    (z : Fin 1→ℤ) (hz : z≠0) (hker : progressionLinearEncoding a z=0) :
    integerProgressionValues (progressionLinearEncoding a).toAddMonoidHom β={0} := by
  have hz0 : z 0≠0 := by
    intro he
    apply hz
    ext j
    have hj : j=0 := Subsingleton.elim _ _
    simpa [hj] using he
  have ha0 : a 0=0 := by
    have he : a 0*z 0=0 := by simpa [progressionLinearEncoding] using hker
    exact (mul_eq_zero.mp he).resolve_right hz0
  ext y
  constructor
  · intro hy
    obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp hy
    simpa [progressionLinearEncoding,ha0] using (Finset.mem_singleton_self (0:ℤ))
  · intro hy
    have hy0 : y=0 := Finset.mem_singleton.mp hy
    subst y
    exact Finset.mem_image.mpr ⟨0,by simp [mem_integerBudgetBox,InBox],by simp⟩

/-- All substantive conclusions of rank descent for the literal returned GAP.
The uniform factor is dimension-only (with fixed `t`) and is the same factor
already used in the mathematical properization assembly. -/
theorem properizePositiveGAP_spec (t : ℕ) (ht : 0<t) (R r : ℕ) (hrR : r≤R)
    (a : Fin r→ℤ) (β : Fin r→ℕ) (hβ : ∀ j,0<β j) :
    (properizePositiveGAP t r a β).rank≤r ∧
    (∀ j,0<(properizePositiveGAP t r a β).widths j) ∧
    Set.InjOn (progressionLinearEncoding (properizePositiveGAP t r a β).generators)
      (integerBudgetBox (fun j => t*(properizePositiveGAP t r a β).widths j)) ∧
    integerProgressionValues (progressionLinearEncoding a).toAddMonoidHom β ⊆
      executableGAPValues (properizePositiveGAP t r a β) ∧
    (integerBudgetBox (properizePositiveGAP t r a β).widths).card≤
      (properizationIterationFactor sharpLatticeDefectBound t R)^r*(integerBudgetBox β).card := by
  classical
  have hF := properizationIterationFactor_pos sharpLatticeDefectBound t R
  induction r using Nat.strong_induction_on with
  | h r ih =>
    cases r with
    | zero =>
      rw [properizePositiveGAP_zero]
      refine ⟨le_rfl,hβ,?_,Finset.Subset.refl _,?_⟩
      · intro x hx y hy hxy
        exact Subsingleton.elim _ _
      · simp
    | succ n =>
      cases n with
      | zero =>
        cases hs : computedShortKernelVector a (fun j => 2*t*β j) with
        | none =>
          rw [properizePositiveGAP_one_none t a β hs]
          refine ⟨le_rfl,hβ,shortKernel_none_tproper (by decide) a β hβ t ht hs,Finset.Subset.refl _,?_⟩
          simpa only [Nat.zero_add,pow_one,one_mul] using Nat.mul_le_mul_right (integerBudgetBox β).card hF
        | some z =>
          have hz := computedShortKernelVector_sound a (fun j => 2*t*β j)
            (by intro j; exact Nat.mul_pos (Nat.mul_pos (by decide) ht) (hβ j)) z hs
          have hv := rankOne_relation_values_zero a β z hz.2.1 hz.2.2
          rw [properizePositiveGAP_one_some t a β z hs]
          refine ⟨by decide,fun j => Fin.elim0 j,?_,?_,?_⟩
          · intro x hx y hy hxy
            apply funext
            intro j
            exact Fin.elim0 (j : Fin 0)
          · rw [executableGAPValues_zero,hv]
          · have hcard := Finset.card_pos.mpr (integerBudgetBox_nonempty β)
            change (integerBudgetBox (Fin.elim0 : Fin 0→ℕ)).card≤_
            have hzcard : (integerBudgetBox (Fin.elim0 : Fin 0→ℕ)).card=1 := by simp [integerBudgetBox_card]
            rw [hzcard,pow_one]
            nlinarith
      | succ n =>
        cases hs : computedShortKernelVector a (fun j => 2*t*β j) with
        | none =>
          rw [properizePositiveGAP_succ_none n t a β hs]
          refine ⟨le_rfl,hβ,shortKernel_none_tproper (by omega) a β hβ t ht hs,Finset.Subset.refl _,?_⟩
          have hp := Nat.one_le_pow (n+2) _ hF
          simpa only [one_mul] using Nat.mul_le_mul_right (integerBudgetBox β).card hp
        | some z =>
          obtain ⟨box,hbox,hpos,hcontains,hcard⟩ := computedReboxing_step (by omega) a β hβ t ht z hs
          have hout : properizePositiveGAP t (n+2) a β=
              properizePositiveGAP t (n+1) (computedReboxedGenerators a z box) (decodedLatticeBoxWidths box) := by
            exact properizePositiveGAP_succ_some n t a β z hs box hbox
          rw [hout]
          obtain ⟨hrank,hwidth,hproper,hsub,hbound⟩ := ih (n+1) (by omega) (by omega)
            (computedReboxedGenerators a z box) (decodedLatticeBoxWidths box) hpos
          refine ⟨hrank.trans (by omega),hwidth,hproper,Finset.Subset.trans hcontains hsub,?_⟩
          have hfac := properizationIterationFactor_bound sharpLatticeDefectBound t R (n+1) (by omega)
          have hstep : (integerBudgetBox (decodedLatticeBoxWidths box)).card≤
              properizationIterationFactor sharpLatticeDefectBound t R*(integerBudgetBox β).card :=
            hcard.trans (Nat.mul_le_mul_right _ hfac)
          apply hbound.trans
          have hm := Nat.mul_le_mul_left ((properizationIterationFactor sharpLatticeDefectBound t R)^(n+1)) hstep
          simpa only [pow_succ,mul_assoc] using hm
end Optss
