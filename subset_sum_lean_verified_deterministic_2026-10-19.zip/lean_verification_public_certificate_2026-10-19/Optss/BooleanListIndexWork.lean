import Optss.BooleanListIndex

/-! Explicit Boolean and traversal work of bounded structural-index control. -/
namespace Optss

/-- The borrow circuit, its traversal, and final Boolean negation. -/
def bitListLEWork (xs ys : List Bool) : ℕ :=
  bitListRippleGates 8 ys xs+bitListSubVisits ys xs+1

def bitIndexLEWork {n m : ℕ} (i : Fin n) (j : Fin m) : ℕ :=
  bitUnaryAddressWork i.val+bitUnaryAddressWork j.val+
    bitListLEWork (bitUnaryAddress i.val) (bitUnaryAddress j.val)
def bitIndexEQWork {n m : ℕ} (i : Fin n) (j : Fin m) : ℕ :=
  bitIndexLEWork i j+bitIndexLEWork j i+1
def bitIndexLTWork {n m : ℕ} (i : Fin n) (j : Fin m) : ℕ := bitIndexLEWork j i+1

def bitIndexAdjacentWork {n m : ℕ} (i : Fin n) (j : Fin m) : ℕ :=
  let next := bitListAdd (bitUnaryAddress i.val) [true]
  bitUnaryAddressWork i.val+bitUnaryAddressWork j.val+
    bitListRippleGates 6 (bitUnaryAddress i.val) [true]+
    bitListAddVisits (bitUnaryAddress i.val) [true]+
    bitListTrimVisits (bitListAddAux false (bitUnaryAddress i.val) [true])+
    bitListLEWork next (bitUnaryAddress j.val)+bitListLEWork (bitUnaryAddress j.val) next+1

theorem bitListLEWork_le (xs ys : List Bool) (L : ℕ) (hx : xs.length ≤ L) (hy : ys.length ≤ L) :
    bitListLEWork xs ys ≤ 9*L+2 := by
  have hm : max ys.length xs.length ≤ L := max_le hy hx
  simp only [bitListLEWork,bitListRippleGates_eq,bitListSubVisits_eq]
  omega

theorem bitIndexLEWork_le {n m : ℕ} (i : Fin n) (j : Fin m) :
    bitIndexLEWork i j ≤ 64*(n+m+1)^2 := by
  have hi := i.isLt
  have hj := j.isLt
  have hii := bitUnaryAddress_length i.val
  have hjj := bitUnaryAddress_length j.val
  have hc := bitListLEWork_le (bitUnaryAddress i.val) (bitUnaryAddress j.val) (n+m+1)
    (by omega) (by omega)
  have hiw := bitUnaryAddressWork_le i.val
  have hjw := bitUnaryAddressWork_le j.val
  have hip : (i.val+1)^2 ≤ (n+m+1)^2 := Nat.pow_le_pow_left (by omega) 2
  have hjp : (j.val+1)^2 ≤ (n+m+1)^2 := Nat.pow_le_pow_left (by omega) 2
  unfold bitIndexLEWork
  nlinarith

theorem bitIndexEQWork_le {n m : ℕ} (i : Fin n) (j : Fin m) :
    bitIndexEQWork i j ≤ 129*(n+m+1)^2 := by
  have h₁ := bitIndexLEWork_le i j
  have h₂ := bitIndexLEWork_le j i
  have he : m+n+1=n+m+1 := by omega
  rw [he] at h₂
  unfold bitIndexEQWork
  nlinarith [show 1 ≤ (n+m+1)^2 by nlinarith]

theorem bitIndexLTWork_le {n m : ℕ} (i : Fin n) (j : Fin m) :
    bitIndexLTWork i j ≤ 65*(n+m+1)^2 := by
  have h := bitIndexLEWork_le j i
  have he : m+n+1=n+m+1 := by omega
  rw [he] at h
  unfold bitIndexLTWork
  nlinarith [show 1 ≤ (n+m+1)^2 by nlinarith]

theorem bitIndexAdjacentWork_le {n m : ℕ} (i : Fin n) (j : Fin m) :
    bitIndexAdjacentWork i j ≤ 128*(n+m+1)^2 := by
  have hi := i.isLt
  have hj := j.isLt
  have hii := bitUnaryAddress_length i.val
  have hjj := bitUnaryAddress_length j.val
  have hnext : (bitListAdd (bitUnaryAddress i.val) [true]).length ≤ n+m+1 := by
    have ht := bitListTrim_length_le (bitListAddAux false (bitUnaryAddress i.val) [true])
    have ha := bitListAddAux_length (bitUnaryAddress i.val) [true] false
    simp only [List.length_cons,List.length_nil] at ha
    exact ht.trans (by omega)
  have hle₁ := bitListLEWork_le (bitListAdd (bitUnaryAddress i.val) [true])
    (bitUnaryAddress j.val) (n+m+1) hnext (by omega)
  have hle₂ := bitListLEWork_le (bitUnaryAddress j.val)
    (bitListAdd (bitUnaryAddress i.val) [true]) (n+m+1) (by omega) hnext
  have ha := bitListAdd_total_visits (bitUnaryAddress i.val) [true]
  have hm : max (bitUnaryAddress i.val).length [true].length ≤ n+m+1 := by
    simp only [List.length_cons,List.length_nil]; omega
  have hiw := bitUnaryAddressWork_le i.val
  have hjw := bitUnaryAddressWork_le j.val
  have hip : (i.val+1)^2 ≤ (n+m+1)^2 := Nat.pow_le_pow_left (by omega) 2
  have hjp : (j.val+1)^2 ≤ (n+m+1)^2 := Nat.pow_le_pow_left (by omega) 2
  unfold bitIndexAdjacentWork
  rw [bitListRippleGates_eq]
  nlinarith

end Optss
