import Optss.CyclicRadixTwo
import Optss.FiniteFourierConvolution

/-!
# Exact Bluestein reduction of an arbitrary cyclic DFT

Quadratic phases live in the finite group of order 2N. Zero padding places
the ordinary chirp convolution into any cyclic group of length at least
3N−2; in particular it may use a power-of-two transform.
-/
namespace Optss
noncomputable section
open scoped BigOperators

/-- Doubling an integer argument cancels doubling of the modulus. -/
theorem stdAddChar_double_modulus (N : ℕ) [NeZero N] (x : ℤ) :
    ZMod.stdAddChar ((2*x:ℤ):ZMod (2*N))=ZMod.stdAddChar (x:ZMod N) := by
  have hN : (N:ℂ)≠0 := by exact_mod_cast (NeZero.ne N)
  rw [ZMod.stdAddChar_coe,ZMod.stdAddChar_coe]
  congr 1
  push_cast
  field_simp
  ring

/-- The sign agrees with mathlib's forward DFT. -/
theorem bluestein_character_identity (N : ℕ) [NeZero N] (j k : ℤ) :
    ZMod.stdAddChar ((-(j*k):ℤ):ZMod N)=
      ZMod.stdAddChar ((-j^2:ℤ):ZMod (2*N))*
      ZMod.stdAddChar ((-k^2:ℤ):ZMod (2*N))*
      ZMod.stdAddChar (((j-k)^2:ℤ):ZMod (2*N)) := by
  rw [← AddChar.map_add_eq_mul,← AddChar.map_add_eq_mul]
  have he : ((-j^2:ℤ):ZMod (2*N))+((-k^2:ℤ):ZMod (2*N))+
      (((j-k)^2:ℤ):ZMod (2*N))=((2*(-(j*k)):ℤ):ZMod (2*N)) := by push_cast; ring
  rw [he,stdAddChar_double_modulus]

noncomputable def bluesteinPaddedInput (N M : ℕ) [NeZero N] [NeZero M]
    (f : ZMod N → ℂ) (x : ZMod M) : ℂ :=
  if x.val<N then f (x.val:ZMod N)*ZMod.stdAddChar ((-(x.val:ℤ)^2:ℤ):ZMod (2*N)) else 0

noncomputable def bluesteinPaddedKernel (N M : ℕ) [NeZero N] [NeZero M]
    (x : ZMod M) : ℂ :=
  if x.val<2*N-1 then ZMod.stdAddChar ((((x.val:ℤ)-(N:ℤ)+1)^2:ℤ):ZMod (2*N)) else 0

/-- Padding converts the relevant cyclic-convolution entries into the
ordinary N-term chirp sum, with no modular wraparound in its support. -/
theorem bluestein_convolution_eq_sum (N M : ℕ) [NeZero N] [NeZero M]
    (hM : 3*N-2≤M) (f : ZMod N → ℂ) (k : Fin N) :
    cyclicConvolution (bluesteinPaddedInput N M f) (bluesteinPaddedKernel N M)
      ((k.val+N-1:ℕ):ZMod M)=
    ∑ j : Fin N, f (j.val:ZMod N)*
      ZMod.stdAddChar ((-(j.val:ℤ)^2:ℤ):ZMod (2*N))*
      ZMod.stdAddChar ((((k.val:ℤ)-(j.val:ℤ))^2:ℤ):ZMod (2*N)) := by
  have hN : 0<N := NeZero.pos N
  have hNM : N≤M := by omega
  have hk := k.isLt
  let S : Finset (ZMod M) := Finset.univ.image (fun j : Fin N => (j.val:ZMod M))
  have hval (j : Fin N) : ((j.val:ZMod M)).val=j.val := by
    rw [ZMod.val_natCast,Nat.mod_eq_of_lt (j.isLt.trans_le hNM)]
  have hinj : Function.Injective (fun j : Fin N => (j.val:ZMod M)) := by
    intro i j he
    apply Fin.ext
    simpa only [hval] using congrArg ZMod.val he
  have hsupport (x : ZMod M) (hx : x∉S) : bluesteinPaddedInput N M f x=0 := by
    unfold bluesteinPaddedInput
    apply if_neg
    intro hh
    exact hx (Finset.mem_image.mpr ⟨⟨x.val,hh⟩,Finset.mem_univ _,ZMod.natCast_zmod_val x⟩)
  have hs := Finset.sum_subset (Finset.subset_univ S)
    (fun x _ hx => by rw [hsupport x hx,zero_mul] :
      ∀ x∈(Finset.univ : Finset (ZMod M)), x∉S →
        bluesteinPaddedInput N M f x*
          bluesteinPaddedKernel N M (((k.val+N-1:ℕ):ZMod M)-x)=0)
  unfold cyclicConvolution
  rw [← hs]
  dsimp only [S]
  rw [Finset.sum_image (fun i _ j _ he => hinj he)]
  apply Finset.sum_congr rfl
  intro j _
  have hj := j.isLt
  have hsub : j.val≤k.val+N-1 := by omega
  have hidx : k.val+N-1-j.val<2*N-1 := by omega
  have hidxM : k.val+N-1-j.val<M := by omega
  have hdiff : ((k.val+N-1:ℕ):ZMod M)-(j.val:ZMod M)=
      ((k.val+N-1-j.val:ℕ):ZMod M) := (Nat.cast_sub hsub).symm
  have hdiffval : (((k.val+N-1:ℕ):ZMod M)-(j.val:ZMod M)).val=k.val+N-1-j.val := by
    rw [hdiff,ZMod.val_natCast,Nat.mod_eq_of_lt hidxM]
  have harg : ((k.val+N-1-j.val:ℕ):ℤ)-(N:ℤ)+1=(k.val:ℤ)-(j.val:ℤ) := by
    omega
  simp only [bluesteinPaddedInput,bluesteinPaddedKernel,hval,if_pos hj,hdiffval,if_pos hidx,harg]

/-- The exact arbitrary-length DFT is one padded cyclic convolution and two
quadratic-phase multiplications. -/
theorem bluestein_dft (N M : ℕ) [NeZero N] [NeZero M]
    (hM : 3*N-2≤M) (f : ZMod N → ℂ) (k : Fin N) :
    ZMod.dft f (k.val:ZMod N)=
      ZMod.stdAddChar ((-(k.val:ℤ)^2:ℤ):ZMod (2*N))*
      cyclicConvolution (bluesteinPaddedInput N M f) (bluesteinPaddedKernel N M)
        ((k.val+N-1:ℕ):ZMod M) := by
  rw [bluestein_convolution_eq_sum N M hM,Finset.mul_sum,ZMod.dft_apply]
  rw [← (ZMod.finEquiv N).toEquiv.sum_comp]
  apply Finset.sum_congr rfl
  intro j _
  rw [smul_eq_mul]
  change ZMod.stdAddChar (-((ZMod.finEquiv N j)*(k.val:ZMod N)))*f (ZMod.finEquiv N j)=_
  rw [zmod_finEquiv_natCast]
  have hc := bluestein_character_identity N (j.val:ℤ) (k.val:ℤ)
  push_cast at hc ⊢
  rw [hc]
  have hs : ((j.val:ZMod (2*N))-(k.val:ZMod (2*N)))^2=
      ((k.val:ZMod (2*N))-(j.val:ZMod (2*N)))^2 := by ring
  rw [hs]
  ring

/-- Chirp multiplication preserves the input norm bound. -/
theorem bluesteinPaddedInput_norm (N M : ℕ) [NeZero N] [NeZero M]
    (f : ZMod N → ℂ) (B : ℝ) (hB : 0≤B) (hf : ∀ j, ‖f j‖≤B) (x : ZMod M) :
    ‖bluesteinPaddedInput N M f x‖≤B := by
  unfold bluesteinPaddedInput
  split_ifs
  · simpa only [norm_mul,AddChar.norm_apply,mul_one] using hf (x.val:ZMod N)
  · simpa only [norm_zero] using hB

theorem bluesteinPaddedKernel_norm (N M : ℕ) [NeZero N] [NeZero M] (x : ZMod M) :
    ‖bluesteinPaddedKernel N M x‖≤1 := by
  unfold bluesteinPaddedKernel
  split_ifs <;> simp only [AddChar.norm_apply,norm_zero,le_refl,zero_le_one]

def bluesteinPadExponent (N : ℕ) : ℕ := Nat.clog 2 (3*N)

theorem bluesteinPadExponent_bounds (N : ℕ) [NeZero N] :
    3*N-2≤2^bluesteinPadExponent N ∧ 2^bluesteinPadExponent N<6*N := by
  have hN : 0<N := NeZero.pos N
  have h3N : 1<3*N := by omega
  have hlo := Nat.le_pow_clog (by decide : 1<2) (3*N)
  have hhi := Nat.pow_pred_clog_lt_self (by decide : 1<2) h3N
  simp only [Nat.pred_eq_sub_one] at hhi
  have he : 0<Nat.clog 2 (3*N) := by
    by_contra hnot
    have hz : Nat.clog 2 (3*N)=0 := by omega
    rw [hz,pow_zero] at hlo
    omega
  have hpow : 2^Nat.clog 2 (3*N)=2*2^(Nat.clog 2 (3*N)-1) := by
    have hh : Nat.clog 2 (3*N)=(Nat.clog 2 (3*N)-1)+1 := by omega
    conv_lhs => rw [hh]
    rw [pow_succ,mul_comm]
  unfold bluesteinPadExponent
  constructor
  · omega
  · rw [hpow]
    omega

/-- A concrete power-of-two length less than six times the original length
suffices for every index of the arbitrary-size DFT. -/
theorem bluestein_dft_power_two (N : ℕ) [NeZero N] (f : ZMod N → ℂ) (k : Fin N) :
    ZMod.dft f (k.val:ZMod N)=
      ZMod.stdAddChar ((-(k.val:ℤ)^2:ℤ):ZMod (2*N))*
      cyclicConvolution (bluesteinPaddedInput N (2^bluesteinPadExponent N) f)
        (bluesteinPaddedKernel N (2^bluesteinPadExponent N))
        ((k.val+N-1:ℕ):ZMod (2^bluesteinPadExponent N)) :=
  bluestein_dft N _ (bluesteinPadExponent_bounds N).1 f k

end
end Optss
