import Optss.ListBluesteinWork
import Optss.BluesteinBitParameters

/-! A literal N times fixed-polynomial-in-bit-length bound for the complete
Boolean/list Bluestein transform. The separate structural initializer and
outer spectrum selection have their own checked source-work bounds. -/
namespace Optss
set_option maxRecDepth 4096
set_option maxHeartbeats 800000

def listDyadicWorkFactor (s p b : ℕ) : ℕ :=
  12*(320*(s+3)^2+4194304*(s+p+73)^2*(8192*(s+p+73)^4+1)^3+16)+
    4*(p+3)+4+3456*(s+1)*(s*(p+6)+b+3)^2

theorem listDyadicWorkPolynomial_factor (N n s p q b c : ℕ)
    (hN : 0 < N) (hn : n≤s) (hp : p≤q) (hb : b≤c) (hM : 2^n≤6*N) :
    listDyadicWorkPolynomial n p b≤N*listDyadicWorkFactor s q c := by
  have hMs : 2^(n+1)≤12*N := by rw [pow_succ]; omega
  have h₁ : 2^(n+1)*(320*(n+3)^2+4194304*(n+p+73)^2*(8192*(n+p+73)^4+1)^3+16)≤
      12*N*(320*(s+3)^2+4194304*(s+q+73)^2*(8192*(s+q+73)^4+1)^3+16) := by gcongr
  have h₂ : 4*(p+3)+4≤N*(4*(q+3)+4) := by
    calc
      _≤4*(q+3)+4 := by omega
      _≤N*(4*(q+3)+4) := Nat.le_mul_of_pos_left _ hN
  have h₃ : 576*(n+1)*2^n*(n*(p+6)+b+3)^2≤
      576*(s+1)*(6*N)*(s*(q+6)+c+3)^2 := by gcongr
  unfold listDyadicWorkPolynomial listDyadicWorkFactor
  generalize 320*(s+3)^2+4194304*(s+q+73)^2*(8192*(s+q+73)^4+1)^3+16 = X at *
  generalize (s*(q+6)+c+3)^2 = Y at *
  generalize 320*(n+3)^2+4194304*(n+p+73)^2*(8192*(n+p+73)^4+1)^3+16 = Z at *
  generalize (n*(p+6)+b+3)^2 = W at *
  nlinarith only [h₁,h₂,h₃]

def listFourierWorkFactor (s : ℕ) : ℕ :=
  let n := s+2
  let p := 5*n+12
  5+864*(s+2)^2+
    2*(4194304*(s+1+p+72)^2*(8192*(s+1+p+72)^4+1)^3)+
    3*listDyadicWorkFactor n p (2*(n*(p+6)+(p+4)+2)+1)+
    3072*(n*(p+6)+(p+4)+3)^2+44+
    512*(3*n*(p+6)+2*(p+4)+8)^2+184

theorem listBluesteinWorkBound_factor (N : ℕ) [NeZero N] :
    listBluesteinWorkBound N (bluesteinPadExponent N)
      (dyadicDFTPrecision (bluesteinPadExponent N))≤N*listFourierWorkFactor N.size := by
  let n := bluesteinPadExponent N
  let p := dyadicDFTPrecision n
  let q := N.size+2
  let t := 5*q+12
  have hN : 0 < N := NeZero.pos N
  have hn : n≤q := bluesteinPadExponent_le_size N
  have hp : p≤t := by dsimp [p,t,dyadicDFTPrecision]; omega
  have hM : 2^n≤6*N := (bluesteinPadExponent_bounds N).2.le
  have hns : (2*N).size≤N.size+1 := by
    apply Nat.size_le.mpr
    rw [pow_succ]
    have hh := Nat.lt_size_self N
    omega
  have hb : 2*(n*(p+6)+(p+4)+2)+1≤2*(q*(t+6)+(t+4)+2)+1 := by gcongr
  have hd := listDyadicWorkPolynomial_factor N n q p t _ _ hN hn hp hb hM
  have hch : 5+N*(864*(N.size+2)^2+
      2*(4194304*((2*N).size+p+72)^2*(characterWorkBits (2*N) (p+2)+1)^3))≤
      N*(5+864*(N.size+2)^2+2*(4194304*(N.size+1+t+72)^2*(8192*(N.size+1+t+72)^4+1)^3)) := by
    have hinner : 4194304*((2*N).size+p+72)^2*(characterWorkBits (2*N) (p+2)+1)^3≤
        4194304*(N.size+1+t+72)^2*(8192*(N.size+1+t+72)^4+1)^3 := by
      have hbase : (2*N).size+p+72≤N.size+1+t+72 := by omega
      have hbase' : (2*N).size+(p+2)+70≤N.size+1+t+72 := by omega
      exact Nat.mul_le_mul
        (Nat.mul_le_mul_left 4194304 (Nat.pow_le_pow_left hbase 2))
        (Nat.pow_le_pow_left (Nat.add_le_add_right
          (Nat.mul_le_mul_left 8192 (Nat.pow_le_pow_left hbase' 4)) 1) 3)
    have hm := Nat.mul_le_mul_left (2*N) hinner
    generalize 4194304*((2*N).size+p+72)^2*(characterWorkBits (2*N) (p+2)+1)^3 = X at *
    generalize 4194304*(N.size+1+t+72)^2*(8192*(N.size+1+t+72)^4+1)^3 = Y at *
    nlinarith only [hm,hN]
  have hm : 512*2^n*(n*(p+6)+(p+4)+3)^2≤
      3072*N*(q*(t+6)+(t+4)+3)^2 := by
    calc
      _≤512*(6*N)*(q*(t+6)+(t+4)+3)^2 := by gcongr
      _=_ := by ring
  have hpoint : 512*N*(3*n*(p+6)+2*(p+4)+8)^2≤512*N*(3*q*(t+6)+2*(t+4)+8)^2 := by gcongr
  have hnM : n≤2^n := Nat.lt_two_pow_self.le
  have hadmin : (2*2^n+2*n)+32*N+16*2^n+32≤184*N := by omega
  have hsmall : 6*2^n+8≤44*N := by omega
  change listBluesteinWorkBound N n p≤_
  unfold listBluesteinWorkBound listFourierWorkFactor
  change _≤N*(5+864*(N.size+2)^2+2*(4194304*(N.size+1+t+72)^2*(8192*(N.size+1+t+72)^4+1)^3)+
    3*listDyadicWorkFactor q t (2*(q*(t+6)+(t+4)+2)+1)+
    3072*(q*(t+6)+(t+4)+3)^2+44+512*(3*q*(t+6)+2*(t+4)+8)^2+184)
  generalize 4194304*((2*N).size+p+72)^2*(characterWorkBits (2*N) (p+2)+1)^3 = X at *
  generalize 4194304*(N.size+1+t+72)^2*(8192*(N.size+1+t+72)^4+1)^3 = Y at *
  generalize listDyadicWorkPolynomial n p (2*(n*(p+6)+(p+4)+2)+1) = U at *
  generalize listDyadicWorkFactor q t (2*(q*(t+6)+(t+4)+2)+1) = V at *
  generalize (n*(p+6)+(p+4)+3)^2 = W at *
  generalize (q*(t+6)+(t+4)+3)^2 = Z at *
  generalize (3*n*(p+6)+2*(p+4)+8)^2 = R at *
  generalize (3*q*(t+6)+2*(t+4)+8)^2 = S at *
  nlinarith only [hch,hd,hm,hpoint,hadmin,hsmall]

def listCanonicalDyadicDFTWork (input : List Bool) : ℕ :=
  let n := bluesteinPadExponent input.length
  listBluesteinTransformWork (List.replicate n false) (dyadicDFTPrecision n) input

theorem listCanonicalDyadicDFTWork_bound (input : List Bool) (hinput : input≠[]) :
    listCanonicalDyadicDFTWork input≤ input.length*listFourierWorkFactor input.length.size := by
  haveI : NeZero input.length := ⟨by have := List.length_pos_iff.mpr hinput; omega⟩
  have h := listBluesteinTransformWork_bound (List.replicate (bluesteinPadExponent input.length) false)
    (dyadicDFTPrecision (bluesteinPadExponent input.length)) input hinput
  simp only [List.length_replicate] at h
  exact h.trans (listBluesteinWorkBound_factor input.length)

end Optss
