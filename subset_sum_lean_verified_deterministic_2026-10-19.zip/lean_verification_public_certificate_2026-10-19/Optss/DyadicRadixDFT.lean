import Optss.DyadicFourierTwiddles

/-! A deterministic fixed-point DFT at power-of-two lengths. Twiddle
generation is explicit and materialized. The statements below certify
accuracy and stored integer heights; they do not identify arithmetic-call
counts with bit-operation runtime. -/
namespace Optss

def dyadicRadixDFT (n p : ℕ) (A : Vector FourierInteger (2^n)) : Vector FourierInteger (2^n) :=
  let T := dyadicCharacterTable n p
  fixedPointRadixTwo (dyadicFourierDenominator p) (dyadicTwiddleFromTable n T) n A

theorem dyadicRadixDFT_error (n p : ℕ) (A : Vector FourierInteger (2^n))
    (B : ℝ) (hB : 0≤B) (hA : ∀ j, ‖fourierIntegerValue (A.get j)‖≤B)
    (k : Fin (2^n)) :
    ‖fourierIntegerValue ((dyadicRadixDFT n p A).get k)/(dyadicFourierDenominator p : ℂ)^n-
      radixDft n (cyclicFftRoot (2^n)) (fourierIntegerVectorValue A) k.val‖≤
        (n : ℝ)*3^n*(1/2 : ℝ)^p*B := by
  dsimp only [dyadicRadixDFT]
  have hdecode := fixedPointRadixTwo_decode (dyadicFourierDenominator p)
    (by exact_mod_cast (dyadicFourierDenominator_pos p).ne')
    (dyadicTwiddleFromTable n (dyadicCharacterTable n p)) n A k
  simp only [Int.cast_natCast] at hdecode
  rw [hdecode]
  have h := radixTwoTransform_error
    (fun l i => fourierIntegerValue (dyadicTwiddleFromTable n (dyadicCharacterTable n p) l i)/
      (dyadicFourierDenominator p : ℂ))
    (cyclicRadixTwiddle n) n (fourierIntegerVectorValue A) B ((1/2 : ℝ)^p) hB
    (by positivity) (pow_le_one₀ (by norm_num) (by norm_num))
    (fun j => by simpa only [fourierIntegerVectorValue,vector_get_ofFn] using hA j)
    (fun l _ i => (cyclicRadixTwiddle_norm n l i).le)
    (fun l _ i => dyadicTwiddleFromTable_error n p l i) k
  have he := radixTwoTransform_exact (cyclicRadixTwiddle n) n (cyclicFftRoot (2^n))
    (fourierIntegerVectorValue A) (fun _ _ _ => rfl)
  rw [he,radixTwoFFT_correct _ _ _ (cyclicFftRoot_period _)] at h
  simpa only [Int.cast_natCast] using h

theorem fourierIntegerVectorValue_cyclic (n : ℕ) (f : ZMod (2^n) → FourierInteger) :
    fourierIntegerVectorValue (cyclicVectorData n f)=
      cyclicVectorData n (fun j => fourierIntegerValue (f j)) := by
  apply Vector.ext
  intro i hi
  change (Vector.ofFn _).get ⟨i,hi⟩=(Vector.ofFn _).get ⟨i,hi⟩
  simp only [vector_get_ofFn,fourierIntegerVectorValue,cyclicVectorData]

theorem dyadicRadixDFT_cyclic_error (n p : ℕ) (f : ZMod (2^n) → FourierInteger)
    (B : ℝ) (hB : 0≤B) (hf : ∀ j, ‖fourierIntegerValue (f j)‖≤B) (k : Fin (2^n)) :
    ‖fourierIntegerValue ((dyadicRadixDFT n p (cyclicVectorData n f)).get k)/
      (dyadicFourierDenominator p : ℂ)^n-
      ZMod.dft (fun j => fourierIntegerValue (f j)) (k.val : ZMod (2^n))‖≤
        (n : ℝ)*3^n*(1/2 : ℝ)^p*B := by
  have h := dyadicRadixDFT_error n p (cyclicVectorData n f) B hB
    (fun j => by simpa only [cyclicVectorData,vector_get_ofFn] using hf (j.val : ZMod (2^n))) k
  rwa [fourierIntegerVectorValue_cyclic,radixDft_eq_cyclic_dft] at h

theorem dyadicFourierDenominator_size (p : ℕ) : (dyadicFourierDenominator p).size=p+3 := by
  simp [dyadicFourierDenominator,Nat.size_pow,Nat.add_assoc]

/-- The actual output integer coordinates have at most this many binary
digits. The bound is linear in depth times requested precision. -/
theorem dyadicRadixDFT_entry_bits (n p B : ℕ) (A : Vector FourierInteger (2^n))
    (hA : ∀ j, FourierIntegerBound (A.get j) B) (k : Fin (2^n)) :
    ((dyadicRadixDFT n p A).get k).re.natAbs.size≤n*(p+6)+B.size+1 ∧
      ((dyadicRadixDFT n p A).get k).im.natAbs.size≤n*(p+6)+B.size+1 := by
  have h := fixedPointRadixTwo_entry_bits (dyadicFourierDenominator p) B
    (dyadicTwiddleFromTable n (dyadicCharacterTable n p)) n A hA
    (fun l _ i => dyadicTwiddleFromTable_bound n p l i) k
  simpa only [dyadicRadixDFT,dyadicFourierDenominator_size,Nat.add_assoc] using h

end Optss
