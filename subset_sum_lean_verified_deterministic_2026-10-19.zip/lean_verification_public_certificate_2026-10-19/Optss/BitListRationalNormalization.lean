import Optss.BitListGcd
import Optss.BinaryRationalNormalization

/-!
# Fraction normalization performed on Boolean lists

Numerator and denominator magnitudes are divided by their Boolean-list gcd.
The sign is retained as one Boolean; zero may carry either sign. The answer
routine uses no natural-number magnitude arithmetic. Decoding to rationals
appears only in the mathematical specification.
-/

namespace Optss

structure BitListFraction where
  negative : Bool
  numerator : List Bool
  denominator : List Bool
  deriving Repr, DecidableEq

def signedBitsValue (negative : Bool) (digits : List Bool) : ℤ :=
  if negative then -(binaryDigitsValue digits:ℤ) else (binaryDigitsValue digits:ℤ)

def bitListFractionValue (q : BitListFraction) : ℚ :=
  (signedBitsValue q.negative q.numerator:ℚ)/(binaryDigitsValue q.denominator:ℚ)

def bitListNormalizeFraction (negative : Bool) (ns ds : List Bool) : BitListFraction :=
  let g := bitListGcd ns ds
  let n := bitListDivision ns g
  let d := bitListDivision ds g
  ⟨negative,n.quotient,d.quotient⟩

theorem bitListNormalizeFraction_fields (negative : Bool) (ns ds : List Bool)
    (hd : 0 < binaryDigitsValue ds) :
    (bitListNormalizeFraction negative ns ds).negative = negative ∧
    (bitListNormalizeFraction negative ns ds).numerator =
      (binaryDigitsValue ns/(binaryDigitsValue ns).gcd (binaryDigitsValue ds)).bits ∧
    (bitListNormalizeFraction negative ns ds).denominator =
      (binaryDigitsValue ds/(binaryDigitsValue ns).gcd (binaryDigitsValue ds)).bits := by
  have hg : 0 < binaryDigitsValue (bitListGcd ns ds) := by
    rw [bitListGcd_correct]
    exact Nat.gcd_pos_of_pos_right _ hd
  have hn := (bitListDivision_encodings ns (bitListGcd ns ds) hg).1
  have hden := (bitListDivision_encodings ds (bitListGcd ns ds) hg).1
  simp only [bitListGcd_correct] at hn hden
  exact ⟨rfl,hn,hden⟩

theorem bitListNormalizeFraction_reduced (negative : Bool) (ns ds : List Bool)
    (hd : 0 < binaryDigitsValue ds) :
    BitListCanonical (bitListNormalizeFraction negative ns ds).numerator ∧
    BitListCanonical (bitListNormalizeFraction negative ns ds).denominator ∧
    0 < binaryDigitsValue (bitListNormalizeFraction negative ns ds).denominator ∧
    (binaryDigitsValue (bitListNormalizeFraction negative ns ds).numerator).Coprime
      (binaryDigitsValue (bitListNormalizeFraction negative ns ds).denominator) := by
  obtain ⟨_, hn, hden⟩ := bitListNormalizeFraction_fields negative ns ds hd
  rw [hn,hden]
  simp only [BitListCanonical, binaryDigitsValue_bits]
  exact ⟨True.intro,True.intro,Nat.div_gcd_pos_of_pos_right _ hd,
    Nat.coprime_div_gcd_div_gcd (Nat.gcd_pos_of_pos_right _ hd)⟩

theorem bitListNormalizeFraction_correct (negative : Bool) (ns ds : List Bool)
    (hd : 0 < binaryDigitsValue ds) :
    bitListFractionValue (bitListNormalizeFraction negative ns ds) =
      (signedBitsValue negative ns:ℚ)/(binaryDigitsValue ds:ℚ) := by
  obtain ⟨hs,hn,hden⟩ := bitListNormalizeFraction_fields negative ns ds hd
  unfold bitListFractionValue
  rw [hs,hn,hden]
  have hg : (((binaryDigitsValue ns).gcd (binaryDigitsValue ds)):ℚ) ≠ 0 := by
    exact_mod_cast (Nat.gcd_pos_of_pos_right (binaryDigitsValue ns) hd).ne'
  have hdq : (binaryDigitsValue ds:ℚ) ≠ 0 := by exact_mod_cast hd.ne'
  unfold signedBitsValue
  simp only [binaryDigitsValue_bits]
  cases negative <;> simp only [Bool.false_eq_true, Bool.true_eq, ↓reduceIte,
    Int.cast_neg, Int.cast_natCast]
  all_goals
    rw [Nat.cast_div (Nat.gcd_dvd_left _ _) hg,
      Nat.cast_div (Nat.gcd_dvd_right _ _) hg]
    field_simp <;> ring

/-- Gate/list work for gcd and both divisions, with constant record overhead.
These counters are not executed by the answer routine. -/
def bitListNormalizeFractionCost (ns ds : List Bool) : ℕ :=
  let g := bitListGcd ns ds
  bitListGcdCost ns ds+bitListDivisionCost ns g+bitListDivisionCost ds g+3

theorem bitListNormalizeFractionCost_bound (ns ds : List Bool)
    (hd : 0 < binaryDigitsValue ds) (L : ℕ) (hn : ns.length ≤ L) (hden : ds.length ≤ L) :
    bitListNormalizeFractionCost ns ds ≤ 128*(L+1)^3 := by
  let g := bitListGcd ns ds
  have hg : 0 < binaryDigitsValue g := by
    rw [bitListGcd_correct]
    exact Nat.gcd_pos_of_pos_right _ hd
  have hgl : g.length ≤ L := by
    rw [(bitListGcd_canonical ns ds).length, bitListGcd_correct]
    exact ((Nat.size_le_size (Nat.gcd_le_right _ hd)).trans
      (Nat.size_le.mpr (binaryDigitsValue_lt_pow ds))).trans hden
  have hG := bitListGcdCost_bound ns ds L hn hden
  have hN := bitListDivisionCost_uniform ns g hg L hn hgl
  have hD := bitListDivisionCost_uniform ds g hg L hden hgl
  change bitListGcdCost ns ds+bitListDivisionCost ns g+bitListDivisionCost ds g+3 ≤ _
  nlinarith [show 1 ≤ (L+1)^2 by nlinarith]

end Optss
