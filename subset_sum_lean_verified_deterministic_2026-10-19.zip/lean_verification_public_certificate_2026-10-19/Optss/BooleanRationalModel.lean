import Optss.BitListRationalOperations
import Optss.CachedReductionCost

/-!
# Boolean-list arithmetic in the cached reduction evaluator

The four rational operations execute the verified Boolean-list algorithms and
reconstruct their already coprime outputs without another normalization. Their
charges count Boolean gates and list visits. Encoding/decoding rational fields,
integer row updates, rounding, comparisons, containers and fuel construction
remain separate from these charges.
-/

namespace Optss
variable {r d : ℕ}

def booleanRatAdd (p q : ℚ) : ℚ × ℕ :=
  let P := rationalBitRepresentation p
  let Q := rationalBitRepresentation q
  ((bitListFractionAdd P Q).toRat
    (bitListFractionAdd_wellFormed P Q
      (rationalBitRepresentation_wellFormed p).2.2.1
      (rationalBitRepresentation_wellFormed q).2.2.1),
    bitListFractionAddCost P Q)

theorem booleanRatAdd_correct (p q : ℚ) :
    (booleanRatAdd p q).1 = p + q := by
  unfold booleanRatAdd
  dsimp only
  rw [BitListFraction.toRat_value, bitListFractionAdd_correct _ _
    (rationalBitRepresentation_wellFormed p).2.2.1
    (rationalBitRepresentation_wellFormed q).2.2.1,
    rationalBitRepresentation_value, rationalBitRepresentation_value]

def booleanRatSub (p q : ℚ) : ℚ × ℕ :=
  let P := rationalBitRepresentation p
  let Q := rationalBitRepresentation q
  ((bitListFractionSub P Q).toRat
    (bitListFractionSub_wellFormed P Q
      (rationalBitRepresentation_wellFormed p).2.2.1
      (rationalBitRepresentation_wellFormed q).2.2.1),
    bitListFractionSubCost P Q)

theorem booleanRatSub_correct (p q : ℚ) :
    (booleanRatSub p q).1 = p - q := by
  unfold booleanRatSub
  dsimp only
  rw [BitListFraction.toRat_value, bitListFractionSub_correct _ _
    (rationalBitRepresentation_wellFormed p).2.2.1
    (rationalBitRepresentation_wellFormed q).2.2.1,
    rationalBitRepresentation_value, rationalBitRepresentation_value]

def booleanRatMul (p q : ℚ) : ℚ × ℕ :=
  let P := rationalBitRepresentation p
  let Q := rationalBitRepresentation q
  ((bitListFractionMul P Q).toRat
    (bitListFractionMul_wellFormed P Q
      (rationalBitRepresentation_wellFormed p).2.2.1
      (rationalBitRepresentation_wellFormed q).2.2.1),
    bitListFractionMulCost P Q)

theorem booleanRatMul_correct (p q : ℚ) :
    (booleanRatMul p q).1 = p * q := by
  unfold booleanRatMul
  dsimp only
  rw [BitListFraction.toRat_value, bitListFractionMul_correct _ _
    (rationalBitRepresentation_wellFormed p).2.2.1
    (rationalBitRepresentation_wellFormed q).2.2.1,
    rationalBitRepresentation_value, rationalBitRepresentation_value]

def booleanRatDiv (p q : ℚ) : ℚ × ℕ :=
  let P := rationalBitRepresentation p
  let Q := rationalBitRepresentation q
  ((bitListFractionDiv P Q).toRat
    (bitListFractionDiv_wellFormed P Q
      (rationalBitRepresentation_wellFormed p).2.2.1),
    bitListFractionDivCost P Q)

theorem booleanRatDiv_correct (p q : ℚ) :
    (booleanRatDiv p q).1 = p / q := by
  unfold booleanRatDiv
  dsimp only
  rw [BitListFraction.toRat_value, bitListFractionDiv_correct _ _
    (rationalBitRepresentation_wellFormed p).2.2.1
    (rationalBitRepresentation_wellFormed q).2.2.1,
    rationalBitRepresentation_value, rationalBitRepresentation_value]

def booleanRationalArithmetic : RationalArithmetic where
  add := booleanRatAdd
  sub := booleanRatSub
  mul := booleanRatMul
  div := booleanRatDiv
  add_value := booleanRatAdd_correct
  sub_value := booleanRatSub_correct
  mul_value := booleanRatMul_correct
  div_value := booleanRatDiv_correct

theorem booleanRationalArithmetic_cubic (p q : ℚ) (L : ℕ)
    (hp : RationalBitBound p L) (hq : RationalBitBound q L) :
    (booleanRationalArithmetic.add p q).2 ≤ 4096*(L+1)^3 ∧
    (booleanRationalArithmetic.sub p q).2 ≤ 4096*(L+1)^3 ∧
    (booleanRationalArithmetic.mul p q).2 ≤ 4096*(L+1)^3 ∧
    (booleanRationalArithmetic.div p q).2 ≤ 4096*(L+1)^3 := by
  have hpl := (rationalBitRepresentation_bound p L).mp hp
  have hql := (rationalBitRepresentation_bound q L).mp hq
  have hpd := (rationalBitRepresentation_wellFormed p).2.2.1
  have hqd := (rationalBitRepresentation_wellFormed q).2.2.1
  have ha := bitListFractionAddCost_bound _ _ hpd hqd L hpl hql
  have hs := bitListFractionSubCost_bound _ _ hpd hqd L hpl hql
  have hm := bitListFractionMulCost_bound _ _ hpd hqd L hpl hql
  have hd := bitListFractionDivCost_bound _ _ hpd L hpl hql
  change bitListFractionAddCost _ _ ≤ _ ∧ bitListFractionSubCost _ _ ≤ _ ∧
    bitListFractionMulCost _ _ ≤ _ ∧ bitListFractionDivCost _ _ ≤ _
  exact ⟨ha.trans (by omega), hs, hm.trans (by omega), hd.trans (by omega)⟩

theorem booleanMeteredCachedData_value (A : Matrix (Fin r) (Fin d) ℤ) :
    ((meteredCachedData booleanRationalArithmetic A).rows,
      (meteredCachedData booleanRationalArithmetic A).swaps) = cachedReductionData A :=
  meteredCachedData_value booleanRationalArithmetic A

/-- The concrete Boolean rational backend preserves the full reduction
specification. This is a correctness result, not a total bit-runtime theorem. -/
theorem booleanMeteredCachedData_spec (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j : ℝ))) :
    IntegerReductionSpecification A
      (integerMatrixDataRows (meteredCachedData booleanRationalArithmetic A).rows)
      (meteredCachedData booleanRationalArithmetic A).swaps := by
  have he := booleanMeteredCachedData_value A
  have h := cachedIntegerReduction_spec A hA
  rw [← he] at h
  exact h

end Optss
