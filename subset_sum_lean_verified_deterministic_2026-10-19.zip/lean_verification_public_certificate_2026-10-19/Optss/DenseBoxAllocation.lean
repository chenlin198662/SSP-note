import Optss.DenseBoxReserve

/-!
# Actual disjoint allocation of axis batches and a residue reserve

Labels are natural indices. Each axis receives one consecutive block of
`q` indices, and the residue reserve receives the next `M`. The support
of these labels embeds in the full support when every unused label can
contribute zero.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

/-- Consecutive coordinate-label block. -/
def fillingAxisBatch {d : ℕ} (q : ℕ) (j : Fin d) : Finset ℕ :=
  Finset.Ico (j.val * q) ((j.val + 1) * q)

/-- Consecutive residue labels following all coordinate blocks. -/
def fillingReserveBatch (d q M : ℕ) : Finset ℕ := Finset.Ico (d * q) (d * q + M)

@[simp] theorem fillingAxisBatch_card {d : ℕ} (q : ℕ) (j : Fin d) :
    (fillingAxisBatch q j).card = q := by simp [fillingAxisBatch, Nat.add_mul]

@[simp] theorem fillingReserveBatch_card (d q M : ℕ) :
    (fillingReserveBatch d q M).card = M := by simp [fillingReserveBatch]

/-- Axis blocks never reuse a label. -/
theorem fillingAxisBatch_disjoint (d q : ℕ) :
    ((Finset.univ : Finset (Fin d)) : Set (Fin d)).PairwiseDisjoint (fillingAxisBatch q) := by
  intro i hi j hj hij
  apply Finset.disjoint_left.mpr
  intro x hxi hxj
  have hxi' := Finset.mem_Ico.mp hxi
  have hxj' := Finset.mem_Ico.mp hxj
  have hij' : i.val ≠ j.val := fun h => hij (Fin.ext h)
  rcases lt_or_gt_of_ne hij' with h | h
  · have hh := Nat.mul_le_mul_right q (show i.val + 1 ≤ j.val by omega)
    omega
  · have hh := Nat.mul_le_mul_right q (show j.val + 1 ≤ i.val by omega)
    omega

/-- Every axis label precedes the residue reserve. -/
theorem fillingAxisBatch_lt {d q : ℕ} {j : Fin d} {i : ℕ} (hi : i ∈ fillingAxisBatch q j) :
    i < d * q := by
  have hh := (Finset.mem_Ico.mp hi).2
  have hd := Nat.mul_le_mul_right q (show j.val + 1 ≤ d by omega)
  omega

/-- The residue labels are disjoint from all axis blocks. -/
theorem fillingReserveBatch_disjoint (d q M : ℕ) :
    Disjoint (Finset.univ.biUnion (fillingAxisBatch (d := d) q)) (fillingReserveBatch d q M) := by
  apply Finset.disjoint_left.mpr
  intro i hi hR
  obtain ⟨j, hj, hij⟩ := Finset.mem_biUnion.mp hi
  have hlt := fillingAxisBatch_lt hij
  have hlo := (Finset.mem_Ico.mp hR).1
  omega

/-- All allocated labels lie in the actual input index interval. -/
theorem filling_allocation_subset (d q M N : ℕ) (h : d * q + M ≤ N) :
    (Finset.univ.biUnion (fillingAxisBatch (d := d) q)) ∪ fillingReserveBatch d q M ⊆ Finset.range N := by
  intro i hi
  rw [Finset.mem_range]
  rcases Finset.mem_union.mp hi with hi | hi
  · obtain ⟨j, hj, hij⟩ := Finset.mem_biUnion.mp hi
    have hh := fillingAxisBatch_lt hij
    omega
  · have hh := (Finset.mem_Ico.mp hi).2
    omega

/-- Adding unused zero-containing summands preserves every already
constructed support point. -/
theorem filling_sum_subset_of_subset {ι G : Type*} [DecidableEq ι]
    [AddCommMonoid G] [DecidableEq G] (S T : Finset ι) (A : ι → Finset G)
    (hST : S ⊆ T) (hzero : ∀ i ∈ T, 0 ∈ A i) :
    (∑ i ∈ S, A i) ⊆ ∑ i ∈ T, A i := by
  have hz : (0 : G) ∈ ∑ i ∈ T \ S, A i := by
    have hh : ∀ U : Finset ι, (∀ i ∈ U, 0 ∈ A i) → (0 : G) ∈ ∑ i ∈ U, A i := by
      intro U
      induction U using Finset.induction_on with
      | empty => simp
      | @insert i U hi ih =>
        intro hU
        rw [Finset.sum_insert hi]
        simpa using Finset.add_mem_add (hU i (Finset.mem_insert_self _ _))
          (ih (fun j hj => hU j (Finset.mem_insert_of_mem hj)))
    exact hh _ (fun i hi => hzero i (Finset.mem_sdiff.mp hi).1)
  intro x hx
  rw [← Finset.sum_sdiff hST]
  exact Finset.mem_add.mpr ⟨0, hz, x, hx, by simp⟩

/-- For `q = floor(N/(2d))`, at most half the labels are consumed by
axis blocks, leaving room for any reserve of size at most `N/2`. -/
theorem filling_allocation_count (d N M : ℕ) (_hd : 0 < d) (hM : 2 * M ≤ N) :
    d * (N / (2 * d)) + M ≤ N := by
  have hh := Nat.div_mul_le_self N (2 * d)
  nlinarith

/-- The actual floor-sized blocks each have at least `N/(4d)` labels
once `N ≥ 2d`; this is stated without division. -/
theorem filling_block_lower_bound (d N : ℕ) (hd : 0 < d) (hN : 2 * d ≤ N) :
    N ≤ 4 * d * (N / (2 * d)) := by
  have hq : 1 ≤ N / (2 * d) := Nat.one_le_div_iff (by omega : 0 < 2 * d) |>.mpr hN
  have hh := Nat.lt_mul_div_succ N (show 0 < 2 * d by omega)
  nlinarith

end
end Optss
