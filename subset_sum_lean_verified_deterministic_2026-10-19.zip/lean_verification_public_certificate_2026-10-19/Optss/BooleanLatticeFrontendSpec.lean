import Optss.BooleanLatticeFrontend

/-! # Exact geometric specification of the complete native frontend -/
namespace Optss
open scoped BigOperators
variable {r m : ℕ}

theorem bitSelectedVertexMatrix_det_ne_zero
    (V : ListBitRationalMatrixData r m)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hspan : Submodule.span ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))=⊤)
    (A : ListBitRationalMatrixData r r) (hA : bitSelectedVertexMatrix V=some A) :
    (storedRationalMatrix A).det≠0 := by
  obtain ⟨B,hB,b,hcolumns,_⟩ := bitSelectedVertexMatrix_basis V hV hspan
  have he : B=A := Option.some.inj (hB.symm.trans hA)
  subst B
  exact (rational_basis_inverse b (storedRationalMatrix A) hcolumns).1

/-- A full-dimensional centrally symmetric input vertex set yields an actual
normalization and an actual reduced basis of the entire normalized input
lattice. The normalization matrix in both products is the one returned by
the executed Boolean inverse, and the sharp defect is certified for the
executed list-stored LLL output. -/
theorem booleanLatticeFrontend_spec (hr : 0<r)
    (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetG : (storedRationalMatrix G).det≠0)
    (hspan : Submodule.span ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))=⊤)
    (hsym : ∀ x∈rationalVertexSet (storedRationalVertices V),-x∈rationalVertexSet (storedRationalVertices V)) :
    ∃ out,booleanLatticeFrontend V G=some out ∧
      ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
        (∀ i j,((storedRationalMatrix out.selectedColumns i j):ℝ)=b j i) ∧
        (∀ x : Fin r → ℝ,∀ i,basisEuclideanNormalization b x i=
          ∑ j,(storedRationalMatrix out.coordinateMatrix i j:ℝ)*x j) ∧
        {x : EuclideanSpace ℝ (Fin r) | ∀ j,|x j|≤1/(r:ℝ)} ⊆
          basisEuclideanNormalization b '' convexHull ℝ (rationalVertexSet (storedRationalVertices V) : Set _) ∧
        basisEuclideanNormalization b '' convexHull ℝ (rationalVertexSet (storedRationalVertices V) : Set _) ⊆
          {x | ∀ j,|x j|≤1} ∧
        storedRationalMatrix out.normalizedVertices=storedRationalMatrix out.coordinateMatrix*storedRationalMatrix V ∧
        storedRationalMatrix out.normalizedLatticeColumns=storedRationalMatrix out.coordinateMatrix*storedRationalMatrix G ∧
        Submodule.span ℤ (Set.range (storedRationalMatrix out.reducedLatticeRows))=
          Submodule.span ℤ (Set.range (storedRationalMatrix out.normalizedLatticeColumns).transpose) ∧
        ∃ reduced : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)),
          (∀ i,reduced i=rationalEuclideanRows (storedRationalMatrix out.reducedLatticeRows) i) ∧
          euclideanOrthogonalityDefect reduced≤sharpLatticeDefectBound r := by
  obtain ⟨A,hselected,b,hcols,hi,ho,_⟩ := bitSelectedVertexMatrix_normalization hr V hV hspan hsym
  have hA := bitSelectedVertexMatrix_wellFormed V hV A hselected
  obtain ⟨hdetA,_,_,hcoord⟩ := rational_basis_inverse b (storedRationalMatrix A) hcols
  let out := booleanLatticeFrontendFromBasis A V G
  have hc := booleanLatticeFrontendFromBasis_coordinates A V G hA hV hG
  have hred := booleanLatticeFrontendFromBasis_reduction A V G hA hG hdetA hdetG
  change storedRationalMatrix out.coordinateMatrix=(storedRationalMatrix A)⁻¹ ∧
    storedRationalMatrix out.normalizedVertices=(storedRationalMatrix A)⁻¹*storedRationalMatrix V ∧
    storedRationalMatrix out.normalizedLatticeColumns=(storedRationalMatrix A)⁻¹*storedRationalMatrix G at hc
  change Submodule.span ℤ (Set.range (storedRationalMatrix out.reducedLatticeRows))=
    Submodule.span ℤ (Set.range (((storedRationalMatrix A)⁻¹*storedRationalMatrix G).transpose)) ∧ _ at hred
  refine ⟨out,?_,b,hcols,?_,hi,ho,?_,?_,?_,hred.2⟩
  · rw [booleanLatticeFrontend,hselected]
    rfl
  · intro x i
    rw [hc.1]
    exact congrFun (hcoord x) i
  · rw [hc.1]
    exact hc.2.1
  · rw [hc.1]
    exact hc.2.2
  · rw [hc.2.2]
    exact hred.1

theorem booleanLatticeFrontend_wellFormed
    (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetG : (storedRationalMatrix G).det≠0)
    (hspan : Submodule.span ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))=⊤)
    (out : BooleanLatticeFrontendResult r m) (hout : booleanLatticeFrontend V G=some out) :
    (∀ i j,(rectangularListFractionMatrix out.selectedColumns i j).WellFormed) ∧
    (∀ i j,(rectangularListFractionMatrix out.coordinateMatrix i j).WellFormed) ∧
    (∀ i j,(rectangularListFractionMatrix out.normalizedVertices i j).WellFormed) ∧
    (∀ i j,(rectangularListFractionMatrix out.normalizedLatticeColumns i j).WellFormed) ∧
    (∀ i j,(rectangularListFractionMatrix out.reducedLatticeRows i j).WellFormed) := by
  unfold booleanLatticeFrontend at hout
  cases he : bitSelectedVertexMatrix V with
  | none => simp [he] at hout
  | some A =>
    rw [he] at hout
    replace hout : booleanLatticeFrontendFromBasis A V G=out := Option.some.inj hout
    subst out
    have hA := bitSelectedVertexMatrix_wellFormed V hV A he
    exact ⟨hA,booleanLatticeFrontendFromBasis_wellFormed A V G hA hV hG
      (bitSelectedVertexMatrix_det_ne_zero V hV hspan A he) hdetG⟩
end Optss
