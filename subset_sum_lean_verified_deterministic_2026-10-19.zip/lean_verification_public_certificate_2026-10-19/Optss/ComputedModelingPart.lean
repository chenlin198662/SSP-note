import Optss.ComputedModelingParameters

/-!
# Executable choice of the largest of eight residue parts

The selector compares actual list lengths over exactly eight candidate parts.
Its mathematical guarantee is the pigeonhole bound used in Lemma 10.2.
-/
namespace Optss
open scoped BigOperators

def chooseMaxScore {α : Type} (score : α→ℕ) (best : α) : List α→α
  | [] => best
  | x::xs => chooseMaxScore score (if score best≤score x then x else best) xs

theorem chooseMaxScore_ge {α : Type} (score : α→ℕ) (best : α) (xs : List α) :
    score best≤score (chooseMaxScore score best xs) ∧
      ∀ x∈xs, score x≤score (chooseMaxScore score best xs) := by
  induction xs generalizing best with
  | nil => simp [chooseMaxScore]
  | cons x xs ih =>
    let next := if score best≤score x then x else best
    have hn₁ : score best≤score next := by dsimp [next]; split_ifs <;> omega
    have hn₂ : score x≤score next := by dsimp [next]; split_ifs <;> omega
    have hh := ih next
    refine ⟨hn₁.trans hh.1,?_⟩
    intro y hy
    rcases List.mem_cons.mp hy with rfl | hy
    · exact hn₂.trans hh.1
    · exact hh.2 y hy

def computedModelingPartNumber (n q : ℕ) (a : ℤ) : ℕ :=
  8*((n:ZMod q)*(a:ZMod q)).val/q

def computedModelingPartAt (data : List ℤ) (n q : ℕ) (j : Fin 8) : List ℤ :=
  data.filter (fun a => computedModelingPartNumber n q a=j.val)

def computedModelingPartIndex (data : List ℤ) (n q : ℕ) : Fin 8 :=
  chooseMaxScore (fun j => (computedModelingPartAt data n q j).length) 0 (List.finRange 8)

def computedModelingPart (data : List ℤ) (n q : ℕ) : List ℤ :=
  computedModelingPartAt data n q (computedModelingPartIndex data n q)

theorem computedModelingPart_max (data : List ℤ) (n q : ℕ) (j : Fin 8) :
    (computedModelingPartAt data n q j).length≤(computedModelingPart data n q).length :=
  (chooseMaxScore_ge (fun j => (computedModelingPartAt data n q j).length)
    0 (List.finRange 8)).2 j (by simp)

theorem modelingPartIndex_number (n q : ℕ) (hq : 0<q) (a : ℤ) :
    (modelingPartIndex hq (n:ZMod q) a).val=computedModelingPartNumber n q a := by
  simp only [modelingPartIndex,modelingResidue,computedModelingPartNumber]
  exact_mod_cast (Int.toNat_natCast (8*((n:ZMod q)*(a:ZMod q)).val/q))

theorem computedModelingPartAt_finset (data : List ℤ) (n q : ℕ) (hq : 0<q) (j : Fin 8) :
    (computedModelingPartAt data n q j).toFinset=
      data.toFinset.filter (fun a => modelingPartIndex hq (n:ZMod q) a=j) := by
  ext a
  simp only [List.mem_toFinset,computedModelingPartAt,List.mem_filter,decide_eq_true_eq,
    Finset.mem_filter,Fin.ext_iff,modelingPartIndex_number n q hq]

theorem computedModelingPart_nodup (data : List ℤ) (n q : ℕ) (h : data.Nodup) :
    (computedModelingPart data n q).Nodup := h.filter _

theorem computedModelingPart_subset (data : List ℤ) (n q : ℕ) :
    (computedModelingPart data n q).toFinset⊆data.toFinset := by
  intro a ha
  exact List.mem_toFinset.mpr (List.mem_of_mem_filter (List.mem_toFinset.mp ha))

theorem computedModelingPart_card (data : List ℤ) (n q : ℕ) (hq : 0<q) (h : data.Nodup) :
    data.length≤8*(computedModelingPart data n q).length := by
  have hsum : data.toFinset.card=∑ j : Fin 8,
      (data.toFinset.filter (fun a => modelingPartIndex hq (n:ZMod q) a=j)).card :=
    Finset.card_eq_sum_card_fiberwise (fun a _ => Finset.mem_univ (modelingPartIndex hq (n:ZMod q) a))
  rw [List.toFinset_card_of_nodup h] at hsum
  calc
    data.length=∑ j : Fin 8, (computedModelingPartAt data n q j).length := by
      rw [hsum]
      congr 1
      funext j
      rw [←computedModelingPartAt_finset data n q hq j]
      exact List.toFinset_card_of_nodup (h.filter _)
    _≤∑ _j : Fin 8, (computedModelingPart data n q).length :=
      Finset.sum_le_sum (fun j _ => computedModelingPart_max data n q j)
    _=8*(computedModelingPart data n q).length := by simp

theorem computedModelingPart_same_interval (data : List ℤ) (n q : ℕ) (hq : 0<q)
    (a b : ℤ) (ha : a∈computedModelingPart data n q) (hb : b∈computedModelingPart data n q) :
    8*(modelingResidue (n:ZMod q) a-modelingResidue (n:ZMod q) b)<q := by
  have ha' := (List.mem_filter.mp ha).2
  have hb' := (List.mem_filter.mp hb).2
  simp only [decide_eq_true_eq] at ha' hb'
  apply modelingPartIndex_difference_lt hq (n:ZMod q) a b
  apply Fin.ext
  rw [modelingPartIndex_number n q hq,modelingPartIndex_number n q hq]
  exact ha'.trans hb'.symm

theorem computedModelingPart_interval (data : List ℤ) (n q : ℕ) (hq : 0<q) :
    ∃ L U : ℤ, (∀ a∈computedModelingPart data n q,
      L≤modelingResidue (n:ZMod q) a ∧ modelingResidue (n:ZMod q) a≤U) ∧
      8*(U-L)<q := by
  classical
  let T := (computedModelingPart data n q).toFinset
  by_cases ht : T.Nonempty
  · let R := T.image (modelingResidue (n:ZMod q))
    have hr : R.Nonempty := ht.image _
    obtain ⟨a,ha,hae⟩ := Finset.mem_image.mp (R.max'_mem hr)
    obtain ⟨b,hb,hbe⟩ := Finset.mem_image.mp (R.min'_mem hr)
    refine ⟨R.min' hr,R.max' hr,?_,?_⟩
    · intro x hx
      have hxR : modelingResidue (n:ZMod q) x∈R :=
        Finset.mem_image.mpr ⟨x,List.mem_toFinset.mpr hx,rfl⟩
      exact ⟨R.min'_le _ hxR,R.le_max' _ hxR⟩
    · rw [←hae,←hbe]
      exact computedModelingPart_same_interval data n q hq a b
        (List.mem_toFinset.mp ha) (List.mem_toFinset.mp hb)
  · refine ⟨0,0,?_,by simpa using (show (0:ℤ)<q by exact_mod_cast hq)⟩
    intro a ha
    exact False.elim (ht ⟨a,List.mem_toFinset.mpr ha⟩)

end Optss
