import Optss.EncodedRationalOutputBounds
import Optss.EncodedReductionWork
import Optss.CachedContainerWork

/-!
# Complete scalar bit work of the encoded rational reduction

This combines the actual denominator product and integer clearing, every
scalar operation along the encoded loop, and all output normalizations.
All bounds are expressed in the original encoded input width. Container and
address-control operations have their separate accounting interpretation.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

/-- Complete scalar work, following the same stored intermediate matrices as
the answer. These counters are mathematical instrumentation. -/
def encodedRationalScalarWork (A : BitRationalMatrixData r d) : ℕ :=
  let D := (bitListClearRationalInput A).2
  bitListClearRationalInputCost A +
    encodedReductionFuelWork (bitMatrixReductionFuel D) D + encodedRationalUnscaleWork A

/-- The uniform loop arithmetic bit envelope after rational input clearing. -/
def rationalClearedArithmeticBits (r d L : ℕ) : ℕ :=
  let C := (r*d+1)*L+1
  3*(C+1)+5*r.size+2*d.size+
    8*(r*(r+1)+1)*(r.size+d.size+2*(C+1)+4)+12

def rationalEncodedLoopBound (r d L : ℕ) : ℕ :=
  let B := r*d*((r*d+1)*L+2)
  (bitLengthReductionFuel r d B+1)*(32*(r+1)^4*(d+1))*
    (65536*(8*(2*(r+d)+10)*(2*r+4)*rationalClearedArithmeticBits r d L+1)^3)

def rationalEncodedScalarBound (r d L : ℕ) : ℕ :=
  105*(r*d)*((r*d+1)*(L+1)+1)^2+1+rationalEncodedLoopBound r d L+
    r*d*(128*(rationalOutputUnscaleBits r d L+1)^3)

theorem encodedRationalLoopWork_bound (A : BitRationalMatrixData r d)
    (hWF : ∀ i j, ((A.get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows A i j:ℝ)))
    (L : ℕ) (hL : ∀ i j, ((A.get i).get j).numerator.length ≤ L ∧
      ((A.get i).get j).denominator.length ≤ L) :
    let D := (bitListClearRationalInput A).2
    encodedReductionFuelWork (bitMatrixReductionFuel D) D ≤ rationalEncodedLoopBound r d L := by
  let D := (bitListClearRationalInput A).2
  let C := (r*d+1)*L+1
  let B := r*d*((r*d+1)*L+2)
  have hD : LinearIndependent ℝ (fun i j => (bitIntegerMatrixValue D i j:ℝ)) := by
    dsimp only [D]
    rw [bitListClearRationalInput_semantics A hWF]
    exact clearRationalInput_independent _ hA
  have hlen := bitListClearRationalInput_lengths A L hL
  have hH : ∀ i j, |bitIntegerMatrixValue D i j| ≤ (2^C:ℕ) := by
    intro i j
    rw [← Int.natCast_natAbs, bitIntegerMatrixValue, BitListInteger.value, signedBitsValue_natAbs]
    exact Int.ofNat_le.mpr ((binaryDigitsValue_lt_pow _).le.trans
      (Nat.pow_le_pow_right (by omega) (hlen i j)))
  have hw := encodedReductionFuelWork_initial_bound (bitMatrixReductionFuel D) D
    (bitListClearRationalInput_canonical A) hD (2^C) hH
  have hs := encodedReductionFuel_swaps_le_length (bitMatrixReductionFuel D) D
  rw [bitMatrixReductionFuel, bitLengthReductionFuelList_length] at hs
  have hsize : bitIntegerMatrixSize D ≤ B := bitListClearRationalInput_size A L hL
  have hf : bitLengthReductionFuel r d (bitIntegerMatrixSize D) ≤ bitLengthReductionFuel r d B := by
    unfold bitLengthReductionFuel
    exact Nat.mul_le_mul_left _ (by omega)
  have hswap : (encodedReductionFuel (bitMatrixReductionFuel D) D).swaps+1 ≤
      bitLengthReductionFuel r d B+1 := Nat.add_le_add_right (hs.trans hf) 1
  have hbits := globalSweepArithmeticBase_input_bits (bitIntegerMatrixValue D) (2^C) hH
  simp only [Nat.size_pow] at hbits
  change (loopArithmeticBase r d (2^C) (gramPotential (bitIntegerMatrixValue D))).size ≤
    rationalClearedArithmeticBits r d L at hbits
  apply hw.trans
  unfold rationalEncodedLoopBound
  apply Nat.mul_le_mul
  · exact Nat.mul_le_mul_right _ hswap
  · exact Nat.mul_le_mul_left 65536 (Nat.pow_le_pow_left
      (Nat.add_le_add_right (Nat.mul_le_mul_left _ hbits) 1) 3)

/-- All scalar gates and list visits of the complete encoded rational
algorithm satisfy this explicit polynomial in dimension and input width. -/
theorem encodedRationalScalarWork_bound (A : BitRationalMatrixData r d)
    (hWF : ∀ i j, ((A.get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows A i j:ℝ)))
    (L : ℕ) (hL : ∀ i j, ((A.get i).get j).numerator.length ≤ L ∧
      ((A.get i).get j).denominator.length ≤ L) :
    encodedRationalScalarWork A ≤ rationalEncodedScalarBound r d L := by
  have hi := bitListClearRationalInputCost_bound A L hL (fun i j => (hWF i j).2.2.1)
  have hm := encodedRationalLoopWork_bound A hWF hA L hL
  have ho := encodedRationalUnscaleWork_bound A hWF hA L hL
  exact Nat.add_le_add (Nat.add_le_add hi hm) ho

end Optss
