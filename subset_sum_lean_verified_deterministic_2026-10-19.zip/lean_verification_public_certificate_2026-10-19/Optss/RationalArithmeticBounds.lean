import Optss.RationalGramSchmidtBounds
import Optss.CachedRationalReduction

/-!
# Sizes of the actual rational arithmetic intermediates

Reduced numerators and denominators are bounded for products, partial dot
products, and partial projection sums of the cached Gram-Schmidt computation.
All input bounds are derived from the integer matrix height and its Gram
potential. The finite-sum bounds apply to every subset, hence to every prefix
of the actual finite fold. These are representation bounds, not a running-time
model for integer multiplication, division, or gcd.
-/

namespace Optss
noncomputable section
open scoped BigOperators Classical
variable {r d : ℕ}

/-- A simultaneous bound on the two reduced integers representing a rational. -/
def RationalSizeBound (q : ℚ) (B : ℕ) : Prop := q.num.natAbs ≤ B ∧ q.den ≤ B

theorem RationalSizeBound.mono {q : ℚ} {B C : ℕ}
    (h : RationalSizeBound q B) (hBC : B ≤ C) : RationalSizeBound q C :=
  ⟨h.1.trans hBC, h.2.trans hBC⟩

theorem RationalSizeBound.pos {q : ℚ} {B : ℕ} (h : RationalSizeBound q B) : 0 < B :=
  lt_of_lt_of_le q.den_pos h.2

theorem rational_divInt_num_le (a b : ℤ) : (Rat.divInt a b).num.natAbs ≤ a.natAbs := by
  by_cases hb : b = 0
  · simp [hb]
  by_cases ha : a = 0
  · simp [ha]
  exact Nat.le_of_dvd (Int.natAbs_pos.mpr ha)
    (Int.natAbs_dvd_natAbs.mpr (Rat.num_dvd a hb))

theorem rational_divInt_den_le (a b : ℤ) : (Rat.divInt a b).den ≤ max 1 b.natAbs := by
  by_cases hb : b = 0
  · simp [hb]
  have hd := Rat.den_dvd a b
  have hd' : (Rat.divInt a b).den ∣ b.natAbs := by
    simpa only [Int.natAbs_natCast] using Int.natAbs_dvd_natAbs.mpr hd
  exact (Nat.le_of_dvd (Int.natAbs_pos.mpr hb) hd').trans (le_max_right _ _)

theorem rational_divInt_size (a b : ℤ) (B : ℕ) (hB : 0 < B)
    (ha : a.natAbs ≤ B) (hb : b.natAbs ≤ B) : RationalSizeBound (Rat.divInt a b) B := by
  exact ⟨(rational_divInt_num_le a b).trans ha,
    (rational_divInt_den_le a b).trans (max_le (by omega) hb)⟩

theorem RationalSizeBound.zero : RationalSizeBound 0 1 := by simp [RationalSizeBound]

theorem RationalSizeBound.intCast (a : ℤ) (B : ℕ) (hB : 0 < B)
    (ha : a.natAbs ≤ B) : RationalSizeBound (a:ℚ) B := by
  simpa only [RationalSizeBound, Rat.num_intCast, Rat.den_intCast] using
    (show a.natAbs ≤ B ∧ 1 ≤ B from ⟨ha, hB⟩)

theorem RationalSizeBound.neg {q : ℚ} {B : ℕ} (h : RationalSizeBound q B) :
    RationalSizeBound (-q) B := by simpa [RationalSizeBound] using h

/-- Products and division never require more than the product of operand
heights, including the field convention for division by zero. -/
theorem RationalSizeBound.mul {p q : ℚ} {B C : ℕ}
    (hp : RationalSizeBound p B) (hq : RationalSizeBound q C) :
    RationalSizeBound (p*q) (B*C) := by
  rw [Rat.mul_eq_mkRat, Rat.mkRat_eq_divInt]
  apply rational_divInt_size _ _ _ (Nat.mul_pos hp.pos hq.pos)
  · simpa only [Int.natAbs_mul] using Nat.mul_le_mul hp.1 hq.1
  · simpa only [Int.natAbs_mul, Int.natAbs_natCast] using Nat.mul_le_mul hp.2 hq.2

theorem RationalSizeBound.div {p q : ℚ} {B C : ℕ}
    (hp : RationalSizeBound p B) (hq : RationalSizeBound q C) :
    RationalSizeBound (p/q) (B*C) := by
  rw [Rat.div_def']
  apply rational_divInt_size _ _ _ (Nat.mul_pos hp.pos hq.pos)
  · simpa only [Int.natAbs_mul, Int.natAbs_natCast] using Nat.mul_le_mul hp.1 hq.2
  · simpa only [Int.natAbs_mul, Int.natAbs_natCast] using Nat.mul_le_mul hp.2 hq.1

/-- Addition's cross products and their sum are controlled before reduction. -/
theorem RationalSizeBound.add {p q : ℚ} {B C : ℕ}
    (hp : RationalSizeBound p B) (hq : RationalSizeBound q C) :
    RationalSizeBound (p+q) (2*B*C) := by
  rw [Rat.add_num_den]
  apply rational_divInt_size _ _ _ (by have := hp.pos; have := hq.pos; positivity)
  · have ht := Int.natAbs_add_le (p.num*q.den) (p.den*q.num)
    simp only [Int.natAbs_mul, Int.natAbs_natCast] at ht
    have h₁ := Nat.mul_le_mul hp.1 hq.2
    have h₂ := Nat.mul_le_mul hp.2 hq.1
    exact ht.trans ((Nat.add_le_add h₁ h₂).trans (by nlinarith : B*C+B*C ≤ 2*B*C))
  · simp only [Int.natAbs_mul, Int.natAbs_natCast]
    have ht := Nat.mul_le_mul hp.2 hq.2
    exact ht.trans (by nlinarith : B*C ≤ 2*B*C)

theorem RationalSizeBound.sub {p q : ℚ} {B C : ℕ}
    (hp : RationalSizeBound p B) (hq : RationalSizeBound q C) :
    RationalSizeBound (p-q) (2*B*C) := by
  simpa only [sub_eq_add_neg] using hp.add hq.neg

/-- Every finite partial sum has height exponential only in its number of
terms, giving a linear bound on its bit length. -/
theorem rational_sum_size {ι : Type*} (s : Finset ι) (q : ι → ℚ)
    (B : ℕ) (_hB : 0 < B) (hq : ∀ i ∈ s, RationalSizeBound (q i) B) :
    RationalSizeBound (∑ i ∈ s, q i) ((2*B)^s.card) := by
  induction s using Finset.induction_on with
  | empty => simpa using RationalSizeBound.zero
  | @insert a s ha ih =>
    rw [Finset.sum_insert ha, Finset.card_insert_of_not_mem ha, pow_succ']
    exact (hq a (Finset.mem_insert_self _ _)).add (ih (fun i hi => hq i (Finset.mem_insert_of_mem hi)))

/-- Convert a height bound directly into reduced numerator/denominator bits. -/
theorem RationalSizeBound.bits {q : ℚ} {B n : ℕ} (hn : 0 < n)
    (h : RationalSizeBound q (B^n)) :
    q.num.natAbs.size ≤ n*B.size ∧ q.den.size ≤ n*B.size :=
  ⟨nat_size_le_of_le_pow hn h.1, nat_size_le_of_le_pow hn h.2⟩

/-- A fixed polynomial base covering all input, orthogonal-vector, and
coefficient heights. The potential is the actual integer Gram potential. -/
def gsArithmeticBase (d H P : ℕ) : ℕ := d*H^2+2+P+H+2

theorem gsArithmeticBase_pos (d H P : ℕ) : 0 < gsArithmeticBase d H P := by
  unfold gsArithmeticBase; omega

private theorem le_gsArithmeticBase (d H P : ℕ) :
    P ≤ gsArithmeticBase d H P ∧ H ≤ gsArithmeticBase d H P ∧
      d*H^2+2 ≤ gsArithmeticBase d H P := by unfold gsArithmeticBase; omega

private theorem le_pow_of_one_le {B : ℕ} (hB : 1 ≤ B) {n : ℕ} (hn : 1 ≤ n) : B ≤ B^n := by
  simpa only [pow_one] using Nat.pow_le_pow_right hB hn

/-- The true Gram-Schmidt cells obey a quadratic height bound in the fixed base. -/
theorem rationalGramSchmidt_size (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (H : ℕ) (i : Fin r) (j : Fin d) :
    RationalSizeBound (rationalGramSchmidt (rationalIntegerRows A) i j)
      (gsArithmeticBase d H (gramPotential A)^2) := by
  have hP := (le_gsArithmeticBase d H (gramPotential A)).1
  constructor
  · exact (rationalGramSchmidt_num_le_potential_sq A hA i j).trans
      (Nat.pow_le_pow_left hP 2)
  · exact (rationalGramSchmidt_den_le_potential A hA i j).trans
      (hP.trans (le_pow_of_one_le (gsArithmeticBase_pos _ _ _) (by omega)))

/-- Coefficient heights use the proven determinant denominator certificate and
row-norm bound, rather than estimating division by an arbitrary tiny rational. -/
theorem rationalGsCoefficient_size (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k j : Fin r) :
    RationalSizeBound (rationalGsCoefficient (rationalIntegerRows A) k j)
      (gsArithmeticBase d H (gramPotential A)^4) := by
  obtain ⟨hP, _, hK⟩ := le_gsArithmeticBase d H (gramPotential A)
  constructor
  · calc
      _ ≤ (d*H^2+2)*gramPotential A^3 := rationalGsCoefficient_num_le_height A hA H hH k j
      _ ≤ gsArithmeticBase d H (gramPotential A)*gsArithmeticBase d H (gramPotential A)^3 :=
        Nat.mul_le_mul hK (Nat.pow_le_pow_left hP _)
      _ = _ := by ring
  · exact (rationalGsCoefficient_den_le_potential A hA k j).trans
      (hP.trans (le_pow_of_one_le (gsArithmeticBase_pos _ _ _) (by omega)))

/-- Input entries are included in the same quadratic cell bound. -/
theorem rationalIntegerRows_size (A : Matrix (Fin r) (Fin d) ℤ)
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (i : Fin r) (j : Fin d) :
    RationalSizeBound (rationalIntegerRows A i j) (gsArithmeticBase d H (gramPotential A)^2) := by
  apply RationalSizeBound.intCast _ _ (pow_pos (gsArithmeticBase_pos _ _ _) _)
  have ha : (A i j).natAbs ≤ H := by
    have hh := hH i j
    rw [← Int.natCast_natAbs] at hh
    exact_mod_cast hh
  exact ha.trans ((le_gsArithmeticBase d H (gramPotential A)).2.1.trans
    (le_pow_of_one_le (gsArithmeticBase_pos _ _ _) (by omega)))

/-- An actual partial dot product, covering every finite-fold accumulator. -/
def rationalPartialDot (s : Finset (Fin d)) (u v : Fin d → ℚ) : ℚ :=
  ∑ l ∈ s, u l*v l

/-- Every partial cross dot product used to form a projection coefficient. -/
theorem rationalPartialDot_cross_size (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k j : Fin r) (s : Finset (Fin d)) :
    RationalSizeBound (rationalPartialDot s (rationalGramSchmidt (rationalIntegerRows A) j)
      (rationalIntegerRows A k)) ((2*gsArithmeticBase d H (gramPotential A)^4)^d) := by
  apply (rational_sum_size s _ _ (pow_pos (gsArithmeticBase_pos _ _ _) _) ?_).mono
  · exact Nat.pow_le_pow_right (by have := gsArithmeticBase_pos d H (gramPotential A); positivity)
      (s.card_le_univ.trans_eq (Fintype.card_fin d))
  · intro l _
    simpa only [← pow_add] using
      (rationalGramSchmidt_size A hA H j l).mul (rationalIntegerRows_size A H hH k l)

/-- Every partial squared-norm dot product used as a projection denominator. -/
theorem rationalPartialDot_self_size (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (j : Fin r) (s : Finset (Fin d)) :
    RationalSizeBound (rationalPartialDot s (rationalGramSchmidt (rationalIntegerRows A) j)
      (rationalGramSchmidt (rationalIntegerRows A) j))
      ((2*gsArithmeticBase d H (gramPotential A)^4)^d) := by
  apply (rational_sum_size s _ _ (pow_pos (gsArithmeticBase_pos _ _ _) _) ?_).mono
  · exact Nat.pow_le_pow_right (by have := gsArithmeticBase_pos d H (gramPotential A); positivity)
      (s.card_le_univ.trans_eq (Fintype.card_fin d))
  · intro l _
    simpa only [← pow_add] using
      (rationalGramSchmidt_size A hA H j l).mul (rationalGramSchmidt_size A hA H j l)

/-- Partial projection sum in one actual Gram-Schmidt output coordinate. -/
def rationalPartialProjection (A : Matrix (Fin r) (Fin d) ℚ)
    (k : Fin r) (l : Fin d) (s : Finset (Fin r)) : ℚ :=
  ∑ i ∈ s, rationalGsCoefficient A k i * rationalGramSchmidt A i l

theorem rationalPartialProjection_size (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r) (l : Fin d) (s : Finset (Fin r)) :
    RationalSizeBound (rationalPartialProjection (rationalIntegerRows A) k l s)
      ((2*gsArithmeticBase d H (gramPotential A)^6)^r) := by
  apply (rational_sum_size s _ _ (pow_pos (gsArithmeticBase_pos _ _ _) _) ?_).mono
  · exact Nat.pow_le_pow_right (by have := gsArithmeticBase_pos d H (gramPotential A); positivity)
      (s.card_le_univ.trans_eq (Fintype.card_fin r))
  · intro i _
    simpa only [← pow_add] using
      (rationalGsCoefficient_size A hA H hH k i).mul (rationalGramSchmidt_size A hA H i l)

/-- Subtraction from the input row is covered at every partial projection sum,
including empty sums and the complete cached row computation. -/
theorem rationalPartialResidual_size (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r) (l : Fin d) (s : Finset (Fin r)) :
    RationalSizeBound (rationalIntegerRows A k l -
      rationalPartialProjection (rationalIntegerRows A) k l s)
      ((2*gsArithmeticBase d H (gramPotential A)^6)^(r+1)) := by
  have hi := (rationalIntegerRows_size A H hH k l).mono
    (Nat.pow_le_pow_right (gsArithmeticBase_pos _ _ _) (by omega : 2 ≤ 6))
  have hh := hi.sub (rationalPartialProjection_size A hA H hH k l s)
  simpa only [pow_succ'] using hh

/-- A bound usable also for empty folds, whose zero rational has denominator one. -/
theorem RationalSizeBound.bits_succ {q : ℚ} {B n : ℕ} (hB : 1 ≤ B)
    (h : RationalSizeBound q (B^n)) :
    q.num.natAbs.size ≤ (n+1)*B.size ∧ q.den.size ≤ (n+1)*B.size :=
  (h.mono (Nat.pow_le_pow_right hB (by omega))).bits (by omega)

/-- Dot-product accumulation bits grow linearly with the ambient dimension. -/
theorem rationalPartialDot_cross_bits (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k j : Fin r) (s : Finset (Fin d)) :
    let q := rationalPartialDot s (rationalGramSchmidt (rationalIntegerRows A) j)
      (rationalIntegerRows A k)
    q.num.natAbs.size ≤ (d+1)*(2*gsArithmeticBase d H (gramPotential A)^4).size ∧
      q.den.size ≤ (d+1)*(2*gsArithmeticBase d H (gramPotential A)^4).size := by
  apply (rationalPartialDot_cross_size A hA H hH k j s).bits_succ
  have hp := pow_pos (gsArithmeticBase_pos d H (gramPotential A)) 4
  omega

/-- The same bit bound covers the squared-norm denominator accumulators. -/
theorem rationalPartialDot_self_bits (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (j : Fin r) (s : Finset (Fin d)) :
    let q := rationalPartialDot s (rationalGramSchmidt (rationalIntegerRows A) j)
      (rationalGramSchmidt (rationalIntegerRows A) j)
    q.num.natAbs.size ≤ (d+1)*(2*gsArithmeticBase d H (gramPotential A)^4).size ∧
      q.den.size ≤ (d+1)*(2*gsArithmeticBase d H (gramPotential A)^4).size := by
  apply (rationalPartialDot_self_size A hA H j s).bits_succ
  have hp := pow_pos (gsArithmeticBase_pos d H (gramPotential A)) 4
  omega

/-- The partial projection sum and its subtraction from the input coordinate
both have bit lengths linear in the number of rows. -/
theorem rationalPartialResidual_bits (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r) (l : Fin d) (s : Finset (Fin r)) :
    let q := rationalIntegerRows A k l - rationalPartialProjection (rationalIntegerRows A) k l s
    q.num.natAbs.size ≤ (r+1)*(2*gsArithmeticBase d H (gramPotential A)^6).size ∧
      q.den.size ≤ (r+1)*(2*gsArithmeticBase d H (gramPotential A)^6).size :=
  (rationalPartialResidual_size A hA H hH k l s).bits (by omega)

/-- The partial dot-product bound applies to the actual cached table at every
completed prefix, not to an abstract collection of bounded operands. -/
theorem cachedPartialDot_cross_size (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ))
    (n : ℕ) (hn : n ≤ r) (k j : Fin r) (hj : j.val < n) (s : Finset (Fin d)) :
    RationalSizeBound (rationalPartialDot s
      ((cachedGSTable (rationalIntegerRows A) n hn).get j).get (rationalIntegerRows A k))
      ((2*gsArithmeticBase d H (gramPotential A)^4)^d) := by
  rw [cachedGSTable_correct _ n hn j hj]
  exact rationalPartialDot_cross_size A hA H hH k j s

theorem cachedPartialDot_self_size (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (n : ℕ) (hn : n ≤ r) (j : Fin r) (hj : j.val < n) (s : Finset (Fin d)) :
    RationalSizeBound (rationalPartialDot s
      ((cachedGSTable (rationalIntegerRows A) n hn).get j).get
      ((cachedGSTable (rationalIntegerRows A) n hn).get j).get)
      ((2*gsArithmeticBase d H (gramPotential A)^4)^d) := by
  rw [cachedGSTable_correct _ n hn j hj]
  exact rationalPartialDot_self_size A hA H j s

/-- Every partial cached projection sum is the corresponding partial sum of
the exact recurrence. The table contains precisely the required earlier rows. -/
theorem cachedPartialProjection_eq (A : Matrix (Fin r) (Fin d) ℚ)
    (k : Fin r) (l : Fin d) (s : Finset (Fin r)) (hs : ∀ i ∈ s, i < k) :
    (∑ i ∈ s, cachedGsCoefficient A (cachedGSTable A k.val (Nat.le_of_lt k.isLt)) k i *
      ((cachedGSTable A k.val (Nat.le_of_lt k.isLt)).get i).get l) =
        rationalPartialProjection A k l s := by
  apply Finset.sum_congr rfl
  intro i hi
  have he := cachedGSTable_correct A k.val (Nat.le_of_lt k.isLt) i (hs i hi)
  simp only [cachedGsCoefficient, he, rationalGsCoefficient]

/-- Actual partial accumulators of the materialized cached row, with no
assumed table-height invariant. -/
theorem cachedPartialResidual_size (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r) (l : Fin d)
    (s : Finset (Fin r)) (hs : ∀ i ∈ s, i < k) :
    RationalSizeBound (rationalIntegerRows A k l -
      ∑ i ∈ s, cachedGsCoefficient (rationalIntegerRows A)
        (cachedGSTable (rationalIntegerRows A) k.val (Nat.le_of_lt k.isLt)) k i *
          ((cachedGSTable (rationalIntegerRows A) k.val (Nat.le_of_lt k.isLt)).get i).get l)
      ((2*gsArithmeticBase d H (gramPotential A)^6)^(r+1)) := by
  rw [cachedPartialProjection_eq _ k l s hs]
  exact rationalPartialResidual_size A hA H hH k l s

/-- Bounds on unreduced integer cross products and numerator sums. These are
also bounds on the inputs to gcd normalization for the usual rational formulas. -/
theorem rational_raw_arithmetic_bounds {p q : ℚ} {B C : ℕ}
    (hp : RationalSizeBound p B) (hq : RationalSizeBound q C) :
    (p.num*q.den).natAbs ≤ B*C ∧
    (p.den*q.num).natAbs ≤ B*C ∧
    (p.num*q.num).natAbs ≤ B*C ∧
    (p.den*q.den : ℤ).natAbs ≤ B*C ∧
    (p.num*q.den+p.den*q.num).natAbs ≤ 2*B*C ∧
    (p.num*q.den-p.den*q.num).natAbs ≤ 2*B*C := by
  have h₁ : (p.num*q.den).natAbs ≤ B*C := by
    simpa only [Int.natAbs_mul, Int.natAbs_natCast] using Nat.mul_le_mul hp.1 hq.2
  have h₂ : (p.den*q.num).natAbs ≤ B*C := by
    simpa only [Int.natAbs_mul, Int.natAbs_natCast] using Nat.mul_le_mul hp.2 hq.1
  refine ⟨h₁, h₂, ?_, ?_, ?_, ?_⟩
  · simpa only [Int.natAbs_mul] using Nat.mul_le_mul hp.1 hq.1
  · simpa only [Int.natAbs_mul, Int.natAbs_natCast] using Nat.mul_le_mul hp.2 hq.2
  · exact (Int.natAbs_add_le _ _).trans ((Nat.add_le_add h₁ h₂).trans (by nlinarith))
  · exact (Int.natAbs_sub_le _ _).trans ((Nat.add_le_add h₁ h₂).trans (by nlinarith))

/-- Even the raw cross products used to divide two accumulated dot products
have bounded bit length. This includes the exact cached coefficient division. -/
theorem rationalDot_division_size (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k j : Fin r) :
    RationalSizeBound (rationalDot (rationalGramSchmidt (rationalIntegerRows A) j)
        (rationalIntegerRows A k) /
      rationalDot (rationalGramSchmidt (rationalIntegerRows A) j)
        (rationalGramSchmidt (rationalIntegerRows A) j))
      ((2*gsArithmeticBase d H (gramPotential A)^4)^(2*d)) := by
  have hx := rationalPartialDot_cross_size A hA H hH k j Finset.univ
  have hy := rationalPartialDot_self_size A hA H j Finset.univ
  simpa only [rationalPartialDot, rationalDot, ← pow_add, two_mul]
    using hx.div hy

/-- A common majorant for all arithmetic in the cached Lovász comparison. -/
def cachedLovaszHeight (d K : ℕ) : ℕ :=
  8*K^8*((2*K^4)^d)^2 + 3*(2*K^4)^d + 1

/-- All scalar intermediates of the exact rational Lovász expression have
explicit reduced numerator/denominator bounds. Earlier dot accumulators are
covered by `rationalPartialDot_self_size`. -/
theorem rationalLovasz_intermediate_sizes (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (j k : Fin r) :
    let Q := rationalIntegerRows A
    let u := rationalGsCoefficient Q k j
    let x := rationalDot (rationalGramSchmidt Q k) (rationalGramSchmidt Q k)
    let y := rationalDot (rationalGramSchmidt Q j) (rationalGramSchmidt Q j)
    let L := cachedLovaszHeight d (gsArithmeticBase d H (gramPotential A))
    RationalSizeBound (u*u) L ∧ RationalSizeBound (u*u*y) L ∧
      RationalSizeBound (x+u*u*y) L ∧ RationalSizeBound (4*(x+u*u*y)) L ∧
        RationalSizeBound (3*y) L := by
  dsimp only
  let K := gsArithmeticBase d H (gramPotential A)
  let D := (2*K^4)^d
  have hK : 1 ≤ K := gsArithmeticBase_pos _ _ _
  have hD : 1 ≤ D := one_le_pow₀ (by have hK4 : 1 ≤ K^4 := one_le_pow₀ hK; omega)
  have hu := rationalGsCoefficient_size A hA H hH k j
  have hx : RationalSizeBound (rationalDot (rationalGramSchmidt (rationalIntegerRows A) k)
      (rationalGramSchmidt (rationalIntegerRows A) k)) D := by
    simpa only [rationalPartialDot, rationalDot] using
      rationalPartialDot_self_size A hA H k Finset.univ
  have hy : RationalSizeBound (rationalDot (rationalGramSchmidt (rationalIntegerRows A) j)
      (rationalGramSchmidt (rationalIntegerRows A) j)) D := by
    simpa only [rationalPartialDot, rationalDot] using
      rationalPartialDot_self_size A hA H j Finset.univ
  have hu2 := hu.mul hu
  have hprod := hu2.mul hy
  have hsum := hx.add hprod
  have hfour : RationalSizeBound 4 4 := by norm_num [RationalSizeBound]
  have hthree : RationalSizeBound 3 3 := by norm_num [RationalSizeBound]
  have hleft := hfour.mul hsum
  have hright := hthree.mul hy
  change RationalSizeBound _ (cachedLovaszHeight d K) ∧ _
  have hK8 : 1 ≤ K^8 := one_le_pow₀ hK
  have hD2 : D ≤ D^2 := by nlinarith
  have hKD : K^8 ≤ K^8*D := Nat.le_mul_of_pos_right _ hD
  have hKD2 : K^8*D ≤ K^8*D^2 := Nat.mul_le_mul_left _ hD2
  have hL : cachedLovaszHeight d K = 8*K^8*D^2+3*D+1 := rfl
  refine ⟨hu2.mono ?_, hprod.mono ?_, hsum.mono ?_, hleft.mono ?_, hright.mono ?_⟩
  all_goals change _ ≤ cachedLovaszHeight d K
  all_goals rw [hL]
  all_goals dsimp only [K] at *
  all_goals nlinarith [pow_add (gsArithmeticBase d H (gramPotential A)) 4 4]

/-- The single Lovász majorant itself has polynomial bit length. -/
theorem cachedLovaszHeight_bits (d K : ℕ) (hK : 1 ≤ K) :
    (cachedLovaszHeight d K).size ≤ (2*d+10)*(8+K+2*K^4).size := by
  apply nat_size_le_of_le_pow (by omega : 0 < 2*d+10)
  let B := 8+K+2*K^4
  have hB : 1 ≤ B := by dsimp [B]; omega
  have hbK : K ≤ B := by dsimp [B]; omega
  have hbD : 2*K^4 ≤ B := by dsimp [B]; omega
  have hterm : 8*K^8*((2*K^4)^d)^2 ≤ B^(2*d+9) := by
    calc
      _ ≤ B*B^8*(B^d)^2 := Nat.mul_le_mul
        (Nat.mul_le_mul (by dsimp [B]; omega) (Nat.pow_le_pow_left hbK _))
        (Nat.pow_le_pow_left (Nat.pow_le_pow_left hbD _) _)
      _ = _ := by rw [← pow_mul, ← pow_succ', ← pow_add]; congr 1; omega
  have hsmall : 3*(2*K^4)^d+1 ≤ 4*B^(2*d+9) := by
    have he := Nat.pow_le_pow_right hB (by omega : d ≤ 2*d+9)
    have hd := (Nat.pow_le_pow_left hbD d).trans he
    have ho : 1 ≤ B^(2*d+9) := one_le_pow₀ hB
    omega
  have hh : cachedLovaszHeight d K ≤ 5*B^(2*d+9) := by
    unfold cachedLovaszHeight
    omega
  calc
    _ ≤ 5*B^(2*d+9) := hh
    _ ≤ B*B^(2*d+9) := Nat.mul_le_mul_right _ (by dsimp [B]; omega)
    _ = _ := by rw [← pow_succ']

/-- The bounds apply literally to the table lookups and coefficient expression
in `cachedFailingAdjacentPairs`. -/
theorem cachedLovasz_intermediate_sizes (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (j k : Fin r) :
    let Q := rationalIntegerRows A
    let T := cachedGSTable Q r le_rfl
    let u := cachedGsCoefficient Q T k j
    let x := rationalDot (T.get k).get (T.get k).get
    let y := rationalDot (T.get j).get (T.get j).get
    let L := cachedLovaszHeight d (gsArithmeticBase d H (gramPotential A))
    RationalSizeBound (u*u) L ∧ RationalSizeBound (u*u*y) L ∧
      RationalSizeBound (x+u*u*y) L ∧ RationalSizeBound (4*(x+u*u*y)) L ∧
        RationalSizeBound (3*y) L := by
  dsimp only
  simpa only [cachedGSTable_full_correct, cachedGsCoefficient_correct] using
    rationalLovasz_intermediate_sizes A hA H hH j k

/-- The additional rational arithmetic in rounding is bounded before the
integer floor division. The equality `round_eq` gives the actual rounding value. -/
theorem rational_round_preparation_size {q : ℚ} {B : ℕ} (hq : RationalSizeBound q B) :
    RationalSizeBound (q+1/2) (4*B) ∧ round q = ⌊q+1/2⌋ := by
  have hh : RationalSizeBound (1/2) 2 := by norm_num [RationalSizeBound]
  refine ⟨?_, round_eq q⟩
  convert hq.add hh using 1; ring

/-- Magnitude bounds for the integer cross products used in the final rational
comparison, once both sides have been constructed. -/
theorem rational_comparison_cross_bits {p q : ℚ} {B : ℕ}
    (hp : RationalSizeBound p B) (hq : RationalSizeBound q B) :
    (p.num*q.den).natAbs.size ≤ 2*B.size ∧
      (q.num*p.den).natAbs.size ≤ 2*B.size := by
  have h₁ := (rational_raw_arithmetic_bounds hp hq).1
  have h₂ := (rational_raw_arithmetic_bounds hq hp).1
  exact ⟨nat_size_le_of_le_pow (by omega) (by simpa only [pow_two] using h₁),
    nat_size_le_of_le_pow (by omega) (by simpa only [pow_two] using h₂)⟩

/-- A height for every integer entry encountered during one complete size sweep. -/
def sweepArithmeticHeight (r d H P : ℕ) : ℕ :=
  (H+r*P+d*H^2+2)*partialReductionGrowth r P^r

/-- Every cached projection accumulator at every actual intermediate integer
matrix inherits an explicit bound from the original input height and potential. -/
theorem outerSweep_innerTrace_cachedResidual_bits
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r)
    (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace (rationalReduceIntegerAll A k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl) (i : Fin r) (l : Fin d)
    (s : Finset (Fin r)) (hs : ∀ j ∈ s, j < i) :
    let Q := rationalIntegerRows B
    let T := cachedGSTable Q i.val (Nat.le_of_lt i.isLt)
    let q := Q i l - ∑ j ∈ s, cachedGsCoefficient Q T i j * (T.get j).get l
    let E := sweepArithmeticHeight r d H (gramPotential A)
    q.num.natAbs.size ≤ (r+1)*(2*gsArithmeticBase d E (gramPotential A)^6).size ∧
      q.den.size ≤ (r+1)*(2*gsArithmeticBase d E (gramPotential A)^6).size := by
  obtain ⟨hind, hp⟩ := outerSweep_innerTrace_independent_potential A hA k B hB
  let E := sweepArithmeticHeight r d H (gramPotential A)
  have hE : ∀ i j, |B i j| ≤ (E:ℤ) := by
    intro i j
    have hh := outerSweep_innerTrace_all_entries A hA H hH k B hB i j
    change (B i j).natAbs ≤ E at hh
    simpa only [Int.natCast_natAbs] using (Int.ofNat_le.mpr hh)
  have hb := (cachedPartialResidual_size B hind E hE i l s hs).bits (by omega)
  simpa only [hp] using hb

/-- The same specialization covers all partial dot products constructed while
rebuilding any row of the cached Gram-Schmidt table at an actual sweep state. -/
theorem outerSweep_innerTrace_cachedDot_bits
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r)
    (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace (rationalReduceIntegerAll A k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl) (n : ℕ) (hn : n ≤ r) (i j : Fin r) (hj : j.val < n)
    (s : Finset (Fin d)) :
    let Q := rationalIntegerRows B
    let T := cachedGSTable Q n hn
    let q := rationalPartialDot s (T.get j).get (Q i)
    let E := sweepArithmeticHeight r d H (gramPotential A)
    q.num.natAbs.size ≤ (d+1)*(2*gsArithmeticBase d E (gramPotential A)^4).size ∧
      q.den.size ≤ (d+1)*(2*gsArithmeticBase d E (gramPotential A)^4).size := by
  obtain ⟨hind, hp⟩ := outerSweep_innerTrace_independent_potential A hA k B hB
  let E := sweepArithmeticHeight r d H (gramPotential A)
  have hE : ∀ i j, |B i j| ≤ (E:ℤ) := by
    intro i j
    have hh := outerSweep_innerTrace_all_entries A hA H hH k B hB i j
    change (B i j).natAbs ≤ E at hh
    simpa only [Int.natCast_natAbs] using (Int.ofNat_le.mpr hh)
  dsimp only
  rw [cachedGSTable_correct _ n hn j hj]
  simpa only [hp] using rationalPartialDot_cross_bits B hind E hE i j s

/-- Fixed polynomial base for all arithmetic sizes throughout one sweep.
Unlike the intermediate entry height, this base has no rank-dependent exponent. -/
def sweepArithmeticBase (r d H P : ℕ) : ℕ :=
  8+H+r*P+d*H^2+partialReductionGrowth r P+d+P

/-- The polynomial base at an intermediate matrix is bounded by a power whose
exponent is linear in rank. Thus taking its bit length is polynomial in rank. -/
theorem sweepGSArithmeticBase_le_pow (r d H P : ℕ) :
    gsArithmeticBase d (sweepArithmeticHeight r d H P) P ≤
      sweepArithmeticBase r d H P^(2*r+4) := by
  let U := sweepArithmeticBase r d H P
  let E := sweepArithmeticHeight r d H P
  have hU : 8 ≤ U := by unfold U sweepArithmeticBase; omega
  have hU1 : 1 ≤ U := by omega
  have hE : E ≤ U^(r+1) := by
    change (H+r*P+d*H^2+2)*partialReductionGrowth r P^r ≤ _
    calc
      _ ≤ U*U^r := Nat.mul_le_mul (by unfold U sweepArithmeticBase; omega)
        (Nat.pow_le_pow_left (by unfold U sweepArithmeticBase; omega) _)
      _ = _ := (pow_succ' _ _).symm
  have hd : d ≤ U := by unfold U sweepArithmeticBase; omega
  have hP : P ≤ U := by unfold U sweepArithmeticBase; omega
  have hN : U ≤ U^(2*r+3) := le_pow_of_one_le hU1 (by omega)
  have hE' : E ≤ U^(2*r+3) := hE.trans
    (Nat.pow_le_pow_right hU1 (by omega))
  have hP' : P ≤ U^(2*r+3) := hP.trans hN
  have h4 : 4 ≤ U^(2*r+3) := (by omega : 4 ≤ U).trans hN
  have hprod : d*E^2 ≤ U^(2*r+3) := by
    calc
      _ ≤ U*(U^(r+1))^2 := Nat.mul_le_mul hd (Nat.pow_le_pow_left hE _)
      _ = _ := by rw [← pow_mul, ← pow_succ']; congr 1; omega
  have hsum : gsArithmeticBase d E P ≤ 4*U^(2*r+3) := by
    unfold gsArithmeticBase
    omega
  calc
    _ ≤ 4*U^(2*r+3) := hsum
    _ ≤ U*U^(2*r+3) := Nat.mul_le_mul_right _ (by omega)
    _ = _ := by rw [← pow_succ']

/-- Explicit bit bound for each fixed-degree arithmetic majorant at any
sweep state, measured against a fixed polynomial in original input parameters. -/
theorem sweepGSArithmeticBase_bits (r d H P e : ℕ) :
    (2*gsArithmeticBase d (sweepArithmeticHeight r d H P) P^e).size ≤
      ((2*r+4)*e+1)*(sweepArithmeticBase r d H P).size := by
  apply nat_size_le_of_le_pow (by omega : 0 < (2*r+4)*e+1)
  have hU : 2 ≤ sweepArithmeticBase r d H P := by unfold sweepArithmeticBase; omega
  calc
    _ ≤ sweepArithmeticBase r d H P*(sweepArithmeticBase r d H P^(2*r+4))^e :=
      Nat.mul_le_mul hU (Nat.pow_le_pow_left (sweepGSArithmeticBase_le_pow r d H P) _)
    _ = _ := by rw [← pow_mul, ← pow_succ']

/-- Fully explicit polynomial bit bound for cached partial residuals throughout
one actual sweep, with no intermediate-height hypothesis. -/
theorem outerSweep_innerTrace_cachedResidual_polynomial_bits
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r)
    (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace (rationalReduceIntegerAll A k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl) (i : Fin r) (l : Fin d)
    (s : Finset (Fin r)) (hs : ∀ j ∈ s, j < i) :
    let Q := rationalIntegerRows B
    let T := cachedGSTable Q i.val (Nat.le_of_lt i.isLt)
    let q := Q i l - ∑ j ∈ s, cachedGsCoefficient Q T i j * (T.get j).get l
    let b := (r+1)*(12*r+25)*(sweepArithmeticBase r d H (gramPotential A)).size
    q.num.natAbs.size ≤ b ∧ q.den.size ≤ b := by
  have hb := outerSweep_innerTrace_cachedResidual_bits A hA H hH k B hB i l s hs
  have hbase := sweepGSArithmeticBase_bits r d H (gramPotential A) 6
  have he : (2*r+4)*6+1 = 12*r+25 := by omega
  rw [he] at hbase
  have hm := Nat.mul_le_mul_left (r+1) hbase
  rw [← Nat.mul_assoc] at hm
  exact ⟨hb.1.trans hm, hb.2.trans hm⟩

/-- Fully explicit polynomial bit bound for cached partial dot products
throughout one actual sweep. -/
theorem outerSweep_innerTrace_cachedDot_polynomial_bits
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r)
    (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace (rationalReduceIntegerAll A k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl) (n : ℕ) (hn : n ≤ r) (i j : Fin r) (hj : j.val < n)
    (s : Finset (Fin d)) :
    let Q := rationalIntegerRows B
    let T := cachedGSTable Q n hn
    let q := rationalPartialDot s (T.get j).get (Q i)
    let b := (d+1)*(8*r+17)*(sweepArithmeticBase r d H (gramPotential A)).size
    q.num.natAbs.size ≤ b ∧ q.den.size ≤ b := by
  have hb := outerSweep_innerTrace_cachedDot_bits A hA H hH k B hB n hn i j hj s
  have hbase := sweepGSArithmeticBase_bits r d H (gramPotential A) 4
  have he : (2*r+4)*4+1 = 8*r+17 := by omega
  rw [he] at hbase
  have hm := Nat.mul_le_mul_left (d+1) hbase
  rw [← Nat.mul_assoc] at hm
  exact ⟨hb.1.trans hm, hb.2.trans hm⟩

/-- Actual individual products supplied to the dot-product accumulators. -/
theorem rationalDotTerm_sizes (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k j : Fin r) (l : Fin d) :
    let g := rationalGramSchmidt (rationalIntegerRows A) j l
    let K := gsArithmeticBase d H (gramPotential A)
    RationalSizeBound (g*rationalIntegerRows A k l) (K^4) ∧
      RationalSizeBound (g*g) (K^4) := by
  constructor
  · simpa only [← pow_add] using
      (rationalGramSchmidt_size A hA H j l).mul (rationalIntegerRows_size A H hH k l)
  · simpa only [← pow_add] using
      (rationalGramSchmidt_size A hA H j l).mul (rationalGramSchmidt_size A hA H j l)

theorem rationalProjectionTerm_size (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k i : Fin r) (l : Fin d) :
    RationalSizeBound (rationalGsCoefficient (rationalIntegerRows A) k i *
      rationalGramSchmidt (rationalIntegerRows A) i l) (gsArithmeticBase d H (gramPotential A)^6) := by
  simpa only [← pow_add] using
    (rationalGsCoefficient_size A hA H hH k i).mul (rationalGramSchmidt_size A hA H i l)

/-- Every cell of the coefficient array materialized by `cachedGSRow`,
including zero cells for rows that have not been processed. -/
theorem cachedGSRow_coefficient_size (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k i : Fin r) :
    RationalSizeBound (if i < k then cachedGsCoefficient (rationalIntegerRows A)
      (cachedGSTable (rationalIntegerRows A) k.val (Nat.le_of_lt k.isLt)) k i else 0)
      (gsArithmeticBase d H (gramPotential A)^4) := by
  split_ifs with hi
  · have he := cachedGSTable_correct (rationalIntegerRows A) k.val
      (Nat.le_of_lt k.isLt) i hi
    simp only [cachedGsCoefficient, he]
    exact rationalGsCoefficient_size A hA H hH k i
  · exact RationalSizeBound.zero.mono (one_le_pow₀ (gsArithmeticBase_pos _ _ _))

/-- The denominator dot-product accumulators have the same explicit polynomial
bit bound at every actual matrix reached during a cached size sweep. -/
theorem outerSweep_innerTrace_cachedSelfDot_polynomial_bits
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (_hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r)
    (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace (rationalReduceIntegerAll A k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl) (n : ℕ) (hn : n ≤ r) (j : Fin r) (hj : j.val < n)
    (s : Finset (Fin d)) :
    let T := cachedGSTable (rationalIntegerRows B) n hn
    let q := rationalPartialDot s (T.get j).get (T.get j).get
    let b := (d+1)*(8*r+17)*(sweepArithmeticBase r d H (gramPotential A)).size
    q.num.natAbs.size ≤ b ∧ q.den.size ≤ b := by
  obtain ⟨hind, hp⟩ := outerSweep_innerTrace_independent_potential A hA k B hB
  let E := sweepArithmeticHeight r d H (gramPotential A)
  have hb := rationalPartialDot_self_bits B hind E j s
  rw [hp] at hb
  have hbase := sweepGSArithmeticBase_bits r d H (gramPotential A) 4
  have he : (2*r+4)*4+1 = 8*r+17 := by omega
  rw [he] at hbase
  have hm := Nat.mul_le_mul_left (d+1) hbase
  rw [← Nat.mul_assoc] at hm
  dsimp only
  rw [cachedGSTable_correct _ n hn j hj]
  exact ⟨hb.1.trans hm, hb.2.trans hm⟩

end
end Optss
