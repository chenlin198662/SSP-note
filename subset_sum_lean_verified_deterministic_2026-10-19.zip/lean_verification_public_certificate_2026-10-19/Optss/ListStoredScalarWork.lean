import Optss.ListStoredReductionLoop
import Optss.EncodedReductionWork

/-!
# Scalar work of the actual list-stored execution

These recurrences follow the scalar calls of the list answer functions,
including their actual reads, cached intermediate values and branch decisions.
Copy and storage costs are separate. The proofs identify the entire scalar
work trace with the encoded reference, not merely the final matrix values.
-/
namespace Optss
open scoped BigOperators
variable {r d : ℕ}

def listStoredGsCoefficientScalarWork (A T : ListBitRationalMatrixData r d) (k j : Fin r) : ℕ :=
  let u := listMatrixRead listCopyFraction T j
  let v := listMatrixRead listCopyFraction A k
  let num := encodedRationalDot u v
  let den := encodedRationalDot u u
  encodedRationalDotWork u v+encodedRationalDotWork u u+bitListFractionDivCost num den

theorem listStoredGsCoefficientScalarWork_eq (A T : ListBitRationalMatrixData r d) (k j : Fin r) :
    listStoredGsCoefficientScalarWork A T k j = encodedGsCoefficientWork (listMatrixVector A) (listMatrixVector T) k j := by
  simp only [listStoredGsCoefficientScalarWork,encodedGsCoefficientWork,listMatrixRead_fun _ listCopyFraction_eq]

def listStoredGSRowScalarWork (A T : ListBitRationalMatrixData r d) (k : Fin r) : ℕ :=
  let coeff := listStoredGSCoefficients A T k
  (∑ i : Fin r, if bitIndexLT i k then listStoredGsCoefficientScalarWork A T k i else 0)+
    ∑ l : Fin d,
      let u := fun i : Finset.Iio k => coeff.read listCopyFraction i
      let v := fun i : Finset.Iio k => listMatrixRead listCopyFraction T i l
      let is := List.ofFn (lowerFinEquiv k)
      encodedProductSumWork u v is+bitListFractionSubCost (listMatrixRead listCopyFraction A k l)
        (encodedProductSum u v is)

theorem listStoredGSRowScalarWork_eq (A T : ListBitRationalMatrixData r d) (k : Fin r) :
    listStoredGSRowScalarWork A T k = encodedGSRowWork (listMatrixVector A) (listMatrixVector T) k := by
  simp only [listStoredGSRowScalarWork,encodedGSRowWork,bitIndexLT_correct,Fin.lt_def,
    listStoredGsCoefficientScalarWork_eq,BooleanListArray.read_toVector _ listCopyFraction_eq,
    listStoredGSCoefficients_eq,listMatrixRead_eq _ listCopyFraction_eq]

def listStoredGSTableScalarWork (A : ListBitRationalMatrixData r d) (n : ℕ) (hn : n≤r) : ℕ :=
  match n with
  | 0 => 0
  | n+1 =>
    let T := listStoredGSTable A n (by omega)
    listStoredGSTableScalarWork A n (by omega)+listStoredGSRowScalarWork A T ⟨n,by omega⟩
termination_by n

theorem listStoredGSTableScalarWork_eq (A : ListBitRationalMatrixData r d) (n : ℕ) (hn : n≤r) :
    listStoredGSTableScalarWork A n hn = encodedGSTableWork (listMatrixVector A) n hn := by
  induction n with
  | zero => simp only [listStoredGSTableScalarWork,encodedGSTableWork]
  | succ n ih =>
    rw [listStoredGSTableScalarWork,encodedGSTableWork,listStoredGSRowScalarWork_eq,listStoredGSTable_eq,ih]

def listStoredIntegerRowUpdateScalarWork (D : ListBitIntegerMatrixData r d) (k j : Fin r)
    (q : BitListInteger) : ℕ :=
  ∑ l : Fin d, bitListIntegerRowCellCost (listMatrixRead listCopyInteger D k l)
    (listCopyInteger q) (listMatrixRead listCopyInteger D j l)

theorem listStoredIntegerRowUpdateScalarWork_eq (D : ListBitIntegerMatrixData r d) (k j : Fin r)
    (q : BitListInteger) : listStoredIntegerRowUpdateScalarWork D k j q =
      encodedIntegerRowUpdateWork (listMatrixVector D) k j q := by
  simp only [listStoredIntegerRowUpdateScalarWork,encodedIntegerRowUpdateWork,
    listMatrixRead_eq _ listCopyInteger_eq,listCopyInteger_eq]

def listStoredReduceIntegerRowScalarWork (D : ListBitIntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (hn : n≤k.val) : ℕ :=
  match n with
  | 0 => 0
  | n+1 =>
    let j : Fin r := ⟨n,by omega⟩
    let Q := listStoredRationalIntegerRows D
    let T := listStoredGSTable Q r le_rfl
    let c := listStoredGsCoefficient Q T k j
    let q := encodedRoundInteger c
    let W := listStoredIntegerRowUpdate D k j q
    listStoredGSTableScalarWork Q r le_rfl+listStoredGsCoefficientScalarWork Q T k j+
      bitListFractionRoundCost c+listStoredIntegerRowUpdateScalarWork D k j q+
      listStoredReduceIntegerRowScalarWork W k n (by omega)
termination_by n

theorem listStoredReduceIntegerRowScalarWork_eq (D : ListBitIntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (hn : n≤k.val) :
    listStoredReduceIntegerRowScalarWork D k n hn = encodedReduceIntegerRowWork (listMatrixVector D) k n hn := by
  induction n generalizing D with
  | zero => simp only [listStoredReduceIntegerRowScalarWork,encodedReduceIntegerRowWork]
  | succ n ih =>
    rw [listStoredReduceIntegerRowScalarWork,encodedReduceIntegerRowWork,ih]
    simp only [listStoredGSTableScalarWork_eq,listStoredGsCoefficientScalarWork_eq,
      listStoredGsCoefficient_eq,listStoredIntegerRowUpdateScalarWork_eq,listStoredIntegerRowUpdate_eq,
      listStoredGSTable_eq,listStoredRationalIntegerRows_eq]

def listStoredReduceIntegerAllScalarWork (D : ListBitIntegerMatrixData r d) (n : ℕ) (hn : n≤r) : ℕ :=
  match n with
  | 0 => 0
  | n+1 =>
    let C := listStoredReduceIntegerAll D n (by omega)
    listStoredReduceIntegerAllScalarWork D n (by omega)+listStoredReduceIntegerRowScalarWork C ⟨n,by omega⟩ n le_rfl
termination_by n

theorem listStoredReduceIntegerAllScalarWork_eq (D : ListBitIntegerMatrixData r d) (n : ℕ) (hn : n≤r) :
    listStoredReduceIntegerAllScalarWork D n hn = encodedReduceIntegerAllWork (listMatrixVector D) n hn := by
  induction n with
  | zero => simp only [listStoredGSTableScalarWork,encodedGSTableWork,
      listStoredReduceIntegerRowScalarWork,encodedReduceIntegerRowWork,
      listStoredReduceIntegerAllScalarWork,encodedReduceIntegerAllWork]
  | succ n ih =>
    rw [listStoredReduceIntegerAllScalarWork,encodedReduceIntegerAllWork,ih,
      listStoredReduceIntegerRowScalarWork_eq,listStoredReduceIntegerAll_eq]

def listStoredLovaszPairScalarWork (A T : ListBitRationalMatrixData r d) (j k : Fin r) : ℕ :=
  let u := listMatrixRead listCopyFraction T k
  let v := listMatrixRead listCopyFraction T j
  let nk := encodedRationalDot u u
  let nj := encodedRationalDot v v
  let mu := listStoredGsCoefficient A T k j
  let square := bitListFractionMul (listCopyFraction mu) mu
  let product := bitListFractionMul square (listCopyFraction nj)
  let total := bitListFractionAdd nk product
  let left := bitListFractionMul encodedFractionFour total
  let right := bitListFractionMul encodedFractionThree nj
  encodedRationalDotWork u u+encodedRationalDotWork v v+listStoredGsCoefficientScalarWork A T k j+
    bitListFractionMulCost (listCopyFraction mu) mu+bitListFractionMulCost square (listCopyFraction nj)+
    bitListFractionAddCost nk product+bitListFractionMulCost encodedFractionFour total+
    bitListFractionMulCost encodedFractionThree nj+bitListFractionLTCost left right

theorem listStoredLovaszPairScalarWork_eq (A T : ListBitRationalMatrixData r d) (j k : Fin r) :
    listStoredLovaszPairScalarWork A T j k = encodedLovaszPairWork (listMatrixVector A) (listMatrixVector T) j k := by
  simp only [listStoredLovaszPairScalarWork,encodedLovaszPairWork,listMatrixRead_fun _ listCopyFraction_eq,
    listStoredGsCoefficient_eq,listStoredGsCoefficientScalarWork_eq,listCopyFraction_eq]

/-- Counts the actual nested finite-list enumeration, including the false
adjacency branches, which make no scalar call. -/
def listStoredFailingPairsScalarWork (D : ListBitIntegerMatrixData r d) : ℕ :=
  let Q := listStoredRationalIntegerRows D
  let T := listStoredGSTable Q r le_rfl
  listStoredGSTableScalarWork Q r le_rfl+
    ((List.ofFn (id : Fin r → Fin r)).map fun j =>
      ((List.ofFn fun k : Fin r => (j,k)).map fun p =>
        if bitIndexAdjacent p.1 p.2 then listStoredLovaszPairScalarWork Q T p.1 p.2 else 0).sum).sum

theorem listStoredFailingPairsScalarWork_eq (D : ListBitIntegerMatrixData r d) :
    listStoredFailingPairsScalarWork D = encodedFailingAdjacentPairsWork (listMatrixVector D) := by
  simp only [listStoredFailingPairsScalarWork,encodedFailingAdjacentPairsWork,List.map_ofFn,List.sum_ofFn,
    Function.comp_apply,Function.id_def,bitIndexAdjacent_correct,listStoredLovaszPairScalarWork_eq,
    listStoredGSTableScalarWork_eq,listStoredGSTable_eq,listStoredRationalIntegerRows_eq]

def listStoredReductionFuelScalarWork : List Bool → ListBitIntegerMatrixData r d → ℕ
  | [],_ => 0
  | _::fuel,D =>
    let C := listStoredReduceIntegerAll D r le_rfl
    let pairs := listStoredFailingPairs C
    let here := listStoredReduceIntegerAllScalarWork D r le_rfl+listStoredFailingPairsScalarWork C
    match bitLeastPair pairs with
    | none => here
    | some p => here+listStoredReductionFuelScalarWork fuel (listStoredBooleanSwapRows C p.1 p.2)

theorem listStoredReductionFuelScalarWork_eq (fuel : List Bool) (D : ListBitIntegerMatrixData r d) :
    listStoredReductionFuelScalarWork fuel D = encodedReductionFuelWork fuel (listMatrixVector D) := by
  induction fuel generalizing D with
  | nil => rfl
  | cons b fuel ih =>
    rw [listStoredReductionFuelScalarWork,encodedReductionFuelWork]
    simp only [← listStoredReduceIntegerAll_eq,← listStoredFailingPairs_eq,
      listStoredReduceIntegerAllScalarWork_eq,listStoredFailingPairsScalarWork_eq]
    split_ifs with h
    · rw [bitLeastPair_eq_least _ h]
      simp only [ih,listStoredBooleanSwapRows_eq]
    · have he : bitLeastPair (listStoredFailingPairs (listStoredReduceIntegerAll D r le_rfl))=none := by
        apply (bitLeastPair_none _).mpr
        apply List.eq_nil_iff_forall_not_mem.mpr
        intro p hp
        exact h ⟨p,List.mem_toFinset.mpr hp⟩
      rw [he]

end Optss
