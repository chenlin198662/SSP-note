import Optss.BooleanListArray

/-! Boolean comparisons for bounded structural indices. -/
namespace Optss

def bitIndexLE {n m : ℕ} (i : Fin n) (j : Fin m) : Bool :=
  bitListLE (bitUnaryAddress i.val) (bitUnaryAddress j.val)
def bitIndexEQ {n m : ℕ} (i : Fin n) (j : Fin m) : Bool := bitIndexLE i j && bitIndexLE j i
def bitIndexLT {n m : ℕ} (i : Fin n) (j : Fin m) : Bool := !(bitIndexLE j i)
def bitIndexAdjacent {n m : ℕ} (i : Fin n) (j : Fin m) : Bool :=
  let next := bitListAdd (bitUnaryAddress i.val) [true]
  bitListLE next (bitUnaryAddress j.val) && bitListLE (bitUnaryAddress j.val) next

@[simp] theorem bitIndexLE_correct {n m : ℕ} (i : Fin n) (j : Fin m) :
    bitIndexLE i j = true ↔ i.val ≤ j.val := by
  simp only [bitIndexLE,bitListLE_correct,bitUnaryAddress_value]
@[simp] theorem bitIndexEQ_correct {n m : ℕ} (i : Fin n) (j : Fin m) :
    bitIndexEQ i j = true ↔ i.val = j.val := by
  simp only [bitIndexEQ,Bool.and_eq_true,bitIndexLE_correct]
  omega
@[simp] theorem bitIndexLT_correct {n m : ℕ} (i : Fin n) (j : Fin m) :
    bitIndexLT i j = true ↔ i.val < j.val := by
  change (!bitIndexLE j i) = true ↔ i.val < j.val
  rw [Bool.not_eq_true',Bool.eq_false_iff]
  exact (not_congr (bitIndexLE_correct j i)).trans Nat.not_le
@[simp] theorem bitIndexAdjacent_correct {n m : ℕ} (i : Fin n) (j : Fin m) :
    bitIndexAdjacent i j = true ↔ j.val = i.val+1 := by
  simp only [bitIndexAdjacent,Bool.and_eq_true,bitListLE_correct,bitListAdd_correct,
    bitUnaryAddress_value,show binaryDigitsValue [true] = 1 from rfl]
  omega


end Optss
