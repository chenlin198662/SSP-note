import Optss.ListStoredRationalReduction
import Optss.ListStoredLoopWorkBounds
import Optss.ListStoredScalarWork

/-!
# Polynomial work of list-stored rational reduction

These charges count actual traversals, payload copies, and Boolean arithmetic
in the final list-stored answer routine. The actual scalar-call trace and
the concrete storage/control recurrences are combined with the boundary
operations into one polynomial in the stored input size.
-/

namespace Optss
variable {r d : ℕ}

theorem listStoredClearedRows_independent (A : ListBitRationalMatrixData r d)
    (hWF : ∀ i j, (((ioMatrixVector A).get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows (ioMatrixVector A) i j : ℝ))) :
    LinearIndependent ℝ (fun i j =>
      (bitIntegerMatrixValue (ioMatrixVector (listStoredClearRationalInput A).2) i j : ℝ)) := by
  have hc := congrArg Prod.snd (listStoredClearRationalInput_eq A)
  dsimp only at hc
  rw [hc,bitListClearRationalInput_semantics _ hWF]
  exact clearRationalInput_independent _ hA

theorem listStoredReducedRows_eq (A : ListBitRationalMatrixData r d)
    (hWF : ∀ i j, (((ioMatrixVector A).get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows (ioMatrixVector A) i j : ℝ))) :
    ioMatrixVector (listStoredReductionFuel
      (listStoredStructuralFuel (listStoredClearRationalInput A).2)
      (listStoredClearRationalInput A).2).rows =
      (encodedIntegerReduction (bitListClearRationalInput (ioMatrixVector A)).2).rows := by
  have hi := listStoredClearedRows_independent A hWF hA
  have hc := congrArg Prod.snd (listStoredClearRationalInput_eq A)
  dsimp only at hc
  have hl := congrArg Prod.fst (listStoredReductionFuel_eq
    (listStoredStructuralFuel (listStoredClearRationalInput A).2)
    (listStoredClearRationalInput A).2)
  simp only [listMatrixVector_eq_ioMatrixVector] at hl
  rw [hl,listStoredStructuralFuel_eq]
  change (structuralEncodedIntegerReduction
    (ioMatrixVector (listStoredClearRationalInput A).2)).rows = _
  rw [structuralEncodedIntegerReduction_eq _ hi,hc]

def listStoredRationalBoundaryWork (A : ListBitRationalMatrixData r d) : ℕ :=
  let cleared := listStoredClearRationalInput A
  let fuel := listStoredStructuralFuel cleared.2
  let out := listStoredReductionFuel fuel cleared.2
  listStoredClearRationalInputWork A+listStoredStructuralFuelWork cleared.2+
    listStoredUnscaleWork cleared.1 out.rows+4

noncomputable def listStoredFuelPolynomial : Polynomial ℕ :=
  let X := Polynomial.X
  64*(X+X*X*((X*X+1)*X+2)+3)^3

theorem listStoredRationalFuelWork_input_size (A : ListBitRationalMatrixData r r) :
    listStoredStructuralFuelWork (listStoredClearRationalInput A).2 ≤
      listStoredFuelPolynomial.eval (listStoredRationalBits A) := by
  have hf := listStoredStructuralFuelWork_bound (listStoredClearRationalInput A).2
  have hc := congrArg Prod.snd (listStoredClearRationalInput_eq A)
  dsimp only at hc
  rw [hc] at hf
  have hb := bitListClearRationalInput_size (ioMatrixVector A) (listStoredRationalBits A)
    (listStoredRationalBits_cell A)
  have hr := listStoredRationalBits_rank A
  apply hf.trans
  simp only [listStoredFuelPolynomial,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_pow,Polynomial.eval_X,Polynomial.eval_ofNat,Polynomial.eval_one]
  gcongr
  exact hb.trans (by gcongr)

noncomputable def listStoredBoundaryPolynomial : Polynomial ℕ :=
  listStoredInputPolynomial+listStoredFuelPolynomial+listStoredOutputPolynomial+4

theorem listStoredRationalBoundaryWork_input_size (A : ListBitRationalMatrixData r r)
    (hWF : ∀ i j, (((ioMatrixVector A).get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows (ioMatrixVector A) i j : ℝ))) :
    listStoredRationalBoundaryWork A ≤
      listStoredBoundaryPolynomial.eval (listStoredRationalBits A) := by
  have hi := listStoredClearRationalInputWork_input_size A hWF
  have hf := listStoredRationalFuelWork_input_size A
  have ho := listStoredUnscaleWork_of_reduction A hWF hA _
    (listStoredReducedRows_eq A hWF hA)
  unfold listStoredRationalBoundaryWork
  dsimp only
  change _+_+listStoredUnscaleWork (listStoredInputDenominator A) _+4 ≤ _
  simp only [listStoredBoundaryPolynomial,Polynomial.eval_add,Polynomial.eval_ofNat]
  omega

/-- Input-size bound on the encoded scalar trace used by the list-loop cost
adapter. The storage simulation separately links its charge to this trace. -/
theorem listStoredRationalLoopScalarWork_input_size (A : ListBitRationalMatrixData r r)
    (hWF : ∀ i j, (((ioMatrixVector A).get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows (ioMatrixVector A) i j : ℝ))) :
    encodedReductionFuelWork (listStoredStructuralFuel (listStoredClearRationalInput A).2)
      (ioMatrixVector (listStoredClearRationalInput A).2) ≤
      rationalScalarPolynomial.eval (listStoredRationalBits A) := by
  have hi := listStoredClearedRows_independent A hWF hA
  have hc := congrArg Prod.snd (listStoredClearRationalInput_eq A)
  dsimp only at hc
  rw [listStoredStructuralFuel_eq,structuralEncodedIntegerReductionWork_eq _ hi,hc]
  have hs := encodedRationalScalarWork_bound (ioMatrixVector A) hWF hA
    (listStoredRationalBits A) (listStoredRationalBits_cell A)
  have hloop : encodedIntegerReductionWork (bitListClearRationalInput (ioMatrixVector A)).2 ≤
      encodedRationalScalarWork (ioMatrixVector A) := by
    unfold encodedRationalScalarWork encodedIntegerReductionWork
    dsimp only
    omega
  exact hloop.trans (hs.trans (rationalEncodedScalarBound_le_polynomial r r
    (listStoredRationalBits A) (listStoredRationalBits A)
    (listStoredRationalBits_rank A) (listStoredRationalBits_rank A) le_rfl))

noncomputable def listStoredClearedSizePolynomial : Polynomial ℕ :=
  let X := Polynomial.X
  X*X*((X*X+1)*X+2)

theorem listStoredClearedSize_input_size (A : ListBitRationalMatrixData r r) :
    bitIntegerMatrixSize (ioMatrixVector (listStoredClearRationalInput A).2) ≤
      listStoredClearedSizePolynomial.eval (listStoredRationalBits A) := by
  have hc := congrArg Prod.snd (listStoredClearRationalInput_eq A)
  dsimp only at hc
  rw [hc]
  apply (bitListClearRationalInput_size _ (listStoredRationalBits A)
    (listStoredRationalBits_cell A)).trans
  have hr := listStoredRationalBits_rank A
  simp only [listStoredClearedSizePolynomial,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat]
  gcongr

theorem listStoredRationalFuelLength_input_size (A : ListBitRationalMatrixData r r) :
    (listStoredStructuralFuel (listStoredClearRationalInput A).2).length ≤
      listStoredFuelPolynomial.eval (listStoredRationalBits A) := by
  rw [listStoredStructuralFuel_length]
  have hc := listStoredClearedSize_input_size A
  have hr := listStoredRationalBits_rank A
  simp only [listStoredClearedSizePolynomial,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat] at hc
  simp only [listStoredFuelPolynomial,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_pow,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat]
  gcongr
  norm_num

/-- All accounted work: physical list input/output and fuel construction,
the scalar trace, and the concrete list-loop storage/control recurrences. -/
def listStoredRationalTotalWork (A : ListBitRationalMatrixData r d) : ℕ :=
  let D := (listStoredClearRationalInput A).2
  let fuel := listStoredStructuralFuel D
  listStoredRationalBoundaryWork A+
    listStoredReductionFuelScalarWork fuel D+
    listStoredReductionFuelStorageWork fuel D

noncomputable def listStoredRationalTotalPolynomial : Polynomial ℕ :=
  let X := Polynomial.X
  listStoredBoundaryPolynomial+rationalScalarPolynomial+
    (listStoredFuelPolynomial+1)*(268435456*(X+X+1)^16)*
      (listStoredClearedSizePolynomial+rationalScalarPolynomial+3)

theorem listStoredRationalTotalWork_input_size (A : ListBitRationalMatrixData r r)
    (hWF : ∀ i j, (((ioMatrixVector A).get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows (ioMatrixVector A) i j : ℝ))) :
    listStoredRationalTotalWork A ≤
      listStoredRationalTotalPolynomial.eval (listStoredRationalBits A) := by
  let N := listStoredRationalBits A
  let D := (listStoredClearRationalInput A).2
  let fuel := listStoredStructuralFuel D
  have hb := listStoredRationalBoundaryWork_input_size A hWF hA
  have hs := listStoredRationalLoopScalarWork_input_size A hWF hA
  have hf := listStoredRationalFuelLength_input_size A
  have hc := listStoredClearedSize_input_size A
  have hr := listStoredRationalBits_rank A
  have hstorage := listStoredReductionFuelStorageWork_polynomial fuel D
  simp only [listMatrixVector_eq_ioMatrixVector] at hstorage
  have hp : listStoredReductionFuelStorageWork fuel D ≤
      (listStoredFuelPolynomial.eval N+1)*(268435456*(N+N+1)^16)*
        (listStoredClearedSizePolynomial.eval N+rationalScalarPolynomial.eval N+3) := by
    apply hstorage.trans
    dsimp only [D,fuel,N] at *
    gcongr
  unfold listStoredRationalTotalWork
  dsimp only
  rw [listStoredReductionFuelScalarWork_eq,listMatrixVector_eq_ioMatrixVector]
  simp only [listStoredRationalTotalPolynomial,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_pow,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat]
  change _ ≤ listStoredBoundaryPolynomial.eval N+rationalScalarPolynomial.eval N+
    (listStoredFuelPolynomial.eval N+1)*(268435456*(N+N+1)^16)*
      (listStoredClearedSizePolynomial.eval N+rationalScalarPolynomial.eval N+3)
  dsimp only [D,fuel,N] at hp
  dsimp only [N]
  omega

/-- Theorem 2.G for native Boolean-list rational input. One fixed polynomial
bounds the actual scalar, storage/control, input/output, and fuel-construction
charges in every dimension. The returned normalized rows form a basis of the
entire input lattice and satisfy the paper's sharp defect bound.

The computation model charges the concrete source list/Boolean operations;
this theorem does not assert a refinement of Lean's compiler or allocator. -/
theorem theorem2G_list_stored_reduction :
    ∃ P : Polynomial ℕ, ∀ (r : ℕ) (A : ListBitRationalMatrixData r r),
      (∀ i j, (((ioMatrixVector A).get i).get j).WellFormed) →
      LinearIndependent ℝ (fun i j => (encodedFractionRows (ioMatrixVector A) i j : ℝ)) →
      Submodule.span ℤ (Set.range (encodedFractionRows
        (ioMatrixVector (listStoredRationalReduction A).1))) =
        Submodule.span ℤ (Set.range (encodedFractionRows (ioMatrixVector A))) ∧
      (∃ b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)),
        (∀ i, b i = rationalEuclideanRows (encodedFractionRows
          (ioMatrixVector (listStoredRationalReduction A).1)) i) ∧
        euclideanOrthogonalityDefect b ≤ sharpLatticeDefectBound r) ∧
      (∀ i j, (((ioMatrixVector (listStoredRationalReduction A).1).get i).get j).WellFormed) ∧
      listStoredRationalTotalWork A ≤ P.eval (listStoredRationalBits A) := by
  refine ⟨listStoredRationalTotalPolynomial, ?_⟩
  intro r A hWF hA
  have hs := listStoredRationalReduction_spec A hWF hA
  exact ⟨hs.1,hs.2,listStoredRationalReduction_wellFormed A hWF hA,
    listStoredRationalTotalWork_input_size A hWF hA⟩

end Optss
