import Optss.BitListIntegerOperations
import Mathlib.Data.Int.GCD

/-!
# Extended Euclidean algorithm on Boolean lists

The recursion performs two Euclidean divisions per fuel cell. Remainders and
signed Bézout coefficients are stored as Boolean lists; no arithmetic on their
decoded values occurs in the answer computation. Agreement with the actual
`Nat.xgcdAux` algorithm makes the existing unimodular constructions reusable.
-/
namespace Optss

def bitListNonnegativeInteger (xs : List Bool) : BitListInteger := ⟨false,xs⟩

@[simp] theorem bitListNonnegativeInteger_value (xs : List Bool) :
    (bitListNonnegativeInteger xs).value=(binaryDigitsValue xs:ℤ) := rfl

structure BitListBezoutResult where
  gcdDigits : List Bool
  left : BitListInteger
  right : BitListInteger
  deriving Repr

def BitListBezoutResult.value (z : BitListBezoutResult) : ℕ×ℤ×ℤ :=
  (binaryDigitsValue z.gcdDigits,z.left.value,z.right.value)

def bitListXgcdFuel : List Bool → List Bool → BitListInteger → BitListInteger →
    List Bool → BitListInteger → BitListInteger → BitListBezoutResult
  | [],_,_,_,bs,s',t' => ⟨bs,s',t'⟩
  | _::fuel,as,s,t,bs,s',t' =>
    if as.isEmpty then ⟨bs,s',t'⟩ else
      let first := bitListDivision bs as
      if first.remainder.isEmpty then ⟨as,s,t⟩ else
        let q := bitListNonnegativeInteger first.quotient
        let u := bitListIntegerRowCell s' q s
        let v := bitListIntegerRowCell t' q t
        let second := bitListDivision as first.remainder
        let p := bitListNonnegativeInteger second.quotient
        bitListXgcdFuel fuel second.remainder
          (bitListIntegerRowCell s p u) (bitListIntegerRowCell t p v)
          first.remainder u v

theorem bitListXgcdFuel_correct (fuel as bs : List Bool)
    (s t s' t' : BitListInteger)
    (ha : BitListCanonical as) (hb : BitListCanonical bs) (hf : as.length≤fuel.length) :
    (bitListXgcdFuel fuel as s t bs s' t').value=
      Nat.xgcdAux (binaryDigitsValue as) s.value t.value (binaryDigitsValue bs) s'.value t'.value := by
  induction fuel generalizing as bs s t s' t' with
  | nil =>
    have he : as=[] := List.length_eq_zero_iff.mp (by simpa using hf)
    subst as
    simp [bitListXgcdFuel,BitListBezoutResult.value,binaryDigitsValue]
  | cons b fuel ih =>
    rw [bitListXgcdFuel]
    dsimp only
    split_ifs with haz hrz
    · have he : as=[] := List.isEmpty_iff.mp haz
      subst as
      simp [BitListBezoutResult.value,binaryDigitsValue]
    · have hap := ha.pos_of_not_empty haz
      have hre := (bitListDivision_correct bs as hap).2
      have hr0 : binaryDigitsValue (bitListDivision bs as).remainder=0 := by
        rw [List.isEmpty_iff.mp hrz]
        rfl
      have hm : binaryDigitsValue bs % binaryDigitsValue as=0 := by omega
      rw [Nat.xgcdAux_rec hap,hm,Nat.xgcd_zero_left]
      rfl
    · let rs := (bitListDivision bs as).remainder
      let ss := (bitListDivision as rs).remainder
      have hap := ha.pos_of_not_empty haz
      have hq := (bitListDivision_correct bs as hap).1
      have hre : binaryDigitsValue rs=binaryDigitsValue bs % binaryDigitsValue as :=
        (bitListDivision_correct bs as hap).2
      have hrc : BitListCanonical rs := by
        change rs=(binaryDigitsValue rs).bits
        rw [hre]
        exact (bitListDivision_encodings bs as hap).2
      have hrp : 0<binaryDigitsValue rs := hrc.pos_of_not_empty hrz
      have hp := (bitListDivision_correct as rs hrp).1
      have hse : binaryDigitsValue ss=binaryDigitsValue as % binaryDigitsValue rs :=
        (bitListDivision_correct as rs hrp).2
      have hsc : BitListCanonical ss := by
        change ss=(binaryDigitsValue ss).bits
        rw [hse]
        exact (bitListDivision_encodings as rs hrp).2
      have hral : binaryDigitsValue rs<binaryDigitsValue as := hre ▸ Nat.mod_lt _ hap
      have hsize := remainder_bits_lt (binaryDigitsValue as) (binaryDigitsValue rs) hrp hral
      have hsf : ss.length≤fuel.length := by
        rw [hsc.length,hse]
        rw [ha.length,List.length_cons] at hf
        omega
      rw [ih _ _ _ _ _ _ hsc hrc hsf]
      simp only [bitListIntegerRowCell_value,bitListNonnegativeInteger_value,hq,hp]
      rw [Nat.xgcdAux_rec hap,←hre,Nat.xgcdAux_rec hrp,←hse]
      simp only [show (bitListDivision bs as).remainder=rs from rfl,hp,Int.natCast_ediv]

def bitListNatXgcd (xs ys : List Bool) : BitListBezoutResult :=
  let as := bitListTrim xs
  let bs := bitListTrim ys
  bitListXgcdFuel as as (bitListNonnegativeInteger [true]) (bitListNonnegativeInteger [])
    bs (bitListNonnegativeInteger []) (bitListNonnegativeInteger [true])

theorem bitListNatXgcd_correct (xs ys : List Bool) :
    (bitListNatXgcd xs ys).value=
      (Nat.gcd (binaryDigitsValue xs) (binaryDigitsValue ys),
       Nat.gcdA (binaryDigitsValue xs) (binaryDigitsValue ys),
       Nat.gcdB (binaryDigitsValue xs) (binaryDigitsValue ys)) := by
  unfold bitListNatXgcd
  rw [bitListXgcdFuel_correct _ _ _ _ _ _ _ (bitListTrim_canonical _) (bitListTrim_canonical _) le_rfl]
  simp only [bitListTrim_value,bitListNonnegativeInteger_value]
  change Nat.xgcdAux _ 1 0 _ 0 1=_
  rw [Nat.xgcdAux_val,Nat.xgcd_val]

theorem bitListNatXgcd_bezout (xs ys : List Bool) :
    (binaryDigitsValue xs:ℤ)*(bitListNatXgcd xs ys).left.value+
      (binaryDigitsValue ys:ℤ)*(bitListNatXgcd xs ys).right.value=
      (Nat.gcd (binaryDigitsValue xs) (binaryDigitsValue ys):ℤ) := by
  have hl := congrArg (fun z : ℕ×ℤ×ℤ => z.2.1) (bitListNatXgcd_correct xs ys)
  have hr := congrArg (fun z : ℕ×ℤ×ℤ => z.2.2) (bitListNatXgcd_correct xs ys)
  change (bitListNatXgcd xs ys).left.value=_ at hl
  change (bitListNatXgcd xs ys).right.value=_ at hr
  rw [hl,hr]
  exact (Nat.gcd_eq_gcd_ab _ _).symm
@[simp] theorem bitListNatXgcd_left (xs ys : List Bool) :
    (bitListNatXgcd xs ys).left.value=Nat.gcdA (binaryDigitsValue xs) (binaryDigitsValue ys) :=
  congrArg (fun z : ℕ×ℤ×ℤ => z.2.1) (bitListNatXgcd_correct xs ys)

@[simp] theorem bitListNatXgcd_right (xs ys : List Bool) :
    (bitListNatXgcd xs ys).right.value=Nat.gcdB (binaryDigitsValue xs) (binaryDigitsValue ys) :=
  congrArg (fun z : ℕ×ℤ×ℤ => z.2.2) (bitListNatXgcd_correct xs ys)

@[simp] theorem bitListNatXgcd_gcd (xs ys : List Bool) :
    binaryDigitsValue (bitListNatXgcd xs ys).gcdDigits=Nat.gcd (binaryDigitsValue xs) (binaryDigitsValue ys) :=
  congrArg Prod.fst (bitListNatXgcd_correct xs ys)

def bitListIntegerXgcd (x y : BitListInteger) : BitListBezoutResult :=
  let out := bitListNatXgcd x.digits y.digits
  ⟨out.gcdDigits,if x.negative then bitListIntegerNeg out.left else out.left,
    if y.negative then bitListIntegerNeg out.right else out.right⟩

/-- Exact agreement on ordinary integer encodings, including zero and negative
inputs. Arbitrary negative-zero representations still give a valid Bézout
identity, but need not choose the same coefficients in the doubly-zero case. -/
theorem bitListIntegerXgcd_bits (x y : ℤ) :
    (bitListIntegerXgcd (integerBitRepresentation x) (integerBitRepresentation y)).value=
      (Int.gcd x y,Int.gcdA x y,Int.gcdB x y) := by
  cases x <;> cases y <;>
    simp [bitListIntegerXgcd,BitListBezoutResult.value,integerBitRepresentation,
      bitListIntegerNeg_value,Int.gcdA,Int.gcdB,Int.gcd_def,binaryDigitsValue_bits,
      show ∀ n : ℕ,¬(n:ℤ)<0 from fun n => not_lt.mpr (Int.natCast_nonneg n)]

end Optss
