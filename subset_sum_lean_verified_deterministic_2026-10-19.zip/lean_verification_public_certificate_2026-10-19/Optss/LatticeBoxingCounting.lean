import Optss.LatticeBoxingGeometry
import Optss.ProperizationQuotient
import Optss.BoxVertexNormalization

/-!
# Boxing and uniform counting in the full basis lattice

The finite sets below contain exactly all points of the supplied full lattice
in a compact body. Transport through basis coordinates connects the geometric
boxing theorem to the residue-class count, uniformly at every real dilation.
An actual reduced-basis defect bound remains an explicit input.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [FiniteDimensional ℝ E] {r : ℕ}

def basisIntegerCoordinates (b : Basis (Fin r) ℝ E) (K : Set E) (hK : IsCompact K) :
    Finset (IntVec r) :=
  integerPoints (b.equivFun '' K)
    (hK.image b.equivFun.continuous_of_finiteDimensional).isBounded

def basisLatticePoints (b : Basis (Fin r) ℝ E) (K : Set E) (hK : IsCompact K) : Finset E :=
  (basisIntegerCoordinates b K hK).image (fun z => b.equivFun.symm (realVector z))

omit [FiniteDimensional ℝ E] in
theorem basis_integer_synthesis_injective (b : Basis (Fin r) ℝ E) :
    Function.Injective (fun z : IntVec r => b.equivFun.symm (realVector z)) := by
  intro x y h
  have he := b.equivFun.symm.injective h
  ext j
  have hj : (x j : ℝ) = (y j : ℝ) := congrFun he j
  exact_mod_cast hj

@[simp] theorem mem_basisLatticePoints (b : Basis (Fin r) ℝ E) (K : Set E) (hK : IsCompact K)
    (x : E) : x ∈ basisLatticePoints b K hK ↔ x ∈ K ∧ x ∈ basisIntegerLattice b := by
  constructor
  · intro hx
    obtain ⟨z, hz, rfl⟩ := Finset.mem_image.mp hx
    obtain ⟨y, hy, he⟩ := (mem_integerPoints _ _ z).mp hz
    refine ⟨?_, ?_⟩
    · simpa only [← he, LinearEquiv.symm_apply_apply] using hy
    · intro j
      refine ⟨z j, ?_⟩
      change b.equivFun (b.equivFun.symm (realVector z)) j = (z j : ℝ)
      rw [LinearEquiv.apply_symm_apply]
      rfl
  · rintro ⟨hxK, hxΛ⟩
    choose z hz using hxΛ
    have he : b.equivFun x = realVector z := funext hz
    apply Finset.mem_image.mpr
    refine ⟨z, (mem_integerPoints _ _ z).mpr ⟨x, hxK, he⟩, ?_⟩
    rw [← he, LinearEquiv.symm_apply_apply]

@[simp] theorem card_basisLatticePoints (b : Basis (Fin r) ℝ E) (K : Set E) (hK : IsCompact K) :
    (basisLatticePoints b K hK).card = (basisIntegerCoordinates b K hK).card :=
  Finset.card_image_of_injective _ (basis_integer_synthesis_injective b)

omit [FiniteDimensional ℝ E] in
theorem basisCoefficientBox_compact (b : Basis (Fin r) ℝ E) (n : Fin r → ℕ) :
    IsCompact (basisCoefficientBox b n) := by
  rw [basisCoefficientBox_eq_image]
  have he : {u : Fin r → ℝ | ∀ j, |u j| ≤ (n j:ℝ)} = realCoefficientBox n := by
    ext u
    exact (mem_realCoefficientBox n u).symm
  rw [he]
  exact (realCoefficientBox_compact n).image b.equivFun.symm.continuous_of_finiteDimensional

omit [FiniteDimensional ℝ E] in
theorem basisCoordinates_smul (b : Basis (Fin r) ℝ E) (K : Set E) (a : ℝ) :
    b.equivFun '' (a • K) = a • (b.equivFun '' K) := by
  ext x
  constructor
  · rintro ⟨y, ⟨z, hz, rfl⟩, rfl⟩
    exact ⟨b.equivFun z, ⟨z, hz, rfl⟩, (map_smul b.equivFun a z).symm⟩
  · rintro ⟨y, ⟨z, hz, rfl⟩, rfl⟩
    exact ⟨a • z, ⟨z, hz, rfl⟩, map_smul b.equivFun a z⟩

/-- The count is for all actual lattice points and is uniform even when the
external dilation lies below the shortest nonzero lattice vector. -/
theorem basisLatticePoints_enclosing_uniform (b : Basis (Fin r) ℝ E)
    (K C : Set E) (hK : IsCompact K) (hC : IsCompact C) (hcK : Convex ℝ K)
    (hsym : ∀ x ∈ K, -x ∈ K) (c : ℝ) (hc : 0 ≤ c) (hencl : C ⊆ c • K)
    (p : ℕ) (hp : 0 < p) (hcp : 2*c ≤ p) (a : ℝ) :
    (basisLatticePoints b (a • C) (hC.smul a)).card ≤
      p^r*(basisLatticePoints b (a • K) (hK.smul a)).card := by
  have hcoords : b.equivFun '' C ⊆ c • (b.equivFun '' K) := by
    rw [← basisCoordinates_smul]
    exact Set.image_mono hencl
  have hsymc : ∀ x ∈ b.equivFun '' K, -x ∈ b.equivFun '' K := by
    rintro x ⟨y, hy, rfl⟩
    exact ⟨-y, hsym y hy, map_neg _ _⟩
  have h := integerPoints_enclosing_uniform (b.equivFun '' K) (b.equivFun '' C)
    (hcK.linear_image b.equivFun.toLinearMap)
    (hK.image b.equivFun.continuous_of_finiteDimensional).isBounded
    (hC.image b.equivFun.continuous_of_finiteDimensional).isBounded
    hsymc c hc hcoords p hp hcp a
  simpa only [card_basisLatticePoints, basisIntegerCoordinates, basisCoordinates_smul] using h

/-- A completely specified dimension/defect-dependent residue modulus. -/
def latticeBoxingResidueModulus (r : ℕ) (ω : ℝ) : ℕ :=
  ⌈2*latticeBoxingDilation r ((r.factorial:ℝ)*ω)⌉₊+1

theorem latticeBoxingResidueModulus_pos (r : ℕ) (ω : ℝ) :
    0 < latticeBoxingResidueModulus r ω := by
  unfold latticeBoxingResidueModulus
  omega

theorem latticeBoxingResidueModulus_bound (r : ℕ) (ω : ℝ) :
    2*latticeBoxingDilation r ((r.factorial:ℝ)*ω) ≤ latticeBoxingResidueModulus r ω := by
  unfold latticeBoxingResidueModulus
  push_cast
  have h := Nat.le_ceil (2*latticeBoxingDilation r ((r.factorial:ℝ)*ω))
  linarith

/-- The geometric and lattice-counting conclusions of B.1 in one theorem.
The same actual full lattice basis is used in both containments and every
dilated count. Reduction and normalization are still explicit inputs here. -/
theorem lattice_boxing_and_counting_of_normalization (hr : 0 < r)
    (K : Set E) (hK : IsCompact K) (hcK : Convex ℝ K)
    (hsym : ∀ x ∈ K, -x ∈ K)
    (e : E ≃L[ℝ] EuclideanSpace ℝ (Fin r))
    (hinner : euclideanCoordinateCube r (1/(r:ℝ)) ⊆ e '' K)
    (houter : e '' K ⊆ euclideanCoordinateCube r 1)
    (b : Basis (Fin r) ℝ E) (ω : ℝ) (hω : 0 < ω)
    (hdefect : euclideanOrthogonalityDefect (b.map e.toLinearEquiv) ≤ ω)
    (x : Fin r → E) (hind : LinearIndependent ℝ x)
    (hxK : ∀ i, x i ∈ K) (hxΛ : ∀ i, x i ∈ basisIntegerLattice b) :
    ∃ n : Fin r → ℕ, (∀ j, 1 ≤ n j) ∧ K ⊆ basisCoefficientBox b n ∧
      basisCoefficientBox b n ⊆ latticeBoxingDilation r ((r.factorial:ℝ)*ω) • K ∧
      ∀ a : ℝ,
        (basisLatticePoints b (a • basisCoefficientBox b n)
          ((basisCoefficientBox_compact b n).smul a)).card ≤
        (latticeBoxingResidueModulus r ω)^r *
          (basisLatticePoints b (a • K) (hK.smul a)).card := by
  obtain ⟨n, hn, hsub, hencl⟩ := lattice_boxing_of_normalization hr K hK e hinner houter
    b ω hω hdefect x hind hxK hxΛ
  refine ⟨n, hn, hsub, hencl, fun a => ?_⟩
  exact basisLatticePoints_enclosing_uniform b K (basisCoefficientBox b n) hK
    (basisCoefficientBox_compact b n) hcK hsym
    (latticeBoxingDilation r ((r.factorial:ℝ)*ω)) (by unfold latticeBoxingDilation; positivity)
    hencl (latticeBoxingResidueModulus r ω) (latticeBoxingResidueModulus_pos r ω)
    (latticeBoxingResidueModulus_bound r ω) a

/-- Exact coefficient-box cardinality; the basis may generate any full lattice. -/
theorem basisIntegerCoordinates_box (b : Basis (Fin r) ℝ E) (n : Fin r → ℕ) :
    basisIntegerCoordinates b (basisCoefficientBox b n) (basisCoefficientBox_compact b n) =
      integerBudgetBox n := by
  ext z
  rw [basisIntegerCoordinates, mem_integerPoints, mem_integerBudgetBox]
  constructor
  · rintro ⟨x, hx, he⟩ j
    have hj := hx j
    change |b.equivFun x j| ≤ (n j:ℝ) at hj
    rw [he] at hj
    change |(z j:ℝ)| ≤ (n j:ℝ) at hj
    exact_mod_cast hj
  · intro hz
    refine ⟨b.equivFun.symm (realVector z), ?_, b.equivFun.apply_symm_apply _⟩
    intro j
    change |b.equivFun (b.equivFun.symm (realVector z)) j| ≤ (n j:ℝ)
    rw [LinearEquiv.apply_symm_apply]
    change |(z j:ℝ)| ≤ (n j:ℝ)
    exact_mod_cast hz j

theorem basisLatticePoints_box_card (b : Basis (Fin r) ℝ E) (n : Fin r → ℕ) :
    (basisLatticePoints b (basisCoefficientBox b n) (basisCoefficientBox_compact b n)).card =
      ∏ j, (2*n j+1) := by
  rw [card_basisLatticePoints, basisIntegerCoordinates_box, integerBudgetBox_card]

section StandardLattice

theorem realVector_is_injective : Function.Injective (realVector (d := r)) := by
  intro x y h
  ext j
  have hj : (x j:ℝ)=(y j:ℝ) := congrFun h j
  exact_mod_cast hj

/-- When the basis generates the complete standard lattice, the finite set is
literally the image of all integer points of the body, with no index loss. -/
theorem basisLatticePoints_standard (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (hΛ : basisIntegerLattice b = Set.range realVector)
    (K : Set (Fin r → ℝ)) (hK : IsCompact K) :
    basisLatticePoints b K hK = (integerPoints K hK.isBounded).image realVector := by
  ext x
  simp only [mem_basisLatticePoints, hΛ, Set.mem_range, Finset.mem_image, mem_integerPoints]
  aesop

theorem basisLatticePoints_standard_card (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (hΛ : basisIntegerLattice b = Set.range realVector)
    (K : Set (Fin r → ℝ)) (hK : IsCompact K) :
    (basisLatticePoints b K hK).card = (integerPoints K hK.isBounded).card := by
  rw [basisLatticePoints_standard b hΛ]
  exact Finset.card_image_of_injective _ realVector_is_injective

end StandardLattice

end
end Optss
