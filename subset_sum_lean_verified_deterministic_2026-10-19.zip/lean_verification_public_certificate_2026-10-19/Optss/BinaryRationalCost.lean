import Optss.BinaryRationalOperations
import Optss.RationalArithmeticBounds

/-!
# Polynomial operand-width charges for rational operations

These bounds apply to the actual binary implementations. They compose the
shift/add multiplication charges with the gcd/division normalization charges.
They are not by themselves a machine-level bit-runtime theorem.
-/

namespace Optss

def RationalBitBound (q : ℚ) (L : ℕ) : Prop :=
  q.num.natAbs.size ≤ L ∧ q.den.size ≤ L

def rationalNormalizationWork (L : ℕ) : ℕ := 16*L^2*(2*L+2)+16*L*(2*L+2)

def rationalProductWork (L : ℕ) : ℕ := 4*L*(3*L+2)

theorem binaryNormalization_work_of_bits (z : ℤ) (D : ℕ) (hD : 0 < D) (L : ℕ)
    (hz : z.natAbs.size ≤ L) (hd : D.size ≤ L) :
    (binaryNormalizeFraction z D hD).2 ≤ rationalNormalizationWork L := by
  apply (binaryNormalizeFraction_widthWork z D hD).trans
  have hm : max z.natAbs.size D.size ≤ L := max_le hz hd
  unfold rationalNormalizationWork
  gcongr

theorem binaryIntMultiplication_work_of_bits (a b : ℤ) (L : ℕ)
    (ha : a.natAbs.size ≤ L) (hb : b.natAbs.size ≤ L) :
    (binaryIntMultiplication a b).2 ≤ rationalProductWork L := by
  exact (binaryIntMultiplication_widthWork a b).trans
    (Nat.mul_le_mul (Nat.mul_le_mul_left 4 hb) (by omega))

theorem binaryMultiplication_work_of_bits (a b L : ℕ) (ha : a.size ≤ L) (hb : b.size ≤ L) :
    (binaryMultiplication a b).widthWork ≤ rationalProductWork L := by
  exact (binaryMultiplication_widthWork a b).trans
    (Nat.mul_le_mul (Nat.mul_le_mul_left 4 hb) (by omega))

theorem int_mul_bits_le (a b : ℤ) : (a*b).natAbs.size ≤ a.natAbs.size+b.natAbs.size := by
  rw [Int.natAbs_mul]
  exact nat_mul_size_le _ _

theorem nat_add_bits_le (a b : ℕ) : (a+b).size ≤ max a.size b.size+1 := by
  apply Nat.size_le.mpr
  rw [pow_succ]
  have ha : a < 2^(max a.size b.size) := (Nat.lt_size_self a).trans_le
    (Nat.pow_le_pow_right (by omega) (le_max_left _ _))
  have hb : b < 2^(max a.size b.size) := (Nat.lt_size_self b).trans_le
    (Nat.pow_le_pow_right (by omega) (le_max_right _ _))
  omega

theorem int_add_bits_le (a b : ℤ) :
    (a+b).natAbs.size ≤ max a.natAbs.size b.natAbs.size+1 :=
  (Nat.size_le_size (Int.natAbs_add_le _ _)).trans (nat_add_bits_le _ _)

theorem binaryRatMul_widthWork (p q : ℚ) (L : ℕ)
    (hp : RationalBitBound p L) (hq : RationalBitBound q L) :
    (binaryRatMul p q).2 ≤ 2*rationalProductWork L+rationalNormalizationWork (2*L) := by
  have hpnum := hp.1
  have hqnum := hq.1
  have hpden := hp.2
  have hqden := hq.2
  have hn := binaryIntMultiplication_work_of_bits p.num q.num L hp.1 hq.1
  have hd := binaryMultiplication_work_of_bits p.den q.den L hp.2 hq.2
  have hnb : (binaryIntMultiplication p.num q.num).1.natAbs.size ≤ 2*L := by
    rw [binaryIntMultiplication_correct]
    exact (int_mul_bits_le _ _).trans (by omega)
  have hdb : (binaryMultiplication p.den q.den).value.size ≤ 2*L := by
    rw [binaryMultiplication_correct]
    exact (nat_mul_size_le _ _).trans (by omega)
  unfold binaryRatMul
  have hnorm := binaryNormalization_work_of_bits (binaryIntMultiplication p.num q.num).1
    (binaryMultiplication p.den q.den).value
    (by rw [binaryMultiplication_correct]; exact Nat.mul_pos p.den_pos q.den_pos)
    (2*L) hnb hdb
  dsimp only
  omega

theorem binaryRatAdd_widthWork (p q : ℚ) (L : ℕ)
    (hp : RationalBitBound p L) (hq : RationalBitBound q L) :
    (binaryRatAdd p q).2 ≤
      3*rationalProductWork L+(2*L+1)+rationalNormalizationWork (2*L+1) := by
  have hpnum := hp.1
  have hqnum := hq.1
  have hpd := hp.2
  have hqd := hq.2
  have hpden : (p.den:ℤ).natAbs.size ≤ L := by simpa using hp.2
  have hqden : (q.den:ℤ).natAbs.size ≤ L := by simpa using hq.2
  have hl := binaryIntMultiplication_work_of_bits p.num q.den L hp.1 hqden
  have hr := binaryIntMultiplication_work_of_bits p.den q.num L hpden hq.1
  have hd := binaryMultiplication_work_of_bits p.den q.den L hp.2 hq.2
  let left := (binaryIntMultiplication p.num q.den).1
  let right := (binaryIntMultiplication p.den q.num).1
  have hlb : left.natAbs.size ≤ 2*L := by
    dsimp [left]
    rw [binaryIntMultiplication_correct]
    exact (int_mul_bits_le _ _).trans (by omega)
  have hrb : right.natAbs.size ≤ 2*L := by
    dsimp [right]
    rw [binaryIntMultiplication_correct]
    exact (int_mul_bits_le _ _).trans (by omega)
  have hnb : (left+right).natAbs.size ≤ 2*L+1 :=
    (int_add_bits_le _ _).trans (by omega)
  have hdb : (binaryMultiplication p.den q.den).value.size ≤ 2*L+1 := by
    rw [binaryMultiplication_correct]
    exact (nat_mul_size_le _ _).trans (by omega)
  unfold binaryRatAdd
  have hnorm := binaryNormalization_work_of_bits (left+right)
    (binaryMultiplication p.den q.den).value
    (by rw [binaryMultiplication_correct]; exact Nat.mul_pos p.den_pos q.den_pos)
    (2*L+1) hnb hdb
  dsimp only
  change _ ≤ _ at hnorm
  dsimp [left, right] at hlb hrb hnorm
  omega

theorem RationalBitBound.neg {q : ℚ} {L : ℕ} (hq : RationalBitBound q L) :
    RationalBitBound (-q) L := by simpa [RationalBitBound] using hq

theorem binaryRatSub_widthWork (p q : ℚ) (L : ℕ)
    (hp : RationalBitBound p L) (hq : RationalBitBound q L) :
    (binaryRatSub p q).2 ≤
      3*rationalProductWork L+(2*L+1)+rationalNormalizationWork (2*L+1) :=
  binaryRatAdd_widthWork p (-q) L hp hq.neg

theorem binaryRatInv_widthWork (q : ℚ) (L : ℕ) (hq : RationalBitBound q L) :
    (binaryRatInv q).2 ≤ rationalNormalizationWork L := by
  unfold binaryRatInv
  split_ifs with hn
  · simp
  · have hb : (q.num.sign*(q.den:ℤ)).natAbs.size ≤ L := by
      simpa only [Int.natAbs_mul, Int.natAbs_sign_of_nonzero hn, Int.natAbs_natCast, one_mul]
        using hq.2
    exact binaryNormalization_work_of_bits _ _ _ L hb hq.1

theorem RationalBitBound.inv {q : ℚ} {L : ℕ} (hq : RationalBitBound q L) :
    RationalBitBound q⁻¹ L := by
  have hL : 0 < L := (Nat.size_pos.mpr q.den_pos).trans_le hq.2
  unfold RationalBitBound
  rw [Rat.inv_def']
  constructor
  · have hn := Nat.size_le_size (rational_divInt_num_le (q.den:ℤ) q.num)
    simpa only [Int.natAbs_natCast] using hn.trans hq.2
  · apply Nat.size_le.mpr
    apply (rational_divInt_den_le (q.den:ℤ) q.num).trans_lt
    apply max_lt
    · exact Nat.one_lt_two_pow hL.ne'
    · exact (Nat.lt_size_self q.num.natAbs).trans_le
        (Nat.pow_le_pow_right (by omega) hq.1)

theorem binaryRatDiv_widthWork (p q : ℚ) (L : ℕ)
    (hp : RationalBitBound p L) (hq : RationalBitBound q L) :
    (binaryRatDiv p q).2 ≤ rationalNormalizationWork L+
      2*rationalProductWork L+rationalNormalizationWork (2*L) := by
  have hi := binaryRatInv_widthWork q L hq
  have hqi : RationalBitBound (binaryRatInv q).1 L := by
    rw [binaryRatInv_correct]
    exact hq.inv
  have hm := binaryRatMul_widthWork p (binaryRatInv q).1 L hp hqi
  change (binaryRatInv q).2+(binaryRatMul p (binaryRatInv q).1).2 ≤ _
  omega

/-- A single cubic envelope covers each of the four binary rational
operations on operands whose reduced fields have at most `L` magnitude bits. -/
theorem binaryRatOperations_cubic (p q : ℚ) (L : ℕ)
    (hp : RationalBitBound p L) (hq : RationalBitBound q L) :
    (binaryRatAdd p q).2 ≤ 2048*(L+1)^3 ∧
    (binaryRatSub p q).2 ≤ 2048*(L+1)^3 ∧
    (binaryRatMul p q).2 ≤ 2048*(L+1)^3 ∧
    (binaryRatDiv p q).2 ≤ 2048*(L+1)^3 := by
  have hadd := binaryRatAdd_widthWork p q L hp hq
  have hsub := binaryRatSub_widthWork p q L hp hq
  have hmul := binaryRatMul_widthWork p q L hp hq
  have hdiv := binaryRatDiv_widthWork p q L hp hq
  unfold rationalNormalizationWork rationalProductWork at hadd hsub hmul hdiv
  constructor
  · nlinarith
  constructor
  · nlinarith
  constructor <;> nlinarith

end Optss
