import Optss.ExecutableProperizationIteration

/-!
# Sequential enumeration of an integer progression

The tail progression is computed once and shared across all coefficients of
the first generator. The answer is a list, with no duplicate-removal search.
Properness proves that this actual list is already distinct. The charge counts
bounded-word arithmetic and list operations; operand and input-access bounds
for particular callers are separate from the enumeration trace.
-/
namespace Optss
open scoped BigOperators

def progressionCoefficientList (m : ℕ) : List ℤ :=
  (List.range (2*m+1)).map (fun k : ℕ => (k:ℤ)-(m:ℤ))

theorem mem_progressionCoefficientList (m : ℕ) (z : ℤ) :
    z∈progressionCoefficientList m ↔ |z|≤(m:ℤ) := by
  simp only [progressionCoefficientList,List.mem_map,List.mem_range]
  constructor
  · rintro ⟨k,hk,rfl⟩
    have hk0 : (0:ℤ)≤k := by positivity
    have hk' : (k:ℤ)<2*(m:ℤ)+1 := by exact_mod_cast hk
    rw [abs_le]
    omega
  · intro hz
    obtain ⟨hl,hu⟩ := abs_le.mp hz
    have hn : ((z+(m:ℤ)).toNat:ℤ)=z+(m:ℤ) := Int.toNat_of_nonneg (by omega)
    refine ⟨(z+(m:ℤ)).toNat,?_,?_⟩ <;> omega

theorem progressionCoefficientList_length (m : ℕ) :
    (progressionCoefficientList m).length=2*m+1 := by simp [progressionCoefficientList]

def progressionValueList : (r : ℕ) → (Fin r→ℤ) → (Fin r→ℕ) → List ℤ
  | 0,_,_ => [0]
  | r+1,a,β =>
    let tail := progressionValueList r (Fin.tail a) (Fin.tail β)
    let head := a 0
    (progressionCoefficientList (β 0)).flatMap (fun z => tail.map (fun x => head*z+x))

theorem integerBudgetBox_cons {r : ℕ} (β : Fin (r+1)→ℕ) (z : ℤ) (tail : Fin r→ℤ) :
    Fin.cons z tail∈integerBudgetBox β ↔ |z|≤(β 0:ℤ) ∧ tail∈integerBudgetBox (Fin.tail β) := by
  simp only [mem_integerBudgetBox]
  constructor
  · intro h
    exact ⟨by simpa using h 0,fun j => by simpa using h j.succ⟩
  · rintro ⟨hz,ht⟩ j
    exact Fin.cases hz ht j

theorem progressionLinearEncoding_cons {r : ℕ} (a : Fin (r+1)→ℤ) (z : ℤ) (tail : Fin r→ℤ) :
    progressionLinearEncoding a (Fin.cons z tail)=a 0*z+progressionLinearEncoding (Fin.tail a) tail := by
  simp [progressionLinearEncoding,Fin.sum_univ_succ,Fin.tail]

theorem mem_progressionValueList (r : ℕ) (a : Fin r→ℤ) (β : Fin r→ℕ) (x : ℤ) :
    x∈progressionValueList r a β ↔
      ∃ z∈integerBudgetBox β,progressionLinearEncoding a z=x := by
  induction r generalizing x with
  | zero => simp [progressionValueList,mem_integerBudgetBox,progressionLinearEncoding,InBox,eq_comm]
  | succ r ih =>
    simp only [progressionValueList,List.mem_flatMap,List.mem_map,mem_progressionCoefficientList]
    constructor
    · rintro ⟨z,hz,w,hw,rfl⟩
      obtain ⟨tail,ht,rfl⟩ := (ih (Fin.tail a) (Fin.tail β) w).mp hw
      exact ⟨Fin.cons z tail,(integerBudgetBox_cons β z tail).mpr ⟨hz,ht⟩,
        progressionLinearEncoding_cons a z tail⟩
    · rintro ⟨z,hz,rfl⟩
      have he : Fin.cons (z 0) (Fin.tail z)=z := Fin.cons_self_tail z
      have hz' := (integerBudgetBox_cons β (z 0) (Fin.tail z)).mp (he.symm ▸ hz)
      refine ⟨z 0,hz'.1,progressionLinearEncoding (Fin.tail a) (Fin.tail z),
        (ih (Fin.tail a) (Fin.tail β) _).mpr ⟨Fin.tail z,hz'.2,rfl⟩,?_⟩
      rw [←progressionLinearEncoding_cons,he]

theorem progressionValueList_toFinset (r : ℕ) (a : Fin r→ℤ) (β : Fin r→ℕ) :
    (progressionValueList r a β).toFinset=
      integerProgressionValues (progressionLinearEncoding a).toAddMonoidHom β := by
  ext x
  simp only [List.mem_toFinset,mem_progressionValueList,integerProgressionValues,Finset.mem_image]
  rfl

theorem progressionValueList_length (r : ℕ) (a : Fin r→ℤ) (β : Fin r→ℕ) :
    (progressionValueList r a β).length=∏ j,(2*β j+1) := by
  induction r with
  | zero => simp [progressionValueList]
  | succ r ih =>
    simp only [progressionValueList,List.length_flatMap,List.length_map,ih]
    rw [List.map_const',List.sum_replicate,progressionCoefficientList_length,Fin.prod_univ_succ]
    rfl

theorem progressionValueList_nodup (r : ℕ) (a : Fin r→ℤ) (β : Fin r→ℕ)
    (hp : Set.InjOn (progressionLinearEncoding a) (integerBudgetBox β)) :
    (progressionValueList r a β).Nodup := by
  have hp' : Set.InjOn (progressionLinearEncoding a).toAddMonoidHom (integerBudgetBox β) := hp
  apply (Multiset.toFinset_card_eq_card_iff_nodup
    (m:=(progressionValueList r a β:Multiset ℤ))).mp
  change (progressionValueList r a β).toFinset.card=(progressionValueList r a β).length
  rw [progressionValueList_toFinset,integerProgressionValues,Finset.card_image_of_injOn hp',
    integerBudgetBox_card,progressionValueList_length]

def progressionValueListWordWork : (r : ℕ) → (Fin r→ℤ) → (Fin r→ℕ) → ℕ
  | 0,_,_ => 2
  | r+1,a,β =>
    let tail := progressionValueList r (Fin.tail a) (Fin.tail β)
    let headLength := 2*β 0+1
    progressionValueListWordWork r (Fin.tail a) (Fin.tail β)+8+8*headLength+
      8*headLength*(tail.length+1)

theorem progressionValueListWordWork_bound (r : ℕ) (a : Fin r→ℤ) (β : Fin r→ℕ) :
    progressionValueListWordWork r a β≤64*(r+1)*(integerBudgetBox β).card := by
  induction r with
  | zero => simp [progressionValueListWordWork,integerBudgetBox_card]
  | succ r ih =>
    have ht := ih (Fin.tail a) (Fin.tail β)
    have htpos : 1≤∏ j : Fin r,(2*(Fin.tail β) j+1) := by
      apply Finset.one_le_prod'
      intro j _
      omega
    have hm := Nat.mul_le_mul_left (64*(r+1)*(∏ j : Fin r,(2*(Fin.tail β) j+1)))
      (show 1≤2*β 0+1 by omega)
    simp only [integerBudgetBox_card] at ht ⊢
    rw [Fin.prod_univ_succ]
    simp only [progressionValueListWordWork,progressionValueList_length]
    change _≤64*(r+1+1)*((2*β 0+1)*(∏ j : Fin r,(2*(Fin.tail β) j+1)))
    nlinarith [Nat.mul_le_mul_left (16*(2*β 0+1)) htpos]

end Optss
