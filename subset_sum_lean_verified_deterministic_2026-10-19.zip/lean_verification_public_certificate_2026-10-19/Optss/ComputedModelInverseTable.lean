import Optss.CenteredModelExtension
import Optss.ArrayInverseTable

/-!
# Actual inverse table for the modeled double difference

Only the list of original double differences is scanned. A centered residue
computes each finite-group address, and the stored table realizes the abstract
inverse used to lift a progression. No tuple search computes a table entry.
-/
namespace Optss
open scoped Pointwise

def computedModelInverseTable (differences : List ℤ) (n p q : ℕ) : Array (Option ℤ) :=
  arrayInverseTable (fun a => (centeredModelExtension n p q a).val) p differences

theorem computedModelInverseTable_correct (data differences : List ℤ) (n p q : ℕ)
    [NeZero p] (hq : 0<q)
    (hf : FreimanEight (computedModelingPart data n q).toFinset
      (fun a => (modelingResidue (n:ZMod q) a : ZMod p)))
    (hdiff : differences.toFinset=
      ((computedModelingPart data n q).toFinset+(computedModelingPart data n q).toFinset)-
        ((computedModelingPart data n q).toFinset+(computedModelingPart data n q).toFinset))
    (x : ZMod p) (a : ℤ) :
    (computedModelInverseTable differences n p q)[x.val]?=some (some a) ↔
      a∈differences ∧ centeredModelExtension n p q a=x := by
  have hinj := centeredModelExtension_injective data n p q hq hf
  have htable := arrayInverseTable_correct (fun a => (centeredModelExtension n p q a).val)
    p differences (fun a _ => ZMod.val_lt _) (by
      intro a ha b hb hab
      apply hinj
      · rw [←hdiff]; exact List.mem_toFinset.mpr ha
      · rw [←hdiff]; exact List.mem_toFinset.mpr hb
      · exact ZMod.val_injective p hab) x.val a
  simpa only [computedModelInverseTable,(ZMod.val_injective p).eq_iff] using htable

theorem computedModelInverseTable_lift (data differences : List ℤ) (n p q : ℕ)
    [NeZero p] (hq : 0<q)
    (hf : FreimanEight (computedModelingPart data n q).toFinset
      (fun a => (modelingResidue (n:ZMod q) a : ZMod p)))
    (hdiff : differences.toFinset=
      ((computedModelingPart data n q).toFinset+(computedModelingPart data n q).toFinset)-
        ((computedModelingPart data n q).toFinset+(computedModelingPart data n q).toFinset))
    (x : ZMod p)
    (hx : x∈
      (((computedModelingPart data n q).toFinset.image (fun a => (modelingResidue (n:ZMod q) a:ZMod p)))+
        ((computedModelingPart data n q).toFinset.image (fun a => (modelingResidue (n:ZMod q) a:ZMod p))))-
      (((computedModelingPart data n q).toFinset.image (fun a => (modelingResidue (n:ZMod q) a:ZMod p)))+
        ((computedModelingPart data n q).toFinset.image (fun a => (modelingResidue (n:ZMod q) a:ZMod p))))) :
    (computedModelInverseTable differences n p q)[x.val]?=some (some
      (modelDifferenceLift (computedModelingPart data n q).toFinset
        (fun a => (modelingResidue (n:ZMod q) a:ZMod p)) x)) := by
  obtain ⟨u,hu,rfl⟩ := (mem_model_doubleDifference_iff _ _ x).mp hx
  rw [modelDifferenceLift_representation hf u hu]
  apply (computedModelInverseTable_correct data differences n p q hq hf hdiff _ _).mpr
  constructor
  · apply List.mem_toFinset.mp
    rw [hdiff]
    exact (mem_doubleDifference_iff _ _).mpr ⟨u,hu,rfl⟩
  · exact centeredModelExtension_fourDifference data n p q hq u
      (fun i => List.mem_toFinset.mp (hu i))

def computedModelInverseTableWordWork (differences : List ℤ) (p : ℕ) : ℕ :=
  arrayInverseTableWordWork (fun _ => 16) p differences

theorem computedModelInverseTableWordWork_bound (differences : List ℤ) (p : ℕ) :
    computedModelInverseTableWordWork differences p≤2*(p+1)+20*differences.length :=
  arrayInverseTableWordWork_bound _ _ _ 16 (fun _ _ => le_rfl)

theorem doubleDifference_card_ambient (S : Finset ℤ) (u : ℕ)
    (hS : ∀ a∈S, 0≤a ∧ a≤u) : ((S+S)-(S+S)).card≤4*u+1 := by
  have hsub : (S+S)-(S+S)⊆Finset.Icc (-(2*(u:ℤ))) (2*u) := by
    intro a ha
    have hh := modelingDifferences_abs_le S 2 u hS a
      (by simpa only [modelingDifferences,two_nsmul] using ha)
    exact Finset.mem_Icc.mpr (abs_le.mp hh)
  have hc := Finset.card_le_card hsub
  rw [Int.card_Icc] at hc
  omega

theorem computedModelInverseTableWordWork_ambient (S : Finset ℤ) (u : ℕ)
    (hS : ∀ a∈S, 0≤a ∧ a≤u) (differences : List ℤ) (hd : differences.Nodup)
    (he : differences.toFinset=(S+S)-(S+S)) (p : ℕ) (hp : p≤256*(u+1)) :
    computedModelInverseTableWordWork differences p≤600*(u+1) := by
  have hl : differences.length≤4*u+1 := by
    rw [←List.toFinset_card_of_nodup hd,he]
    exact doubleDifference_card_ambient S u hS
  have hh := computedModelInverseTableWordWork_bound differences p
  omega

end Optss
