import Optss.ComputedModelingMultiplierWork

/-!
# Computed prime and multiplier parameters from the actual difference list

The list is the distinct materialized representation of 8S-8S. Both primes
and the multiplier are returned by the executable sieves already verified.
No prime or multiplier is supplied as an input witness.
-/
namespace Optss

def computedModelingParameters (data : List ℤ) (u : ℕ) : Option (ℕ×ℕ×ℕ) := do
  let (p,q) ← computedModelingPrimes data.length u
  let n ← computedModelingMultiplier data p q
  pure (p,q,n)

theorem computedModelingParameters_correct (S : Finset ℤ) (u : ℕ) (data : List ℤ)
    (hS : ∀ a∈S, 0≤a ∧ a≤u) (hnodup : data.Nodup)
    (hdata : data.toFinset=modelingDifferences S 8) :
    ∃ p q n : ℕ, computedModelingParameters data u=some (p,q,n) ∧
      p.Prime ∧ q.Prime ∧ 8*(data.length+1)<p ∧ p<16*(data.length+1) ∧
      max (16*u) (2*p)<q ∧ p≤256*(u+1) ∧ q≤modelingPrimeTableLimit u ∧
      0<n ∧ n<q ∧ (n:ZMod q)≠0 ∧
      (∀ e∈modelingDifferences S 8, e≠0 → ∀ t∈Finset.Icc 1 ((q-1)/p),
        (n:ZMod q)*(e:ZMod q)≠(t*p:ℕ)) := by
  have hlen : (modelingDifferences S 8).card=data.length := by
    rw [←hdata,List.toFinset_card_of_nodup hnodup]
  obtain ⟨p,q,hpq,hp,hq,hplo,hphi,hql,hpb,hqb⟩ := computedModelingPrimes_of_interval S u hS
  rw [hlen] at hpq hplo hphi
  letI : Fact q.Prime := ⟨hq⟩
  have hqu : (8:ℤ)*u<q := by
    have h := (le_max_left (16*u) (2*p)).trans_lt hql
    exact_mod_cast (show 8*u<q by omega)
  have hD : ∀ e∈data, |e|<(q:ℤ) := by
    intro e he
    have he' : e∈modelingDifferences S 8 := by
      rw [←hdata]; exact List.mem_toFinset.mpr he
    exact (modelingDifferences_abs_le S 8 u hS e he').trans_lt hqu
  have hcard : (data.toFinset.erase 0).card<p := by
    have hc := (Finset.card_erase_le (s:=data.toFinset) (a:=0)).trans (List.toFinset_card_le data)
    omega
  obtain ⟨n,hn,hpos,hnq,hnot⟩ := computedModelingMultiplier_exists data p q hD hcard
  have hn0 : (n:ZMod q)≠0 := by
    intro hz
    have hv := congrArg ZMod.val hz
    rw [ZMod.val_natCast_of_lt hnq,ZMod.val_zero] at hv
    omega
  refine ⟨p,q,n,?_,hp,hq,hplo,hphi,hql,hpb,hqb,hpos,hnq,hn0,?_⟩
  · change Option.bind (computedModelingPrimes data.length u)
      (fun pq => Option.bind (computedModelingMultiplier data pq.1 pq.2)
        (fun n => some (pq.1,pq.2,n)))=some (p,q,n)
    rw [hpq]
    dsimp only [Option.bind]
    rw [hn]
  · intro e he he0 t ht hbad
    have he' : e∈data.toFinset := by rwa [hdata]
    have heq : (e:ZMod q)≠0 := fun hz =>
      he0 (bounded_intCast_eq_zero (hD e (List.mem_toFinset.mp he')) hz)
    apply hnot
    exact Finset.mem_image.mpr ⟨(e,t),
      Finset.mem_product.mpr ⟨Finset.mem_erase.mpr ⟨he0,he'⟩,ht⟩,
      ((eq_div_iff heq).mpr hbad).symm⟩

/-- The computed multiplier work is uniformly nearlinear in the original
ambient interval; its logarithmic factor comes from actual Boolean inverses. -/
theorem computedModelingMultiplierWork_ambient (S : Finset ℤ) (u : ℕ) (data : List ℤ)
    (hS : ∀ a∈S, 0≤a ∧ a≤u) (hnodup : data.Nodup)
    (hdata : data.toFinset=modelingDifferences S 8) (p q : ℕ) [Fact q.Prime]
    (hp : 8*(data.length+1)<p) (hq : q≤modelingPrimeTableLimit u) :
    (computedModelingMultiplierTrace data p q).2≤
      340*(16*u+1)*((modelingPrimeTableLimit u).size+1)^3+
        28*(modelingPrimeTableLimit u+1)+9 := by
  have hlen : data.length≤16*u+1 := by
    rw [←List.toFinset_card_of_nodup hnodup,hdata]
    exact modelingDifferences_card_ambient S u hS
  exact (computedModelingMultiplierTrace_work data p q (by omega)).trans
    (by gcongr; exact Nat.size_le_size hq)

end Optss
