import Optss.BooleanFourierArithmetic

/-! The fixed-point radix-two answer stored entirely as Boolean lists.
The scalar-work recurrence follows its cached recursive arrays and actual
butterfly operands. Indexing and array allocation are separate costs. -/
namespace Optss
open scoped BigOperators

def bitFourierVectorValue {m : ℕ} (A : Vector BitFourierInteger m) : Vector FourierInteger m :=
  Vector.ofFn fun j => (A.get j).value

def bitFixedPointRadixTwo (D : BitListInteger) (T : ℕ → ℕ → BitFourierInteger) :
    (n : ℕ) → Vector BitFourierInteger (2^n) → Vector BitFourierInteger (2^n)
  | 0,A => A
  | n+1,A =>
    let E := bitFixedPointRadixTwo D T n (radixEvenData n A)
    let O := bitFixedPointRadixTwo D T n (radixOddData n A)
    Vector.ofFn fun k => bitFourierButterfly D (E.get (radixModIndex n k)) (T n k.val)
      (O.get (radixModIndex n k))

theorem bitFourierVectorValue_even (n : ℕ) (A : Vector BitFourierInteger (2^(n+1))) :
    bitFourierVectorValue (radixEvenData n A)=radixEvenData n (bitFourierVectorValue A) := by
  apply Vector.ext
  intro i hi
  change (Vector.ofFn _).get ⟨i,hi⟩=(Vector.ofFn _).get ⟨i,hi⟩
  simp only [vector_get_ofFn,radixEvenData,bitFourierVectorValue]

theorem bitFourierVectorValue_odd (n : ℕ) (A : Vector BitFourierInteger (2^(n+1))) :
    bitFourierVectorValue (radixOddData n A)=radixOddData n (bitFourierVectorValue A) := by
  apply Vector.ext
  intro i hi
  change (Vector.ofFn _).get ⟨i,hi⟩=(Vector.ofFn _).get ⟨i,hi⟩
  simp only [vector_get_ofFn,radixOddData,bitFourierVectorValue]

theorem bitFixedPointRadixTwo_value (D : BitListInteger) (T : ℕ → ℕ → BitFourierInteger)
    (n : ℕ) (A : Vector BitFourierInteger (2^n)) :
    bitFourierVectorValue (bitFixedPointRadixTwo D T n A)=
      fixedPointRadixTwo D.value (fun l k => (T l k).value) n (bitFourierVectorValue A) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    have he := congrArg (fun V => V.get) (ih (radixEvenData n A))
    have ho := congrArg (fun V => V.get) (ih (radixOddData n A))
    rw [bitFourierVectorValue_even] at he
    rw [bitFourierVectorValue_odd] at ho
    apply Vector.ext
    intro i hi
    change (Vector.ofFn _).get ⟨i,hi⟩=(Vector.ofFn _).get ⟨i,hi⟩
    simp only [vector_get_ofFn,bitFixedPointRadixTwo,bitFourierVectorValue,
      fixedPointRadixTwo,bitFourierButterfly_value]
    have he' := congrFun he (radixModIndex n ⟨i,hi⟩)
    have ho' := congrFun ho (radixModIndex n ⟨i,hi⟩)
    simp only [bitFourierVectorValue,vector_get_ofFn] at he' ho'
    rw [he',ho']

theorem bitFixedPointRadixTwo_canonical (D : BitListInteger) (T : ℕ → ℕ → BitFourierInteger)
    (n : ℕ) (A : Vector BitFourierInteger (2^n)) (hA : ∀ j, (A.get j).Canonical)
    (k : Fin (2^n)) : ((bitFixedPointRadixTwo D T n A).get k).Canonical := by
  cases n with
  | zero => exact hA k
  | succ n =>
    simp only [bitFixedPointRadixTwo,vector_get_ofFn]
    exact bitFourierButterfly_canonical _ _ _ _

theorem BitFourierInteger.width_iff_value_bits (z : BitFourierInteger) (hz : z.Canonical) (L : ℕ) :
    z.Width L ↔ z.value.re.natAbs.size≤L ∧ z.value.im.natAbs.size≤L := by
  have hre : z.re.digits.length=z.value.re.natAbs.size := by
    change _=(signedBitsValue z.re.negative z.re.digits).natAbs.size
    rw [signedBitsValue_natAbs]
    exact hz.1.length
  have him : z.im.digits.length=z.value.im.natAbs.size := by
    change _=(signedBitsValue z.im.negative z.im.digits).natAbs.size
    rw [signedBitsValue_natAbs]
    exact hz.2.length
  simp only [BitFourierInteger.Width,hre,him]

theorem BitFourierInteger.width_of_bound (z : BitFourierInteger) (hz : z.Canonical) (B : ℕ)
    (hB : FourierIntegerBound z.value B) : z.Width B.size := by
  apply (z.width_iff_value_bits hz _).mpr
  constructor
  · apply Nat.size_le_size
    have h := hB.1
    rw [← Int.natCast_natAbs] at h
    exact_mod_cast h
  · apply Nat.size_le_size
    have h := hB.2
    rw [← Int.natCast_natAbs] at h
    exact_mod_cast h

theorem bitFixedPointRadixTwo_width (D : BitListInteger) (d B : ℕ) (hD : D.value=(d : ℤ))
    (T : ℕ → ℕ → BitFourierInteger) (n : ℕ) (A : Vector BitFourierInteger (2^n))
    (hAc : ∀ j, (A.get j).Canonical) (hA : ∀ j, FourierIntegerBound (A.get j).value B)
    (hT : ∀ l<n, ∀ k, FourierIntegerBound (T l k).value (2*d)) (k : Fin (2^n)) :
    ((bitFixedPointRadixTwo D T n A).get k).Width (n*(d.size+3)+B.size+1) := by
  apply ((bitFixedPointRadixTwo D T n A).get k).width_iff_value_bits
    (bitFixedPointRadixTwo_canonical D T n A hAc k) _ |>.mpr
  have hvalue := congrArg (fun V => V.get k) (bitFixedPointRadixTwo_value D T n A)
  simp only [bitFourierVectorValue,vector_get_ofFn,hD] at hvalue
  rw [hvalue]
  exact fixedPointRadixTwo_entry_bits d B _ n _
    (fun j => by simpa only [bitFourierVectorValue,vector_get_ofFn] using hA j) hT k

def bitFixedPointRadixTwoWork (D : BitListInteger) (T : ℕ → ℕ → BitFourierInteger) :
    (n : ℕ) → Vector BitFourierInteger (2^n) → ℕ
  | 0,_ => 0
  | n+1,A =>
    let E := bitFixedPointRadixTwo D T n (radixEvenData n A)
    let O := bitFixedPointRadixTwo D T n (radixOddData n A)
    bitFixedPointRadixTwoWork D T n (radixEvenData n A)+
      bitFixedPointRadixTwoWork D T n (radixOddData n A)+
      ∑ k : Fin (2^(n+1)), bitFourierButterflyWork D (E.get (radixModIndex n k))
        (T n k.val) (O.get (radixModIndex n k))

theorem bitFixedPointRadixTwoWork_bound (D : BitListInteger) (d B : ℕ)
    (hD : D.value=(d : ℤ)) (hDc : BitListCanonical D.digits)
    (T : ℕ → ℕ → BitFourierInteger) (n : ℕ) (A : Vector BitFourierInteger (2^n))
    (hAc : ∀ j, (A.get j).Canonical) (hA : ∀ j, FourierIntegerBound (A.get j).value B)
    (hTc : ∀ l<n, ∀ k, (T l k).Canonical)
    (hT : ∀ l<n, ∀ k, FourierIntegerBound (T l k).value (2*d)) :
    bitFixedPointRadixTwoWork D T n A≤
      512*radixTwoButterflyCount n*(n*(d.size+3)+B.size+2)^2 := by
  have hDlen : D.digits.length=d.size := by
    have hh : D.value.natAbs.size=D.digits.length := by
      rw [BitListInteger.value,signedBitsValue_natAbs]
      exact hDc.length.symm
    rw [hD,Int.natAbs_natCast] at hh
    exact hh.symm
  induction n with
  | zero => simp only [bitFixedPointRadixTwoWork,radixTwoButterflyCount,zero_mul,mul_zero,le_refl]
  | succ n ih =>
    let H := (n+1)*(d.size+3)+B.size+1
    have hH : n*(d.size+3)+B.size+1≤H := by dsimp [H]; nlinarith
    have hDH : d.size≤H := by dsimp [H]; nlinarith
    have hTH : d.size+2≤H := by dsimp [H]; nlinarith
    have hAe : ∀ j, (radixEvenData n A |>.get j).Canonical :=
      fun j => by simpa only [radixEvenData,vector_get_ofFn] using hAc (radixEvenIndex n j)
    have hAo : ∀ j, (radixOddData n A |>.get j).Canonical :=
      fun j => by simpa only [radixOddData,vector_get_ofFn] using hAc (radixOddIndex n j)
    have hBe : ∀ j, FourierIntegerBound (radixEvenData n A |>.get j).value B :=
      fun j => by simpa only [radixEvenData,vector_get_ofFn] using hA (radixEvenIndex n j)
    have hBo : ∀ j, FourierIntegerBound (radixOddData n A |>.get j).value B :=
      fun j => by simpa only [radixOddData,vector_get_ofFn] using hA (radixOddIndex n j)
    have hTn := fun l (hl : l<n) k => hT l (by omega) k
    have hTcn := fun l (hl : l<n) k => hTc l (by omega) k
    have he := ih (radixEvenData n A) hAe hBe hTcn hTn
    have ho := ih (radixOddData n A) hAo hBo hTcn hTn
    have hwidth : n*(d.size+3)+B.size+2≤H+1 := by omega
    have he' : bitFixedPointRadixTwoWork D T n (radixEvenData n A)≤512*radixTwoButterflyCount n*(H+1)^2 :=
      he.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hwidth 2))
    have ho' : bitFixedPointRadixTwoWork D T n (radixOddData n A)≤512*radixTwoButterflyCount n*(H+1)^2 :=
      ho.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hwidth 2))
    have hs : (∑ k : Fin (2^(n+1)), bitFourierButterflyWork D
        ((bitFixedPointRadixTwo D T n (radixEvenData n A)).get (radixModIndex n k))
        (T n k.val) ((bitFixedPointRadixTwo D T n (radixOddData n A)).get (radixModIndex n k)))≤
        (2^(n+1))* (512*(H+1)^2) := by
      calc
        _ ≤ ∑ _k : Fin (2^(n+1)), 512*(H+1)^2 := by
          apply Finset.sum_le_sum
          intro k _
          have hew := bitFixedPointRadixTwo_width D d B hD T n (radixEvenData n A) hAe hBe hTn (radixModIndex n k)
          have how := bitFixedPointRadixTwo_width D d B hD T n (radixOddData n A) hAo hBo hTn (radixModIndex n k)
          have htw := (T n k.val).width_of_bound (hTc n (by omega) k.val) (2*d) (hT n (by omega) k.val)
          have htwo : (2*d).size≤d.size+2 := by
            have h := nat_mul_size_le 2 d
            have hh : (2 : ℕ).size≤2 := Nat.size_le.mpr (by decide)
            omega
          exact bitFourierButterflyWork_bound D _ _ _ H (hDlen.le.trans hDH)
            ⟨hew.1.trans hH,hew.2.trans hH⟩
            ⟨htw.1.trans (htwo.trans hTH),htw.2.trans (htwo.trans hTH)⟩
            ⟨how.1.trans hH,how.2.trans hH⟩
        _ = _ := by simp
    change _≤512*radixTwoButterflyCount (n+1)*(H+1)^2
    dsimp only [bitFixedPointRadixTwoWork]
    calc
      _ ≤ 512*radixTwoButterflyCount n*(H+1)^2+
          512*radixTwoButterflyCount n*(H+1)^2+(2^(n+1))*(512*(H+1)^2) := add_le_add (add_le_add he' ho') hs
      _ = _ := by rw [radixTwoButterflyCount]; ring

end Optss
