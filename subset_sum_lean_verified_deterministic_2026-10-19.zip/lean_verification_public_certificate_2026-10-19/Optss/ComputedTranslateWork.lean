import Optss.ComputedTranslateCover

/-!
# Exact conflict-query accounting for the greedy translate scan

The conflict query counter follows the actual early-stopping `any` predicate.
Packing bounds the selected list at every recursive stage, so the total work
is linear in input length times the final number of selected translations.
-/
namespace Optss
open scoped Pointwise

def translateConflictQueries (conflict : ℤ→Bool) (x : ℤ) : List ℤ→ℕ
  | [] => 0
  | y::ys => if conflict (x-y) then 1 else translateConflictQueries conflict x ys+1

theorem translateConflictQueries_le (conflict : ℤ→Bool) (x : ℤ) (ys : List ℤ) :
    translateConflictQueries conflict x ys≤ys.length := by
  induction ys with
  | nil => rfl
  | cons y ys ih => simp only [translateConflictQueries,List.length_cons]; split <;> omega

def greedyTranslateWork (conflict : ℤ→Bool) : List ℤ→ℕ
  | [] => 1
  | x::xs => greedyTranslateWork conflict xs+
    translateConflictQueries conflict x (greedyTranslateList conflict xs)+3

theorem greedyTranslateList_tail_length_le (conflict : ℤ→Bool) (x : ℤ) (xs : List ℤ) :
    (greedyTranslateList conflict xs).length≤(greedyTranslateList conflict (x::xs)).length := by
  simp only [greedyTranslateList]
  split <;> simp

theorem greedyTranslateWork_bound (conflict : ℤ→Bool) (xs : List ℤ) :
    greedyTranslateWork conflict xs≤((greedyTranslateList conflict xs).length+3)*xs.length+1 := by
  induction xs with
  | nil => simp [greedyTranslateWork]
  | cons x xs ih =>
    have hq := translateConflictQueries_le conflict x (greedyTranslateList conflict xs)
    have hl := greedyTranslateList_tail_length_le conflict x xs
    have hm := Nat.mul_le_mul_right xs.length (Nat.add_le_add_right hl 3)
    simp only [greedyTranslateWork,List.length_cons]
    nlinarith only [ih,hq,hl,hm]

theorem greedyTranslateList_card_bound (P : Finset ℤ) (hP : P.Nonempty) (conflict : ℤ→Bool)
    (hc : ∀ z, conflict z=true ↔ z∈P-P) (xs : List ℤ) (K : ℕ)
    (hK : (xs.toFinset+P).card≤K*P.card) :
    (greedyTranslateList conflict xs).length≤K := by
  have hh := (greedyTranslateList_packing P hP conflict hc xs).trans hK
  have hp := Finset.card_pos.mpr hP
  nlinarith

/-- Once a stored conflict query has constant word cost, this is the claimed
constant-number-of-translates linear scan. -/
theorem greedyTranslateWork_constant (P : Finset ℤ) (hP : P.Nonempty) (conflict : ℤ→Bool)
    (hc : ∀ z, conflict z=true ↔ z∈P-P) (xs : List ℤ) (K : ℕ)
    (hK : (xs.toFinset+P).card≤K*P.card) :
    greedyTranslateWork conflict xs≤(K+3)*xs.length+1 := by
  exact (greedyTranslateWork_bound conflict xs).trans (by
    gcongr
    exact greedyTranslateList_card_bound P hP conflict hc xs K hK)

end Optss
