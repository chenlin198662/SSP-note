import Optss.ExecutableLatticeReduction
import Optss.LatticePotentialBounds
import Mathlib.Data.Vector.Basic
import Mathlib.Tactic.IrreducibleDef

/-!
# Materialized rational arithmetic for lattice reduction

The first executable implementation repeatedly expands recursive Gram-Schmidt
expressions and permutation determinants. This module replaces them with
array-backed tables and direct rational Lovász tests. Vector cells contain
computed rationals, rather than closures that recursively recompute earlier
rows. Integer updates are materialized as well. Arithmetic-operation and bit
cost claims require separate accounting.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

private theorem arrayVector_get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

private theorem arrayVector_get_set {α : Type*} {n : ℕ} (v : Vector α n)
    (k i : Fin n) (a : α) :
    (v.set k.val a k.isLt).get i = if i = k then a else v.get i := by
  change (v.set k.val a k.isLt)[i.val] = _
  rw [Vector.getElem_set]
  split <;> rename_i h
  · have he : i = k := Fin.ext h.symm
    simp [he]
  · have he : i ≠ k := fun he => h (congrArg Fin.val he.symm)
    simp [he]
    rfl

/-- A materialized rational row. -/
abbrev RationalRow (d : ℕ) := Vector ℚ d

/-- A materialized table of orthogonalized rational rows. -/
abbrev RationalGSTable (r d : ℕ) := Vector (RationalRow d) r

/-- Compute one row from an already filled table. Projection coefficients are
materialized first so each dot product is computed only once. -/
def cachedGSRow (A : Matrix (Fin r) (Fin d) ℚ) (T : RationalGSTable r d)
    (k : Fin r) : RationalRow d :=
  let coeff : Vector ℚ r := Vector.ofFn fun i =>
    if i < k then rationalDot (T.get i).get (A k) /
      rationalDot (T.get i).get (T.get i).get else 0
  Vector.ofFn fun l => A k l - ∑ i : Finset.Iio k, coeff.get i * (T.get i).get l

/-- Fill the table from left to right. The recursive call computes the entire
previous table once, and all stored rows are actual arrays of rationals. -/
def cachedGSTable (A : Matrix (Fin r) (Fin d) ℚ) (n : ℕ) (hn : n ≤ r) :
    RationalGSTable r d :=
  match n with
  | 0 => Vector.replicate r (Vector.replicate d 0)
  | n+1 =>
    let T := cachedGSTable A n (by omega)
    let k : Fin r := ⟨n, by omega⟩
    T.set n (cachedGSRow A T k) (by omega)
termination_by n

theorem cachedGSRow_correct (A : Matrix (Fin r) (Fin d) ℚ)
    (T : RationalGSTable r d) (k : Fin r)
    (hT : ∀ i : Fin r, i < k → (T.get i).get = rationalGramSchmidt A i) :
    (cachedGSRow A T k).get = rationalGramSchmidt A k := by
  funext l
  rw [rationalGramSchmidt]
  simp only [cachedGSRow, arrayVector_get_ofFn, Pi.sub_apply,
    Finset.sum_apply, Pi.smul_apply, smul_eq_mul]
  congr 1
  apply Finset.sum_congr rfl
  intro i _
  have hi : (i:Fin r) < k := Finset.mem_Iio.mp i.2
  have he := hT i hi
  simp only [hi, ↓reduceIte]
  change rationalDot (T.get i).get (A k) / rationalDot (T.get i).get (T.get i).get *
      (T.get i).get l = _
  rw [he]

theorem cachedGSTable_correct (A : Matrix (Fin r) (Fin d) ℚ)
    (n : ℕ) (hn : n ≤ r) (i : Fin r) (hi : i.val < n) :
    ((cachedGSTable A n hn).get i).get = rationalGramSchmidt A i := by
  induction n generalizing i with
  | zero => omega
  | succ n ih =>
    rw [cachedGSTable]
    by_cases hin : i.val = n
    · have he : i = (⟨n, by omega⟩ : Fin r) := Fin.ext hin
      rw [he]
      rw [arrayVector_get_set _ ⟨n, by omega⟩]
      simp only [↓reduceIte]
      apply cachedGSRow_correct
      intro j hj
      exact ih (by omega) j hj
    · rw [arrayVector_get_set _ ⟨n, by omega⟩]
      simp only [show i ≠ (⟨n, by omega⟩ : Fin r) from fun he => hin (congrArg Fin.val he), ↓reduceIte]
      exact ih (by omega) i (by omega)

/-- The complete cached table agrees with the original exact rational
recurrence in every cell, including on dependent inputs. -/
theorem cachedGSTable_full_correct (A : Matrix (Fin r) (Fin d) ℚ) (i : Fin r) :
    ((cachedGSTable A r le_rfl).get i).get = rationalGramSchmidt A i :=
  cachedGSTable_correct A r le_rfl i i.isLt

/-- One coefficient computed from a materialized table. -/
def cachedGsCoefficient (A : Matrix (Fin r) (Fin d) ℚ)
    (T : RationalGSTable r d) (k j : Fin r) : ℚ :=
  rationalDot (T.get j).get (A k) / rationalDot (T.get j).get (T.get j).get

theorem cachedGsCoefficient_correct (A : Matrix (Fin r) (Fin d) ℚ) (k j : Fin r) :
    cachedGsCoefficient A (cachedGSTable A r le_rfl) k j = rationalGsCoefficient A k j := by
  simp only [cachedGsCoefficient, cachedGSTable_full_correct, rationalGsCoefficient]

/-- Extensional matrix wrapper used in the semantic reference procedure.
The executed implementation below returns `IntegerMatrixData` instead. -/
def cacheIntegerMatrix (A : Matrix (Fin r) (Fin d) ℤ) : Matrix (Fin r) (Fin d) ℤ :=
  let data : Vector (Vector ℤ d) r := Vector.ofFn fun i => Vector.ofFn (A i)
  fun i j => (data.get i).get j

theorem cacheIntegerMatrix_eq (A : Matrix (Fin r) (Fin d) ℤ) : cacheIntegerMatrix A = A := by
  funext i j
  simp only [cacheIntegerMatrix, arrayVector_get_ofFn]

/-- Functional reference sweep with cached rational Gram-Schmidt. The
array-valued implementation below is used for execution. -/
def cachedReduceIntegerRow (A : Matrix (Fin r) (Fin d) ℤ)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) : Matrix (Fin r) (Fin d) ℤ :=
  match n with
  | 0 => A
  | n+1 =>
    let j : Fin r := ⟨n, by omega⟩
    let Q := rationalIntegerRows A
    let T := cachedGSTable Q r le_rfl
    let q : ℤ := round (cachedGsCoefficient Q T k j)
    cachedReduceIntegerRow (cacheIntegerMatrix (Function.update A k (A k - q • A j))) k n (by omega)
termination_by n

theorem cachedReduceIntegerRow_eq (A : Matrix (Fin r) (Fin d) ℤ)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) :
    cachedReduceIntegerRow A k n h = rationalReduceIntegerRow A k n h := by
  induction n generalizing A with
  | zero => rw [cachedReduceIntegerRow, rationalReduceIntegerRow]
  | succ n ih =>
    rw [cachedReduceIntegerRow, rationalReduceIntegerRow, ih,
      cachedGsCoefficient_correct, cacheIntegerMatrix_eq]

/-- The complete cached size sweep. Initial entries are materialized once. -/
def cachedReduceIntegerAll (A : Matrix (Fin r) (Fin d) ℤ)
    (n : ℕ) (h : n ≤ r) : Matrix (Fin r) (Fin d) ℤ :=
  match n with
  | 0 => cacheIntegerMatrix A
  | n+1 =>
    let C := cachedReduceIntegerAll A n (by omega)
    cachedReduceIntegerRow C ⟨n, by omega⟩ n le_rfl
termination_by n

theorem cachedReduceIntegerAll_eq (A : Matrix (Fin r) (Fin d) ℤ)
    (n : ℕ) (h : n ≤ r) :
    cachedReduceIntegerAll A n h = rationalReduceIntegerAll A n h := by
  induction n with
  | zero => rw [cachedReduceIntegerAll, rationalReduceIntegerAll, cacheIntegerMatrix_eq]
  | succ n ih =>
    rw [cachedReduceIntegerAll, rationalReduceIntegerAll, cachedReduceIntegerRow_eq, ih]

theorem cachedReduceIntegerAll_full_eq (A : Matrix (Fin r) (Fin d) ℤ) :
    cachedReduceIntegerAll A r le_rfl = executableSizeSweep A := by
  rw [cachedReduceIntegerAll_eq]
  unfold executableSizeSweep
  rfl

/-- Direct rational Lovász test using one cached Gram-Schmidt table. -/
def cachedFailingAdjacentPairs (A : Matrix (Fin r) (Fin d) ℤ) : Finset (Fin r × Fin r) :=
  let Q := rationalIntegerRows A
  let T := cachedGSTable Q r le_rfl
  Finset.univ.filter fun p => p.2.val = p.1.val+1 ∧
    4*(rationalDot (T.get p.2).get (T.get p.2).get +
      (cachedGsCoefficient Q T p.2 p.1)^2*rationalDot (T.get p.1).get (T.get p.1).get) <
      3*rationalDot (T.get p.1).get (T.get p.1).get


/-- The cached rational comparison is exactly the determinant comparison on
independent integer rows. Determinants occur only in this specification. -/
theorem cachedFailingAdjacentPairs_eq (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) :
    cachedFailingAdjacentPairs A = failingAdjacentPairs A := by
  ext p
  simp only [cachedFailingAdjacentPairs, Finset.mem_filter, Finset.mem_univ, true_and,
    cachedGSTable_full_correct, cachedGsCoefficient_correct, mem_failingAdjacentPairs]
  apply and_congr_right
  intro hadj
  have hd : (0:ℝ) < (prefixGramDet A ⟨p.1.val, by omega⟩:ℝ) := by
    exact_mod_cast prefixGramDet_pos A hA ⟨p.1.val, by omega⟩
  have hsucc := prefixGramDet_succ_eq A p.1
  have hindex : (⟨p.1.val+1, by omega⟩ : Fin (r+1)) = ⟨p.2.val, by omega⟩ := Fin.ext hadj.symm
  rw [hindex] at hsucc
  have hswap := prefixGramDet_swap_adjacent_eq A p.1 p.2 hadj
  have hreal :
      (4:ℝ)*(‖gramSchmidt ℝ (euclideanIntegerRows A) p.2‖^2 +
        (gsCoefficient (euclideanIntegerRows A) p.2 p.1)^2*
          ‖gramSchmidt ℝ (euclideanIntegerRows A) p.1‖^2) <
        3*‖gramSchmidt ℝ (euclideanIntegerRows A) p.1‖^2 ↔
      (4:ℝ)*(prefixGramDet (swapRows A p.1 p.2) ⟨p.2.val, by omega⟩:ℝ) <
        3*(prefixGramDet A ⟨p.2.val, by omega⟩:ℝ) := by
    rw [hsucc, hswap]
    constructor
    · intro h
      have hm := mul_lt_mul_of_pos_left h hd
      nlinarith only [hm]
    · intro h
      apply (mul_lt_mul_left hd).mp
      nlinarith only [h]
  have hcast : ∀ i : Fin r,
      (rationalDot (rationalGramSchmidt (rationalIntegerRows A) i)
        (rationalGramSchmidt (rationalIntegerRows A) i):ℝ) =
      ‖gramSchmidt ℝ (euclideanIntegerRows A) i‖^2 := by
    intro i
    rw [rationalDot_self_cast, rationalGramSchmidt_cast, rationalEuclideanRows_integer]
  constructor
  · intro h
    have h' : (4:ℝ)*((rationalDot (rationalGramSchmidt (rationalIntegerRows A) p.2)
          (rationalGramSchmidt (rationalIntegerRows A) p.2):ℝ) +
        (rationalGsCoefficient (rationalIntegerRows A) p.2 p.1:ℝ)^2*
          (rationalDot (rationalGramSchmidt (rationalIntegerRows A) p.1)
            (rationalGramSchmidt (rationalIntegerRows A) p.1):ℝ)) <
        3*(rationalDot (rationalGramSchmidt (rationalIntegerRows A) p.1)
          (rationalGramSchmidt (rationalIntegerRows A) p.1):ℝ) := by exact_mod_cast h
    rw [hcast, hcast, rationalGsCoefficient_cast, rationalEuclideanRows_integer] at h'
    exact_mod_cast hreal.mp h'
  · intro h
    have h' : (4:ℝ)*(prefixGramDet (swapRows A p.1 p.2) ⟨p.2.val, by omega⟩:ℝ) <
        3*(prefixGramDet A ⟨p.2.val, by omega⟩:ℝ) := by exact_mod_cast h
    have hc := hreal.mpr h'
    rw [← rationalEuclideanRows_integer A, ← rationalGsCoefficient_cast] at hc
    rw [rationalEuclideanRows_integer A, ← hcast p.1, ← hcast p.2] at hc
    exact_mod_cast hc


/-- The same deterministic lexicographic policy, applied to the cached test. -/
@[irreducible] def cachedLeastFailingAdjacentPair (A : Matrix (Fin r) (Fin d) ℤ)
    (h : (cachedFailingAdjacentPairs A).Nonempty) : Fin r × Fin r := by
  letI : LinearOrder (Fin r × Fin r) :=
    LinearOrder.lift' (toLex : Fin r × Fin r → Fin r ×ₗ Fin r)
      (fun _ _ h => toLex_inj.mp h)
  exact (cachedFailingAdjacentPairs A).min' h

theorem cachedLeastFailingAdjacentPair_eq (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (h : (cachedFailingAdjacentPairs A).Nonempty) :
    cachedLeastFailingAdjacentPair A h = leastFailingAdjacentPair A
      ((cachedFailingAdjacentPairs_eq A hA) ▸ h) := by
  simp only [cachedLeastFailingAdjacentPair, leastFailingAdjacentPair,
    cachedFailingAdjacentPairs_eq A hA]

/-- Functional reference loop for exact correspondence proofs. Execution
uses the array-valued `materializedReductionFuel` below. -/
def cachedReductionFuel : ℕ → Matrix (Fin r) (Fin d) ℤ →
    Matrix (Fin r) (Fin d) ℤ × ℕ
  | 0, A => (A, 0)
  | n+1, A =>
    let C := cachedReduceIntegerAll A r le_rfl
    if hfail : (cachedFailingAdjacentPairs C).Nonempty then
      let p := cachedLeastFailingAdjacentPair C hfail
      let out := cachedReductionFuel n (cacheIntegerMatrix (swapRows C p.1 p.2))
      (out.1, out.2+1)
    else (C, 0)

/-- Caching preserves the exact deterministic matrix and swap count for every
fuel value, not just eventual lattice equivalence. -/
theorem cachedReductionFuel_eq (fuel : ℕ) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) :
    cachedReductionFuel fuel A = executableReductionFuel fuel A := by
  induction fuel generalizing A with
  | zero => rfl
  | succ n ih =>
    rw [cachedReductionFuel, executableReductionFuel, cachedReduceIntegerAll_full_eq]
    let C := executableSizeSweep A
    have hC := (executableSizeSweep_spec A hA).1
    have htests := cachedFailingAdjacentPairs_eq C hC
    split_ifs with hc ho ho
    · have hp : cachedLeastFailingAdjacentPair (executableSizeSweep A) hc =
          leastFailingAdjacentPair (executableSizeSweep A) ho :=
        cachedLeastFailingAdjacentPair_eq C hC hc
      simp only [hp, cacheIntegerMatrix_eq]
      exact congrArg (fun out : Matrix (Fin r) (Fin d) ℤ × ℕ => (out.1, out.2+1))
        (ih _ (hC.comp (Equiv.swap _ _) (Equiv.swap _ _).injective))
    · exact False.elim (ho (htests ▸ hc))
    · exact False.elim (hc (htests.symm ▸ ho))
    · rfl

/-- Actual input height found by a finite maximum over integer entries. -/
def integerMatrixHeight (A : Matrix (Fin r) (Fin d) ℤ) : ℕ :=
  Finset.univ.sup fun p : Fin r × Fin d => (A p.1 p.2).natAbs

theorem integerMatrixHeight_bound (A : Matrix (Fin r) (Fin d) ℤ) (i : Fin r) (j : Fin d) :
    |A i j| ≤ (integerMatrixHeight A:ℤ) := by
  rw [← Int.natCast_natAbs]
  exact Int.ofNat_le.mpr (Finset.le_sup (f := fun p : Fin r × Fin d => (A p.1 p.2).natAbs)
    (Finset.mem_univ (i,j)))

/-- Computable initial fuel uses the explicit height bound, avoiding any
integer Gram-determinant evaluation in the executed algorithm. -/
def cachedReductionInitialFuel (A : Matrix (Fin r) (Fin d) ℤ) : ℕ :=
  (latticeInputGramBound r d (integerMatrixHeight A))^(r+1)

theorem gramPotential_le_cachedReductionInitialFuel (A : Matrix (Fin r) (Fin d) ℤ) :
    gramPotential A ≤ cachedReductionInitialFuel A :=
  gramPotential_height_bound A (integerMatrixHeight A) (integerMatrixHeight_bound A)

/-- Integer state stored as arrays, so evaluating a matrix entry cannot rerun
the reduction that produced the matrix. -/
abbrev IntegerMatrixData (r d : ℕ) := Vector (Vector ℤ d) r

def materializeIntegerMatrix (A : Matrix (Fin r) (Fin d) ℤ) : IntegerMatrixData r d :=
  Vector.ofFn fun i => Vector.ofFn (A i)

def integerMatrixDataRows (D : IntegerMatrixData r d) : Matrix (Fin r) (Fin d) ℤ :=
  fun i j => (D.get i).get j

theorem integerMatrixDataRows_materialize (A : Matrix (Fin r) (Fin d) ℤ) :
    integerMatrixDataRows (materializeIntegerMatrix A) = A := by
  funext i j
  simp only [integerMatrixDataRows, materializeIntegerMatrix, arrayVector_get_ofFn]

/-- Array-valued descending sweep. Returning data, rather than a function,
prevents compiler eta expansion from delaying materialization until lookup. -/
def materializedReduceIntegerRow (D : IntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) : IntegerMatrixData r d :=
  match n with
  | 0 => D
  | n+1 =>
    let j : Fin r := ⟨n, by omega⟩
    let A := integerMatrixDataRows D
    let Q := rationalIntegerRows A
    let T := cachedGSTable Q r le_rfl
    let q : ℤ := round (cachedGsCoefficient Q T k j)
    let W := materializeIntegerMatrix (Function.update A k (A k - q • A j))
    materializedReduceIntegerRow W k n (by omega)
termination_by n

theorem materializedReduceIntegerRow_eq (D : IntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) :
    integerMatrixDataRows (materializedReduceIntegerRow D k n h) =
      cachedReduceIntegerRow (integerMatrixDataRows D) k n h := by
  induction n generalizing D with
  | zero => rw [materializedReduceIntegerRow, cachedReduceIntegerRow]
  | succ n ih =>
    rw [materializedReduceIntegerRow, cachedReduceIntegerRow, ih,
      integerMatrixDataRows_materialize, cacheIntegerMatrix_eq]

def materializedReduceIntegerAll (D : IntegerMatrixData r d)
    (n : ℕ) (h : n ≤ r) : IntegerMatrixData r d :=
  match n with
  | 0 => D
  | n+1 =>
    let C := materializedReduceIntegerAll D n (by omega)
    materializedReduceIntegerRow C ⟨n, by omega⟩ n le_rfl
termination_by n

theorem materializedReduceIntegerAll_eq (D : IntegerMatrixData r d)
    (n : ℕ) (h : n ≤ r) :
    integerMatrixDataRows (materializedReduceIntegerAll D n h) =
      cachedReduceIntegerAll (integerMatrixDataRows D) n h := by
  induction n with
  | zero => rw [materializedReduceIntegerAll, cachedReduceIntegerAll, cacheIntegerMatrix_eq]
  | succ n ih =>
    rw [materializedReduceIntegerAll, cachedReduceIntegerAll, materializedReduceIntegerRow_eq, ih]

/-- The actual cached loop stores and returns integer arrays. The matrix view
is used only to read cells in exact rational calculations. -/
def materializedReductionFuel : ℕ → IntegerMatrixData r d → IntegerMatrixData r d × ℕ
  | 0, D => (D, 0)
  | n+1, D =>
    let C := materializedReduceIntegerAll D r le_rfl
    let A := integerMatrixDataRows C
    if hfail : (cachedFailingAdjacentPairs A).Nonempty then
      let p := cachedLeastFailingAdjacentPair A hfail
      let out := materializedReductionFuel n (materializeIntegerMatrix (swapRows A p.1 p.2))
      (out.1, out.2+1)
    else (C, 0)

theorem materializedReductionFuel_eq (fuel : ℕ) (D : IntegerMatrixData r d) :
    (integerMatrixDataRows (materializedReductionFuel fuel D).1,
      (materializedReductionFuel fuel D).2) = cachedReductionFuel fuel (integerMatrixDataRows D) := by
  induction fuel generalizing D with
  | zero => rfl
  | succ n ih =>
    rw [materializedReductionFuel, cachedReductionFuel]
    rw [← materializedReduceIntegerAll_eq]
    split_ifs with h
    · simp only [Prod.fst, Prod.snd, cacheIntegerMatrix_eq]
      have he := ih (materializeIntegerMatrix (swapRows
        (integerMatrixDataRows (materializedReduceIntegerAll D r le_rfl))
        (cachedLeastFailingAdjacentPair _ h).1 (cachedLeastFailingAdjacentPair _ h).2))
      rw [integerMatrixDataRows_materialize] at he
      exact congrArg (fun out : Matrix (Fin r) (Fin d) ℤ × ℕ => (out.1, out.2+1)) he
    · rfl

theorem materializedReductionFuel_spec (fuel : ℕ) (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ)))
    (hfuel : gramPotential (integerMatrixDataRows D) ≤ fuel) :
    IntegerReductionSpecification (integerMatrixDataRows D)
      (integerMatrixDataRows (materializedReductionFuel fuel D).1)
      (materializedReductionFuel fuel D).2 := by
  have he := materializedReductionFuel_eq fuel D
  rw [cachedReductionFuel_eq _ _ hD] at he
  have h := executableReductionFuel_spec fuel (integerMatrixDataRows D) hD hfuel
  rw [← he] at h
  exact h

/-- Seal the completed data computation so proof checking does not unfold
large fuel expressions; the opaque wrapper preserves executable code. -/
irreducible_def cachedReductionData (A : Matrix (Fin r) (Fin d) ℤ) : IntegerMatrixData r d × ℕ :=
  materializedReductionFuel (cachedReductionInitialFuel A) (materializeIntegerMatrix A)

theorem cachedIntegerReduction_spec (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) :
    IntegerReductionSpecification A (integerMatrixDataRows (cachedReductionData A).1)
      (cachedReductionData A).2 := by
  have hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows (materializeIntegerMatrix A) i j:ℝ)) := by
    rw [integerMatrixDataRows_materialize]
    exact hA
  have hfuel : gramPotential (integerMatrixDataRows (materializeIntegerMatrix A)) ≤
      cachedReductionInitialFuel A := by
    rw [integerMatrixDataRows_materialize]
    exact gramPotential_le_cachedReductionInitialFuel A
  have h := materializedReductionFuel_spec (cachedReductionInitialFuel A)
    (materializeIntegerMatrix A) hD hfuel
  rw [integerMatrixDataRows_materialize] at h
  simpa only [cachedReductionData_def] using h

/-- The materialized, determinant-free executable implementation, returning
all the previously verified lattice-reduction guarantees. -/
def cachedIntegerReduction (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) : IntegerLLLResult A :=
  let out := cachedReductionData A
  let h := cachedIntegerReduction_spec A hA
  { rows := integerMatrixDataRows out.1
    swapCount := out.2
    independent := h.1
    sameLattice := h.2.1
    sizeReduced := h.2.2.1
    lovasz := h.2.2.2.1
    contraction := h.2.2.2.2 }

end Optss
