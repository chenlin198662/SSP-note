import Optss.BitListExtendedGcd
import Optss.BitListRationalOrderRound

/-!
# Coefficient sizes and work of the Boolean extended Euclidean algorithm

Each pair of Euclidean steps adds at most `2*(L+1)` bits to any coefficient.
There are at most `L` pairs. The actual Boolean division and signed row-cell
charges therefore give a polynomial bound without a sharp Bézout estimate.
The model counts scalar bit gates and list visits plus constant local control;
encoding and external storage remain separately accounted operations.
-/
namespace Optss

theorem bitListXgcdFuel_lengths (fuel as bs : List Bool)
    (s t s' t' : BitListInteger) (ha : BitListCanonical as) (hb : BitListCanonical bs)
    (L C : ℕ) (hal : as.length≤L) (hbl : bs.length≤L)
    (hs : s.digits.length≤C) (ht : t.digits.length≤C)
    (hs' : s'.digits.length≤C) (ht' : t'.digits.length≤C) :
    (bitListXgcdFuel fuel as s t bs s' t').left.digits.length≤C+2*fuel.length*(L+1) ∧
    (bitListXgcdFuel fuel as s t bs s' t').right.digits.length≤C+2*fuel.length*(L+1) := by
  induction fuel generalizing as bs s t s' t' C with
  | nil => simpa only [bitListXgcdFuel,List.length_nil,mul_zero,zero_mul,add_zero] using And.intro hs' ht'
  | cons b fuel ih =>
    rw [bitListXgcdFuel]
    dsimp only
    split_ifs with haz hrz
    · constructor <;> simp only [List.length_cons] <;> omega
    · constructor <;> simp only [List.length_cons] <;> omega
    · let rs := (bitListDivision bs as).remainder
      let ss := (bitListDivision as rs).remainder
      let q := bitListNonnegativeInteger (bitListDivision bs as).quotient
      let p := bitListNonnegativeInteger (bitListDivision as rs).quotient
      let u := bitListIntegerRowCell s' q s
      let v := bitListIntegerRowCell t' q t
      have hap := ha.pos_of_not_empty haz
      have hrc := bitListDivision_remainder_canonical bs as hap
      have hrp : 0<binaryDigitsValue rs := hrc.pos_of_not_empty hrz
      have hsc := bitListDivision_remainder_canonical as rs hrp
      have hrl : rs.length≤L := (bitListDivisionDigits_remainder_width bs as hap).trans hal
      have hsl : ss.length≤L := (bitListDivisionDigits_remainder_width as rs hrp).trans hrl
      have hq : q.digits.length≤L := (bitListDivision_quotient_length_le bs as).trans hbl
      have hp : p.digits.length≤L := (bitListDivision_quotient_length_le as rs).trans hal
      have hu : u.digits.length≤C+(L+1) := by
        have h := bitListIntegerRowCell_length s' q s
        exact h.trans (by omega)
      have hv : v.digits.length≤C+(L+1) := by
        have h := bitListIntegerRowCell_length t' q t
        exact h.trans (by omega)
      have hsu : (bitListIntegerRowCell s p u).digits.length≤C+2*(L+1) := by
        have h := bitListIntegerRowCell_length s p u
        exact h.trans (by omega)
      have htv : (bitListIntegerRowCell t p v).digits.length≤C+2*(L+1) := by
        have h := bitListIntegerRowCell_length t p v
        exact h.trans (by omega)
      have hi := ih ss rs _ _ u v hsc hrc (C+2*(L+1)) hsl hrl hsu htv
        (by omega) (by omega)
      have he : C+2*(L+1)+2*fuel.length*(L+1)=C+2*(b::fuel).length*(L+1) := by
        simp only [List.length_cons]
        ring
      exact he ▸ hi

theorem bitListNatXgcd_lengths (xs ys : List Bool) (L : ℕ)
    (hx : xs.length≤L) (hy : ys.length≤L) :
    (bitListNatXgcd xs ys).left.digits.length≤1+2*L*(L+1) ∧
    (bitListNatXgcd xs ys).right.digits.length≤1+2*L*(L+1) := by
  have hxt := (bitListTrim_length_le xs).trans hx
  have hyt := (bitListTrim_length_le ys).trans hy
  have h := bitListXgcdFuel_lengths (bitListTrim xs) (bitListTrim xs) (bitListTrim ys)
    (bitListNonnegativeInteger [true]) (bitListNonnegativeInteger [])
    (bitListNonnegativeInteger []) (bitListNonnegativeInteger [true])
    (bitListTrim_canonical _) (bitListTrim_canonical _) L 1 hxt hyt (by decide) (by decide) (by decide) (by decide)
  have hm : 1+2*(bitListTrim xs).length*(L+1)≤1+2*L*(L+1) := by gcongr
  exact ⟨h.1.trans hm,h.2.trans hm⟩

def bitListXgcdFuelWork : List Bool → List Bool → BitListInteger → BitListInteger →
    List Bool → BitListInteger → BitListInteger → ℕ
  | [],_,_,_,_,_,_ => 1
  | _::fuel,as,s,t,bs,s',t' =>
    if as.isEmpty then 2 else
      let first := bitListDivision bs as
      if first.remainder.isEmpty then 3+bitListDivisionCost bs as else
        let q := bitListNonnegativeInteger first.quotient
        let u := bitListIntegerRowCell s' q s
        let v := bitListIntegerRowCell t' q t
        let second := bitListDivision as first.remainder
        let p := bitListNonnegativeInteger second.quotient
        12+bitListDivisionCost bs as+bitListIntegerRowCellCost s' q s+
          bitListIntegerRowCellCost t' q t+bitListDivisionCost as first.remainder+
          bitListIntegerRowCellCost s p u+bitListIntegerRowCellCost t p v+
          bitListXgcdFuelWork fuel second.remainder
            (bitListIntegerRowCell s p u) (bitListIntegerRowCell t p v) first.remainder u v

/-- A fixed envelope for all operands on a fuel suffix avoids repeatedly
expanding a height recurrence. The accumulated bit growth is linear in the
remaining number of paired steps. -/
theorem bitListXgcdFuelWork_bound (fuel as bs : List Bool)
    (s t s' t' : BitListInteger) (ha : BitListCanonical as) (hb : BitListCanonical bs)
    (L C W : ℕ) (hal : as.length≤L) (hbl : bs.length≤L)
    (hs : s.digits.length≤C) (ht : t.digits.length≤C)
    (hs' : s'.digits.length≤C) (ht' : t'.digits.length≤C)
    (hL : L≤W) (hW : C+2*fuel.length*(L+1)≤W) :
    bitListXgcdFuelWork fuel as s t bs s' t'≤1+574*fuel.length*(W+1)^2 := by
  induction fuel generalizing as bs s t s' t' C with
  | nil => simp [bitListXgcdFuelWork]
  | cons b fuel ih =>
    rw [bitListXgcdFuelWork]
    dsimp only
    split_ifs with haz hrz
    · simp only [List.length_cons]
      nlinarith [show 1≤(W+1)^2 from Nat.one_le_pow _ _ (Nat.succ_le_succ (Nat.zero_le W))]
    · have hap := ha.pos_of_not_empty haz
      have hc := bitListDivisionCost_uniform bs as hap W (hbl.trans hL) (hal.trans hL)
      simp only [List.length_cons]
      nlinarith [show 1≤(W+1)^2 from Nat.one_le_pow _ _ (Nat.succ_le_succ (Nat.zero_le W))]
    · let rs := (bitListDivision bs as).remainder
      let ss := (bitListDivision as rs).remainder
      let q := bitListNonnegativeInteger (bitListDivision bs as).quotient
      let p := bitListNonnegativeInteger (bitListDivision as rs).quotient
      let u := bitListIntegerRowCell s' q s
      let v := bitListIntegerRowCell t' q t
      have hap := ha.pos_of_not_empty haz
      have hrc := bitListDivision_remainder_canonical bs as hap
      have hrp : 0<binaryDigitsValue rs := hrc.pos_of_not_empty hrz
      have hsc := bitListDivision_remainder_canonical as rs hrp
      have hrl : rs.length≤L := (bitListDivisionDigits_remainder_width bs as hap).trans hal
      have hsl : ss.length≤L := (bitListDivisionDigits_remainder_width as rs hrp).trans hrl
      have hq : q.digits.length≤L := (bitListDivision_quotient_length_le bs as).trans hbl
      have hp : p.digits.length≤L := (bitListDivision_quotient_length_le as rs).trans hal
      have hu : u.digits.length≤C+(L+1) := (bitListIntegerRowCell_length s' q s).trans (by omega)
      have hv : v.digits.length≤C+(L+1) := (bitListIntegerRowCell_length t' q t).trans (by omega)
      have hsu : (bitListIntegerRowCell s p u).digits.length≤C+2*(L+1) :=
        (bitListIntegerRowCell_length s p u).trans (by omega)
      have htv : (bitListIntegerRowCell t p v).digits.length≤C+2*(L+1) :=
        (bitListIntegerRowCell_length t p v).trans (by omega)
      have hW' : C+2*(L+1)+2*fuel.length*(L+1)≤W := by
        calc
          _=C+2*(b::fuel).length*(L+1) := by simp only [List.length_cons]; ring
          _≤W := hW
      have hi := ih ss rs _ _ u v hsc hrc (C+2*(L+1)) hsl hrl hsu htv
        (by omega) (by omega) hW'
      have hCW : C≤W := by omega
      have huW : u.digits.length≤W := by omega
      have hvW : v.digits.length≤W := by omega
      have hc1 := bitListDivisionCost_uniform bs as hap W (hbl.trans hL) (hal.trans hL)
      have hc2 := bitListDivisionCost_uniform as rs hrp W (hal.trans hL) (hrl.trans hL)
      have hc3 := bitListIntegerRowCellCost_bound s' q s W (hs'.trans hCW) (hq.trans hL) (hs.trans hCW)
      have hc4 := bitListIntegerRowCellCost_bound t' q t W (ht'.trans hCW) (hq.trans hL) (ht.trans hCW)
      have hc5 := bitListIntegerRowCellCost_bound s p u W (hs.trans hCW) (hp.trans hL) huW
      have hc6 := bitListIntegerRowCellCost_bound t p v W (ht.trans hCW) (hp.trans hL) hvW
      change 12+bitListDivisionCost bs as+bitListIntegerRowCellCost s' q s+
        bitListIntegerRowCellCost t' q t+bitListDivisionCost as rs+
        bitListIntegerRowCellCost s p u+bitListIntegerRowCellCost t p v+
        bitListXgcdFuelWork fuel ss _ _ rs u v≤_
      simp only [List.length_cons]
      apply (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add
        (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add (Nat.le_refl 12) hc1) hc3) hc4) hc2) hc5) hc6) hi).trans
      nlinarith only [show 1≤(W+1)^2 from Nat.one_le_pow _ _ (Nat.succ_le_succ (Nat.zero_le W))]

def bitListNatXgcdWork (xs ys : List Bool) : ℕ :=
  bitListTrimVisits xs+bitListTrimVisits ys+6+
    bitListXgcdFuelWork (bitListTrim xs) (bitListTrim xs)
      (bitListNonnegativeInteger [true]) (bitListNonnegativeInteger []) (bitListTrim ys)
      (bitListNonnegativeInteger []) (bitListNonnegativeInteger [true])

theorem bitListNatXgcdWork_bound (xs ys : List Bool) (L : ℕ)
    (hx : xs.length≤L) (hy : ys.length≤L) :
    bitListNatXgcdWork xs ys≤10000*(L+1)^5 := by
  have hxt := (bitListTrim_length_le xs).trans hx
  have hyt := (bitListTrim_length_le ys).trans hy
  have hc := bitListXgcdFuelWork_bound (bitListTrim xs) (bitListTrim xs) (bitListTrim ys)
    (bitListNonnegativeInteger [true]) (bitListNonnegativeInteger [])
    (bitListNonnegativeInteger []) (bitListNonnegativeInteger [true])
    (bitListTrim_canonical _) (bitListTrim_canonical _) L 1 (1+2*L*(L+1)) hxt hyt
    (by decide) (by decide) (by decide) (by decide) (by nlinarith) (by gcongr)
  have hm : 574*(bitListTrim xs).length*(1+2*L*(L+1)+1)^2≤574*L*(1+2*L*(L+1)+1)^2 := by gcongr
  have hsmall : 1+2*L*(L+1)+1≤2*(L+1)^2 := by nlinarith
  have hm' : 574*L*(1+2*L*(L+1)+1)^2≤2296*(L+1)^5 := by
    calc
      _≤574*(L+1)*(2*(L+1)^2)^2 := by gcongr; omega
      _=2296*(L+1)^5 := by ring
  have hp : L+1≤(L+1)^5 := Nat.le_self_pow (by decide) _
  unfold bitListNatXgcdWork
  rw [bitListTrimVisits_eq,bitListTrimVisits_eq]
  omega

theorem bitListInteger_value_bits_le (z : BitListInteger) : z.value.natAbs.size≤z.digits.length := by
  have hv : z.value.natAbs=binaryDigitsValue z.digits := by
    cases hz : z.negative <;> simp [BitListInteger.value,signedBitsValue,hz]
  rw [hv]
  exact Nat.size_le.mpr (binaryDigitsValue_lt_pow z.digits)

theorem bitListIntegerXgcd_lengths (x y : BitListInteger) (L : ℕ)
    (hx : x.digits.length≤L) (hy : y.digits.length≤L) :
    (bitListIntegerXgcd x y).left.digits.length≤1+2*L*(L+1) ∧
    (bitListIntegerXgcd x y).right.digits.length≤1+2*L*(L+1) := by
  have h := bitListNatXgcd_lengths x.digits y.digits L hx hy
  constructor
  · cases hneg : x.negative <;> simpa only [bitListIntegerXgcd,hneg,Bool.false_eq_true,ite_false,ite_true,bitListIntegerNeg] using h.1
  · cases hneg : y.negative <;> simpa only [bitListIntegerXgcd,hneg,Bool.false_eq_true,ite_false,ite_true,bitListIntegerNeg] using h.2

/-- Polynomial bit lengths of the exact coefficients used by the existing
integer unimodular maps. This is derived from the concrete Boolean algorithm. -/
theorem integer_gcd_coefficients_bits (x y : ℤ) (L : ℕ)
    (hx : x.natAbs.size≤L) (hy : y.natAbs.size≤L) :
    (Int.gcdA x y).natAbs.size≤1+2*L*(L+1) ∧
    (Int.gcdB x y).natAbs.size≤1+2*L*(L+1) := by
  have h := bitListIntegerXgcd_lengths (integerBitRepresentation x) (integerBitRepresentation y) L
    (by simpa only [integerBitRepresentation_length] using hx)
    (by simpa only [integerBitRepresentation_length] using hy)
  have hl := congrArg (fun z : ℕ×ℤ×ℤ => z.2.1) (bitListIntegerXgcd_bits x y)
  have hr := congrArg (fun z : ℕ×ℤ×ℤ => z.2.2) (bitListIntegerXgcd_bits x y)
  change (bitListIntegerXgcd (integerBitRepresentation x) (integerBitRepresentation y)).left.value=Int.gcdA x y at hl
  change (bitListIntegerXgcd (integerBitRepresentation x) (integerBitRepresentation y)).right.value=Int.gcdB x y at hr
  constructor
  · rw [←hl]
    exact (bitListInteger_value_bits_le _).trans h.1
  · rw [←hr]
    exact (bitListInteger_value_bits_le _).trans h.2

def bitListIntegerXgcdWork (x y : BitListInteger) : ℕ := bitListNatXgcdWork x.digits y.digits+4

theorem bitListIntegerXgcdWork_bound (x y : BitListInteger) (L : ℕ)
    (hx : x.digits.length≤L) (hy : y.digits.length≤L) :
    bitListIntegerXgcdWork x y≤10004*(L+1)^5 := by
  have h := bitListNatXgcdWork_bound x.digits y.digits L hx hy
  have hp : 1≤(L+1)^5 := Nat.one_le_pow _ _ (by omega)
  unfold bitListIntegerXgcdWork
  nlinarith only [h,hp]

end Optss
