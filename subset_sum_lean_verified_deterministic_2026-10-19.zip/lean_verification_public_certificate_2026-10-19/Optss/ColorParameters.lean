import Optss.BucketLoadProbability

/-!
# Explicit parameters for Appendix A.2

A concrete constant `gamma = 2 / log 2` suffices for the load parameter.
The bucket and repetition counts satisfy the proved probability hypotheses.
The factor-count and scaled-width estimates are explicit inequalities; no
asymptotic arithmetic or convolution running-time bound is asserted here.
-/
namespace Optss
noncomputable section

/-- The manuscript's logarithmic load parameter with one explicit constant. -/
def colorLoadParameter (m V : ℕ) (ζ : ℝ) : ℕ :=
  ⌈2 * Real.logb 2 (((m : ℝ) + V + 2) / ζ)⌉₊

/-- The rounded bucket count, in executable natural arithmetic. -/
def colorBucketCount (k L : ℕ) : ℕ := max 1 ((k + L - 1) / L)

/-- Number of colors in each repetition within a bucket. -/
def colorPaletteSize (L : ℕ) : ℕ := 128 * L ^ 2

/-- The repetition count printed in the manuscript. -/
def colorRepetitionCount (b : ℕ) (ζ : ℝ) : ℕ :=
  ⌈Real.logb 2 (2 * (b : ℝ) / ζ)⌉₊

theorem colorLoadParameter_eq_natural_log (m V : ℕ) (ζ : ℝ) :
    colorLoadParameter m V ζ =
      ⌈(2 / Real.log 2) * Real.log (((m : ℝ) + V + 2) / ζ)⌉₊ := by
  unfold colorLoadParameter
  congr 1
  unfold Real.logb
  ring

theorem color_load_constant_pos : (0 : ℝ) < 2 / Real.log 2 := by
  exact div_pos (by norm_num) (Real.log_pos (by norm_num))

/-- The standard natural formula for a ceiling quotient. -/
theorem nat_ceil_div_eq_add_pred_div (k L : ℕ) (hL : 0 < L) :
    ⌈(k : ℝ) / L⌉₊ = (k + L - 1) / L := by
  have hLR : (0 : ℝ) < L := by exact_mod_cast hL
  have hmod := Nat.mod_lt (k + L - 1) hL
  have hdecomp := Nat.mod_add_div (k + L - 1) L
  have hsub : k + L - 1 + 1 = k + L := by omega
  have hround : k ≤ ((k + L - 1) / L) * L := by nlinarith
  apply Nat.le_antisymm
  · apply Nat.ceil_le.mpr
    apply (div_le_iff₀ hLR).mpr
    exact_mod_cast hround
  · have hc := Nat.le_ceil ((k : ℝ) / L)
    have hkreal := (div_le_iff₀ hLR).mp hc
    have hknat : k ≤ ⌈(k : ℝ) / L⌉₊ * L := by exact_mod_cast hkreal
    apply Nat.le_of_lt_succ
    apply (Nat.div_lt_iff_lt_mul hL).mpr
    nlinarith

theorem colorBucketCount_eq_ceil (k L : ℕ) (hL : 0 < L) :
    colorBucketCount k L = max 1 ⌈(k : ℝ) / L⌉₊ := by
  rw [nat_ceil_div_eq_add_pred_div k L hL]
  rfl

/-- The load parameter is positive for the paper's inputs. -/
theorem colorLoadParameter_pos (m V : ℕ) (ζ : ℝ)
    (hm : 1 ≤ m) (hV : 1 ≤ V) (hζ : 0 < ζ) (hζ1 : ζ < 1) :
    0 < colorLoadParameter m V ζ := by
  have hmR : (1 : ℝ) ≤ m := by exact_mod_cast hm
  have hVR : (1 : ℝ) ≤ V := by exact_mod_cast hV
  have hX : (1 : ℝ) < ((m : ℝ) + V + 2) / ζ := by
    apply (lt_div_iff₀ hζ).mpr
    nlinarith
  have hlog := Real.logb_pos (by norm_num : (1 : ℝ) < 2) hX
  have hc := Nat.le_ceil (2 * Real.logb 2 (((m : ℝ) + V + 2) / ζ))
  have hpos : (0 : ℝ) < colorLoadParameter m V ζ := by
    change (0 : ℝ) < (⌈2 * Real.logb 2 (((m : ℝ) + V + 2) / ζ)⌉₊ : ℝ)
    linarith
  exact_mod_cast hpos

/-- Rounding never requires more buckets than the positive witness cap. -/
theorem colorBucketCount_le_cap (k L : ℕ) (hk : 1 ≤ k) (hL : 1 ≤ L) :
    colorBucketCount k L ≤ k := by
  apply max_le hk
  apply Nat.le_of_lt_succ
  apply (Nat.div_lt_iff_lt_mul (by omega : 0 < L)).mpr
  have hsub : k + L - 1 + 1 = k + L := by omega
  nlinarith [Nat.mul_le_mul hk hL]

/-- The precise rounding overhead in bucket capacity is at most one `L`. -/
theorem colorBucketCount_mul_le (k L : ℕ) :
    colorBucketCount k L * L ≤ k + L := by
  unfold colorBucketCount
  by_cases h : (k + L - 1) / L ≤ 1
  · rw [max_eq_left h]
    simp
  · rw [max_eq_right (by omega)]
    exact (Nat.div_mul_le_self (k + L - 1) L).trans (Nat.sub_le _ _)

/-- Both bucket-count bounds and capacity for the actual parameter choices. -/
theorem color_parameter_bucket_bounds (m k V : ℕ) (ζ : ℝ)
    (hk : 1 ≤ k) (hkm : k ≤ m) (hV : 1 ≤ V) (hζ : 0 < ζ) (hζ1 : ζ < 1) :
    let L := colorLoadParameter m V ζ
    let b := colorBucketCount k L
    0 < L ∧ 0 < b ∧ b ≤ k ∧ b ≤ m ∧ k ≤ b * L := by
  have hL := colorLoadParameter_pos m V ζ (hk.trans hkm) hV hζ hζ1
  have hb := colorBucketCount_le_cap k _ hk hL
  refine ⟨hL, ?_, hb, hb.trans hkm, rounded_bucket_count_capacity k _ hL⟩
  unfold colorBucketCount
  omega

/-- The logarithmic load parameter leaves at most half the failure budget
for overloaded buckets, with no unspecified sufficiently-large constant. -/
theorem color_parameter_load_budget (m k V : ℕ) (ζ : ℝ)
    (hk : 1 ≤ k) (hkm : k ≤ m) (hV : 1 ≤ V) (hζ : 0 < ζ) (hζ1 : ζ < 1) :
    let L := colorLoadParameter m V ζ
    let b := colorBucketCount k L
    2 * (b : ℝ) ≤ ζ * 2 ^ (4 * L) := by
  obtain ⟨hL, _, _, hbm, _⟩ := color_parameter_bucket_bounds m k V ζ hk hkm hV hζ hζ1
  let L := colorLoadParameter m V ζ
  let b := colorBucketCount k L
  have hmR : (1 : ℝ) ≤ m := by exact_mod_cast hk.trans hkm
  have hVR : (1 : ℝ) ≤ V := by exact_mod_cast hV
  have hX : (1 : ℝ) < ((m : ℝ) + V + 2) / ζ := by
    apply (lt_div_iff₀ hζ).mpr
    nlinarith
  have hlog := Real.logb_pos (by norm_num : (1 : ℝ) < 2) hX
  have hc : 2 * Real.logb 2 (((m : ℝ) + V + 2) / ζ) ≤ (L : ℝ) := Nat.le_ceil _
  have hlogL : Real.logb 2 (((m : ℝ) + V + 2) / ζ) ≤ (L : ℝ) := by linarith
  have hpow := (Real.logb_le_iff_le_rpow (by norm_num : (1 : ℝ) < 2)
    (by positivity : (0 : ℝ) < ((m : ℝ) + V + 2) / ζ)).mp hlogL
  rw [Real.rpow_natCast] at hpow
  have hnum : (m : ℝ) + V + 2 ≤ ζ * 2 ^ L := by
    have h := (div_le_iff₀ hζ).mp hpow
    nlinarith
  have hpowgrow : (2 : ℝ) ^ (L + 1) ≤ 2 ^ (4 * L) :=
    pow_le_pow_right₀ (by norm_num) (by omega)
  rw [pow_succ] at hpowgrow
  have hscaled := mul_le_mul_of_nonneg_left hpowgrow hζ.le
  have hbmR : (b : ℝ) ≤ m := by exact_mod_cast hbm
  change 2 * (b : ℝ) ≤ ζ * 2 ^ (4 * L)
  nlinarith

/-- Explicit factor count for all bucket/color products in one repetition. -/
theorem color_parameter_factor_count (k L : ℕ) :
    colorBucketCount k L * colorPaletteSize L ≤ 128 * (k * L + L ^ 2) := by
  have h := Nat.mul_le_mul_right L (colorBucketCount_mul_le k L)
  unfold colorPaletteSize
  nlinarith

/-- The total scaled coordinate width is controlled by the dimension and
polylogarithmic load parameter when `k*alpha ≤ 2d`. -/
theorem color_parameter_scaled_width (k L d : ℕ) (α : ℝ)
    (hα : 0 ≤ α) (hα1 : α ≤ 1) (hkα : (k : ℝ) * α ≤ 2 * d) :
    ((colorBucketCount k L * colorPaletteSize L : ℕ) : ℝ) * α ≤
      128 * (2 * (d : ℝ) * L + (L : ℝ) ^ 2) := by
  have hcount : ((colorBucketCount k L * colorPaletteSize L : ℕ) : ℝ) ≤
      128 * ((k : ℝ) * L + (L : ℝ) ^ 2) := by
    exact_mod_cast color_parameter_factor_count k L
  have hscaled := mul_le_mul_of_nonneg_right hcount hα
  have hterm := mul_le_mul_of_nonneg_right hkα (show (0 : ℝ) ≤ L by positivity)
  have hlast := mul_le_mul_of_nonneg_left hα1 (show (0 : ℝ) ≤ (L : ℝ)^2 by positivity)
  nlinarith


/-- The chosen palette is nonempty, so uniform colors are well defined. -/
theorem colorPaletteSize_pos (L : ℕ) (hL : 0 < L) : 0 < colorPaletteSize L := by
  unfold colorPaletteSize
  positivity

/-- The paper's repetition count is positive on the permitted probability
range, so every bucket receives an actual coloring experiment. -/
theorem colorRepetitionCount_pos (b : ℕ) (hb : 0 < b) (ζ : ℝ)
    (hζ : 0 < ζ) (hζ1 : ζ < 1) : 0 < colorRepetitionCount b ζ := by
  have hbR : (1 : ℝ) ≤ b := by exact_mod_cast hb
  have hX : (1 : ℝ) < 2 * (b : ℝ) / ζ := by
    apply (lt_div_iff₀ hζ).mpr
    nlinarith
  have hlog := Real.logb_pos (by norm_num : (1 : ℝ) < 2) hX
  have hc := Nat.le_ceil (Real.logb 2 (2 * (b : ℝ) / ζ))
  have hpos : (0 : ℝ) < colorRepetitionCount b ζ := by
    change (0 : ℝ) < (⌈Real.logb 2 (2 * (b : ℝ) / ζ)⌉₊ : ℝ)
    linarith
  exact_mod_cast hpos

section Probability
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The first hashing stage meets its failure budget under the concrete
parameter definitions and the manuscript's input assumptions. -/
theorem color_parameters_load_half_failure (S : Finset ι) (m k V : ℕ) (ζ : ℝ)
    (hk : 1 ≤ k) (hkm : k ≤ m) (hV : 1 ≤ V) (hζ : 0 < ζ) (hζ1 : ζ < 1)
    (hS : S.card ≤ k) :
    let L := colorLoadParameter m V ζ
    let b := colorBucketCount k L
    uniformProbability (Finset.univ.biUnion (bucketOverloadEvent S b L)) ≤ ζ / 2 := by
  obtain ⟨_, hb, _, _, hcapacity⟩ := color_parameter_bucket_bounds m k V ζ hk hkm hV hζ hζ1
  exact uniform_bucket_load_half_budget S _ _ hb (hS.trans hcapacity) ζ
    (color_parameter_load_budget m k V ζ hk hkm hV hζ hζ1)

/-- After conditioning on controlled bucket loads, the actual repeated
colorings meet the other half of the failure budget. -/
theorem color_parameters_collision_half_failure (m k V : ℕ) (ζ : ℝ)
    (hk : 1 ≤ k) (hkm : k ≤ m) (hV : 1 ≤ V) (hζ : 0 < ζ) (hζ1 : ζ < 1)
    (S : Fin (colorBucketCount k (colorLoadParameter m V ζ)) → Finset ι)
    (hS : ∀ p, (S p).card ≤ 8 * colorLoadParameter m V ζ) :
    let L := colorLoadParameter m V ζ
    let b := colorBucketCount k L
    uniformProbability (bucketCollisionEvent b L (colorRepetitionCount b ζ) S) ≤ ζ / 2 := by
  obtain ⟨hL, hb, _, _, _⟩ := color_parameter_bucket_bounds m k V ζ hk hkm hV hζ hζ1
  exact uniform_bucket_collision_half_budget _ _ S hb hL hS ζ hζ

end Probability
end
end Optss
