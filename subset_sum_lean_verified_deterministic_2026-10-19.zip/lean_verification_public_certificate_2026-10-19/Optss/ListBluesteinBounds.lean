import Optss.ListBluesteinTransform

/-! Physical output-digit bounds for the actual list Bluestein evaluator.
The estimates are derived from canonical stored arithmetic and from the
proved character magnitudes; they are not extra hypotheses on intermediate
Fourier arrays. -/
namespace Optss
set_option maxRecDepth 4096
set_option maxHeartbeats 800000

theorem fourier_exists_vector {α : Type*} (xs : List α) (n : ℕ) (hn : xs.length=n) :
    ∃ A : Vector α n, List.ofFn A.get=xs := by
  refine ⟨Vector.ofFn (fun i => xs[i.val]'(by omega)),?_⟩
  apply List.ext_getElem
  · simpa only [List.length_ofFn] using hn.symm
  · intro i hi hi'
    simp only [List.getElem_ofFn,vector_get_ofFn]

theorem fourier_forall_zipWith {α β γ : Type*} (f : α → β → γ)
    (xs : List α) (ys : List β) (P : γ → Prop)
    (h : ∀ x∈xs, ∀ y∈ys, P (f x y)) : ∀ z∈List.zipWith f xs ys, P z := by
  induction xs generalizing ys with
  | nil => simp
  | cons x xs ih =>
    cases ys with
    | nil => simp
    | cons y ys =>
      intro z hz
      simp only [List.zipWith_cons_cons,List.mem_cons] at hz
      rcases hz with rfl|hz
      · exact h _ (by simp) _ (by simp)
      · exact ih ys (fun a ha b hb => h a (by simp [ha]) b (by simp [hb])) z hz

theorem fourierListPad_forall {α : Type*} (z : α) (fuel : List Bool) (xs : List α)
    (P : α → Prop) (hz : P z) (hxs : ∀ x∈xs, P x) : ∀ x∈fourierListPad z fuel xs,P x := by
  induction fuel generalizing xs with
  | nil => simp [fourierListPad]
  | cons b fuel ih =>
    cases xs with
    | nil => simpa only [fourierListPad,List.forall_mem_cons] using
        And.intro hz (ih [] (by simp))
    | cons x xs =>
      simp only [fourierListPad,List.forall_mem_cons]
      exact ⟨hxs x (by simp),ih xs (fun a ha => hxs a (by simp [ha]))⟩

theorem bitFourierZero_canonical : bitFourierZero.Canonical := by
  constructor <;> simp [BitListCanonical,bitFourierZero,binaryDigitsValue]

theorem bitFourierZero_width (b : ℕ) : bitFourierZero.Width b := by
  constructor <;> exact Nat.zero_le _

theorem bitChirpPairs_canonical (ms fuel counter : List Bool) (p : ℕ) :
    ∀ q∈bitChirpPairs ms p fuel counter,q.1.Canonical ∧ q.2.Canonical := by
  induction fuel generalizing counter with
  | nil => simp [bitChirpPairs]
  | cons b fuel ih =>
    simp only [bitChirpPairs,List.forall_mem_cons]
    exact ⟨bitChirpPair_canonical _ _ _,ih _⟩

theorem bitStoredCharacter_width {N : ℕ} [NeZero N] (z : BitFourierInteger)
    (hz : z.Canonical) (x : ZMod N) (p : ℕ) (he : z.value=dyadicCharacterInteger x p) :
    z.Width (p+4) := by
  have h := z.width_of_bound hz (2*dyadicFourierDenominator p)
    (by rw [he]; exact dyadicCharacterInteger_bound x p)
  have heq : 2*dyadicFourierDenominator p=2^(p+3) := by
    calc
      2*dyadicFourierDenominator p=2*2^(p+2) := rfl
      _=2^((p+2)+1) := by rw [pow_succ]; ring
      _=2^(p+3) := rfl
  simpa only [heq,Nat.size_pow] using h

theorem listBluesteinChirps_bounds (input : List Bool) [NeZero input.length] (p : ℕ) :
    ∀ q∈listBluesteinChirps input p,
      (q.1.Canonical ∧ q.1.Width (p+4)) ∧ (q.2.Canonical ∧ q.2.Width (p+4)) := by
  intro q hq
  have hc := bitChirpPairs_canonical (false::listLengthDigits input) input [] p q hq
  obtain ⟨hn,hp⟩ := listBluesteinChirps_values input p
  have hnq : q.1.value∈List.ofFn (fun k : Fin input.length =>
      dyadicCharacterInteger (-(k.val : ZMod (2*input.length))^2) p) :=
    hn ▸ List.mem_map.mpr ⟨q,hq,rfl⟩
  have hpq : q.2.value∈List.ofFn (fun k : Fin input.length =>
      dyadicCharacterInteger ((k.val : ZMod (2*input.length))^2) p) :=
    hp ▸ List.mem_map.mpr ⟨q,hq,rfl⟩
  obtain ⟨i,hi⟩ := List.mem_ofFn.mp hnq
  obtain ⟨j,hj⟩ := List.mem_ofFn.mp hpq
  exact ⟨⟨hc.1,bitStoredCharacter_width q.1 hc.1 _ p hi.symm⟩,
    ⟨hc.2,bitStoredCharacter_width q.2 hc.2 _ p hj.symm⟩⟩

theorem listDyadicTransform_list_bounds (depth : List Bool) (p b : ℕ)
    (A : List BitFourierInteger) (hlen : A.length=2^depth.length)
    (hA : ∀ z∈A,z.Canonical ∧ z.Width b) :
    (listDyadicTransform depth p A).length=2^depth.length ∧
      ∀ z∈listDyadicTransform depth p A,z.Canonical ∧ z.Width (depth.length*(p+6)+b+2) := by
  obtain ⟨V,rfl⟩ := fourier_exists_vector A _ hlen
  have hc : ∀ j,(V.get j).Canonical := fun j => (hA _ (List.mem_ofFn.mpr ⟨j,rfl⟩)).1
  have hw : ∀ j,(V.get j).Width b := fun j => (hA _ (List.mem_ofFn.mpr ⟨j,rfl⟩)).2
  exact ⟨listDyadicTransform_length depth p V,fun z hz =>
    ⟨listDyadicTransform_canonical depth p V hc z hz,listDyadicTransform_width depth p b V hc hw z hz⟩⟩

theorem listCyclicReflect_forall {α : Type*} (xs : List α) (P : α → Prop)
    (h : ∀ x∈xs,P x) : ∀ x∈listCyclicReflect xs,P x := by
  cases xs with
  | nil => simp [listCyclicReflect]
  | cons x xs =>
    simp only [listCyclicReflect,List.forall_mem_cons] at h ⊢
    exact ⟨h.1,fun y hy => h.2 y (List.mem_reverse.mp hy)⟩

theorem listCyclicConvolution_list_bounds (depth : List Bool) (p b : ℕ)
    (A B : List BitFourierInteger) (hla : A.length=2^depth.length) (hlb : B.length=2^depth.length)
    (ha : ∀ z∈A,z.Canonical ∧ z.Width b) (hb : ∀ z∈B,z.Canonical ∧ z.Width b) :
    (listCyclicConvolution depth p A B).length=2^depth.length ∧
      ∀ z∈listCyclicConvolution depth p A B,z.Canonical ∧ z.Width (3*depth.length*(p+6)+2*b+7) := by
  let FA := listDyadicTransform depth p A
  let FB := listDyadicTransform depth p B
  let P := List.zipWith bitFourierMul FA FB
  have hfa := listDyadicTransform_list_bounds depth p b A hla ha
  have hfb := listDyadicTransform_list_bounds depth p b B hlb hb
  have hlp : P.length=2^depth.length := by simp only [P,List.length_zipWith,FA,FB,hfa.1,hfb.1,min_self]
  have hP : ∀ z∈P,z.Canonical ∧ z.Width (2*(depth.length*(p+6)+b+2)+1) := by
    apply fourier_forall_zipWith
    intro a ha b hb
    exact ⟨bitFourierMul_canonical _ _,bitFourierMul_width _ _ _ (hfa.2 _ ha).2 (hfb.2 _ hb).2⟩
  have hthird := listDyadicTransform_list_bounds depth p _ P hlp hP
  constructor
  · exact (listCyclicReflect_length _).trans hthird.1
  · apply listCyclicReflect_forall
    intro z hz
    have hh := hthird.2 z hz
    convert hh using 1 <;> ring

theorem listBluestein_prepared_bounds (depth : List Bool) (p : ℕ) (input : List Bool)
    (hinput : input≠[]) :
    let chirps := listBluesteinChirps input p
    let neg := chirps.map Prod.fst
    let pos := chirps.map Prod.snd
    let fuel := radixListFuel depth
    let A := fourierListPad bitFourierZero fuel
      (List.zipWith (fun b z => if b then z else bitFourierZero) input neg)
    let B := fourierListPad bitFourierZero fuel (pos.reverse++pos.tail)
    neg.length=input.length ∧ A.length=2^depth.length ∧ B.length=2^depth.length ∧
      (∀ z∈neg,z.Canonical ∧ z.Width (p+4)) ∧
      (∀ z∈A,z.Canonical ∧ z.Width (p+4)) ∧
      (∀ z∈B,z.Canonical ∧ z.Width (p+4)) := by
  haveI : NeZero input.length := ⟨by have := List.length_pos_iff.mpr hinput; omega⟩
  let P := fun z : BitFourierInteger => z.Canonical ∧ z.Width (p+4)
  have hz : P bitFourierZero := ⟨bitFourierZero_canonical,bitFourierZero_width _⟩
  have hn : ∀ z∈(listBluesteinChirps input p).map Prod.fst,P z := by
    intro z hm
    obtain ⟨q,hq,rfl⟩ := List.mem_map.mp hm
    exact (listBluesteinChirps_bounds input p q hq).1
  have hp : ∀ z∈(listBluesteinChirps input p).map Prod.snd,P z := by
    intro z hm
    obtain ⟨q,hq,rfl⟩ := List.mem_map.mp hm
    exact (listBluesteinChirps_bounds input p q hq).2
  refine ⟨?_,?_,?_,hn,?_,?_⟩
  · simp only [List.length_map,listBluesteinChirps,bitChirpPairs_length]
  · rw [fourierListPad_length,radixListFuel_length]
  · rw [fourierListPad_length,radixListFuel_length]
  · apply fourierListPad_forall _ _ _ P hz
    apply fourier_forall_zipWith
    intro b hb z hzz
    cases b
    · exact hz
    · exact hn z hzz
  · apply fourierListPad_forall _ _ _ P hz
    intro z hm
    rcases List.mem_append.mp hm with hm|hm
    · exact hp z (List.mem_reverse.mp hm)
    · exact hp z (List.mem_of_mem_tail hm)

def listBluesteinOutputBits (n p : ℕ) : ℕ := 6*n*(p+6)+4*p+31

theorem listBluesteinTransform_bounds (depth : List Bool) (p : ℕ) (input : List Bool)
    (hinput : input≠[]) :
    ∀ z∈listBluesteinTransform depth p input,z.Canonical ∧ z.Width (listBluesteinOutputBits depth.length p) := by
  obtain ⟨hn,hla,hlb,hneg,ha,hb⟩ := listBluestein_prepared_bounds depth p input hinput
  let neg := (listBluesteinChirps input p).map Prod.fst
  let pos := (listBluesteinChirps input p).map Prod.snd
  let A := fourierListPad bitFourierZero (radixListFuel depth)
      (List.zipWith (fun b z => if b then z else bitFourierZero) input neg)
  let B := fourierListPad bitFourierZero (radixListFuel depth) (pos.reverse++pos.tail)
  have hc := listCyclicConvolution_list_bounds depth p (p+4) A B hla hlb ha hb
  change ∀ z∈List.zipWith bitFourierMul neg (fourierListDrop input.tail
    (listCyclicConvolution depth p A B)),_
  apply fourier_forall_zipWith
  intro z hz w hw
  have hzw := (hneg z hz).2
  have hww := (hc.2 w (List.mem_of_mem_drop (by simpa only [fourierListDrop_eq] using hw))).2
  have hmul := bitFourierMul_width z w (3*depth.length*(p+6)+2*(p+4)+7)
    (hzw.mono (by omega)) hww
  refine ⟨bitFourierMul_canonical _ _,?_⟩
  convert hmul using 1 <;> simp only [listBluesteinOutputBits] <;> ring

theorem listBluesteinTransform_length (N : ℕ) [NeZero N] (depth : List Bool) (p : ℕ)
    (f : Vector Bool N) (hpad : 3*N-2≤2^depth.length) :
    (listBluesteinTransform depth p (List.ofFn f.get)).length=N := by
  have h := congrArg List.length (listBluesteinTransform_eq N depth p f hpad)
  simpa only [List.length_map,List.length_ofFn] using h

theorem listCyclicConvolutionWork_list_bound (depth : List Bool) (p b : ℕ)
    (A B : List BitFourierInteger) (hla : A.length=2^depth.length) (hlb : B.length=2^depth.length)
    (ha : ∀ z∈A,z.Canonical ∧ z.Width b) (hb : ∀ z∈B,z.Canonical ∧ z.Width b) :
    listCyclicConvolutionWork depth p A B≤
      3*listDyadicWorkPolynomial depth.length p (2*(depth.length*(p+6)+b+2)+1)+
        512*2^depth.length*(depth.length*(p+6)+b+3)^2+6*2^depth.length+8 := by
  obtain ⟨VA,rfl⟩ := fourier_exists_vector A _ hla
  obtain ⟨VB,rfl⟩ := fourier_exists_vector B _ hlb
  exact listCyclicConvolutionWork_bound depth p b VA VB
    (fun j => (ha _ (List.mem_ofFn.mpr ⟨j,rfl⟩)).1)
    (fun j => (hb _ (List.mem_ofFn.mpr ⟨j,rfl⟩)).1)
    (fun j => (ha _ (List.mem_ofFn.mpr ⟨j,rfl⟩)).2)
    (fun j => (hb _ (List.mem_ofFn.mpr ⟨j,rfl⟩)).2)

end Optss
