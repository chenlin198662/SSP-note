import Optss.Basic

/-! # Exact reorientation and anchoring (§9.1)

Counts are integers with explicit lower and upper bounds. These proofs cover
Lemma 9.3(iii) and the anchor correspondence used in Lemma 9.2; they do not
establish the short-solution bound or the preprocessing running time.
-/

namespace Optss
open scoped BigOperators

variable {ι G : Type*} [Fintype ι] [AddCommGroup G]

/-- Complement exactly the types whose orientation flag is true. -/
def reorientCounts (c : ι → ℤ) (flip : ι → Bool) (x : ι → ℤ) : ι → ℤ :=
  fun i => if flip i then c i - x i else x i

def reorientVectors (v : ι → G) (flip : ι → Bool) : ι → G :=
  fun i => if flip i then -v i else v i

def endpoint (c : ι → ℤ) (flip : ι → Bool) : ι → ℤ :=
  fun i => if flip i then c i else 0

omit [Fintype ι] in
@[simp] theorem reorientCounts_involutive (c : ι → ℤ) (flip : ι → Bool) (x : ι → ℤ) :
    reorientCounts c flip (reorientCounts c flip x) = x := by
  funext i
  simp only [reorientCounts]
  split <;> simp_all

omit [Fintype ι] in
theorem reorientCounts_bounded {c x : ι → ℤ} (flip : ι → Bool)
    (hx : BoundedCounts c x) : BoundedCounts c (reorientCounts c flip x) := by
  intro i
  have hi := hx i
  simp only [reorientCounts]
  split <;> constructor <;> omega

/-- Complementing endpoint choices is an exact equality of weighted sums. -/
theorem reorientation_sum (v : ι → G) (c x : ι → ℤ) (flip : ι → Bool) :
    weightedSum v (reorientCounts c flip x) =
      weightedSum v (endpoint c flip) + weightedSum (reorientVectors v flip) x := by
  rw [weightedSum, weightedSum, weightedSum, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  simp only [reorientCounts, endpoint, reorientVectors]
  cases h : flip i <;> simp [h, sub_eq_add_neg, add_zsmul, neg_zsmul]

/-- Lemma 9.3(iii), with no expansion of copies. -/
theorem reorientation_iff (v : ι → G) (c : ι → ℤ) (flip : ι → Bool) (t : G) :
    t ∈ countSums v c ↔
      t - weightedSum v (endpoint c flip) ∈ countSums (reorientVectors v flip) c := by
  constructor
  · rintro ⟨x, hx, rfl⟩
    refine ⟨reorientCounts c flip x, reorientCounts_bounded flip hx, ?_⟩
    have h := reorientation_sum v c (reorientCounts c flip x) flip
    rw [reorientCounts_involutive] at h
    rw [h]
    abel
  · rintro ⟨y, hy, hsum⟩
    refine ⟨reorientCounts c flip y, reorientCounts_bounded flip hy, ?_⟩
    rw [reorientation_sum, hsum]
    abel

omit [Fintype ι] in
/-- Positive and negative deviations from any feasible anchor recover a valid count. -/
theorem anchor_reconstruction_bounds {c b p q : ι → ℤ}
    (hb : BoundedCounts c b)
    (hp : BoundedCounts (fun i => c i - b i) p)
    (hq : BoundedCounts b q) :
    BoundedCounts c (fun i => b i + p i - q i) := by
  intro i
  have hi := hb i
  have hpi := hp i
  have hqi := hq i
  dsimp at hpi ⊢
  constructor <;> omega

omit [Fintype ι] in
/-- Any feasible original count splits into available forward and backward changes. -/
theorem exists_anchor_deviations {c b x : ι → ℤ}
    (hb : BoundedCounts c b) (hx : BoundedCounts c x) :
    ∃ p q : ι → ℤ, BoundedCounts (fun i => c i - b i) p ∧ BoundedCounts b q ∧
      x = fun i => b i + p i - q i := by
  refine ⟨fun i => max (x i - b i) 0, fun i => max (b i - x i) 0, ?_, ?_, ?_⟩
  · intro i
    have hi := hx i
    have hbi := hb i
    dsimp
    constructor
    · exact le_max_right _ _
    · exact max_le (by omega) (by omega)
  · intro i
    have hi := hx i
    have hbi := hb i
    dsimp
    constructor
    · exact le_max_right _ _
    · exact max_le (by omega) (by omega)
  · funext i
    dsimp
    omega

/-- The exact anchor reduction in the proof of Lemma 9.2, before multiplicity capping. -/
theorem anchor_feasible_iff (v : ι → G) (c b : ι → ℤ) (hb : BoundedCounts c b) (t : G) :
    t ∈ countSums v c ↔
      ∃ p q : ι → ℤ, BoundedCounts (fun i => c i - b i) p ∧ BoundedCounts b q ∧
        weightedSum v p - weightedSum v q = t - weightedSum v b := by
  constructor
  · rintro ⟨x, hx, rfl⟩
    rcases exists_anchor_deviations hb hx with ⟨p, q, hp, hq, rfl⟩
    refine ⟨p, q, hp, hq, ?_⟩
    rw [weightedSum_sub, weightedSum_add]
    abel
  · rintro ⟨p, q, hp, hq, hs⟩
    refine ⟨fun i => b i + p i - q i, anchor_reconstruction_bounds hb hp hq, ?_⟩
    rw [weightedSum_sub, weightedSum_add]
    calc
      weightedSum v b + weightedSum v p - weightedSum v q =
          weightedSum v b + (weightedSum v p - weightedSum v q) := by abel
      _ = t := by rw [hs]; abel

end Optss
