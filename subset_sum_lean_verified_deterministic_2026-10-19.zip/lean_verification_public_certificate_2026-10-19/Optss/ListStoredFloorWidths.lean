import Optss.ListStoredVertexWidths
import Optss.BooleanFloorWidths

/-! Actual stored coordinate scans for zero-allowing floor widths. -/
namespace Optss
open scoped BigOperators
variable {r m : ℕ}

def listMatrixFloorWidthScan (P : ListBitRationalMatrixData r m) : BooleanListArray (List Bool) r :=
  ⟨P.data.map (fun row => booleanVertexFloorWidth row.data),by simp [P.length_eq]⟩

def listMatrixFloorWidthScanWork (P : ListBitRationalMatrixData r m) : ℕ :=
  2*r+1+(P.data.map (fun row => booleanVertexFloorWidthWork row.data)).sum

theorem listMatrixFloorWidthScan_get (P : ListBitRationalMatrixData r m) (i : Fin r) :
    (listMatrixFloorWidthScan P).toVector.get i=booleanVertexFloorWidth ((P.toVector.get i).data) := by
  simp [listMatrixFloorWidthScan,BooleanListArray.toVector,Vector.get]

theorem listMatrixFloorWidthScanWork_bound (P : ListBitRationalMatrixData r m)
    (hP : ∀ i j,(rectangularListFractionMatrix P i j).WellFormed) (T : ℕ) (hT : 0<T)
    (hbits : ∀ i j,(rectangularListFractionMatrix P i j).numerator.length≤T ∧
      (rectangularListFractionMatrix P i j).denominator.length≤T) :
    listMatrixFloorWidthScanWork P≤2*r+1+r*(m+2)*1024*(T+1)^2 := by
  have hw := (matrixRows_forall P BitListFraction.WellFormed).mpr hP
  have hb := (matrixRows_forall P (fun q => q.numerator.length≤T ∧ q.denominator.length≤T)).mpr hbits
  unfold listMatrixFloorWidthScanWork
  apply Nat.add_le_add_left
  have hs := List.sum_le_card_nsmul (P.data.map (fun row => booleanVertexFloorWidthWork row.data))
    ((m+2)*1024*(T+1)^2) (by
      intro z hz
      obtain ⟨row,hr,rfl⟩ := List.mem_map.mp hz
      simpa only [row.length_eq] using booleanVertexFloorWidthWork_bound row.data (hw row hr) T hT (hb row hr))
  simpa only [List.length_map,P.length_eq,nsmul_eq_mul,mul_assoc] using hs

def listStoredVertexFloorWidths (C : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m) :
    BooleanListArray (List Bool) r :=
  let coordinates := constructedListMatrixMul C V
  listMatrixFloorWidthScan coordinates

def listStoredVertexFloorWidthsWork (C : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m) : ℕ :=
  let coordinates := constructedListMatrixMul C V
  constructedListMatrixMulWork C V+listMatrixFloorWidthScanWork coordinates+1

theorem listStoredVertexFloorWidths_value (C : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m)
    (hC : ∀ i j,(rectangularListFractionMatrix C i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) (j : Fin r) :
    binaryDigitsValue ((listStoredVertexFloorWidths C V).toVector.get j)=
      rationalVertexFloorWidth ((rectangularListFractionMatrix C).map bitListFractionValue) (storedRationalVertices V) j := by
  rw [listStoredVertexFloorWidths,listMatrixFloorWidthScan_get,booleanListArray_data_eq_ofFn]
  apply booleanVertexFloorWidth_coordinate_value
  · intro i
    rw [← rectangularListFractionMatrix_row]
    exact constructedListMatrixMul_wellFormed C V hC hV j i
  · intro i
    rw [← rectangularListFractionMatrix_row,constructedListMatrixMul_value C V hC hV]
    rfl

theorem listStoredVertexFloorWidths_canonical (C : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m)
    (hC : ∀ i j,(rectangularListFractionMatrix C i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) (j : Fin r) :
    BitListCanonical ((listStoredVertexFloorWidths C V).toVector.get j) := by
  rw [listStoredVertexFloorWidths,listMatrixFloorWidthScan_get]
  apply booleanVertexFloorWidth_canonical
  apply (((constructedListMatrixMul C V).toVector.get j).forall_data_iff BitListFraction.WellFormed).mpr
  intro i
  rw [← rectangularListFractionMatrix_row]
  exact constructedListMatrixMul_wellFormed C V hC hV j i

noncomputable def storedVertexFloorWidthsPolynomial (r m : ℕ) : Polynomial ℕ :=
  constructedMatrixMulPolynomial r r m+
    Polynomial.C (2*r+2)+
    Polynomial.C (r*(m+2)*1024)*(Polynomial.C (r+1)*(2*Polynomial.X+2)+1)^2

theorem listStoredVertexFloorWidthsWork_input_polynomial (C : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m)
    (hC : ∀ i j,(rectangularListFractionMatrix C i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) :
    listStoredVertexFloorWidthsWork C V≤
      (storedVertexFloorWidthsPolynomial r m).eval (listStoredRationalBits C+listStoredRationalBits V) := by
  let L := listStoredRationalBits C+listStoredRationalBits V
  have hbitsC : ∀ i j,(rectangularListFractionMatrix C i j).numerator.length≤L ∧
      (rectangularListFractionMatrix C i j).denominator.length≤L := by
    intro i j
    have h : (rectangularListFractionMatrix C i j).numerator.length≤listStoredRationalBits C ∧
        (rectangularListFractionMatrix C i j).denominator.length≤listStoredRationalBits C := listStoredRationalBits_cell C i j
    exact ⟨h.1.trans (Nat.le_add_right _ _),h.2.trans (Nat.le_add_right _ _)⟩
  have hbitsV : ∀ i j,(rectangularListFractionMatrix V i j).numerator.length≤L ∧
      (rectangularListFractionMatrix V i j).denominator.length≤L := by
    intro i j
    have h : (rectangularListFractionMatrix V i j).numerator.length≤listStoredRationalBits V ∧
        (rectangularListFractionMatrix V i j).denominator.length≤listStoredRationalBits V := listStoredRationalBits_cell V i j
    exact ⟨h.1.trans (Nat.le_add_left _ _),h.2.trans (Nat.le_add_left _ _)⟩
  have hs := listMatrixFloorWidthScanWork_bound (constructedListMatrixMul C V)
    (constructedListMatrixMul_wellFormed C V hC hV) ((r+1)*(2*L+2)) (by positivity)
    (constructedListMatrixMul_lengths C V hC hV L hbitsC hbitsV)
  have hm := constructedListMatrixMulWork_input_polynomial C V hC hV
  change constructedListMatrixMulWork C V≤(constructedMatrixMulPolynomial r r m).eval L at hm
  unfold listStoredVertexFloorWidthsWork
  simp only [storedVertexFloorWidthsPolynomial,Polynomial.eval_add,Polynomial.eval_C,
    Polynomial.eval_mul,Polynomial.eval_ofNat,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_pow]
  change _≤(constructedMatrixMulPolynomial r r m).eval L+(2*r+2)+r*(m+2)*1024*((r+1)*(2*L+2)+1)^2
  omega
end Optss
