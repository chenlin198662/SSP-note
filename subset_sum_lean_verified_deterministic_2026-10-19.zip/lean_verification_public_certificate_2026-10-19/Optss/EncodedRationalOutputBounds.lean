import Optss.EncodedRationalReduction
import Optss.RationalInputHeight

/-!
# Output lengths and unscaling work for the encoded rational algorithm

Every integer returned before unscaling has a polynomial number of stored
bits. The common denominator has the original input-product length bound.
Consequently the actual final Boolean gcd/division normalization, summed over
all output entries, has polynomial scalar gate/list cost as well.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

private theorem outputLength_get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

theorem bitListClearRationalInput_canonical (A : BitRationalMatrixData r d) :
    EncodedIntegerCanonical (bitListClearRationalInput A).2 := by
  intro i j
  simp only [bitListClearRationalInput, outputLength_get_ofFn]
  change BitListCanonical (bitListMultiplication _ _)
  unfold BitListCanonical
  rw [bitListMultiplication_correct, bitListMultiplication_eq_bits]

theorem encodedIntegerReduction_output_lengths (D : BitIntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (bitIntegerMatrixValue D i j:ℝ)))
    (hC : EncodedIntegerCanonical D) (L : ℕ)
    (hL : ∀ i j, ((D.get i).get j).digits.length ≤ L) (i : Fin r) (j : Fin d) :
    ((((encodedIntegerReduction D).rows.get i).get j).digits).length ≤
      (r*(r+1)+1)*(r.size+d.size+2*(L+1)+4) := by
  have hH : ∀ i j, |bitIntegerMatrixValue D i j| ≤ (2^L:ℕ) := by
    intro i j
    rw [← Int.natCast_natAbs, bitIntegerMatrixValue, BitListInteger.value, signedBitsValue_natAbs]
    apply Int.ofNat_le.mpr
    exact (binaryDigitsValue_lt_pow _).le.trans (Nat.pow_le_pow_right (by omega) (hL i j))
  have hb := (executableIntegerReduction (bitIntegerMatrixValue D) hD).entry_bits_bound
    (bitIntegerMatrixValue D) (2^L) hH i j
  have he := congrArg Prod.fst (encodedIntegerReduction_value D hD)
  dsimp only [Prod.fst] at he
  change ((executableReductionFuel (gramPotential (bitIntegerMatrixValue D))
    (bitIntegerMatrixValue D)).1 i j).natAbs.size ≤ _ at hb
  rw [← he] at hb
  have hc := encodedReductionFuel_canonical (bitMatrixReductionFuel D) D hC i j
  have hlen : ((((encodedIntegerReduction D).rows.get i).get j).digits).length =
      (bitIntegerMatrixValue (encodedIntegerReduction D).rows i j).natAbs.size := by
    rw [bitIntegerMatrixValue, BitListInteger.value, signedBitsValue_natAbs]
    exact hc.length
  rw [hlen]
  apply hb.trans
  apply Nat.mul_le_mul_left
  simpa only [Nat.size_pow] using latticeHeightBase_bits r d (2^L)

/-- One polynomial envelope for both inputs to every output normalizer. -/
def rationalOutputUnscaleBits (r d L : ℕ) : ℕ :=
  (r*(r+1)+1)*(r.size+d.size+2*((r*d+1)*L+2)+4)+r*d*L+1

theorem encodedRationalUnscale_operand_lengths (A : BitRationalMatrixData r d)
    (hWF : ∀ i j, ((A.get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows A i j:ℝ)))
    (L : ℕ) (hL : ∀ i j, ((A.get i).get j).numerator.length ≤ L ∧
      ((A.get i).get j).denominator.length ≤ L) :
    let cleared := bitListClearRationalInput A
    let out := encodedIntegerReduction cleared.2
    cleared.1.length ≤ rationalOutputUnscaleBits r d L ∧
      ∀ i j, ((out.rows.get i).get j).digits.length ≤ rationalOutputUnscaleBits r d L := by
  let D := (bitListClearRationalInput A).2
  have hD : LinearIndependent ℝ (fun i j => (bitIntegerMatrixValue D i j:ℝ)) := by
    dsimp only [D]
    rw [bitListClearRationalInput_semantics A hWF]
    exact clearRationalInput_independent _ hA
  have hc := bitListClearRationalInput_canonical A
  have hl := bitListClearRationalInput_lengths A L hL
  have hd := bitRationalInputDenominator_length A L (fun i j => (hL i j).2)
  constructor
  · exact hd.trans (by unfold rationalOutputUnscaleBits; omega)
  · intro i j
    have ho := encodedIntegerReduction_output_lengths D hD hc ((r*d+1)*L+1) hl i j
    exact ho.trans (by
      unfold rationalOutputUnscaleBits
      simp only [Nat.add_assoc, Nat.reduceAdd]
      omega)

def encodedRationalUnscaleWork (A : BitRationalMatrixData r d) : ℕ :=
  let cleared := bitListClearRationalInput A
  let out := encodedIntegerReduction cleared.2
  ∑ i : Fin r, ∑ j : Fin d,
    bitListNormalizeFractionCost ((out.rows.get i).get j).digits cleared.1

/-- Actual scalar cost of normalizing all output fractions. -/
theorem encodedRationalUnscaleWork_bound (A : BitRationalMatrixData r d)
    (hWF : ∀ i j, ((A.get i).get j).WellFormed)
    (hA : LinearIndependent ℝ (fun i j => (encodedFractionRows A i j:ℝ)))
    (L : ℕ) (hL : ∀ i j, ((A.get i).get j).numerator.length ≤ L ∧
      ((A.get i).get j).denominator.length ≤ L) :
    encodedRationalUnscaleWork A ≤ r*d*(128*(rationalOutputUnscaleBits r d L+1)^3) := by
  have hl := encodedRationalUnscale_operand_lengths A hWF hA L hL
  have hp := bitRationalInputDenominator_positive A (fun i j => (hWF i j).2.2.1)
  unfold encodedRationalUnscaleWork
  dsimp only
  calc
    _ ≤ ∑ _i : Fin r, ∑ _j : Fin d, 128*(rationalOutputUnscaleBits r d L+1)^3 := by
      apply Finset.sum_le_sum
      intro i _
      apply Finset.sum_le_sum
      intro j _
      exact bitListNormalizeFractionCost_bound _ _ hp _ (hl.2 i j) hl.1
    _ = _ := by simp; ring

end Optss
