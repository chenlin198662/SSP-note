import Optss.PackedConvolution
import Mathlib.Algebra.MvPolynomial.Basic
import Mathlib.Algebra.MonoidAlgebra.MapDomain
import Mathlib.Algebra.Polynomial.Degree.Support

/-!
# Padded multivariate convolution by integer packing

Mixed-radix positions use the full product output box. The encoding is additive
and is injective on that box, so it cannot confuse carries between coordinate
exponents with polynomial coefficients. This is the fixed-dimensional padding
step of Lemma 10.1. Arithmetic correctness is separate from multiplication time.
-/

namespace Optss
open scoped BigOperators Pointwise
noncomputable section

/-- Row-major index with the first coordinate least significant. -/
def boxIndex : {d : ℕ} → (Fin d → ℕ) → (Fin d → ℕ) → ℕ
  | 0, _, _ => 0
  | _ + 1, m, x => x 0 + (m 0 + 1) * boxIndex (fun i => m i.succ) (fun i => x i.succ)

@[simp] theorem boxIndex_zero {d : ℕ} (m : Fin d → ℕ) : boxIndex m 0 = 0 := by
  induction d with
  | zero => rfl
  | succ d ih =>
    have ht := ih (fun i => m i.succ)
    change boxIndex (fun i => m i.succ) (fun _ => 0) = 0 at ht
    simp only [boxIndex, Pi.zero_apply, ht, mul_zero, add_zero]

theorem boxIndex_add {d : ℕ} (m x y : Fin d → ℕ) :
    boxIndex m (x + y) = boxIndex m x + boxIndex m y := by
  induction d with
  | zero => simp [boxIndex]
  | succ d ih =>
    simp only [boxIndex, Pi.add_apply]
    have ht := ih (fun i => m i.succ) (fun i => x i.succ) (fun i => y i.succ)
    change boxIndex (fun i => m i.succ) (fun i => x i.succ + y i.succ) = _ at ht
    rw [ht]
    ring

/-- The number of array entries includes every zero-width coordinate. -/
def boxVolume {d : ℕ} (m : Fin d → ℕ) : ℕ := ∏ i, (m i + 1)

theorem boxVolume_pos {d : ℕ} (m : Fin d → ℕ) : 0 < boxVolume m := by
  exact Finset.prod_pos (fun i _ => Nat.zero_lt_succ (m i))

theorem boxIndex_lt {d : ℕ} (m x : Fin d → ℕ) (hx : ∀ i, x i ≤ m i) :
    boxIndex m x < boxVolume m := by
  induction d with
  | zero => simp [boxIndex, boxVolume]
  | succ d ih =>
    have ht := ih (fun i => m i.succ) (fun i => x i.succ) (fun i => hx i.succ)
    have hh := hx 0
    simp only [boxIndex, boxVolume, Fin.prod_univ_succ] at *
    nlinarith

theorem boxIndex_injOn {d : ℕ} (m : Fin d → ℕ) :
    Set.InjOn (boxIndex m) {x | ∀ i, x i ≤ m i} := by
  intro x hx y hy he
  induction d with
  | zero => exact Subsingleton.elim _ _
  | succ d ih =>
    have head : x 0 = y 0 := by
      have := congrArg (fun n => n % (m 0 + 1)) he
      simpa only [boxIndex, Nat.add_mul_mod_self_left,
        Nat.mod_eq_of_lt (Nat.lt_succ_of_le (hx 0)),
        Nat.mod_eq_of_lt (Nat.lt_succ_of_le (hy 0))] using this
    have tail : boxIndex (fun i => m i.succ) (fun i => x i.succ) =
        boxIndex (fun i => m i.succ) (fun i => y i.succ) := by
      simp only [boxIndex, head] at he
      exact Nat.eq_of_mul_eq_mul_left (Nat.zero_lt_succ _) (Nat.add_left_cancel he)
    have ht := ih (fun i => m i.succ) (fun i => hx i.succ) (fun i => hy i.succ) tail
    funext i
    exact Fin.cases head (fun j => congrFun ht j) i

/-- The index is additive before any restriction on exponent vectors. -/
def boxExponentIndex {d : ℕ} (m : Fin d → ℕ) : (Fin d →₀ ℕ) →+ ℕ where
  toFun e := boxIndex m e
  map_zero' := boxIndex_zero m
  map_add' e f := boxIndex_add m e f

def polynomialInBox {d : ℕ} {R : Type*} [CommSemiring R]
    (m : Fin d → ℕ) (p : MvPolynomial (Fin d) R) : Prop :=
  ∀ e ∈ p.support, ∀ j, e j ≤ m j

/-- Kronecker substitution as a ring homomorphism. -/
def flattenPolynomial {d : ℕ} (R : Type*) [CommSemiring R] (m : Fin d → ℕ) :
    MvPolynomial (Fin d) R →+* Polynomial R :=
  (Polynomial.toFinsuppIso R).symm.toRingHom.comp
    (AddMonoidAlgebra.mapDomainRingHom R (boxExponentIndex m))

theorem flattenPolynomial_coeff {d : ℕ} {R : Type*} [CommSemiring R]
    (m : Fin d → ℕ) (p : MvPolynomial (Fin d) R) (hp : polynomialInBox m p)
    (e : Fin d →₀ ℕ) (he : ∀ j, e j ≤ m j) :
    (flattenPolynomial R m p).coeff (boxIndex m e) = p.coeff e := by
  change Finsupp.mapDomain (boxExponentIndex m) p ((boxExponentIndex m) e) = p.coeff e
  apply Finsupp.mapDomain_apply' {e : Fin d →₀ ℕ | ∀ j, e j ≤ m j} p hp _ he
  intro a ha b hb hab
  apply Finsupp.ext
  exact congrFun (boxIndex_injOn m ha hb hab)

theorem polynomialInBox_mul {d : ℕ} {R : Type*} [CommSemiring R]
    (m n : Fin d → ℕ) (p q : MvPolynomial (Fin d) R)
    (hp : polynomialInBox m p) (hq : polynomialInBox n q) :
    polynomialInBox (m + n) (p * q) := by
  intro e he
  obtain ⟨a, ha, b, hb, rfl⟩ := Finset.mem_add.mp (MvPolynomial.support_mul p q he)
  intro j
  exact Nat.add_le_add (hp a ha j) (hq b hb j)

/-- Product coefficients survive the padded substitution exactly. -/
theorem flattenPolynomial_mul_coeff {d : ℕ} {R : Type*} [CommSemiring R]
    (m n : Fin d → ℕ) (p q : MvPolynomial (Fin d) R)
    (hp : polynomialInBox m p) (hq : polynomialInBox n q)
    (e : Fin d →₀ ℕ) (he : ∀ j, e j ≤ m j + n j) :
    (flattenPolynomial R (m + n) p * flattenPolynomial R (m + n) q).coeff
      (boxIndex (m + n) e) = (p * q).coeff e := by
  rw [← map_mul]
  exact flattenPolynomial_coeff (m + n) (p * q) (polynomialInBox_mul m n p q hp hq) e he


theorem polynomialInBox_mono {d : ℕ} {R : Type*} [CommSemiring R]
    {m n : Fin d → ℕ} (hmn : ∀ j, m j ≤ n j) {p : MvPolynomial (Fin d) R}
    (hp : polynomialInBox m p) : polynomialInBox n p :=
  fun e he j => (hp e he j).trans (hmn j)

/-- Every nonzero flattened coefficient came from an actual input exponent. -/
theorem mem_flattenPolynomial_support {d : ℕ} {R : Type*} [CommSemiring R]
    (m : Fin d → ℕ) (p : MvPolynomial (Fin d) R) {k : ℕ}
    (hk : k ∈ (flattenPolynomial R m p).support) :
    ∃ e ∈ p.support, boxIndex m e = k := by
  change k ∈ (Finsupp.mapDomain (boxExponentIndex m) p).support at hk
  exact Finset.mem_image.mp (Finsupp.mapDomain_support hk)

/-- The flattened input fits in the array with the advertised number of cells. -/
theorem flattenPolynomial_natDegree_lt {d : ℕ} {R : Type*} [CommSemiring R]
    (m : Fin d → ℕ) (p : MvPolynomial (Fin d) R) (hp : polynomialInBox m p) :
    (flattenPolynomial R m p).natDegree < boxVolume m := by
  by_cases hz : flattenPolynomial R m p = 0
  · simpa [hz] using boxVolume_pos m
  · obtain ⟨e, he, hindex⟩ := mem_flattenPolynomial_support m p
      (Polynomial.natDegree_mem_support_of_nonzero hz)
    rw [← hindex]
    exact boxIndex_lt m e (hp e he)

/-- Injection on the exponent box prevents coefficient accumulation in the
flattened input, so the original coefficient maximum is preserved. -/
theorem flattenPolynomial_coeff_le {d : ℕ} (m : Fin d → ℕ)
    (p : MvPolynomial (Fin d) ℕ) (hp : polynomialInBox m p) (A : ℕ)
    (hA : ∀ e, p.coeff e ≤ A) (k : ℕ) :
    (flattenPolynomial ℕ m p).coeff k ≤ A := by
  by_cases hk : k ∈ (flattenPolynomial ℕ m p).support
  · obtain ⟨e, he, rfl⟩ := mem_flattenPolynomial_support m p hk
    rw [flattenPolynomial_coeff m p hp e (hp e he)]
    exact hA e
  · have hz := Polynomial.not_mem_support_iff.mp hk
    rw [hz]
    exact Nat.zero_le A

/-- Exact multivariate convolution and both input encoding bounds, reduced to
one natural-number multiplication. Padding uses the sum of the input widths,
not just their retained/truncation box. -/
theorem multivariate_packed_convolution {d : ℕ} (m n : Fin d → ℕ)
    (p q : MvPolynomial (Fin d) ℕ) (hp : polynomialInBox m p)
    (hq : polynomialInBox n q) (A C : ℕ)
    (hA : ∀ e, p.coeff e ≤ A) (hC : ∀ e, q.coeff e ≤ C) :
    let V := boxVolume (m + n)
    let b := V * (A + 1) * (C + 1) + 1
    let P := flattenPolynomial ℕ (m + n) p
    let Q := flattenPolynomial ℕ (m + n) q
    (P.eval b).size ≤ V * b.size ∧ (Q.eval b).size ≤ V * b.size ∧
      ∀ e : Fin d →₀ ℕ, (∀ j, e j ≤ m j + n j) →
        (P.eval b * Q.eval b) / b ^ boxIndex (m + n) e % b = (p * q).coeff e := by
  dsimp only
  have hp' : polynomialInBox (m + n) p :=
    polynomialInBox_mono (fun j => Nat.le_add_right (m j) (n j)) hp
  have hq' : polynomialInBox (m + n) q :=
    polynomialInBox_mono (fun j => Nat.le_add_left (n j) (m j)) hq
  obtain ⟨hbitsP, hbitsQ, hprod⟩ := packed_convolution_with_encoding_bounds
    (flattenPolynomial ℕ (m + n) p) (flattenPolynomial ℕ (m + n) q)
    (boxVolume (m + n)) (boxVolume (m + n)) A C
    (flattenPolynomial_natDegree_lt _ p hp') (flattenPolynomial_natDegree_lt _ q hq')
    (flattenPolynomial_coeff_le _ p hp' A hA) (flattenPolynomial_coeff_le _ q hq' C hC)
  refine ⟨hbitsP, hbitsQ, ?_⟩
  intro e he
  rw [hprod]
  exact flattenPolynomial_mul_coeff m n p q hp hq e he

/-- Doubling each width increases the array length by at most a factor `2^d`,
including any zero-width coordinates. -/
theorem padded_boxVolume_le {d : ℕ} (m : Fin d → ℕ) :
    boxVolume (m + m) ≤ 2 ^ d * boxVolume m := by
  calc
    boxVolume (m + m) ≤ ∏ j, (2 * (m j + 1)) := by
      apply Finset.prod_le_prod
      · intro j _; exact Nat.zero_le _
      · intro j _; simp only [Pi.add_apply]; omega
    _ = 2 ^ d * boxVolume m := by
      rw [Finset.prod_mul_distrib]
      simp [boxVolume]

end
end Optss
