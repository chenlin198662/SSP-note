import Optss.BitListModularPower

/-!
# Bit work of the computed modular power

These source counters sum the actual Boolean multiplication and division
circuits and list visits. Intermediate residues are bounded by the modulus,
so every arithmetic width follows from the original input lists.
-/
namespace Optss

def bitListModMulWork (xs ys qs : List Bool) : ℕ :=
  bitListMultiplicationGates xs ys+bitListMultiplicationVisits xs ys+
    bitListDivisionBitWork (bitListMultiplication xs ys) qs+3

theorem bitListModMulWork_bound (xs ys qs : List Bool) (L : ℕ)
    (hq : 0<binaryDigitsValue qs) (hx : xs.length≤L) (hy : ys.length≤L)
    (hql : qs.length≤L) : bitListModMulWork xs ys qs≤128*(L+1)^2 := by
  have hm := bitListMultiplication_uniform_cost xs ys L hx hy
  have hd := bitListDivisionBitWork_bound (bitListMultiplication xs ys) qs hq
  have hl := bitListMultiplication_length_le xs ys
  have hd' : 16*((bitListMultiplication xs ys).length+1)*(qs.length+1)≤
      16*(2*L+1)*(L+1) := by gcongr <;> omega
  unfold bitListModMulWork
  nlinarith

def bitListModPowWork (xs qs : List Bool) : List Bool → ℕ
  | [] => bitListDivisionBitWork [true] qs+1
  | b::bs =>
    let prev := bitListModPow xs qs bs
    let sq := bitListModMul prev prev qs
    bitListModPowWork xs qs bs+bitListModMulWork prev prev qs+
      (if b then bitListModMulWork sq xs qs else 0)+4

theorem bitListModPowWork_bound (xs qs es : List Bool) (L : ℕ)
    (hq : 0<binaryDigitsValue qs) (hx : xs.length≤L) (hql : qs.length≤L) :
    bitListModPowWork xs qs es≤300*(es.length+1)*(L+1)^2 := by
  induction es with
  | nil =>
    have hd := bitListDivisionBitWork_bound [true] qs hq
    simp only [List.length_cons,List.length_nil] at hd
    simp only [bitListModPowWork,List.length_nil]
    nlinarith [sq_nonneg (L:ℤ)]
  | cons b bs ih =>
    have hp := (bitListModPow_width xs qs bs hq).trans hql
    have hs := (bitListModMul_width (bitListModPow xs qs bs)
      (bitListModPow xs qs bs) qs hq).trans hql
    have hm := bitListModMulWork_bound (bitListModPow xs qs bs)
      (bitListModPow xs qs bs) qs L hq hp hp hql
    have hm' := bitListModMulWork_bound
      (bitListModMul (bitListModPow xs qs bs) (bitListModPow xs qs bs) qs)
      xs qs L hq hs hx hql
    cases b <;> simp only [bitListModPowWork,Bool.false_eq_true,if_false,if_true,
      List.length_cons,add_zero] <;> nlinarith

/-- Cubic bit work when the input residue fits within the modulus bit width. -/
theorem bitListPrimeInverse_bitWork (xs : List Bool) (q : ℕ) (hq : 0<q)
    (hx : xs.length≤q.size) :
    bitListModPowWork xs q.bits (q-2).bits≤300*(q.size+1)^3 := by
  have he : (q-2).bits.length≤q.size := by
    rw [Nat.size_eq_bits_len]
    exact Nat.size_le_size (Nat.sub_le _ _)
  have h := bitListModPowWork_bound xs q.bits (q-2).bits q.size
    (by simpa only [binaryDigitsValue_bits] using hq) hx
    (by rw [Nat.size_eq_bits_len])
  calc
    _≤300*((q-2).bits.length+1)*(q.size+1)^2 := h
    _≤300*(q.size+1)*(q.size+1)^2 := by gcongr
    _=300*(q.size+1)^3 := by ring

end Optss
