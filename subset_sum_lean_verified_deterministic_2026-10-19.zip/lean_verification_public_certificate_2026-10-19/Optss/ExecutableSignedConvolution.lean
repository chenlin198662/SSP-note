import Optss.ExecutablePackedConvolution

/-!
# Executable signed packed convolution

Split each integer list into its positive and negative magnitudes, run four
proved natural packed convolutions, and combine their decoded arrays with the
correct signs. Every carry base is computed by the natural backend.
-/

namespace Optss.ExecutablePackedConvolution

open scoped BigOperators

/-- Positive and negative magnitudes retain the original coefficient positions. -/
def positive (xs : List ℤ) : List ℕ := xs.map Int.toNat

def negative (xs : List ℤ) : List ℕ := xs.map (fun z => (-z).toNat)

@[simp] theorem positive_getD (xs : List ℤ) (i : ℕ) :
    (positive xs).getD i 0 = (xs.getD i 0).toNat := by
  simpa only [positive, Int.toNat_zero] using List.getD_map xs 0 Int.toNat (n := i)

@[simp] theorem negative_getD (xs : List ℤ) (i : ℕ) :
    (negative xs).getD i 0 = (-(xs.getD i 0)).toNat := by
  simpa only [negative, neg_zero, Int.toNat_zero] using
    List.getD_map xs 0 (fun z : ℤ => (-z).toNat) (n := i)

theorem signed_digit_split (xs : List ℤ) (i : ℕ) :
    ((positive xs).getD i 0 : ℤ) - ((negative xs).getD i 0 : ℤ) = xs.getD i 0 := by
  rw [positive_getD, negative_getD]
  exact Int.toNat_sub_toNat_neg _

/-- Standard signed integer convolution, with zero-padding at every index. -/
def signedCoefficient (xs ys : List ℤ) (i : ℕ) : ℤ :=
  ∑ ab ∈ Finset.antidiagonal i, xs.getD ab.1 0 * ys.getD ab.2 0

/-- Four nonnegative products exactly recover the signed convolution. -/
theorem signedCoefficient_split (xs ys : List ℤ) (i : ℕ) :
    (coefficient (positive xs) (positive ys) i : ℤ) -
      (coefficient (positive xs) (negative ys) i : ℤ) -
      (coefficient (negative xs) (positive ys) i : ℤ) +
      (coefficient (negative xs) (negative ys) i : ℤ) = signedCoefficient xs ys i := by
  simp only [coefficient, signedCoefficient, Nat.cast_sum, Nat.cast_mul,
    ← Finset.sum_sub_distrib, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro ab _
  calc
    _ = (((positive xs).getD ab.1 0 : ℤ) - ((negative xs).getD ab.1 0 : ℤ)) *
        (((positive ys).getD ab.2 0 : ℤ) - ((negative ys).getD ab.2 0 : ℤ)) := by ring
    _ = _ := by rw [signed_digit_split, signed_digit_split]

/-- Materialize four products once and combine already decoded coefficients.
No polynomial, coefficient oracle, or classical choice runs in this function. -/
def convolveSigned (xs ys : List ℤ) : List ℤ :=
  let xp := positive xs
  let xn := negative xs
  let yp := positive ys
  let yn := negative ys
  let pp := (convolve xp yp).toArray
  let pn := (convolve xp yn).toArray
  let np := (convolve xn yp).toArray
  let nn := (convolve xn yn).toArray
  List.ofFn (fun i : Fin (outputLength xs ys) =>
    (pp[i.val]?.getD 0 : ℤ) - (pn[i.val]?.getD 0 : ℤ) -
      (np[i.val]?.getD 0 : ℤ) + (nn[i.val]?.getD 0 : ℤ))

@[simp] theorem convolveSigned_length (xs ys : List ℤ) :
    (convolveSigned xs ys).length = outputLength xs ys := by simp [convolveSigned]

theorem convolveSigned_getD_lt (xs ys : List ℤ) (i : ℕ)
    (hi : i < outputLength xs ys) :
    (convolveSigned xs ys).getD i 0 = signedCoefficient xs ys i := by
  unfold convolveSigned
  rw [List.getD_eq_getElem _ _ (by simpa using hi), List.getElem_ofFn]
  simp only [List.getElem?_toArray, ← List.getD_eq_getElem?_getD, convolve_getD]
  exact signedCoefficient_split xs ys i

theorem signedCoefficient_eq_zero_of_ge (xs ys : List ℤ) (i : ℕ)
    (hi : outputLength xs ys ≤ i) : signedCoefficient xs ys i = 0 := by
  cases xs with
  | nil => simp [signedCoefficient]
  | cons x xs =>
      cases ys with
      | nil => simp [signedCoefficient]
      | cons y ys =>
          apply Finset.sum_eq_zero
          intro ab hab
          have habsum := Finset.mem_antidiagonal.mp hab
          dsimp only [outputLength] at hi
          by_cases hx : ab.1 < (x :: xs).length
          · have hy : (y :: ys).length ≤ ab.2 := by
              simp only [List.length_cons] at hx ⊢
              omega
            rw [List.getD_eq_default _ _ hy]
            simp
          · rw [List.getD_eq_default _ _ (Nat.le_of_not_gt hx)]
            simp

/-- Exact signed coefficient equality for every index, including missing cells. -/
theorem convolveSigned_getD (xs ys : List ℤ) (i : ℕ) :
    (convolveSigned xs ys).getD i 0 = signedCoefficient xs ys i := by
  by_cases hi : i < outputLength xs ys
  · exact convolveSigned_getD_lt xs ys i hi
  · rw [List.getD_eq_default _ _ (by simpa using (Nat.le_of_not_gt hi)),
      signedCoefficient_eq_zero_of_ge xs ys i (Nat.le_of_not_gt hi)]

/-- Cancellation-sensitive support is tested on the exact signed convolution. -/
theorem convolveSigned_nonzero_iff (xs ys : List ℤ) (i : ℕ) :
    (convolveSigned xs ys).getD i 0 ≠ 0 ↔ signedCoefficient xs ys i ≠ 0 := by
  rw [convolveSigned_getD]

/-- Packing and digit-extraction steps in the four executed natural products.
Sign splitting, array conversion, and the final entrywise combination are
separate linear passes; integer bit costs are not included in this counter. -/
def signedDigitSteps (xs ys : List ℤ) : ℕ :=
  digitSteps (positive xs) (positive ys) + digitSteps (positive xs) (negative ys) +
    digitSteps (negative xs) (positive ys) + digitSteps (negative xs) (negative ys)

theorem signedDigitSteps_le (xs ys : List ℤ) :
    signedDigitSteps xs ys ≤ 8 * (xs.length + ys.length) := by
  have hpp := digitSteps_le (positive xs) (positive ys)
  have hpn := digitSteps_le (positive xs) (negative ys)
  have hnp := digitSteps_le (negative xs) (positive ys)
  have hnn := digitSteps_le (negative xs) (negative ys)
  simp only [positive, negative, List.length_map] at hpp hpn hnp hnn
  simp only [signedDigitSteps, positive, negative]
  omega

/-- An array-facing interface with the same concrete signed implementation. -/
def convolveSignedArray (xs ys : Array ℤ) : Array ℤ :=
  (convolveSigned xs.toList ys.toList).toArray

theorem convolveSignedArray_getD (xs ys : Array ℤ) (i : ℕ) :
    (convolveSignedArray xs ys)[i]?.getD 0 = signedCoefficient xs.toList ys.toList i := by
  simpa only [convolveSignedArray, List.getElem?_toArray, ← List.getD_eq_getElem?_getD]
    using convolveSigned_getD xs.toList ys.toList i

end Optss.ExecutablePackedConvolution
