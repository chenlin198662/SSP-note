import Optss.BitListRationalOperations
import Mathlib.Data.Rat.Floor

/-!
# Boolean comparison and rounding of encoded rationals

Comparison uses signed cross products. Rounding is exactly floor after adding
one half, so negative half ties follow mathlib's convention toward positive
infinity. Only Boolean-list arithmetic computes returned answers.
-/

namespace Optss

theorem bitListTrim_isEmpty_iff (xs : List Bool) :
    (bitListTrim xs).isEmpty = true ↔ binaryDigitsValue xs = 0 := by
  constructor
  · intro h
    have he := bitListTrim_value xs
    rw [List.isEmpty_iff.mp h] at he
    exact he.symm
  · intro h
    apply List.isEmpty_iff.mpr
    rw [bitListTrim_eq_bits, h, Nat.zero_bits]

/-- Signed integer comparison, including either sign of zero and high zeros. -/
def bitListSignedLE (s t : Bool) (xs ys : List Bool) : Bool :=
  if s = t then if s then bitListLE ys xs else bitListLE xs ys
  else if s then true else (bitListTrim xs).isEmpty && (bitListTrim ys).isEmpty

theorem bitListSignedLE_correct (s t : Bool) (xs ys : List Bool) :
    bitListSignedLE s t xs ys = true ↔ signedBitsValue s xs ≤ signedBitsValue t ys := by
  cases s <;> cases t <;> simp [bitListSignedLE, signedBitsValue, bitListLE_correct,
    bitListTrim_isEmpty_iff]
  simp only [← List.isEmpty_iff, bitListTrim_isEmpty_iff]
  omega

def bitListFractionLE (p q : BitListFraction) : Bool :=
  bitListSignedLE p.negative q.negative
    (bitListMultiplication p.numerator q.denominator)
    (bitListMultiplication q.numerator p.denominator)

def bitListFractionLT (p q : BitListFraction) : Bool := !(bitListFractionLE q p)

theorem bitListFractionLE_correct (p q : BitListFraction)
    (hp : 0 < binaryDigitsValue p.denominator) (hq : 0 < binaryDigitsValue q.denominator) :
    bitListFractionLE p q = true ↔ bitListFractionValue p ≤ bitListFractionValue q := by
  rw [bitListFractionLE, bitListSignedLE_correct, signedBitsValue_mul_right, signedBitsValue_mul_right]
  have hp' : (0:ℚ) < binaryDigitsValue p.denominator := by exact_mod_cast hp
  have hq' : (0:ℚ) < binaryDigitsValue q.denominator := by exact_mod_cast hq
  unfold bitListFractionValue
  rw [div_le_div_iff₀ hp' hq']
  exact_mod_cast (Iff.rfl :
    signedBitsValue p.negative p.numerator*(binaryDigitsValue q.denominator:ℤ) ≤
      signedBitsValue q.negative q.numerator*(binaryDigitsValue p.denominator:ℤ) ↔ _)

theorem bitListFractionLT_correct (p q : BitListFraction)
    (hp : 0 < binaryDigitsValue p.denominator) (hq : 0 < binaryDigitsValue q.denominator) :
    bitListFractionLT p q = true ↔ bitListFractionValue p < bitListFractionValue q := by
  have h := bitListFractionLE_correct q p hq hp
  unfold bitListFractionLT
  cases he : bitListFractionLE q p <;> simp_all

/-- Gate/list work for the signed comparison branches. -/
def bitListSignedLECost (s t : Bool) (xs ys : List Bool) : ℕ :=
  if s = t then bitListRippleGates 8 xs ys+bitListSubVisits xs ys+3
  else if s then 2 else bitListTrimVisits xs+bitListTrimVisits ys+3

theorem bitListSignedLECost_bound (s t : Bool) (xs ys : List Bool) (L : ℕ)
    (hx : xs.length ≤ L) (hy : ys.length ≤ L) : bitListSignedLECost s t xs ys ≤ 16*(L+1) := by
  have hm : max xs.length ys.length ≤ L := max_le hx hy
  simp only [bitListSignedLECost, bitListRippleGates_eq, bitListSubVisits_eq, bitListTrimVisits_eq]
  split_ifs <;> omega

def bitListFractionLECost (p q : BitListFraction) : ℕ :=
  bitListProductWork p.numerator q.denominator+bitListProductWork q.numerator p.denominator+
    bitListSignedLECost p.negative q.negative (bitListMultiplication p.numerator q.denominator)
      (bitListMultiplication q.numerator p.denominator)

def bitListFractionLTCost (p q : BitListFraction) : ℕ := bitListFractionLECost q p+1

theorem bitListFractionLECost_bound (p q : BitListFraction) (L : ℕ)
    (hp : p.numerator.length ≤ L ∧ p.denominator.length ≤ L)
    (hq : q.numerator.length ≤ L ∧ q.denominator.length ≤ L) :
    bitListFractionLECost p q ≤ 128*(L+1)^2 := by
  have h₁ := bitListMultiplication_uniform_cost p.numerator q.denominator L hp.1 hq.2
  have h₂ := bitListMultiplication_uniform_cost q.numerator p.denominator L hq.1 hp.2
  have hx : (bitListMultiplication p.numerator q.denominator).length ≤ 2*L :=
    (bitListMultiplication_length_le _ _).trans (by omega)
  have hy : (bitListMultiplication q.numerator p.denominator).length ≤ 2*L :=
    (bitListMultiplication_length_le _ _).trans (by omega)
  have h₃ := bitListSignedLECost_bound p.negative q.negative _ _ (2*L) hx hy
  unfold bitListFractionLECost bitListProductWork
  nlinarith

theorem bitListFractionLTCost_bound (p q : BitListFraction) (L : ℕ)
    (hp : p.numerator.length ≤ L ∧ p.denominator.length ≤ L)
    (hq : q.numerator.length ≤ L ∧ q.denominator.length ≤ L) :
    bitListFractionLTCost p q ≤ 256*(L+1)^2 := by
  have h := bitListFractionLECost_bound q p L hq hp
  unfold bitListFractionLTCost
  nlinarith

/-- Floor returns a Boolean sign and canonical magnitude. A negative rational
with nonzero remainder requires one extra unit of negative magnitude. -/
def bitListFractionFloor (p : BitListFraction) : Bool × List Bool :=
  let out := bitListDivision p.numerator p.denominator
  if p.negative then
    if out.remainder.isEmpty then (true,out.quotient)
    else (true,bitListAdd out.quotient [true])
  else (false,out.quotient)

theorem bitListFractionFloor_correct (p : BitListFraction)
    (hp : 0 < binaryDigitsValue p.denominator) :
    signedBitsValue (bitListFractionFloor p).1 (bitListFractionFloor p).2 =
      ⌊bitListFractionValue p⌋ := by
  have hq := (bitListDivision_correct p.numerator p.denominator hp).1
  have hr := (bitListDivision_correct p.numerator p.denominator hp).2
  have hc := bitListDivision_remainder_canonical p.numerator p.denominator hp
  unfold bitListFractionFloor
  dsimp only
  cases hs : p.negative
  · simp only [Bool.false_eq_true, ↓reduceIte, signedBitsValue, bitListFractionValue, hs]
    rw [Rat.floor_intCast_div_natCast, hq, Int.natCast_ediv]
  · simp only [↓reduceIte]
    split_ifs with hz
    · have hzero : binaryDigitsValue p.numerator % binaryDigitsValue p.denominator = 0 := by
        rw [List.isEmpty_iff.mp hz] at hr
        exact hr.symm
      have hdiv : (binaryDigitsValue p.denominator:ℤ) ∣ (binaryDigitsValue p.numerator:ℤ) := by
        exact_mod_cast Nat.dvd_of_mod_eq_zero hzero
      simp only [signedBitsValue, ↓reduceIte, bitListFractionValue, hs]
      rw [Rat.floor_intCast_div_natCast, Int.neg_ediv_of_dvd hdiv, hq, Int.natCast_ediv]
    · have hrp := hc.pos_of_not_empty hz
      have hnd : ¬ (binaryDigitsValue p.denominator:ℤ) ∣ (binaryDigitsValue p.numerator:ℤ) := by
        rw [Int.natCast_dvd_natCast]
        intro h
        have hh := Nat.mod_eq_zero_of_dvd h
        omega
      have hdp : (0:ℤ) < binaryDigitsValue p.denominator := by exact_mod_cast hp
      simp only [signedBitsValue, ↓reduceIte, bitListFractionValue, hs, bitListAdd_correct,
        binaryDigitsValue, Bool.toNat_true, mul_zero, zero_add]
      rw [Rat.floor_intCast_div_natCast, Int.neg_ediv, if_neg hnd,
        Int.sign_eq_one_of_pos hdp, hq, Int.natCast_add, Int.natCast_one, Int.natCast_ediv]
      ring

/-- Exact one-half, with canonical numerator and denominator lists. -/
def bitListFractionHalf : BitListFraction := ⟨false,[true],[false,true]⟩

theorem bitListFractionHalf_value : bitListFractionValue bitListFractionHalf = 1/2 := by
  norm_num [bitListFractionHalf, bitListFractionValue, signedBitsValue, binaryDigitsValue]

theorem bitListFractionHalf_den_pos : 0 < binaryDigitsValue bitListFractionHalf.denominator := by
  norm_num [bitListFractionHalf, binaryDigitsValue]

/-- Nearest-integer rounding uses pure encoded addition followed by floor.
Half ties are therefore resolved toward positive infinity, including negatives. -/
def bitListFractionRound (p : BitListFraction) : Bool × List Bool :=
  bitListFractionFloor (bitListFractionAdd p bitListFractionHalf)

theorem bitListFractionRound_correct (p : BitListFraction)
    (hp : 0 < binaryDigitsValue p.denominator) :
    signedBitsValue (bitListFractionRound p).1 (bitListFractionRound p).2 =
      round (bitListFractionValue p) := by
  rw [bitListFractionRound, bitListFractionFloor_correct _
    (bitListFractionAdd_wellFormed p bitListFractionHalf hp bitListFractionHalf_den_pos).2.2.1,
    bitListFractionAdd_correct _ _ hp bitListFractionHalf_den_pos, bitListFractionHalf_value, round_eq]

theorem bitListDivision_quotient_length_le (ns ds : List Bool) :
    (bitListDivision ns ds).quotient.length ≤ ns.length := by
  exact (bitListTrim_length_le _).trans_eq (bitListDivisionDigits_quotient_length ns ds)

theorem bitListNormalizeFraction_lengths (s : Bool) (ns ds : List Bool) :
    (bitListNormalizeFraction s ns ds).numerator.length ≤ ns.length ∧
      (bitListNormalizeFraction s ns ds).denominator.length ≤ ds.length :=
  ⟨bitListDivision_quotient_length_le _ _, bitListDivision_quotient_length_le _ _⟩

theorem bitListFractionAdd_lengths (p q : BitListFraction) (L : ℕ)
    (hp : p.numerator.length ≤ L ∧ p.denominator.length ≤ L)
    (hq : q.numerator.length ≤ L ∧ q.denominator.length ≤ L) :
    (bitListFractionAdd p q).numerator.length ≤ 2*L+1 ∧
      (bitListFractionAdd p q).denominator.length ≤ 2*L := by
  let x := bitListMultiplication p.numerator q.denominator
  let y := bitListMultiplication q.numerator p.denominator
  have hx : x.length ≤ 2*L := (bitListMultiplication_length_le _ _).trans (by omega)
  have hy : y.length ≤ 2*L := (bitListMultiplication_length_le _ _).trans (by omega)
  have hs := bitListSignedAdd_length p.negative q.negative x y
  have hd := bitListMultiplication_length_le p.denominator q.denominator
  have hn := bitListNormalizeFraction_lengths (bitListSignedAdd p.negative q.negative x y).1
    (bitListSignedAdd p.negative q.negative x y).2 (bitListMultiplication p.denominator q.denominator)
  change _ ≤ 2*L+1 ∧ _ ≤ 2*L
  exact ⟨hn.1.trans (by omega), hn.2.trans (by omega)⟩

/-- Floor's concrete work consists of one binary-list division and at most
one ripple increment. -/
def bitListFractionFloorCost (p : BitListFraction) : ℕ :=
  let out := bitListDivision p.numerator p.denominator
  bitListDivisionCost p.numerator p.denominator + if p.negative then
    if out.remainder.isEmpty then 2 else
      bitListRippleGates 6 out.quotient [true]+bitListAddVisits out.quotient [true]+
        bitListTrimVisits (bitListAddAux false out.quotient [true])+3
    else 1

theorem bitListFractionFloorCost_bound (p : BitListFraction)
    (hp : 0 < binaryDigitsValue p.denominator) (L : ℕ)
    (hpl : p.numerator.length ≤ L ∧ p.denominator.length ≤ L) :
    bitListFractionFloorCost p ≤ 64*(L+1)^2 := by
  have hd := bitListDivisionCost_uniform p.numerator p.denominator hp L hpl.1 hpl.2
  have hq := (bitListDivision_quotient_length_le p.numerator p.denominator).trans hpl.1
  have ha := bitListAddAux_length (bitListDivision p.numerator p.denominator).quotient [true] false
  unfold bitListFractionFloorCost
  dsimp only
  split_ifs <;> simp only [bitListRippleGates_eq, bitListAddVisits_eq,
    bitListTrimVisits_eq, List.length_cons, List.length_nil, Nat.zero_add] at * <;>
      nlinarith [show max (bitListDivision p.numerator p.denominator).quotient.length 1 ≤ L+1 by omega]

def bitListFractionRoundCost (p : BitListFraction) : ℕ :=
  bitListFractionAddCost p bitListFractionHalf+
    bitListFractionFloorCost (bitListFractionAdd p bitListFractionHalf)+1

/-- Nearest-integer rounding has an explicit cubic gate/list bound, covering
negative inputs and exact half ties. -/
theorem bitListFractionRoundCost_bound (p : BitListFraction)
    (hp : 0 < binaryDigitsValue p.denominator) (L : ℕ)
    (hpl : p.numerator.length ≤ L ∧ p.denominator.length ≤ L) :
    bitListFractionRoundCost p ≤ 65536*(L+1)^3 := by
  have hpl' : p.numerator.length ≤ L+2 ∧ p.denominator.length ≤ L+2 := by omega
  have hh : bitListFractionHalf.numerator.length ≤ L+2 ∧ bitListFractionHalf.denominator.length ≤ L+2 := by
    simp only [bitListFractionHalf, List.length_cons, List.length_nil]; omega
  have ha := bitListFractionAddCost_bound p bitListFractionHalf hp bitListFractionHalf_den_pos
    (L+2) hpl' hh
  have hlen := bitListFractionAdd_lengths p bitListFractionHalf (L+2) hpl' hh
  have hlen' : (bitListFractionAdd p bitListFractionHalf).numerator.length ≤ 2*(L+2)+1 ∧
      (bitListFractionAdd p bitListFractionHalf).denominator.length ≤ 2*(L+2)+1 := by omega
  have hf := bitListFractionFloorCost_bound (bitListFractionAdd p bitListFractionHalf)
    (bitListFractionAdd_wellFormed p bitListFractionHalf hp bitListFractionHalf_den_pos).2.2.1
    (2*(L+2)+1) hlen'
  unfold bitListFractionRoundCost
  nlinarith [show 1 ≤ (L+1)^2 by nlinarith]

end Optss
