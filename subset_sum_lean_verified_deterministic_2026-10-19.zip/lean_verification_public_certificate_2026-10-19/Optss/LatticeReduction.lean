import Optss.LatticeBoxingGeometry
import Mathlib.Analysis.InnerProductSpace.GramSchmidtOrtho
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.LinearAlgebra.Matrix.Transvection
import Mathlib.Algebra.Order.Round
import Mathlib.Data.Real.StarOrdered

/-!
# Exact lattice-reduction invariants

Mathlib supplies Gram–Schmidt, but not LLL reduction. This module starts that
missing construction with actual integer row operations and integer Gram
matrices. In particular, the potential uses determinants of the actual prefix
Gram matrices. No LLL existence or running-time assertion is assumed here.

The reduction operations and potential follow Section 1 of Lenstra, Lenstra,
and Lovász, *Factoring polynomials with rational coefficients* (1982).
-/

namespace Optss
noncomputable section
open scoped BigOperators Matrix

section Operations
variable {ι E R : Type*} [DecidableEq ι] [Ring R] [AddCommGroup E] [Module R E]

/-- An elementary size-reduction operation, replacing vector `k` by
`v k - q • v j`. In lattice applications the coefficient is an integer. -/
def reduceVector (v : ι → E) (j k : ι) (q : R) : ι → E :=
  Function.update v k (v k - q • v j)

/-- This is an equality of full spans over the coefficient ring, so with
`R=ℤ` it preserves the entire lattice. -/
theorem span_reduceVector (v : ι → E) (j k : ι) (hjk : j ≠ k) (q : R) :
    Submodule.span R (Set.range (reduceVector v j k q)) =
      Submodule.span R (Set.range v) :=
  Submodule.span_range_update_sub_smul hjk v q

/-- The elementary row operation is invertible: reduction by `-q` undoes it. -/
theorem reduceVector_inverse (v : ι → E) (j k : ι) (hjk : j ≠ k) (q : R) :
    reduceVector (reduceVector v j k q) j k (-q) = v := by
  funext i
  by_cases hi : i = k
  · subst i
    simp [reduceVector, hjk]
  · simp [reduceVector, hi]

/-- Size reduction preserves linear independence over the same scalar ring. -/
theorem linearIndependent_reduceVector_iff (v : ι → E) (j k : ι)
    (hjk : j ≠ k) (q : R) :
    LinearIndependent R (reduceVector v j k q) ↔ LinearIndependent R v := by
  let c : ι → R := Pi.single k (-q)
  have hc : c j = 0 := by simp [c, hjk]
  have he : reduceVector v j k q = v + (fun i => c i • v j) := by
    funext i
    by_cases hi : i = k
    · subst i; simp [reduceVector, c, sub_eq_add_neg]
    · simp [reduceVector, c, hi]
  rw [he]
  exact linearIndependent_add_smul_iff hc

omit [DecidableEq ι] in
/-- A permutation, including an adjacent swap, preserves the whole lattice. -/
theorem span_permuteVector (v : ι → E) (σ : Equiv.Perm ι) :
    Submodule.span R (Set.range (v ∘ σ)) = Submodule.span R (Set.range v) := by
  rw [Set.range_comp, Equiv.range_eq_univ, Set.image_univ]

end Operations

section Gram
variable {m n : Type*} [Fintype m] [Fintype n] [DecidableEq m]

/-- Gram matrix of the rows, in exact integer arithmetic. -/
def integerGram (A : Matrix m n ℤ) : Matrix m m ℤ := A * A.transpose

omit [Fintype m] [DecidableEq m] in
/-- Its entries are exactly the integer dot products. -/
theorem integerGram_apply (A : Matrix m n ℤ) (i j : m) :
    integerGram A i j = ∑ k, A i k * A j k := rfl

omit [Fintype m] [DecidableEq m] in
/-- Casting the exact integer Gram matrix gives the ordinary real Gram matrix. -/
theorem integerGram_cast (A : Matrix m n ℤ) :
    (integerGram A).map (Int.castRingHom ℝ) =
      (A.map (Int.castRingHom ℝ)) * (A.map (Int.castRingHom ℝ)).transpose := by
  ext i j
  simp [integerGram, Matrix.mul_apply]

/-- Independent integer rows have strictly positive integer Gram determinant,
proved by the positive definiteness of the actual real Gram matrix. -/
theorem integerGram_det_pos (A : Matrix m n ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ))) :
    0 < (integerGram A).det := by
  classical
  let B : Matrix n m ℝ := (A.map (Int.castRingHom ℝ)).transpose
  have hinj : Function.Injective B.mulVec := Matrix.mulVec_injective_iff.mpr hA
  have hpos : ((A.map (Int.castRingHom ℝ)) *
      (A.map (Int.castRingHom ℝ)).transpose).PosDef := by
    have h := (Matrix.PosDef.one : (1 : Matrix n n ℝ).PosDef).conjTranspose_mul_mul_same hinj
    simpa [B, Matrix.conjTranspose_eq_transpose_of_trivial] using h
  have hd := hpos.det_pos
  rw [← integerGram_cast] at hd
  have he : ((integerGram A).det:ℝ) = ((integerGram A).map (Int.castRingHom ℝ)).det :=
    Int.cast_det _
  rw [← he] at hd
  exact_mod_cast hd

omit [Fintype n] in
/-- The matrix formula is an actual unimodular transvection, even for a
rectangular matrix whose rows generate a lower-rank lattice. -/
theorem reduceVector_eq_transvection_mul (A : Matrix m n ℤ)
    (j k : m) (q : ℤ) :
    reduceVector A j k q = Matrix.transvection k j (-q) * A := by
  ext i l
  by_cases hi : i = k
  · subst i
    simp [reduceVector, Matrix.transvection, Matrix.add_mul, sub_eq_add_neg]
  · simp [reduceVector, Matrix.transvection, Matrix.add_mul, hi]

/-- A size-reduction row operation leaves the actual Gram determinant exactly
unchanged; this is derived from the determinant-one transvection. -/
theorem integerGram_det_reduceVector (A : Matrix m n ℤ)
    (j k : m) (hjk : j ≠ k) (q : ℤ) :
    (integerGram (reduceVector A j k q)).det = (integerGram A).det := by
  rw [reduceVector_eq_transvection_mul]
  have he : integerGram (Matrix.transvection k j (-q) * A) =
      Matrix.transvection k j (-q) * integerGram A * (Matrix.transvection k j (-q)).transpose := by
    simp only [integerGram, Matrix.transpose_mul, Matrix.mul_assoc]
  rw [he, Matrix.det_mul, Matrix.det_mul, Matrix.det_transpose,
    Matrix.det_transvection_of_ne k j hjk.symm]
  ring

/-- Permuting rows simultaneously permutes rows and columns of their Gram
matrix and therefore preserves its determinant. -/
theorem integerGram_det_permute (A : Matrix m n ℤ) (σ : Equiv.Perm m) :
    (integerGram (A ∘ σ)).det = (integerGram A).det := by
  have he : integerGram (A ∘ σ) = (integerGram A).submatrix σ σ := by
    ext i j
    rfl
  rw [he, Matrix.det_submatrix_equiv_self]

end Gram

section PrefixPotential
variable {r d : ℕ}

/-- The first `t` actual integer vectors, with no zero padding. -/
def prefixRows (A : Matrix (Fin r) (Fin d) ℤ) (t : Fin (r+1)) :
    Matrix (Fin t.val) (Fin d) ℤ := fun i => A (i.castLE (Nat.le_of_lt_succ t.isLt))

/-- Squared covolume of the lattice generated by the actual prefix. -/
def prefixGramDet (A : Matrix (Fin r) (Fin d) ℤ) (t : Fin (r+1)) : ℤ :=
  (integerGram (prefixRows A t)).det

/-- The usual integer Gram-determinant potential, including the harmless
empty-prefix factor `1`. It is positive on every independent integer family. -/
def gramPotential (A : Matrix (Fin r) (Fin d) ℤ) : ℕ :=
  ∏ t : Fin (r+1), (prefixGramDet A t).natAbs

theorem prefixGramDet_pos (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ))) (t : Fin (r+1)) :
    0 < prefixGramDet A t := by
  apply integerGram_det_pos
  exact hA.comp (fun i : Fin t.val => i.castLE (Nat.le_of_lt_succ t.isLt))
    (fun i j hij => Fin.ext (congrArg (fun z : Fin r => z.val) hij))

theorem gramPotential_pos (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ))) :
    0 < gramPotential A := by
  apply Finset.prod_pos
  intro t _
  exact Int.natAbs_pos.mpr (ne_of_gt (prefixGramDet_pos A hA t))

/-- A reduction of a row outside a prefix does not modify that prefix. -/
theorem prefixRows_reduceVector_outside (A : Matrix (Fin r) (Fin d) ℤ)
    (j k : Fin r) (q : ℤ) (t : Fin (r+1)) (ht : t.val ≤ k.val) :
    prefixRows (reduceVector A j k q) t = prefixRows A t := by
  ext i l
  have hi : i.castLE (Nat.le_of_lt_succ t.isLt) ≠ k := by
    intro h
    have := congrArg Fin.val h
    have := i.isLt
    simp only [Fin.coe_castLE] at *
    omega
  simp [prefixRows, reduceVector, hi]

/-- If both rows are in the prefix, its reduction is the same elementary
integer operation on the smaller matrix. -/
theorem prefixRows_reduceVector_inside (A : Matrix (Fin r) (Fin d) ℤ)
    (j k : Fin r) (q : ℤ) (t : Fin (r+1)) (hj : j.val < t.val) (hk : k.val < t.val) :
    prefixRows (reduceVector A j k q) t =
      reduceVector (prefixRows A t) ⟨j.val,hj⟩ ⟨k.val,hk⟩ q := by
  ext i l
  simp only [prefixRows, reduceVector, Function.update_apply, Fin.ext_iff, Fin.coe_castLE]
  rfl

/-- Every prefix determinant, and hence every Gram-Schmidt length represented
as a quotient of consecutive prefix determinants, survives integer reduction. -/
theorem prefixGramDet_reduceVector (A : Matrix (Fin r) (Fin d) ℤ)
    (j k : Fin r) (hjk : j < k) (q : ℤ) (t : Fin (r+1)) :
    prefixGramDet (reduceVector A j k q) t = prefixGramDet A t := by
  unfold prefixGramDet
  by_cases hk : k.val < t.val
  · have hj : j.val < t.val := lt_trans hjk hk
    rw [prefixRows_reduceVector_inside A j k q t hj hk]
    exact integerGram_det_reduceVector _ _ _ (by
      intro h
      have := congrArg Fin.val h
      exact (ne_of_lt hjk) (Fin.ext this)) q
  · rw [prefixRows_reduceVector_outside A j k q t (Nat.le_of_not_gt hk)]

/-- Size reduction leaves the exact integer potential unchanged. -/
theorem gramPotential_reduceVector (A : Matrix (Fin r) (Fin d) ℤ)
    (j k : Fin r) (hjk : j < k) (q : ℤ) :
    gramPotential (reduceVector A j k q) = gramPotential A := by
  unfold gramPotential
  apply Finset.prod_congr rfl
  intro t _
  rw [prefixGramDet_reduceVector A j k hjk q t]

/-- Actual row interchange, rather than an abstract change in assigned lengths. -/
def swapRows (A : Matrix (Fin r) (Fin d) ℤ) (j k : Fin r) : Matrix (Fin r) (Fin d) ℤ :=
  A ∘ Equiv.swap j k

theorem prefixRows_swap_outside (A : Matrix (Fin r) (Fin d) ℤ)
    (j k : Fin r) (t : Fin (r+1)) (hj : t.val ≤ j.val) (hk : t.val ≤ k.val) :
    prefixRows (swapRows A j k) t = prefixRows A t := by
  ext i l
  have hij : i.castLE (Nat.le_of_lt_succ t.isLt) ≠ j := by
    intro h
    have := congrArg Fin.val h
    have := i.isLt
    simp only [Fin.coe_castLE] at *
    omega
  have hik : i.castLE (Nat.le_of_lt_succ t.isLt) ≠ k := by
    intro h
    have := congrArg Fin.val h
    have := i.isLt
    simp only [Fin.coe_castLE] at *
    omega
  simp [prefixRows, swapRows, Equiv.swap_apply_of_ne_of_ne hij hik]

theorem prefixRows_swap_inside (A : Matrix (Fin r) (Fin d) ℤ)
    (j k : Fin r) (t : Fin (r+1)) (hj : j.val < t.val) (hk : k.val < t.val) :
    prefixRows (swapRows A j k) t =
      prefixRows A t ∘ Equiv.swap ⟨j.val,hj⟩ ⟨k.val,hk⟩ := by
  ext i l
  simp only [prefixRows, swapRows, Function.comp_apply]
  congr 2
  apply Fin.ext
  simp only [Equiv.swap_apply_def, Fin.ext_iff, Fin.coe_castLE]
  split_ifs <;> rfl

/-- An adjacent swap can change exactly one prefix Gram determinant. -/
theorem prefixGramDet_swap_adjacent_of_ne (A : Matrix (Fin r) (Fin d) ℤ)
    (j k : Fin r) (hjk : k.val = j.val+1) (t : Fin (r+1)) (ht : t.val ≠ k.val) :
    prefixGramDet (swapRows A j k) t = prefixGramDet A t := by
  unfold prefixGramDet
  by_cases hj : t.val ≤ j.val
  · rw [prefixRows_swap_outside A j k t hj (by omega)]
  · have hj' : j.val < t.val := by omega
    have hk' : k.val < t.val := by omega
    rw [prefixRows_swap_inside A j k t hj' hk']
    exact integerGram_det_permute _ _

/-- The determinant version of an adjacent Lovász failure decreases the
actual integer potential. Its comparison is between the actual old and new
prefix covolumes, not between arbitrary supplied potential weights. -/
theorem gramPotential_swap_lt (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ)))
    (j k : Fin r) (hjk : k.val = j.val+1)
    (hfail : prefixGramDet (swapRows A j k) ⟨k.val, by omega⟩ <
      prefixGramDet A ⟨k.val, by omega⟩) :
    gramPotential (swapRows A j k) < gramPotential A := by
  have hs : LinearIndependent ℝ (fun i => fun l => ((swapRows A j k) i l:ℝ)) :=
    hA.comp (Equiv.swap j k) (Equiv.swap j k).injective
  have hlt : (prefixGramDet (swapRows A j k) ⟨k.val, by omega⟩).natAbs <
      (prefixGramDet A ⟨k.val, by omega⟩).natAbs := by
    have hpos' := prefixGramDet_pos (swapRows A j k) hs ⟨k.val, by omega⟩
    exact Int.natAbs_lt_natAbs_of_nonneg_of_lt hpos'.le hfail
  apply Finset.prod_lt_prod
  · intro t _
    exact Int.natAbs_pos.mpr (ne_of_gt (prefixGramDet_pos _ hs t))
  · intro t _
    by_cases ht : t.val = k.val
    · have he : t = ⟨k.val, by omega⟩ := Fin.ext ht
      rw [he]
      exact hlt.le
    · rw [prefixGramDet_swap_adjacent_of_ne A j k hjk t ht]
  · exact ⟨⟨k.val, by omega⟩, Finset.mem_univ _, hlt⟩

/-- An exact `3/4` determinant test already implies strict descent. The
identification with the conventional Gram-Schmidt Lovász test is separate. -/
theorem gramPotential_swap_lt_of_three_quarters (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ)))
    (j k : Fin r) (hjk : k.val = j.val+1)
    (hfail : 4*prefixGramDet (swapRows A j k) ⟨k.val, by omega⟩ <
      3*prefixGramDet A ⟨k.val, by omega⟩) :
    gramPotential (swapRows A j k) < gramPotential A := by
  apply gramPotential_swap_lt A hA j k hjk
  have hpos := prefixGramDet_pos A hA ⟨k.val, by omega⟩
  omega

/-- The exact determinant test contracts the entire actual potential by
`3/4`, because every other prefix factor is identical. -/
theorem gramPotential_swap_three_quarters (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ)))
    (j k : Fin r) (hjk : k.val = j.val+1)
    (hfail : 4*prefixGramDet (swapRows A j k) ⟨k.val, by omega⟩ <
      3*prefixGramDet A ⟨k.val, by omega⟩) :
    4*gramPotential (swapRows A j k) < 3*gramPotential A := by
  let t₀ : Fin (r+1) := ⟨k.val, by omega⟩
  have hs : LinearIndependent ℝ (fun i => fun l => ((swapRows A j k) i l:ℝ)) :=
    hA.comp (Equiv.swap j k) (Equiv.swap j k).injective
  have hfailNat : 4*(prefixGramDet (swapRows A j k) t₀).natAbs <
      3*(prefixGramDet A t₀).natAbs := by
    have h₁ := prefixGramDet_pos A hA t₀
    have h₂ := prefixGramDet_pos (swapRows A j k) hs t₀
    have hcast : (4*(prefixGramDet (swapRows A j k) t₀).natAbs:ℤ) <
        3*(prefixGramDet A t₀).natAbs := by
      simpa only [Int.natCast_natAbs, abs_of_pos h₁, abs_of_pos h₂] using hfail
    exact_mod_cast hcast
  let tail : ℕ := ∏ t ∈ Finset.univ.erase t₀, (prefixGramDet A t).natAbs
  have htail : 0 < tail := Finset.prod_pos fun t _ =>
    Int.natAbs_pos.mpr (ne_of_gt (prefixGramDet_pos A hA t))
  have hsame : (∏ t ∈ Finset.univ.erase t₀,
      (prefixGramDet (swapRows A j k) t).natAbs) = tail := by
    apply Finset.prod_congr rfl
    intro t ht
    have hne : t.val ≠ k.val := by
      intro he
      exact (Finset.mem_erase.mp ht).1 (Fin.ext he)
    rw [prefixGramDet_swap_adjacent_of_ne A j k hjk t hne]
  have hpA : gramPotential A = (prefixGramDet A t₀).natAbs * tail :=
    (Finset.mul_prod_erase _ _ (Finset.mem_univ t₀)).symm
  have hpB : gramPotential (swapRows A j k) =
      (prefixGramDet (swapRows A j k) t₀).natAbs * tail := by
    unfold gramPotential
    rw [← Finset.mul_prod_erase _ _ (Finset.mem_univ t₀), hsame]
  rw [hpA, hpB]
  simpa only [mul_assoc] using mul_lt_mul_of_pos_right hfailNat htail

/-- The well-ordering argument actually selects a minimum-potential basis of
the same full integer lattice. It assumes no reduced-basis existence theorem. -/
theorem exists_minimum_gramPotential (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ))) :
    ∃ B : Matrix (Fin r) (Fin d) ℤ,
      Submodule.span ℤ (Set.range B) = Submodule.span ℤ (Set.range A) ∧
      LinearIndependent ℝ (fun i => fun j => (B i j:ℝ)) ∧
      ∀ C : Matrix (Fin r) (Fin d) ℤ,
        Submodule.span ℤ (Set.range C) = Submodule.span ℤ (Set.range A) →
        LinearIndependent ℝ (fun i => fun j => (C i j:ℝ)) →
        gramPotential B ≤ gramPotential C := by
  classical
  let P : ℕ → Prop := fun n => ∃ B : Matrix (Fin r) (Fin d) ℤ,
    Submodule.span ℤ (Set.range B) = Submodule.span ℤ (Set.range A) ∧
    LinearIndependent ℝ (fun i => fun j => (B i j:ℝ)) ∧ gramPotential B = n
  have hex : ∃ n, P n := ⟨gramPotential A, A, rfl, hA, rfl⟩
  obtain ⟨B, hspan, hB, hpot⟩ := Nat.find_spec hex
  refine ⟨B, hspan, hB, fun C hCspan hC => ?_⟩
  rw [hpot]
  exact Nat.find_min' hex ⟨C, hCspan, hC, rfl⟩

/-- A minimum-potential basis passes the stronger determinant test with
parameter `1` at every adjacent position, as every swap is a genuine basis of
the same lattice. Subsequent integer size reductions preserve its minimum. -/
theorem minimum_gramPotential_adjacent (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i => fun j => (A i j:ℝ)))
    (hmin : ∀ C : Matrix (Fin r) (Fin d) ℤ,
      Submodule.span ℤ (Set.range C) = Submodule.span ℤ (Set.range A) →
      LinearIndependent ℝ (fun i => fun j => (C i j:ℝ)) →
      gramPotential A ≤ gramPotential C)
    (j k : Fin r) (hjk : k.val = j.val+1) :
    prefixGramDet A ⟨k.val, by omega⟩ ≤
      prefixGramDet (swapRows A j k) ⟨k.val, by omega⟩ := by
  by_contra hn
  have hlt := gramPotential_swap_lt A hA j k hjk (lt_of_not_ge hn)
  have hsame : Submodule.span ℤ (Set.range (swapRows A j k)) =
      Submodule.span ℤ (Set.range A) := span_permuteVector A (Equiv.swap j k)
  have hs : LinearIndependent ℝ (fun i => fun l => ((swapRows A j k) i l:ℝ)) :=
    hA.comp (Equiv.swap j k) (Equiv.swap j k).injective
  exact (not_lt_of_ge (hmin _ hsame hs)) hlt

end PrefixPotential

section GramSchmidtReduction
variable {r : ℕ} {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- Gram-Schmidt at a position depends only on the actual initial vector
segment, derived directly from its recursive definition. -/
theorem gramSchmidt_congr_initial (v w : Fin r → E) (n : Fin r)
    (hvw : ∀ i, i ≤ n → v i = w i) :
    gramSchmidt ℝ v n = gramSchmidt ℝ w n := by
  induction n using WellFoundedLT.induction with
  | ind n ih =>
    rw [gramSchmidt_def, gramSchmidt_def, hvw n le_rfl]
    congr 1
    apply Finset.sum_congr rfl
    intro i hi
    have hin : i < n := Finset.mem_Iio.mp hi
    rw [ih i hin (fun j hj => hvw j (hj.trans hin.le))]

/-- A later vector update leaves earlier orthogonalized vectors unchanged. -/
theorem gramSchmidt_reduceVector_before (v : Fin r → E) (j k i : Fin r)
    (q : ℝ) (hik : i < k) :
    gramSchmidt ℝ (reduceVector v j k q) i = gramSchmidt ℝ v i := by
  apply gramSchmidt_congr_initial
  intro l hli
  have hlk : l ≠ k := ne_of_lt (hli.trans_lt hik)
  simp [reduceVector, hlk]

/-- The diagonal Gram-Schmidt coefficient equals its squared norm. -/
theorem inner_gramSchmidt_original (v : Fin r → E) (j : Fin r) :
    @inner ℝ E _ (gramSchmidt ℝ v j) (v j) = ‖gramSchmidt ℝ v j‖^2 := by
  nth_rw 1 [gramSchmidt_def'' ℝ v j]
  rw [inner_add_right, inner_sum]
  have hz : ∑ i ∈ Finset.Iio j,
      @inner ℝ E _ (gramSchmidt ℝ v j)
        ((@inner ℝ E _ (gramSchmidt ℝ v i) (v j) / ‖gramSchmidt ℝ v i‖^2) •
          gramSchmidt ℝ v i) = 0 := by
    apply Finset.sum_eq_zero
    intro i hi
    rw [inner_smul_right, gramSchmidt_orthogonal ℝ v (ne_of_gt (Finset.mem_Iio.mp hi)), mul_zero]
  simp only [RCLike.ofReal_real_eq_id, id_eq, hz, add_zero, real_inner_self_eq_norm_sq]

/-- The actual coefficient used by the nearest-integer size-reduction step. -/
def gsCoefficient (v : Fin r → E) (k j : Fin r) : ℝ :=
  @inner ℝ E _ (gramSchmidt ℝ v j) (v k) / ‖gramSchmidt ℝ v j‖^2

/-- Subtracting `q` times an earlier vector subtracts exactly `q` from its
Gram-Schmidt coefficient, while the earlier orthogonal vector is preserved. -/
theorem gsCoefficient_reduceVector (v : Fin r → E) (hv : LinearIndependent ℝ v)
    (j k : Fin r) (hjk : j < k) (q : ℝ) :
    gsCoefficient (reduceVector v j k q) k j = gsCoefficient v k j - q := by
  have hn : ‖gramSchmidt ℝ v j‖ ≠ 0 :=
    norm_ne_zero_iff.mpr (gramSchmidt_ne_zero j hv)
  unfold gsCoefficient
  rw [gramSchmidt_reduceVector_before v j k j q hjk]
  simp only [reduceVector, Function.update_self, inner_sub_right, inner_smul_right]
  rw [inner_gramSchmidt_original]
  field_simp
  ring

/-- Nearest-integer subtraction actually puts the selected coefficient in
`[-1/2,1/2]`. Combined with integer-span invariance this is a real reduction step. -/
theorem gsCoefficient_round_reduced (v : Fin r → E) (hv : LinearIndependent ℝ v)
    (j k : Fin r) (hjk : j < k) :
    |gsCoefficient (reduceVector v j k (round (gsCoefficient v k j):ℝ)) k j| ≤ 1/2 := by
  rw [gsCoefficient_reduceVector v hv j k hjk]
  exact abs_sub_round _

/-- Descending size reduction leaves already-treated larger coefficients
unchanged, as the corresponding Gram-Schmidt directions are orthogonal to
the earlier subtracted vector. -/
theorem gsCoefficient_reduceVector_later (v : Fin r → E)
    (j k i : Fin r) (hji : j < i) (hik : i < k) (q : ℝ) :
    gsCoefficient (reduceVector v j k q) k i = gsCoefficient v k i := by
  unfold gsCoefficient
  rw [gramSchmidt_reduceVector_before v j k i q hik]
  simp only [reduceVector, Function.update_self, inner_sub_right, inner_smul_right]
  rw [gramSchmidt_inv_triangular ℝ v hji, mul_zero, sub_zero]

/-- An integer-valued real row operation preserves the whole integer span,
including when the lattice is embedded in a real Euclidean space. -/
theorem integerSpan_reduceVector (v : Fin r → E) (j k : Fin r) (hjk : j ≠ k) (q : ℤ) :
    Submodule.span ℤ (Set.range (reduceVector v j k (q:ℝ))) =
      Submodule.span ℤ (Set.range v) := by
  simpa only [reduceVector, Int.cast_smul_eq_zsmul] using
    (span_reduceVector (R := ℤ) v j k hjk q)

/-- A complete descending nearest-integer sweep for the first `n` coefficients
of row `k`. Each recursive call performs an actual integer row operation. -/
def roundReduceRow (v : Fin r → E) (k : Fin r) (n : ℕ) (h : n ≤ k.val) : Fin r → E :=
  match n with
  | 0 => v
  | n+1 =>
    let j : Fin r := ⟨n, by omega⟩
    let q : ℤ := round (gsCoefficient v k j)
    roundReduceRow (reduceVector v j k (q:ℝ)) k n (by omega)
termination_by n

/-- The descending sweep reduces every requested coefficient, preserves the
larger ones, and retains both independence and the entire integer lattice. -/
theorem roundReduceRow_spec (v : Fin r → E) (hv : LinearIndependent ℝ v)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) :
    LinearIndependent ℝ (roundReduceRow v k n h) ∧
    Submodule.span ℤ (Set.range (roundReduceRow v k n h)) = Submodule.span ℤ (Set.range v) ∧
    (∀ i, i ≠ k → roundReduceRow v k n h i = v i) ∧
    (∀ i : Fin r, i.val < n → |gsCoefficient (roundReduceRow v k n h) k i| ≤ 1/2) ∧
    (∀ i : Fin r, n ≤ i.val → i < k →
      gsCoefficient (roundReduceRow v k n h) k i = gsCoefficient v k i) := by
  induction n generalizing v with
  | zero =>
    have hz : roundReduceRow v k 0 h = v := by rw [roundReduceRow]
    rw [hz]
    exact ⟨hv, rfl, fun _ _ => rfl, fun _ hi => by omega, fun _ _ _ => rfl⟩
  | succ n ih =>
    let j : Fin r := ⟨n, by omega⟩
    let q : ℤ := round (gsCoefficient v k j)
    let w := reduceVector v j k (q:ℝ)
    have hjk : j < k := by change n < k.val; omega
    have hw : LinearIndependent ℝ w :=
      (linearIndependent_reduceVector_iff v j k (ne_of_lt hjk) (q:ℝ)).mpr hv
    obtain ⟨hind, hspan, hsame, hsmall, hlarge⟩ := ih w hw (by omega : n ≤ k.val)
    have hout : roundReduceRow v k (n+1) h = roundReduceRow w k n (by omega) := by
      rw [roundReduceRow]
    rw [hout]
    refine ⟨hind, hspan.trans (integerSpan_reduceVector v j k (ne_of_lt hjk) q), ?_, ?_, ?_⟩
    · intro i hik
      rw [hsame i hik]
      simp [w, reduceVector, hik]
    · intro i hi
      by_cases hin : i.val < n
      · exact hsmall i hin
      · have he : i = j := Fin.ext (by dsimp [j]; omega)
        rw [he, hlarge j (by exact Nat.le_refl n) hjk]
        exact gsCoefficient_round_reduced v hv j k hjk
    · intro i hi hik
      rw [hlarge i (by omega) hik]
      exact gsCoefficient_reduceVector_later v j k i (by change n < i.val; omega) hik (q:ℝ)

/-- Every row admits a fully size-reduced replacement in the very same
integer lattice, obtained by the explicit finite descending sweep above. -/
theorem exists_size_reduced_row (v : Fin r → E) (hv : LinearIndependent ℝ v) (k : Fin r) :
    ∃ w : Fin r → E, LinearIndependent ℝ w ∧
      Submodule.span ℤ (Set.range w) = Submodule.span ℤ (Set.range v) ∧
      (∀ i, i ≠ k → w i = v i) ∧
      (∀ i, i < k → |gsCoefficient w k i| ≤ 1/2) := by
  obtain ⟨hind, hspan, hsame, hsmall, _⟩ := roundReduceRow_spec v hv k k.val le_rfl
  exact ⟨roundReduceRow v k k.val le_rfl, hind, hspan, hsame, fun i hi => hsmall i hi⟩

/-- A coefficient below the diagonal depends only on the vector prefix
through its row. -/
theorem gsCoefficient_congr_initial (v w : Fin r → E) (k j : Fin r) (hjk : j ≤ k)
    (he : ∀ i, i ≤ k → v i = w i) : gsCoefficient v k j = gsCoefficient w k j := by
  unfold gsCoefficient
  rw [he k le_rfl, gramSchmidt_congr_initial v w j (fun i hi => he i (hi.trans hjk))]

/-- An explicit finite sweep, processing rows from the first to the last. -/
def roundReduceAll (v : Fin r → E) (n : ℕ) (h : n ≤ r) : Fin r → E :=
  match n with
  | 0 => v
  | n+1 =>
    let w := roundReduceAll v n (by omega)
    let k : Fin r := ⟨n, by omega⟩
    roundReduceRow w k n le_rfl
termination_by n

/-- The full finite sweep preserves the exact integer lattice and makes all
strictly lower Gram-Schmidt coefficients at most `1/2` in absolute value. -/
theorem roundReduceAll_spec (v : Fin r → E) (hv : LinearIndependent ℝ v)
    (n : ℕ) (h : n ≤ r) :
    LinearIndependent ℝ (roundReduceAll v n h) ∧
    Submodule.span ℤ (Set.range (roundReduceAll v n h)) = Submodule.span ℤ (Set.range v) ∧
    (∀ i : Fin r, n ≤ i.val → roundReduceAll v n h i = v i) ∧
    (∀ k j : Fin r, k.val < n → j < k →
      |gsCoefficient (roundReduceAll v n h) k j| ≤ 1/2) := by
  induction n with
  | zero =>
    have hz : roundReduceAll v 0 h = v := by rw [roundReduceAll]
    rw [hz]
    exact ⟨hv, rfl, fun _ _ => rfl, fun _ _ hn _ => by omega⟩
  | succ n ih =>
    let w := roundReduceAll v n (by omega : n ≤ r)
    let k : Fin r := ⟨n, by omega⟩
    obtain ⟨hind, hspan, hsame, hsmall⟩ := ih (by omega : n ≤ r)
    obtain ⟨hind', hspan', hsame', hsmall', _⟩ := roundReduceRow_spec w hind k n le_rfl
    have hout : roundReduceAll v (n+1) h = roundReduceRow w k n le_rfl := by rw [roundReduceAll]
    rw [hout]
    refine ⟨hind', hspan'.trans hspan, ?_, ?_⟩
    · intro i hi
      have hik : i ≠ k := by intro he; have := congrArg Fin.val he; dsimp [k] at this; omega
      rw [hsame' i hik]
      exact hsame i (by omega)
    · intro i j hin hji
      by_cases hi : i.val < n
      · have hcoeff : gsCoefficient (roundReduceRow w k n le_rfl) i j = gsCoefficient w i j := by
          apply gsCoefficient_congr_initial _ _ i j hji.le
          intro l hli
          apply hsame'
          intro he
          have hel := congrArg Fin.val he
          change l.val ≤ i.val at hli
          dsimp [k] at hel
          omega
        rw [hcoeff]
        exact hsmall i j hi hji
      · have hik : i = k := Fin.ext (by dsimp [k]; omega)
        subst i
        exact hsmall' j hji

/-- Constructive size reduction for an arbitrary real lattice basis: a finite
sequence of explicitly rounded integer row operations, with no LLL axiom. -/
theorem exists_size_reduced_family (v : Fin r → E) (hv : LinearIndependent ℝ v) :
    ∃ w : Fin r → E, LinearIndependent ℝ w ∧
      Submodule.span ℤ (Set.range w) = Submodule.span ℤ (Set.range v) ∧
      ∀ k j, j < k → |gsCoefficient w k j| ≤ 1/2 := by
  obtain ⟨hind, hspan, _, hsmall⟩ := roundReduceAll_spec v hv r le_rfl
  exact ⟨roundReduceAll v r le_rfl, hind, hspan, fun k j hjk => hsmall k j k.isLt hjk⟩

end GramSchmidtReduction

end
end Optss
