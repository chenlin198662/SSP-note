import Optss.RestartingGreedyBlock
import Optss.CommonGapModel

/-!
# Bounded deletion sequences and a common-lattice block window

A finite iteration of actual block selectors preserves original labels. Its
aggregate deletion bound validates a single protected-rank certificate for
every prefix. The proved integer lattice-chain bound then supplies a consecutive
window whose block supports generate one common full lattice.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1000000
variable {ι : Type} [DecidableEq ι] {d : ℕ}

/-- Uniform structural interface of an actual bounded block selector. -/
structure BoundedBlockSelector (v : ι → IntVec d) (initial : Finset ι) (B : ℕ) where
  select : Finset ι → GreedyBlockState ι (IntVec d)
  valid : ∀ s ⊆ initial, (select s).Valid v
  chosen_subset : ∀ s ⊆ initial, (select s).chosen ⊆ s
  remaining_eq : ∀ s ⊆ initial, (select s).remaining = s \ (select s).chosen
  size_le : ∀ s ⊆ initial, (select s).chosen.card ≤ B

namespace BoundedBlockSelector
variable {v : ι → IntVec d} {initial : Finset ι} {B : ℕ}

/-- The actual remaining labels after each selected block. -/
def remaining (F : BoundedBlockSelector v initial B) : ℕ → Finset ι
  | 0 => initial
  | n+1 => (F.select (F.remaining n)).remaining

/-- The actual block selected at this index. -/
def block (F : BoundedBlockSelector v initial B) (n : ℕ) : GreedyBlockState ι (IntVec d) :=
  F.select (F.remaining n)

theorem remaining_subset (F : BoundedBlockSelector v initial B) (n : ℕ) :
    F.remaining n ⊆ initial := by
  induction n with
  | zero => exact Finset.Subset.refl _
  | succ n ih =>
    rw [remaining, F.remaining_eq _ ih]
    exact Finset.sdiff_subset.trans ih

theorem remaining_step (F : BoundedBlockSelector v initial B) (n : ℕ) :
    F.remaining (n+1) = F.remaining n \ (F.block n).chosen :=
  F.remaining_eq _ (F.remaining_subset n)

theorem remaining_antitone (F : BoundedBlockSelector v initial B) : Antitone F.remaining := by
  apply antitone_nat_of_succ_le
  intro n
  rw [F.remaining_step]
  exact Finset.sdiff_subset

theorem deleted_card_le (F : BoundedBlockSelector v initial B) (n : ℕ) :
    (initial \ F.remaining n).card ≤ n*B := by
  induction n with
  | zero => simp [remaining]
  | succ n ih =>
    have hs := F.chosen_subset _ (F.remaining_subset n)
    have he : initial \ F.remaining (n+1) = (initial \ F.remaining n) ∪ (F.block n).chosen := by
      rw [F.remaining_step]
      ext i
      constructor
      · intro hi
        obtain ⟨hia, hin⟩ := Finset.mem_sdiff.mp hi
        by_cases him : i ∈ F.remaining n
        · exact Finset.mem_union_right _ (by
            by_contra hni
            exact hin (Finset.mem_sdiff.mpr ⟨him, hni⟩))
        · exact Finset.mem_union_left _ (Finset.mem_sdiff.mpr ⟨hia, him⟩)
      · intro hi
        rcases Finset.mem_union.mp hi with hi | hi
        · obtain ⟨hia, hin⟩ := Finset.mem_sdiff.mp hi
          exact Finset.mem_sdiff.mpr ⟨hia, fun hm => hin (Finset.mem_sdiff.mp hm).1⟩
        · exact Finset.mem_sdiff.mpr ⟨F.remaining_subset n (hs hi),
            fun hm => (Finset.mem_sdiff.mp hm).2 hi⟩
    rw [he]
    calc
      _ ≤ (initial \ F.remaining n).card + (F.block n).chosen.card := Finset.card_union_le _ _
      _ ≤ n*B+B := Nat.add_le_add ih (F.size_le _ (F.remaining_subset n))
      _ = (n+1)*B := by ring

theorem blocks_disjoint (F : BoundedBlockSelector v initial B) {i j : ℕ} (hij : i < j) :
    Disjoint (F.block i).chosen (F.block j).chosen := by
  apply Finset.disjoint_left.mpr
  intro x hi hj
  have hx := F.chosen_subset _ (F.remaining_subset j) hj
  have hm := F.remaining_antitone (Nat.succ_le_of_lt hij) hx
  rw [F.remaining_step] at hm
  exact (Finset.mem_sdiff.mp hm).2 hi

theorem remaining_full_rank (F : BoundedBlockSelector v initial B) (n k : ℕ)
    (hbudget : n*B ≤ k)
    (hprotected : ∀ deleted : Finset ι, deleted.card ≤ k →
      labelSpan ℝ (fun i => realVector (v i)) (initial \ deleted) = ⊤) :
    ∀ i ≤ n, labelSpan ℝ (fun j => realVector (v j)) (F.remaining i) = ⊤ := by
  intro i hi
  have hd := (F.deleted_card_le i).trans ((Nat.mul_le_mul_right B hi).trans hbudget)
  have he : initial \ (initial \ F.remaining i) = F.remaining i :=
    Finset.sdiff_sdiff_eq_self (F.remaining_subset i)
  simpa only [he] using hprotected (initial \ F.remaining i) hd

/-- A rank-protected finite block sequence contains an actual consecutive
window with one common generated lattice. Every block in the window has exact
subset-sum support on pairwise disjoint original labels. -/
theorem common_lattice_window (F : BoundedBlockSelector v initial B) (n ℓ k : ℕ)
    (hbudget : n*B ≤ k)
    (hprotected : ∀ deleted : Finset ι, deleted.card ≤ k →
      labelSpan ℝ (fun i => realVector (v i)) (initial \ deleted) = ⊤)
    (w : Fin d → ℕ) (hbox : ∀ i ∈ initial, InCenteredBox w (v i))
    (hlength : (Nat.log 2 (d.factorial*∏ j, w j)+1)*ℓ ≤ n)
    (hgenerated : ∀ i < n, AddSubgroup.closure ((F.block i).sums : Set (IntVec d)) =
      generatedLattice v (F.remaining i)) :
    ∃ b ≤ Nat.log 2 (d.factorial*∏ j, w j),
      (∀ t ≤ ℓ, generatedLattice v (F.remaining (b*ℓ+t)) = generatedLattice v (F.remaining (b*ℓ))) ∧
      (∀ t < ℓ, AddSubgroup.closure ((F.block (b*ℓ+t)).sums : Set (IntVec d)) =
        generatedLattice v (F.remaining (b*ℓ))) ∧
      (∀ t < ℓ, (F.block (b*ℓ+t)).sums = labelledSubsetSupport v (F.block (b*ℓ+t)).chosen) ∧
      (∀ i < ℓ, ∀ j < ℓ, i ≠ j → Disjoint (F.block (b*ℓ+i)).chosen (F.block (b*ℓ+j)).chosen) ∧
      (initial \ F.remaining (b*ℓ)).card ≤ b*ℓ*B := by
  obtain ⟨b, hb, hlat⟩ := remaining_lattices_common_run v F.remaining n ℓ
    (fun i _ => F.remaining_antitone (Nat.le_succ i))
    (F.remaining_full_rank n k hbudget hprotected) w
    (fun i _ j hj => hbox j (F.remaining_subset i hj)) hlength
  have hwindow : ∀ t < ℓ, b*ℓ+t < n := by
    intro t ht
    have hbound := Nat.mul_le_mul_right ℓ (Nat.add_le_add_right hb 1)
    have hbn := hbound.trans hlength
    calc
      b*ℓ+t < b*ℓ+ℓ := Nat.add_lt_add_left ht _
      _ = (b+1)*ℓ := by ring
      _ ≤ n := hbn
  refine ⟨b, hb, hlat, ?_, ?_, ?_, F.deleted_card_le (b*ℓ)⟩
  · intro t ht
    exact (hgenerated _ (hwindow t ht)).trans (hlat t ht.le)
  · intro t _
    exact (F.valid _ (F.remaining_subset (b*ℓ+t))).2
  · intro i _ j _ hij
    rcases lt_or_gt_of_ne hij with hij | hij
    · exact F.blocks_disjoint (Nat.add_lt_add_left hij _)
    · exact (F.blocks_disjoint (Nat.add_lt_add_left hij _)).symm

end BoundedBlockSelector
end
end Optss
