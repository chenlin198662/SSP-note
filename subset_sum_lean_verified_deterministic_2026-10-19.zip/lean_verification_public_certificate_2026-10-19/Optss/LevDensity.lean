import Optss.LevGrowth
import Optss.LevDensityArithmetic

/-!
# Actual sumset density estimates for Lev's interval theorem

The finite sets here are normalized to have minimum zero and the stated
maximum. Their gcd-one condition is exactly the absence of a proper
integer arithmetic progression after normalization. Cardinality growth
is obtained from the proved 1997 theorem, then telescoped; it is not an
input hypothesis.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

/-- A normalized integer set with its actual diameter and no common divisor. -/
def LevNormalized (A : Finset ℤ) (l : ℕ) : Prop :=
  A ⊆ Finset.Icc 0 (l : ℤ) ∧ 0 ∈ A ∧ (l : ℤ) ∈ A ∧ A.gcd id = 1

/-- Actual sum of the first `k` summands, including the empty sum `{0}`. -/
def levPrefixSum (A : ℕ → Finset ℤ) (k : ℕ) : Finset ℤ :=
  ((List.range k).map A).sum

@[simp] theorem levPrefixSum_zero (A : ℕ → Finset ℤ) : levPrefixSum A 0 = {0} := rfl

@[simp] theorem levPrefixSum_succ (A : ℕ → Finset ℤ) (k : ℕ) :
    levPrefixSum A (k + 1) = levPrefixSum A k + A k := by
  simp [levPrefixSum, List.range_succ]

private theorem lev_list_map_sum_lower {α : Type*} (L : List α) (f : α → ℤ) (c : ℤ)
    (hf : ∀ a ∈ L, c ≤ f a) : (L.length : ℤ) * c ≤ (L.map f).sum := by
  induction L with
  | nil => simp
  | cons a L ih =>
    have ha := hf a (by simp)
    have hL := ih (fun b hb => hf b (by simp [hb]))
    simp only [List.length_cons, List.map_cons, List.sum_cons, Nat.cast_add, Nat.cast_one]
    nlinarith

/-- The diameter is at least one less than the number of points. -/
theorem LevNormalized.card_le (A : Finset ℤ) (l : ℕ) (hA : LevNormalized A l) :
    A.card ≤ l + 1 := by
  have h := Finset.card_le_card hA.1
  simpa using h

private theorem lev_effective_card_lower (A : Finset ℤ) (l n : ℕ) (h : n ≤ A.card) :
    (n : ℤ) - 1 ≤ levEffectiveCard l A := by
  unfold levEffectiveCard
  split_ifs <;> omega

/-- One genuine growth step with the uniform density parameter. -/
theorem lev_density_step (A : ℕ → Finset ℤ) (l : ℕ → ℕ) (n j : ℕ) (hn : 3 ≤ n)
    (hA : ∀ i ≤ j, LevNormalized (A i) (l i))
    (hcard : ∀ i ≤ j, n ≤ (A i).card)
    (hl : ∀ i ≤ j, l i ≤ l j) :
    (levPrefixSum A j).card +
      min ((l j : ℤ) - 1) (((j : ℤ) + 1) * ((n : ℤ) - 2)) + 1 ≤
        ((levPrefixSum A (j + 1)).card : ℤ) := by
  have hpos : 0 < l j := by
    have h := (hA j le_rfl).card_le (A j) (l j)
    have hc := hcard j le_rfl
    omega
  let L := (List.range j).map A
  have hL : ∀ B ∈ L, B.Nonempty := by
    intro B hB
    obtain ⟨i, hi, rfl⟩ := List.mem_map.mp hB
    exact ⟨0, (hA i (by simpa using (List.mem_range.mp hi).le)).2.1⟩
  have hb : ∀ B ∈ L ++ [A j], B ⊆ Finset.Icc 0 (l j : ℤ) := by
    intro B hB
    rcases List.mem_append.mp hB with hB | hB
    · obtain ⟨i, hi, rfl⟩ := List.mem_map.mp hB
      have hij : i ≤ j := (List.mem_range.mp hi).le
      exact (hA i hij).1.trans (Finset.Icc_subset_Icc le_rfl (by exact_mod_cast hl i hij))
    · have he : B = A j := by simpa using hB
      subst B
      exact (hA j le_rfl).1
  have hc : ((L ++ [A j]).length : ℤ) * ((n : ℤ) - 1) ≤
      ((L ++ [A j]).map (fun B => (levEffectiveCard (l j) B : ℤ))).sum := by
    apply lev_list_map_sum_lower
    intro B hB
    apply lev_effective_card_lower
    rcases List.mem_append.mp hB with hB | hB
    · obtain ⟨i, hi, rfl⟩ := List.mem_map.mp hB
      exact hcard i (List.mem_range.mp hi).le
    · have he : B = A j := by simpa using hB
      subst B
      exact hcard j le_rfl
  have hg := lev1997_growth L (A j) (l j) hpos hL hb
    (hA j le_rfl).2.1 (hA j le_rfl).2.2.1 (hA j le_rfl).2.2.2
  have hlen : L.length = j := by simp [L]
  simp only [List.length_append, List.length_singleton, Nat.cast_add, Nat.cast_one, hlen] at hc hg
  have hmin := min_le_min_left (l j : ℤ) (show
    ((j : ℤ) + 1) * ((n : ℤ) - 2) + 1 ≤
      ((L ++ [A j]).map (fun B => (levEffectiveCard (l j) B : ℤ))).sum - j by nlinarith)
  have he : min ((l j : ℤ) - 1) (((j : ℤ) + 1) * ((n : ℤ) - 2)) + 1 =
      min (l j : ℤ) (((j : ℤ) + 1) * ((n : ℤ) - 2) + 1) := by
    rw [← min_add_add_right]; congr 1; ring
  rw [levPrefixSum_succ]
  change ((L.sum).card : ℤ) + _ + 1 ≤ ((L.sum + A j).card : ℤ)
  linarith

/-- Telescope the actual growth steps. -/
theorem lev_density_telescoped (A : ℕ → Finset ℤ) (l : ℕ → ℕ) (n k : ℕ) (hn : 3 ≤ n)
    (hA : ∀ i < k, LevNormalized (A i) (l i))
    (hcard : ∀ i < k, n ≤ (A i).card)
    (hl : MonotoneOn l (Finset.range k)) :
    1 + ∑ i ∈ Finset.range k,
      (min ((l i : ℤ) - 1) (((i : ℤ) + 1) * ((n : ℤ) - 2)) + 1) ≤
        ((levPrefixSum A k).card : ℤ) := by
  induction k with
  | zero => simp
  | succ k ih =>
    have hprev := ih (fun i hi => hA i (by omega)) (fun i hi => hcard i (by omega))
      (fun i hi j hj hij => hl
        (Finset.mem_range.mpr (by have := Finset.mem_range.mp hi; omega))
        (Finset.mem_range.mpr (by have := Finset.mem_range.mp hj; omega)) hij)
    have hstep := lev_density_step A l n k hn
      (fun i hi => hA i (by omega)) (fun i hi => hcard i (by omega))
      (fun i hi => hl (Finset.mem_range.mpr (by omega)) (Finset.mem_range.mpr (by omega)) hi)
    rw [Finset.sum_range_succ]
    linarith

private theorem lev_min_double (t a : ℤ) : 2 * min t a - t = min t (2 * a - t) := by
  rcases le_total t a with h | h
  · rw [min_eq_left h, min_eq_left (by omega)]; omega
  · rw [min_eq_right h, min_eq_right (by omega)]

/-- Equation (1) in doubled, integral form. The diameter term is the sum
of the actual input diameters. -/
theorem lev_density_equation (A : ℕ → Finset ℤ) (l : ℕ → ℕ) (n k : ℕ) (hn : 3 ≤ n)
    (hA : ∀ i < k, LevNormalized (A i) (l i))
    (hcard : ∀ i < k, n ≤ (A i).card)
    (hl : MonotoneOn l (Finset.range k)) :
    (∑ i ∈ Finset.range k, (l i : ℤ)) +
      (∑ i ∈ Finset.range k,
        min ((l i : ℤ) - 1) (2 * ((i : ℤ) + 1) * ((n : ℤ) - 2) - ((l i : ℤ) - 1))) + k + 2 ≤
      2 * ((levPrefixSum A k).card : ℤ) := by
  have h := lev_density_telescoped A l n k hn hA hcard hl
  have he : (∑ i ∈ Finset.range k, (l i : ℤ)) +
      (∑ i ∈ Finset.range k,
        min ((l i : ℤ) - 1) (2 * ((i : ℤ) + 1) * ((n : ℤ) - 2) - ((l i : ℤ) - 1))) + k =
      2 * ∑ i ∈ Finset.range k,
        (min ((l i : ℤ) - 1) (((i : ℤ) + 1) * ((n : ℤ) - 2)) + 1) := by
    rw [← Finset.sum_add_distrib, Finset.mul_sum]
    have hk : (k : ℤ) = ∑ _i ∈ Finset.range k, (1 : ℤ) := by simp
    rw [hk, ← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro i hi
    have hh := lev_min_double ((l i : ℤ) - 1) (((i : ℤ) + 1) * ((n : ℤ) - 2))
    rw [← mul_assoc] at hh
    linarith
  linarith

/-- Proposition 1(ii): sufficiently many aperiodic summands give the
uniform doubled density lower bound. -/
theorem lev_density_bound (A : ℕ → Finset ℤ) (l : ℕ → ℕ) (n k : ℕ) (hn : 3 ≤ n)
    (hA : ∀ i < k, LevNormalized (A i) (l i))
    (hcard : ∀ i < k, n ≤ (A i).card)
    (hl : MonotoneOn l (Finset.range k))
    (hwidth : ∀ i < k, (l i : ℤ) - 1 ≤ (k : ℤ) * ((n : ℤ) - 2)) :
    (∑ i ∈ Finset.range k, (l i : ℤ)) + (k : ℤ) * ((n : ℤ) - 1) + 2 ≤
      2 * ((levPrefixSum A k).card : ℤ) := by
  have he := lev_density_equation A l n k hn hA hcard hl
  have hm := lev_ordered_min_sum k ((n : ℤ) - 2) (fun i => (l i : ℤ) - 1)
    (by omega)
    (fun i hi j hj hij => by have := hl hi hj hij; exact_mod_cast sub_le_sub_right (by exact_mod_cast this : (l i : ℤ) ≤ l j) 1)
    (fun i hi => by have hc := (hA i hi).card_le (A i) (l i); have hn' := hcard i hi; dsimp; omega)
    hwidth
  nlinarith

/-- Proposition 1(i), with the exact loss at the upper diameter. -/
theorem lev_density_bound_endpoint (A : ℕ → Finset ℤ) (l : ℕ → ℕ)
    (n k L : ℕ) (hn : 3 ≤ n)
    (hA : ∀ i < k, LevNormalized (A i) (l i))
    (hcard : ∀ i < k, n ≤ (A i).card)
    (hl : MonotoneOn l (Finset.range k))
    (hwidth : ∀ i < k, l i ≤ L) (hLn : n - 1 ≤ L)
    (hL : (L : ℤ) - 1 ≤ (k + 1 : ℕ) * ((n : ℤ) - 2)) :
    (∑ i ∈ Finset.range k, (l i : ℤ)) +
      (k + 1 : ℕ) * ((n : ℤ) - 1) - L + 2 ≤
        2 * ((levPrefixSum A k).card : ℤ) := by
  have he := lev_density_equation A l n k hn hA hcard hl
  have hm := lev_ordered_min_sum_endpoint k ((n : ℤ) - 2) ((L : ℤ) - 1)
    (fun i => (l i : ℤ) - 1) (by omega)
    (fun i hi j hj hij => by have := hl hi hj hij; exact_mod_cast sub_le_sub_right (by exact_mod_cast this : (l i : ℤ) ≤ l j) 1)
    (fun i hi => by have hc := (hA i hi).card_le (A i) (l i); have hn' := hcard i hi; dsimp; omega)
    (fun i hi => by have := hwidth i hi; dsimp; omega) (by omega) hL
  push_cast at hm ⊢
  nlinarith

/-- Every actual prefix sum lies in the interval determined by the sum
of the input diameters. -/
theorem levPrefixSum_subset_interval (A : ℕ → Finset ℤ) (l : ℕ → ℕ) (k : ℕ)
    (hA : ∀ i < k, A i ⊆ Finset.Icc 0 (l i : ℤ)) :
    levPrefixSum A k ⊆ Finset.Icc 0 (∑ i ∈ Finset.range k, (l i : ℤ)) := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [levPrefixSum_succ, Finset.sum_range_succ]
    intro x hx
    obtain ⟨a, ha, b, hb, rfl⟩ := Finset.mem_add.mp hx
    have ha' := Finset.mem_Icc.mp (ih (fun i hi => hA i (by omega)) ha)
    have hb' := Finset.mem_Icc.mp (hA k (by omega) hb)
    exact Finset.mem_Icc.mpr ⟨by omega, by omega⟩

/-- Both endpoints are attained, so the sum of the input diameters is
the actual diameter, rather than merely an ambient bound. -/
theorem levPrefixSum_endpoints (A : ℕ → Finset ℤ) (l : ℕ → ℕ) (k : ℕ)
    (hA : ∀ i < k, 0 ∈ A i ∧ (l i : ℤ) ∈ A i) :
    0 ∈ levPrefixSum A k ∧ (∑ i ∈ Finset.range k, (l i : ℤ)) ∈ levPrefixSum A k := by
  induction k with
  | zero => simp
  | succ k ih =>
    have hp := ih (fun i hi => hA i (by omega))
    rw [levPrefixSum_succ, Finset.sum_range_succ]
    constructor
    · simpa using Finset.add_mem_add hp.1 (hA k (by omega)).1
    · exact Finset.add_mem_add hp.2 (hA k (by omega)).2

end
end Optss
