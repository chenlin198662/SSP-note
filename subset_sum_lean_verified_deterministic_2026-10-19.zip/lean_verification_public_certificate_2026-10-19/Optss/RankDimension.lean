import Optss.SignedPotential
import Optss.RankPotentialBounds
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.LinearIndependent.Lemmas

/-!
# Actual span dimension and explicit rank thresholds

A maximal independent subfamily is selected from the actual finite input labels.
Its cardinality is the finrank of the current span, so the signed-potential
counting bound controls the actual rank, not just a supplied independent family.
The final theorems give explicit integer inequalities sufficient for a rank
threshold; no asymptotic scale assumption is hidden in their statements.
-/

namespace Optss
open scoped BigOperators Pointwise Classical
noncomputable section

section Selection
variable {ι K E : Type*} [Fintype ι] [DivisionRing K] [AddCommGroup E] [Module K E]

/-- The actual dimension of the span of all current live types. -/
def inputSpanRank (K : Type*) [DivisionRing K] {E ι : Type*} [AddCommGroup E]
    [Module K E] (v : ι → E) : ℕ := Module.finrank K (Submodule.span K (Set.range v))

/-- A full independent family can be selected from the original finite labels.
No basis vectors outside the input family are substituted into the counting proof. -/
theorem exists_independent_items_of_span_rank (v : ι → E) :
    ∃ labels : Fin (inputSpanRank K v) → ι,
      Function.Injective labels ∧ LinearIndependent K (fun j => v (labels j)) := by
  obtain ⟨κ, a, ha, hspan, hind⟩ := exists_linearIndependent' K v
  letI : Finite κ := Finite.of_injective a ha
  letI : Fintype κ := Fintype.ofFinite κ
  have hcard : inputSpanRank K v = Fintype.card κ := by
    unfold inputSpanRank
    rw [← hspan]
    exact finrank_span_eq_card hind
  let e : Fin (inputSpanRank K v) ≃ κ := (finCongr hcard).trans (Fintype.equivFin κ).symm
  refine ⟨a ∘ e, ha.comp e.injective, ?_⟩
  exact hind.comp e e.injective

end Selection

/-- Increasing the number of independent directions cannot decrease the
coefficient-simplex cardinality. -/
theorem choose_dimension_mono (k : ℕ) : Monotone (fun r => (k+r).choose r) := by
  intro a b hab
  change (k+a).choose a ≤ (k+b).choose b
  calc
    _ = (k+a).choose k := Nat.choose_symm_add.symm
    _ ≤ (k+b).choose k := Nat.choose_le_choose k (Nat.add_le_add_left hab k)
    _ = _ := Nat.choose_symm_add

/-- Any strict upper-threshold violation excludes that dimension and larger ones. -/
theorem rank_lt_of_simplex_bound (rank k D Pmax : ℕ)
    (hbound : (k+rank).choose rank ≤ Pmax) (hthreshold : Pmax < (k+D).choose D) :
    rank < D := by
  by_contra hnot
  have hle : D ≤ rank := by omega
  have hmono := choose_dimension_mono k hle
  change (k+D).choose D ≤ (k+rank).choose rank at hmono
  omega

/-- A division-free, explicit sufficient inequality for the binomial threshold. -/
theorem simplex_threshold_of_power (k D Pmax : ℕ)
    (hthreshold : D.factorial * Pmax < (k+1)^D) :
    Pmax < (k+D).choose D := by
  exact Nat.lt_of_mul_lt_mul_left
    (hthreshold.trans_le (pow_le_factorial_mul_choose k D))

section Rank
variable {ι K E : Type*} [Fintype ι] [DivisionRing K] [CharZero K]
  [AddCommGroup E] [Module K E] {d k : ℕ}

/-- The complete vector potential obstruction for the actual current span rank. -/
theorem inputSpanRank_vector_count_bound (original : ι → IntVec d) (current : ι → E)
    (h : PreservesSignedSums k original current) (N : Fin d → ℕ)
    (hN : ∀ i, InCenteredBox N (original i)) :
    (k + inputSpanRank K current).choose (inputSpanRank K current) ≤
      ∏ j, (2 * k * N j + 1) := by
  obtain ⟨labels, _, hind⟩ := exists_independent_items_of_span_rank (K := K) current
  exact independent_current_card_bound original current h N hN labels hind

/-- The complete scalar potential obstruction for the actual current span rank. -/
theorem inputSpanRank_scalar_count_bound (original : ι → ℤ) (current : ι → E)
    (h : PreservesSignedSums k original current) (N : ℕ)
    (hN : ∀ i, |original i| ≤ (N : ℤ)) :
    (k + inputSpanRank K current).choose (inputSpanRank K current) ≤ 2 * k * N + 1 := by
  obtain ⟨labels, _, hind⟩ := exists_independent_items_of_span_rank (K := K) current
  exact independent_current_scalar_card_bound original current h N hN labels hind

/-- Exact vector rank bound at any explicit binomial threshold. -/
theorem inputSpanRank_vector_lt (original : ι → IntVec d) (current : ι → E)
    (h : PreservesSignedSums k original current) (N : Fin d → ℕ)
    (hN : ∀ i, InCenteredBox N (original i)) (D : ℕ)
    (hthreshold : (∏ j, (2 * k * N j + 1)) < (k+D).choose D) :
    inputSpanRank K current < D :=
  rank_lt_of_simplex_bound _ k D _ (inputSpanRank_vector_count_bound original current h N hN) hthreshold

/-- Exact scalar rank bound at any explicit binomial threshold. -/
theorem inputSpanRank_scalar_lt (original : ι → ℤ) (current : ι → E)
    (h : PreservesSignedSums k original current) (N : ℕ)
    (hN : ∀ i, |original i| ≤ (N : ℤ)) (D : ℕ)
    (hthreshold : 2 * k * N + 1 < (k+D).choose D) :
    inputSpanRank K current < D :=
  rank_lt_of_simplex_bound _ k D _ (inputSpanRank_scalar_count_bound original current h N hN) hthreshold

/-- The factorial-power inequality is sufficient for the vector rank threshold. -/
theorem inputSpanRank_vector_lt_of_power (original : ι → IntVec d) (current : ι → E)
    (h : PreservesSignedSums k original current) (N : Fin d → ℕ)
    (hN : ∀ i, InCenteredBox N (original i)) (D : ℕ)
    (hthreshold : D.factorial * (∏ j, (2 * k * N j + 1)) < (k+1)^D) :
    inputSpanRank K current < D :=
  inputSpanRank_vector_lt original current h N hN D (simplex_threshold_of_power k D _ hthreshold)

/-- The factorial-power inequality is sufficient for the scalar rank threshold. -/
theorem inputSpanRank_scalar_lt_of_power (original : ι → ℤ) (current : ι → E)
    (h : PreservesSignedSums k original current) (N : ℕ)
    (hN : ∀ i, |original i| ≤ (N : ℤ)) (D : ℕ)
    (hthreshold : D.factorial * (2 * k * N + 1) < (k+1)^D) :
    inputSpanRank K current < D :=
  inputSpanRank_scalar_lt original current h N hN D (simplex_threshold_of_power k D _ hthreshold)

end Rank

/-- Separate the polynomial dependence on `k` from the fixed original box widths. -/
theorem potential_box_polynomial_bound {d : ℕ} (N : Fin d → ℕ) (k : ℕ) :
    (∏ j, (2*k*N j+1)) ≤ (k+1)^d * ∏ j, (2*N j+1) := by
  calc
    _ ≤ ∏ j, ((k+1) * (2*N j+1)) := by
      apply Finset.prod_le_prod
      · intro j _; omega
      · intro j _; nlinarith
    _ = _ := by rw [Finset.prod_mul_distrib]; simp

/-- An explicit degree-separated condition sufficient for the vector threshold.
The exponent `D-d` is positive in the manuscript's intended application. -/
theorem vector_rank_power_threshold {d : ℕ} (N : Fin d → ℕ) (k D : ℕ) (hD : d ≤ D)
    (hthreshold : D.factorial * (∏ j, (2*N j+1)) < (k+1)^(D-d)) :
    D.factorial * (∏ j, (2*k*N j+1)) < (k+1)^D := by
  calc
    _ ≤ D.factorial * ((k+1)^d * ∏ j, (2*N j+1)) :=
      Nat.mul_le_mul_left _ (potential_box_polynomial_bound N k)
    _ = (k+1)^d * (D.factorial * ∏ j, (2*N j+1)) := by ring
    _ < (k+1)^d * (k+1)^(D-d) := (Nat.mul_lt_mul_left (pow_pos (by omega) _)).mpr hthreshold
    _ = (k+1)^D := by rw [← pow_add, Nat.add_sub_of_le hD]

/-- Scalar version of the explicit threshold with the dependence on `k` separated. -/
theorem scalar_rank_power_threshold (N k D : ℕ) (hD : 1 ≤ D)
    (hthreshold : D.factorial * (2*N+1) < (k+1)^(D-1)) :
    D.factorial * (2*k*N+1) < (k+1)^D := by
  have h := vector_rank_power_threshold (d := 1) (fun _ => N) k D hD
    (by simpa using hthreshold)
  simpa using h

section ExplicitRank
variable {ι K E : Type*} [Fintype ι] [DivisionRing K] [CharZero K]
  [AddCommGroup E] [Module K E] {d k : ℕ}

/-- Actual vector rank under a fully numerical, degree-separated threshold. -/
theorem inputSpanRank_vector_lt_explicit (original : ι → IntVec d) (current : ι → E)
    (h : PreservesSignedSums k original current) (N : Fin d → ℕ)
    (hN : ∀ i, InCenteredBox N (original i)) (D : ℕ) (hD : d ≤ D)
    (hthreshold : D.factorial * (∏ j, (2*N j+1)) < (k+1)^(D-d)) :
    inputSpanRank K current < D :=
  inputSpanRank_vector_lt_of_power original current h N hN D
    (vector_rank_power_threshold N k D hD hthreshold)

/-- Actual scalar rank under a fully numerical, degree-separated threshold. -/
theorem inputSpanRank_scalar_lt_explicit (original : ι → ℤ) (current : ι → E)
    (h : PreservesSignedSums k original current) (N : ℕ)
    (hN : ∀ i, |original i| ≤ (N : ℤ)) (D : ℕ) (hD : 1 ≤ D)
    (hthreshold : D.factorial * (2*N+1) < (k+1)^(D-1)) :
    inputSpanRank K current < D :=
  inputSpanRank_scalar_lt_of_power original current h N hN D
    (scalar_rank_power_threshold N k D hD hthreshold)

end ExplicitRank

end
end Optss
