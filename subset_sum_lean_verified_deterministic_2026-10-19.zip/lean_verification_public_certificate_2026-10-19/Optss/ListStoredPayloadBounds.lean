import Optss.ScalarOutputWork
import Optss.EncodedReductionWork

/-!
# Payload growth along the encoded cached trace

All statements are unconditional. A freshly computed scalar's stored payload
is covered by its concrete arithmetic work; retained matrix cells preserve
an existing bound. Therefore table construction and integer reduction increase
maximum payload length by at most their accumulated scalar work. The exact
list-storage projection theorems transfer these bounds without re-encoding.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

private theorem get_set {α : Type*} {n : ℕ} (v : Vector α n)
    (k i : Fin n) (a : α) :
    (v.set k.val a k.isLt).get i = if i = k then a else v.get i := by
  change (v.set k.val a k.isLt)[i.val] = _
  rw [Vector.getElem_set]
  split <;> rename_i h
  · have he : i = k := Fin.ext h.symm
    simp [he]
  · have he : i ≠ k := fun he => h (congrArg Fin.val he.symm)
    simp [he]
    rfl

theorem encodedProductSum_output_le_work {ι : Type*} (u v : ι → BitListFraction) (is : List ι) :
    (encodedProductSum u v is).numerator.length+(encodedProductSum u v is).denominator.length ≤
      1+encodedProductSumWork u v is := by
  cases is with
  | nil => simp [encodedProductSum,encodedProductSumWork,bitListFractionZero]
  | cons i is =>
    have h := bitListFractionAdd_output_le_cost (bitListFractionMul (u i) (v i)) (encodedProductSum u v is)
    rw [encodedProductSum,encodedProductSumWork]
    omega

theorem encodedRationalDot_output_le_work (u v : Fin d → BitListFraction) :
    (encodedRationalDot u v).numerator.length+(encodedRationalDot u v).denominator.length ≤
      1+encodedRationalDotWork u v := encodedProductSum_output_le_work _ _ _

theorem encodedGsCoefficient_output_le_work (A T : BitRationalMatrixData r d) (k j : Fin r) :
    (encodedGsCoefficient A T k j).numerator.length+(encodedGsCoefficient A T k j).denominator.length ≤
      encodedGsCoefficientWork A T k j := by
  have h := bitListFractionDiv_output_le_cost
    (encodedRationalDot (T.get j).get (A.get k).get)
    (encodedRationalDot (T.get j).get (T.get j).get)
  unfold encodedGsCoefficient encodedGsCoefficientWork
  dsimp only
  omega

theorem encodedGSCoefficients_output_le_work (A T : BitRationalMatrixData r d) (k i : Fin r) :
    ((encodedGSCoefficients A T k).get i).numerator.length+
      ((encodedGSCoefficients A T k).get i).denominator.length ≤
      1+∑ j : Fin r, if j < k then encodedGsCoefficientWork A T k j else 0 := by
  simp only [encodedGSCoefficients,get_ofFn]
  split_ifs with hi
  · have h := encodedGsCoefficient_output_le_work A T k i
    have hs : (if i < k then encodedGsCoefficientWork A T k i else 0) ≤
        ∑ j : Fin r, if j < k then encodedGsCoefficientWork A T k j else 0 :=
      Finset.single_le_sum (f := fun j : Fin r => if j < k then encodedGsCoefficientWork A T k j else 0) (fun j _ => Nat.zero_le _) (Finset.mem_univ i)
    simp only [hi,↓reduceIte] at hs
    omega
  · simp only [bitListFractionZero,List.length_nil,List.length_cons]
    omega

theorem encodedGSRow_output_le_work (A T : BitRationalMatrixData r d) (k : Fin r) (l : Fin d) :
    ((encodedGSRow A T k).get l).numerator.length+((encodedGSRow A T k).get l).denominator.length ≤
      encodedGSRowWork A T k := by
  let coeff := encodedGSCoefficients A T k
  let u := fun i : Finset.Iio k => coeff.get i
  let v := fun (j : Fin d) (i : Finset.Iio k) => (T.get i).get j
  let is := List.ofFn (lowerFinEquiv k)
  let w := fun j : Fin d => encodedProductSumWork u (v j) is+
    bitListFractionSubCost ((A.get k).get j) (encodedProductSum u (v j) is)
  have h := bitListFractionSub_output_le_cost ((A.get k).get l) (encodedProductSum u (v l) is)
  have hs : w l ≤ ∑ j : Fin d, w j := Finset.single_le_sum (fun j _ => Nat.zero_le _) (Finset.mem_univ l)
  simp only [encodedGSRow,get_ofFn]
  change (bitListFractionSub ((A.get k).get l) (encodedProductSum u (v l) is)).numerator.length+
    (bitListFractionSub ((A.get k).get l) (encodedProductSum u (v l) is)).denominator.length ≤
    (∑ i : Fin r, if i < k then encodedGsCoefficientWork A T k i else 0)+(∑ j : Fin d, w j)
  have hw : (bitListFractionSub ((A.get k).get l) (encodedProductSum u (v l) is)).numerator.length+
      (bitListFractionSub ((A.get k).get l) (encodedProductSum u (v l) is)).denominator.length ≤ w l := by
    dsimp only [w]
    omega
  exact hw.trans (hs.trans (Nat.le_add_left _ _))

theorem encodedGSTable_output_le_work (A : BitRationalMatrixData r d) (n : ℕ) (hn : n ≤ r)
    (i : Fin r) (j : Fin d) :
    (((encodedGSTable A n hn).get i).get j).numerator.length+
      (((encodedGSTable A n hn).get i).get j).denominator.length ≤ 1+encodedGSTableWork A n hn := by
  induction n with
  | zero => simp [encodedGSTable,encodedGSTableWork,Vector.get,bitListFractionZero]
  | succ n ih =>
    let k : Fin r := ⟨n,by omega⟩
    let T := encodedGSTable A n (by omega)
    have hr := encodedGSRow_output_le_work A T k j
    have ht := ih (by omega)
    change ((T.get i).get j).numerator.length+((T.get i).get j).denominator.length ≤
      1+encodedGSTableWork A n (by omega) at ht
    rw [encodedGSTable,encodedGSTableWork]
    change (((T.set k.val (encodedGSRow A T k) k.isLt).get i).get j).numerator.length+
      (((T.set k.val (encodedGSRow A T k) k.isLt).get i).get j).denominator.length ≤
        1+(encodedGSTableWork A n (by omega)+encodedGSRowWork A T k)
    rw [get_set]
    split_ifs <;> omega

theorem encodedIntegerRowUpdate_output_le_work (D : BitIntegerMatrixData r d) (k j : Fin r)
    (q : BitListInteger) (B : ℕ) (hB : ∀ i l, ((D.get i).get l).digits.length ≤ B) (i : Fin r) (l : Fin d) :
    (((bitListIntegerRowUpdate D k j q).get i).get l).digits.length ≤
      B+encodedIntegerRowUpdateWork D k j q := by
  have h := bitListIntegerRowCell_output_le_cost ((D.get k).get l) q ((D.get j).get l)
  have hs : bitListIntegerRowCellCost ((D.get k).get l) q ((D.get j).get l) ≤
      encodedIntegerRowUpdateWork D k j q :=
    Finset.single_le_sum (f := fun a : Fin d => bitListIntegerRowCellCost ((D.get k).get a) q ((D.get j).get a)) (fun a _ => Nat.zero_le _) (Finset.mem_univ l)
  rw [bitListIntegerRowUpdate,get_set]
  split_ifs
  · rw [get_ofFn]
    omega
  · exact (hB i l).trans (by omega)

theorem encodedReduceIntegerRow_output_le_work (D : BitIntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (hn : n ≤ k.val) (B : ℕ)
    (hB : ∀ i l, ((D.get i).get l).digits.length ≤ B) (i : Fin r) (l : Fin d) :
    (((encodedReduceIntegerRow D k n hn).get i).get l).digits.length ≤
      B+encodedReduceIntegerRowWork D k n hn := by
  induction n generalizing D B with
  | zero => simpa [encodedReduceIntegerRow,encodedReduceIntegerRowWork] using hB i l
  | succ n ih =>
    let j : Fin r := ⟨n,by omega⟩
    let Q := encodedRationalIntegerRows D
    let T := encodedGSTable Q r le_rfl
    let c := encodedGsCoefficient Q T k j
    let q := encodedRoundInteger c
    let W := bitListIntegerRowUpdate D k j q
    have hW := encodedIntegerRowUpdate_output_le_work D k j q B hB
    have hi := ih W (by omega) (B+encodedIntegerRowUpdateWork D k j q) hW
    rw [encodedReduceIntegerRow,encodedReduceIntegerRowWork]
    change (((encodedReduceIntegerRow W k n _).get i).get l).digits.length ≤
      B+(encodedGSTableWork Q r le_rfl+encodedGsCoefficientWork Q T k j+
        bitListFractionRoundCost c+encodedIntegerRowUpdateWork D k j q+encodedReduceIntegerRowWork W k n _)
    omega

theorem encodedReduceIntegerAll_output_le_work (D : BitIntegerMatrixData r d)
    (n : ℕ) (hn : n ≤ r) (B : ℕ)
    (hB : ∀ i l, ((D.get i).get l).digits.length ≤ B) (i : Fin r) (l : Fin d) :
    (((encodedReduceIntegerAll D n hn).get i).get l).digits.length ≤
      B+encodedReduceIntegerAllWork D n hn := by
  induction n generalizing i l with
  | zero => simpa [encodedReduceIntegerAll,encodedReduceIntegerAllWork] using hB i l
  | succ n ih =>
    let C := encodedReduceIntegerAll D n (by omega)
    have hC : ∀ a b, ((C.get a).get b).digits.length ≤ B+encodedReduceIntegerAllWork D n (by omega) := by
      intro a b
      exact ih (by omega) a b
    have hr := encodedReduceIntegerRow_output_le_work C ⟨n,by omega⟩ n le_rfl
      (B+encodedReduceIntegerAllWork D n (by omega)) hC i l
    rw [encodedReduceIntegerAll,encodedReduceIntegerAllWork]
    change (((encodedReduceIntegerRow C ⟨n,by omega⟩ n le_rfl).get i).get l).digits.length ≤
      B+(encodedReduceIntegerAllWork D n (by omega)+encodedReduceIntegerRowWork C ⟨n,by omega⟩ n le_rfl)
    omega

theorem encodedSwapRows_output_bound (D : BitIntegerMatrixData r d) (j k : Fin r) (B : ℕ)
    (hB : ∀ i l, ((D.get i).get l).digits.length ≤ B) (i : Fin r) (l : Fin d) :
    (((encodedSwapRows D j k).get i).get l).digits.length ≤ B := by
  simp only [encodedSwapRows,get_ofFn]
  exact hB _ _

/-- Every recursive accumulator belongs to a suffix of the original dot list. -/
theorem encodedProductSumWork_append_right_le {ι : Type*} (u v : ι → BitListFraction)
    (pre suffix : List ι) :
    encodedProductSumWork u v suffix ≤ encodedProductSumWork u v (pre++suffix) := by
  induction pre with
  | nil => rfl
  | cons i pre ih =>
    rw [List.cons_append,encodedProductSumWork]
    omega

theorem encodedProductSum_suffix_output_le_work {ι : Type*} (u v : ι → BitListFraction)
    (pre suffix : List ι) :
    (encodedProductSum u v suffix).numerator.length+(encodedProductSum u v suffix).denominator.length ≤
      1+encodedProductSumWork u v (pre++suffix) :=
  (encodedProductSum_output_le_work u v suffix).trans
    (Nat.add_le_add_left (encodedProductSumWork_append_right_le u v pre suffix) 1)

/-- The maximum retained integer payload grows at most by accumulated scalar
work along the actual loop, including early termination. -/
theorem encodedReductionFuel_output_le_work (fuel : List Bool) (D : BitIntegerMatrixData r d)
    (B : ℕ) (hB : ∀ i l, ((D.get i).get l).digits.length ≤ B) (i : Fin r) (l : Fin d) :
    ((((encodedReductionFuel fuel D).rows).get i).get l).digits.length ≤
      B+encodedReductionFuelWork fuel D := by
  induction fuel generalizing D B with
  | nil => simpa [encodedReductionFuel,encodedReductionFuelWork] using hB i l
  | cons b fuel ih =>
    let C := encodedReduceIntegerAll D r le_rfl
    have hC : ∀ a b, ((C.get a).get b).digits.length ≤ B+encodedReduceIntegerAllWork D r le_rfl :=
      encodedReduceIntegerAll_output_le_work D r le_rfl B hB
    rw [encodedReductionFuel,encodedReductionFuelWork]
    split_ifs with h
    · let p := leastPairInFinset (encodedFailingAdjacentPairs C) h
      let W := encodedSwapRows C p.1 p.2
      have hW := encodedSwapRows_output_bound C p.1 p.2
        (B+encodedReduceIntegerAllWork D r le_rfl) hC
      have hi := ih W (B+encodedReduceIntegerAllWork D r le_rfl) hW
      change ((((encodedReductionFuel fuel W).rows).get i).get l).digits.length ≤
        B+(encodedReduceIntegerAllWork D r le_rfl+encodedFailingAdjacentPairsWork C+
          encodedReductionFuelWork fuel W)
      omega
    · have hi := hC i l
      change ((C.get i).get l).digits.length ≤
        B+(encodedReduceIntegerAllWork D r le_rfl+encodedFailingAdjacentPairsWork C)
      omega

end Optss
