import Optss.BinaryRationalCost

/-!
# Arithmetic bases in terms of original input bits

The Gram potential can be large as an integer, but its bit length is polynomial
in dimension and input bit length. The fixed polynomial bases controlling all
partial sweeps inherit explicit logarithmic input-height dependence.
-/

namespace Optss
variable {r d : ℕ}

theorem nat_add_size_le_sum (a b : ℕ) : (a+b).size ≤ a.size+b.size+1 :=
  (nat_add_bits_le a b).trans (by omega)

theorem nat_succ_size_le (a : ℕ) : (a+1).size ≤ a.size+1 := by
  apply Nat.size_le.mpr
  rw [pow_succ]
  have ha := Nat.lt_size_self a
  have hp : 0 < 2^a.size := by positivity
  omega

theorem nat_square_size_le (a : ℕ) : (a^2).size ≤ 2*a.size := by
  simpa only [pow_two, two_mul] using nat_mul_size_le a a

theorem nat_max_size_le_sum (a b : ℕ) : (max a b).size ≤ a.size+b.size := by
  rcases le_total a b with h|h
  · rw [max_eq_right h]; omega
  · rw [max_eq_left h]; omega

theorem latticeHeightBase_bits (r d H : ℕ) :
    ((r+1)*(d+1)*(H+1)^2).size ≤ r.size+d.size+2*H.size+4 := by
  have h₁ := nat_mul_size_le ((r+1)*(d+1)) ((H+1)^2)
  have h₂ := nat_mul_size_le (r+1) (d+1)
  have hr := nat_succ_size_le r
  have hd := nat_succ_size_le d
  have hH := nat_succ_size_le H
  have hsq := nat_square_size_le (H+1)
  omega

theorem gramPotential_input_bits (A : Matrix (Fin r) (Fin d) ℤ) (H : ℕ)
    (hA : ∀ i j, |A i j| ≤ (H:ℤ)) :
    (gramPotential A).size ≤ (r*(r+1)+1)*(r.size+d.size+2*H.size+4) := by
  let B := (r+1)*(d+1)*(H+1)^2
  have hB : 1 ≤ B := by
    have hb : 0 < B := by dsimp [B]; positivity
    omega
  have hp : gramPotential A ≤ B^(r*(r+1)) := by
    calc
      _ ≤ (latticeInputGramBound r d H)^(r+1) := gramPotential_height_bound A H hA
      _ ≤ (B^r)^(r+1) := Nat.pow_le_pow_left (latticeInputGramBound_le_power r d H) _
      _ = _ := by rw [pow_mul]
  have hs : (gramPotential A).size ≤ (r*(r+1)+1)*B.size :=
    nat_size_le_of_le_pow (by omega) (hp.trans (Nat.pow_le_pow_right hB (by omega)))
  exact hs.trans (Nat.mul_le_mul_left _ (latticeHeightBase_bits r d H))

theorem partialReductionGrowth_bits (r P : ℕ) :
    (partialReductionGrowth r P).size ≤ r.size+3*P.size+2 := by
  have hsq := nat_square_size_le P
  have hs := nat_succ_size_le (P^2)
  have hrp := nat_mul_size_le r P
  have hm := nat_mul_size_le (P^2+1) (r*P)
  have hfin := nat_succ_size_le ((P^2+1)*(r*P))
  unfold partialReductionGrowth
  rw [Nat.add_comm 1]
  omega

theorem sweepArithmeticBase_bits (r d H P : ℕ) :
    (sweepArithmeticBase r d H P).size ≤
      3*H.size+2*r.size+2*d.size+5*P.size+12 := by
  have hrp := nat_mul_size_le r P
  have hs := nat_square_size_le H
  have hd := nat_mul_size_le d (H^2)
  have hg := partialReductionGrowth_bits r P
  have h1 := nat_add_size_le_sum 8 H
  have h2 := nat_add_size_le_sum (8+H) (r*P)
  have h3 := nat_add_size_le_sum (8+H+r*P) (d*H^2)
  have h4 := nat_add_size_le_sum (8+H+r*P+d*H^2) (partialReductionGrowth r P)
  have h5 := nat_add_size_le_sum (8+H+r*P+d*H^2+partialReductionGrowth r P) d
  have h6 := nat_add_size_le_sum (8+H+r*P+d*H^2+partialReductionGrowth r P+d) P
  have h8 : Nat.size 8 = 4 := by
    change Nat.size (2^3) = 3+1
    exact Nat.size_pow
  unfold sweepArithmeticBase
  omega

theorem globalSweepArithmeticBase_bits (r d H P : ℕ) :
    (sweepArithmeticBase r d (max H (r*P)) P).size ≤
      3*H.size+5*r.size+2*d.size+8*P.size+12 := by
  have hm := nat_max_size_le_sum H (r*P)
  have hp := nat_mul_size_le r P
  have hbase := sweepArithmeticBase_bits r d (max H (r*P)) P
  omega

/-- One explicit polynomial in rank and logarithmic original height controls
the uniform arithmetic base for every pass of the reduction. -/
theorem globalSweepArithmeticBase_input_bits (A : Matrix (Fin r) (Fin d) ℤ) (H : ℕ)
    (hA : ∀ i j, |A i j| ≤ (H:ℤ)) :
    (sweepArithmeticBase r d (max H (r*gramPotential A)) (gramPotential A)).size ≤
      3*H.size+5*r.size+2*d.size+
        8*(r*(r+1)+1)*(r.size+d.size+2*H.size+4)+12 := by
  have hb := globalSweepArithmeticBase_bits r d H (gramPotential A)
  have hp := gramPotential_input_bits A H hA
  nlinarith

/-- Three potential contractions dominate one factor of two. Thus the actual
number of swaps is bounded directly by input potential bits, without real logs. -/
theorem IntegerLLLResult.swapCount_lt_three_potential_bits (A : Matrix (Fin r) (Fin d) ℤ)
    (out : IntegerLLLResult A) : out.swapCount < 3*(gramPotential A).size := by
  have hpow : (2:ℝ)^(out.swapCount/3) ≤ gramPotential A := by
    calc
      _ ≤ ((4/3:ℝ)^3)^(out.swapCount/3) :=
        pow_le_pow_left₀ (by norm_num) (by norm_num) _
      _ = (4/3:ℝ)^(3*(out.swapCount/3)) := by rw [pow_mul]
      _ ≤ (4/3:ℝ)^out.swapCount := pow_le_pow_right₀ (by norm_num) (by omega)
      _ ≤ _ := out.swapCount_ratio_le A
  have hp : (gramPotential A:ℝ) < (2:ℝ)^(gramPotential A).size := by
    exact_mod_cast Nat.lt_size_self (gramPotential A)
  have hs : out.swapCount/3 < (gramPotential A).size :=
    (pow_lt_pow_iff_right₀ (by norm_num : (1:ℝ)<2)).mp (hpow.trans_lt hp)
  omega

theorem IntegerLLLResult.swapCount_input_bits (A : Matrix (Fin r) (Fin d) ℤ)
    (out : IntegerLLLResult A) (H : ℕ) (hA : ∀ i j, |A i j| ≤ (H:ℤ)) :
    out.swapCount+1 ≤ 3*(r*(r+1)+1)*(r.size+d.size+2*H.size+4) := by
  have hs := out.swapCount_lt_three_potential_bits A
  have hp := gramPotential_input_bits A H hA
  nlinarith

end Optss
