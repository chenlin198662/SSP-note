import Optss.GridAffine
import Optss.MixedRadix
import Mathlib.LinearAlgebra.Matrix.ToLin

/-!
# Recovering the full old-vector map

This file makes the finite-grid argument in Lemma 3.3 and Corollary 9.6
explicit. The fill is supplied as actual coefficient witnesses; affineness and
the decoder are derived from the encoding's injectivity. The asymptotic GAP
construction and its running time are separate obligations.
-/

namespace Optss

open scoped BigOperators

/-- Natural offsets enumerate every lattice point of a translated integer box. -/
def integerGridPoint {r : ℕ} (origin : IntVec r) (x : Fin r → ℕ) : IntVec r :=
  origin + fun i => (x i : ℤ)

@[simp] theorem integerGridPoint_zero {r : ℕ} (origin : IntVec r) :
    integerGridPoint origin 0 = origin := by ext i; simp [integerGridPoint]

theorem integerGridPoint_step {r : ℕ} (origin : IntVec r)
    (x : Fin r → ℕ) (i : Fin r) :
    integerGridPoint origin (gridStep x i) = integerGridPoint origin x + Pi.single i 1 := by
  ext j
  by_cases h : j = i
  · subst j; simp [integerGridPoint, add_assoc]
  · simp [integerGridPoint, gridStep_apply_ne _ h, Pi.single_eq_of_ne h]

private theorem le_gridStep {ι : Type*} [DecidableEq ι] (x : ι → ℕ) (i : ι) :
    x ≤ gridStep x i := fun _ => Nat.le_add_right _ _

/-- Encoding injectivity forces every mixed and pure second difference to vanish. -/
theorem gridSecondDifferences_of_encoding {r : ℕ} {G H : Type*}
    [AddCommGroup G] [AddCommGroup H]
    (encode : G →+ H) (project : IntVec r →+ H) (D : Set G)
    (hinj : Set.InjOn encode D) (origin : IntVec r) (m : Fin r → ℕ)
    (f : (Fin r → ℕ) → G)
    (hf : ∀ x, x ≤ m → encode (f x) = project (integerGridPoint origin x))
    (hsum : ∀ x y, x ≤ m → y ≤ m → f x + f y ∈ D) :
    GridSecondDifferences f m := by
  intro x i j hdouble
  have hi : gridStep x i ≤ m := (le_gridStep _ j).trans hdouble
  have hj : gridStep x j ≤ m := (le_gridStep _ i).trans
    (by simpa only [gridStep_comm] using hdouble)
  have hx : x ≤ m := (le_gridStep x i).trans hi
  apply hinj (hsum x _ hx hdouble) (hsum _ _ hi hj)
  simp only [map_add, hf _ hx, hf _ hdouble, hf _ hi, hf _ hj,
    integerGridPoint_step, map_add]
  abel

/-- Adding two centered-box vectors adds their width bounds. -/
theorem inCenteredBox_add {d : ℕ} {a b : Fin d → ℕ} {x y : IntVec d}
    (hx : InCenteredBox a x) (hy : InCenteredBox b y) :
    InCenteredBox (fun i => a i + b i) (x + y) := by
  intro i
  simpa only [Pi.add_apply, Nat.cast_add] using
    (abs_add_le (x i) (y i)).trans (add_le_add (hx i) (hy i))

theorem inCenteredBox_mono {d : ℕ} {a b : Fin d → ℕ} {x : IntVec d}
    (hx : InCenteredBox a x) (hab : ∀ i, a i ≤ b i) : InCenteredBox b x := by
  intro i
  exact (hx i).trans (by exact_mod_cast hab i)

/-- A displacement lying within the box widths can occur between two grid points.
This handles negative displacements and widths zero without an interior-point assumption. -/
theorem exists_grid_displacement {r : ℕ} (m : Fin r → ℕ) (u : IntVec r)
    (hu : InCenteredBox m u) :
    ∃ x y : Fin r → ℕ, x ≤ m ∧ y ≤ m ∧
      (fun i => (y i : ℤ)) - (fun i => (x i : ℤ)) = u := by
  refine ⟨fun i => (-u i).toNat, fun i => (u i).toNat, ?_, ?_, ?_⟩
  · intro i
    change (-u i).toNat ≤ m i
    have hi := abs_le.mp (hu i)
    omega
  · intro i
    change (u i).toNat ≤ m i
    have hi := abs_le.mp (hu i)
    omega
  · ext i
    simp only [Pi.sub_apply]
    omega

/-- The decoder exists whenever a complete coefficient box is filled by old
vectors bounded by `q` input boxes, and the encoding is injective on `2q` boxes.
All coordinate neighbors are present, and every retained coefficient displacement
fits in the fill widths. These are the explicit size conditions used in Lemma 3.3. -/
theorem oldVectorDecoder_of_bounded_fill {r d : ℕ} {α : Type*}
    (encode : IntVec d →+ ℤ) (project : IntVec r →+ ℤ)
    (p : Fin d → ℕ) (q : ℕ) (hq : 1 ≤ q)
    (hinj : Set.InjOn encode {x | InCenteredBox (fun i => 2 * q * p i) x})
    (origin : IntVec r) (m : Fin r → ℕ) (hm : ∀ i, 1 ≤ m i)
    (f : (Fin r → ℕ) → IntVec d)
    (hf : ∀ x, x ≤ m → encode (f x) = project (integerGridPoint origin x))
    (hbound : ∀ x, x ≤ m → InCenteredBox (fun i => q * p i) (f x))
    (u : α → IntVec r) (v : α → IntVec d)
    (hu : ∀ a, InCenteredBox m (u a)) (hv : ∀ a, InCenteredBox p (v a))
    (hrep : ∀ a, encode (v a) = project (u a)) :
    ∃ F : IntVec r →+ IntVec d,
      (∀ a, F (u a) = v a) ∧ encode.comp F = project ∧
      (∀ x, x ≤ m → f x = f 0 + F (fun i => (x i : ℤ))) := by
  let a : Fin r → IntVec d := fun i => f (gridStep 0 i) - f 0
  let F := gridLinearPart a
  have hlocal : GridSecondDifferences f m := by
    apply gridSecondDifferences_of_encoding encode project _ hinj origin m f hf
    intro x y hx hy
    exact inCenteredBox_mono (inCenteredBox_add (hbound x hx) (hbound y hy))
      (fun i => by nlinarith)
  have haff : ∀ x, x ≤ m → f x = f 0 + F (fun i => (x i : ℤ)) :=
    fun x hx => grid_affine_integer_formula f m hlocal x hx
  have hz : (0 : Fin r → ℕ) ≤ m := fun _ => Nat.zero_le _
  have hneighbor (i : Fin r) : gridStep 0 i ≤ m := by
    intro j
    by_cases h : j = i
    · subst j; simpa using hm i
    · simp [gridStep_apply_ne _ h]
  have ha (i : Fin r) : encode (a i) = project (Pi.single i 1) := by
    dsimp [a]
    rw [map_sub, hf _ (hneighbor i), hf _ hz, integerGridPoint_step,
      integerGridPoint_zero, map_add]
    abel
  refine ⟨F, ?_, ?_, haff⟩
  · intro label
    obtain ⟨x, y, hx, hy, hdisp⟩ := exists_grid_displacement m (u label) (hu label)
    have hFy : InCenteredBox (fun i => 2 * q * p i) (f y) :=
      inCenteredBox_mono (hbound y hy) (fun i => by nlinarith)
    have hFxv : InCenteredBox (fun i => 2 * q * p i) (f x + v label) := by
      apply inCenteredBox_mono (inCenteredBox_add (hbound x hx) (hv label))
      intro i
      nlinarith
    have he : f y = f x + v label := by
      apply hinj hFy hFxv
      rw [map_add, hf _ hy, hf _ hx, hrep, ← map_add]
      congr 1
      dsimp [integerGridPoint]
      have : (fun i => (y i : ℤ)) = (fun i => (x i : ℤ)) + u label := by
        exact sub_eq_iff_eq_add.mp hdisp |>.trans (add_comm _ _)
      rw [this, add_assoc]
    rw [haff y hy, haff x hx] at he
    have hh : F (fun i => (y i : ℤ)) - F (fun i => (x i : ℤ)) = v label := by
      apply sub_eq_iff_eq_add.mpr
      have ht : F (fun i => (y i : ℤ)) = F (fun i => (x i : ℤ)) + v label :=
        add_left_cancel (he.trans (add_assoc _ _ _))
      simpa [add_comm] using ht
    rw [← map_sub, hdisp] at hh
    exact hh
  · apply AddMonoidHom.ext
    intro x
    change encode (∑ i, x i • a i) = project x
    rw [map_sum]
    have hdecomp : x = ∑ i, x i • (Pi.single i 1 : IntVec r) := by
      ext j
      simp [Pi.single_apply, ite_smul]
    calc
      (∑ i, encode (x i • a i)) = ∑ i, x i • project (Pi.single i 1) := by
        apply Finset.sum_congr rfl
        intro i _
        rw [map_zsmul, ha]
      _ = project (∑ i, x i • (Pi.single i 1 : IntVec r)) := by
        rw [map_sum]
        simp only [map_zsmul]
      _ = project x := congrArg project hdecomp.symm

/-- The homomorphism in the decoder is represented by an integer matrix. -/
theorem integer_hom_eq_matrix {r d : ℕ} (F : IntVec r →+ IntVec d) :
    ∃ M : Matrix (Fin d) (Fin r) ℤ, ∀ x, M.mulVec x = F x := by
  refine ⟨fun j i => F (Pi.single i 1) j, ?_⟩
  intro x
  have hdecomp : x = ∑ i, x i • (Pi.single i 1 : IntVec r) := by
    ext j
    simp [Pi.single_apply, ite_smul]
  conv_rhs => rw [hdecomp, map_sum]
  simp_rw [map_zsmul]
  ext j
  simp only [Matrix.mulVec, dotProduct, Finset.sum_apply,
    Pi.smul_apply, zsmul_eq_mul]
  apply Finset.sum_congr rfl
  intro i _
  change F (Pi.single i 1) j * x i = x i * F (Pi.single i 1) j
  exact mul_comm _ _

/-- Every sum of `s.card` input vectors lies in the correspondingly dilated box. -/
theorem inCenteredBox_finset_sum {d : ℕ} {α : Type*}
    (p : Fin d → ℕ) (v : α → IntVec d) (s : Finset α)
    (hv : ∀ i ∈ s, InCenteredBox p (v i)) :
    InCenteredBox (fun j => s.card * p j) (∑ i ∈ s, v i) := by
  intro j
  simp only [Finset.sum_apply]
  calc
    |∑ i ∈ s, v i j| ≤ ∑ i ∈ s, |v i j| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _i ∈ s, (p j : ℤ) := Finset.sum_le_sum (fun i hi => hv i hi j)
    _ = (s.card * p j : ℕ) := by simp

/-- Stored reserve-subset witnesses provide a bounded lift of every grid point.
Repeated input values remain separate labels, so this applies to multisets. -/
theorem exists_bounded_fill_of_subset_witnesses {r d : ℕ} {α : Type*}
    (encode : IntVec d →+ ℤ) (project : IntVec r →+ ℤ)
    (p : Fin d → ℕ) (u : α → IntVec r) (v : α → IntVec d)
    (R : Finset α) (hv : ∀ i ∈ R, InCenteredBox p (v i))
    (hrep : ∀ i ∈ R, encode (v i) = project (u i))
    (origin : IntVec r) (m : Fin r → ℕ)
    (hfill : ∀ x, x ≤ m → ∃ s : Finset α,
      s ⊆ R ∧ (∑ i ∈ s, u i) = integerGridPoint origin x) :
    ∃ f : (Fin r → ℕ) → IntVec d,
      (∀ x, x ≤ m → encode (f x) = project (integerGridPoint origin x)) ∧
      (∀ x, x ≤ m → InCenteredBox (fun j => R.card * p j) (f x)) := by
  classical
  choose s hs using hfill
  let f : (Fin r → ℕ) → IntVec d := fun x =>
    if hx : x ≤ m then ∑ i ∈ s x hx, v i else 0
  refine ⟨f, ?_, ?_⟩
  · intro x hx
    dsimp only [f]
    rw [dif_pos hx, map_sum]
    calc
      (∑ i ∈ s x hx, encode (v i)) = ∑ i ∈ s x hx, project (u i) := by
        apply Finset.sum_congr rfl
        intro i hi
        exact hrep i ((hs x hx).1 hi)
      _ = project (∑ i ∈ s x hx, u i) := (map_sum project _ _).symm
      _ = project (integerGridPoint origin x) := congrArg project (hs x hx).2
  · intro x hx
    dsimp only [f]
    rw [dif_pos hx]
    apply inCenteredBox_mono (inCenteredBox_finset_sum p v (s x hx)
      (fun i hi => hv i ((hs x hx).1 hi)))
    intro j
    exact Nat.mul_le_mul_right _ (Finset.card_le_card (hs x hx).1)

/-- Full old-vector decoding from a finite labelled reserve fill. The matrix is
derived, not supplied as a certificate. `max 1 R.card` covers an empty reserve
without imposing an unnecessary nonemptiness condition. The explicit fill-width
conditions replace the manuscript's asymptotic "sufficiently large" threshold. -/
theorem oldVectorDecoder_of_reserve_fill {r d : ℕ} {α : Type*}
    (encode : IntVec d →+ ℤ) (project : IntVec r →+ ℤ)
    (p : Fin d → ℕ) (u : α → IntVec r) (v : α → IntVec d)
    (R : Finset α)
    (hinj : Set.InjOn encode
      {x | InCenteredBox (fun j => 2 * max 1 R.card * p j) x})
    (origin : IntVec r) (m : Fin r → ℕ) (hm : ∀ j, 1 ≤ m j)
    (hu : ∀ i, InCenteredBox m (u i)) (hv : ∀ i, InCenteredBox p (v i))
    (hrep : ∀ i, encode (v i) = project (u i))
    (hfill : ∀ x, x ≤ m → ∃ s : Finset α,
      s ⊆ R ∧ (∑ i ∈ s, u i) = integerGridPoint origin x) :
    ∃ M : Matrix (Fin d) (Fin r) ℤ,
      (∀ i, M.mulVec (u i) = v i) ∧
      (∀ x, encode (M.mulVec x) = project x) := by
  obtain ⟨f, hf, hbound⟩ := exists_bounded_fill_of_subset_witnesses
    encode project p u v R (fun i _ => hv i) (fun i _ => hrep i) origin m hfill
  obtain ⟨F, hF, hcomp, _⟩ := oldVectorDecoder_of_bounded_fill
    encode project p (max 1 R.card) (le_max_left _ _) hinj origin m hm f hf
    (fun x hx => inCenteredBox_mono (hbound x hx)
      (fun j => Nat.mul_le_mul_right _ (le_max_right _ _))) u v hu hv hrep
  obtain ⟨M, hM⟩ := integer_hom_eq_matrix F
  refine ⟨M, fun i => (hM _).trans (hF i), ?_⟩
  intro x
  rw [hM]
  exact DFunLike.congr_fun hcomp x

/-- Equal coefficient sums of two reserve witnesses have equal full old-vector
sums; the scalar witness therefore cannot choose inconsistent old coordinates. -/
theorem reserve_witness_old_sum_unique {r d : ℕ} {α : Type*}
    (encode : IntVec d →+ ℤ) (project : IntVec r →+ ℤ)
    (p : Fin d → ℕ) (u : α → IntVec r) (v : α → IntVec d)
    (R : Finset α)
    (hinj : Set.InjOn encode {x | InCenteredBox (fun j => R.card * p j) x})
    (hv : ∀ i ∈ R, InCenteredBox p (v i))
    (hrep : ∀ i ∈ R, encode (v i) = project (u i))
    (s t : Finset α) (hs : s ⊆ R) (ht : t ⊆ R)
    (he : (∑ i ∈ s, u i) = ∑ i ∈ t, u i) :
    (∑ i ∈ s, v i) = ∑ i ∈ t, v i := by
  apply hinj
  · exact inCenteredBox_mono (inCenteredBox_finset_sum p v s (fun i hi => hv i (hs hi)))
      (fun j => Nat.mul_le_mul_right _ (Finset.card_le_card hs))
  · exact inCenteredBox_mono (inCenteredBox_finset_sum p v t (fun i hi => hv i (ht hi)))
      (fun j => Nat.mul_le_mul_right _ (Finset.card_le_card ht))
  · calc
      encode (∑ i ∈ s, v i) = project (∑ i ∈ s, u i) := by
        simp only [map_sum]
        exact Finset.sum_congr rfl (fun i hi => hrep i (hs hi))
      _ = project (∑ i ∈ t, u i) := congrArg project he
      _ = encode (∑ i ∈ t, v i) := by
        simp only [map_sum]
        exact Finset.sum_congr rfl (fun i hi => (hrep i (ht hi)).symm)

end Optss
