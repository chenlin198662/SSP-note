import Optss.LevIntervalExtension

/-!
# Primitive normalization of actual integer fibers

Every finite integer set with at least two elements is translated by its
minimum and divided by the gcd of its differences. The resulting finite
set has gcd one, the same cardinality, and an exact affine reconstruction.
The period bound is derived from the actual number of distinct points.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

/-- Primitive normalization, including the exact diameter identity and
an upper bound on the period from the set's cardinality. -/
theorem integer_fiber_normalization (A : Finset ℤ) (hcard : 2 ≤ A.card) :
    ∃ (a v : ℤ) (l : ℕ) (B : Finset ℤ),
      0 < v ∧ LevNormalized B l ∧ B.card = A.card ∧
      A = B.image (fun x => a + v * x) ∧
      a ∈ A ∧ a + v * l ∈ A ∧
      (∀ x ∈ A, a ≤ x ∧ x ≤ a + v * l) ∧
      v * ((A.card : ℤ) - 1) ≤ v * l := by
  have hne : A.Nonempty := Finset.card_pos.mp (by omega)
  let a := A.min' hne
  let b := A.max' hne
  let f : ℤ → ℤ := fun x => x - a
  let v := A.gcd f
  have ha : a ∈ A := A.min'_mem hne
  have hb : b ∈ A := A.max'_mem hne
  have hab : a < b := by
    obtain ⟨x, y, hx, hy, hxy⟩ := Finset.one_lt_card_iff.mp (by omega : 1 < A.card)
    exact A.min'_lt_max' hx hy hxy
  have hfn : f b ≠ 0 := by dsimp [f]; omega
  have hvne : v ≠ 0 := by
    intro h
    exact hfn (Finset.gcd_eq_zero_iff.mp h b hb)
  have hvnonneg : 0 ≤ v := Int.nonneg_of_normalize_eq_self Finset.normalize_gcd
  have hv : 0 < v := lt_of_le_of_ne hvnonneg (Ne.symm hvne)
  have hdvd : ∀ x ∈ A, v ∣ f x := fun x hx => Finset.gcd_dvd hx
  let B := A.image (fun x => f x / v)
  let l := ((b - a) / v).toNat
  have hquot : 0 ≤ (b - a) / v := Int.ediv_nonneg (by omega) hv.le
  have hl : (l : ℤ) = (b - a) / v := Int.toNat_of_nonneg hquot
  have hreconstruct : ∀ x ∈ A, a + v * (f x / v) = x := by
    intro x hx
    rw [Int.mul_ediv_cancel' (hdvd x hx)]
    dsimp [f]
    omega
  have hBcard : B.card = A.card := by
    apply Finset.card_image_iff.mpr
    intro x hx y hy he
    dsimp only at he
    have hx' := hreconstruct x hx
    have hy' := hreconstruct y hy
    rw [he] at hx'
    omega
  have hB : LevNormalized B l := by
    refine ⟨?_, ?_, ?_, ?_⟩
    · intro x hx
      obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
      refine Finset.mem_Icc.mpr ⟨?_, ?_⟩
      · exact Int.ediv_nonneg (sub_nonneg.mpr (A.min'_le y hy)) hv.le
      · rw [hl]
        exact Int.ediv_le_ediv hv (sub_le_sub_right (A.le_max' y hy) a)
    · exact Finset.mem_image.mpr ⟨a, ha, by simp [f]⟩
    · exact Finset.mem_image.mpr ⟨b, hb, hl.symm⟩
    · change (A.image (fun x => f x / A.gcd f)).gcd id = 1
      rw [Finset.gcd_image]
      exact Finset.gcd_div_eq_one hb hfn
  have he : A = B.image (fun x => a + v * x) := by
    apply Finset.Subset.antisymm
    · intro x hx
      exact Finset.mem_image.mpr ⟨f x / v, Finset.mem_image.mpr ⟨x, hx, rfl⟩, hreconstruct x hx⟩
    · intro x hx
      obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
      obtain ⟨z, hz, rfl⟩ := Finset.mem_image.mp hy
      simpa only [hreconstruct z hz] using hz
  have htop : a + v * l = b := by
    rw [hl]
    exact hreconstruct b hb
  refine ⟨a, v, l, B, hv, hB, hBcard, he, ha, ?_, ?_, ?_⟩
  · simpa [htop] using hb
  · intro x hx
    rw [htop]
    exact ⟨A.min'_le x hx, A.le_max' x hx⟩
  · have hc := hB.card_le B l
    rw [hBcard] at hc
    apply mul_le_mul_of_nonneg_left _ hv.le
    omega

/-- The actual affine period is bounded by the ambient diameter divided
by one less than the number of points. No density estimate is assumed. -/
theorem integer_fiber_period_bound (A : Finset ℤ) (u w : ℤ)
    (hcard : 2 ≤ A.card) (hbox : A ⊆ Finset.Icc u (u + w)) :
    ∃ (a v : ℤ) (l : ℕ) (B : Finset ℤ),
      0 < v ∧ LevNormalized B l ∧ B.card = A.card ∧
      A = B.image (fun x => a + v * x) ∧
      v * l ≤ w ∧ v * ((A.card : ℤ) - 1) ≤ w := by
  obtain ⟨a, v, l, B, hv, hB, hc, he, ha, hb, hx, hper⟩ := integer_fiber_normalization A hcard
  have ha' := Finset.mem_Icc.mp (hbox ha)
  have hb' := Finset.mem_Icc.mp (hbox hb)
  exact ⟨a, v, l, B, hv, hB, hc, he, by omega, by omega⟩

/-- A finite integer set is aperiodic when it is not contained in any
translate of a proper nonzero subgroup `vℤ`. -/
def IntegerAperiodic (A : Finset ℤ) : Prop :=
  ∀ v : ℤ, 1 < v → ∀ a : ℤ, ¬∀ x ∈ A, v ∣ x - a

/-- An aperiodic set needs only translation, not any dilation, in its
primitive normalization. -/
theorem integer_aperiodic_normalization (A : Finset ℤ) (u : ℤ) (W : ℕ)
    (hcard : 2 ≤ A.card) (hbox : A ⊆ Finset.Icc u (u + W)) (haper : IntegerAperiodic A) :
    ∃ (a : ℤ) (l : ℕ) (B : Finset ℤ),
      LevNormalized B l ∧ B.card = A.card ∧ A = B.image (fun x => a + x) ∧ l ≤ W := by
  obtain ⟨a, v, l, B, hv, hB, hc, he, hw, hper⟩ := integer_fiber_period_bound A u W hcard hbox
  have hv1 : v = 1 := by
    by_contra hvne
    have hv' : 1 < v := by omega
    apply haper v hv' a
    intro x hx
    rw [he] at hx
    obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
    exact ⟨y, by ring⟩
  subst v
  simp only [one_mul] at he hw
  exact ⟨a, l, B, hB, hc, he, by exact_mod_cast hw⟩

end
end Optss
