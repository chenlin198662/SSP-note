import Optss.BooleanRationalExpression

/-!
# Actual Boolean determinant, inverse and matrix-product scalar traces

The determinant expression is built by structural Laplace expansion; each
cofactor inverse cell divides a row-replacement determinant by the input
determinant. Answer arithmetic stays in normalized Boolean-list fractions.
The proved work includes scalar gates/list visits, explicit payload copies,
and expression-node visits. Matrix-address access, expression construction,
and output-container allocation remain separately stated costs. Bounds are
polynomial in input bits for each fixed rank, with explicit dimension constants.
-/
namespace Optss
open scoped BigOperators
namespace RationalExpression
variable {ι : Type*}

def sum : List (RationalExpression ι) → RationalExpression ι
  | [] => .zero
  | e::es => .binary .add e (sum es)

theorem sum_rational (x : ι → ℚ) (es : List (RationalExpression ι)) :
    (sum es).rational x=(es.map (fun e => e.rational x)).sum := by
  induction es <;> simp_all [sum,rational,RationalBinaryOp.rational]

theorem sum_nodes (es : List (RationalExpression ι)) :
    (sum es).nodes=1+(es.map (fun e => e.nodes+1)).sum := by
  induction es <;> simp_all [sum,nodes]
  omega

def sign : ℕ → RationalExpression ι
  | 0 => .one
  | n+1 => .neg (sign n)

theorem sign_rational (x : ι → ℚ) (n : ℕ) :
    (sign n : RationalExpression ι).rational x=(-1)^n := by
  induction n <;> simp_all [sign,rational,pow_succ]

theorem sign_nodes (n : ℕ) : (sign n : RationalExpression ι).nodes=n+1 := by
  induction n <;> simp_all [sign,nodes]

/-- Finite expansion with all signs and subdeterminants represented explicitly. -/
def determinant : (n : ℕ) → Matrix (Fin n) (Fin n) (RationalExpression ι) → RationalExpression ι
  | 0,_ => .one
  | n+1,A => sum (List.ofFn fun j : Fin (n+1) =>
      .binary .mul (sign j.val) (.binary .mul (A 0 j)
        (determinant n (A.submatrix Fin.succ j.succAbove))))

theorem determinant_rational (x : ι → ℚ) (n : ℕ)
    (A : Matrix (Fin n) (Fin n) (RationalExpression ι)) :
    (determinant n A).rational x=Matrix.det (fun i j => (A i j).rational x) := by
  induction n with
  | zero => simp [determinant,rational]
  | succ n ih =>
    rw [determinant,sum_rational]
    simp only [List.map_ofFn,List.sum_ofFn,Function.comp_apply,rational,sign_rational,RationalBinaryOp.rational,ih]
    rw [Matrix.det_succ_row_zero]
    apply Finset.sum_congr rfl
    intro j _
    simp only [Matrix.submatrix_apply,mul_assoc]
    rfl

/-- Dimension-only operation-tree size when every input cell has at most `a` nodes. -/
def determinantNodes : ℕ → ℕ → ℕ
  | 0,_ => 1
  | n+1,a => 1+(n+1)*(n+a+determinantNodes n a+4)

theorem determinant_nodes_le (n a : ℕ)
    (A : Matrix (Fin n) (Fin n) (RationalExpression ι))
    (hA : ∀ i j,(A i j).nodes≤a) :
    (determinant n A).nodes≤determinantNodes n a := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [determinant,sum_nodes]
    simp only [List.map_ofFn,List.sum_ofFn,Function.comp_apply]
    unfold determinantNodes
    apply Nat.add_le_add_left
    calc
      _ ≤ ∑ _j : Fin (n+1),(n+a+determinantNodes n a+4) := by
        apply Finset.sum_le_sum
        intro j _
        have hm := ih (A.submatrix Fin.succ j.succAbove) (fun i k => hA _ _)
        have hrow := hA 0 j
        have hj := j.isLt
        simp only [nodes,sign_nodes]
        omega
      _ = _ := by simp
end RationalExpression

variable {r d m : ℕ}

/-- Determinant expression addresses the actual input cells by their row/column pair. -/
def rationalMatrixDeterminantExpression (r : ℕ) : RationalExpression (Fin r × Fin r) :=
  RationalExpression.determinant r (fun i j => .input (i,j))

def rationalMatrixInverseExpression (r : ℕ) (i j : Fin r) : RationalExpression (Fin r × Fin r) :=
  .binary .div
    (RationalExpression.determinant r (fun k l =>
      if k=j then if l=i then .one else .zero else .input (k,l)))
    (rationalMatrixDeterminantExpression r)

def booleanMatrixDeterminant (A : Matrix (Fin r) (Fin r) BitListFraction) : BitListFraction :=
  (rationalMatrixDeterminantExpression r).encoded (fun p => A p.1 p.2)

def booleanMatrixDeterminantWork (A : Matrix (Fin r) (Fin r) BitListFraction) : ℕ :=
  (rationalMatrixDeterminantExpression r).work (fun p => A p.1 p.2)

/-- Every output cell is materialized once; the denominator determinant is
recomputed for each cell, and the work bound explicitly includes those calls. -/
def booleanMatrixInverse (A : Matrix (Fin r) (Fin r) BitListFraction) :
    Vector (Vector BitListFraction r) r :=
  Vector.ofFn fun i => Vector.ofFn fun j =>
    (rationalMatrixInverseExpression r i j).encoded (fun p => A p.1 p.2)

def booleanMatrixInverseWork (A : Matrix (Fin r) (Fin r) BitListFraction) : ℕ :=
  ∑ i : Fin r,∑ j : Fin r,
    (rationalMatrixInverseExpression r i j).work (fun p => A p.1 p.2)

theorem rationalMatrixDeterminantExpression_value (A : Matrix (Fin r) (Fin r) ℚ) :
    (rationalMatrixDeterminantExpression r).rational (fun p => A p.1 p.2)=A.det := by
  simpa only [rationalMatrixDeterminantExpression,RationalExpression.rational] using
    RationalExpression.determinant_rational (fun p => A p.1 p.2) r (fun i j => .input (i,j))

theorem rationalMatrixInverseExpression_value (A : Matrix (Fin r) (Fin r) ℚ) (i j : Fin r) :
    (rationalMatrixInverseExpression r i j).rational (fun p => A p.1 p.2)=
      rationalCofactorInverse A i j := by
  simp only [rationalMatrixInverseExpression,RationalExpression.rational,
    RationalBinaryOp.rational,RationalExpression.determinant_rational,
    rationalMatrixDeterminantExpression_value,rationalCofactorInverse]
  have hm : (fun k l => RationalExpression.rational (fun p => A p.1 p.2)
      (if k=j then if l=i then .one else .zero else .input (k,l))) =
      A.updateRow j (Pi.single i 1) := by
    ext k l
    simp only [Matrix.updateRow_apply,Pi.single_apply]
    split_ifs <;> rfl
  rw [hm]

theorem booleanMatrixDeterminant_wellFormed (A : Matrix (Fin r) (Fin r) BitListFraction)
    (hA : ∀ i j,(A i j).WellFormed) : (booleanMatrixDeterminant A).WellFormed :=
by
  exact RationalExpression.wellFormed (fun p : Fin r × Fin r => A p.1 p.2)
    (fun p => hA p.1 p.2) (rationalMatrixDeterminantExpression r)

theorem booleanMatrixDeterminant_value (A : Matrix (Fin r) (Fin r) BitListFraction)
    (hA : ∀ i j,(A i j).WellFormed) :
    bitListFractionValue (booleanMatrixDeterminant A)=
      Matrix.det (fun i j => bitListFractionValue (A i j)) := by
  rw [booleanMatrixDeterminant,
    (rationalMatrixDeterminantExpression r).value (fun p => A p.1 p.2) (fun p => hA p.1 p.2)]
  exact rationalMatrixDeterminantExpression_value (fun i j => bitListFractionValue (A i j))

theorem booleanMatrixInverse_cell (A : Matrix (Fin r) (Fin r) BitListFraction) (i j : Fin r) :
    ((booleanMatrixInverse A).get i).get j=
      (rationalMatrixInverseExpression r i j).encoded (fun p => A p.1 p.2) := by
  simp [booleanMatrixInverse,Vector.get]

theorem booleanMatrixInverse_wellFormed (A : Matrix (Fin r) (Fin r) BitListFraction)
    (hA : ∀ i j,(A i j).WellFormed) (i j : Fin r) :
    (((booleanMatrixInverse A).get i).get j).WellFormed := by
  rw [booleanMatrixInverse_cell]
  exact (rationalMatrixInverseExpression r i j).wellFormed (fun p => A p.1 p.2) (fun p => hA p.1 p.2)

theorem booleanMatrixInverse_value (A : Matrix (Fin r) (Fin r) BitListFraction)
    (hA : ∀ i j,(A i j).WellFormed) (i j : Fin r) :
    bitListFractionValue (((booleanMatrixInverse A).get i).get j)=
      rationalCofactorInverse (fun i j => bitListFractionValue (A i j)) i j := by
  rw [booleanMatrixInverse_cell,
    (rationalMatrixInverseExpression r i j).value (fun p => A p.1 p.2) (fun p => hA p.1 p.2)]
  exact rationalMatrixInverseExpression_value (fun i j => bitListFractionValue (A i j)) i j

theorem rationalMatrixDeterminantExpression_nodes (r : ℕ) :
    (rationalMatrixDeterminantExpression r).nodes≤RationalExpression.determinantNodes r 1 :=
  RationalExpression.determinant_nodes_le r 1 _ (fun _ _ => le_rfl)

theorem rationalMatrixInverseExpression_nodes (r : ℕ) (i j : Fin r) :
    (rationalMatrixInverseExpression r i j).nodes≤2*RationalExpression.determinantNodes r 1+1 := by
  have hnum := RationalExpression.determinant_nodes_le r 1
    (fun k l : Fin r => if k=j then if l=i then RationalExpression.one else .zero else .input (k,l))
    (by intro k l; dsimp only; split_ifs <;> exact le_rfl)
  have hden := rationalMatrixDeterminantExpression_nodes r
  change _+_+1≤_
  omega

/-- Actual scalar and expression traversal work; no operand-height premise
is assumed beyond the original normalized input fields. -/
theorem booleanMatrixDeterminantWork_bound (A : Matrix (Fin r) (Fin r) BitListFraction)
    (hA : ∀ i j,(A i j).WellFormed) (L : ℕ)
    (hbits : ∀ i j,(A i j).numerator.length≤L ∧ (A i j).denominator.length≤L) :
    booleanMatrixDeterminantWork A≤RationalExpression.determinantNodes r 1*
      RationalExpression.charge (RationalExpression.determinantNodes r 1) L := by
  have hn := rationalMatrixDeterminantExpression_nodes r
  have h := (rationalMatrixDeterminantExpression r).work_le (fun p => A p.1 p.2)
    (fun p => hA p.1 p.2) L
    (fun p => ((A p.1 p.2).value_bit_bound_iff (hA _ _) L).mpr (hbits _ _)) _ hn
  exact h.trans (Nat.mul_le_mul_right _ hn)

theorem booleanMatrixInverseWork_bound (A : Matrix (Fin r) (Fin r) BitListFraction)
    (hA : ∀ i j,(A i j).WellFormed) (L : ℕ)
    (hbits : ∀ i j,(A i j).numerator.length≤L ∧ (A i j).denominator.length≤L) :
    booleanMatrixInverseWork A≤r*r*(2*RationalExpression.determinantNodes r 1+1)*
      RationalExpression.charge (2*RationalExpression.determinantNodes r 1+1) L := by
  unfold booleanMatrixInverseWork
  calc
    _ ≤ ∑ _i : Fin r,∑ _j : Fin r,(2*RationalExpression.determinantNodes r 1+1)*
        RationalExpression.charge (2*RationalExpression.determinantNodes r 1+1) L := by
      apply Finset.sum_le_sum
      intro i _
      apply Finset.sum_le_sum
      intro j _
      have hn := rationalMatrixInverseExpression_nodes r i j
      exact ((rationalMatrixInverseExpression r i j).work_le (fun p => A p.1 p.2)
        (fun p => hA p.1 p.2) L
        (fun p => ((A p.1 p.2).value_bit_bound_iff (hA _ _) L).mpr (hbits _ _)) _ hn).trans
          (Nat.mul_le_mul_right _ hn)
    _ = _ := by simp; ring
/-- Physical normalized output lengths inherit the sharper determinant bound. -/
theorem booleanMatrixDeterminant_output_bits (A : Matrix (Fin r) (Fin r) BitListFraction)
    (hA : ∀ i j,(A i j).WellFormed) (L : ℕ)
    (hbits : ∀ i j,(A i j).numerator.length≤L ∧ (A i j).denominator.length≤L) :
    (booleanMatrixDeterminant A).numerator.length≤r.factorial*(r*L+2) ∧
      (booleanMatrixDeterminant A).denominator.length≤r.factorial*(r*L+2) := by
  apply ((booleanMatrixDeterminant A).value_bit_bound_iff (booleanMatrixDeterminant_wellFormed A hA) _).mp
  rw [booleanMatrixDeterminant_value A hA]
  exact rationalDeterminant_bits _ L (fun i j => ((A i j).value_bit_bound_iff (hA i j) L).mpr (hbits i j))

theorem booleanMatrixInverse_output_bits (A : Matrix (Fin r) (Fin r) BitListFraction)
    (hA : ∀ i j,(A i j).WellFormed) (L : ℕ)
    (hbits : ∀ i j,(A i j).numerator.length≤L ∧ (A i j).denominator.length≤L) (i j : Fin r) :
    (((booleanMatrixInverse A).get i).get j).numerator.length≤2*r.factorial*(r*L+2) ∧
      (((booleanMatrixInverse A).get i).get j).denominator.length≤2*r.factorial*(r*L+2) := by
  apply ((((booleanMatrixInverse A).get i).get j).value_bit_bound_iff
    (booleanMatrixInverse_wellFormed A hA i j) _).mp
  rw [booleanMatrixInverse_value A hA]
  exact rationalCofactorInverse_bits _ L
    (fun i j => ((A i j).value_bit_bound_iff (hA i j) L).mpr (hbits i j)) i j

/-- A product cell is one explicit sum of input-coordinate products. -/
def rationalMatrixMulExpression (r d m : ℕ) (i : Fin r) (j : Fin m) :
    RationalExpression ((Fin r × Fin d) ⊕ (Fin d × Fin m)) :=
  RationalExpression.sum (List.ofFn fun k : Fin d =>
    .binary .mul (.input (.inl (i,k))) (.input (.inr (k,j))))

def booleanMatrixMulInputs (A : Matrix (Fin r) (Fin d) BitListFraction)
    (B : Matrix (Fin d) (Fin m) BitListFraction) :
    ((Fin r × Fin d) ⊕ (Fin d × Fin m)) → BitListFraction :=
  Sum.elim (fun p => A p.1 p.2) (fun p => B p.1 p.2)

def booleanMatrixMul (A : Matrix (Fin r) (Fin d) BitListFraction)
    (B : Matrix (Fin d) (Fin m) BitListFraction) : Vector (Vector BitListFraction m) r :=
  Vector.ofFn fun i => Vector.ofFn fun j =>
    (rationalMatrixMulExpression r d m i j).encoded (booleanMatrixMulInputs A B)

def booleanMatrixMulWork (A : Matrix (Fin r) (Fin d) BitListFraction)
    (B : Matrix (Fin d) (Fin m) BitListFraction) : ℕ :=
  ∑ i : Fin r,∑ j : Fin m,
    (rationalMatrixMulExpression r d m i j).work (booleanMatrixMulInputs A B)

theorem rationalMatrixMulExpression_value (A : Matrix (Fin r) (Fin d) ℚ)
    (B : Matrix (Fin d) (Fin m) ℚ) (i : Fin r) (j : Fin m) :
    (rationalMatrixMulExpression r d m i j).rational
      (Sum.elim (fun p => A p.1 p.2) (fun p => B p.1 p.2))=(A*B) i j := by
  simp only [rationalMatrixMulExpression,RationalExpression.sum_rational,List.map_ofFn,
    List.sum_ofFn,Function.comp_apply,RationalExpression.rational,RationalBinaryOp.rational,
    Sum.elim_inl,Sum.elim_inr,Matrix.mul_apply]

theorem rationalMatrixMulExpression_nodes (i : Fin r) (j : Fin m) :
    (rationalMatrixMulExpression r d m i j).nodes=4*d+1 := by
  simp [rationalMatrixMulExpression,RationalExpression.sum_nodes,RationalExpression.nodes,
    List.map_ofFn,List.sum_ofFn]
  omega

theorem booleanMatrixMul_cell (A : Matrix (Fin r) (Fin d) BitListFraction)
    (B : Matrix (Fin d) (Fin m) BitListFraction) (i : Fin r) (j : Fin m) :
    ((booleanMatrixMul A B).get i).get j=
      (rationalMatrixMulExpression r d m i j).encoded (booleanMatrixMulInputs A B) := by
  simp [booleanMatrixMul,Vector.get]

theorem booleanMatrixMul_wellFormed (A : Matrix (Fin r) (Fin d) BitListFraction)
    (B : Matrix (Fin d) (Fin m) BitListFraction)
    (hA : ∀ i j,(A i j).WellFormed) (hB : ∀ i j,(B i j).WellFormed) (i : Fin r) (j : Fin m) :
    (((booleanMatrixMul A B).get i).get j).WellFormed := by
  rw [booleanMatrixMul_cell]
  apply (rationalMatrixMulExpression r d m i j).wellFormed
  intro p
  cases p with
  | inl p => exact hA p.1 p.2
  | inr p => exact hB p.1 p.2

theorem booleanMatrixMul_value (A : Matrix (Fin r) (Fin d) BitListFraction)
    (B : Matrix (Fin d) (Fin m) BitListFraction)
    (hA : ∀ i j,(A i j).WellFormed) (hB : ∀ i j,(B i j).WellFormed) (i : Fin r) (j : Fin m) :
    bitListFractionValue (((booleanMatrixMul A B).get i).get j)=
      (A.map bitListFractionValue*B.map bitListFractionValue) i j := by
  have hw : ∀ p,(booleanMatrixMulInputs A B p).WellFormed := by
    intro p; cases p with
    | inl p => exact hA p.1 p.2
    | inr p => exact hB p.1 p.2
  rw [booleanMatrixMul_cell,RationalExpression.value _ hw]
  have he : (fun p => bitListFractionValue (booleanMatrixMulInputs A B p))=
      Sum.elim (fun p => bitListFractionValue (A p.1 p.2)) (fun p => bitListFractionValue (B p.1 p.2)) := by
    funext p; cases p <;> rfl
  rw [he]
  exact rationalMatrixMulExpression_value (A.map bitListFractionValue) (B.map bitListFractionValue) i j

theorem booleanMatrixMulWork_bound (A : Matrix (Fin r) (Fin d) BitListFraction)
    (B : Matrix (Fin d) (Fin m) BitListFraction)
    (hA : ∀ i j,(A i j).WellFormed) (hB : ∀ i j,(B i j).WellFormed) (L : ℕ)
    (hbitsA : ∀ i j,(A i j).numerator.length≤L ∧ (A i j).denominator.length≤L)
    (hbitsB : ∀ i j,(B i j).numerator.length≤L ∧ (B i j).denominator.length≤L) :
    booleanMatrixMulWork A B≤r*m*(4*d+1)*RationalExpression.charge (4*d+1) L := by
  have hw : ∀ p,(booleanMatrixMulInputs A B p).WellFormed := by
    intro p; cases p with
    | inl p => exact hA p.1 p.2
    | inr p => exact hB p.1 p.2
  have hb : ∀ p,RationalBitBound (bitListFractionValue (booleanMatrixMulInputs A B p)) L := by
    intro p; cases p with
    | inl p => exact ((A p.1 p.2).value_bit_bound_iff (hA _ _) L).mpr (hbitsA _ _)
    | inr p => exact ((B p.1 p.2).value_bit_bound_iff (hB _ _) L).mpr (hbitsB _ _)
  unfold booleanMatrixMulWork
  calc
    _ ≤ ∑ _i : Fin r,∑ _j : Fin m,(4*d+1)*RationalExpression.charge (4*d+1) L := by
      apply Finset.sum_le_sum
      intro i _
      apply Finset.sum_le_sum
      intro j _
      have h := (rationalMatrixMulExpression r d m i j).work_le _ hw L hb (4*d+1)
        (rationalMatrixMulExpression_nodes i j).le
      simpa only [rationalMatrixMulExpression_nodes] using h
    _ = _ := by simp; ring
end Optss
