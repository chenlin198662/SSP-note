import Optss.InteriorRank
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.RingTheory.PrincipalIdealDomain
import Mathlib.LinearAlgebra.FreeModule.PID
import Mathlib.LinearAlgebra.FreeModule.Finite.Basic
import Mathlib.LinearAlgebra.Projection
import Mathlib.Algebra.Group.Torsion

/-!
# Primitive integer directions and their split quotient

Coordinate gcd extraction constructs the primitive divisor of any nonzero
integer vector. A finite Bézout recursion gives an integer linear functional
that evaluates to one on the primitive direction, and hence an integral split
projection. These are exact algebraic constructions, without HNF runtime claims.
-/

namespace Optss
open scoped BigOperators Classical
noncomputable section

variable {d : ℕ}

/-- Finite Bézout recursion constructs an actual integer linear functional
whose value is the gcd of the selected coordinates. -/
theorem exists_coordinate_gcd_functional (z : IntVec d) (s : Finset (Fin d)) :
    ∃ ℓ : IntVec d →ₗ[ℤ] ℤ, ℓ z = s.gcd z := by
  induction s using Finset.induction_on with
  | empty => exact ⟨0, by simp⟩
  | @insert i s hi ih =>
    obtain ⟨ℓ, hℓ⟩ := ih
    obtain ⟨a, b, hab⟩ := exists_gcd_eq_mul_add_mul (z i) (s.gcd z)
    refine ⟨a • (LinearMap.proj i) + b • ℓ, ?_⟩
    simp only [LinearMap.add_apply, LinearMap.smul_apply, LinearMap.proj_apply, smul_eq_mul,
      hℓ, Finset.gcd_insert]
    rw [hab]
    ring

/-- An exact primitive divisor, with the original coordinate gcd and an actual
Bézout functional. Dividing cannot enlarge any coordinate. -/
theorem exists_primitive_divisor (z : IntVec d) (hz : z ≠ 0) :
    ∃ p : IntVec d, ∃ ℓ : IntVec d →ₗ[ℤ] ℤ,
      Finset.univ.gcd z ≠ 0 ∧ z = (Finset.univ.gcd z) • p ∧
      Finset.univ.gcd p = 1 ∧ ℓ p = 1 ∧ ∀ j, |p j| ≤ |z j| := by
  have hnz : ∃ j : Fin d, z j ≠ 0 := by
    by_contra h
    push_neg at h
    exact hz (funext h)
  obtain ⟨j, hj⟩ := hnz
  obtain ⟨p, hp, hprim⟩ := Finset.extract_gcd z (show (Finset.univ : Finset (Fin d)).Nonempty from
    ⟨j, Finset.mem_univ _⟩)
  have hg : Finset.univ.gcd z ≠ 0 := by
    intro hzero
    exact hj ((Finset.gcd_eq_zero_iff.mp hzero) j (Finset.mem_univ _))
  obtain ⟨ℓ, hℓ⟩ := exists_coordinate_gcd_functional p Finset.univ
  have hdecomp : z = (Finset.univ.gcd z) • p := by
    ext i
    exact hp i (Finset.mem_univ _)
  refine ⟨p, ℓ, hg, hdecomp, hprim, hℓ.trans hprim, ?_⟩
  intro i
  have hg1 := Int.one_le_abs hg
  rw [hp i (Finset.mem_univ _), abs_mul]
  nlinarith [abs_nonneg (p i)]

/-- Primitive division preserves membership in the kernel of an integer encoding. -/
theorem primitive_divisor_mem_kernel (ρ : IntVec d →ₗ[ℤ] ℤ)
    (z p : IntVec d) (g : ℤ) (hg : g ≠ 0) (hz : z = g • p) (hρ : ρ z = 0) :
    ρ p = 0 := by
  rw [hz, map_smul, smul_eq_mul] at hρ
  exact (mul_eq_zero.mp hρ).resolve_left hg

/-- Exact integer projection along the primitive direction onto the Bézout kernel. -/
def primitiveProjection (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) : IntVec d →ₗ[ℤ] IntVec d :=
  LinearMap.id - (LinearMap.smulRight ℓ p)

@[simp] theorem primitiveProjection_apply (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (x : IntVec d) :
    primitiveProjection p ℓ x = x - ℓ x • p := rfl

/-- The projection has precisely the integer line as its kernel. -/
theorem primitiveProjection_ker (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1) :
    LinearMap.ker (primitiveProjection p ℓ) = Submodule.span ℤ {p} := by
  ext x
  rw [LinearMap.mem_ker, primitiveProjection_apply, sub_eq_zero, Submodule.mem_span_singleton]
  constructor
  · intro hx
    exact ⟨ℓ x, hx.symm⟩
  · rintro ⟨a, rfl⟩
    rw [map_smul, hp, smul_eq_mul, mul_one]

/-- The integral split projection lands in the Bézout kernel. -/
def primitiveKernelProjection (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1) :
    IntVec d →ₗ[ℤ] LinearMap.ker ℓ :=
  (primitiveProjection p ℓ).codRestrict (LinearMap.ker ℓ) (by
    intro x
    rw [LinearMap.mem_ker, primitiveProjection_apply, map_sub, map_smul, hp, smul_eq_mul, mul_one]
    exact sub_self _)

@[simp] theorem primitiveKernelProjection_coe (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ)
    (hp : ℓ p = 1) (x : IntVec d) :
    (primitiveKernelProjection p ℓ hp x : IntVec d) = x - ℓ x • p := rfl

/-- Every point of the Bézout kernel is fixed, so the projection is onto. -/
theorem primitiveKernelProjection_surjective (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ)
    (hp : ℓ p = 1) : Function.Surjective (primitiveKernelProjection p ℓ hp) := by
  intro y
  refine ⟨y, Subtype.ext ?_⟩
  have hy : ℓ y = 0 := LinearMap.mem_ker.mp y.property
  simp [hy]

/-- The explicit integer splitting exhibits the primitive line as a direct
summand, rather than assuming that the quotient is torsion free. -/
def primitiveSplitEquiv (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1) :
    IntVec d ≃ₗ[ℤ] (LinearMap.ker ℓ × ℤ) where
  toFun x := (primitiveKernelProjection p ℓ hp x, ℓ x)
  invFun y := y.1 + y.2 • p
  left_inv x := by simp
  right_inv y := by
    apply Prod.ext
    · apply Subtype.ext
      have hy : ℓ y.1 = 0 := LinearMap.mem_ker.mp y.1.property
      change (y.1 : IntVec d) + y.2 • p - ℓ ((y.1 : IntVec d) + y.2 • p) • p = y.1
      rw [map_add, map_smul, hy, hp, smul_eq_mul, mul_one, zero_add]
      abel
    · have hy : ℓ y.1 = 0 := LinearMap.mem_ker.mp y.1.property
      change ℓ ((y.1 : IntVec d) + y.2 • p) = y.2
      rw [map_add, map_smul, hy, hp, smul_eq_mul, mul_one, zero_add]
  map_add' x y := by simp
  map_smul' a x := Prod.ext ((primitiveKernelProjection p ℓ hp).map_smul a x) (ℓ.map_smul a x)

/-- The Bézout kernel is a free integer module of precisely one smaller rank. -/
theorem primitiveKernel_finrank (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1) :
    Module.finrank ℤ (LinearMap.ker ℓ) = d-1 := by
  have h := (primitiveSplitEquiv p ℓ hp).finrank_eq
  simp only [Module.finrank_fin_fun, Module.finrank_prod, Module.finrank_self] at h
  omega

/-- An actual integral coordinate basis for the complementary kernel. -/
def primitiveKernelCoordinates (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1) :
    LinearMap.ker ℓ ≃ₗ[ℤ] IntVec (d-1) :=
  ((Module.finBasis ℤ (LinearMap.ker ℓ)).reindex
    (finCongr (primitiveKernel_finrank p ℓ hp))).equivFun

/-- The integral quotient map in exactly `d-1` integer coordinates. -/
def primitiveQuotientMap (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1) :
    IntVec d →ₗ[ℤ] IntVec (d-1) :=
  (primitiveKernelCoordinates p ℓ hp).toLinearMap.comp (primitiveKernelProjection p ℓ hp)

theorem primitiveQuotientMap_surjective (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1) :
    Function.Surjective (primitiveQuotientMap p ℓ hp) :=
  (primitiveKernelCoordinates p ℓ hp).surjective.comp (primitiveKernelProjection_surjective p ℓ hp)

theorem primitiveQuotientMap_ker (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1) :
    LinearMap.ker (primitiveQuotientMap p ℓ hp) = Submodule.span ℤ {p} := by
  rw [primitiveQuotientMap, LinearMap.ker_comp_of_ker_eq_bot _ (LinearEquiv.ker _)]
  have hk : LinearMap.ker (primitiveKernelProjection p ℓ hp) =
      LinearMap.ker (primitiveProjection p ℓ) := by
    ext x
    simp only [LinearMap.mem_ker]
    exact Subtype.val_injective.eq_iff.symm
  rw [hk, primitiveProjection_ker p ℓ hp]

/-- The quotient itself is integrally isomorphic to a free `d-1` dimensional
integer module, proving torsion-freeness and freeness constructively. -/
def primitiveQuotientEquiv (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1) :
    (IntVec d ⧸ Submodule.span ℤ {p}) ≃ₗ[ℤ] IntVec (d-1) :=
  (Submodule.quotEquivOfEq _ _ (primitiveQuotientMap_ker p ℓ hp).symm).trans
    ((primitiveQuotientMap p ℓ hp).quotKerEquivOfSurjective (primitiveQuotientMap_surjective p ℓ hp))

theorem primitive_quotient_free (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1) :
    Module.Free ℤ (IntVec d ⧸ Submodule.span ℤ {p}) :=
  Module.Free.of_equiv (primitiveQuotientEquiv p ℓ hp).symm

theorem primitive_quotient_finrank (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1) :
    Module.finrank ℤ (IntVec d ⧸ Submodule.span ℤ {p}) = d-1 := by
  simpa only [Module.finrank_fin_fun] using (primitiveQuotientEquiv p ℓ hp).finrank_eq

/-- Extend an integer matrix to real coordinates by its actual integer columns. -/
def integerMapRealExtension {m n : ℕ} (f : IntVec m →ₗ[ℤ] IntVec n) :
    (Fin m → ℝ) →ₗ[ℝ] (Fin n → ℝ) where
  toFun x i := ∑ j : Fin m, x j * (f (Pi.single j (1:ℤ)) i : ℝ)
  map_add' x y := by ext i; simp [add_mul, Finset.sum_add_distrib]
  map_smul' a x := by ext i; simp [Finset.mul_sum, mul_assoc]

/-- The extension agrees exactly with the original integer map. -/
theorem integerMapRealExtension_cast {m n : ℕ} (f : IntVec m →ₗ[ℤ] IntVec n) (x : IntVec m) :
    integerMapRealExtension f (realVector x) = realVector (f x) := by
  have hx : x = ∑ j : Fin m, x j • (Pi.single j (1:ℤ) : IntVec m) := by
    ext j
    simp [Finset.sum_apply, Pi.single_apply, Pi.smul_apply]
  have hfx : f x = ∑ j : Fin m, x j • f (Pi.single j (1:ℤ)) := by
    conv_lhs => rw [hx]
    simp only [map_sum, map_smul]
  ext i
  have hi := congrFun hfx i
  simp only [Finset.sum_apply, Pi.smul_apply, smul_eq_mul] at hi
  change (∑ j : Fin m, (x j : ℝ) * (f (Pi.single j (1:ℤ)) i : ℝ)) = (f x i : ℝ)
  exact_mod_cast hi.symm

@[simp] theorem realVector_single (j : Fin d) :
    realVector (Pi.single j (1:ℤ)) = (Pi.single j (1:ℝ) : Fin d → ℝ) := by
  ext i
  simp [realVector, Pi.single_apply]

/-- Integer surjectivity supplies every real coordinate axis, and therefore
surjectivity of the real extension. -/
theorem integerMapRealExtension_surjective {m n : ℕ} (f : IntVec m →ₗ[ℤ] IntVec n)
    (hf : Function.Surjective f) : Function.Surjective (integerMapRealExtension f) := by
  apply LinearMap.range_eq_top.mp
  by_contra hproper
  obtain ⟨j, hj⟩ := exists_coordinate_axis_outside (LinearMap.range (integerMapRealExtension f)) hproper
  obtain ⟨x, hx⟩ := hf (Pi.single j (1:ℤ))
  apply hj
  apply LinearMap.mem_range.mpr
  refine ⟨realVector x, ?_⟩
  rw [integerMapRealExtension_cast, hx, realVector_single]

/-- The actual real quotient map obtained from the same integral matrix. -/
def primitiveRealQuotientMap (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1) :
    (Fin d → ℝ) →ₗ[ℝ] (Fin (d-1) → ℝ) :=
  integerMapRealExtension (primitiveQuotientMap p ℓ hp)

@[simp] theorem primitiveRealQuotientMap_cast (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ)
    (hp : ℓ p = 1) (x : IntVec d) :
    primitiveRealQuotientMap p ℓ hp (realVector x) = realVector (primitiveQuotientMap p ℓ hp x) :=
  integerMapRealExtension_cast _ x

theorem primitiveRealQuotientMap_surjective (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ)
    (hp : ℓ p = 1) : Function.Surjective (primitiveRealQuotientMap p ℓ hp) :=
  integerMapRealExtension_surjective _ (primitiveQuotientMap_surjective p ℓ hp)

/-- The real kernel is precisely the real line through the primitive direction. -/
theorem primitiveRealQuotientMap_ker (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1) :
    LinearMap.ker (primitiveRealQuotientMap p ℓ hp) = Submodule.span ℝ {realVector p} := by
  have hpnz : p ≠ 0 := by intro hz; simp [hz] at hp
  have hrealnz : realVector p ≠ 0 := by
    intro heq
    apply hpnz
    ext i
    have hi := congrFun heq i
    change (p i : ℝ) = 0 at hi
    exact_mod_cast hi
  have hd : 0 < d := by
    by_contra hn
    have hd0 : d = 0 := by omega
    subst d
    exact hpnz (Subsingleton.elim _ _)
  have hpk : p ∈ LinearMap.ker (primitiveQuotientMap p ℓ hp) := by
    rw [primitiveQuotientMap_ker]
    exact Submodule.subset_span (Set.mem_singleton p)
  have hrealpk : realVector p ∈ LinearMap.ker (primitiveRealQuotientMap p ℓ hp) := by
    rw [LinearMap.mem_ker]
    change integerMapRealExtension (primitiveQuotientMap p ℓ hp) (realVector p) = 0
    rw [integerMapRealExtension_cast, LinearMap.mem_ker.mp hpk, map_zero]
  have hle : Submodule.span ℝ {realVector p} ≤ LinearMap.ker (primitiveRealQuotientMap p ℓ hp) :=
    Submodule.span_le.mpr (by simpa using hrealpk)
  have hrank := (primitiveRealQuotientMap p ℓ hp).finrank_range_add_finrank_ker
  rw [LinearMap.range_eq_top.mpr (primitiveRealQuotientMap_surjective p ℓ hp)] at hrank
  simp only [finrank_top, Module.finrank_fin_fun] at hrank
  have hker : Module.finrank ℝ (LinearMap.ker (primitiveRealQuotientMap p ℓ hp)) = 1 := by omega
  exact (Submodule.eq_of_le_of_finrank_eq hle (by rw [finrank_span_singleton hrealnz, hker])).symm

/-- Primitive division preserves a relation in any torsion-free abelian target
group, by cancellation of the nonzero integer scalar. -/
theorem primitive_divisor_mem_add_kernel {G : Type*} [AddCommGroup G] [IsAddTorsionFree G]
    (ρ : IntVec d →+ G)
    (z p : IntVec d) (g : ℤ) (hg : g ≠ 0) (hz : z = g • p) (hρ : ρ z = 0) :
    ρ p = 0 := by
  rw [hz, map_zsmul] at hρ
  apply zsmul_right_injective hg
  simpa only [smul_zero] using hρ

/-- The descended abelian-group encoding is obtained from the actual complementary
integer coordinates and their inclusion in the original ambient lattice. -/
def primitiveDescendedHom {G : Type*} [AddCommGroup G]
    (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p = 1)
    (ρ : IntVec d →+ G) : IntVec (d-1) →+ G :=
  ρ.comp ((LinearMap.ker ℓ).subtype.toAddMonoidHom.comp
    (primitiveKernelCoordinates p ℓ hp).symm.toLinearMap.toAddMonoidHom)

/-- When the primitive direction is a relation of the group encoding, the
integral quotient preserves that encoding exactly on every original vector.
Torsion-freeness is unnecessary once the primitive relation is known. -/
theorem primitiveDescendedHom_quotient {G : Type*} [AddCommGroup G]
    (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ)
    (hp : ℓ p = 1) (ρ : IntVec d →+ G) (hρ : ρ p = 0) (x : IntVec d) :
    primitiveDescendedHom p ℓ hp ρ (primitiveQuotientMap p ℓ hp x) = ρ x := by
  change ρ (((primitiveKernelCoordinates p ℓ hp).symm
    ((primitiveKernelCoordinates p ℓ hp) (primitiveKernelProjection p ℓ hp x)) :
      LinearMap.ker ℓ) : IntVec d) = ρ x
  rw [LinearEquiv.symm_apply_apply]
  change ρ (x - ℓ x • p) = ρ x
  rw [map_sub, map_zsmul, hρ, smul_zero, sub_zero]

/-- Freeness of the constructed quotient supplies the torsion-free property used
by integer lattice properization. -/
theorem primitive_quotient_torsion_free (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ)
    (hp : ℓ p = 1) : NoZeroSMulDivisors ℤ (IntVec d ⧸ Submodule.span ℤ {p}) := by
  letI := primitive_quotient_free p ℓ hp
  infer_instance

end
end Optss
