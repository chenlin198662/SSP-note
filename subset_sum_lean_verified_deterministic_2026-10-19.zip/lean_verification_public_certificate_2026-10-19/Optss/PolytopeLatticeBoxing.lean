import Optss.RationalReductionExistence
import Mathlib.Analysis.Convex.Topology

/-!
# Full-lattice boxing of symmetric rational polytopes

A finite symmetric vertex hull containing a full independent family of lattice
points has positive integer widths in a suitable basis of the entire lattice.
Rationality is measured in the supplied reference lattice basis. The actual
normalization and integer reduction are constructed, and the lattice-point
count is uniform under every real dilation. These are mathematical existence
and counting statements, without an algorithmic or bit-cost assertion.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {r : ℕ}

section ReferenceLattice
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]

/-- Independent points in the hull force the actual vertices to span. -/
theorem vertices_span_of_independent_hull (b₀ : Basis (Fin r) ℝ E) (S : Finset E)
    (x : Fin r → E) (hx : LinearIndependent ℝ x)
    (hxS : ∀ i, x i ∈ convexHull ℝ (S : Set E)) :
    Submodule.span ℝ (S : Set E) = ⊤ := by
  have hfull : Submodule.span ℝ (Set.range x) = ⊤ :=
    hx.span_eq_top_of_card_eq_finrank' (Module.finrank_eq_card_basis b₀).symm
  apply top_unique
  rw [← hfull]
  apply Submodule.span_le.mpr
  rintro _ ⟨i, rfl⟩
  exact (convexHull_min Submodule.subset_span (Submodule.convex _)) (hxS i)

omit [FiniteDimensional ℝ E] in
/-- Symmetry of the finite vertex set passes to its entire real convex hull. -/
theorem symmetric_vertex_hull (S : Finset E) (hsym : ∀ x ∈ S, -x ∈ S) :
    ∀ x ∈ convexHull ℝ (S : Set E), -x ∈ convexHull ℝ (S : Set E) := by
  have hneg : -(S : Set E) = (S : Set E) := by
    ext x
    change (-x ∈ S) ↔ x ∈ S
    constructor
    · intro hx
      simpa only [neg_neg] using hsym (-x) hx
    · exact hsym x
  intro x hx
  have heq : -(convexHull ℝ (S : Set E)) = convexHull ℝ (S : Set E) := by
    rw [← convexHull_neg, hneg]
  rw [← heq]
  change - -x ∈ convexHull ℝ (S : Set E)
  simpa only [neg_neg] using hx

/-- Rationality in reference-lattice coordinates constructs one normalization
and an actual reduced basis of exactly that reference lattice. -/
theorem rational_polytope_normalization_and_basis (hr : 0 < r)
    (b₀ : Basis (Fin r) ℝ E) (S : Finset E)
    (hspan : Submodule.span ℝ (S : Set E) = ⊤)
    (hsym : ∀ x ∈ S, -x ∈ S)
    (hrat : ∀ x ∈ S, ∀ i, ∃ q : ℚ, (q : ℝ) = b₀.equivFun x i) :
    ∃ a : E ≃L[ℝ] EuclideanSpace ℝ (Fin r), ∃ b : Basis (Fin r) ℝ E,
      basisIntegerLattice b = basisIntegerLattice b₀ ∧
      euclideanCoordinateCube r (1/(r:ℝ)) ⊆ a '' convexHull ℝ (S : Set E) ∧
      a '' convexHull ℝ (S : Set E) ⊆ euclideanCoordinateCube r 1 ∧
      euclideanOrthogonalityDefect (b.map a.toLinearEquiv) ≤ latticeReductionDefectBound r := by
  let T : Finset (Fin r → ℝ) := S.image b₀.equivFun
  have hT : (T : Set (Fin r → ℝ)) = b₀.equivFun '' (S : Set E) := by
    simp only [T, Finset.coe_image]
  have hTspan : Submodule.span ℝ (T : Set (Fin r → ℝ)) = ⊤ := by
    rw [hT, Submodule.span_image, hspan, Submodule.map_top]
    exact LinearMap.range_eq_top.mpr b₀.equivFun.surjective
  have hTsym : ∀ y ∈ T, -y ∈ T := by
    intro y hy
    simp only [T, Finset.mem_image] at hy ⊢
    obtain ⟨x, hx, rfl⟩ := hy
    exact ⟨-x, hsym x hx, map_neg _ _⟩
  have hTrat : ∀ y ∈ T, ∀ i, ∃ q : ℚ, (q : ℝ) = y i := by
    intro y hy i
    simp only [T, Finset.mem_image] at hy
    obtain ⟨x, hx, rfl⟩ := hy
    exact hrat x hx i
  obtain ⟨v, _, _, hinner, houter, ⟨cert⟩⟩ :=
    exists_rational_vertex_normalization hr T hTspan hTsym hTrat
  let a₀ := basisEuclideanNormalization v
  obtain ⟨b₁, hΛ₁, hdefect⟩ := exists_standard_lattice_basis_bounded_defect a₀ cert
  let a : E ≃L[ℝ] EuclideanSpace ℝ (Fin r) :=
    b₀.equivFun.toContinuousLinearEquiv.trans a₀
  let b : Basis (Fin r) ℝ E := b₁.map b₀.equivFun.symm
  have hΛ : basisIntegerLattice b = basisIntegerLattice b₀ := by
    rw [show b = b₁.map b₀.equivFun.symm from rfl, basisIntegerLattice_map, hΛ₁]
    ext x
    constructor
    · rintro ⟨_, ⟨z, rfl⟩, rfl⟩ j
      refine ⟨z j, ?_⟩
      change b₀.equivFun (b₀.equivFun.symm (realVector z)) j = (z j : ℝ)
      rw [LinearEquiv.apply_symm_apply]
      rfl
    · intro hx
      choose z hz using hx
      refine ⟨realVector z, Set.mem_range_self z, ?_⟩
      apply b₀.equivFun.injective
      rw [LinearEquiv.apply_symm_apply]
      exact funext (fun j => (hz j).symm)
  have hHull : a '' convexHull ℝ (S : Set E) = a₀ '' convexHull ℝ (T : Set (Fin r → ℝ)) := by
    rw [hT, ← basis_coordinates_image_convexHull b₀, Set.image_image]
    rfl
  have hbmap : b.map a.toLinearEquiv = b₁.map a₀.toLinearEquiv := by
    apply DFunLike.coe_injective
    funext j
    change a₀ (b₀.equivFun (b₀.equivFun.symm (b₁ j))) = a₀ (b₁ j)
    rw [LinearEquiv.apply_symm_apply]
  refine ⟨a, b, hΛ, ?_, ?_, ?_⟩
  · rw [hHull]
    exact hinner
  · rw [hHull]
    exact houter
  · rw [hbmap]
    exact hdefect

/-- Finite lattice-point sets depend on the full lattice itself, rather than
on the basis used to describe it. -/
theorem basisLatticePoints_eq_of_lattice_eq (b b₀ : Basis (Fin r) ℝ E)
    (hΛ : basisIntegerLattice b = basisIntegerLattice b₀) (K : Set E) (hK : IsCompact K) :
    basisLatticePoints b K hK = basisLatticePoints b₀ K hK := by
  ext x
  simp only [mem_basisLatticePoints, hΛ]

/-- Mathematical full-lattice boxing for a rational symmetric polytope in
arbitrary reference-lattice coordinates. All dilated counts use the original
reference lattice, and the output basis generates exactly that same lattice. -/
theorem rational_polytope_full_lattice_boxing (hr : 0 < r)
    (b₀ : Basis (Fin r) ℝ E) (S : Finset E)
    (hsym : ∀ x ∈ S, -x ∈ S)
    (hrat : ∀ x ∈ S, ∀ i, ∃ q : ℚ, (q : ℝ) = b₀.equivFun x i)
    (x : Fin r → E) (hx : LinearIndependent ℝ x)
    (hxS : ∀ i, x i ∈ convexHull ℝ (S : Set E))
    (hxΛ : ∀ i, x i ∈ basisIntegerLattice b₀) :
    ∃ b : Basis (Fin r) ℝ E, basisIntegerLattice b = basisIntegerLattice b₀ ∧
      ∃ n : Fin r → ℕ, (∀ j, 1 ≤ n j) ∧
        convexHull ℝ (S : Set E) ⊆ basisCoefficientBox b n ∧
        basisCoefficientBox b n ⊆
          latticeBoxingDilation r ((r.factorial:ℝ)*latticeReductionDefectBound r) •
            convexHull ℝ (S : Set E) ∧
        ∀ s : ℝ,
          (basisLatticePoints b₀ (s • basisCoefficientBox b n)
            ((basisCoefficientBox_compact b n).smul s)).card ≤
          (latticeBoxingResidueModulus r (latticeReductionDefectBound r))^r *
            (basisLatticePoints b₀ (s • convexHull ℝ (S : Set E))
              (S.finite_toSet.isCompact_convexHull.smul s)).card := by
  obtain ⟨a, b, hΛ, hinner, houter, hdefect⟩ := rational_polytope_normalization_and_basis hr
    b₀ S (vertices_span_of_independent_hull b₀ S x hx hxS) hsym hrat
  have hxΛ' (i : Fin r) : x i ∈ basisIntegerLattice b := by rw [hΛ]; exact hxΛ i
  obtain ⟨n, hn, hsub, hencl, hc⟩ := lattice_boxing_and_counting_of_normalization hr
    (convexHull ℝ (S : Set E)) S.finite_toSet.isCompact_convexHull (convex_convexHull ℝ _)
    (symmetric_vertex_hull S hsym) a hinner houter b (latticeReductionDefectBound r)
    (latticeReductionDefectBound_pos r) hdefect x hx hxS hxΛ'
  refine ⟨b, hΛ, n, hn, hsub, hencl, fun s => ?_⟩
  simpa only [basisLatticePoints_eq_of_lattice_eq b b₀ hΛ] using hc s

end ReferenceLattice


/-- Rational standard coordinates of both the reference basis and the vertices
imply rational reference-lattice coordinates by the actual inverse matrix. -/
theorem rational_basis_coordinates (b₀ : Basis (Fin r) ℝ (Fin r → ℝ))
    (hb₀ : ∀ i j, ∃ q : ℚ, (q : ℝ) = b₀ j i)
    (x : Fin r → ℝ) (hx : ∀ i, ∃ q : ℚ, (q : ℝ) = x i) :
    ∀ i, ∃ q : ℚ, (q : ℝ) = b₀.equivFun x i := by
  choose Q hQ using hb₀
  let A : Matrix (Fin r) (Fin r) ℚ := Q
  obtain ⟨_, _, _, hcoord⟩ := rational_basis_inverse b₀ A hQ
  choose z hz using hx
  intro i
  refine ⟨∑ j, A⁻¹ i j * z j, ?_⟩
  rw [hcoord]
  simp only [Rat.cast_sum, Rat.cast_mul, hz, Matrix.mulVec, dotProduct, Matrix.map_apply]

/-- Standard-coordinate specialization: independent integer points suffice to
derive full span, and both counts are for all actual integer points. -/
theorem rational_polytope_standard_lattice_boxing (hr : 0 < r)
    (S : Finset (Fin r → ℝ)) (hsym : ∀ x ∈ S, -x ∈ S)
    (hrat : ∀ x ∈ S, ∀ i, ∃ q : ℚ, (q : ℝ) = x i)
    (u : Fin r → IntVec r) (hu : LinearIndependent ℝ (fun i => realVector (u i)))
    (huS : ∀ i, realVector (u i) ∈ convexHull ℝ (S : Set (Fin r → ℝ))) :
    ∃ b : Basis (Fin r) ℝ (Fin r → ℝ), basisIntegerLattice b = Set.range (@realVector r) ∧
      ∃ n : Fin r → ℕ, (∀ j, 1 ≤ n j) ∧
        convexHull ℝ (S : Set (Fin r → ℝ)) ⊆ basisCoefficientBox b n ∧
        basisCoefficientBox b n ⊆
          latticeBoxingDilation r ((r.factorial:ℝ)*latticeReductionDefectBound r) •
            convexHull ℝ (S : Set (Fin r → ℝ)) ∧
        ∀ s : ℝ,
          (integerPoints (s • basisCoefficientBox b n)
            ((basisCoefficientBox_compact b n).smul s).isBounded).card ≤
          (latticeBoxingResidueModulus r (latticeReductionDefectBound r))^r *
            (integerPoints (s • convexHull ℝ (S : Set (Fin r → ℝ)))
              (S.finite_toSet.isCompact_convexHull.smul s).isBounded).card := by
  have hrat₀ : ∀ x ∈ S, ∀ i, ∃ q : ℚ,
      (q : ℝ) = (Pi.basisFun ℝ (Fin r)).equivFun x i := by
    simpa only [Basis.equivFun_apply, Pi.basisFun_repr] using hrat
  have huΛ (i : Fin r) : realVector (u i) ∈ basisIntegerLattice (Pi.basisFun ℝ (Fin r)) := by
    rw [basisIntegerLattice_standard]
    exact Set.mem_range_self _
  obtain ⟨b, hΛ, n, hn, hsub, hencl, hc⟩ := rational_polytope_full_lattice_boxing hr
    (Pi.basisFun ℝ (Fin r)) S hsym hrat₀ (fun i => realVector (u i)) hu huS huΛ
  refine ⟨b, hΛ.trans basisIntegerLattice_standard, n, hn, hsub, hencl, fun s => ?_⟩
  simpa only [basisLatticePoints_standard_card (Pi.basisFun ℝ (Fin r))
    basisIntegerLattice_standard] using hc s

end
end Optss
