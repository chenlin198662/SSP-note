import Optss.FreimanCube
import Optss.FreimanHalfspace

/-!
# Dimension induction for the Freiman cube lemma

The positive constants are defined recursively; their positivity and the
induction inequalities are proved directly. This avoids relying on the
particularly weak closed-form constant in the source.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 1800000
variable {E : Type*} [AddCommGroup E] [Module ℝ E]

def freimanCubeFraction : ℕ → ℝ → ℝ
  | 0, _ => 1
  | r+1, τ => min (1/3) (freimanCubeFraction r (9*τ^2) / (9*τ))

theorem freimanCubeFraction_pos (r : ℕ) (τ : ℝ) (hτ : 0 < τ) :
    0 < freimanCubeFraction r τ := by
  induction r generalizing τ with
  | zero => norm_num [freimanCubeFraction]
  | succ r ih =>
    rw [freimanCubeFraction]
    exact lt_min (by norm_num) (div_pos (ih _ (by positivity)) (by positivity))

theorem freimanCubeFraction_le_third (r : ℕ) (τ : ℝ) :
    freimanCubeFraction (r+1) τ ≤ 1/3 := min_le_left _ _

omit [Module ℝ E] in
theorem finset_translate_add (S T : Finset E) (a b : E) :
    S.image (a + ·) + T.image (b + ·) = (S+T).image ((a+b) + ·) := by
  ext x
  constructor
  · intro hx
    obtain ⟨u, hu, v, hv, rfl⟩ := Finset.mem_add.mp hx
    obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hu
    obtain ⟨z, hz, rfl⟩ := Finset.mem_image.mp hv
    exact Finset.mem_image.mpr ⟨y+z, Finset.add_mem_add hy hz, by abel⟩
  · intro hx
    obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
    obtain ⟨u, hu, v, hv, rfl⟩ := Finset.mem_add.mp hy
    exact Finset.mem_add.mpr ⟨a+u, Finset.mem_image.mpr ⟨u, hu, rfl⟩,
      b+v, Finset.mem_image.mpr ⟨v, hv, rfl⟩, by abel⟩

omit [Module ℝ E] in
theorem finset_translate_double_card (S : Finset E) (a : E) :
    (S.image (a+·) + S.image (a+·)).card = (S+S).card := by
  rw [finset_translate_add, Finset.card_image_of_injective _ (add_right_injective _)]

theorem centered_translate_symmetric (S : Finset E) (a : E)
    (hS : ∀ x ∈ S, (2 : ℝ) • a - x ∈ S) :
    ∀ x ∈ S.image (-a+·), -x ∈ S.image (-a+·) := by
  intro x hx
  obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
  exact Finset.mem_image.mpr ⟨(2 : ℝ) • a-y, hS y hy, by module⟩

def freimanCubeCapture (S : Finset E) (L : Submodule ℝ E) (a : E) (v : List E) : Finset E :=
  S.filter (fun x => x-a ∈ freimanCubeBody v + (L : Set E))

theorem freimanCubeCapture_translate (S : Finset E) (L : Submodule ℝ E) (a : E)
    (v : List E) :
    freimanCubeCapture (S.image (-a+·)) L 0 v = (freimanCubeCapture S L a v).image (-a+·) := by
  ext x
  simp only [freimanCubeCapture, Finset.mem_filter, Finset.mem_image, sub_zero]
  constructor
  · rintro ⟨⟨y, hy, rfl⟩, hmem⟩
    refine ⟨y, ⟨hy, ?_⟩, rfl⟩
    convert hmem using 1
    abel
  · rintro ⟨y, ⟨hy, hmem⟩, rfl⟩
    refine ⟨⟨y, hy, rfl⟩, ?_⟩
    convert hmem using 1
    abel

theorem freimanCubeCapture_symmetric (S : Finset E) (L : Submodule ℝ E) (a : E)
    (v : List E) (hS : ∀ x ∈ S, (2 : ℝ) • a-x ∈ S) :
    ∀ x ∈ freimanCubeCapture S L a v,
      (2 : ℝ) • a-x ∈ freimanCubeCapture S L a v := by
  intro x hx
  obtain ⟨hxS, hxC⟩ := Finset.mem_filter.mp hx
  obtain ⟨q, hq, y, hy, he⟩ := Set.mem_add.mp hxC
  apply Finset.mem_filter.mpr
  refine ⟨hS x hxS, Set.mem_add.mpr ⟨-q, freimanCubeBody_symmetric v q hq,
    -y, L.neg_mem hy, ?_⟩⟩
  calc
    -q + -y = -(q+y) := by abel
    _ = -(x-a) := by rw [he]
    _ = (2 : ℝ) • a-x-a := by module

omit [Module ℝ E] in
theorem freimanCubeVertices_replicate_zero (r : ℕ) :
    freimanCubeVertices (List.replicate r (0 : E)) = {0} := by
  induction r with
  | zero => rfl
  | succ r ih => simpa only [List.replicate_succ, freimanCubeVertices_zero_cons] using ih

theorem nonzero_linear_form_kernel_finrank [FiniteDimensional ℝ E]
    (f : E →ₗ[ℝ] ℝ) (hf : f ≠ 0) :
    Module.finrank ℝ (LinearMap.ker f) + 1 = Module.finrank ℝ E := by
  have hx : ∃ x, f x ≠ 0 := by
    by_contra h
    push_neg at h
    exact hf (LinearMap.ext h)
  obtain ⟨x, hx⟩ := hx
  have hsurj : Function.Surjective f := fun y =>
    ⟨(y / f x) • x, by simp only [map_smul, smul_eq_mul, div_mul_cancel₀ _ hx]⟩
  have hh := f.finrank_range_add_finrank_ker
  rw [LinearMap.range_eq_top.mpr hsurj] at hh
  simp only [finrank_top, Module.finrank_self] at hh
  omega

/-- The full symmetric cube induction, modulo a specified subspace. It
constructs actual vertices in `S` and retains a positive, uniform fraction
of `S` inside the cube plus that subspace. -/
theorem symmetric_freiman_cube [FiniteDimensional ℝ E]
    (r : ℕ) (hr : 0 < r) (L : Submodule ℝ E)
    (hdim : Module.finrank ℝ L + r = Module.finrank ℝ E)
    (S : Finset E) (hS : S.Nonempty) (hsym : ∀ x ∈ S, -x ∈ S)
    (τ : ℝ) (hτ : 0 < τ) (hdoub : ((S+S).card : ℝ) ≤ τ * S.card) :
    ∃ v : List E, v.length = r ∧ freimanCubeVertices v ⊆ S ∧
      freimanCubeFraction r τ * S.card ≤ (freimanCubeCapture S L 0 v).card := by
  induction r using Nat.strong_induction_on generalizing L S τ with
  | h r ih =>
    have hδ : freimanCubeFraction r τ ≤ 1/3 := by
      cases r with
      | zero => omega
      | succ r => exact freimanCubeFraction_le_third r τ
    let Z := S.filter (fun x => x ∈ L)
    by_cases hmany : S.card ≤ 3 * Z.card
    · have hZne : Z.Nonempty := Finset.card_pos.mp (by have := hS.card_pos; omega)
      obtain ⟨a, ha⟩ := hZne
      obtain ⟨haS, haL⟩ := Finset.mem_filter.mp ha
      let v := a :: List.replicate (r-1) 0
      have hverts : freimanCubeVertices v ⊆ S := by
        change {-a,a} + freimanCubeVertices (List.replicate (r-1) 0) ⊆ S
        rw [freimanCubeVertices_replicate_zero]
        change {-a,a} + (0 : Finset E) ⊆ S
        rw [add_zero]
        intro x hx
        rcases (show x = -a ∨ x = a by simpa using hx) with rfl | rfl
        · exact hsym a haS
        · exact haS
      have hZsub : Z ⊆ freimanCubeCapture S L 0 v := by
        intro x hx
        obtain ⟨hxS, hxL⟩ := Finset.mem_filter.mp hx
        apply Finset.mem_filter.mpr
        refine ⟨hxS, ?_⟩
        rw [sub_zero]
        exact Set.mem_add.mpr ⟨0, freimanCubeBody_zero v, x, hxL, zero_add x⟩
      refine ⟨v, by simp only [v, List.length_cons, List.length_replicate]; omega, hverts, ?_⟩
      have hm : (S.card : ℝ) ≤ 3 * Z.card := by exact_mod_cast hmany
      have hz : (Z.card : ℝ) ≤ (freimanCubeCapture S L 0 v).card :=
        by exact_mod_cast Finset.card_le_card hZsub
      have hsnn : (0 : ℝ) ≤ S.card := by positivity
      nlinarith
    · have houtside : ∃ x ∈ S, x ∉ L := by
        by_contra hn
        push_neg at hn
        have he : Z = S := Finset.filter_eq_self.mpr hn
        rw [he] at hmany
        omega
      obtain ⟨f, hf, hfL, hfS⟩ := finite_exact_hyperplane_form L S houtside
      by_cases hr1 : r = 1
      · have hker : L = LinearMap.ker f := Submodule.eq_of_le_of_finrank_eq hfL (by
          have hh := nonzero_linear_form_kernel_finrank f hf
          omega)
        obtain ⟨a, ha, hna, hcover⟩ := exists_segment_mod_kernel S hS hsym f
        have hverts : freimanCubeVertices [a] ⊆ S := by
          change {-a,a} + (0 : Finset E) ⊆ S
          rw [add_zero]
          intro x hx
          rcases (show x = -a ∨ x = a by simpa using hx) with rfl | rfl
          · exact hna
          · exact ha
        have hsub : S ⊆ freimanCubeCapture S L 0 [a] := by
          intro x hx
          apply Finset.mem_filter.mpr
          refine ⟨hx, ?_⟩
          simpa only [sub_zero, freimanCubeBody, hker] using hcover x hx
        refine ⟨[a], by simp [hr1], hverts, ?_⟩
        have hh : (S.card : ℝ) ≤ (freimanCubeCapture S L 0 [a]).card :=
          by exact_mod_cast Finset.card_le_card hsub
        have hsnn : (0 : ℝ) ≤ S.card := by positivity
        nlinarith
      · have hzEq : S.filter (fun x => f x = 0) = Z := by
          apply Finset.filter_congr
          intro x hx
          exact hfS x hx
        have hzsmall : 3 * (S.filter (fun x => f x = 0)).card ≤ S.card := by
          rw [hzEq]
          omega
        obtain ⟨a, T, hTne, hTS, hTpos, haPos, hTsym, hTsize, hTdoub⟩ :=
          positive_halfspace_symmetric_subset S hS hsym f hzsmall τ hτ hdoub
        have haL : a ∉ L := fun haL => (ne_of_gt haPos) (hfL haL)
        have ha0 : a ≠ 0 := by intro ha; rw [ha, map_zero] at haPos; linarith
        let L₁ := L ⊔ Submodule.span ℝ ({a} : Set E)
        have hdim₁ : Module.finrank ℝ L₁ = Module.finrank ℝ L + 1 := by
          have hh := Submodule.finrank_sup_add_finrank_inf_eq L (Submodule.span ℝ ({a} : Set E))
          rw [(Submodule.disjoint_span_singleton_of_not_mem haL).eq_bot,
            finrank_bot, finrank_span_singleton ha0, add_zero] at hh
          exact hh
        let T₀ := T.image (-a+·)
        have hT₀card : T₀.card = T.card := Finset.card_image_of_injective _ (add_right_injective _)
        have hT₀ne : T₀.Nonempty := hTne.image _
        have hT₀sym := centered_translate_symmetric T a hTsym
        have hT₀doub : ((T₀+T₀).card : ℝ) ≤ (9*τ^2) * T₀.card := by
          rw [hT₀card]
          change ((T.image (-a+·) + T.image (-a+·)).card : ℝ) ≤ _
          rw [finset_translate_double_card]
          exact hTdoub
        obtain ⟨v, hvlen, hverts₀, hcapture₀⟩ := ih (r-1) (by omega) (by omega) L₁
          (by omega) T₀ hT₀ne hT₀sym (9*τ^2) (by positivity) hT₀doub
        have hvertsT : ∀ q ∈ freimanCubeVertices v, a+q ∈ T := by
          intro q hq
          obtain ⟨x, hx, he⟩ := Finset.mem_image.mp (hverts₀ hq)
          convert hx using 1
          rw [← he]
          abel
        have hbodyPos : ∀ q ∈ freimanCubeBody v, 0 < f (a+q) := by
          have hh := freimanCubeBody_halfspace v f (-f a) (fun q hq => by
            have hp := hTpos _ (hvertsT q hq)
            rw [map_add] at hp
            linarith)
          intro q hq
          rw [map_add]
          linarith [hh q hq]
        let U := freimanCubeCapture T L₁ a v
        let V := freimanCubeCapture S L 0 (a::v)
        have hUcard : (freimanCubeCapture T₀ L₁ 0 v).card = U.card := by
          rw [freimanCubeCapture_translate, Finset.card_image_of_injective _ (add_right_injective _)]
        have hUpos : ∀ x ∈ U, 0 < f x := fun x hx => hTpos x (Finset.mem_filter.mp hx).1
        have hUref := freimanCubeCapture_symmetric T L₁ a v hTsym
        have hVsym : ∀ x ∈ V, -x ∈ V := by
          have hh := freimanCubeCapture_symmetric S L 0 (a::v)
            (fun x hx => by simpa using hsym x hx)
          simpa only [smul_zero, zero_sub] using hh
        have hcover : ∀ u ∈ U, u ∈ V ∨ (2 : ℝ) • a-u ∈ V := by
          intro u hu
          obtain ⟨huT, huC⟩ := Finset.mem_filter.mp hu
          obtain ⟨q, hq, z, hz, he⟩ := Set.mem_add.mp huC
          obtain ⟨y, hy, z', hz', hz⟩ := Submodule.mem_sup.mp hz
          obtain ⟨t, ht⟩ := Submodule.mem_span_singleton.mp hz'
          have hue : u = a+q+t • a+y := by
            calc
              u = a+(u-a) := by abel
              _ = a+(q+z) := by rw [he]
              _ = a+(q+(y+z')) := by rw [hz]
              _ = _ := by rw [← ht]; abel
          have hve : (2 : ℝ) • a-u = a-q-t • a-y := by rw [hue]; module
          have hqneg := freimanCubeBody_symmetric v q hq
          have hqm : 0 < f (a-q) := by simpa only [sub_eq_add_neg] using hbodyPos (-q) hqneg
          have halternative := cube_axis_reflection_alternative L f hfL a q y t
            (freimanCubeBody v) haPos hq hqneg hy (hbodyPos q hq) hqm
            (by rw [← hue]; exact hTpos u huT)
            (by rw [← hve]; exact hTpos _ (hTsym u huT))
          rcases halternative with hu | hv
          · left
            apply Finset.mem_filter.mpr
            exact ⟨hTS huT, by simpa only [sub_zero, freimanCubeBody, ← hue] using hu⟩
          · right
            apply Finset.mem_filter.mpr
            exact ⟨hTS (hTsym u huT), by simpa only [sub_zero, freimanCubeBody, ← hve] using hv⟩
        have hUV := reflection_selection_card_le U V a f hUpos hUref hVsym hcover
        have hverts : freimanCubeVertices (a::v) ⊆ S := by
          intro x hx
          obtain ⟨p, hp, q, hq, rfl⟩ := Finset.mem_add.mp hx
          rcases (show p = -a ∨ p = a by simpa using hp) with rfl | rfl
          · have hh := hsym _ (hTS (hvertsT (-q) (freimanCubeVertices_symmetric v q hq)))
            convert hh using 1
            abel
          · exact hTS (hvertsT q hq)
        refine ⟨a::v, by simp only [List.length_cons, hvlen]; omega, hverts, ?_⟩
        have hδstep : freimanCubeFraction r τ ≤
            freimanCubeFraction (r-1) (9*τ^2) / (9*τ) := by
          have hrEq : r = (r-1)+1 := by omega
          conv_lhs => rw [hrEq, freimanCubeFraction]
          exact min_le_right _ _
        rw [hT₀card, hUcard] at hcapture₀
        calc
          _ ≤ (freimanCubeFraction (r-1) (9*τ^2) / (9*τ)) * S.card :=
            mul_le_mul_of_nonneg_right hδstep (Nat.cast_nonneg _)
          _ = freimanCubeFraction (r-1) (9*τ^2) * (S.card / (9*τ)) := by ring
          _ ≤ freimanCubeFraction (r-1) (9*τ^2) * T.card :=
            mul_le_mul_of_nonneg_left hTsize (freimanCubeFraction_pos _ _ (by positivity)).le
          _ ≤ U.card := hcapture₀
          _ ≤ (V.card : ℝ) := by exact_mod_cast hUV

def generalFreimanCubeFraction (n : ℕ) (τ : ℝ) : ℝ := freimanCubeFraction n (τ^2) / τ

theorem generalFreimanCubeFraction_pos (n : ℕ) (τ : ℝ) (hτ : 0 < τ) :
    0 < generalFreimanCubeFraction n τ :=
  div_pos (freimanCubeFraction_pos n _ (by positivity)) hτ

/-- Bilu's cube lemma for an arbitrary nonempty finite set. The cube is
constructed with actual vertices in the input; its captured fraction is a
positive function solely of dimension and the doubling parameter. -/
theorem freiman_cube_lemma [FiniteDimensional ℝ E]
    (hn : 0 < Module.finrank ℝ E) (S : Finset E) (hS : S.Nonempty)
    (τ : ℝ) (hτ : 0 < τ) (hdoub : ((S+S).card : ℝ) ≤ τ * S.card) :
    ∃ b : E, ∃ v : List E, v.length = Module.finrank ℝ E ∧
      (freimanCubeVertices v).image (b+·) ⊆ S ∧
      generalFreimanCubeFraction (Module.finrank ℝ E) τ * S.card ≤
        (freimanCubeCapture S ⊥ b v).card := by
  obtain ⟨t, T, hTS, hTsym, hTsize, hTdoub⟩ := small_doubling_symmetric_subset S hS τ hτ hdoub
  have hTne : T.Nonempty := by
    apply Finset.card_pos.mp
    have hSpos : (0 : ℝ) < S.card := by exact_mod_cast hS.card_pos
    have hh : (0 : ℝ) < T.card := (div_pos hSpos hτ).trans_le hTsize
    exact_mod_cast hh
  let b := (1/2 : ℝ) • t
  have hb : (2 : ℝ) • b = t := by dsimp [b]; module
  have hTsym' : ∀ x ∈ T, (2 : ℝ) • b-x ∈ T := by simpa only [hb] using hTsym
  let T₀ := T.image (-b+·)
  have hT₀card : T₀.card = T.card := Finset.card_image_of_injective _ (add_right_injective _)
  have hT₀doub : ((T₀+T₀).card : ℝ) ≤ τ^2 * T₀.card := by
    rw [hT₀card]
    change ((T.image (-b+·) + T.image (-b+·)).card : ℝ) ≤ _
    rw [finset_translate_double_card]
    exact hTdoub
  obtain ⟨v, hv, hverts, hcapture⟩ := symmetric_freiman_cube (Module.finrank ℝ E) hn ⊥
    (by simp) T₀ (hTne.image _) (centered_translate_symmetric T b hTsym') (τ^2)
    (by positivity) hT₀doub
  refine ⟨b, v, hv, ?_, ?_⟩
  · intro x hx
    obtain ⟨q, hq, rfl⟩ := Finset.mem_image.mp hx
    obtain ⟨y, hy, he⟩ := Finset.mem_image.mp (hverts hq)
    apply hTS
    convert hy using 1
    rw [← he]
    abel
  · have hcapcard : (freimanCubeCapture T₀ ⊥ 0 v).card =
        (freimanCubeCapture T ⊥ b v).card := by
      rw [freimanCubeCapture_translate, Finset.card_image_of_injective _ (add_right_injective _)]
    have hcapsub : freimanCubeCapture T ⊥ b v ⊆ freimanCubeCapture S ⊥ b v :=
      Finset.filter_subset_filter _ hTS
    rw [hT₀card, hcapcard] at hcapture
    calc
      _ = freimanCubeFraction (Module.finrank ℝ E) (τ^2) * (S.card / τ) := by
        unfold generalFreimanCubeFraction
        ring
      _ ≤ freimanCubeFraction (Module.finrank ℝ E) (τ^2) * T.card :=
        mul_le_mul_of_nonneg_left hTsize (freimanCubeFraction_pos _ _ (by positivity)).le
      _ ≤ (freimanCubeCapture T ⊥ b v).card := hcapture
      _ ≤ (freimanCubeCapture S ⊥ b v).card := by exact_mod_cast Finset.card_le_card hcapsub

end
end Optss
