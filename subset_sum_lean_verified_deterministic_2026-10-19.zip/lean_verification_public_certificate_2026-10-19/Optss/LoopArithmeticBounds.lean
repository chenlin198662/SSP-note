import Optss.CachedReductionCost
import Optss.RationalArithmeticBounds
import Optss.BinaryRationalModel

/-!
# Uniform arithmetic bounds throughout the lattice-reduction loop

The actual array-valued loop supplies the pass trace. Complete size reduction
bounds every entry by rank times the current potential, adjacent interchange
preserves that entry bound, and every accepted interchange decreases potential.
Thus all passes share bounds fixed by the original input.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

/-- Pass-input arrays in the materialized algorithm, including the initial
array and each actual array after an accepted adjacent interchange. -/
def materializedPassTrace : ℕ → IntegerMatrixData r d → List (IntegerMatrixData r d)
  | 0, D => [D]
  | n+1, D =>
    let C := materializedReduceIntegerAll D r le_rfl
    let A := integerMatrixDataRows C
    if h : (cachedFailingAdjacentPairs A).Nonempty then
      let p := cachedLeastFailingAdjacentPair A h
      D :: materializedPassTrace n (materializeIntegerMatrix (swapRows A p.1 p.2))
    else [D]

/-- The trace length is tied to the loop's actual swaps. A zero-fuel input
still records its initial array, so this is an upper bound on executed passes. -/
theorem materializedPassTrace_length (fuel : ℕ) (D : IntegerMatrixData r d) :
    (materializedPassTrace fuel D).length = (materializedReductionFuel fuel D).2+1 := by
  induction fuel generalizing D with
  | zero => rfl
  | succ n ih =>
    rw [materializedPassTrace, materializedReductionFuel]
    split_ifs <;> simp only [List.length_cons, List.length_singleton, List.length_nil, Prod.snd, ih]

theorem materializedFullSweep_invariants (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ))) :
    let C := integerMatrixDataRows (materializedReduceIntegerAll D r le_rfl)
    LinearIndependent ℝ (fun i j => (C i j:ℝ)) ∧
    gramPotential C = gramPotential (integerMatrixDataRows D) ∧
    (∀ i j, |C i j| ≤ (r*gramPotential (integerMatrixDataRows D):ℕ)) := by
  dsimp only
  rw [materializedReduceIntegerAll_eq, cachedReduceIntegerAll_eq]
  obtain ⟨hind, _, hp, hsize⟩ := rationalReduceIntegerAll_spec (integerMatrixDataRows D) hD
  refine ⟨hind, hp, ?_⟩
  intro i j
  simpa only [hp] using sizeReduced_entry_le_potential _ hind hsize i j

/-- Every visited pass input has independent rows, potential at most `P`, and
entry height at most `H`, provided `H` also covers the reduced height `rP`.
The hypotheses are conditions on the initial input, not on future states. -/
theorem materializedPassTrace_invariants (fuel : ℕ) (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ)))
    (H P : ℕ) (hP : gramPotential (integerMatrixDataRows D) ≤ P)
    (hH : ∀ i j, |integerMatrixDataRows D i j| ≤ (H:ℤ)) (hcover : r*P ≤ H)
    (E : IntegerMatrixData r d) (hE : E ∈ materializedPassTrace fuel D) :
    LinearIndependent ℝ (fun i j => (integerMatrixDataRows E i j:ℝ)) ∧
    gramPotential (integerMatrixDataRows E) ≤ P ∧
    (∀ i j, |integerMatrixDataRows E i j| ≤ (H:ℤ)) := by
  induction fuel generalizing D with
  | zero =>
    have he : E = D := by simpa only [materializedPassTrace, List.mem_singleton] using hE
    subst E
    exact ⟨hD,hP,hH⟩
  | succ n ih =>
    rw [materializedPassTrace] at hE
    split_ifs at hE with hbad
    · rcases List.mem_cons.mp hE with he | hE
      · subst E
        exact ⟨hD,hP,hH⟩
      · let C := integerMatrixDataRows (materializedReduceIntegerAll D r le_rfl)
        obtain ⟨hC, hpC, hhC⟩ := materializedFullSweep_invariants D hD
        let p := cachedLeastFailingAdjacentPair C hbad
        have hp : p ∈ failingAdjacentPairs C := by
          dsimp only [p]
          rw [cachedLeastFailingAdjacentPair_eq C hC hbad]
          exact leastFailingAdjacentPair_mem C _
        have hpair := (mem_failingAdjacentPairs C p).mp hp
        have hdec : gramPotential (swapRows C p.1 p.2) < gramPotential C :=
          gramPotential_swap_lt_of_three_quarters C hC p.1 p.2 hpair.1 hpair.2
        have hind : LinearIndependent ℝ (fun i j => (swapRows C p.1 p.2 i j:ℝ)) :=
          hC.comp (Equiv.swap p.1 p.2) (Equiv.swap p.1 p.2).injective
        have hnextP : gramPotential (swapRows C p.1 p.2) ≤ P := by
          exact hdec.le.trans (hpC ▸ hP)
        have hnextH : ∀ i j, |swapRows C p.1 p.2 i j| ≤ (H:ℤ) := by
          intro i j
          have hc := hhC ((Equiv.swap p.1 p.2) i) j
          have hnat : r*gramPotential (integerMatrixDataRows D) ≤ H :=
            (Nat.mul_le_mul_left r hP).trans hcover
          exact hc.trans (by exact_mod_cast hnat)
        apply ih (materializeIntegerMatrix (swapRows C p.1 p.2))
          (by simpa only [integerMatrixDataRows_materialize] using hind)
          (by simpa only [integerMatrixDataRows_materialize] using hnextP)
          (by simpa only [integerMatrixDataRows_materialize] using hnextH) hE
    · have he : E = D := List.mem_singleton.mp hE
      subst E
      exact ⟨hD,hP,hH⟩

/-- The original height and potential give one bound for every pass. -/
theorem materializedPassTrace_initial_bounds (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (fuel : ℕ)
    (E : IntegerMatrixData r d) (hE : E ∈ materializedPassTrace fuel (materializeIntegerMatrix A)) :
    LinearIndependent ℝ (fun i j => (integerMatrixDataRows E i j:ℝ)) ∧
    gramPotential (integerMatrixDataRows E) ≤ gramPotential A ∧
    (∀ i j, |integerMatrixDataRows E i j| ≤ (max H (r*gramPotential A):ℕ)) := by
  apply materializedPassTrace_invariants fuel (materializeIntegerMatrix A)
    (by simpa only [integerMatrixDataRows_materialize] using hA)
    (max H (r*gramPotential A)) (gramPotential A)
    (by rw [integerMatrixDataRows_materialize])
  · intro i j
    rw [integerMatrixDataRows_materialize]
    exact (hH i j).trans (by exact_mod_cast le_max_left H (r*gramPotential A))
  · exact le_max_right _ _
  · exact hE

/-- Uniform polynomial base for all passes and all their partial sweeps. -/
def loopArithmeticBase (r d H P : ℕ) : ℕ :=
  sweepArithmeticBase r d (max H (r*P)) P

theorem sweepArithmeticBase_mono (r d : ℕ) {H H' P P' : ℕ}
    (hH : H ≤ H') (hP : P ≤ P') :
    sweepArithmeticBase r d H P ≤ sweepArithmeticBase r d H' P' := by
  unfold sweepArithmeticBase partialReductionGrowth
  gcongr

/-- Every cached partial residual in every actual pass has one bit bound fixed
by the original input. -/
theorem loop_innerTrace_cachedResidual_bits
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (fuel : ℕ)
    (E : IntegerMatrixData r d) (hE : E ∈ materializedPassTrace fuel (materializeIntegerMatrix A))
    (k : Fin r) (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace
      (rationalReduceIntegerAll (integerMatrixDataRows E) k.val (Nat.le_of_lt k.isLt)) k k.val le_rfl)
    (i : Fin r) (l : Fin d) (s : Finset (Fin r)) (hs : ∀ j ∈ s, j < i) :
    let Q := rationalIntegerRows B
    let T := cachedGSTable Q i.val (Nat.le_of_lt i.isLt)
    let q := Q i l - ∑ j ∈ s, cachedGsCoefficient Q T i j * (T.get j).get l
    RationalBitBound q ((r+1)*(12*r+25)*(loopArithmeticBase r d H (gramPotential A)).size) := by
  obtain ⟨hEin,hEP,hEH⟩ := materializedPassTrace_initial_bounds A hA H hH fuel E hE
  have hb := outerSweep_innerTrace_cachedResidual_polynomial_bits (integerMatrixDataRows E)
    hEin (max H (r*gramPotential A)) hEH k B hB i l s hs
  have hbase := sweepArithmeticBase_mono r d (H := max H (r*gramPotential A))
    (H' := max H (r*gramPotential A)) le_rfl hEP
  have hsize := Nat.mul_le_mul_left ((r+1)*(12*r+25)) (Nat.size_le_size hbase)
  exact ⟨hb.1.trans hsize, hb.2.trans hsize⟩

/-- Every cached cross-dot-product accumulator in every actual pass has one
bit bound fixed by the original input. -/
theorem loop_innerTrace_cachedDot_bits
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (fuel : ℕ)
    (E : IntegerMatrixData r d) (hE : E ∈ materializedPassTrace fuel (materializeIntegerMatrix A))
    (k : Fin r) (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace
      (rationalReduceIntegerAll (integerMatrixDataRows E) k.val (Nat.le_of_lt k.isLt)) k k.val le_rfl)
    (n : ℕ) (hn : n ≤ r) (i j : Fin r) (hj : j.val < n) (s : Finset (Fin d)) :
    let Q := rationalIntegerRows B
    let T := cachedGSTable Q n hn
    let q := rationalPartialDot s (T.get j).get (Q i)
    RationalBitBound q ((d+1)*(8*r+17)*(loopArithmeticBase r d H (gramPotential A)).size) := by
  obtain ⟨hEin,hEP,hEH⟩ := materializedPassTrace_initial_bounds A hA H hH fuel E hE
  have hb := outerSweep_innerTrace_cachedDot_polynomial_bits (integerMatrixDataRows E)
    hEin (max H (r*gramPotential A)) hEH k B hB n hn i j hj s
  have hbase := sweepArithmeticBase_mono r d (H := max H (r*gramPotential A))
    (H' := max H (r*gramPotential A)) le_rfl hEP
  have hsize := Nat.mul_le_mul_left ((d+1)*(8*r+17)) (Nat.size_le_size hbase)
  exact ⟨hb.1.trans hsize, hb.2.trans hsize⟩

/-- The denominator accumulators share the same uniform dot-product bound. -/
theorem loop_innerTrace_cachedSelfDot_bits
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (fuel : ℕ)
    (E : IntegerMatrixData r d) (hE : E ∈ materializedPassTrace fuel (materializeIntegerMatrix A))
    (k : Fin r) (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace
      (rationalReduceIntegerAll (integerMatrixDataRows E) k.val (Nat.le_of_lt k.isLt)) k k.val le_rfl)
    (n : ℕ) (hn : n ≤ r) (j : Fin r) (hj : j.val < n) (s : Finset (Fin d)) :
    let T := cachedGSTable (rationalIntegerRows B) n hn
    let q := rationalPartialDot s (T.get j).get (T.get j).get
    RationalBitBound q ((d+1)*(8*r+17)*(loopArithmeticBase r d H (gramPotential A)).size) := by
  obtain ⟨hEin,hEP,hEH⟩ := materializedPassTrace_initial_bounds A hA H hH fuel E hE
  have hb := outerSweep_innerTrace_cachedSelfDot_polynomial_bits (integerMatrixDataRows E)
    hEin (max H (r*gramPotential A)) hEH k B hB n hn j hj s
  have hbase := sweepArithmeticBase_mono r d (H := max H (r*gramPotential A))
    (H' := max H (r*gramPotential A)) le_rfl hEP
  have hsize := Nat.mul_le_mul_left ((d+1)*(8*r+17)) (Nat.size_le_size hbase)
  exact ⟨hb.1.trans hsize, hb.2.trans hsize⟩

/-- Actual division of any two cross/self accumulators in an actual pass has
cubic binary charge in the globally bounded operand bit length. -/
theorem loop_innerTrace_coefficientDivision_work
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (fuel : ℕ)
    (E : IntegerMatrixData r d) (hE : E ∈ materializedPassTrace fuel (materializeIntegerMatrix A))
    (k : Fin r) (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace
      (rationalReduceIntegerAll (integerMatrixDataRows E) k.val (Nat.le_of_lt k.isLt)) k k.val le_rfl)
    (n : ℕ) (hn : n ≤ r) (i j : Fin r) (hj : j.val < n) :
    let Q := rationalIntegerRows B
    let T := cachedGSTable Q n hn
    let x := rationalDot (T.get j).get (Q i)
    let y := rationalDot (T.get j).get (T.get j).get
    let L := (d+1)*(8*r+17)*(loopArithmeticBase r d H (gramPotential A)).size
    (binaryRatDiv x y).2 ≤ 2048*(L+1)^3 := by
  have hx := loop_innerTrace_cachedDot_bits A hA H hH fuel E hE k B hB n hn i j hj Finset.univ
  have hy := loop_innerTrace_cachedSelfDot_bits A hA H hH fuel E hE k B hB n hn j hj Finset.univ
  exact (binaryRatOperations_cubic _ _ _ hx hy).2.2.2


end Optss
