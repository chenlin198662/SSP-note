import Optss.LevIntervals

/-!
# Extending the interval and Lev's linear-length corollary

Once an interval spans every remaining summand, its two endpoint
translates overlap or touch. Thus adding each actual summand increases
the guaranteed interval length by its actual diameter.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

/-- The two endpoint translates fill the entire extended interval. -/
theorem interval_add_endpoints (S A : Finset ℤ) (a b l : ℤ)
    (hI : Finset.Icc a b ⊆ S) (hzero : 0 ∈ A) (hl : l ∈ A)
    (hspan : l ≤ b - a + 1) : Finset.Icc a (b + l) ⊆ S + A := by
  intro x hx
  obtain ⟨hxa, hxb⟩ := Finset.mem_Icc.mp hx
  by_cases h : x ≤ b
  · exact Finset.mem_add.mpr ⟨x, hI (Finset.mem_Icc.mpr ⟨hxa, h⟩), 0, hzero, by omega⟩
  · exact Finset.mem_add.mpr ⟨x - l, hI (Finset.mem_Icc.mpr ⟨by omega, by omega⟩), l, hl, by omega⟩

/-- Adding an actual list of sufficiently short normalized sets preserves
an interval and increases its length by the full sum of their diameters. -/
theorem interval_add_normalized_list (S : Finset ℤ) (a b : ℤ)
    (L : List (Finset ℤ × ℕ)) (hI : Finset.Icc a b ⊆ S)
    (hA : ∀ p ∈ L, 0 ∈ p.1 ∧ (p.2 : ℤ) ∈ p.1)
    (hwidth : ∀ p ∈ L, (p.2 : ℤ) ≤ b - a) :
    Finset.Icc a (b + (L.map (fun p => (p.2 : ℤ))).sum) ⊆ S + (L.map Prod.fst).sum := by
  induction L with
  | nil => simpa using hI
  | cons p L ih =>
    have hprev := ih (fun q hq => hA q (by simp [hq])) (fun q hq => hwidth q (by simp [hq]))
    have hz : 0 ≤ (L.map (fun p => (p.2 : ℤ))).sum :=
      List.sum_nonneg (by intro x hx; obtain ⟨q, hq, rfl⟩ := List.mem_map.mp hx; positivity)
    have hh := interval_add_endpoints (S + (L.map Prod.fst).sum) p.1 a
      (b + (L.map (fun p => (p.2 : ℤ))).sum) p.2 hprev
      (hA p (by simp)).1 (hA p (by simp)).2 (by have := hwidth p (by simp); omega)
    simpa [List.map_cons, List.sum_cons, add_assoc, add_left_comm, add_comm] using hh

private theorem lev_diameter_sum_lower (L : List (Finset ℤ × ℕ)) (n : ℕ)
    (hA : ∀ p ∈ L, LevNormalized p.1 p.2) (hcard : ∀ p ∈ L, n ≤ p.1.card) :
    (L.length : ℤ) * ((n : ℤ) - 1) ≤ (L.map (fun p => (p.2 : ℤ))).sum := by
  induction L with
  | nil => simp
  | cons p L ih =>
    have hdiam := (hA p (by simp)).card_le p.1 p.2
    have hn := hcard p (by simp)
    have hprev := ih (fun q hq => hA q (by simp [hq])) (fun q hq => hcard q (by simp [hq]))
    simp only [List.length_cons, List.map_cons, List.sum_cons, Nat.cast_add, Nat.cast_one]
    push_cast at hprev
    nlinarith

/-- The full linear-length interval corollary with a maximal-diameter
summand placed last. The next wrapper sorts an arbitrary input family. -/
theorem lev_interval_corollary_last (L : List (Finset ℤ × ℕ)) (p : Finset ℤ × ℕ)
    (n k : ℕ) (hn : 3 ≤ n) (hcount : 2 * k + 1 ≤ L.length)
    (hA : ∀ q ∈ L ++ [p], LevNormalized q.1 q.2)
    (hcard : ∀ q ∈ L ++ [p], n ≤ q.1.card)
    (hwidth : ∀ q ∈ L, q.2 ≤ p.2)
    (hW : (p.2 : ℤ) - 1 ≤ (k + 1 : ℕ) * ((n : ℤ) - 2)) :
    ∃ a b : ℤ, Finset.Icc a b ⊆ ((L ++ [p]).map Prod.fst).sum ∧
      ((L.length + 1 : ℕ) : ℤ) * ((n : ℤ) - 1) ≤ b - a := by
  let T := L.take (2 * k + 1)
  let R := L.drop (2 * k + 1)
  have hT : T.length = 2 * k + 1 := by simp [T, List.length_take, Nat.min_eq_left hcount]
  have hmT : ∀ q ∈ T, q ∈ L := fun q hq => List.mem_of_mem_take hq
  have hmR : ∀ q ∈ R, q ∈ L := fun q hq => List.mem_of_mem_drop hq
  have hnormp := hA p (by simp)
  have hcardp := hcard p (by simp)
  have hWp : n - 1 ≤ p.2 := by have := hnormp.card_le p.1 p.2; omega
  obtain ⟨a, b, hI, hlen, hlong⟩ := lev_list_long_interval T n k p.2 hn hT
    (fun q hq => hA q (List.mem_append_left _ (hmT q hq)))
    (fun q hq => hcard q (List.mem_append_left _ (hmT q hq)))
    (fun q hq => hwidth q (hmT q hq)) hWp hW
  have hnormR : ∀ q ∈ R, LevNormalized q.1 q.2 :=
    fun q hq => hA q (List.mem_append_left _ (hmR q hq))
  have hcardR : ∀ q ∈ R, n ≤ q.1.card :=
    fun q hq => hcard q (List.mem_append_left _ (hmR q hq))
  have hdiam := lev_diameter_sum_lower R n hnormR hcardR
  have hext := interval_add_normalized_list ((T.map Prod.fst).sum) a b (R ++ [p]) hI
    (fun q hq => by
      have hnorm := hA q (by
        rcases List.mem_append.mp hq with hq | hq
        · exact List.mem_append_left _ (hmR q hq)
        · exact List.mem_append_right _ hq)
      exact ⟨hnorm.2.1, hnorm.2.2.1⟩)
    (fun q hq => by
      rcases List.mem_append.mp hq with hq | hq
      · exact (by exact_mod_cast hwidth q (hmR q hq) : (q.2 : ℤ) ≤ p.2).trans hlong
      · have he : q = p := by simpa using hq
        subst q; exact hlong)
  refine ⟨a, b + ((R ++ [p]).map (fun q => (q.2 : ℤ))).sum, ?_, ?_⟩
  · have he : T ++ R = L := List.take_append_drop _ _
    simpa only [List.map_append, List.sum_append, ← add_assoc, ← List.sum_append,
      ← List.map_append, ← List.append_assoc, he] using hext
  · have hR : R.length = L.length - (2 * k + 1) := List.length_drop
    have hR' : (R.length : ℤ) + (2 * (k : ℤ) + 1) = L.length := by omega
    simp only [List.map_append, List.sum_append, List.map_singleton, List.sum_singleton]
    push_cast at hlen ⊢
    nlinarith

/-- Lev 2010 Corollary 1 in a division-free parameterization, with arbitrary
input order. It produces `length * (n - 1)` consecutive gaps. -/
theorem lev_interval_corollary (L : List (Finset ℤ × ℕ)) (n k : ℕ)
    (hn : 3 ≤ n) (hcount : 2 * (k + 1) ≤ L.length)
    (hA : ∀ p ∈ L, LevNormalized p.1 p.2)
    (hcard : ∀ p ∈ L, n ≤ p.1.card)
    (hwidth : ∀ p ∈ L, (p.2 : ℤ) - 1 ≤ (k + 1 : ℕ) * ((n : ℤ) - 2)) :
    ∃ a b : ℤ, Finset.Icc a b ⊆ (L.map Prod.fst).sum ∧
      (L.length : ℤ) * ((n : ℤ) - 1) ≤ b - a := by
  obtain ⟨A, l, hm, hl, hs, hd⟩ := lev_sorted_enumeration L
  let F := (List.range (L.length - 1)).map (fun i => (A i, l i))
  let p := (A (L.length - 1), l (L.length - 1))
  have hpos : 0 < L.length := by omega
  have hmF : ∀ q ∈ F ++ [p], q ∈ L := by
    intro q hq
    rcases List.mem_append.mp hq with hq | hq
    · obtain ⟨i, hi, rfl⟩ := List.mem_map.mp hq
      exact hm i (by have := List.mem_range.mp hi; omega)
    · have he : q = p := by simpa using hq
      subst q
      exact hm _ (by omega)
  have hlen : F.length = L.length - 1 := by simp [F]
  obtain ⟨a, b, hI, hlong⟩ := lev_interval_corollary_last F p n k hn (by rw [hlen]; omega)
    (fun q hq => hA q (hmF q hq)) (fun q hq => hcard q (hmF q hq))
    (fun q hq => by
      obtain ⟨i, hi, rfl⟩ := List.mem_map.mp hq
      have hi' := List.mem_range.mp hi
      exact hl (Finset.mem_range.mpr (by omega)) (Finset.mem_range.mpr (by omega)) (by omega))
    (hwidth p (hm _ (by omega)))
  refine ⟨a, b, ?_, ?_⟩
  · have he : (F ++ [p]).map Prod.fst = (List.range L.length).map A := by
      have hk : L.length = (L.length - 1) + 1 := by omega
      conv_rhs => rw [hk]
      simp [F, p, List.range_succ, List.map_map, Function.comp_def]
    rw [he, ← levPrefixSum, hs] at hI
    exact hI
  · simpa only [hlen, Nat.sub_add_cancel (by omega : 1 ≤ L.length)] using hlong

/-- An explicit natural-number version of the source's ceiling choice.
For `W ≥ 2`, `(W - 2)/(n - 2) + 1 = ceil((W - 1)/(n - 2))`.
All conclusions concern actual sumsets. -/
theorem lev_interval_corollary_width (L : List (Finset ℤ × ℕ)) (n W : ℕ)
    (hn : 3 ≤ n) (hW : 2 ≤ W)
    (hcount : 2 * ((W - 2) / (n - 2) + 1) ≤ L.length)
    (hA : ∀ p ∈ L, LevNormalized p.1 p.2)
    (hcard : ∀ p ∈ L, n ≤ p.1.card)
    (hwidth : ∀ p ∈ L, p.2 ≤ W) :
    ∃ a b : ℤ, Finset.Icc a b ⊆ (L.map Prod.fst).sum ∧
      (L.length : ℤ) * ((n : ℤ) - 1) ≤ b - a := by
  apply lev_interval_corollary L n ((W - 2) / (n - 2)) hn hcount hA hcard
  intro p hp
  have hb := Nat.lt_mul_div_succ (W - 2) (show 0 < n - 2 by omega)
  have hpn := hwidth p hp
  have hc : ((W - 2 : ℕ) : ℤ) < ((n - 2 : ℕ) : ℤ) * (((W - 2) / (n - 2) + 1 : ℕ) : ℤ) := by
    exact_mod_cast hb
  rw [Nat.cast_sub (by omega : 2 ≤ W), Nat.cast_sub (by omega : 2 ≤ n)] at hc
  push_cast at hc ⊢
  nlinarith

end
end Optss
