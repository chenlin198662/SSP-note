import Optss.ListStoredSweepWorkBounds

/-! Explicit polynomial majorants for the concrete storage stage factors. -/
namespace Optss

theorem listStoredRowFactor_le (r d : ℕ) :
    listStoredRowFactor r d ≤ 524288*(r+d+1)^8 := by
  let S := r+d+1
  have hS : 0<S := by dsimp [S]; omega
  have hr : r≤S := by dsimp [S]; omega
  have hd : d≤S := by dsimp [S]; omega
  have hdr : d+1≤S := by dsimp [S]; omega
  have hrd : r*d≤S^2 := by simpa [pow_two] using Nat.mul_le_mul hr hd
  have hp₁ : S≤S^2 := by simpa using (Nat.pow_le_pow_right hS (by decide : (1:ℕ)≤2))
  have hp₅ : S^5≤S^8 := Nat.pow_le_pow_right hS (by decide)
  have hp₆ : S^6≤S^8 := Nat.pow_le_pow_right hS (by decide)
  have hp₄ : S^4≤S^8 := Nat.pow_le_pow_right hS (by decide)
  have hp₀ : 1≤S^8 := one_le_pow₀ hS
  have he : 4*r*d+r+1≤6*S^2 := by nlinarith
  have h₁ : (4*r*d+r+1)*listStorageFactor r d ≤ 12288*S^8 := by
    calc
      _ ≤ (6*S^2)*(2048*S^4) := Nat.mul_le_mul_right _ he
      _ = 12288*S^6 := by ring
      _ ≤ _ := Nat.mul_le_mul_left _ hp₆
  have h₂ : 8192*S^5≤8192*S^8 := Nat.mul_le_mul_left _ hp₅
  have h₃ : (4*d+4)*listStorageFactor r d ≤ 8192*S^8 := by
    calc
      _ ≤ (4*S)*(2048*S^4) := Nat.mul_le_mul_right _ (by omega)
      _ = 8192*S^5 := by ring
      _ ≤ _ := Nat.mul_le_mul_left _ hp₅
  have h₄ : listStorageFactor r d ≤ 2048*S^8 := Nat.mul_le_mul_left _ hp₄
  change (4*r*d+r+1)*listStorageFactor r d+262144*S^8+
    8192*S^5+(4*d+4)*listStorageFactor r d+listStorageFactor r d+4 ≤ 524288*S^8
  omega

theorem listStoredAllFactor_le (r d : ℕ) :
    listStoredAllFactor r d ≤ 1048576*(r+d+1)^9 := by
  let S := r+d+1
  have hS : 0<S := by dsimp [S]; omega
  have hr : r+1≤S := by dsimp [S]; omega
  have hrow := listStoredRowFactor_le r d
  change listStoredRowFactor r d ≤ 524288*S^8 at hrow
  have h₁ : (r+1)*listStoredRowFactor r d ≤ 524288*S^9 := by
    calc
      _ ≤ S*(524288*S^8) := Nat.mul_le_mul hr hrow
      _ = _ := by ring
  have h₂ : listStorageFactor r d ≤ 2048*S^9 :=
    Nat.mul_le_mul_left _ (Nat.pow_le_pow_right hS (by decide : (4:ℕ)≤9))
  have h₃ : 1≤S^9 := one_le_pow₀ hS
  unfold listStoredAllFactor
  change _ ≤ 1048576*S^9
  omega

theorem listStoredFullSweepFactor_le (r d : ℕ) :
    (r+1)*listStoredAllFactor r d ≤ 1048576*(r+d+1)^10 := by
  calc
    _ ≤ (r+d+1)*(1048576*(r+d+1)^9) := Nat.mul_le_mul (by omega) (listStoredAllFactor_le r d)
    _ = _ := by ring

end Optss
