import Optss.GreedyGrowth
import Optss.Enumeration
import Mathlib.Data.List.MinMax
import Mathlib.Data.Finset.Sort
import Mathlib.Algebra.GeomSum
import Mathlib.Data.Real.Archimedean

/-!
# Actual greedy block construction

Remaining labels are distinct copies; equal vector values may have many labels.
Each step scans their translation increments, selects a maximum, removes that
label, and updates the exact support by union with its translate. Repeated
sumsets used to certify growth permit arbitrary repetitions and do not consume
copies. The finite growth bounds below make no running-time assertion.
-/
namespace Optss
open scoped BigOperators Pointwise

variable {ι G : Type*} [LinearOrder ι] [AddCommGroup G] [DecidableEq G]

/-- Exact subset sums using only the specified original labels. -/
def labelledSubsetSupport (v : ι → G) (P : Finset ι) : Finset G :=
  P.powerset.image (fun s => ∑ i ∈ s, v i)

omit [LinearOrder ι] in
@[simp] theorem mem_labelledSubsetSupport (v : ι → G) (P : Finset ι) (x : G) :
    x ∈ labelledSubsetSupport v P ↔ ∃ s ⊆ P, (∑ i ∈ s, v i) = x := by
  simp [labelledSubsetSupport]

omit [LinearOrder ι] in
@[simp] theorem zero_mem_labelledSubsetSupport (v : ι → G) (P : Finset ι) :
    0 ∈ labelledSubsetSupport v P := by
  exact (mem_labelledSubsetSupport v P 0).mpr ⟨∅, Finset.empty_subset _, by simp⟩

theorem labelledSubsetSupport_insert (v : ι → G) (P : Finset ι) {i : ι} (hi : i ∉ P) :
    labelledSubsetSupport v (insert i P) =
      labelledSubsetSupport v P ∪ (labelledSubsetSupport v P).image (fun x => x + v i) := by
  unfold labelledSubsetSupport
  rw [Finset.powerset_insert, Finset.image_union, Finset.image_image, Finset.image_image]
  congr 1
  apply Finset.image_congr
  intro s hs
  have his : i ∉ s := fun h => hi (Finset.mem_powerset.mp hs h)
  simp only [Function.comp_apply, Finset.sum_insert his]
  exact add_comm _ _

/-- The actual maximum-increment choice; ties use the order of the labels. -/
def greedyLabel (v : ι → G) (S : Finset G) (R : Finset ι) : Option ι :=
  (R.sort (· ≤ ·)).argmax (fun i => translationIncrement S (v i))

theorem greedyLabel_spec (v : ι → G) (S : Finset G) (R : Finset ι) {i : ι}
    (hi : greedyLabel v S R = some i) :
    i ∈ R ∧ ∀ j ∈ R, translationIncrement S (v j) ≤ translationIncrement S (v i) := by
  have hs := List.argmax_eq_some_iff.mp hi
  exact ⟨by simpa using hs.1, fun j hj => hs.2.1 j (by simpa using hj)⟩

@[simp] theorem greedyLabel_eq_none (v : ι → G) (S : Finset G) (R : Finset ι) :
    greedyLabel v S R = none ↔ R = ∅ := by
  simp only [greedyLabel, List.argmax_eq_none, ← List.length_eq_zero_iff,
    Finset.length_sort, Finset.card_eq_zero]

theorem greedyLabel_exists (v : ι → G) (S : Finset G) (R : Finset ι) (hR : R.Nonempty) :
    ∃ i, greedyLabel v S R = some i := by
  cases h : greedyLabel v S R with
  | none => exact False.elim (hR.ne_empty ((greedyLabel_eq_none v S R).mp h))
  | some i => exact ⟨i, rfl⟩

/-- The stored state distinguishes used labels from available copies. -/
structure GreedyBlockState (ι G : Type*) where
  chosen : Finset ι
  remaining : Finset ι
  sums : Finset G

/-- A state stores precisely the subset sums of its selected labels. -/
def GreedyBlockState.Valid (v : ι → G) (st : GreedyBlockState ι G) : Prop :=
  Disjoint st.chosen st.remaining ∧ st.sums = labelledSubsetSupport v st.chosen

/-- Initialize the greedy phase after selecting a prescribed seed. -/
def greedyBlockSeed (v : ι → G) (all seed : Finset ι) : GreedyBlockState ι G :=
  ⟨seed, all \ seed, labelledSubsetSupport v seed⟩

theorem greedyBlockSeed_valid (v : ι → G) (all seed : Finset ι) :
    (greedyBlockSeed v all seed).Valid v := ⟨Finset.disjoint_sdiff, rfl⟩

/-- One actual greedy update, doing nothing only when no label remains. -/
def greedyBlockStep (v : ι → G) (st : GreedyBlockState ι G) : GreedyBlockState ι G :=
  match greedyLabel v st.sums st.remaining with
  | none => st
  | some i => ⟨insert i st.chosen, st.remaining.erase i,
      st.sums ∪ st.sums.image (fun x => x + v i)⟩

theorem greedyBlockStep_of_some (v : ι → G) (st : GreedyBlockState ι G) {i : ι}
    (hi : greedyLabel v st.sums st.remaining = some i) :
    greedyBlockStep v st = ⟨insert i st.chosen, st.remaining.erase i,
      st.sums ∪ st.sums.image (fun x => x + v i)⟩ := by simp [greedyBlockStep, hi]

theorem greedyBlockStep_valid (v : ι → G) (st : GreedyBlockState ι G) (hst : st.Valid v) :
    (greedyBlockStep v st).Valid v := by
  cases hi : greedyLabel v st.sums st.remaining with
  | none => simpa [greedyBlockStep, hi] using hst
  | some i =>
    have himem := (greedyLabel_spec v st.sums st.remaining hi).1
    have hinot : i ∉ st.chosen := fun h => Finset.disjoint_left.mp hst.1 h himem
    rw [greedyBlockStep_of_some v st hi]
    constructor
    · exact Finset.disjoint_insert_left.mpr ⟨Finset.not_mem_erase _ _,
        hst.1.mono_right (Finset.erase_subset _ _)⟩
    · change st.sums ∪ st.sums.image (fun x => x + v i) = _
      rw [labelledSubsetSupport_insert v st.chosen hinot, ← hst.2]

theorem greedyBlockStep_support_mono (v : ι → G) (st : GreedyBlockState ι G) :
    st.sums ⊆ (greedyBlockStep v st).sums := by
  cases hi : greedyLabel v st.sums st.remaining with
  | none => simp [greedyBlockStep, hi]
  | some i => simp [greedyBlockStep, hi]

theorem greedyBlockStep_partition (v : ι → G) (st : GreedyBlockState ι G) :
    (greedyBlockStep v st).chosen ∪ (greedyBlockStep v st).remaining = st.chosen ∪ st.remaining := by
  cases hi : greedyLabel v st.sums st.remaining with
  | none => simp [greedyBlockStep, hi]
  | some i =>
    have himem := (greedyLabel_spec v st.sums st.remaining hi).1
    simp only [greedyBlockStep, hi]
    ext j
    simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_erase]
    by_cases hji : j = i
    · subst j
      simp [himem]
    · simp [hji, Ne.symm hji]

theorem greedyBlockStep_remaining_card (v : ι → G) (st : GreedyBlockState ι G) :
    (greedyBlockStep v st).remaining.card = st.remaining.card - 1 := by
  cases hi : greedyLabel v st.sums st.remaining with
  | none =>
    have hR := (greedyLabel_eq_none v st.sums st.remaining).mp hi
    rw [greedyBlockStep, hi]
    simp [hR]
  | some i =>
    simp only [greedyBlockStep, hi]
    exact Finset.card_erase_of_mem (greedyLabel_spec v st.sums st.remaining hi).1

/-- A finite number of actual maximum-increment updates. -/
def greedyBlockRun (v : ι → G) : ℕ → GreedyBlockState ι G → GreedyBlockState ι G
  | 0, st => st
  | n+1, st => greedyBlockStep v (greedyBlockRun v n st)

theorem greedyBlockRun_valid (v : ι → G) (st : GreedyBlockState ι G)
    (hst : st.Valid v) (n : ℕ) : (greedyBlockRun v n st).Valid v := by
  induction n with
  | zero => exact hst
  | succ n ih => exact greedyBlockStep_valid v _ ih

theorem greedyBlockRun_support_mono (v : ι → G) (st : GreedyBlockState ι G) :
    Monotone (fun n => (greedyBlockRun v n st).sums) := by
  apply monotone_nat_of_le_succ
  intro n
  exact greedyBlockStep_support_mono v _

theorem greedyBlockRun_partition (v : ι → G) (st : GreedyBlockState ι G) (n : ℕ) :
    (greedyBlockRun v n st).chosen ∪ (greedyBlockRun v n st).remaining =
      st.chosen ∪ st.remaining := by
  induction n with
  | zero => rfl
  | succ n ih => exact (greedyBlockStep_partition v _).trans ih

theorem greedyBlockRun_remaining_card (v : ι → G) (st : GreedyBlockState ι G) (n : ℕ) :
    (greedyBlockRun v n st).remaining.card = st.remaining.card - n := by
  induction n with
  | zero => simp [greedyBlockRun]
  | succ n ih => rw [greedyBlockRun, greedyBlockStep_remaining_card, ih, Nat.sub_sub]

theorem greedyBlockRun_chosen_card (v : ι → G) (st : GreedyBlockState ι G)
    (hst : st.Valid v) (n : ℕ) :
    (greedyBlockRun v n st).chosen.card = st.chosen.card + min n st.remaining.card := by
  have hv := greedyBlockRun_valid v st hst n
  have hc := congrArg Finset.card (greedyBlockRun_partition v st n)
  rw [Finset.card_union_of_disjoint hv.1, Finset.card_union_of_disjoint hst.1,
    greedyBlockRun_remaining_card] at hc
  omega

/-- Live values include zero for repeated-sumset certificates. Repetitions in
`q • liveValues` do not allocate any extra labels. -/
def greedyLiveValues (v : ι → G) (st : GreedyBlockState ι G) : Finset G :=
  insert 0 (st.remaining.image v)

/-- Cardinality changes by exactly the translation increment of the chosen label. -/
theorem greedyBlockStep_card_of_some (v : ι → G) (st : GreedyBlockState ι G) {i : ι}
    (hi : greedyLabel v st.sums st.remaining = some i) :
    (greedyBlockStep v st).sums.card = st.sums.card + translationIncrement st.sums (v i) := by
  rw [greedyBlockStep_of_some v st hi]
  have h := Finset.card_sdiff_add_card (st.sums.image (fun x => x + v i)) st.sums
  simpa only [translationIncrement, Finset.union_comm, Nat.add_comm] using h.symm

/-- Lemma 2.E supplies the actual selected maximum's growth, from repeated
sumset data of the current remaining values rather than a growth premise. -/
theorem greedyBlockStep_growth (v : ι → G) (st : GreedyBlockState ι G)
    (hS : st.sums.Nonempty) (q : ℕ) (hq : 1 ≤ q)
    (hgrowth : 2 * st.sums.card ≤ (q • greedyLiveValues v st).card) :
    2 * q * st.sums.card + st.sums.card ≤ 2 * q * (greedyBlockStep v st).sums.card := by
  obtain ⟨u, hu, hg⟩ := greedy_growth st.sums (greedyLiveValues v st) hS
    (Finset.insert_nonempty _ _) q hq hgrowth
  have hincrement : ((st.sums + {u}) \ st.sums).card = translationIncrement st.sums u := by
    unfold translationIncrement
    congr 1
    ext x
    simp only [Finset.mem_sdiff, Finset.mem_add, Finset.mem_singleton, Finset.mem_image]
    aesop
  rw [hincrement] at hg
  have hu0 : u ≠ 0 := by
    intro hzero
    subst u
    simp only [translationIncrement_zero, Nat.mul_zero] at hg
    have := Finset.card_pos.mpr hS
    omega
  obtain ⟨j, hj, rfl⟩ := Finset.mem_image.mp ((Finset.mem_insert.mp hu).resolve_left hu0)
  obtain ⟨i, hi⟩ := greedyLabel_exists v st.sums st.remaining ⟨j, hj⟩
  have hmax := (greedyLabel_spec v st.sums st.remaining hi).2 j hj
  rw [greedyBlockStep_card_of_some v st hi]
  nlinarith

/-- A doubling interval takes at most `2q` selected labels. The certificate is
needed only at current states before the support reaches the doubled size. -/
theorem greedyBlockRun_doubles (v : ι → G) (st : GreedyBlockState ι G)
    (hS : st.sums.Nonempty) (q : ℕ) (hq : 1 ≤ q)
    (hcert : ∀ n < 2 * q,
      (greedyBlockRun v n st).sums.card < 2 * st.sums.card →
      2 * (greedyBlockRun v n st).sums.card ≤
        (q • greedyLiveValues v (greedyBlockRun v n st)).card) :
    2 * st.sums.card ≤ (greedyBlockRun v (2 * q) st).sums.card := by
  have hmono := greedyBlockRun_support_mono v st
  have hprogress : ∀ n ≤ 2 * q,
      2 * st.sums.card ≤ (greedyBlockRun v n st).sums.card ∨
      (2 * q + n) * st.sums.card ≤ 2 * q * (greedyBlockRun v n st).sums.card := by
    intro n
    induction n with
    | zero => intro _; right; simp [greedyBlockRun]
    | succ n ih =>
      intro hn
      have hstepmono := Finset.card_le_card (hmono (Nat.le_succ n))
      rcases ih (by omega) with hdone | hprogress
      · exact Or.inl (hdone.trans hstepmono)
      · by_cases hdone : 2 * st.sums.card ≤ (greedyBlockRun v n st).sums.card
        · exact Or.inl (hdone.trans hstepmono)
        · right
          have hbase : st.sums.card ≤ (greedyBlockRun v n st).sums.card :=
            Finset.card_le_card (hmono (Nat.zero_le n))
          have hnonempty : (greedyBlockRun v n st).sums.Nonempty :=
            hS.mono (hmono (Nat.zero_le n))
          have hstep := greedyBlockStep_growth v (greedyBlockRun v n st) hnonempty q hq
            (hcert n (by omega) (by omega))
          change 2 * q * (greedyBlockRun v n st).sums.card +
            (greedyBlockRun v n st).sums.card ≤
            2 * q * (greedyBlockRun v (n+1) st).sums.card at hstep
          nlinarith
  rcases hprogress (2 * q) le_rfl with hdone | hprogress
  · exact hdone
  · apply Nat.le_of_mul_le_mul_left (c := 2 * q) _ (by omega)
    nlinarith

/-- Actual stopping loop: no further label is removed once the target is met. -/
def greedyBlockUntil (v : ι → G) (target : ℕ) : ℕ → GreedyBlockState ι G → GreedyBlockState ι G
  | 0, st => st
  | n+1, st => if target ≤ st.sums.card then st
      else greedyBlockUntil v target n (greedyBlockStep v st)

theorem greedyBlockRun_step (v : ι → G) (st : GreedyBlockState ι G) (n : ℕ) :
    greedyBlockRun v n (greedyBlockStep v st) = greedyBlockRun v (n+1) st := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [greedyBlockRun, ih]

/-- The stopped algorithm executes a genuine prefix of the maximum-increment
run, and either meets its target or uses all supplied fuel. -/
theorem greedyBlockUntil_eq_run (v : ι → G) (target n : ℕ) (st : GreedyBlockState ι G) :
    ∃ k ≤ n, greedyBlockUntil v target n st = greedyBlockRun v k st ∧
      (target ≤ (greedyBlockUntil v target n st).sums.card ∨ k = n) := by
  induction n generalizing st with
  | zero => exact ⟨0, le_rfl, rfl, Or.inr rfl⟩
  | succ n ih =>
    by_cases hdone : target ≤ st.sums.card
    · exact ⟨0, Nat.zero_le _, by simp [greedyBlockUntil, hdone, greedyBlockRun],
        Or.inl (by simp [greedyBlockUntil, hdone])⟩
    · obtain ⟨k, hk, he, hstop⟩ := ih (greedyBlockStep v st)
      refine ⟨k+1, by omega, ?_, ?_⟩
      · rw [greedyBlockUntil, if_neg hdone, he, greedyBlockRun_step]
      · simpa only [greedyBlockUntil, if_neg hdone, Nat.add_right_cancel_iff] using hstop

/-- The actual stopping loop doubles support within `2q` available-copy
selections, with all support and no-reuse invariants preserved. -/
theorem greedyBlockUntil_doubles (v : ι → G) (st : GreedyBlockState ι G)
    (hst : st.Valid v) (q : ℕ) (hq : 1 ≤ q)
    (hcert : ∀ n < 2 * q,
      (greedyBlockRun v n st).sums.card < 2 * st.sums.card →
      2 * (greedyBlockRun v n st).sums.card ≤
        (q • greedyLiveValues v (greedyBlockRun v n st)).card) :
    let out := greedyBlockUntil v (2 * st.sums.card) (2 * q) st
    out.Valid v ∧ 2 * st.sums.card ≤ out.sums.card ∧
    out.chosen.card ≤ st.chosen.card + 2 * q ∧
    out.chosen ∪ out.remaining = st.chosen ∪ st.remaining := by
  dsimp only
  obtain ⟨k, hk, he, hstop⟩ := greedyBlockUntil_eq_run v (2 * st.sums.card) (2 * q) st
  have hs : st.sums.Nonempty := by
    rw [hst.2]
    exact ⟨0, zero_mem_labelledSubsetSupport v st.chosen⟩
  refine ⟨he.symm ▸ greedyBlockRun_valid v st hst k, ?_, ?_, ?_⟩
  · rcases hstop with hdone | rfl
    · exact hdone
    · rw [he]
      exact greedyBlockRun_doubles v st hs q hq hcert
  · rw [he, greedyBlockRun_chosen_card v st hst k]
    omega
  · rw [he]
    exact greedyBlockRun_partition v st k

/-- The returned support is exact, rather than merely a sound subset of the
selected labels' support. Every output uses distinct selected original labels. -/
theorem greedyBlockUntil_exact_support (v : ι → G) (target n : ℕ)
    (st : GreedyBlockState ι G) (hst : st.Valid v) (x : G) :
    x ∈ (greedyBlockUntil v target n st).sums ↔
      ∃ s ⊆ (greedyBlockUntil v target n st).chosen, (∑ i ∈ s, v i) = x := by
  obtain ⟨k, _, he, _⟩ := greedyBlockUntil_eq_run v target n st
  rw [he, (greedyBlockRun_valid v st hst k).2, mem_labelledSubsetSupport]

/-- Compose actual doubling phases with explicitly supplied scale parameters. -/
def greedyDoublingSchedule (v : ι → G) : List ℕ → GreedyBlockState ι G → GreedyBlockState ι G
  | [], st => st
  | q :: qs, st => greedyDoublingSchedule v qs
      (greedyBlockUntil v (2 * st.sums.card) (2 * q) st)

/-- Certificates concern only repeated sumsets of the actual live values in
states visited by this schedule. They do not assume the desired growth step. -/
def GreedyScheduleCertificate (v : ι → G) : List ℕ → GreedyBlockState ι G → Prop
  | [], _ => True
  | q :: qs, st => 1 ≤ q ∧
      (∀ n < 2 * q, (greedyBlockRun v n st).sums.card < 2 * st.sums.card →
        2 * (greedyBlockRun v n st).sums.card ≤
          (q • greedyLiveValues v (greedyBlockRun v n st)).card) ∧
      GreedyScheduleCertificate v qs (greedyBlockUntil v (2 * st.sums.card) (2 * q) st)

/-- Finite multi-scale growth and its exact sum-of-scales selection bound. -/
theorem greedyDoublingSchedule_correct (v : ι → G) (qs : List ℕ)
    (st : GreedyBlockState ι G) (hst : st.Valid v) (hcert : GreedyScheduleCertificate v qs st) :
    let out := greedyDoublingSchedule v qs st
    out.Valid v ∧ 2 ^ qs.length * st.sums.card ≤ out.sums.card ∧
    out.chosen.card ≤ st.chosen.card + 2 * qs.sum ∧
    out.chosen ∪ out.remaining = st.chosen ∪ st.remaining := by
  induction qs generalizing st with
  | nil => simpa [greedyDoublingSchedule] using hst
  | cons q qs ih =>
    obtain ⟨hq, hgrowth, htail⟩ := hcert
    obtain ⟨hv, hg, hc, hp⟩ := greedyBlockUntil_doubles v st hst q hq hgrowth
    obtain ⟨hv', hg', hc', hp'⟩ := ih _ hv htail
    refine ⟨hv', ?_, ?_, hp'.trans hp⟩
    · have hmul := Nat.mul_le_mul_left (2 ^ qs.length) hg
      change 2 ^ (qs.length + 1) * st.sums.card ≤
        (greedyDoublingSchedule v qs (greedyBlockUntil v (2 * st.sums.card) (2 * q) st)).sums.card
      rw [pow_succ]
      nlinarith
    · change (greedyDoublingSchedule v qs
        (greedyBlockUntil v (2 * st.sums.card) (2 * q) st)).chosen.card ≤
        st.chosen.card + 2 * (q + qs.sum)
      omega

theorem greedyBlockSeed_partition (v : ι → G) (all seed : Finset ι) (hs : seed ⊆ all) :
    (greedyBlockSeed v all seed).chosen ∪ (greedyBlockSeed v all seed).remaining = all := by
  exact Finset.union_sdiff_of_subset hs

/-- All selected copies in a completed seed-and-growth schedule come from the
original input. The remainder is disjoint and accounts for every unused label. -/
theorem greedyDoublingSchedule_seed_labels (v : ι → G) (all seed : Finset ι)
    (hs : seed ⊆ all) (qs : List ℕ)
    (hcert : GreedyScheduleCertificate v qs (greedyBlockSeed v all seed)) :
    let out := greedyDoublingSchedule v qs (greedyBlockSeed v all seed)
    out.chosen ⊆ all ∧ out.remaining ⊆ all ∧ Disjoint out.chosen out.remaining ∧
    out.sums = labelledSubsetSupport v out.chosen ∧
    out.chosen.card ≤ seed.card + 2 * qs.sum := by
  obtain ⟨hv, _, hc, hp⟩ := greedyDoublingSchedule_correct v qs _
    (greedyBlockSeed_valid v all seed) hcert
  rw [greedyBlockSeed_partition v all seed hs] at hp
  exact ⟨fun i hi => hp ▸ Finset.mem_union_left _ hi,
    fun i hi => hp ▸ Finset.mem_union_right _ hi, hv.1, hv.2, hc⟩

/-- Explicit rounded geometric scale quotas, ordered from small to large. -/
noncomputable def greedyGeometricQuota (Q r : ℝ) (m : ℕ) (j : Fin m) : ℕ :=
  max 1 ⌈Q * r ^ (m - 1 - j.val)⌉₊

theorem greedyGeometricQuota_pos (Q r : ℝ) (m : ℕ) (j : Fin m) :
    1 ≤ greedyGeometricQuota Q r m j := le_max_left _ _

/-- The rounding cost is at most one per scale. -/
theorem greedyGeometricQuota_le (Q r : ℝ) (hQ : 0 ≤ Q) (hr : 0 ≤ r)
    (m : ℕ) (j : Fin m) :
    (greedyGeometricQuota Q r m j : ℝ) ≤ Q * r ^ (m - 1 - j.val) + 1 := by
  unfold greedyGeometricQuota
  rw [Nat.cast_max, Nat.cast_one]
  have hx : 0 ≤ Q * r ^ (m - 1 - j.val) := mul_nonneg hQ (pow_nonneg hr _)
  exact max_le (by linarith) (Nat.ceil_lt_add_one hx).le

/-- Finite geometric accounting for all rounded doubling scales. -/
theorem greedyGeometricQuota_sum_le (Q r : ℝ) (hQ : 0 ≤ Q) (hr : 0 ≤ r)
    (hr1 : r < 1) (m : ℕ) :
    ((List.ofFn (greedyGeometricQuota Q r m)).sum : ℝ) ≤ Q / (1 - r) + m := by
  have hgeom : (∑ j : Fin m, r ^ (m - 1 - j.val)) ≤ 1 / (1 - r) := by
    rw [Fin.sum_univ_eq_sum_range (fun j => r ^ (m - 1 - j)) m,
      Finset.sum_range_reflect]
    simpa only [Nat.Ico_zero_eq_range, pow_zero] using
      (geom_sum_Ico_le_of_lt_one hr hr1 (m := 0) (n := m))
  calc
    ((List.ofFn (greedyGeometricQuota Q r m)).sum : ℝ) =
        ∑ j : Fin m, (greedyGeometricQuota Q r m j : ℝ) := by
      rw [List.sum_ofFn, Nat.cast_sum]
    _ ≤ ∑ j : Fin m, (Q * r ^ (m - 1 - j.val) + 1) :=
      Finset.sum_le_sum (fun j _ => greedyGeometricQuota_le Q r hQ hr m j)
    _ = Q * (∑ j : Fin m, r ^ (m - 1 - j.val)) + m := by
      rw [Finset.sum_add_distrib, ← Finset.mul_sum]
      simp
    _ ≤ Q / (1 - r) + m := by
      simpa only [mul_one_div] using
        add_le_add_right (mul_le_mul_of_nonneg_left hgeom hQ) (m : ℝ)

/-- A certified geometric schedule uses at most the geometric sum of its
actual per-phase selection budgets, including every ceiling error. -/
theorem greedyGeometricSchedule_selection_bound (v : ι → G)
    (Q r : ℝ) (hQ : 0 ≤ Q) (hr : 0 ≤ r) (hr1 : r < 1) (m : ℕ)
    (st : GreedyBlockState ι G) (hst : st.Valid v)
    (hcert : GreedyScheduleCertificate v (List.ofFn (greedyGeometricQuota Q r m)) st) :
    ((greedyDoublingSchedule v (List.ofFn (greedyGeometricQuota Q r m)) st).chosen.card : ℝ) ≤
      st.chosen.card + 2 * (Q / (1 - r) + m) := by
  have h := (greedyDoublingSchedule_correct v _ st hst hcert).2.2.1
  have hR : ((greedyDoublingSchedule v (List.ofFn (greedyGeometricQuota Q r m)) st).chosen.card : ℝ) ≤
      st.chosen.card + 2 * ((List.ofFn (greedyGeometricQuota Q r m)).sum : ℝ) := by
    exact_mod_cast h
  have hs := greedyGeometricQuota_sum_le Q r hQ hr hr1 m
  linarith

end Optss
