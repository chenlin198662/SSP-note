import Optss.BooleanVertexNormalization
import Optss.ListStoredMatrixTranspose
import Optss.ListStoredRationalWork

/-!
# A concrete normalization and lattice-reduction frontend

Input vertices and a full rational lattice basis are stored as columns.
The selected vertex matrix is inverted with the Boolean cofactor evaluator.
The same inverse normalizes both the vertices and the entire input lattice.
A physical transpose supplies the row convention of the actual list-stored
LLL routine. All decoding functions below are proof views, not answer steps.
-/
namespace Optss
open scoped BigOperators
variable {r m : ℕ}

def storedRationalMatrix {a b : ℕ} (A : ListBitRationalMatrixData a b) : Matrix (Fin a) (Fin b) ℚ :=
  (rectangularListFractionMatrix A).map bitListFractionValue

theorem storedRationalMatrix_eq_rows {a b : ℕ} (A : ListBitRationalMatrixData a b) :
    storedRationalMatrix A=encodedFractionRows (ioMatrixVector A) := rfl

theorem storedRationalMatrix_mul {a b c : ℕ}
    (A : ListBitRationalMatrixData a b) (B : ListBitRationalMatrixData b c)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hB : ∀ i j,(rectangularListFractionMatrix B i j).WellFormed) :
    storedRationalMatrix (constructedListMatrixMul A B)=storedRationalMatrix A*storedRationalMatrix B := by
  ext i j
  exact constructedListMatrixMul_value A B hA hB i j

theorem storedRationalMatrix_transpose {a b : ℕ} (A : ListBitRationalMatrixData a b) :
    storedRationalMatrix (listStoredMatrixTranspose A)=(storedRationalMatrix A).transpose := by
  ext i j
  exact congrArg bitListFractionValue (listStoredMatrixTranspose_entry A i j)

theorem storedRationalMatrix_inverse (A : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed) :
    storedRationalMatrix (constructedListMatrixInverse A)=(storedRationalMatrix A)⁻¹ := by
  rw [storedRationalMatrix,constructedListMatrixInverse_value_matrix A hA,rationalCofactorInverse_eq]
  rfl

theorem storedRationalRows_independent (A : ListBitRationalMatrixData r r)
    (hA : (storedRationalMatrix A).det≠0) :
    LinearIndependent ℝ (fun i j => (encodedFractionRows (ioMatrixVector A) i j : ℝ)) := by
  have hr : ((storedRationalMatrix A).map (Rat.castHom ℝ)).det≠0 := by
    change ((storedRationalMatrix A).map (fun q : ℚ => (q:ℝ))).det≠0
    rw [←Rat.cast_det]
    exact_mod_cast hA
  exact Matrix.linearIndependent_rows_of_det_ne_zero hr

structure BooleanLatticeFrontendResult (r m : ℕ) where
  selectedColumns : ListBitRationalMatrixData r r
  coordinateMatrix : ListBitRationalMatrixData r r
  normalizedVertices : ListBitRationalMatrixData r m
  normalizedLatticeColumns : ListBitRationalMatrixData r r
  reducedLatticeRows : ListBitRationalMatrixData r r
  swapTicks : List Bool

def booleanLatticeFrontendFromBasis (A : ListBitRationalMatrixData r r)
    (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r) : BooleanLatticeFrontendResult r m :=
  let C := constructedListMatrixInverse A
  let W := constructedListMatrixMul C V
  let M := constructedListMatrixMul C G
  let T := listStoredMatrixTranspose M
  let reduced := listStoredRationalReduction T
  ⟨A,C,W,M,reduced.1,reduced.2⟩

def booleanLatticeFrontend (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r) :
    Option (BooleanLatticeFrontendResult r m) :=
  (bitSelectedVertexMatrix V).map fun A => booleanLatticeFrontendFromBasis A V G

def booleanLatticeFrontendFromBasisWork (A : ListBitRationalMatrixData r r)
    (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r) : ℕ :=
  let C := constructedListMatrixInverse A
  let M := constructedListMatrixMul C G
  let T := listStoredMatrixTranspose M
  constructedListMatrixInverseWork A+constructedListMatrixMulWork C V+
    constructedListMatrixMulWork C G+listStoredMatrixTransposeWork M+
    listStoredRationalTotalWork T+6

def booleanLatticeFrontendWork (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r) : ℕ :=
  bitSelectedVertexMatrixWork V+(match bitSelectedVertexMatrix V with
    | none => 1
    | some A => booleanLatticeFrontendFromBasisWork A V G+1)

theorem frontend_normalized_lattice_det
    (A G : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetA : (storedRationalMatrix A).det≠0) (hdetG : (storedRationalMatrix G).det≠0) :
    (storedRationalMatrix (listStoredMatrixTranspose
      (constructedListMatrixMul (constructedListMatrixInverse A) G))).det≠0 := by
  rw [storedRationalMatrix_transpose,Matrix.det_transpose,
    storedRationalMatrix_mul _ G (constructedListMatrixInverse_wellFormed A hA) hG,
    storedRationalMatrix_inverse A hA,Matrix.det_mul,Matrix.det_nonsing_inv,Ring.inverse_eq_inv]
  exact mul_ne_zero (inv_ne_zero hdetA) hdetG

/-- Exact coordinates of both normalized inputs; the same inverse is used. -/
theorem booleanLatticeFrontendFromBasis_coordinates
    (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed) :
    let out := booleanLatticeFrontendFromBasis A V G
    storedRationalMatrix out.coordinateMatrix=(storedRationalMatrix A)⁻¹ ∧
      storedRationalMatrix out.normalizedVertices=(storedRationalMatrix A)⁻¹*storedRationalMatrix V ∧
      storedRationalMatrix out.normalizedLatticeColumns=(storedRationalMatrix A)⁻¹*storedRationalMatrix G := by
  dsimp only [booleanLatticeFrontendFromBasis]
  rw [storedRationalMatrix_mul _ V (constructedListMatrixInverse_wellFormed A hA) hV,
    storedRationalMatrix_mul _ G (constructedListMatrixInverse_wellFormed A hA) hG,
    storedRationalMatrix_inverse A hA]
  exact ⟨rfl,rfl,rfl⟩

/-- The reduced output spans the complete normalized lattice, with the sharp
orthogonality-defect guarantee of the paper's LLL input theorem. -/
theorem booleanLatticeFrontendFromBasis_reduction
    (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetA : (storedRationalMatrix A).det≠0) (hdetG : (storedRationalMatrix G).det≠0) :
    let out := booleanLatticeFrontendFromBasis A V G
    Submodule.span ℤ (Set.range (storedRationalMatrix out.reducedLatticeRows))=
      Submodule.span ℤ (Set.range (((storedRationalMatrix A)⁻¹*storedRationalMatrix G).transpose)) ∧
    ∃ b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)),
      (∀ i,b i=rationalEuclideanRows (storedRationalMatrix out.reducedLatticeRows) i) ∧
      euclideanOrthogonalityDefect b≤sharpLatticeDefectBound r := by
  let C := constructedListMatrixInverse A
  let M := constructedListMatrixMul C G
  let T := listStoredMatrixTranspose M
  have hC := constructedListMatrixInverse_wellFormed A hA
  have hM := constructedListMatrixMul_wellFormed C G hC hG
  have hT := listStoredMatrixTranspose_wellFormed M hM
  have hi := storedRationalRows_independent T (frontend_normalized_lattice_det A G hA hG hdetA hdetG)
  have h := listStoredRationalReduction_spec T hT hi
  change Submodule.span ℤ (Set.range (storedRationalMatrix (listStoredRationalReduction T).1))=
    Submodule.span ℤ (Set.range (storedRationalMatrix T)) ∧ _ at h
  have hTm : storedRationalMatrix T=((storedRationalMatrix A)⁻¹*storedRationalMatrix G).transpose := by
    rw [storedRationalMatrix_transpose,storedRationalMatrix_mul C G hC hG,storedRationalMatrix_inverse A hA]
  rw [hTm] at h
  exact h

theorem booleanLatticeFrontendFromBasis_wellFormed
    (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetA : (storedRationalMatrix A).det≠0) (hdetG : (storedRationalMatrix G).det≠0) :
    let out := booleanLatticeFrontendFromBasis A V G
    (∀ i j,(rectangularListFractionMatrix out.coordinateMatrix i j).WellFormed) ∧
    (∀ i j,(rectangularListFractionMatrix out.normalizedVertices i j).WellFormed) ∧
    (∀ i j,(rectangularListFractionMatrix out.normalizedLatticeColumns i j).WellFormed) ∧
    (∀ i j,(rectangularListFractionMatrix out.reducedLatticeRows i j).WellFormed) := by
  let C := constructedListMatrixInverse A
  let M := constructedListMatrixMul C G
  let T := listStoredMatrixTranspose M
  have hC := constructedListMatrixInverse_wellFormed A hA
  have hM := constructedListMatrixMul_wellFormed C G hC hG
  have hT := listStoredMatrixTranspose_wellFormed M hM
  have hi := storedRationalRows_independent T (frontend_normalized_lattice_det A G hA hG hdetA hdetG)
  exact ⟨hC,constructedListMatrixMul_wellFormed C V hC hV,hM,
    listStoredRationalReduction_wellFormed T hT hi⟩
end Optss
