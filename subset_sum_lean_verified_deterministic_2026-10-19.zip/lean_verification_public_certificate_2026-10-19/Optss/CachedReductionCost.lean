import Optss.CachedRationalReduction

/-!
# Compositional arithmetic counters for cached lattice reduction

Arithmetic implementations return their value and a charge. All values are
proved to agree with the cached evaluator. The unit-charge implementation
counts scalar rational operations; it does not identify one rational operation
with one machine step. This interface also admits separately verified binary
arithmetic implementations with operand-dependent charges.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

/-- A rational arithmetic implementation with exact values and explicit work
charges. Charges may depend on the actual operands. -/
structure RationalArithmetic where
  add : ℚ → ℚ → ℚ × ℕ
  sub : ℚ → ℚ → ℚ × ℕ
  mul : ℚ → ℚ → ℚ × ℕ
  div : ℚ → ℚ → ℚ × ℕ
  add_value : ∀ x y, (add x y).1 = x+y
  sub_value : ∀ x y, (sub x y).1 = x-y
  mul_value : ∀ x y, (mul x y).1 = x*y
  div_value : ∀ x y, (div x y).1 = x/y

/-- Scalar-operation counter. Binary arithmetic can be substituted by
supplying its exact value laws and its actual work charges. -/
def unitRationalArithmetic : RationalArithmetic where
  add x y := (x+y, 1)
  sub x y := (x-y, 1)
  mul x y := (x*y, 1)
  div x y := (x/y, 1)
  add_value _ _ := rfl
  sub_value _ _ := rfl
  mul_value _ _ := rfl
  div_value _ _ := rfl

@[simp] theorem unit_add_work (x y : ℚ) : (unitRationalArithmetic.add x y).2 = 1 := rfl
@[simp] theorem unit_sub_work (x y : ℚ) : (unitRationalArithmetic.sub x y).2 = 1 := rfl
@[simp] theorem unit_mul_work (x y : ℚ) : (unitRationalArithmetic.mul x y).2 = 1 := rfl
@[simp] theorem unit_div_work (x y : ℚ) : (unitRationalArithmetic.div x y).2 = 1 := rfl

/-- A dot-product fold that accounts for each multiplication and addition. -/
def meteredProductSum {ι : Type*} (ops : RationalArithmetic) (u v : ι → ℚ) :
    List ι → ℚ × ℕ
  | [] => (0, 0)
  | i::is =>
    let p := ops.mul (u i) (v i)
    let tail := meteredProductSum ops u v is
    let s := ops.add p.1 tail.1
    (s.1, p.2+tail.2+s.2)

theorem meteredProductSum_value {ι : Type*} (ops : RationalArithmetic)
    (u v : ι → ℚ) (is : List ι) :
    (meteredProductSum ops u v is).1 = (is.map fun i => u i*v i).sum := by
  induction is with
  | nil => rfl
  | cons i is ih =>
    simp only [meteredProductSum, ops.add_value, ops.mul_value, ih, List.map_cons, List.sum_cons]

theorem meteredProductSum_unit_work {ι : Type*} (u v : ι → ℚ) (is : List ι) :
    (meteredProductSum unitRationalArithmetic u v is).2 = 2*is.length := by
  induction is with
  | nil => rfl
  | cons i is ih =>
    simp only [meteredProductSum, unit_mul_work, unit_add_work, ih, List.length_cons]
    omega

def meteredRationalDot (ops : RationalArithmetic) (u v : Fin d → ℚ) : ℚ × ℕ :=
  meteredProductSum ops u v (List.ofFn id)

theorem meteredRationalDot_value (ops : RationalArithmetic) (u v : Fin d → ℚ) :
    (meteredRationalDot ops u v).1 = rationalDot u v := by
  rw [meteredRationalDot, meteredProductSum_value, List.map_ofFn, List.sum_ofFn]
  rfl

theorem meteredRationalDot_unit_work (u v : Fin d → ℚ) :
    (meteredRationalDot unitRationalArithmetic u v).2 = 2*d := by
  simp only [meteredRationalDot, meteredProductSum_unit_work, List.length_ofFn]

/-- Projection coefficient built from two charged dot products and division. -/
def meteredGsCoefficient (ops : RationalArithmetic) (A : Matrix (Fin r) (Fin d) ℚ)
    (T : RationalGSTable r d) (k j : Fin r) : ℚ × ℕ :=
  let num := meteredRationalDot ops (T.get j).get (A k)
  let den := meteredRationalDot ops (T.get j).get (T.get j).get
  let result := ops.div num.1 den.1
  (result.1, num.2+den.2+result.2)

theorem meteredGsCoefficient_value (ops : RationalArithmetic)
    (A : Matrix (Fin r) (Fin d) ℚ) (T : RationalGSTable r d) (k j : Fin r) :
    (meteredGsCoefficient ops A T k j).1 = cachedGsCoefficient A T k j := by
  simp only [meteredGsCoefficient, ops.div_value, meteredRationalDot_value, cachedGsCoefficient]

theorem meteredGsCoefficient_unit_work (A : Matrix (Fin r) (Fin d) ℚ)
    (T : RationalGSTable r d) (k j : Fin r) :
    (meteredGsCoefficient unitRationalArithmetic A T k j).2 = 4*d+1 := by
  simp only [meteredGsCoefficient, unit_div_work, meteredRationalDot_unit_work]
  omega

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

/-- Computable enumeration of exactly the rows preceding `k`. -/
def lowerFinEquiv (k : Fin r) : Fin k.val ≃ Finset.Iio k where
  toFun i := ⟨⟨i.val, lt_trans i.isLt k.isLt⟩, Finset.mem_Iio.mpr i.isLt⟩
  invFun i := ⟨i.val.val, show (i.val:Fin r) < k from Finset.mem_Iio.mp i.2⟩
  left_inv _ := rfl
  right_inv _ := rfl

/-- A materialized charged row calculation. Every coefficient and coordinate
is evaluated once and stored before its value and charge are read. -/
def meteredGSRow (ops : RationalArithmetic) (A : Matrix (Fin r) (Fin d) ℚ)
    (T : RationalGSTable r d) (k : Fin r) : RationalRow d × ℕ :=
  let coeff : Vector (ℚ × ℕ) r := Vector.ofFn fun i =>
    if i < k then meteredGsCoefficient ops A T k i else (0,0)
  let row : Vector (ℚ × ℕ) d := Vector.ofFn fun l =>
    let acc := meteredProductSum ops (fun i : Finset.Iio k => (coeff.get i).1)
      (fun i => (T.get i).get l) (List.ofFn (lowerFinEquiv k))
    let residual := ops.sub (A k l) acc.1
    (residual.1, acc.2+residual.2)
  (Vector.ofFn fun l => (row.get l).1,
    (∑ i : Fin r, (coeff.get i).2)+(∑ l : Fin d, (row.get l).2))

theorem meteredGSRow_value (ops : RationalArithmetic) (A : Matrix (Fin r) (Fin d) ℚ)
    (T : RationalGSTable r d) (k : Fin r) :
    (meteredGSRow ops A T k).1 = cachedGSRow A T k := by
  apply Vector.ext
  intro l hl
  change ((meteredGSRow ops A T k).1).get ⟨l,hl⟩ = (cachedGSRow A T k).get ⟨l,hl⟩
  simp only [meteredGSRow, cachedGSRow, get_ofFn, ops.sub_value,
    meteredProductSum_value, List.map_ofFn, List.sum_ofFn]
  simp only [Function.comp_apply]
  rw [Equiv.sum_comp (lowerFinEquiv k) (fun i : Finset.Iio k =>
    (if (i:Fin r) < k then meteredGsCoefficient ops A T k i else (0,0)).1 *
      (T.get i).get ⟨l,hl⟩)]
  congr 1
  apply Finset.sum_congr rfl
  intro i _
  have hi : (i:Fin r) < k := Finset.mem_Iio.mp i.2
  simp only [hi, ↓reduceIte, meteredGsCoefficient_value, cachedGsCoefficient]

theorem meteredGSRow_unit_work (A : Matrix (Fin r) (Fin d) ℚ)
    (T : RationalGSTable r d) (k : Fin r) :
    (meteredGSRow unitRationalArithmetic A T k).2 = k.val*(4*d+1)+d*(2*k.val+1) := by
  simp only [meteredGSRow, get_ofFn, meteredProductSum_unit_work,
    meteredGsCoefficient_unit_work, unit_sub_work, List.length_ofFn,
    apply_ite Prod.snd, Prod.snd_zero, Finset.sum_const]
  have hc : (∑ i : Fin r, if i < k then 4*d+1 else 0) = k.val*(4*d+1) := by
    rw [← Finset.sum_filter]
    have he : Finset.univ.filter (fun i : Fin r => i < k) = Finset.Iio k := by ext i; simp
    rw [he]
    simp
  simpa only [Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] using congrArg (fun x => x+d*(2*k.val+1)) hc

/-- The charged table uses exactly the same array update pattern as the
cached table, adding the charges actually returned by each row calculation. -/
def meteredGSTable (ops : RationalArithmetic) (A : Matrix (Fin r) (Fin d) ℚ)
    (n : ℕ) (hn : n ≤ r) : RationalGSTable r d × ℕ :=
  match n with
  | 0 => (Vector.replicate r (Vector.replicate d 0), 0)
  | n+1 =>
    let previous := meteredGSTable ops A n (by omega)
    let row := meteredGSRow ops A previous.1 ⟨n, by omega⟩
    (previous.1.set n row.1 (by omega), previous.2+row.2)
termination_by n

theorem meteredGSTable_value (ops : RationalArithmetic) (A : Matrix (Fin r) (Fin d) ℚ)
    (n : ℕ) (hn : n ≤ r) : (meteredGSTable ops A n hn).1 = cachedGSTable A n hn := by
  induction n with
  | zero => rw [meteredGSTable, cachedGSTable]
  | succ n ih => rw [meteredGSTable, cachedGSTable, meteredGSRow_value, ih]

theorem meteredGSTable_unit_work (A : Matrix (Fin r) (Fin d) ℚ)
    (n : ℕ) (hn : n ≤ r) :
    (meteredGSTable unitRationalArithmetic A n hn).2 =
      ∑ k ∈ Finset.range n, (k*(4*d+1)+d*(2*k+1)) := by
  induction n with
  | zero => simp [meteredGSTable]
  | succ n ih =>
    rw [meteredGSTable, meteredGSRow_unit_work, ih, Finset.sum_range_succ]

theorem meteredGSTable_unit_work_le (A : Matrix (Fin r) (Fin d) ℚ)
    (n : ℕ) (hn : n ≤ r) :
    (meteredGSTable unitRationalArithmetic A n hn).2 ≤ n*(r*(4*d+1)+d*(2*r+1)) := by
  rw [meteredGSTable_unit_work]
  calc
    _ ≤ ∑ _k ∈ Finset.range n, (r*(4*d+1)+d*(2*r+1)) := by
      apply Finset.sum_le_sum
      intro k hk
      have hk : k ≤ r := (Nat.le_of_lt (Finset.mem_range.mp hk)).trans hn
      exact Nat.add_le_add (Nat.mul_le_mul_right _ hk)
        (Nat.mul_le_mul_left _ (by omega))
    _ = _ := by simp

/-- One integer row operation, charging one multiplication and one subtraction
per updated coordinate. Array reads, allocation, and copies are not included
in this scalar-arithmetic counter. -/
def meteredIntegerRowUpdate (D : IntegerMatrixData r d) (k j : Fin r) (q : ℤ) :
    IntegerMatrixData r d × ℕ :=
  let row : Vector (ℤ × ℕ) d := Vector.ofFn fun l =>
    let product : ℤ × ℕ := (q*(D.get j).get l, 1)
    let difference : ℤ × ℕ := ((D.get k).get l-product.1, 1)
    (difference.1, product.2+difference.2)
  (D.set k.val (Vector.ofFn fun l => (row.get l).1) k.isLt,
    ∑ l : Fin d, (row.get l).2)

theorem meteredIntegerRowUpdate_work (D : IntegerMatrixData r d) (k j : Fin r) (q : ℤ) :
    (meteredIntegerRowUpdate D k j q).2 = 2*d := by
  simp [meteredIntegerRowUpdate, get_ofFn, mul_comm]

theorem meteredIntegerRowUpdate_value (D : IntegerMatrixData r d) (k j : Fin r) (q : ℤ) :
    (meteredIntegerRowUpdate D k j q).1 = materializeIntegerMatrix
      (Function.update (integerMatrixDataRows D) k
        (integerMatrixDataRows D k-q • integerMatrixDataRows D j)) := by
  apply Vector.ext
  intro i hi
  apply Vector.ext
  intro l hl
  change ((meteredIntegerRowUpdate D k j q).1[i]).get ⟨l,hl⟩ =
    ((materializeIntegerMatrix (Function.update (integerMatrixDataRows D) k
      (integerMatrixDataRows D k-q • integerMatrixDataRows D j))).get ⟨i,hi⟩).get ⟨l,hl⟩
  by_cases hik : i = k.val
  · subst i
    simp only [meteredIntegerRowUpdate, Vector.getElem_set_self, get_ofFn,
      materializeIntegerMatrix, Function.update_self, Pi.sub_apply, Pi.smul_apply,
      smul_eq_mul, integerMatrixDataRows]
  · have hfin : (⟨i,hi⟩ : Fin r) ≠ k := fun he => hik (congrArg Fin.val he)
    simp only [meteredIntegerRowUpdate, Vector.getElem_set_ne k.isLt hi (Ne.symm hik),
      materializeIntegerMatrix, get_ofFn, Function.update_of_ne hfin, integerMatrixDataRows]
    rfl

/-- Instrumented array-valued inner sweep. Rounding is counted as one scalar
operation, separately from its eventual binary implementation cost. -/
def meteredReduceIntegerRow (ops : RationalArithmetic) (D : IntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) : IntegerMatrixData r d × ℕ :=
  match n with
  | 0 => (D,0)
  | n+1 =>
    let j : Fin r := ⟨n, by omega⟩
    let Q := rationalIntegerRows (integerMatrixDataRows D)
    let T := meteredGSTable ops Q r le_rfl
    let coefficient := meteredGsCoefficient ops Q T.1 k j
    let q := round coefficient.1
    let update := meteredIntegerRowUpdate D k j q
    let tail := meteredReduceIntegerRow ops update.1 k n (by omega)
    (tail.1, T.2+coefficient.2+1+update.2+tail.2)
termination_by n

theorem meteredReduceIntegerRow_value (ops : RationalArithmetic) (D : IntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) :
    (meteredReduceIntegerRow ops D k n h).1 = materializedReduceIntegerRow D k n h := by
  induction n generalizing D with
  | zero => rw [meteredReduceIntegerRow, materializedReduceIntegerRow]
  | succ n ih =>
    rw [meteredReduceIntegerRow, materializedReduceIntegerRow, ih,
      meteredGSTable_value, meteredGsCoefficient_value, meteredIntegerRowUpdate_value]

/-- Upper bound for one inner update, derived from the table and coefficient
operation counts, one rounding call, and the actual integer row update. -/
def cachedInnerArithmeticBound (r d : ℕ) : ℕ :=
  r*(r*(4*d+1)+d*(2*r+1))+(4*d+1)+1+2*d

theorem meteredReduceIntegerRow_unit_work_le (D : IntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) :
    (meteredReduceIntegerRow unitRationalArithmetic D k n h).2 ≤ n*cachedInnerArithmeticBound r d := by
  induction n generalizing D with
  | zero => simp [meteredReduceIntegerRow]
  | succ n ih =>
    rw [meteredReduceIntegerRow]
    simp only [meteredGsCoefficient_unit_work, meteredIntegerRowUpdate_work]
    have ht := meteredGSTable_unit_work_le (rationalIntegerRows (integerMatrixDataRows D)) r le_rfl
    have hi := ih (meteredIntegerRowUpdate D k ⟨n, by omega⟩
      (round (meteredGsCoefficient unitRationalArithmetic
        (rationalIntegerRows (integerMatrixDataRows D))
        (meteredGSTable unitRationalArithmetic (rationalIntegerRows (integerMatrixDataRows D)) r le_rfl).1
        k ⟨n, by omega⟩).1)).1 (by omega)
    unfold cachedInnerArithmeticBound at *
    nlinarith

def meteredReduceIntegerAll (ops : RationalArithmetic) (D : IntegerMatrixData r d)
    (n : ℕ) (h : n ≤ r) : IntegerMatrixData r d × ℕ :=
  match n with
  | 0 => (D,0)
  | n+1 =>
    let previous := meteredReduceIntegerAll ops D n (by omega)
    let current := meteredReduceIntegerRow ops previous.1 ⟨n, by omega⟩ n le_rfl
    (current.1, previous.2+current.2)
termination_by n

theorem meteredReduceIntegerAll_value (ops : RationalArithmetic) (D : IntegerMatrixData r d)
    (n : ℕ) (h : n ≤ r) :
    (meteredReduceIntegerAll ops D n h).1 = materializedReduceIntegerAll D n h := by
  induction n with
  | zero => rw [meteredReduceIntegerAll, materializedReduceIntegerAll]
  | succ n ih =>
    rw [meteredReduceIntegerAll, materializedReduceIntegerAll, meteredReduceIntegerRow_value, ih]

theorem meteredReduceIntegerAll_unit_work_le (D : IntegerMatrixData r d)
    (n : ℕ) (h : n ≤ r) :
    (meteredReduceIntegerAll unitRationalArithmetic D n h).2 ≤ n*r*cachedInnerArithmeticBound r d := by
  induction n with
  | zero => simp [meteredReduceIntegerAll]
  | succ n ih =>
    rw [meteredReduceIntegerAll]
    have hc := meteredReduceIntegerRow_unit_work_le
      (meteredReduceIntegerAll unitRationalArithmetic D n (by omega)).1 ⟨n, by omega⟩ n le_rfl
    have hi := ih (by omega)
    have hn : n ≤ r := by omega
    have hm := Nat.mul_le_mul_right (cachedInnerArithmeticBound r d) hn
    nlinarith


/-- Charged direct Lovász comparison. Common squared lengths are reused, and
one rational comparison is counted as a scalar operation. -/
def meteredLovaszPair (ops : RationalArithmetic) (A : Matrix (Fin r) (Fin d) ℚ)
    (T : RationalGSTable r d) (j k : Fin r) : Bool × ℕ :=
  let nk := meteredRationalDot ops (T.get k).get (T.get k).get
  let nj := meteredRationalDot ops (T.get j).get (T.get j).get
  let mu := meteredGsCoefficient ops A T k j
  let square := ops.mul mu.1 mu.1
  let product := ops.mul square.1 nj.1
  let total := ops.add nk.1 product.1
  let left := ops.mul 4 total.1
  let right := ops.mul 3 nj.1
  (decide (left.1 < right.1),
    nk.2+nj.2+mu.2+square.2+product.2+total.2+left.2+right.2+1)

theorem meteredLovaszPair_value (ops : RationalArithmetic)
    (A : Matrix (Fin r) (Fin d) ℚ) (T : RationalGSTable r d) (j k : Fin r) :
    (meteredLovaszPair ops A T j k).1 = decide
      (4*(rationalDot (T.get k).get (T.get k).get +
        (cachedGsCoefficient A T k j)^2*rationalDot (T.get j).get (T.get j).get) <
        3*rationalDot (T.get j).get (T.get j).get) := by
  simp only [meteredLovaszPair, ops.mul_value, ops.add_value,
    meteredRationalDot_value, meteredGsCoefficient_value, pow_two]

theorem meteredLovaszPair_unit_work (A : Matrix (Fin r) (Fin d) ℚ)
    (T : RationalGSTable r d) (j k : Fin r) :
    (meteredLovaszPair unitRationalArithmetic A T j k).2 = 8*d+7 := by
  simp only [meteredLovaszPair, unit_mul_work, unit_add_work,
    meteredRationalDot_unit_work, meteredGsCoefficient_unit_work]
  omega

/-- The finite search materializes every adjacent-pair test once. Nonadjacent
pairs perform no rational arithmetic. -/
def meteredFailingAdjacentPairs (ops : RationalArithmetic) (D : IntegerMatrixData r d) :
    Finset (Fin r × Fin r) × ℕ :=
  let Q := rationalIntegerRows (integerMatrixDataRows D)
  let T := meteredGSTable ops Q r le_rfl
  let tests : Vector (Vector (Bool × ℕ) r) r := Vector.ofFn fun j => Vector.ofFn fun k =>
    if k.val = j.val+1 then meteredLovaszPair ops Q T.1 j k else (false,0)
  (Finset.univ.filter fun p => ((tests.get p.1).get p.2).1,
    T.2+∑ j : Fin r, ∑ k : Fin r, ((tests.get j).get k).2)

theorem meteredFailingAdjacentPairs_value (ops : RationalArithmetic) (D : IntegerMatrixData r d) :
    (meteredFailingAdjacentPairs ops D).1 = cachedFailingAdjacentPairs (integerMatrixDataRows D) := by
  ext p
  simp only [meteredFailingAdjacentPairs, cachedFailingAdjacentPairs, Finset.mem_filter,
    Finset.mem_univ, true_and, get_ofFn, meteredGSTable_value]
  by_cases h : p.2.val = p.1.val+1
  · simp only [h, ↓reduceIte, meteredLovaszPair_value, decide_eq_true_eq, true_and]
  · simp only [h, ↓reduceIte, Bool.false_eq_true, false_and]

/-- Search arithmetic is bounded by one table and at most `r²` pair tests. -/
def cachedSearchArithmeticBound (r d : ℕ) : ℕ :=
  r*(r*(4*d+1)+d*(2*r+1))+r*r*(8*d+7)

theorem meteredFailingAdjacentPairs_unit_work_le (D : IntegerMatrixData r d) :
    (meteredFailingAdjacentPairs unitRationalArithmetic D).2 ≤ cachedSearchArithmeticBound r d := by
  unfold meteredFailingAdjacentPairs
  simp only [get_ofFn, apply_ite Prod.snd]
  have ht := meteredGSTable_unit_work_le
    (rationalIntegerRows (integerMatrixDataRows D)) r le_rfl
  have hs : (∑ j : Fin r, ∑ k : Fin r,
      if k.val = j.val+1 then
        (meteredLovaszPair unitRationalArithmetic (rationalIntegerRows (integerMatrixDataRows D))
          (meteredGSTable unitRationalArithmetic (rationalIntegerRows (integerMatrixDataRows D)) r le_rfl).1 j k).2
      else 0) ≤ r*r*(8*d+7) := by
    calc
      _ ≤ ∑ _j : Fin r, ∑ _k : Fin r, (8*d+7) := by
        apply Finset.sum_le_sum
        intro j _
        apply Finset.sum_le_sum
        intro k _
        split_ifs <;> simp [meteredLovaszPair_unit_work]
      _ = _ := by simp; ring
  unfold cachedSearchArithmeticBound
  exact Nat.add_le_add ht hs

/-- Deterministic minimum of the already computed finite test set. -/
def leastPairInFinset (S : Finset (Fin r × Fin r)) (hS : S.Nonempty) : Fin r × Fin r := by
  letI : LinearOrder (Fin r × Fin r) :=
    LinearOrder.lift' (toLex : Fin r × Fin r → Fin r ×ₗ Fin r)
      (fun _ _ h => toLex_inj.mp h)
  exact S.min' hS

theorem leastPairInFinset_cached (A : Matrix (Fin r) (Fin d) ℤ)
    (h : (cachedFailingAdjacentPairs A).Nonempty) :
    leastPairInFinset (cachedFailingAdjacentPairs A) h = cachedLeastFailingAdjacentPair A h := by
  unfold leastPairInFinset cachedLeastFailingAdjacentPair
  rfl

/-- Charged reduction result with a separate swap count. -/
structure MeteredLatticeResult (r d : ℕ) where
  rows : IntegerMatrixData r d
  swaps : ℕ
  work : ℕ
  deriving Repr

/-- A compositional arithmetic implementation of the entire cached loop.
Container traversals and input-fuel construction are outside this arithmetic
counter and remain separately visible algorithmic operations. -/
def meteredReductionFuel (ops : RationalArithmetic) : ℕ → IntegerMatrixData r d → MeteredLatticeResult r d
  | 0, D => ⟨D,0,0⟩
  | n+1, D =>
    let sweep := meteredReduceIntegerAll ops D r le_rfl
    let tests := meteredFailingAdjacentPairs ops sweep.1
    if h : tests.1.Nonempty then
      let p := leastPairInFinset tests.1 h
      let W := materializeIntegerMatrix (swapRows (integerMatrixDataRows sweep.1) p.1 p.2)
      let tail := meteredReductionFuel ops n W
      ⟨tail.rows, tail.swaps+1, sweep.2+tests.2+tail.work⟩
    else ⟨sweep.1,0,sweep.2+tests.2⟩

/-- Polynomial scalar-arithmetic charge for one complete sweep and search. -/
def cachedPassArithmeticBound (r d : ℕ) : ℕ :=
  r*r*cachedInnerArithmeticBound r d+cachedSearchArithmeticBound r d

theorem meteredReductionFuel_unit_work_le (fuel : ℕ) (D : IntegerMatrixData r d) :
    (meteredReductionFuel unitRationalArithmetic fuel D).work ≤
      ((meteredReductionFuel unitRationalArithmetic fuel D).swaps+1)*cachedPassArithmeticBound r d := by
  induction fuel generalizing D with
  | zero => simp [meteredReductionFuel]
  | succ n ih =>
    rw [meteredReductionFuel]
    split_ifs with h
    · simp only [MeteredLatticeResult.work, MeteredLatticeResult.swaps]
      have hs := meteredReduceIntegerAll_unit_work_le D r le_rfl
      have ht := meteredFailingAdjacentPairs_unit_work_le
        (meteredReduceIntegerAll unitRationalArithmetic D r le_rfl).1
      have hi := ih (materializeIntegerMatrix (swapRows
        (integerMatrixDataRows (meteredReduceIntegerAll unitRationalArithmetic D r le_rfl).1)
        (leastPairInFinset _ h).1 (leastPairInFinset _ h).2))
      unfold cachedPassArithmeticBound at *
      nlinarith
    · simp only [MeteredLatticeResult.work, MeteredLatticeResult.swaps, zero_add, one_mul]
      exact Nat.add_le_add (meteredReduceIntegerAll_unit_work_le D r le_rfl)
        (meteredFailingAdjacentPairs_unit_work_le
          (meteredReduceIntegerAll unitRationalArithmetic D r le_rfl).1)


/-- The instrumented evaluator preserves both the exact output arrays and
swap count of the materialized algorithm for every arithmetic implementation
satisfying the four value laws. -/
theorem meteredReductionFuel_value (ops : RationalArithmetic) (fuel : ℕ)
    (D : IntegerMatrixData r d) :
    ((meteredReductionFuel ops fuel D).rows, (meteredReductionFuel ops fuel D).swaps) =
      materializedReductionFuel fuel D := by
  induction fuel generalizing D with
  | zero => rfl
  | succ n ih =>
    rw [meteredReductionFuel, materializedReductionFuel]
    simp only [meteredFailingAdjacentPairs_value, meteredReduceIntegerAll_value]
    split_ifs with h
    · simp only [MeteredLatticeResult.rows, MeteredLatticeResult.swaps, leastPairInFinset_cached]
      exact congrArg (fun out : IntegerMatrixData r d × ℕ => (out.1, out.2+1))
        (ih (materializeIntegerMatrix (swapRows (integerMatrixDataRows
          (materializedReduceIntegerAll D r le_rfl))
          (cachedLeastFailingAdjacentPair _ h).1 (cachedLeastFailingAdjacentPair _ h).2)))
    · rfl

/-- Scalar-arithmetic count in terms of the actual materialized loop's swaps,
with no assumed number of passes. -/
theorem meteredReductionFuel_work_le_actual_swaps (fuel : ℕ) (D : IntegerMatrixData r d) :
    (meteredReductionFuel unitRationalArithmetic fuel D).work ≤
      ((materializedReductionFuel fuel D).2+1)*cachedPassArithmeticBound r d := by
  have he := congrArg Prod.snd (meteredReductionFuel_value unitRationalArithmetic fuel D)
  change (meteredReductionFuel unitRationalArithmetic fuel D).swaps =
    (materializedReductionFuel fuel D).2 at he
  rw [← he]
  exact meteredReductionFuel_unit_work_le fuel D

/-- Explicit low-degree bound for all charged scalar operations per pass. -/
theorem cachedPassArithmeticBound_le (r d : ℕ) :
    cachedPassArithmeticBound r d ≤ 32*(r+1)^4*(d+1) := by
  let remainder := 26*r^4*d+31*r^4+127*r^3*d+128*r^3+
    172*r^2*d+182*r^2+127*r*d+128*r+32*d+32
  have he : cachedPassArithmeticBound r d + remainder = 32*(r+1)^4*(d+1) := by
    unfold cachedPassArithmeticBound cachedInnerArithmeticBound cachedSearchArithmeticBound remainder
    ring
  exact (Nat.le_add_right (cachedPassArithmeticBound r d) remainder).trans he.le

/-- A generic sufficient-fuel correctness theorem for the instrumented
implementation; charges never affect its mathematical output. -/
theorem meteredReductionFuel_spec (ops : RationalArithmetic) (fuel : ℕ)
    (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ)))
    (hfuel : gramPotential (integerMatrixDataRows D) ≤ fuel) :
    IntegerReductionSpecification (integerMatrixDataRows D)
      (integerMatrixDataRows (meteredReductionFuel ops fuel D).rows)
      (meteredReductionFuel ops fuel D).swaps := by
  have he := meteredReductionFuel_value ops fuel D
  have h := materializedReductionFuel_spec fuel D hD hfuel
  rw [← he] at h
  exact h


/-- Fully materialized charged execution with determinant-free initial fuel.
Sealing the result avoids expanding large natural fuel expressions in proofs. -/
irreducible_def meteredCachedData (ops : RationalArithmetic)
    (A : Matrix (Fin r) (Fin d) ℤ) : MeteredLatticeResult r d :=
  meteredReductionFuel ops (cachedReductionInitialFuel A) (materializeIntegerMatrix A)

theorem meteredCachedData_value (ops : RationalArithmetic) (A : Matrix (Fin r) (Fin d) ℤ) :
    ((meteredCachedData ops A).rows, (meteredCachedData ops A).swaps) = cachedReductionData A := by
  rw [meteredCachedData_def, cachedReductionData_def]
  exact meteredReductionFuel_value ops _ _

/-- Scalar operations of the actual charged run are bounded by a polynomial
in dimensions times its actual swap count plus one. This excludes container
administration and fuel construction, and treats rounding and comparison as
scalar operations whose binary costs need separate refinement. -/
theorem meteredCachedData_work_le (A : Matrix (Fin r) (Fin d) ℤ) :
    (meteredCachedData unitRationalArithmetic A).work ≤
      ((cachedReductionData A).2+1)*(32*(r+1)^4*(d+1)) := by
  rw [meteredCachedData_def, cachedReductionData_def]
  exact (meteredReductionFuel_work_le_actual_swaps _ _).trans
    (Nat.mul_le_mul_left _ (cachedPassArithmeticBound_le r d))

/-- The arithmetic count refers to the same swap count as the certified
public reduction result, so its already proved logarithmic estimate applies. -/
theorem meteredCachedData_work_le_certified_swaps (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) :
    (meteredCachedData unitRationalArithmetic A).work ≤
      ((cachedIntegerReduction A hA).swapCount+1)*(32*(r+1)^4*(d+1)) :=
  meteredCachedData_work_le A


end Optss
