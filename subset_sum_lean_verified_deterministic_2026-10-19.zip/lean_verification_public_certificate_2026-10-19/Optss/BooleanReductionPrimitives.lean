import Optss.BitListRationalOrderRound
import Optss.BooleanRationalModel

/-!
# Boolean comparison and rounding at the rational evaluator boundary

These wrappers encode the reduced rational fields, run the Boolean-list
algorithms, and decode their answers. Their charges are the concrete Boolean
gate/list-visit counts proved for those algorithms. Representation conversion
and the computation of instrumentation counters are separate from these counts.
-/

namespace Optss

def booleanRatLE (p q : ℚ) : Bool × ℕ :=
  let P := rationalBitRepresentation p
  let Q := rationalBitRepresentation q
  (bitListFractionLE P Q, bitListFractionLECost P Q)

theorem booleanRatLE_correct (p q : ℚ) :
    (booleanRatLE p q).1 = decide (p ≤ q) := by
  apply Bool.eq_iff_iff.mpr
  simpa only [booleanRatLE, rationalBitRepresentation_value, decide_eq_true_eq] using
    bitListFractionLE_correct (rationalBitRepresentation p) (rationalBitRepresentation q)
      (rationalBitRepresentation_wellFormed p).2.2.1
      (rationalBitRepresentation_wellFormed q).2.2.1

def booleanRatLT (p q : ℚ) : Bool × ℕ :=
  let P := rationalBitRepresentation p
  let Q := rationalBitRepresentation q
  (bitListFractionLT P Q, bitListFractionLTCost P Q)

theorem booleanRatLT_correct (p q : ℚ) :
    (booleanRatLT p q).1 = decide (p < q) := by
  apply Bool.eq_iff_iff.mpr
  simpa only [booleanRatLT, rationalBitRepresentation_value, decide_eq_true_eq] using
    bitListFractionLT_correct (rationalBitRepresentation p) (rationalBitRepresentation q)
      (rationalBitRepresentation_wellFormed p).2.2.1
      (rationalBitRepresentation_wellFormed q).2.2.1

def booleanRatFloor (p : ℚ) : ℤ × ℕ :=
  let P := rationalBitRepresentation p
  let result := bitListFractionFloor P
  (signedBitsValue result.1 result.2, bitListFractionFloorCost P)

theorem booleanRatFloor_correct (p : ℚ) : (booleanRatFloor p).1 = ⌊p⌋ := by
  simpa only [booleanRatFloor, rationalBitRepresentation_value] using
    bitListFractionFloor_correct (rationalBitRepresentation p)
      (rationalBitRepresentation_wellFormed p).2.2.1

def booleanRatRound (p : ℚ) : ℤ × ℕ :=
  let P := rationalBitRepresentation p
  let result := bitListFractionRound P
  (signedBitsValue result.1 result.2, bitListFractionRoundCost P)

theorem booleanRatRound_correct (p : ℚ) : (booleanRatRound p).1 = round p := by
  simpa only [booleanRatRound, rationalBitRepresentation_value] using
    bitListFractionRound_correct (rationalBitRepresentation p)
      (rationalBitRepresentation_wellFormed p).2.2.1

theorem booleanRatLE_quadratic (p q : ℚ) (L : ℕ)
    (hp : RationalBitBound p L) (hq : RationalBitBound q L) :
    (booleanRatLE p q).2 ≤ 128*(L+1)^2 :=
  bitListFractionLECost_bound _ _ L
    ((rationalBitRepresentation_bound p L).mp hp)
    ((rationalBitRepresentation_bound q L).mp hq)

theorem booleanRatLT_quadratic (p q : ℚ) (L : ℕ)
    (hp : RationalBitBound p L) (hq : RationalBitBound q L) :
    (booleanRatLT p q).2 ≤ 256*(L+1)^2 :=
  bitListFractionLTCost_bound _ _ L
    ((rationalBitRepresentation_bound p L).mp hp)
    ((rationalBitRepresentation_bound q L).mp hq)

theorem booleanRatFloor_quadratic (p : ℚ) (L : ℕ)
    (hp : RationalBitBound p L) : (booleanRatFloor p).2 ≤ 64*(L+1)^2 :=
  bitListFractionFloorCost_bound _ (rationalBitRepresentation_wellFormed p).2.2.1 L
    ((rationalBitRepresentation_bound p L).mp hp)

theorem booleanRatRound_cubic (p : ℚ) (L : ℕ)
    (hp : RationalBitBound p L) : (booleanRatRound p).2 ≤ 65536*(L+1)^3 :=
  bitListFractionRoundCost_bound _ (rationalBitRepresentation_wellFormed p).2.2.1 L
    ((rationalBitRepresentation_bound p L).mp hp)

/-- All rational scalar primitives have one common concrete cubic bound.
This includes the strict test and nearest-integer rounding used by LLL. -/
theorem booleanRationalPrimitives_cubic (p q : ℚ) (L : ℕ)
    (hp : RationalBitBound p L) (hq : RationalBitBound q L) :
    (booleanRationalArithmetic.add p q).2 ≤ 65536*(L+1)^3 ∧
    (booleanRationalArithmetic.sub p q).2 ≤ 65536*(L+1)^3 ∧
    (booleanRationalArithmetic.mul p q).2 ≤ 65536*(L+1)^3 ∧
    (booleanRationalArithmetic.div p q).2 ≤ 65536*(L+1)^3 ∧
    (booleanRatLE p q).2 ≤ 65536*(L+1)^3 ∧
    (booleanRatLT p q).2 ≤ 65536*(L+1)^3 ∧
    (booleanRatRound p).2 ≤ 65536*(L+1)^3 := by
  have h := booleanRationalArithmetic_cubic p q L hp hq
  have hle := booleanRatLE_quadratic p q L hp hq
  have hlt := booleanRatLT_quadratic p q L hp hq
  have hpow : (L+1)^2 ≤ (L+1)^3 := by
    calc
      (L+1)^2 = (L+1)^2*1 := by omega
      _ ≤ (L+1)^2*(L+1) := Nat.mul_le_mul_left _ (by omega)
      _ = (L+1)^3 := by ring
  exact ⟨h.1.trans (by omega), h.2.1.trans (by omega), h.2.2.1.trans (by omega),
    h.2.2.2.trans (by omega), hle.trans (by nlinarith), hlt.trans (by nlinarith),
    booleanRatRound_cubic p L hp⟩

end Optss
