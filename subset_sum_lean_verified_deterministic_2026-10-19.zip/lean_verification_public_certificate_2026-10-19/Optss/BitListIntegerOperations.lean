import Optss.BitListRationalOperations
import Optss.CachedReductionCost

/-!
# Signed Boolean integers and elementary lattice row updates

The answer routines use signs and Boolean lists throughout. A zero magnitude
may carry either sign. Correctness accepts noncanonical input lists; the output
magnitudes are canonical. Costs count gates and list visits and keep matrix
storage operations and integer encoding/decoding separate.
-/

namespace Optss

structure BitListInteger where
  negative : Bool
  digits : List Bool
  deriving Repr

def BitListInteger.value (z : BitListInteger) : ℤ :=
  signedBitsValue z.negative z.digits

def integerBitRepresentation (z : ℤ) : BitListInteger :=
  ⟨decide (z < 0), z.natAbs.bits⟩

theorem integerBitRepresentation_value (z : ℤ) :
    (integerBitRepresentation z).value = z := by
  by_cases hz : z < 0
  · simp [integerBitRepresentation, BitListInteger.value, signedBitsValue,
      hz, binaryDigitsValue_bits, Int.natCast_natAbs, abs_of_neg hz]
  · simp [integerBitRepresentation, BitListInteger.value, signedBitsValue,
      hz, binaryDigitsValue_bits, Int.natCast_natAbs, abs_of_nonneg (le_of_not_gt hz)]

theorem integerBitRepresentation_length (z : ℤ) :
    (integerBitRepresentation z).digits.length = z.natAbs.size := by
  simp only [integerBitRepresentation, Nat.size_eq_bits_len]

def bitListIntegerNeg (z : BitListInteger) : BitListInteger := ⟨!z.negative, z.digits⟩

def bitListIntegerAdd (x y : BitListInteger) : BitListInteger :=
  let s := bitListSignedAdd x.negative y.negative x.digits y.digits
  ⟨s.1,s.2⟩

def bitListIntegerSub (x y : BitListInteger) : BitListInteger :=
  bitListIntegerAdd x (bitListIntegerNeg y)

def bitListIntegerMul (x y : BitListInteger) : BitListInteger :=
  ⟨Bool.xor x.negative y.negative, bitListMultiplication x.digits y.digits⟩

/-- One coordinate of the elementary operation `row[k] -= c * row[j]`. -/
def bitListIntegerRowCell (u c v : BitListInteger) : BitListInteger :=
  bitListIntegerSub u (bitListIntegerMul c v)

theorem bitListIntegerNeg_value (z : BitListInteger) :
    (bitListIntegerNeg z).value = -z.value := by
  cases hz : z.negative <;> simp [bitListIntegerNeg, BitListInteger.value, signedBitsValue, hz]

theorem bitListIntegerAdd_value (x y : BitListInteger) :
    (bitListIntegerAdd x y).value = x.value+y.value :=
  bitListSignedAdd_correct _ _ _ _

theorem bitListIntegerSub_value (x y : BitListInteger) :
    (bitListIntegerSub x y).value = x.value-y.value := by
  rw [bitListIntegerSub, bitListIntegerAdd_value, bitListIntegerNeg_value, sub_eq_add_neg]

theorem bitListIntegerMul_value (x y : BitListInteger) :
    (bitListIntegerMul x y).value = x.value*y.value :=
  signedBitsValue_xor_mul _ _ _ _

theorem bitListIntegerRowCell_value (u c v : BitListInteger) :
    (bitListIntegerRowCell u c v).value = u.value-c.value*v.value := by
  rw [bitListIntegerRowCell, bitListIntegerSub_value, bitListIntegerMul_value]

theorem bitListSignedDiff_canonical (s : Bool) (xs ys : List Bool) :
    BitListCanonical (bitListSignedDiff s xs ys).2 := by
  unfold bitListSignedDiff
  dsimp only
  split_ifs <;> exact bitListTrim_canonical _

theorem bitListSignedAdd_canonical (s t : Bool) (xs ys : List Bool) :
    BitListCanonical (bitListSignedAdd s t xs ys).2 := by
  unfold bitListSignedAdd
  split_ifs
  · exact bitListTrim_canonical _
  · exact bitListSignedDiff_canonical _ _ _

theorem bitListIntegerAdd_canonical (x y : BitListInteger) :
    BitListCanonical (bitListIntegerAdd x y).digits := bitListSignedAdd_canonical _ _ _ _

theorem bitListIntegerSub_canonical (x y : BitListInteger) :
    BitListCanonical (bitListIntegerSub x y).digits := bitListIntegerAdd_canonical _ _

theorem bitListIntegerMul_canonical (x y : BitListInteger) :
    BitListCanonical (bitListIntegerMul x y).digits := by
  unfold BitListCanonical
  change bitListMultiplication x.digits y.digits =
    (binaryDigitsValue (bitListMultiplication x.digits y.digits)).bits
  rw [bitListMultiplication_correct, bitListMultiplication_eq_bits]

theorem bitListIntegerRowCell_canonical (u c v : BitListInteger) :
    BitListCanonical (bitListIntegerRowCell u c v).digits := bitListIntegerSub_canonical _ _

theorem bitListIntegerAdd_length (x y : BitListInteger) :
    (bitListIntegerAdd x y).digits.length ≤ max x.digits.length y.digits.length+1 :=
  bitListSignedAdd_length _ _ _ _

theorem bitListIntegerSub_length (x y : BitListInteger) :
    (bitListIntegerSub x y).digits.length ≤ max x.digits.length y.digits.length+1 :=
  bitListIntegerAdd_length _ _

theorem bitListIntegerMul_length (x y : BitListInteger) :
    (bitListIntegerMul x y).digits.length ≤ x.digits.length+y.digits.length :=
  bitListMultiplication_length_le _ _

theorem bitListIntegerRowCell_length (u c v : BitListInteger) :
    (bitListIntegerRowCell u c v).digits.length ≤
      max u.digits.length (c.digits.length+v.digits.length)+1 := by
  exact (bitListIntegerSub_length _ _).trans
    (Nat.add_le_add_right (max_le_max le_rfl (bitListIntegerMul_length _ _)) 1)

def bitListIntegerAddCost (x y : BitListInteger) : ℕ :=
  bitListSignedAddCost x.negative y.negative x.digits y.digits

def bitListIntegerSubCost (x y : BitListInteger) : ℕ :=
  bitListIntegerAddCost x (bitListIntegerNeg y)+1

def bitListIntegerMulCost (x y : BitListInteger) : ℕ :=
  bitListProductWork x.digits y.digits+1

def bitListIntegerRowCellCost (u c v : BitListInteger) : ℕ :=
  bitListIntegerMulCost c v+bitListIntegerSubCost u (bitListIntegerMul c v)

theorem bitListIntegerAddCost_bound (x y : BitListInteger) (L : ℕ)
    (hx : x.digits.length ≤ L) (hy : y.digits.length ≤ L) :
    bitListIntegerAddCost x y ≤ 30*(L+1) := bitListSignedAddCost_bound _ _ _ _ L hx hy

theorem bitListIntegerSubCost_bound (x y : BitListInteger) (L : ℕ)
    (hx : x.digits.length ≤ L) (hy : y.digits.length ≤ L) :
    bitListIntegerSubCost x y ≤ 31*(L+1) := by
  have h := bitListIntegerAddCost_bound x (bitListIntegerNeg y) L hx hy
  unfold bitListIntegerSubCost
  omega

theorem bitListIntegerMulCost_bound (x y : BitListInteger) (L : ℕ)
    (hx : x.digits.length ≤ L) (hy : y.digits.length ≤ L) :
    bitListIntegerMulCost x y ≤ 41*(L+1)^2 := by
  have h := bitListMultiplication_uniform_cost x.digits y.digits L hx hy
  unfold bitListIntegerMulCost bitListProductWork
  nlinarith [show 1 ≤ (L+1)^2 by nlinarith]

theorem bitListIntegerRowCellCost_bound (u c v : BitListInteger) (L : ℕ)
    (hu : u.digits.length ≤ L) (hc : c.digits.length ≤ L) (hv : v.digits.length ≤ L) :
    bitListIntegerRowCellCost u c v ≤ 128*(L+1)^2 := by
  have hm := bitListIntegerMulCost_bound c v L hc hv
  have hl : (bitListIntegerMul c v).digits.length ≤ 2*L :=
    (bitListIntegerMul_length c v).trans (by omega)
  have hs := bitListIntegerSubCost_bound u (bitListIntegerMul c v) (2*L) (by omega) hl
  unfold bitListIntegerRowCellCost
  nlinarith

/-- Rational-evaluator-compatible wrapper; field encoding and decoding are
separate from the returned gate/list charge. -/
def booleanIntegerRowCell (u c v : ℤ) : ℤ × ℕ :=
  let U := integerBitRepresentation u
  let C := integerBitRepresentation c
  let V := integerBitRepresentation v
  ((bitListIntegerRowCell U C V).value, bitListIntegerRowCellCost U C V)

theorem booleanIntegerRowCell_value (u c v : ℤ) :
    (booleanIntegerRowCell u c v).1 = u-c*v := by
  dsimp only [booleanIntegerRowCell]
  rw [bitListIntegerRowCell_value, integerBitRepresentation_value,
    integerBitRepresentation_value, integerBitRepresentation_value]

theorem booleanIntegerRowCell_cost (u c v : ℤ) (L : ℕ)
    (hu : u.natAbs.size ≤ L) (hc : c.natAbs.size ≤ L) (hv : v.natAbs.size ≤ L) :
    (booleanIntegerRowCell u c v).2 ≤ 128*(L+1)^2 := by
  apply bitListIntegerRowCellCost_bound
  · simpa only [integerBitRepresentation_length] using hu
  · simpa only [integerBitRepresentation_length] using hc
  · simpa only [integerBitRepresentation_length] using hv

abbrev BitIntegerMatrixData (r d : ℕ) := Vector (Vector BitListInteger d) r

def bitIntegerMatrixValue {r d : ℕ} (D : BitIntegerMatrixData r d) :
    Matrix (Fin r) (Fin d) ℤ := fun i j => ((D.get i).get j).value

/-- Encoded row update: only the selected row's scalar entries are recomputed. -/
def bitListIntegerRowUpdate {r d : ℕ} (D : BitIntegerMatrixData r d)
    (k j : Fin r) (c : BitListInteger) : BitIntegerMatrixData r d :=
  D.set k.val (Vector.ofFn fun l => bitListIntegerRowCell ((D.get k).get l) c ((D.get j).get l)) k.isLt

private theorem integerBits_get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

private theorem integerBits_get_set_self {α : Type*} {n : ℕ} (D : Vector α n)
    (k : Fin n) (x : α) : (D.set k.val x k.isLt).get k = x := by
  change (D.set k.val x k.isLt)[k.val] = x
  simp

private theorem integerBits_get_set_ne {α : Type*} {n : ℕ} (D : Vector α n)
    (k i : Fin n) (x : α) (h : k.val ≠ i.val) :
    (D.set k.val x k.isLt).get i = D.get i := by
  change (D.set k.val x k.isLt)[i.val] = D[i.val]
  exact Vector.getElem_set_ne k.isLt i.isLt h

theorem bitListIntegerRowUpdate_value {r d : ℕ} (D : BitIntegerMatrixData r d)
    (k j : Fin r) (c : BitListInteger) :
    bitIntegerMatrixValue (bitListIntegerRowUpdate D k j c) =
      Function.update (bitIntegerMatrixValue D) k
        (bitIntegerMatrixValue D k-c.value • bitIntegerMatrixValue D j) := by
  funext i l
  by_cases hik : i = k
  · subst i
    simp only [bitIntegerMatrixValue, bitListIntegerRowUpdate,
      integerBits_get_set_self, integerBits_get_ofFn,
      Function.update_self, Pi.sub_apply, Pi.smul_apply, smul_eq_mul]
    exact bitListIntegerRowCell_value _ _ _
  · have hval : k.val ≠ i.val := fun h => hik (Fin.ext h.symm)
    simp only [bitIntegerMatrixValue, bitListIntegerRowUpdate,
      integerBits_get_set_ne D k i _ hval, Function.update_of_ne hik]

def bitListIntegerRowUpdateCost {r d : ℕ} (D : BitIntegerMatrixData r d)
    (k j : Fin r) (c : BitListInteger) : ℕ :=
  ∑ l : Fin d, bitListIntegerRowCellCost ((D.get k).get l) c ((D.get j).get l)

/-- Scalar bit work of a complete row operation. Array reads, allocation,
replacement and sharing are not part of this scalar charge. -/
theorem bitListIntegerRowUpdateCost_bound {r d : ℕ} (D : BitIntegerMatrixData r d)
    (k j : Fin r) (c : BitListInteger) (L : ℕ)
    (hD : ∀ i l, ((D.get i).get l).digits.length ≤ L) (hc : c.digits.length ≤ L) :
    bitListIntegerRowUpdateCost D k j c ≤ d*128*(L+1)^2 := by
  calc
    _ ≤ ∑ _l : Fin d, 128*(L+1)^2 := by
      apply Finset.sum_le_sum
      intro l _
      exact bitListIntegerRowCellCost_bound _ _ _ L (hD k l) hc (hD j l)
    _ = _ := by simp; ring


end Optss
