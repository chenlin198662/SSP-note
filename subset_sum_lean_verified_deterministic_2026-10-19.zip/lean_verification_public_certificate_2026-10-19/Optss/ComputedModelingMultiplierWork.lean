import Optss.ComputedModelingMultiplier

/-!
# Work of the materialized modeling sieve

Each difference has one Boolean inverse computation, followed by exactly
floor((q-1)/p) word-sized marks. The final scan reads the same stored array.
The source model charges word arithmetic/indexed array operations and also
all gates/list visits of the inverse implementation. Every bit operation is
bounded by one word operation; no modular-inverse oracle is used.
-/
namespace Optss

@[simp] theorem computedModelingMarkRow_length (e : ℤ) (p q : ℕ) :
    (computedModelingMarkRow e p q).length=(q-1)/p := by
  simp only [computedModelingMarkRow,List.length_map,List.length_range]

theorem computedModelingMarkSchedule_length (data : List ℤ) (p q : ℕ) :
    (computedModelingMarkSchedule data p q).length=
      (data.filter (fun e => e≠0)).length*((q-1)/p) := by
  unfold computedModelingMarkSchedule
  rw [List.length_flatMap]
  simp

theorem computedModelingMarkSchedule_eighth (data : List ℤ) (p q : ℕ)
    (hq : 1<q) (hp : 8*data.length<p) :
    8*(computedModelingMarkSchedule data p q).length<q-1 := by
  rw [computedModelingMarkSchedule_length]
  have hl := List.length_filter_le (fun e : ℤ => decide (e≠0)) data
  have hm := Nat.div_mul_le_self (q-1) p
  by_cases hz : (q-1)/p=0
  · simp only [hz,mul_zero]; omega
  · have hh : 0<(q-1)/p := Nat.pos_of_ne_zero hz
    nlinarith

def computedModelingInverseWork (e : ℤ) (q : ℕ) : ℕ :=
  bitListModPowWork ((e:ZMod q).val.bits) q.bits (q-2).bits+16*(q.size+1)

theorem computedModelingInverseWork_bound (e : ℤ) (q : ℕ) [NeZero q] :
    computedModelingInverseWork e q≤316*(q.size+1)^3 := by
  have hx : ((e:ZMod q).val.bits).length≤q.size := by
    rw [Nat.size_eq_bits_len]
    exact Nat.size_le_size (ZMod.val_lt _).le
  have h := bitListPrimeInverse_bitWork ((e:ZMod q).val.bits) q (NeZero.pos q) hx
  unfold computedModelingInverseWork
  nlinarith [Nat.zero_le q.size, sq_nonneg (q.size:ℤ)]

def computedModelingMarkRowWork (e : ℤ) (p q : ℕ) : ℕ :=
  computedModelingInverseWork e q+12*((q-1)/p+1)

def computedModelingSieveWork (data : List ℤ) (p q : ℕ) : ℕ :=
  4*data.length+3*(q+1)+
    ((data.filter (fun e => e≠0)).map (fun e => computedModelingMarkRowWork e p q)).sum+
    3*((computedModelingMarkSchedule data p q).length+1)

theorem computedModelingSieveWork_bound (data : List ℤ) (p q : ℕ) [NeZero q] :
    computedModelingSieveWork data p q≤
      340*data.length*(q.size+1)^3+15*(computedModelingMarkSchedule data p q).length+
        3*(q+1)+3 := by
  have hrow : ((data.filter (fun e => e≠0)).map
      (fun e => computedModelingMarkRowWork e p q)).sum≤
      (data.filter (fun e => e≠0)).length*(316*(q.size+1)^3+12*((q-1)/p+1)) := by
    apply le_trans (primeSieve_sum_map_mono _ _
      (fun _ => 316*(q.size+1)^3+12*((q-1)/p+1)) ?_)
    · simp
    · intro e he
      exact Nat.add_le_add_right (computedModelingInverseWork_bound e q) _
  have hl := List.length_filter_le (fun e : ℤ => decide (e≠0)) data
  have hh : (data.filter (fun e => e≠0)).length*(316*(q.size+1)^3+12)≤
      data.length*(316*(q.size+1)^3+12) := Nat.mul_le_mul_right _ hl
  have hpos : 0<(q.size+1)^3 := pow_pos (by omega) _
  have hw := Nat.mul_le_mul_left data.length
    (show 316*(q.size+1)^3+16≤340*(q.size+1)^3 by omega)
  rw [computedModelingSieveWork,computedModelingMarkSchedule_length]
  nlinarith only [hrow,hh,hw]

def computedModelingMultiplierTrace (data : List ℤ) (p q : ℕ) : Option ℕ×ℕ :=
  let flags := computedModelingFlags data p q
  let scan := scanPrimeFlagsTrace flags 0 q
  (scan.1,computedModelingSieveWork data p q+scan.2+4)

theorem computedModelingMultiplierTrace_value (data : List ℤ) (p q : ℕ) :
    (computedModelingMultiplierTrace data p q).1=computedModelingMultiplier data p q :=
  scanPrimeFlagsTrace_value _ _ _

/-- Nearlinear in allocated interval length, with an explicit cubic bit factor. -/
theorem computedModelingMultiplierTrace_work (data : List ℤ) (p q : ℕ)
    [Fact q.Prime] (hp : 8*data.length<p) :
    (computedModelingMultiplierTrace data p q).2≤
      340*data.length*(q.size+1)^3+28*(q+1)+9 := by
  have hs := computedModelingSieveWork_bound data p q
  have hm := computedModelingMarkSchedule_eighth data p q (Fact.out : q.Prime).one_lt hp
  have hscan := scanPrimeFlagsTrace_work (computedModelingFlags data p q) 0 q
  simp only [computedModelingFlags_size] at hscan
  dsimp only [computedModelingMultiplierTrace]
  omega

end Optss
