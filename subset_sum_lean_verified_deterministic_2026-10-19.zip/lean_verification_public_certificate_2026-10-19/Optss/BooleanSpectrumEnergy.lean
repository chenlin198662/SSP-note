import Optss.BooleanFourierArithmetic
import Optss.BooleanListIndexWork
import Optss.DyadicBogolyubovSpectrum

/-!
# Spectrum selection by exact Boolean integer energy comparison

The common threshold is computed once as m³Q². Each Fourier output uses
unsigned squares of its two stored magnitudes, followed by comparison with
8N times that energy. No rational division or normalization computes a test.
-/
namespace Optss

def bitFourierEnergy (z : BitFourierInteger) : List Bool :=
  bitListAdd (bitListMultiplication z.re.digits z.re.digits)
    (bitListMultiplication z.im.digits z.im.digits)

def bitSpectrumThreshold (ms qs : List Bool) : List Bool :=
  let m2 := bitListMultiplication ms ms
  let m3 := bitListMultiplication m2 ms
  let q2 := bitListMultiplication qs qs
  bitListMultiplication m3 q2

def bitSpectrumScale (ns : List Bool) : List Bool := false::false::false::ns

def bitSpectrumKeep (scale threshold : List Bool) (z : BitFourierInteger) : Bool :=
  bitListLE threshold (bitListMultiplication scale (bitFourierEnergy z))

theorem bitFourierEnergy_value (z : BitFourierInteger) :
    binaryDigitsValue (bitFourierEnergy z)=
      (binaryDigitsValue z.re.digits)^2+(binaryDigitsValue z.im.digits)^2 := by
  simp only [bitFourierEnergy,bitListAdd_correct,bitListMultiplication_correct,pow_two]

theorem bitSpectrumThreshold_value (ms qs : List Bool) :
    binaryDigitsValue (bitSpectrumThreshold ms qs)=(binaryDigitsValue ms)^3*(binaryDigitsValue qs)^2 := by
  simp only [bitSpectrumThreshold,bitListMultiplication_correct]
  ring

theorem bitSpectrumScale_value (ns : List Bool) :
    binaryDigitsValue (bitSpectrumScale ns)=8*binaryDigitsValue ns := by
  simp only [bitSpectrumScale,binaryDigitsValue,Bool.toNat_false,zero_add]
  ring

theorem bitFourierEnergy_rational (z : BitFourierInteger) (Q : ℕ) :
    rationalComplexEnergy ((z.value.re:ℚ)/(Q:ℚ),(z.value.im:ℚ)/(Q:ℚ))=
      ((binaryDigitsValue z.re.digits:ℚ)^2+(binaryDigitsValue z.im.digits:ℚ)^2)/(Q:ℚ)^2 := by
  have hre : (z.value.re:ℚ)^2=(binaryDigitsValue z.re.digits:ℚ)^2 := by
    change ((signedBitsValue z.re.negative z.re.digits:ℤ):ℚ)^2=_
    cases h : z.re.negative <;> simp [signedBitsValue,h]
  have him : (z.value.im:ℚ)^2=(binaryDigitsValue z.im.digits:ℚ)^2 := by
    change ((signedBitsValue z.im.negative z.im.digits:ℤ):ℚ)^2=_
    cases h : z.im.negative <;> simp [signedBitsValue,h]
  simp only [rationalComplexEnergy,div_pow,hre,him]
  exact (add_div _ _ _).symm

theorem bitSpectrumKeep_correct {N : ℕ} [NeZero N] (A : Finset (ZMod N))
    (ns ms qs : List Bool) (hn : binaryDigitsValue ns=N) (hm : binaryDigitsValue ms=A.card)
    (hq : 0<binaryDigitsValue qs) (z : BitFourierInteger) :
    bitSpectrumKeep (bitSpectrumScale ns) (bitSpectrumThreshold ms qs) z=true ↔
      2*rationalFourierEnergySlack A≤
        rationalComplexEnergy ((z.value.re:ℚ)/(binaryDigitsValue qs:ℚ),(z.value.im:ℚ)/(binaryDigitsValue qs:ℚ)) := by
  have hN : (0:ℚ)<N := Nat.cast_pos.mpr (NeZero.pos N)
  have hQ : (0:ℚ)<binaryDigitsValue qs := Nat.cast_pos.mpr hq
  have hslack : 2*rationalFourierEnergySlack A=(A.card:ℚ)^3/(8*N) := by
    unfold rationalFourierEnergySlack
    field_simp
    ring
  rw [bitSpectrumKeep,bitListLE_correct,bitListMultiplication_correct,
    bitSpectrumThreshold_value,bitSpectrumScale_value,bitFourierEnergy_value,hn,hm,
    bitFourierEnergy_rational,hslack,div_le_div_iff₀ (by positivity) (by positivity)]
  norm_cast
  rw [mul_comm ((binaryDigitsValue z.re.digits)^2+(binaryDigitsValue z.im.digits)^2)]
end Optss
