import Optss.SmallDoublingWideFilling
import Optss.FlooredDyadicBoxes

/-!
# Uniform constants for the long-sumset assembly

Finite suprema over the bounded rank range give common dyadic properness,
filling and growth-window constants. No monotonicity of dimension-dependent
boxing or properization factors is assumed.
-/
namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical

def longSumsetProperExponent (R : ℕ) : ℕ :=
  (Finset.range (R+1)).sup (fun e => ⌈(denseLatticeProperScale e)⁻¹⌉₊)

def longSumsetFillExponent (R : ℕ) : ℕ :=
  (Finset.range (R+1)).sup (fun e =>
    max (denseBoxSummandThreshold e (rankContainerDensity R))
      ⌈(denseLatticeFillingDilation e (rankContainerDensity R))⁻¹⌉₊)

def longSumsetDegreeWindow (R : ℕ) : ℕ :=
  (Finset.range (R+1)).sup (fun e =>
    2*properizationIterationFactor latticeReductionDefectBound 3 e*
      2^((longSumsetProperExponent R+longSumsetFillExponent R)*(e-1)))

def longSumsetUniformFillingDilation (R : ℕ) : ℝ :=
  ((2:ℝ)^longSumsetFillExponent R)⁻¹

theorem longSumsetUniformFillingDilation_pos (R : ℕ) :
    0<longSumsetUniformFillingDilation R := by unfold longSumsetUniformFillingDilation; positivity

theorem longSumsetProperExponent_spec (R e : ℕ) (he : 0<e) (heR : e≤R) :
    ((2:ℝ)^longSumsetProperExponent R)⁻¹≤denseLatticeProperScale e := by
  have hη := denseLatticeProperScale_pos he
  have hceil : ⌈(denseLatticeProperScale e)⁻¹⌉₊≤longSumsetProperExponent R :=
    Finset.le_sup (f := fun e => ⌈(denseLatticeProperScale e)⁻¹⌉₊)
      (Finset.mem_range.mpr (by omega))
  have hp : longSumsetProperExponent R≤2^longSumsetProperExponent R := Nat.lt_two_pow_self.le
  have hh := (Nat.le_ceil ((denseLatticeProperScale e)⁻¹)).trans
    (show (⌈(denseLatticeProperScale e)⁻¹⌉₊:ℝ)≤(2:ℝ)^longSumsetProperExponent R by exact_mod_cast hceil.trans hp)
  exact (inv_le_comm₀ (by positivity) hη).mpr hh

theorem longSumsetFillExponent_spec (R e : ℕ) (he : 0<e) (heR : e≤R) :
    denseBoxSummandThreshold e (rankContainerDensity R)≤2^longSumsetFillExponent R ∧
    1≤denseLatticeFillingDilation e (rankContainerDensity R)*
      (2:ℝ)^longSumsetFillExponent R ∧
    longSumsetUniformFillingDilation R≤denseLatticeFillingDilation e (rankContainerDensity R) := by
  have hγ := denseLatticeFillingDilation_pos he _ (rankContainerDensity_pos R)
  have hceil : max (denseBoxSummandThreshold e (rankContainerDensity R))
      ⌈(denseLatticeFillingDilation e (rankContainerDensity R))⁻¹⌉₊≤longSumsetFillExponent R :=
    Finset.le_sup (f := fun e => max (denseBoxSummandThreshold e (rankContainerDensity R))
      ⌈(denseLatticeFillingDilation e (rankContainerDensity R))⁻¹⌉₊)
      (Finset.mem_range.mpr (by omega))
  have hp : longSumsetFillExponent R≤2^longSumsetFillExponent R := Nat.lt_two_pow_self.le
  have hnat := hceil.trans hp
  have hi := (le_max_right _ _).trans hnat
  have hh := (Nat.le_ceil ((denseLatticeFillingDilation e (rankContainerDensity R))⁻¹)).trans
    (show (⌈(denseLatticeFillingDilation e (rankContainerDensity R))⁻¹⌉₊:ℝ)≤
      (2:ℝ)^longSumsetFillExponent R by exact_mod_cast hi)
  refine ⟨(le_max_left _ _).trans hnat,?_,?_⟩
  · simpa only [mul_inv_cancel₀ hγ.ne'] using mul_le_mul_of_nonneg_left hh hγ.le
  · exact (inv_le_comm₀ (by positivity) hγ).mpr hh

theorem longSumsetDegreeWindow_spec (R e : ℕ) (heR : e≤R) :
    2*(properizationIterationFactor latticeReductionDefectBound 3 e:ℝ)*
      (2:ℝ)^((longSumsetProperExponent R+longSumsetFillExponent R)*(e-1))≤
        longSumsetDegreeWindow R := by
  have hh : 2*properizationIterationFactor latticeReductionDefectBound 3 e*
      2^((longSumsetProperExponent R+longSumsetFillExponent R)*(e-1))≤longSumsetDegreeWindow R :=
    Finset.le_sup (f := fun e => 2*properizationIterationFactor latticeReductionDefectBound 3 e*
      2^((longSumsetProperExponent R+longSumsetFillExponent R)*(e-1)))
      (Finset.mem_range.mpr (by omega))
  exact_mod_cast hh

/-- The parameters needed by the final growth/filling profile, bundled. -/
theorem long_sumset_uniform_parameters (R : ℕ) :
    ∃ v w L : ℕ, ∃ γlow : ℝ, 0<γlow ∧ ∀ e : ℕ, 0<e → e≤R →
      ((2:ℝ)^v)⁻¹≤denseLatticeProperScale e ∧
      denseBoxSummandThreshold e (rankContainerDensity R)≤2^w ∧
      1≤denseLatticeFillingDilation e (rankContainerDensity R)*(2:ℝ)^w ∧
      2*(properizationIterationFactor latticeReductionDefectBound 3 e:ℝ)*
        (2:ℝ)^((v+w)*(e-1))≤L ∧
      γlow≤denseLatticeFillingDilation e (rankContainerDensity R) := by
  refine ⟨longSumsetProperExponent R,longSumsetFillExponent R,longSumsetDegreeWindow R,
    longSumsetUniformFillingDilation R,longSumsetUniformFillingDilation_pos R,?_⟩
  intro e he heR
  have hf := longSumsetFillExponent_spec R e he heR
  exact ⟨longSumsetProperExponent_spec R e he heR,hf.1,hf.2.1,
    longSumsetDegreeWindow_spec R e heR,hf.2.2⟩

end
end Optss
