import Optss.CountLiveTypes
import Optss.CoefficientBounds

/-!
# Exact index counts for the actual counted preparation

The bounds in this file concern the very subtype indices used by the live
orthant computation after capacity preprocessing. They count monomial summands,
prepared levels and Newton product summands. These counts are not arithmetic
operation or bit-complexity bounds; those additionally depend on representation,
coefficient sizes and the cost of polynomial multiplication.
-/

namespace Optss
open scoped BigOperators Classical
noncomputable section

variable {ι : Type*} [Fintype ι] {d : ℕ}

/-- Exactly the nested subtype used by the live per-orthant computation after
`correctionCapacity` has discarded and capped the original types. -/
abbrev LiveCorrectionOrthant (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool) :=
  {i : {i // coordinateOrthant (v i) = ε} //
    correctionCapacity v c (fun j => (Δ j : ℤ)) kcap i ≠ 0}

/-- The stored capacity of an actual live orthant type. -/
def liveCorrectionCount (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool)
    (i : LiveCorrectionOrthant v c Δ kcap ε) : ℕ :=
  correctionCapacity v c (fun j => (Δ j : ℤ)) kcap i.val.val

omit [Fintype ι] in
/-- A nonzero preprocessed capacity certifies that the type lies in the box. -/
theorem correctionCapacity_ne_zero_inBox (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : IntVec d) (kcap : ℕ) (i : ι)
    (hi : correctionCapacity v c Δ kcap i ≠ 0) : InBox Δ (v i) := by
  classical
  by_contra hbox
  exact hi (by simp [correctionCapacity, hbox])

omit [Fintype ι] in
theorem liveCorrectionCount_pos_le (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool)
    (i : LiveCorrectionOrthant v c Δ kcap ε) :
    0 < liveCorrectionCount v c Δ kcap ε i ∧ liveCorrectionCount v c Δ kcap ε i ≤ kcap :=
  ⟨Nat.pos_of_ne_zero i.property,
    (correctionCapacity_le v c (fun j => (Δ j : ℤ)) kcap i.val.val).2⟩

omit [Fintype ι] in
/-- Absolute exponents of all live types lie in the prepared exponent box. -/
theorem liveCorrectionExponent_le (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool)
    (i : LiveCorrectionOrthant v c Δ kcap ε) : absoluteExponent (v i.val.val) ≤ Δ := by
  intro j
  have h := correctionCapacity_ne_zero_inBox v c (fun j => (Δ j : ℤ)) kcap i.val.val i.property j
  change (v i.val.val j).natAbs ≤ Δ j
  exact_mod_cast (show ((v i.val.val j).natAbs : ℤ) ≤ Δ j by simpa only [Int.natCast_natAbs] using h)

/-- Distinct original types imply the product-volume bound for the exact live
subtype on which each local Newton table is actually computed. -/
theorem liveCorrectionOrthant_card_le (v : ι → IntVec d) (hinj : Function.Injective v)
    (c : ι → ℕ) (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool) :
    Fintype.card (LiveCorrectionOrthant v c Δ kcap ε) ≤ ∏ j, (Δ j + 1) := by
  apply card_types_le_orthant_box (fun i : LiveCorrectionOrthant v c Δ kcap ε => v i.val.val)
    ?_ ε ?_ Δ (liveCorrectionExponent_le v c Δ kcap ε)
  · intro i j he
    apply Subtype.ext
    apply Subtype.ext
    exact hinj he
  · intro i
    simpa only [i.val.property] using inOrthant_coordinateOrthant (v i.val.val)

/-- Total available copies used in coefficient-size analysis are bounded without
constructing the copies in the computation. -/
theorem liveCorrectionOrthant_total_le (v : ι → IntVec d) (hinj : Function.Injective v)
    (c : ι → ℕ) (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool) :
    (∑ i : LiveCorrectionOrthant v c Δ kcap ε, liveCorrectionCount v c Δ kcap ε i) ≤
      kcap * ∏ j, (Δ j + 1) := by
  exact capped_total_le _ kcap _ (fun i => (liveCorrectionCount_pos_le v c Δ kcap ε i).2)
    (liveCorrectionOrthant_card_le v hinj c Δ kcap ε)

/-- The monomial table used by the live local support, with the original type
indices physically restricted to nonzero preprocessed capacities. -/
def liveOrthantPowerTable (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool) : List (MvPolynomial (Fin d) ℤ) :=
  monomialPowerTable Δ (liveCorrectionCount v c Δ kcap ε)
    (fun i => absoluteExponent (v i.val.val)) kcap

/-- This is exactly the power table inside the already verified operational support. -/
theorem liveDecodedCountOrthantSupport_table (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool) :
    liveDecodedCountOrthantSupport v
      (correctionCapacity v c (fun j => (Δ j : ℤ)) kcap) Δ kcap ε =
    (∑ k ∈ Finset.range (kcap + 1),
      (newtonTable Δ (liveOrthantPowerTable v c Δ kcap ε) kcap).getD k 0).support.image
        (orthantDecode ε) := by
  rfl

/-- Preparation includes levels zero through `kcap`; level zero is currently
stored even though the Newton updates read only positive power indices. -/
theorem liveOrthantPowerTable_length (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool) :
    (liveOrthantPowerTable v c Δ kcap ε).length = kcap + 1 := by
  simp [liveOrthantPowerTable, monomialPowerTable]

/-- Each pair indexes one monomial summand in the actual power-table definition:
a prepared level and a live original type. -/
def liveMonomialPreparationIndices (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool) :
    Finset (ℕ × LiveCorrectionOrthant v c Δ kcap ε) :=
  (Finset.range (kcap + 1)) ×ˢ Finset.univ

theorem liveMonomialPreparationIndices_card (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool) :
    (liveMonomialPreparationIndices v c Δ kcap ε).card =
      (kcap + 1) * Fintype.card (LiveCorrectionOrthant v c Δ kcap ε) := by
  simp [liveMonomialPreparationIndices]

theorem liveMonomialPreparationIndices_card_le (v : ι → IntVec d) (hinj : Function.Injective v)
    (c : ι → ℕ) (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool) :
    (liveMonomialPreparationIndices v c Δ kcap ε).card ≤ (kcap + 1) * ∏ j, (Δ j + 1) := by
  rw [liveMonomialPreparationIndices_card]
  exact Nat.mul_le_mul_left _ (liveCorrectionOrthant_card_le v hinj c Δ kcap ε)

/-- Total number of live type indices across every orthant. -/
theorem all_liveCorrectionOrthant_card_le (v : ι → IntVec d) (hinj : Function.Injective v)
    (c : ι → ℕ) (Δ : Fin d →₀ ℕ) (kcap : ℕ) :
    (∑ ε : Fin d → Bool, Fintype.card (LiveCorrectionOrthant v c Δ kcap ε)) ≤
      2 ^ d * ∏ j, (Δ j + 1) := by
  calc
    _ ≤ ∑ _ε : Fin d → Bool, ∏ j, (Δ j + 1) :=
      Finset.sum_le_sum (fun ε _ => liveCorrectionOrthant_card_le v hinj c Δ kcap ε)
    _ = _ := by simp [Fintype.card_fun]

/-- Total multiplicity represented in the bounded local coefficient analysis. -/
theorem all_liveCorrectionOrthant_total_le (v : ι → IntVec d) (hinj : Function.Injective v)
    (c : ι → ℕ) (Δ : Fin d →₀ ℕ) (kcap : ℕ) :
    (∑ ε : Fin d → Bool,
      ∑ i : LiveCorrectionOrthant v c Δ kcap ε, liveCorrectionCount v c Δ kcap ε i) ≤
      2 ^ d * (kcap * ∏ j, (Δ j + 1)) := by
  calc
    _ ≤ ∑ _ε : Fin d → Bool, kcap * ∏ j, (Δ j + 1) :=
      Finset.sum_le_sum (fun ε _ => liveCorrectionOrthant_total_le v hinj c Δ kcap ε)
    _ = _ := by simp [Fintype.card_fun]

/-- Exact total number of prepared entries in the local power tables. -/
theorem all_liveOrthantPowerTable_lengths (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) :
    (∑ ε : Fin d → Bool, (liveOrthantPowerTable v c Δ kcap ε).length) =
      2 ^ d * (kcap + 1) := by
  simp [liveOrthantPowerTable_length, Fintype.card_fun]

/-- Total monomial summands generated before truncating all prepared power sums. -/
theorem all_liveMonomialPreparationIndices_card_le (v : ι → IntVec d)
    (hinj : Function.Injective v) (c : ι → ℕ) (Δ : Fin d →₀ ℕ) (kcap : ℕ) :
    (∑ ε : Fin d → Bool, (liveMonomialPreparationIndices v c Δ kcap ε).card) ≤
      2 ^ d * ((kcap + 1) * ∏ j, (Δ j + 1)) := by
  calc
    _ ≤ ∑ _ε : Fin d → Bool, (kcap + 1) * ∏ j, (Δ j + 1) :=
      Finset.sum_le_sum (fun ε _ => liveMonomialPreparationIndices_card_le v hinj c Δ kcap ε)
    _ = _ := by simp [Fintype.card_fun]

/-- Each orthant performs the exact triangular number of Newton product summands. -/
theorem all_newton_table_product_summands (d kcap : ℕ) :
    (∑ _ε : Fin d → Bool, ∑ k ∈ Finset.range (kcap + 1), (Finset.Icc 1 k).card) =
      2 ^ d * (kcap * (kcap + 1) / 2) := by
  calc
    _ = ∑ _ε : Fin d → Bool, kcap * (kcap + 1) / 2 := by
      apply Finset.sum_congr rfl
      intro ε _
      exact newton_table_product_summands kcap
    _ = _ := by simp [Fintype.card_fun]

/-- A polynomial upper bound on that exact product-summand count. This counts
terms, not the cost of multiplying the polynomials in those terms. -/
theorem all_newton_table_product_summands_le (d kcap : ℕ) :
    (∑ _ε : Fin d → Bool, ∑ k ∈ Finset.range (kcap + 1), (Finset.Icc 1 k).card) ≤
      2 ^ d * (kcap * (kcap + 1)) := by
  rw [all_newton_table_product_summands]
  exact Nat.mul_le_mul_left _ (Nat.div_le_self _ _)

/-- The coefficient-size theorem now applies directly to each actual live table,
with the volume derived from distinctness and preprocessing rather than assumed. -/
theorem live_countNewtonTable_coeff_bits (v : ι → IntVec d) (hinj : Function.Injective v)
    (c : ι → ℕ) (Δ e : Fin d →₀ ℕ) (kcap k : ℕ) (hkcap : 0 < kcap) (hk : k ≤ kcap)
    (ε : Fin d → Bool) :
    (MvPolynomial.coeff e
      ((countNewtonTable Δ (liveCorrectionCount v c Δ kcap ε)
        (fun i => MvPolynomial.monomial (absoluteExponent (v i.val.val)) (1 : ℤ)) kcap).getD k 0)).natAbs.size ≤
      kcap * (kcap * ∏ j, (Δ j + 1)).size := by
  apply countNewtonTable_coeff_bits _ _ Δ e kcap _ k hkcap ?_ ?_ ?_ hk
  · exact Finset.prod_pos (fun j _ => Nat.succ_pos _)
  · intro i
    exact (liveCorrectionCount_pos_le v c Δ kcap ε i).2
  · exact liveCorrectionOrthant_card_le v hinj c Δ kcap ε

end
end Optss
