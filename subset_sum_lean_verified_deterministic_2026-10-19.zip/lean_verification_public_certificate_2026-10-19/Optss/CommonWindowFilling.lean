import Optss.CommonReserveCoordinateModel
import Optss.CommonPhaseBudget

/-!
# An actual common block window supplies the reserve and remainder

This composes the finite greedy block iteration, its genuine common-lattice
window, whole-lattice boxing, and dense-box filling. The partition and every
coordinate witness refer to the original labels of that iteration.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1400000

namespace BoundedBlockSelector
variable {ι : Type} [DecidableEq ι] {d : ℕ} {v : ι → IntVec d}
  {initial : Finset ι} {B : ℕ}

/-- The labels before, inside, and after the actual window form an exact
pairwise disjoint partition. -/
theorem window_partition (F : BoundedBlockSelector v initial B) (start ℓ : ℕ) :
    initial = (initial \ F.remaining start) ∪ (F.reserve start ℓ ∪ F.remaining (start+ℓ)) ∧
    Disjoint (initial \ F.remaining start) (F.reserve start ℓ ∪ F.remaining (start+ℓ)) ∧
    Disjoint (F.reserve start ℓ) (F.remaining (start+ℓ)) := by
  have hr := F.reserve_subset start ℓ
  rw [F.remaining_after_reserve]
  have he : F.reserve start ℓ ∪ (F.remaining start \ F.reserve start ℓ) = F.remaining start :=
    Finset.union_sdiff_of_subset hr
  exact ⟨by rw [he, Finset.sdiff_union_of_subset (F.remaining_subset start)],
    he.symm ▸ Finset.sdiff_disjoint, Finset.disjoint_sdiff⟩

/-- Every dense common-lattice window gives a true coordinate reserve,
proper on the same filled dilation, and a remainder robust under further
bounded deletions. Block density and lattice stability are supplied by the
actual window theorem, rather than assumed for the final coordinate model. -/
theorem dense_window_coordinate_model (F : BoundedBlockSelector v initial B)
    (hd : 0 < d) (scalar : ι → ℤ) (ρ : IntVec d →+ ℤ)
    (hrepr : ∀ i ∈ initial, ρ (v i) = scalar i)
    (w : Fin d → ℕ) (hbox : ∀ i ∈ initial, InCenteredBox w (v i))
    (h M n ℓ k extra K : ℕ) (hh : 1 ≤ h) (hK : 1 ≤ K)
    (hBK : max h B ≤ K*h)
    (hρ : Set.InjOn ρ (integerBudgetBox (fun j => 20*h*w j)))
    (C : ℝ) (hC : 0 < C)
    (hvolume : ((integerBudgetBox (fun j => h*w j)).card : ℝ) ≤ C*M)
    (hbudget : n*B+extra ≤ k)
    (hprotected : ∀ deleted : Finset ι, deleted.card ≤ k →
      labelSpan ℝ (fun i => realVector (v i)) (initial \ deleted) = ⊤)
    (hlength : (Nat.log 2 (d.factorial*∏ j, w j)+1)*ℓ ≤ n)
    (hℓ : 0 < ℓ)
    (hℓbound : denseBoxSummandThreshold d (commonBoxBlockDensity d K C) ≤ ℓ)
    (hwidth : denseBoxWidthThreshold (commonBoxBlockDensity d K C) ≤ 2*h+1)
    (hwindow : DenseCommonBlockWindow F w ℓ M) :
    ∃ b ≤ Nat.log 2 (d.factorial*∏ j, w j),
      (initial \ F.remaining (b*ℓ)).card ≤ Nat.log 2 (d.factorial*∏ j, w j)*ℓ*B ∧
      (F.reserve (b*ℓ) ℓ).card ≤ ℓ*B ∧
      initial = (initial \ F.remaining (b*ℓ)) ∪
        (F.reserve (b*ℓ) ℓ ∪ F.remaining (b*ℓ+ℓ)) ∧
      Disjoint (initial \ F.remaining (b*ℓ))
        (F.reserve (b*ℓ) ℓ ∪ F.remaining (b*ℓ+ℓ)) ∧
      Disjoint (F.reserve (b*ℓ) ℓ) (F.remaining (b*ℓ+ℓ)) ∧
      Nonempty (CommonReserveCoordinateModel d scalar (F.remaining (b*ℓ))
        (F.reserve (b*ℓ) ℓ) (F.remaining (b*ℓ+ℓ)) h extra (commonBoxFilledScale d K C ℓ)) := by
  obtain ⟨b, hb, hlat, hgood, _, hdeleted⟩ := hwindow
  have hend : b*ℓ+ℓ ≤ n := by
    calc
      _ = (b+1)*ℓ := by ring
      _ ≤ (Nat.log 2 (d.factorial*∏ j, w j)+1)*ℓ := Nat.mul_le_mul_right ℓ (Nat.add_le_add_right hb 1)
      _ ≤ n := hlength
  have hstart : b*ℓ ≤ n := (Nat.le_add_right _ _).trans hend
  have hfull := F.remaining_full_rank n k ((Nat.le_add_right (n*B) extra).trans hbudget) hprotected
  have hgen := F.reserve_generated (b*ℓ) ℓ hℓ (by simpa only [Nat.add_zero] using (hgood 0 hℓ).2.2.1)
  obtain ⟨hp, hdisE, hdisR⟩ := F.window_partition (b*ℓ) ℓ
  refine ⟨b, hb, hdeleted.trans (Nat.mul_le_mul_right B (Nat.mul_le_mul_right ℓ hb)),
    F.reserve_card_le _ _, hp, hdisE, hdisR, ?_⟩
  apply common_reserve_coordinate_model hd v scalar (F.remaining (b*ℓ))
    (F.reserve (b*ℓ) ℓ) (F.remaining (b*ℓ+ℓ)) (F.reserve_subset _ _)
    (F.remaining_antitone (Nat.le_add_right _ _)) (hfull _ hstart) w
    (fun i hi => hbox i (F.remaining_subset _ hi)) ρ
    (fun i hi => hrepr i (F.remaining_subset _ hi)) h (max h B) K M ℓ extra hh
    (le_max_left _ _) hK hBK hρ C hC hvolume
    (fun i => (F.block (b*ℓ+i)).sums)
  · intro i hi x hx j
    exact (F.block_sums_box w hbox _ x hx j).trans (by
      dsimp only
      exact_mod_cast Nat.mul_le_mul_right (w j) (le_max_right h B))
  · exact fun i hi => (hgood i hi).2.1
  · exact fun i hi => (hgood i hi).1
  · exact fun i hi => (hgood i hi).2.2.1
  · exact F.reserve_support _ _
  · exact hgen
  · exact hlat ℓ le_rfl
  · exact F.remaining_protected (b*ℓ+ℓ) extra k
      ((Nat.add_le_add_right (Nat.mul_le_mul_right B hend) extra).trans hbudget) hprotected
  · exact hℓ
  · exact hℓbound
  · exact hwidth.trans (by omega)

end BoundedBlockSelector
end
end Optss
