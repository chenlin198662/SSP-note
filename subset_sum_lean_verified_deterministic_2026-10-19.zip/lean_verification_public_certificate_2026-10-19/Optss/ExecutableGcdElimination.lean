import Optss.PrimitiveQuotient
import Mathlib.Data.Int.GCD

/-!
# Executable unimodular elimination of an integer direction

Every two-coordinate update is given by the extended Euclidean algorithm
and an explicit integral inverse. A finite deterministic pass eliminates
all coordinates except a designated pivot. No basis-choice oracle occurs
in this construction. Bit-operation refinement is a separate stage.
-/
namespace Optss
variable {d : ℕ}

/-- The divided Bézout identity used by the unimodular update. -/
theorem gcd_divided_bezout (x y : ℤ) (hg : Int.gcd x y≠0) :
    Int.gcdA x y*(x/(Int.gcd x y:ℤ))+Int.gcdB x y*(y/(Int.gcd x y:ℤ))=1 := by
  have hx := Int.ediv_mul_cancel (show (Int.gcd x y:ℤ)∣x from Int.gcd_dvd_left)
  have hy := Int.ediv_mul_cancel (show (Int.gcd x y:ℤ)∣y from Int.gcd_dvd_right)
  have hb := Int.gcd_eq_gcd_ab x y
  have hg' : (Int.gcd x y:ℤ)≠0 := by exact_mod_cast hg
  apply mul_right_cancel₀ hg'
  rw [add_mul,mul_assoc,mul_assoc,hx,hy,one_mul]
  linarith

def integerGcdPairEquiv (x y : ℤ) : (ℤ×ℤ) ≃ₗ[ℤ] (ℤ×ℤ) :=
  if hg : Int.gcd x y=0 then LinearEquiv.refl ℤ _ else
  { toFun := fun z => (Int.gcdA x y*z.1+Int.gcdB x y*z.2,
        -(y/(Int.gcd x y:ℤ))*z.1+(x/(Int.gcd x y:ℤ))*z.2)
    invFun := fun z => ((x/(Int.gcd x y:ℤ))*z.1-Int.gcdB x y*z.2,
        (y/(Int.gcd x y:ℤ))*z.1+Int.gcdA x y*z.2)
    left_inv := by
      intro z
      have hb := gcd_divided_bezout x y hg
      apply Prod.ext <;> dsimp only
      · linear_combination z.1*hb
      · linear_combination z.2*hb
    right_inv := by
      intro z
      have hb := gcd_divided_bezout x y hg
      apply Prod.ext <;> dsimp only
      · linear_combination z.1*hb
      · linear_combination z.2*hb
    map_add' := by intro z w; apply Prod.ext <;> simp only [Prod.fst_add,Prod.snd_add] <;> ring
    map_smul' := by intro a z; apply Prod.ext <;> simp only [Prod.smul_fst,Prod.smul_snd,smul_eq_mul,RingHom.id_apply] <;> ring }

theorem integerGcdPairEquiv_input (x y : ℤ) :
    integerGcdPairEquiv x y (x,y)=((Int.gcd x y:ℤ),0) := by
  unfold integerGcdPairEquiv
  split_ifs with hg
  · obtain ⟨rfl,rfl⟩ := Int.gcd_eq_zero_iff.mp hg
    simp
  · have hx := Int.ediv_mul_cancel (show (Int.gcd x y:ℤ)∣x from Int.gcd_dvd_left)
    have hy := Int.ediv_mul_cancel (show (Int.gcd x y:ℤ)∣y from Int.gcd_dvd_right)
    have hb := Int.gcd_eq_gcd_ab x y
    have hg' : (Int.gcd x y:ℤ)≠0 := by exact_mod_cast hg
    apply Prod.ext <;> dsimp only
    · change Int.gcdA x y*x+Int.gcdB x y*y=(Int.gcd x y:ℤ)
      linarith
    · apply mul_right_cancel₀ hg'
      calc
        (-(y/(Int.gcd x y:ℤ))*x+(x/(Int.gcd x y:ℤ))*y)*(Int.gcd x y:ℤ)=
          -x*((y/(Int.gcd x y:ℤ))*(Int.gcd x y:ℤ))+y*((x/(Int.gcd x y:ℤ))*(Int.gcd x y:ℤ)) := by ring
        _=0*(Int.gcd x y:ℤ) := by rw [hx,hy]; ring

/-- Apply a two-dimensional integral automorphism to two distinct coordinates. -/
def integerCoordinatePairEquiv (i j : Fin d) (hij : i≠j)
    (e : (ℤ×ℤ) ≃ₗ[ℤ] (ℤ×ℤ)) : (Fin d→ℤ) ≃ₗ[ℤ] (Fin d→ℤ) where
  toFun z k := if k=i then (e (z i,z j)).1 else if k=j then (e (z i,z j)).2 else z k
  invFun z k := if k=i then (e.symm (z i,z j)).1 else if k=j then (e.symm (z i,z j)).2 else z k
  left_inv z := by
    funext k
    by_cases hki : k=i
    · subst k
      simp only [ite_true,Ne.symm hij,ite_false]
      exact congrArg Prod.fst (e.symm_apply_apply (z i,z j))
    · by_cases hkj : k=j
      · subst k
        simp only [ite_true,Ne.symm hij,ite_false]
        exact congrArg Prod.snd (e.symm_apply_apply (z i,z j))
      · simp only [hki,hkj,ite_false]
  right_inv z := by
    funext k
    by_cases hki : k=i
    · subst k
      simp only [ite_true,Ne.symm hij,ite_false]
      exact congrArg Prod.fst (e.apply_symm_apply (z i,z j))
    · by_cases hkj : k=j
      · subst k
        simp only [ite_true,Ne.symm hij,ite_false]
        exact congrArg Prod.snd (e.apply_symm_apply (z i,z j))
      · simp only [hki,hkj,ite_false]
  map_add' z w := by
    funext k
    have he : e (z i+w i,z j+w j)=e (z i,z j)+e (w i,w j) := e.map_add (z i,z j) (w i,w j)
    dsimp only [Pi.add_apply]
    split_ifs <;> simp only [he,Prod.fst_add,Prod.snd_add]
  map_smul' a z := by
    funext k
    have he : e (a*z i,a*z j)=a • e (z i,z j) := e.map_smul a (z i,z j)
    dsimp only [Pi.smul_apply,smul_eq_mul,RingHom.id_apply]
    split_ifs <;> simp only [he,Prod.smul_fst,Prod.smul_snd,smul_eq_mul]

def integerEliminateCoordinate (z : Fin d→ℤ) (pivot j : Fin d) :
    (Fin d→ℤ) ≃ₗ[ℤ] (Fin d→ℤ) :=
  if h : pivot=j then LinearEquiv.refl ℤ _ else
    integerCoordinatePairEquiv pivot j h (integerGcdPairEquiv (z pivot) (z j))

theorem integerEliminateCoordinate_target (z : Fin d→ℤ) (pivot j : Fin d) (hj : j≠pivot) :
    integerEliminateCoordinate z pivot j z j=0 := by
  simp only [integerEliminateCoordinate,Ne.symm hj,↓reduceDIte,integerCoordinatePairEquiv,
    LinearEquiv.coe_mk,LinearMap.coe_mk,AddHom.coe_mk,hj,ite_false,ite_true]
  exact congrArg Prod.snd (integerGcdPairEquiv_input (z pivot) (z j))

theorem integerEliminateCoordinate_preserves_zero (z : Fin d→ℤ) (pivot j k : Fin d)
    (hk : k≠pivot) (hz : z k=0) : integerEliminateCoordinate z pivot j z k=0 := by
  by_cases hj : pivot=j
  · simp [integerEliminateCoordinate,hj,hz]
  · by_cases hkj : k=j
    · subst k; exact integerEliminateCoordinate_target z pivot j hk
    · simp [integerEliminateCoordinate,hj,integerCoordinatePairEquiv,hk,hkj,hz]

def integerGcdElimination (z : Fin d→ℤ) (pivot : Fin d) : List (Fin d) → (Fin d→ℤ) ≃ₗ[ℤ] (Fin d→ℤ)
  | [] => LinearEquiv.refl ℤ _
  | j::js =>
    let step := integerEliminateCoordinate z pivot j
    step.trans (integerGcdElimination (step z) pivot js)

theorem integerGcdElimination_preserves_zero (z : Fin d→ℤ) (pivot k : Fin d)
    (js : List (Fin d)) (hk : k≠pivot) (hz : z k=0) :
    integerGcdElimination z pivot js z k=0 := by
  induction js generalizing z with
  | nil => exact hz
  | cons j js ih =>
    exact ih (integerEliminateCoordinate z pivot j z)
      (integerEliminateCoordinate_preserves_zero z pivot j k hk hz)

theorem integerGcdElimination_eliminates (z : Fin d→ℤ) (pivot k : Fin d)
    (js : List (Fin d)) (hk : k≠pivot) (hmem : k∈js) :
    integerGcdElimination z pivot js z k=0 := by
  induction js generalizing z with
  | nil => simp at hmem
  | cons j js ih =>
    rcases List.mem_cons.mp hmem with rfl | hmem
    · exact integerGcdElimination_preserves_zero _ pivot k js hk
        (integerEliminateCoordinate_target z pivot k hk)
    · exact ih _ hmem

/-- A deterministic integer automorphism; the only arithmetic in its
executable path is extended gcd, exact division, addition and multiplication. -/
def integerDirectionEquiv (z : Fin (d+1)→ℤ) : (Fin (d+1)→ℤ) ≃ₗ[ℤ] (Fin (d+1)→ℤ) :=
  integerGcdElimination z 0 (List.ofFn id)

theorem integerDirectionEquiv_tail (z : Fin (d+1)→ℤ) (j : Fin d) :
    integerDirectionEquiv z z j.succ=0 := by
  exact integerGcdElimination_eliminates z 0 j.succ (List.ofFn id)
    (Fin.succ_ne_zero j) (List.mem_ofFn.mpr ⟨j.succ,rfl⟩)

end Optss
