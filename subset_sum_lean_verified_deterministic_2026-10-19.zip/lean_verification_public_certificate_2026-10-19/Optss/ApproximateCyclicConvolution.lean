import Optss.CyclicRadixTwo
import Optss.FiniteFourierConvolution

/-! Stability of the three-transform convolution formula. This perturbation
lemma is deliberately separate from the actual fixed-point implementation. -/
namespace Optss
open scoped BigOperators
variable {N : ℕ} [NeZero N]

theorem cyclic_dft_norm_le (f : ZMod N → ℂ) (B : ℝ)
    (hf : ∀ j, ‖f j‖≤B) (k : ZMod N) : ‖ZMod.dft f k‖≤(N : ℝ)*B := by
  rw [ZMod.dft_apply]
  calc
    _ ≤ ∑ j : ZMod N, B := norm_sum_le_of_le _ (fun j _ => by
      simpa only [smul_eq_mul,norm_mul,AddChar.norm_apply,one_mul] using hf j)
    _ = _ := by simp [ZMod.card]

theorem cyclic_dft_distance_le (f g : ZMod N → ℂ) (B : ℝ)
    (hfg : ∀ j, ‖f j-g j‖≤B) (k : ZMod N) :
    ‖ZMod.dft f k-ZMod.dft g k‖≤(N : ℝ)*B := by
  have h := cyclic_dft_norm_le (f-g) B hfg k
  simpa only [map_sub,Pi.sub_apply] using h

theorem cyclic_convolution_three_dft (f g : ZMod N → ℂ) (k : ZMod N) :
    ZMod.dft (fun j => ZMod.dft f j*ZMod.dft g j) (-k)/(N : ℂ)=
      cyclicConvolution f g k := by
  rw [← cyclic_dft_convolution,ZMod.dft_dft]
  simp only [neg_neg,smul_eq_mul]
  have hN : (N : ℂ)≠0 := Nat.cast_ne_zero.mpr (NeZero.ne N)
  field_simp

theorem complex_product_error (a a' b b' : ℂ) :
    ‖a*b-a'*b'‖≤‖a-a'‖*‖b‖+‖a'‖*‖b-b'‖ := by
  have he : a*b-a'*b'=(a-a')*b+a'*(b-b') := by ring
  rw [he]
  exact (norm_add_le _ _).trans (by rw [norm_mul,norm_mul])

theorem cyclicConvolution_norm_le (f g : ZMod N → ℂ) (B C : ℝ)
    (hB : 0≤B) (hf : ∀ j, ‖f j‖≤B) (hg : ∀ j, ‖g j‖≤C) (k : ZMod N) :
    ‖cyclicConvolution f g k‖≤(N : ℝ)*B*C := by
  unfold cyclicConvolution
  calc
    _ ≤ ∑ j : ZMod N, B*C := norm_sum_le_of_le _ (fun j _ => by
      rw [norm_mul]
      exact mul_le_mul (hf j) (hg (k-j)) (norm_nonneg _) hB)
    _ = _ := by simp [ZMod.card,mul_assoc]

theorem cyclicConvolution_distance_le (f f' g g' : ZMod N → ℂ) (B C ε δ : ℝ)
    (hB : 0≤B) (hε : 0≤ε) (hf : ∀ j, ‖f' j‖≤B) (hg : ∀ j, ‖g j‖≤C)
    (hff : ∀ j, ‖f j-f' j‖≤ε) (hgg : ∀ j, ‖g j-g' j‖≤δ) (k : ZMod N) :
    ‖cyclicConvolution f g k-cyclicConvolution f' g' k‖≤(N : ℝ)*(ε*C+B*δ) := by
  unfold cyclicConvolution
  rw [← Finset.sum_sub_distrib]
  calc
    _ ≤ ∑ j : ZMod N, (ε*C+B*δ) := norm_sum_le_of_le _ (fun j _ =>
      (complex_product_error _ _ _ _).trans (add_le_add
        (mul_le_mul (hff j) (hg (k-j)) (norm_nonneg _) hε)
        (mul_le_mul (hf j) (hgg (k-j)) (norm_nonneg _) hB)))
    _ = _ := by simp [ZMod.card]; ring

/-- The error contains exactly one vanishing factor E. No FFT accuracy
or construction is postulated here; the concrete radix-two theorem below
will supply this reusable operator estimate. -/
theorem approximate_cyclic_convolution
    (F : (ZMod N → ℂ) → (ZMod N → ℂ)) (E B : ℝ) (hE : 0≤E) (hB : 0≤B)
    (hF : ∀ h R, 0≤R → (∀ j, ‖h j‖≤R) → ∀ k, ‖F h k-ZMod.dft h k‖≤E*R)
    (f g : ZMod N → ℂ) (hf : ∀ j, ‖f j‖≤B) (hg : ∀ j, ‖g j‖≤B)
    (k : ZMod N) :
    ‖F (fun j => F f j*F g j) (-k)/(N : ℂ)-cyclicConvolution f g k‖≤
      E*(2*(N : ℝ)+E)*B^2+(E/(N : ℝ))*((N : ℝ)+E)^2*B^2 := by
  have hN : (0 : ℝ)<N := Nat.cast_pos.mpr (NeZero.pos N)
  have hf' : ∀ j, ‖F f j‖≤((N : ℝ)+E)*B := by
    intro j
    have h := norm_sub_norm_le (F f j) (ZMod.dft f j)
    have ha := hF f B hB hf j
    have hb := cyclic_dft_norm_le f B hf j
    nlinarith
  have hg' : ∀ j, ‖F g j‖≤((N : ℝ)+E)*B := by
    intro j
    have h := norm_sub_norm_le (F g j) (ZMod.dft g j)
    have ha := hF g B hB hg j
    have hb := cyclic_dft_norm_le g B hg j
    nlinarith
  have hprod : ∀ j, ‖F f j*F g j‖≤((N : ℝ)+E)^2*B^2 := by
    intro j
    rw [norm_mul]
    calc
      _ ≤ (((N : ℝ)+E)*B)*(((N : ℝ)+E)*B) := mul_le_mul (hf' j) (hg' j) (norm_nonneg _) (by positivity)
      _ = _ := by ring
  have hprodErr : ∀ j, ‖F f j*F g j-ZMod.dft f j*ZMod.dft g j‖≤E*(2*(N : ℝ)+E)*B^2 := by
    intro j
    calc
      _ ≤ ‖F f j-ZMod.dft f j‖*‖F g j‖+‖ZMod.dft f j‖*‖F g j-ZMod.dft g j‖ :=
        complex_product_error _ _ _ _
      _ ≤ (E*B)*(((N : ℝ)+E)*B)+((N : ℝ)*B)*(E*B) := by
        gcongr
        · exact hF f B hB hf j
        · exact hg' j
        · exact cyclic_dft_norm_le f B hf j
        · exact hF g B hB hg j
      _ = _ := by ring
  have hthird := hF (fun j => F f j*F g j) (((N : ℝ)+E)^2*B^2) (by positivity) hprod (-k)
  have hdiff := cyclic_dft_distance_le (fun j => F f j*F g j)
    (fun j => ZMod.dft f j*ZMod.dft g j) (E*(2*(N : ℝ)+E)*B^2) hprodErr (-k)
  rw [← cyclic_convolution_three_dft f g k,← sub_div,norm_div,Complex.norm_natCast]
  apply (div_le_iff₀ hN).mpr
  have htri := norm_sub_le_norm_sub_add_norm_sub (F (fun j => F f j*F g j) (-k))
    (ZMod.dft (fun j => F f j*F g j) (-k))
    (ZMod.dft (fun j => ZMod.dft f j*ZMod.dft g j) (-k))
  calc
    _ ≤ E*(((N : ℝ)+E)^2*B^2)+(N : ℝ)*(E*(2*(N : ℝ)+E)*B^2) := by linarith
    _ = _ := by field_simp; ring

end Optss
