import Optss.BooleanReductionPrimitives
import Optss.BitListIntegerOperations

/-!
# Cached lattice reduction with every scalar primitive supplied explicitly

Rational arithmetic, comparison, nearest-integer rounding and integer row cells
all return exact values and charges. Container traversal, input fuel and
representation conversion remain outside the scalar gate/list accounting.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

structure ReductionPrimitives extends RationalArithmetic where
  lt : ℚ → ℚ → Bool × ℕ
  round : ℚ → ℤ × ℕ
  rowCell : ℤ → ℤ → ℤ → ℤ × ℕ
  lt_value : ∀ x y, (lt x y).1 = decide (x < y)
  round_value : ∀ x, (round x).1 = _root_.round x
  rowCell_value : ∀ u c v, (rowCell u c v).1 = u-c*v

instance : Coe ReductionPrimitives RationalArithmetic := ⟨ReductionPrimitives.toRationalArithmetic⟩

def booleanReductionPrimitives : ReductionPrimitives where
  toRationalArithmetic := booleanRationalArithmetic
  lt := booleanRatLT
  round := booleanRatRound
  rowCell := booleanIntegerRowCell
  lt_value := booleanRatLT_correct
  round_value := booleanRatRound_correct
  rowCell_value := booleanIntegerRowCell_value

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

def primitiveIntegerRowUpdate (ops : ReductionPrimitives) (D : IntegerMatrixData r d) (k j : Fin r) (q : ℤ) :
    IntegerMatrixData r d × ℕ :=
  let row : Vector (ℤ × ℕ) d := Vector.ofFn fun l =>
    ops.rowCell ((D.get k).get l) q ((D.get j).get l)
  (D.set k.val (Vector.ofFn fun l => (row.get l).1) k.isLt,
    ∑ l : Fin d, (row.get l).2)

theorem primitiveIntegerRowUpdate_value (ops : ReductionPrimitives) (D : IntegerMatrixData r d) (k j : Fin r) (q : ℤ) :
    (primitiveIntegerRowUpdate ops D k j q).1 = materializeIntegerMatrix
      (Function.update (integerMatrixDataRows D) k
        (integerMatrixDataRows D k-q • integerMatrixDataRows D j)) := by
  apply Vector.ext
  intro i hi
  apply Vector.ext
  intro l hl
  change ((primitiveIntegerRowUpdate ops D k j q).1[i]).get ⟨l,hl⟩ =
    ((materializeIntegerMatrix (Function.update (integerMatrixDataRows D) k
      (integerMatrixDataRows D k-q • integerMatrixDataRows D j))).get ⟨i,hi⟩).get ⟨l,hl⟩
  by_cases hik : i = k.val
  · subst i
    simp only [primitiveIntegerRowUpdate, Vector.getElem_set_self, get_ofFn,
      materializeIntegerMatrix, Function.update_self, Pi.sub_apply, Pi.smul_apply,
      smul_eq_mul, integerMatrixDataRows, ops.rowCell_value]
  · have hfin : (⟨i,hi⟩ : Fin r) ≠ k := fun he => hik (congrArg Fin.val he)
    simp only [primitiveIntegerRowUpdate, Vector.getElem_set_ne k.isLt hi (Ne.symm hik),
      materializeIntegerMatrix, get_ofFn, Function.update_of_ne hfin, integerMatrixDataRows]
    rfl

def primitiveReduceIntegerRow (ops : ReductionPrimitives) (D : IntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) : IntegerMatrixData r d × ℕ :=
  match n with
  | 0 => (D,0)
  | n+1 =>
    let j : Fin r := ⟨n, by omega⟩
    let Q := rationalIntegerRows (integerMatrixDataRows D)
    let T := meteredGSTable ops Q r le_rfl
    let coefficient := meteredGsCoefficient ops Q T.1 k j
    let q := ops.round coefficient.1
    let update := primitiveIntegerRowUpdate ops D k j q.1
    let tail := primitiveReduceIntegerRow ops update.1 k n (by omega)
    (tail.1, T.2+coefficient.2+q.2+update.2+tail.2)
termination_by n

theorem primitiveReduceIntegerRow_value (ops : ReductionPrimitives) (D : IntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (h : n ≤ k.val) :
    (primitiveReduceIntegerRow ops D k n h).1 = materializedReduceIntegerRow D k n h := by
  induction n generalizing D with
  | zero => rw [primitiveReduceIntegerRow, materializedReduceIntegerRow]
  | succ n ih =>
    rw [primitiveReduceIntegerRow, materializedReduceIntegerRow, ih,
      meteredGSTable_value, meteredGsCoefficient_value, primitiveIntegerRowUpdate_value, ops.round_value]

def primitiveReduceIntegerAll (ops : ReductionPrimitives) (D : IntegerMatrixData r d)
    (n : ℕ) (h : n ≤ r) : IntegerMatrixData r d × ℕ :=
  match n with
  | 0 => (D,0)
  | n+1 =>
    let previous := primitiveReduceIntegerAll ops D n (by omega)
    let current := primitiveReduceIntegerRow ops previous.1 ⟨n, by omega⟩ n le_rfl
    (current.1, previous.2+current.2)
termination_by n

theorem primitiveReduceIntegerAll_value (ops : ReductionPrimitives) (D : IntegerMatrixData r d)
    (n : ℕ) (h : n ≤ r) :
    (primitiveReduceIntegerAll ops D n h).1 = materializedReduceIntegerAll D n h := by
  induction n with
  | zero => rw [primitiveReduceIntegerAll, materializedReduceIntegerAll]
  | succ n ih =>
    rw [primitiveReduceIntegerAll, materializedReduceIntegerAll, primitiveReduceIntegerRow_value, ih]

def primitiveLovaszPair (ops : ReductionPrimitives) (A : Matrix (Fin r) (Fin d) ℚ)
    (T : RationalGSTable r d) (j k : Fin r) : Bool × ℕ :=
  let nk := meteredRationalDot ops (T.get k).get (T.get k).get
  let nj := meteredRationalDot ops (T.get j).get (T.get j).get
  let mu := meteredGsCoefficient ops A T k j
  let square := ops.mul mu.1 mu.1
  let product := ops.mul square.1 nj.1
  let total := ops.add nk.1 product.1
  let left := ops.mul 4 total.1
  let right := ops.mul 3 nj.1
  let test := ops.lt left.1 right.1
  (test.1, nk.2+nj.2+mu.2+square.2+product.2+total.2+left.2+right.2+test.2)

theorem primitiveLovaszPair_value (ops : ReductionPrimitives)
    (A : Matrix (Fin r) (Fin d) ℚ) (T : RationalGSTable r d) (j k : Fin r) :
    (primitiveLovaszPair ops A T j k).1 = decide
      (4*(rationalDot (T.get k).get (T.get k).get +
        (cachedGsCoefficient A T k j)^2*rationalDot (T.get j).get (T.get j).get) <
        3*rationalDot (T.get j).get (T.get j).get) := by
  simp only [primitiveLovaszPair, ops.mul_value, ops.add_value,
    meteredRationalDot_value, meteredGsCoefficient_value, pow_two, ops.lt_value]

def primitiveFailingAdjacentPairs (ops : ReductionPrimitives) (D : IntegerMatrixData r d) :
    Finset (Fin r × Fin r) × ℕ :=
  let Q := rationalIntegerRows (integerMatrixDataRows D)
  let T := meteredGSTable ops Q r le_rfl
  let tests : Vector (Vector (Bool × ℕ) r) r := Vector.ofFn fun j => Vector.ofFn fun k =>
    if k.val = j.val+1 then primitiveLovaszPair ops Q T.1 j k else (false,0)
  (Finset.univ.filter fun p => ((tests.get p.1).get p.2).1,
    T.2+∑ j : Fin r, ∑ k : Fin r, ((tests.get j).get k).2)

theorem primitiveFailingAdjacentPairs_value (ops : ReductionPrimitives) (D : IntegerMatrixData r d) :
    (primitiveFailingAdjacentPairs ops D).1 = cachedFailingAdjacentPairs (integerMatrixDataRows D) := by
  ext p
  simp only [primitiveFailingAdjacentPairs, cachedFailingAdjacentPairs, Finset.mem_filter,
    Finset.mem_univ, true_and, get_ofFn, meteredGSTable_value]
  by_cases h : p.2.val = p.1.val+1
  · simp only [h, ↓reduceIte, primitiveLovaszPair_value, decide_eq_true_eq, true_and]
  · simp only [h, ↓reduceIte, Bool.false_eq_true, false_and]

def primitiveReductionFuel (ops : ReductionPrimitives) : ℕ → IntegerMatrixData r d → MeteredLatticeResult r d
  | 0, D => ⟨D,0,0⟩
  | n+1, D =>
    let sweep := primitiveReduceIntegerAll ops D r le_rfl
    let tests := primitiveFailingAdjacentPairs ops sweep.1
    if h : tests.1.Nonempty then
      let p := leastPairInFinset tests.1 h
      let W := materializeIntegerMatrix (swapRows (integerMatrixDataRows sweep.1) p.1 p.2)
      let tail := primitiveReductionFuel ops n W
      ⟨tail.rows, tail.swaps+1, sweep.2+tests.2+tail.work⟩
    else ⟨sweep.1,0,sweep.2+tests.2⟩

theorem primitiveReductionFuel_value (ops : ReductionPrimitives) (fuel : ℕ)
    (D : IntegerMatrixData r d) :
    ((primitiveReductionFuel ops fuel D).rows, (primitiveReductionFuel ops fuel D).swaps) =
      materializedReductionFuel fuel D := by
  induction fuel generalizing D with
  | zero => rfl
  | succ n ih =>
    rw [primitiveReductionFuel, materializedReductionFuel]
    simp only [primitiveFailingAdjacentPairs_value, primitiveReduceIntegerAll_value]
    split_ifs with h
    · simp only [MeteredLatticeResult.rows, MeteredLatticeResult.swaps, leastPairInFinset_cached]
      exact congrArg (fun out : IntegerMatrixData r d × ℕ => (out.1, out.2+1))
        (ih (materializeIntegerMatrix (swapRows (integerMatrixDataRows
          (materializedReduceIntegerAll D r le_rfl))
          (cachedLeastFailingAdjacentPair _ h).1 (cachedLeastFailingAdjacentPair _ h).2)))
    · rfl

theorem primitiveReductionFuel_spec (ops : ReductionPrimitives) (fuel : ℕ)
    (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ)))
    (hfuel : gramPotential (integerMatrixDataRows D) ≤ fuel) :
    IntegerReductionSpecification (integerMatrixDataRows D)
      (integerMatrixDataRows (primitiveReductionFuel ops fuel D).rows)
      (primitiveReductionFuel ops fuel D).swaps := by
  have he := primitiveReductionFuel_value ops fuel D
  have h := materializedReductionFuel_spec fuel D hD hfuel
  rw [← he] at h
  exact h

irreducible_def primitiveCachedData (ops : ReductionPrimitives)
    (A : Matrix (Fin r) (Fin d) ℤ) : MeteredLatticeResult r d :=
  primitiveReductionFuel ops (cachedReductionInitialFuel A) (materializeIntegerMatrix A)

theorem primitiveCachedData_value (ops : ReductionPrimitives) (A : Matrix (Fin r) (Fin d) ℤ) :
    ((primitiveCachedData ops A).rows, (primitiveCachedData ops A).swaps) = cachedReductionData A := by
  rw [primitiveCachedData_def, cachedReductionData_def]
  exact primitiveReductionFuel_value ops _ _

/-- Supplying the Boolean scalar implementations preserves the entire
certified reduction conclusion, including the original integer lattice. -/
theorem primitiveCachedData_spec (ops : ReductionPrimitives)
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) :
    IntegerReductionSpecification A
      (integerMatrixDataRows (primitiveCachedData ops A).rows)
      (primitiveCachedData ops A).swaps := by
  have he := primitiveCachedData_value ops A
  have h := cachedIntegerReduction_spec A hA
  rw [← he] at h
  exact h

/-- Uniform bound for every scalar operation supplied by the Boolean
implementation. This does not charge representation or container operations. -/
theorem booleanReductionPrimitives_scalar_bounds (p q : ℚ) (u c v : ℤ) (L : ℕ)
    (hp : RationalBitBound p L) (hq : RationalBitBound q L)
    (hu : u.natAbs.size ≤ L) (hc : c.natAbs.size ≤ L) (hv : v.natAbs.size ≤ L) :
    (booleanReductionPrimitives.add p q).2 ≤ 65536*(L+1)^3 ∧
    (booleanReductionPrimitives.sub p q).2 ≤ 65536*(L+1)^3 ∧
    (booleanReductionPrimitives.mul p q).2 ≤ 65536*(L+1)^3 ∧
    (booleanReductionPrimitives.div p q).2 ≤ 65536*(L+1)^3 ∧
    (booleanReductionPrimitives.lt p q).2 ≤ 65536*(L+1)^3 ∧
    (booleanReductionPrimitives.round p).2 ≤ 65536*(L+1)^3 ∧
    (booleanReductionPrimitives.rowCell u c v).2 ≤ 65536*(L+1)^3 := by
  have h := booleanRationalPrimitives_cubic p q L hp hq
  have hi := booleanIntegerRowCell_cost u c v L hu hc hv
  have hpow : (L+1)^2 ≤ (L+1)^3 :=
    pow_le_pow_right' (by omega : 1 ≤ L+1) (by omega : 2 ≤ 3)
  exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2.1, h.2.2.2.2.2.1, h.2.2.2.2.2.2,
    hi.trans (by nlinarith)⟩

end Optss
