import Optss.RadixTwoStability

/-! An integer-only radix-two answer routine. A common twiddle denominator D
is accumulated once per level, so rational normalization is unnecessary in
the butterfly loop. The complex decode appears only in proofs. -/
namespace Optss

structure FourierInteger where
  re : ℤ
  im : ℤ
  deriving DecidableEq, Repr

instance : Add FourierInteger := ⟨fun z w => ⟨z.re+w.re,z.im+w.im⟩⟩
instance : Mul FourierInteger := ⟨fun z w => ⟨z.re*w.re-z.im*w.im,z.re*w.im+z.im*w.re⟩⟩
def fourierIntegerScale (D : ℤ) (z : FourierInteger) : FourierInteger := ⟨D*z.re,D*z.im⟩
def fourierIntegerValue (z : FourierInteger) : ℂ := (z.re : ℂ)+(z.im : ℂ)*Complex.I
def fourierIntegerVectorValue {m : ℕ} (A : Vector FourierInteger m) : Vector ℂ m :=
  Vector.ofFn fun j => fourierIntegerValue (A.get j)

theorem fourierIntegerValue_add (z w : FourierInteger) :
    fourierIntegerValue (z+w)=fourierIntegerValue z+fourierIntegerValue w := by
  simp only [fourierIntegerValue,Int.cast_add]
  change ((z.re+w.re : ℤ) : ℂ)+((z.im+w.im : ℤ) : ℂ)*Complex.I=_
  push_cast
  ring

theorem fourierIntegerValue_mul (z w : FourierInteger) :
    fourierIntegerValue (z*w)=fourierIntegerValue z*fourierIntegerValue w := by
  change ((z.re*w.re-z.im*w.im : ℤ) : ℂ)+
    ((z.re*w.im+z.im*w.re : ℤ) : ℂ)*Complex.I=_
  simp only [fourierIntegerValue,Int.cast_sub,Int.cast_mul,Int.cast_add]
  ring_nf
  simp only [Complex.I_sq]
  ring

theorem fourierIntegerValue_scale (D : ℤ) (z : FourierInteger) :
    fourierIntegerValue (fourierIntegerScale D z)=(D : ℂ)*fourierIntegerValue z := by
  simp only [fourierIntegerScale,fourierIntegerValue,Int.cast_mul]
  ring

def fixedPointRadixTwo (D : ℤ) (T : ℕ → ℕ → FourierInteger) :
    (n : ℕ) → Vector FourierInteger (2^n) → Vector FourierInteger (2^n)
  | 0,A => A
  | n+1,A =>
    let E := fixedPointRadixTwo D T n (radixEvenData n A)
    let O := fixedPointRadixTwo D T n (radixOddData n A)
    Vector.ofFn fun k => fourierIntegerScale D (E.get (radixModIndex n k))+
      T n k.val*O.get (radixModIndex n k)

theorem fourierIntegerVectorValue_even (n : ℕ) (A : Vector FourierInteger (2^(n+1))) :
    fourierIntegerVectorValue (radixEvenData n A)=radixEvenData n (fourierIntegerVectorValue A) := by
  apply Vector.ext
  intro j hj
  change (Vector.ofFn _).get ⟨j,hj⟩=(Vector.ofFn _).get ⟨j,hj⟩
  simp only [vector_get_ofFn,radixEvenData,fourierIntegerVectorValue]

theorem fourierIntegerVectorValue_odd (n : ℕ) (A : Vector FourierInteger (2^(n+1))) :
    fourierIntegerVectorValue (radixOddData n A)=radixOddData n (fourierIntegerVectorValue A) := by
  apply Vector.ext
  intro j hj
  change (Vector.ofFn _).get ⟨j,hj⟩=(Vector.ofFn _).get ⟨j,hj⟩
  simp only [vector_get_ofFn,radixOddData,fourierIntegerVectorValue]

/-- Exact semantic refinement of every stored integer output. The only
division is this proof-side readback by D^n. -/
theorem fixedPointRadixTwo_decode (D : ℤ) (hD : D≠0) (T : ℕ → ℕ → FourierInteger)
    (n : ℕ) (A : Vector FourierInteger (2^n)) (k : Fin (2^n)) :
    fourierIntegerValue ((fixedPointRadixTwo D T n A).get k)/(D : ℂ)^n=
      (radixTwoTransform (fun l i => fourierIntegerValue (T l i)/(D : ℂ)) n
        (fourierIntegerVectorValue A)).get k := by
  have hDC : (D : ℂ)≠0 := by exact_mod_cast hD
  induction n with
  | zero => simp [fixedPointRadixTwo,radixTwoTransform,fourierIntegerVectorValue,vector_get_ofFn]
  | succ n ih =>
    have he := ih (radixEvenData n A) (radixModIndex n k)
    have ho := ih (radixOddData n A) (radixModIndex n k)
    rw [fourierIntegerVectorValue_even] at he
    rw [fourierIntegerVectorValue_odd] at ho
    simp only [fixedPointRadixTwo,radixTwoTransform,vector_get_ofFn,
      fourierIntegerValue_add,fourierIntegerValue_mul,fourierIntegerValue_scale]
    rw [← he,← ho]
    rw [pow_succ (D : ℂ) n]
    field_simp
    ring

end Optss
