import Optss.ListStoredWorkFactors
import Optss.ListStoredSearchWorkBounds

/-!
# Storage work of the entire concrete list-backed reduction loop

The bound uses only the actual initial payload lengths, actual encoded scalar
work along the same trace, and the consumed fuel-list length. Every cached and
updated payload is bounded by produced scalar work; no future-state width or
storage-cost bound is assumed.
-/
namespace Optss
variable {r d : ℕ}

/-- The explicitly charged size sweep, test construction, minimum fold,
row permutation, and recursive list control in one pass. -/
def listStoredPassFactor (r d : ℕ) : ℕ :=
  (r+1)*listStoredAllFactor r d+16777216*(r+d+1)^12+
    (r*r+1)*8*listStorageFactor r d+(4*r+1)*listStorageFactor r d+6

theorem listStoredPassFactor_pos (r d : ℕ) : 0<listStoredPassFactor r d := by
  unfold listStoredPassFactor
  omega

theorem listStoredReductionFuelStorageWork_bound (fuel : List Bool)
    (D : ListBitIntegerMatrixData r d) (B : ℕ)
    (hB : ∀ i l,integerPayload (((listMatrixVector D).get i).get l) ≤ B) :
    listStoredReductionFuelStorageWork fuel D ≤
      (fuel.length+1)*listStoredPassFactor r d*
        (B+encodedReductionFuelWork fuel (listMatrixVector D)+3) := by
  induction fuel generalizing D B with
  | nil =>
    rw [listStoredReductionFuelStorageWork,encodedReductionFuelWork]
    have hp := listStoredPassFactor_pos r d
    simp only [List.length_nil]
    nlinarith
  | cons b fuel ih =>
    let C := listStoredReduceIntegerAll D r le_rfl
    let w₁ := encodedReduceIntegerAllWork (listMatrixVector D) r le_rfl
    let w₂ := encodedFailingAdjacentPairsWork (listMatrixVector C)
    let pairs := listStoredFailingPairs C
    let P := listStoredPassFactor r d
    have hC : ∀ i l,integerPayload (((listMatrixVector C).get i).get l) ≤ B+w₁ := by
      intro i l
      change integerPayload (((listMatrixVector (listStoredReduceIntegerAll D r le_rfl)).get i).get l) ≤ _
      rw [listStoredReduceIntegerAll_eq]
      exact encodedReduceIntegerAll_output_le_work (listMatrixVector D) r le_rfl B hB i l
    have hsw := listStoredReduceIntegerAllStorageWork_bound D r le_rfl B hB
    have hse := listStoredFailingPairsStorageWork_bound C (B+w₁) hC
    have hmi : bitLeastPairWork pairs ≤ (r*r+1)*8*listStorageFactor r d :=
      (bitLeastPairWork_le (d:=d) pairs).trans
        (Nat.mul_le_mul_right _ (Nat.mul_le_mul_right 8
          (Nat.add_le_add_right (listStoredFailingPairs_length C) 1)))
    rw [listStoredReductionFuelStorageWork,encodedReductionFuelWork]
    simp only [← listStoredReduceIntegerAll_eq,← listStoredFailingPairs_eq]
    split_ifs with h
    · rw [bitLeastPair_eq_least _ h]
      let p := leastPairInFinset pairs.toFinset h
      let W := listStoredBooleanSwapRows C p.1 p.2
      let wt := encodedReductionFuelWork fuel (listMatrixVector W)
      let R := B+(w₁+w₂+wt)+3
      have hW : ∀ i l,integerPayload (((listMatrixVector W).get i).get l) ≤ B+w₁ := by
        intro i l
        change integerPayload (((listMatrixVector (listStoredBooleanSwapRows C p.1 p.2)).get i).get l) ≤ _
        rw [listStoredBooleanSwapRows_eq]
        exact encodedSwapRows_output_bound (listMatrixVector C) p.1 p.2 (B+w₁) hC i l
      have hnext := ih W (B+w₁) hW
      have hswap := listStoredBooleanSwapRowsStorageWork_bound C p.1 p.2 (B+w₁) hC
      have hR : 1≤R := by dsimp [R]; omega
      have hsw' : listStoredReduceIntegerAllStorageWork D r le_rfl ≤
          (r+1)*listStoredAllFactor r d*R :=
        hsw.trans (Nat.mul_le_mul_left _ (by change B+w₁+3≤R; dsimp [R]; omega))
      have hse' : listStoredFailingPairsStorageWork C ≤ 16777216*(r+d+1)^12*R :=
        hse.trans (Nat.mul_le_mul_left _ (by change B+w₁+w₂+3≤R; dsimp [R]; omega))
      have hmi' : bitLeastPairWork pairs ≤ ((r*r+1)*8*listStorageFactor r d)*R :=
        hmi.trans (Nat.le_mul_of_pos_right _ hR)
      have hswap' : listStoredBooleanSwapRowsStorageWork C p.1 p.2 ≤
          ((4*r+1)*listStorageFactor r d)*R :=
        hswap.trans (Nat.mul_le_mul_left _ (by dsimp [R]; omega))
      have hnext' : listStoredReductionFuelStorageWork fuel W ≤ (fuel.length+1)*P*R :=
        hnext.trans (Nat.mul_le_mul_left _ (by change B+w₁+wt+3≤R; dsimp [R]; omega))
      have hsix : 6≤6*R := Nat.le_mul_of_pos_right _ hR
      simp only [List.length_cons]
      rw [← listStoredBooleanSwapRows_eq]
      change listStoredReduceIntegerAllStorageWork D r le_rfl+
          listStoredFailingPairsStorageWork C+bitLeastPairWork pairs+3+
          listStoredBooleanSwapRowsStorageWork C p.1 p.2+
          listStoredReductionFuelStorageWork fuel W+3 ≤ (fuel.length+1+1)*P*R
      calc
        _ ≤ (r+1)*listStoredAllFactor r d*R+16777216*(r+d+1)^12*R+
            ((r*r+1)*8*listStorageFactor r d)*R+
            ((4*r+1)*listStorageFactor r d)*R+(fuel.length+1)*P*R+6*R := by omega
        _ = _ := by dsimp only [P]; unfold listStoredPassFactor; ring
    · have he : bitLeastPair pairs = none := by
        apply (bitLeastPair_none _).mpr
        apply List.eq_nil_iff_forall_not_mem.mpr
        intro p hp
        exact h ⟨p,List.mem_toFinset.mpr hp⟩
      change bitLeastPair (listStoredFailingPairs (listStoredReduceIntegerAll D r le_rfl))=none at he
      rw [he]
      let R := B+(w₁+w₂)+3
      have hR : 1≤R := by dsimp [R]; omega
      have hsw' : listStoredReduceIntegerAllStorageWork D r le_rfl ≤
          (r+1)*listStoredAllFactor r d*R :=
        hsw.trans (Nat.mul_le_mul_left _ (by change B+w₁+3≤R; dsimp [R]; omega))
      have hse' : listStoredFailingPairsStorageWork C ≤ 16777216*(r+d+1)^12*R :=
        hse.trans (Nat.mul_le_mul_left _ (by change B+w₁+w₂+3≤R; dsimp [R]; omega))
      have hmi' : bitLeastPairWork pairs ≤ ((r*r+1)*8*listStorageFactor r d)*R :=
        hmi.trans (Nat.le_mul_of_pos_right _ hR)
      have hthree : 3≤6*R := by omega
      change listStoredReduceIntegerAllStorageWork D r le_rfl+
        listStoredFailingPairsStorageWork C+bitLeastPairWork pairs+3 ≤
          ((b::fuel).length+1)*P*R
      calc
        _ ≤ (r+1)*listStoredAllFactor r d*R+16777216*(r+d+1)^12*R+
            ((r*r+1)*8*listStorageFactor r d)*R+6*R := by omega
        _ = ((r+1)*listStoredAllFactor r d+16777216*(r+d+1)^12+
            (r*r+1)*8*listStorageFactor r d+6)*R := by ring
        _ ≤ P*R := Nat.mul_le_mul_right R (by
          change (r+1)*listStoredAllFactor r d+16777216*(r+d+1)^12+
            (r*r+1)*8*listStorageFactor r d+6 ≤
              (r+1)*listStoredAllFactor r d+16777216*(r+d+1)^12+
                (r*r+1)*8*listStorageFactor r d+(4*r+1)*listStorageFactor r d+6
          omega)
        _ ≤ ((b::fuel).length+1)*P*R := by
          exact Nat.mul_le_mul_right R (Nat.le_mul_of_pos_left _ (by simp))

/-- A fixed polynomial bounds the explicit sum of all pass-stage factors. -/
theorem listStoredPassFactor_le (r d : ℕ) :
    listStoredPassFactor r d ≤ 268435456*(r+d+1)^16 := by
  let S := r+d+1
  have hS : 0<S := by dsimp [S]; omega
  have hr : r≤S := by dsimp [S]; omega
  have hp₀ : 1≤S^16 := one_le_pow₀ hS
  have hp₁ : S≤S^2 := by simpa using Nat.pow_le_pow_right hS (by decide : (1:ℕ)≤2)
  have hp₂ : S^2≤S^16 := Nat.pow_le_pow_right hS (by decide)
  have hp₅ : S^5≤S^16 := Nat.pow_le_pow_right hS (by decide)
  have hp₆ : S^6≤S^16 := Nat.pow_le_pow_right hS (by decide)
  have hp₁₀ : S^10≤S^16 := Nat.pow_le_pow_right hS (by decide)
  have hp₁₂ : S^12≤S^16 := Nat.pow_le_pow_right hS (by decide)
  have h₁ : (r+1)*listStoredAllFactor r d ≤ 1048576*S^16 :=
    (listStoredFullSweepFactor_le r d).trans (Nat.mul_le_mul_left _ hp₁₀)
  have h₂ : 16777216*S^12≤16777216*S^16 := Nat.mul_le_mul_left _ hp₁₂
  have hrr : r*r+1≤2*S^2 := by
    have hh := Nat.mul_le_mul hr hr
    have hp : 1≤S^2 := one_le_pow₀ hS
    nlinarith
  have h₃ : (r*r+1)*8*listStorageFactor r d ≤ 32768*S^16 := by
    calc
      _ ≤ (2*S^2)*8*(2048*S^4) := Nat.mul_le_mul_right _ (Nat.mul_le_mul_right 8 hrr)
      _ = 32768*S^6 := by ring
      _ ≤ _ := Nat.mul_le_mul_left _ hp₆
  have h₄ : (4*r+1)*listStorageFactor r d ≤ 10240*S^16 := by
    calc
      _ ≤ (5*S)*(2048*S^4) := Nat.mul_le_mul_right _ (by omega)
      _ = 10240*S^5 := by ring
      _ ≤ _ := Nat.mul_le_mul_left _ hp₅
  change (r+1)*listStoredAllFactor r d+16777216*S^12+
    (r*r+1)*8*listStorageFactor r d+(4*r+1)*listStorageFactor r d+6≤268435456*S^16
  omega

/-- Universal storage overhead bound in actual input payload size, actual
scalar work, and literal fuel length. No independence hypothesis is needed. -/
theorem listStoredReductionFuelStorageWork_polynomial (fuel : List Bool)
    (D : ListBitIntegerMatrixData r d) :
    listStoredReductionFuelStorageWork fuel D ≤
      (fuel.length+1)*(268435456*(r+d+1)^16)*
        (bitIntegerMatrixSize (listMatrixVector D)+
          encodedReductionFuelWork fuel (listMatrixVector D)+3) := by
  apply (listStoredReductionFuelStorageWork_bound fuel D
    (bitIntegerMatrixSize (listMatrixVector D)) (bitIntegerMatrixSize_cell (listMatrixVector D))).trans
  exact Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ (listStoredPassFactor_le r d))

end Optss
