import Optss.LatticeBoxingCounting

/-!
# The precise ceiling widths in geometric lattice boxing

These statements identify the widths used in the containment proof, allowing
an executable maximum/ceiling routine to discharge them by equality.
-/
namespace Optss
noncomputable section
open scoped BigOperators Pointwise
variable {r : ℕ}

section Map
variable {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
  [NormedAddCommGroup F] [NormedSpace ℝ F] [FiniteDimensional ℝ F]

theorem basisCoordinateRadius_map (b : Basis (Fin r) ℝ E) (f : E ≃ₗ[ℝ] F)
    (K : Set E) (hK : IsCompact K) (hne : K.Nonempty)
    (hF : IsCompact (f '' K)) (hneF : (f '' K).Nonempty) (j : Fin r) :
    basisCoordinateRadius (b.map f) (f '' K) hF hneF j=basisCoordinateRadius b K hK hne j := by
  apply le_antisymm
  · obtain ⟨x,hx,hfx⟩ := basisCoordinateMaximizer_mem (b.map f) (f '' K) hF hneF j
    unfold basisCoordinateRadius
    rw [←hfx]
    change |b.repr (f.symm (f x)) j|≤_
    rw [f.symm_apply_apply]
    exact basisCoordinate_le_radius b K hK hne j hx
  · have h := basisCoordinate_le_radius (b.map f) (f '' K) hF hneF j
      (Set.mem_image_of_mem f (basisCoordinateMaximizer_mem b K hK hne j))
    change |b.repr (f.symm (f (basisCoordinateMaximizer b K hK hne j))) j|≤_ at h
    rw [f.symm_apply_apply] at h
    exact h

theorem basisIntegerWidth_map (b : Basis (Fin r) ℝ E) (f : E ≃ₗ[ℝ] F)
    (K : Set E) (hK : IsCompact K) (hne : K.Nonempty)
    (hF : IsCompact (f '' K)) (hneF : (f '' K).Nonempty) :
    basisIntegerWidth (b.map f) (f '' K) hF hneF=basisIntegerWidth b K hK hne := by
  funext j
  unfold basisIntegerWidth
  rw [basisCoordinateRadius_map b f K hK hne hF hneF j]
end Map

theorem normalized_lattice_boxing_exact_widths (hr : 0<r)
    (K : Set (EuclideanSpace ℝ (Fin r))) (hK : IsCompact K) (hne : K.Nonempty)
    (hinner : euclideanCoordinateCube r (1/(r:ℝ)) ⊆ K)
    (houter : K ⊆ euclideanCoordinateCube r 1)
    (b : Basis (Fin r) ℝ (EuclideanSpace ℝ (Fin r)))
    (ω : ℝ) (hω : 0<ω) (hdual : BasisDualNormBound b ω)
    (x : Fin r → EuclideanSpace ℝ (Fin r)) (hind : LinearIndependent ℝ x)
    (hxK : ∀ i,x i∈K) (hxΛ : ∀ i,x i∈basisIntegerLattice b) :
    let n := basisIntegerWidth b K hK hne
    (∀ j,1≤n j) ∧ K ⊆ basisCoefficientBox b n ∧
      basisCoefficientBox b n ⊆ latticeBoxingDilation r ω • K := by
  have hrR : (0:ℝ)<r := by exact_mod_cast hr
  have hsqrt : 0<Real.sqrt (r:ℝ) := Real.sqrt_pos.mpr hrR
  let n := basisIntegerWidth b K hK hne
  have hrad (j : Fin r) : 1≤basisCoordinateRadius b K hK hne j :=
    basisCoordinateRadius_ge_one b K hK hne x hind hxK hxΛ j
  have hn (j : Fin r) : (n j:ℝ)*‖b j‖≤2*ω*Real.sqrt r :=
    basisIntegerWidth_mul_norm_le b K hK hne ω (Real.sqrt r) hω.le hdual
      (fun y hy => norm_le_sqrt_dimension_of_cube (houter hy)) j (hrad j)
  refine ⟨fun j => (basisIntegerWidth_bounds b K hK hne j (hrad j)).1,
    subset_basisCoefficientBox b K hK hne,?_⟩
  intro z hz
  have hzNorm := basisCoefficientBox_norm_le b n (2*ω*Real.sqrt r) hn hz
  let J := latticeBoxingDilation r ω
  have hJ : 0<J := by dsimp [J,latticeBoxingDilation]; positivity
  have hscaled : ‖J⁻¹ • z‖≤1/(r:ℝ) := by
    rw [norm_smul,Real.norm_of_nonneg (inv_nonneg.mpr hJ.le)]
    calc
      J⁻¹*‖z‖≤J⁻¹*((r:ℝ)*(2*ω*Real.sqrt r)) :=
        mul_le_mul_of_nonneg_left hzNorm (inv_nonneg.mpr hJ.le)
      _ = _ := by
        dsimp [J,latticeBoxingDilation]
        field_simp [ne_of_gt hrR,ne_of_gt hsqrt,ne_of_gt hω]
        ring
  refine ⟨J⁻¹ • z,hinner (mem_cube_of_norm_le hscaled),?_⟩
  change J • (J⁻¹ • z)=z
  rw [smul_smul,mul_inv_cancel₀ (ne_of_gt hJ),one_smul]

/-- Normalization preserves exactly the integer ceiling widths, so both
containments and every real-dilate count concern the same computed box. -/
theorem lattice_boxing_exact_widths_of_normalization
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    (hr : 0<r) (K : Set E) (hK : IsCompact K) (hne : K.Nonempty)
    (hcK : Convex ℝ K) (hsym : ∀ x∈K,-x∈K)
    (e : E ≃L[ℝ] EuclideanSpace ℝ (Fin r))
    (hinner : euclideanCoordinateCube r (1/(r:ℝ)) ⊆ e '' K)
    (houter : e '' K ⊆ euclideanCoordinateCube r 1)
    (b : Basis (Fin r) ℝ E) (ω : ℝ) (hω : 0<ω)
    (hdefect : euclideanOrthogonalityDefect (b.map e.toLinearEquiv)≤ω)
    (x : Fin r → E) (hind : LinearIndependent ℝ x)
    (hxK : ∀ i,x i∈K) (hxΛ : ∀ i,x i∈basisIntegerLattice b) :
    let n := basisIntegerWidth b K hK hne
    (∀ j,1≤n j) ∧ K ⊆ basisCoefficientBox b n ∧
      basisCoefficientBox b n ⊆ latticeBoxingDilation r ((r.factorial:ℝ)*ω) • K ∧
      ∀ s : ℝ,(basisLatticePoints b (s • basisCoefficientBox b n)
          ((basisCoefficientBox_compact b n).smul s)).card≤
        (latticeBoxingResidueModulus r ω)^r*(basisLatticePoints b (s • K) (hK.smul s)).card := by
  have hxe : LinearIndependent ℝ (fun i => e (x i)) :=
    hind.map' e.toLinearMap (LinearMap.ker_eq_bot.mpr e.injective)
  have hxΛe (i : Fin r) : e (x i)∈basisIntegerLattice (b.map e.toLinearEquiv) := by
    rw [basisIntegerLattice_map]
    exact ⟨x i,hxΛ i,rfl⟩
  have hK' := hK.image e.continuous
  have hne' := hne.image e
  have h := normalized_lattice_boxing_exact_widths hr (e '' K) hK' hne' hinner houter
    (b.map e.toLinearEquiv) ((r.factorial:ℝ)*ω)
    (mul_pos (by exact_mod_cast Nat.factorial_pos r) hω)
    (basisDualNormBound_of_orthogonalityDefect _ ω hdefect)
    (fun i => e (x i)) hxe (fun i => ⟨x i,hxK i,rfl⟩) hxΛe
  dsimp only at h
  have hw : basisIntegerWidth (b.map e.toLinearEquiv) (e '' K) hK' hne'=basisIntegerWidth b K hK hne :=
    basisIntegerWidth_map b e.toLinearEquiv K hK hne hK' hne'
  rw [hw] at h
  let n := basisIntegerWidth b K hK hne
  have hencl : basisCoefficientBox b n ⊆ latticeBoxingDilation r ((r.factorial:ℝ)*ω) • K := by
    intro y hy
    have hym : e y∈basisCoefficientBox (b.map e.toLinearEquiv) n := by
      rw [basisCoefficientBox_map]
      exact ⟨y,hy,rfl⟩
    obtain ⟨u,⟨z,hz,rfl⟩,he⟩ := h.2.2 hym
    refine ⟨z,hz,e.injective ?_⟩
    simpa only [map_smul] using he
  refine ⟨h.1,subset_basisCoefficientBox b K hK hne,hencl,?_⟩
  intro s
  exact basisLatticePoints_enclosing_uniform b K (basisCoefficientBox b n) hK
    (basisCoefficientBox_compact b n) hcK hsym
    (latticeBoxingDilation r ((r.factorial:ℝ)*ω)) (by unfold latticeBoxingDilation; positivity)
    hencl (latticeBoxingResidueModulus r ω) (latticeBoxingResidueModulus_pos r ω)
    (latticeBoxingResidueModulus_bound r ω) s
end
end Optss
