import Optss.Kneser
import Mathlib.Algebra.BigOperators.Group.List.Basic
import Mathlib.Tactic

/-!
# Kneser's theorem for an actual finite family of summands

The bounds here are consequences of the fully proved two-set Kneser theorem.
No sumset growth estimate is taken as an external hypothesis.
-/
namespace Optss
open scoped Pointwise BigOperators
variable {G : Type*} [AddCommGroup G] [DecidableEq G]

/-- A finite sum of nonempty finite sets is nonempty, including the empty sum. -/
theorem nonempty_list_sum (L : List (Finset G)) (hL : ∀ A ∈ L, A.Nonempty) :
    L.sum.Nonempty := by
  induction L with
  | nil => simp
  | cons A L ih =>
    exact (hL A (by simp)).add (ih (fun B hB => hL B (by simp [hB])))

/-- The unsaturated cardinality consequence of Kneser for an arbitrary list. -/
theorem kneser_list_card (L : List (Finset G)) (hL : ∀ A ∈ L, A.Nonempty) :
    (L.map Finset.card).sum ≤ L.sum.card + (L.length - 1) * L.sum.addStab.card := by
  induction L with
  | nil => simp
  | cons A L ih =>
    have hA := hL A (by simp)
    have htail : ∀ B ∈ L, B.Nonempty := fun B hB => hL B (by simp [hB])
    cases L with
    | nil => simp
    | cons B L =>
      have hT := nonempty_list_sum (B :: L) htail
      have hI := ih htail
      have hstab : (B :: L).sum.addStab.card ≤ (A + (B :: L).sum).addStab.card :=
        Finset.card_le_card (Finset.subset_addStab_add_right hA)
      have hK := Finset.add_kneser A (B :: L).sum
      have hN := (hA.add hT).addStab
      have hca := Finset.card_le_card_add_right (s := A) hN
      have hct := Finset.card_le_card_add_right (s := (B :: L).sum) hN
      have hm := Nat.mul_le_mul_left ((B :: L).length - 1) hstab
      simp only [List.map_cons, List.sum_cons, List.length_cons, Nat.add_sub_cancel,
        Nat.add_mul, one_mul] at *
      omega

/-- Saturating every nonempty list summand by a finite-set stabilizer is the
same as saturating its sum once. -/
theorem list_sum_add_stab (L : List (Finset G)) (hne : L ≠ []) (S : Finset G) :
    (L.map (fun A => A + S.addStab)).sum = L.sum + S.addStab := by
  induction L with
  | nil => contradiction
  | cons A L ih =>
    cases L with
    | nil => simp
    | cons B L =>
      simp only [List.map_cons, List.sum_cons] at ih ⊢
      rw [ih (by simp), add_add_add_comm, Finset.addStab_add_addStab]

/-- Full stabilizer-saturated Kneser inequality for a finite nonempty family. -/
theorem kneser_list_saturated_card (L : List (Finset G)) (hne : L ≠ [])
    (hL : ∀ A ∈ L, A.Nonempty) :
    (L.map (fun A => (A + L.sum.addStab).card)).sum ≤
      L.sum.card + (L.length - 1) * L.sum.addStab.card := by
  have hS := nonempty_list_sum L hL
  have hmap : ∀ A ∈ L.map (fun A => A + L.sum.addStab), A.Nonempty := by
    intro A hA
    obtain ⟨B, hB, rfl⟩ := List.mem_map.mp hA
    exact (hL B hB).add hS.addStab
  have h := kneser_list_card (L.map (fun A => A + L.sum.addStab)) hmap
  rw [list_sum_add_stab L hne L.sum, Finset.add_addStab] at h
  simpa only [List.map_map, List.length_map, Function.comp_def] using h

end Optss
