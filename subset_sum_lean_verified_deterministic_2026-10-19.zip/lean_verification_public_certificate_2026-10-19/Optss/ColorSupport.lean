import Optss.Basic
import Mathlib.Algebra.Group.Pointwise.Finset.Basic
import Mathlib.Data.Fintype.BigOperators

/-!
# Deterministic support correctness for Appendix A.2

Color factors contain zero and the actual values of labels carrying a color.
Their finite Minkowski sum, unions across repetitions, and products across
disjoint buckets preserve actual-copy witnesses. Injective colorings retain
fixed witnesses. Only the final support is filtered by the global box; no
intermediate clipping is part of this construction.
-/
namespace Optss
open scoped BigOperators Pointwise
section
variable {ι G : Type*} [DecidableEq ι] [DecidableEq G] [AddCommGroup G]

/-- Finite Minkowski addition of one set for each index. -/
def indexedSupportSum {n : ℕ} (A : Fin n → Finset G) : Finset G :=
  (List.ofFn A).sum

theorem mem_indexedSupportSum {n : ℕ} (A : Fin n → Finset G) (t : G) :
    t ∈ indexedSupportSum A ↔ ∃ x : Fin n → G, (∀ p, x p ∈ A p) ∧ ∑ p, x p = t := by
  rw [indexedSupportSum, Finset.mem_sum_list_ofFn]
  constructor
  · rintro ⟨x, hx⟩
    exact ⟨fun p => x p, fun p => (x p).property, by simpa [List.sum_ofFn] using hx⟩
  · rintro ⟨x, hx, hsum⟩
    exact ⟨fun p => ⟨x p, hx p⟩, by simpa [List.sum_ofFn] using hsum⟩

/-- Disjoint buckets compose local actual-copy witnesses into one subset of
original labels. The finite union cannot use any label twice. -/
theorem indexedSupportSum_sound {b : ℕ} (v : ι → G) (S : Finset ι)
    (bucket : ι → Fin b) (A : Fin b → Finset G)
    (hA : ∀ p t, t ∈ A p → ∃ s : Finset ι,
      s ⊆ S.filter (fun i => bucket i = p) ∧ ∑ i ∈ s, v i = t)
    {t : G} (ht : t ∈ indexedSupportSum A) :
    ∃ s : Finset ι, s ⊆ S ∧ ∑ i ∈ s, v i = t := by
  obtain ⟨x, hx, hsum⟩ := (mem_indexedSupportSum A t).mp ht
  choose s hs he using fun p => hA p (x p) (hx p)
  have hdis : Set.PairwiseDisjoint (↑(Finset.univ : Finset (Fin b))) s := by
    intro p _ q _ hpq
    apply Finset.disjoint_left.mpr
    intro i hip hiq
    have hp := (Finset.mem_filter.mp (hs p hip)).2
    have hq := (Finset.mem_filter.mp (hs q hiq)).2
    exact hpq (hp.symm.trans hq)
  refine ⟨Finset.univ.biUnion s, ?_, ?_⟩
  · intro i hi
    obtain ⟨p, _, hip⟩ := Finset.mem_biUnion.mp hi
    exact (Finset.mem_filter.mp (hs p hip)).1
  · rw [Finset.sum_biUnion hdis]
    simpa only [he] using hsum

omit [DecidableEq ι] in
/-- If every bucket retains its part of a fixed selection, their Minkowski
sum retains the complete selection. -/
theorem indexedSupportSum_retains {b : ℕ} (v : ι → G) (s : Finset ι)
    (bucket : ι → Fin b) (A : Fin b → Finset G)
    (hA : ∀ p, (∑ i ∈ s.filter (fun i => bucket i = p), v i) ∈ A p) :
    (∑ i ∈ s, v i) ∈ indexedSupportSum A := by
  apply (mem_indexedSupportSum A _).mpr
  exact ⟨fun p => ∑ i ∈ s.filter (fun i => bucket i = p), v i,
    hA, Finset.sum_fiberwise s bucket v⟩

/-- One actual Appendix A.2 factor: choose zero or one label of this color. -/
def colorFactor {q : ℕ} (v : ι → G) (S : Finset ι) (color : ι → Fin q)
    (p : Fin q) : Finset G :=
  insert 0 ((S.filter (fun i => color i = p)).image v)

omit [DecidableEq ι] in
theorem mem_colorFactor {q : ℕ} (v : ι → G) (S : Finset ι) (color : ι → Fin q)
    (p : Fin q) (t : G) :
    t ∈ colorFactor v S color p ↔ t = 0 ∨ ∃ i ∈ S, color i = p ∧ v i = t := by
  simp only [colorFactor, Finset.mem_insert, Finset.mem_image, Finset.mem_filter]
  aesop

omit [DecidableEq ι] in
theorem colorFactor_sound {q : ℕ} (v : ι → G) (S : Finset ι) (color : ι → Fin q)
    (p : Fin q) (t : G) (ht : t ∈ colorFactor v S color p) :
    ∃ s : Finset ι, s ⊆ S.filter (fun i => color i = p) ∧ ∑ i ∈ s, v i = t := by
  rcases (mem_colorFactor v S color p t).mp ht with rfl | ⟨i, hi, hic, rfl⟩
  · exact ⟨∅, Finset.empty_subset _, by simp⟩
  · exact ⟨{i}, Finset.singleton_subset_iff.mpr (Finset.mem_filter.mpr ⟨hi, hic⟩), by simp⟩

/-- A product of color factors is their full, unclipped Minkowski sum. -/
def colorSupport {q : ℕ} (v : ι → G) (S : Finset ι) (color : ι → Fin q) : Finset G :=
  indexedSupportSum (colorFactor v S color)

theorem colorSupport_sound {q : ℕ} (v : ι → G) (S : Finset ι) (color : ι → Fin q)
    {t : G} (ht : t ∈ colorSupport v S color) :
    ∃ s : Finset ι, s ⊆ S ∧ ∑ i ∈ s, v i = t :=
  indexedSupportSum_sound v S color (colorFactor v S color) (colorFactor_sound v S color) ht

/-- Distinct colors on a fixed witness ensure that each of its color fibers
is a permitted singleton or empty choice in the corresponding actual factor. -/
theorem colorSupport_retains {q : ℕ} (v : ι → G) (S s : Finset ι)
    (color : ι → Fin q) (hs : s ⊆ S) (hinj : Set.InjOn color (s : Set ι)) :
    (∑ i ∈ s, v i) ∈ colorSupport v S color := by
  apply indexedSupportSum_retains v s color
  intro p
  by_cases hempty : s.filter (fun i => color i = p) = ∅
  · simp [hempty, colorFactor]
  · obtain ⟨i, hi⟩ := Finset.nonempty_iff_ne_empty.mpr hempty
    have hi' := Finset.mem_filter.mp hi
    have hf : s.filter (fun j => color j = p) = {i} := by
      apply Finset.eq_singleton_iff_unique_mem.mpr
      refine ⟨hi, ?_⟩
      intro j hj
      have hj' := Finset.mem_filter.mp hj
      exact hinj hj'.1 hi'.1 (hj'.2.trans hi'.2.symm)
    rw [hf, Finset.sum_singleton]
    exact (mem_colorFactor v S color p (v i)).mpr (Or.inr ⟨i, hs hi'.1, hi'.2, rfl⟩)

/-- Union the outputs of the repeated colorings within one bucket. -/
def repeatedColorSupport {r q : ℕ} (v : ι → G) (S : Finset ι)
    (color : Fin r → ι → Fin q) : Finset G :=
  Finset.univ.biUnion (fun a => colorSupport v S (color a))

theorem repeatedColorSupport_sound {r q : ℕ} (v : ι → G) (S : Finset ι)
    (color : Fin r → ι → Fin q) {t : G} (ht : t ∈ repeatedColorSupport v S color) :
    ∃ s : Finset ι, s ⊆ S ∧ ∑ i ∈ s, v i = t := by
  obtain ⟨a, _, ha⟩ := Finset.mem_biUnion.mp ht
  exact colorSupport_sound v S (color a) ha

theorem repeatedColorSupport_retains {r q : ℕ} (v : ι → G) (S s : Finset ι)
    (color : Fin r → ι → Fin q) (hs : s ⊆ S)
    (hgood : ∃ a, Set.InjOn (color a) (s : Set ι)) :
    (∑ i ∈ s, v i) ∈ repeatedColorSupport v S color := by
  obtain ⟨a, ha⟩ := hgood
  exact Finset.mem_biUnion.mpr ⟨a, Finset.mem_univ _, colorSupport_retains v S s (color a) hs ha⟩

/-- The actual two-stage construction before final global-box intersection. -/
def bucketColorSupport {b r q : ℕ} (v : ι → G) (S : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin r → ι → Fin q) : Finset G :=
  indexedSupportSum (fun p => repeatedColorSupport v (S.filter (fun i => bucket i = p)) (color p))

/-- All outputs of the two-stage construction use distinct original labels. -/
theorem bucketColorSupport_sound {b r q : ℕ} (v : ι → G) (S : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin r → ι → Fin q)
    {t : G} (ht : t ∈ bucketColorSupport v S bucket color) :
    ∃ s : Finset ι, s ⊆ S ∧ ∑ i ∈ s, v i = t := by
  exact indexedSupportSum_sound v S bucket _
    (fun p t ht => repeatedColorSupport_sound v _ (color p) ht) ht

/-- Every bucket may use its own successful repetition: one globally shared
successful repetition is unnecessary. This is Appendix A.2's retention event. -/
theorem bucketColorSupport_retains {b r q : ℕ} (v : ι → G) (S s : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin r → ι → Fin q) (hs : s ⊆ S)
    (hgood : ∀ p, ∃ a, Set.InjOn (color p a) (↑(s.filter (fun i => bucket i = p)) : Set ι)) :
    (∑ i ∈ s, v i) ∈ bucketColorSupport v S bucket color := by
  apply indexedSupportSum_retains v s bucket
  intro p
  apply repeatedColorSupport_retains v _ _ (color p) _ (hgood p)
  exact Finset.filter_subset_filter _ hs

/-- Filter only the final sum of bucket supports by the requested global box. -/
def clippedBucketColorSupport {b r q : ℕ} (v : ι → G) (S : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin r → ι → Fin q)
    (B : Set G) [DecidablePred B] : Finset G :=
  (bucketColorSupport v S bucket color).filter B

/-- Soundness survives arbitrary final clipping, including boxes whose
intermediate color or bucket partial sums need not contain the witness. -/
theorem clippedBucketColorSupport_sound {b r q : ℕ} (v : ι → G) (S : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin r → ι → Fin q)
    (B : Set G) [DecidablePred B] {t : G} (ht : t ∈ clippedBucketColorSupport v S bucket color B) :
    t ∈ B ∧ ∃ s : Finset ι, s ⊆ S ∧ ∑ i ∈ s, v i = t := by
  obtain ⟨ht, hB⟩ := Finset.mem_filter.mp ht
  exact ⟨hB, bucketColorSupport_sound v S bucket color ht⟩

/-- The complete deterministic implication underlying Lemma A.2: conditional
on a successful repetition in every bucket, each fixed in-box witness survives. -/
theorem clippedBucketColorSupport_retains {b r q : ℕ} (v : ι → G) (S s : Finset ι)
    (bucket : ι → Fin b) (color : Fin b → Fin r → ι → Fin q)
    (B : Set G) [DecidablePred B] (hs : s ⊆ S) (hB : (∑ i ∈ s, v i) ∈ B)
    (hgood : ∀ p, ∃ a, Set.InjOn (color p a) (↑(s.filter (fun i => bucket i = p)) : Set ι)) :
    (∑ i ∈ s, v i) ∈ clippedBucketColorSupport v S bucket color B :=
  Finset.mem_filter.mpr ⟨bucketColorSupport_retains v S s bucket color hs hgood, hB⟩

end
end Optss
