import Optss.BooleanGcdPair

/-! Native stored inputs, including negative zero, have the same unimodular
update as their decoded integers. This permits repeated Boolean matrix updates
without decoding and re-encoding intermediate integers. -/
namespace Optss

theorem bitListInteger_natAbs (x : BitListInteger) :
    x.value.natAbs=binaryDigitsValue x.digits := by
  cases hx : x.negative <;> simp [BitListInteger.value,signedBitsValue,hx]

theorem bitListIntegerXgcd_gcd_value (x y : BitListInteger) :
    binaryDigitsValue (bitListIntegerXgcd x y).gcdDigits=Int.gcd x.value y.value := by
  rw [Int.gcd_def,bitListInteger_natAbs,bitListInteger_natAbs]
  exact bitListNatXgcd_gcd _ _

/-- Coefficients agree with the standard signed Bézout choice unless both
magnitudes vanish. The matrix routine selects the identity in that case. -/
theorem bitListIntegerXgcd_coefficients (x y : BitListInteger)
    (hg : Int.gcd x.value y.value≠0) :
    (bitListIntegerXgcd x y).left.value=Int.gcdA x.value y.value ∧
    (bitListIntegerXgcd x y).right.value=Int.gcdB x.value y.value := by
  have hg' : Nat.gcd (binaryDigitsValue x.digits) (binaryDigitsValue y.digits)≠0 := by
    simpa only [Int.gcd_def,bitListInteger_natAbs] using hg
  have hxval : x.value=if x.negative then -(binaryDigitsValue x.digits:ℤ) else (binaryDigitsValue x.digits:ℤ) := rfl
  have hyval : y.value=if y.negative then -(binaryDigitsValue y.digits:ℤ) else (binaryDigitsValue y.digits:ℤ) := rfl
  rw [hxval,hyval]
  cases hx : x.negative <;> cases hy : y.negative <;>
    simp only [bitListIntegerXgcd,hx,hy,Bool.false_eq_true,ite_false,ite_true,
      bitListIntegerNeg_value,bitListNatXgcd_left,bitListNatXgcd_right]
  all_goals
    cases hm : binaryDigitsValue x.digits <;> cases hn : binaryDigitsValue y.digits <;>
      simp only [hm,hn,Nat.gcd_zero_left,Nat.gcd_zero_right,ne_eq,Nat.succ_ne_zero,not_false_eq_true] at hg' ⊢
  all_goals first
    | contradiction
    | simp only [Int.neg_ofNat_succ,Int.gcdA,Int.gcdB,Int.natAbs_zero,Int.natAbs_ofNat,Int.natAbs_negSucc,Nat.gcdA_zero_left,
        Nat.gcdB_zero_left,Nat.gcdA_zero_right (Nat.succ_ne_zero _),Nat.gcdB_zero_right (Nat.succ_ne_zero _),
        Int.natCast_zero,neg_zero,Int.neg_zero,true_and,and_true,and_self]

theorem bitListGcdPairMatrix_native_value (x y : BitListInteger) :
    (bitListGcdPairMatrix x y).value=
      if Int.gcd x.value y.value=0 then (1,0,0,1) else
        (Int.gcdA x.value y.value,Int.gcdB x.value y.value,
          -(y.value/(Int.gcd x.value y.value:ℤ)),x.value/(Int.gcd x.value y.value:ℤ)) := by
  let out := bitListIntegerXgcd x y
  let gs := bitListTrim out.gcdDigits
  have hg : binaryDigitsValue gs=Int.gcd x.value y.value := by
    rw [bitListTrim_value]
    exact bitListIntegerXgcd_gcd_value x y
  have hz : gs.isEmpty=true ↔ Int.gcd x.value y.value=0 :=
    (canonical_isEmpty_iff_zero gs (bitListTrim_canonical _)).trans (by rw [hg])
  change (if gs.isEmpty then
    (⟨bitListNonnegativeInteger [true],bitListNonnegativeInteger [],
      bitListNonnegativeInteger [],bitListNonnegativeInteger [true]⟩ : BitListGcdPairMatrix)
    else ⟨out.left,out.right,bitListIntegerNeg (bitListIntegerExactQuotient y gs),
      bitListIntegerExactQuotient x gs⟩).value=_
  by_cases h0 : Int.gcd x.value y.value=0
  · rw [if_pos (hz.mpr h0),if_pos h0]
    rfl
  · rw [if_neg (mt hz.mp h0),if_neg h0]
    have hgp : 0<binaryDigitsValue gs := hg ▸ Nat.pos_of_ne_zero h0
    have hdx : binaryDigitsValue gs∣binaryDigitsValue x.digits := by
      rw [hg,Int.gcd_def,bitListInteger_natAbs,bitListInteger_natAbs]
      exact Nat.gcd_dvd_left _ _
    have hdy : binaryDigitsValue gs∣binaryDigitsValue y.digits := by
      rw [hg,Int.gcd_def,bitListInteger_natAbs,bitListInteger_natAbs]
      exact Nat.gcd_dvd_right _ _
    have hcoeff := bitListIntegerXgcd_coefficients x y h0
    change (out.left.value,out.right.value,(bitListIntegerNeg (bitListIntegerExactQuotient y gs)).value,
      (bitListIntegerExactQuotient x gs).value)=_
    rw [hcoeff.1,hcoeff.2,bitListIntegerNeg_value,bitListIntegerExactQuotient_value y gs hgp hdy,
      bitListIntegerExactQuotient_value x gs hgp hdx,hg]

theorem bitListGcdPairMatrix_native_eq (x y : BitListInteger) :
    (bitListGcdPairMatrix x y).value=
      (bitListGcdPairMatrix (integerBitRepresentation x.value) (integerBitRepresentation y.value)).value := by
  rw [bitListGcdPairMatrix_native_value,bitListGcdPairMatrix_bits]

theorem bitListGcdPairApply_native (x y u v : BitListInteger) :
    let M := bitListGcdPairMatrix x y
    ((bitListGcdPairApply M u v).1.value,(bitListGcdPairApply M u v).2.value)=
      integerGcdPairEquiv x.value y.value (u.value,v.value) := by
  have he := bitListGcdPairMatrix_native_eq x y
  have ha := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.1) he
  have hb := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.1) he
  have hc := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.2.1) he
  have hd := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.2.2) he
  dsimp only [BitListGcdPairMatrix.value] at ha hb hc hd
  dsimp only
  rw [bitListGcdPairApply_value,ha,hb,hc,hd,←bitListGcdPairApply_value]
  exact bitListGcdPairApply_bits x.value y.value u v

theorem bitListGcdPairInverseApply_native (x y u v : BitListInteger) :
    let M := bitListGcdPairMatrix x y
    ((bitListGcdPairInverseApply M u v).1.value,(bitListGcdPairInverseApply M u v).2.value)=
      (integerGcdPairEquiv x.value y.value).symm (u.value,v.value) := by
  have he := bitListGcdPairMatrix_native_eq x y
  have ha := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.1) he
  have hb := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.1) he
  have hc := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.2.1) he
  have hd := congrArg (fun z : ℤ×ℤ×ℤ×ℤ => z.2.2.2) he
  dsimp only [BitListGcdPairMatrix.value] at ha hb hc hd
  dsimp only
  rw [bitListGcdPairInverseApply_value,ha,hb,hc,hd,←bitListGcdPairInverseApply_value]
  exact bitListGcdPairInverseApply_bits x.value y.value u v
end Optss
