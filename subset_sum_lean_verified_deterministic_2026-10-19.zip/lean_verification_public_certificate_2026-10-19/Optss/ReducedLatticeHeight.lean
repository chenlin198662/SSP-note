import Optss.LatticePotentialBounds
import Optss.SharpLatticeDefect
import Optss.CoefficientBounds

/-!
# Integer heights after complete size reduction

Every positive integer prefix determinant lies between one and the full Gram
potential. Exact Gram–Schmidt ratios then bound all orthogonalized lengths;
size reduction bounds the actual row coordinates. These bounds apply after
each complete sweep, not yet to every partial arithmetic operation.
-/

namespace Optss
noncomputable section
open scoped BigOperators
variable {r d : ℕ}

theorem prefixGramDet_le_potential (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (t : Fin (r+1)) :
    (prefixGramDet A t).natAbs ≤ gramPotential A := by
  unfold gramPotential
  apply Finset.single_le_prod' (s := Finset.univ) (f := fun j => (prefixGramDet A j).natAbs)
  · intro j _
    have h := prefixGramDet_pos A hA j
    exact Int.natAbs_pos.mpr (ne_of_gt h)
  · exact Finset.mem_univ _

theorem gramSchmidt_sq_le_potential (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (i : Fin r) :
    ‖gramSchmidt ℝ (euclideanIntegerRows A) i‖^2 ≤ gramPotential A := by
  have hlo : (1:ℝ) ≤ (prefixGramDet A ⟨i.val, by omega⟩:ℝ) := by
    exact_mod_cast prefixGramDet_pos A hA ⟨i.val, by omega⟩
  have hhi : (prefixGramDet A ⟨i.val+1, by omega⟩:ℝ) ≤ gramPotential A := by
    have hb := prefixGramDet_le_potential A hA ⟨i.val+1, by omega⟩
    have hpos := prefixGramDet_pos A hA ⟨i.val+1, by omega⟩
    have hb' : prefixGramDet A ⟨i.val+1, by omega⟩ ≤ (gramPotential A:ℤ) := by
      simpa only [Int.natCast_natAbs, abs_of_pos hpos] using (Int.ofNat_le.mpr hb)
    exact_mod_cast hb'
  have hid := prefixGramDet_succ_eq A i
  nlinarith [sq_nonneg ‖gramSchmidt ℝ (euclideanIntegerRows A) i‖]

theorem sizeReduced_norm_sq_le_potential (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (hsize : ∀ k j : Fin r, j < k → |gsCoefficient (euclideanIntegerRows A) k j| ≤ 1/2)
    (i : Fin r) : ‖euclideanIntegerRows A i‖^2 ≤ (r:ℝ)*gramPotential A := by
  rw [norm_sq_eq_gs_sq_add]
  have hsum : (∑ j ∈ Finset.Iio i, (gsCoefficient (euclideanIntegerRows A) i j)^2 *
      ‖gramSchmidt ℝ (euclideanIntegerRows A) j‖^2) ≤ (i.val:ℝ)*gramPotential A := by
    calc
      _ ≤ ∑ _j ∈ Finset.Iio i, (gramPotential A:ℝ) := by
        apply Finset.sum_le_sum
        intro j hj
        have hμ := hsize i j (Finset.mem_Iio.mp hj)
        have hμsq : (gsCoefficient (euclideanIntegerRows A) i j)^2 ≤ 1 := by
          nlinarith [sq_abs (gsCoefficient (euclideanIntegerRows A) i j),
            abs_nonneg (gsCoefficient (euclideanIntegerRows A) i j)]
        exact (mul_le_mul_of_nonneg_right hμsq (sq_nonneg _)).trans
          (by simpa only [one_mul] using gramSchmidt_sq_le_potential A hA j)
      _ = _ := by simp
  have hi : (i.val:ℝ)+1 ≤ r := by exact_mod_cast i.isLt
  have hown := gramSchmidt_sq_le_potential A hA i
  nlinarith [mul_le_mul_of_nonneg_right hi (Nat.cast_nonneg (gramPotential A): (0:ℝ)≤gramPotential A)]

/-- Actual integer entries, not merely Gram–Schmidt coordinates, are bounded
after any complete size-reduction sweep. -/
theorem sizeReduced_entry_le_potential (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (hsize : ∀ k j : Fin r, j < k → |gsCoefficient (euclideanIntegerRows A) k j| ≤ 1/2)
    (i : Fin r) (j : Fin d) : |A i j| ≤ (r*gramPotential A:ℕ) := by
  have hn := sizeReduced_norm_sq_le_potential A hA hsize i
  have hj : |(A i j:ℝ)| ≤ ‖euclideanIntegerRows A i‖ := by
    simpa only [euclideanIntegerRows, Matrix.map_apply, Real.norm_eq_abs] using
      PiLp.norm_apply_le (euclideanIntegerRows A i) j
  have hs : ((A i j).natAbs:ℝ)^2 ≤ ((r*gramPotential A:ℕ):ℝ) := by
    rw [Int.cast_natAbs, Int.cast_abs]
    push_cast
    nlinarith [norm_nonneg (euclideanIntegerRows A i), abs_nonneg (A i j:ℝ)]
  have hsN : (A i j).natAbs^2 ≤ r*gramPotential A := by exact_mod_cast hs
  have hnat : (A i j).natAbs ≤ r*gramPotential A :=
    (Nat.le_mul_self _).trans (by simpa only [pow_two] using hsN)
  simpa only [Int.natCast_natAbs] using (Int.ofNat_le.mpr hnat)

theorem IntegerLLLResult.potential_le_input (A : Matrix (Fin r) (Fin d) ℤ)
    (out : IntegerLLLResult A) : gramPotential out.rows ≤ gramPotential A := by
  have hp : (3:ℕ)^out.swapCount ≤ 4^out.swapCount := Nat.pow_le_pow_left (by omega) _
  have h := (Nat.mul_le_mul_right (gramPotential out.rows) hp).trans out.contraction
  exact Nat.le_of_mul_le_mul_left h (by positivity)

theorem IntegerLLLResult.entry_le_input_potential (A : Matrix (Fin r) (Fin d) ℤ)
    (out : IntegerLLLResult A) (i : Fin r) (j : Fin d) :
    |out.rows i j| ≤ (r*gramPotential A:ℕ) := by
  exact (sizeReduced_entry_le_potential out.rows out.independent out.sizeReduced i j).trans
    (by exact_mod_cast Nat.mul_le_mul_left r (out.potential_le_input A))

theorem fullIntegerSweep_entry_le_potential (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (i : Fin r) (j : Fin d) :
    |roundReduceIntegerAll A r le_rfl i j| ≤ (r*gramPotential A:ℕ) := by
  obtain ⟨hind, _, hpot, hsize⟩ := fullIntegerSweep_spec A hA
  simpa only [hpot] using sizeReduced_entry_le_potential
    (roundReduceIntegerAll A r le_rfl) hind hsize i j

/-- A magnitude-bit bound for every output coordinate in terms of the actual
input height. One extra bit is enough for an external sign representation. -/
theorem IntegerLLLResult.entry_bits_bound (A : Matrix (Fin r) (Fin d) ℤ)
    (out : IntegerLLLResult A) (H : ℕ) (hA : ∀ i j, |A i j| ≤ (H:ℤ))
    (i : Fin r) (j : Fin d) :
    (out.rows i j).natAbs.size ≤
      (r*(r+1)+1)*(((r+1)*(d+1)*(H+1)^2).size) := by
  let B := (r+1)*(d+1)*(H+1)^2
  have hB : r ≤ B := by
    have h1 : 1 ≤ d+1 := by omega
    have h2 : 1 ≤ (H+1)^2 := one_le_pow₀ (by omega)
    have h3 : r+1 ≤ (r+1)*(d+1) := by nlinarith
    have h4 := Nat.mul_le_mul_left ((r+1)*(d+1)) h2
    dsimp [B]
    nlinarith
  have hp : gramPotential A ≤ B^(r*(r+1)) := by
    calc
      _ ≤ (latticeInputGramBound r d H)^(r+1) := gramPotential_height_bound A H hA
      _ ≤ (B^r)^(r+1) := Nat.pow_le_pow_left (latticeInputGramBound_le_power r d H) _
      _ = _ := by rw [pow_mul]
  have hout : (out.rows i j).natAbs ≤ r*gramPotential A := by
    have h := out.entry_le_input_potential A i j
    rw [← Int.natCast_natAbs] at h
    exact Int.ofNat_le.mp h
  apply nat_size_le_of_le_pow (by omega : 0 < r*(r+1)+1)
  calc
    _ ≤ r*gramPotential A := hout
    _ ≤ B*B^(r*(r+1)) := Nat.mul_le_mul hB hp
    _ = B^(r*(r+1)+1) := by rw [pow_succ, mul_comm]

end
end Optss
