import Optss.GreedyBlocks
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Log.Base

/-!
# Quantitative greedy scales from a repeated-sumset profile

The scale parameters are explicit rounded roots. The repeated-sumset profile
is an external mathematical input; the translation-growth consequence is
proved using the actual greedy routine. No arithmetic running time is claimed.
-/
namespace Optss
open scoped BigOperators Pointwise

/-- Root scale for the `j`th doubling interval, capped at the final scale `h`. -/
noncomputable def greedyScaleQuota (c : ℝ) (a h q0 L j : ℕ) : ℕ :=
  min h (max q0 ⌈(h : ℝ) * (1 / (c * (2 : ℝ) ^ (L - 1 - j))) ^ (a : ℝ)⁻¹⌉₊)

theorem greedyScaleQuota_bounds (c : ℝ) (a h q0 L j : ℕ) (hq0 : q0 ≤ h) :
    q0 ≤ greedyScaleQuota c a h q0 L j ∧ greedyScaleQuota c a h q0 L j ≤ h := by
  exact ⟨le_min hq0 (le_max_left _ _), min_le_left _ _⟩

variable {ι G : Type*} [LinearOrder ι] [AddCommGroup G] [DecidableEq G]

/-- The repeated-growth profile, corresponding to equation (58), on the live
value support of a particular actual copy state. -/
def GreedyRepeatedProfile (v : ι → G) (st : GreedyBlockState ι G)
    (c M : ℝ) (a h q0 : ℕ) : Prop :=
  ∀ q : ℕ, q0 ≤ q → q ≤ h →
    c * M * ((q : ℝ) / h) ^ a ≤ ((q • greedyLiveValues v st).card : ℝ)

omit [LinearOrder ι] in
/-- The explicit quota discharges Lemma 2.E's hypothesis throughout its
absolute doubling interval. If rounding reaches `h`, the no-restart bound
supplies the final-range certificate instead. -/
theorem greedyScaleQuota_growth (v : ι → G) (st : GreedyBlockState ι G)
    (c M : ℝ) (a h q0 L T j : ℕ) (hc : 0 < c) (hM : (2 : ℝ) ^ (L + 1) ≤ M)
    (ha : 1 ≤ a) (hh : 0 < h) (hq0 : q0 ≤ h) (hj : j < L)
    (hsize : st.sums.card < min (2 ^ (j + 1)) T)
    (hprofile : GreedyRepeatedProfile v st c M a h q0)
    (hnorestart : 2 * (T - 1) ≤ (h • greedyLiveValues v st).card) :
    2 * st.sums.card ≤ (greedyScaleQuota c a h q0 L j • greedyLiveValues v st).card := by
  let x : ℝ := 1 / (c * (2 : ℝ) ^ (L - 1 - j))
  let raw : ℕ := max q0 ⌈(h : ℝ) * x ^ (a : ℝ)⁻¹⌉₊
  have hx : 0 ≤ x := by dsimp [x]; positivity
  have hhR : (0 : ℝ) < h := by exact_mod_cast hh
  by_cases hcap : h ≤ raw
  · have hq : greedyScaleQuota c a h q0 L j = h := min_eq_left hcap
    rw [hq]
    exact (Nat.mul_le_mul_left 2 (by omega : st.sums.card ≤ T - 1)).trans hnorestart
  · have hq : greedyScaleQuota c a h q0 L j = raw := by
      change min h raw = raw
      exact min_eq_right (le_of_lt (lt_of_not_ge hcap))
    have hqrange := greedyScaleQuota_bounds c a h q0 L j hq0
    have hceil : (h : ℝ) * x ^ (a : ℝ)⁻¹ ≤ (raw : ℝ) :=
      (Nat.le_ceil _).trans (by exact_mod_cast (le_max_right q0 ⌈(h : ℝ) * x ^ (a : ℝ)⁻¹⌉₊))
    have hroot : x ^ (a : ℝ)⁻¹ ≤ (raw : ℝ) / h := by
      apply (le_div_iff₀ hhR).mpr
      simpa only [mul_comm] using hceil
    have hpow : x ≤ ((raw : ℝ) / h) ^ a := by
      have hp := pow_le_pow_left₀ (Real.rpow_nonneg hx _) hroot a
      simpa only [Real.rpow_inv_natCast_pow hx (by omega : a ≠ 0)] using hp
    have hprofile' := hprofile _ hqrange.1 hqrange.2
    rw [hq] at hprofile' ⊢
    have hexp : j + 2 + (L - 1 - j) = L + 1 := by omega
    have htwo : (2 : ℝ) ^ (j + 2) ≤ M / 2 ^ (L - 1 - j) := by
      apply (le_div_iff₀ (by positivity)).mpr
      rw [← pow_add, hexp]
      exact hM
    have hnum : 2 * st.sums.card ≤ 2 ^ (j + 2) := by
      have hz : st.sums.card ≤ 2 ^ (j + 1) := by omega
      have hm := Nat.mul_le_mul_left 2 hz
      simpa only [pow_succ, Nat.mul_comm, Nat.mul_assoc] using hm
    have hM0 : 0 ≤ M := (by positivity : (0 : ℝ) ≤ 2 ^ (L + 1)).trans hM
    have hbound : (2 * st.sums.card : ℕ) ≤ (raw • greedyLiveValues v st).card := by
      apply (Nat.cast_le (α := ℝ)).mp
      calc
        ((2 * st.sums.card : ℕ) : ℝ) ≤ (2 : ℝ) ^ (j + 2) := by exact_mod_cast hnum
        _ ≤ M / 2 ^ (L - 1 - j) := htwo
        _ = c * M * x := by dsimp [x]; field_simp; ring
        _ ≤ c * M * ((raw : ℝ) / h) ^ a :=
          mul_le_mul_of_nonneg_left hpow (mul_nonneg hc.le hM0)
        _ ≤ _ := hprofile'
    exact hbound

/-- The fixed geometric ratio determined by the profile exponent. -/
noncomputable def greedyScaleRatio (a : ℕ) : ℝ := (1 / 2 : ℝ) ^ (a : ℝ)⁻¹

theorem greedyScaleRatio_bounds (a : ℕ) (ha : 1 ≤ a) :
    0 < greedyScaleRatio a ∧ greedyScaleRatio a < 1 := by
  have haR : (0 : ℝ) < a := by exact_mod_cast (by omega : 0 < a)
  exact ⟨Real.rpow_pos_of_pos (by norm_num) _,
    Real.rpow_lt_one (by norm_num) (by norm_num) (inv_pos.mpr haR)⟩

theorem greedyScale_root_factor (c : ℝ) (hc : 0 < c) (a n : ℕ) :
    (1 / (c * (2 : ℝ) ^ n)) ^ (a : ℝ)⁻¹ =
      (1 / c) ^ (a : ℝ)⁻¹ * greedyScaleRatio a ^ n := by
  have he : 1 / (c * (2 : ℝ) ^ n) = (1 / c) * (1 / 2 : ℝ) ^ n := by
    rw [div_pow]
    field_simp
  rw [he, Real.mul_rpow (by positivity) (by positivity)]
  congr 1
  unfold greedyScaleRatio
  rw [← Real.rpow_natCast_mul (by norm_num : (0 : ℝ) ≤ 1 / 2),
    ← Real.rpow_mul_natCast (by norm_num : (0 : ℝ) ≤ 1 / 2)]
  congr 1
  ring

theorem greedyScaleQuota_le_geometric (c : ℝ) (hc : 0 < c) (a h q0 L : ℕ) (j : Fin L) :
    greedyScaleQuota c a h q0 L j.val ≤ q0 +
      greedyGeometricQuota ((h : ℝ) * (1 / c) ^ (a : ℝ)⁻¹) (greedyScaleRatio a) L j := by
  unfold greedyScaleQuota greedyGeometricQuota
  rw [greedyScale_root_factor c hc, ← mul_assoc]
  omega

/-- Explicit total fuel for all absolute doubling intervals. -/
noncomputable def greedyScaleBudget (c : ℝ) (a h q0 L : ℕ) : ℕ :=
  2 * ∑ j ∈ Finset.range L, greedyScaleQuota c a h q0 L j

/-- The geometric part costs a constant times `h`; the small-scale and rounding
costs are at most `2(q0+1)L`. The constant depends only on `c` and `a`. -/
theorem greedyScaleBudget_le (c : ℝ) (hc : 0 < c) (a h q0 L : ℕ) (ha : 1 ≤ a) :
    (greedyScaleBudget c a h q0 L : ℝ) ≤
      2 * ((h : ℝ) * (1 / c) ^ (a : ℝ)⁻¹ / (1 - greedyScaleRatio a) + (q0 + 1 : ℕ) * L) := by
  let Q : ℝ := (h : ℝ) * (1 / c) ^ (a : ℝ)⁻¹
  have hsum : (∑ j ∈ Finset.range L, greedyScaleQuota c a h q0 L j) ≤
      L * q0 + (List.ofFn (greedyGeometricQuota Q (greedyScaleRatio a) L)).sum := by
    rw [Finset.sum_range, List.sum_ofFn]
    calc
      _ ≤ ∑ j : Fin L, (q0 + greedyGeometricQuota Q (greedyScaleRatio a) L j) :=
        Finset.sum_le_sum (fun j _ => greedyScaleQuota_le_geometric c hc a h q0 L j)
      _ = _ := by simp [Finset.sum_add_distrib]
  have hsumR : ((∑ j ∈ Finset.range L, greedyScaleQuota c a h q0 L j) : ℝ) ≤
      (L : ℝ) * q0 + ((List.ofFn (greedyGeometricQuota Q (greedyScaleRatio a) L)).sum : ℝ) := by
    exact_mod_cast hsum
  have hgeo := greedyGeometricQuota_sum_le Q (greedyScaleRatio a) (by dsimp [Q]; positivity)
    (greedyScaleRatio_bounds a ha).1.le (greedyScaleRatio_bounds a ha).2 L
  unfold greedyScaleBudget
  push_cast
  dsimp only [Q] at hgeo
  nlinarith

/-- The doubling argument works for any nearer target, including the last
partially filled doubling interval. -/
theorem greedyBlockRun_reaches (v : ι → G) (st : GreedyBlockState ι G)
    (hS : st.sums.Nonempty) (q T : ℕ) (hq : 1 ≤ q) (hT : T ≤ 2 * st.sums.card)
    (hcert : ∀ n < 2 * q, (greedyBlockRun v n st).sums.card < T →
      2 * (greedyBlockRun v n st).sums.card ≤
        (q • greedyLiveValues v (greedyBlockRun v n st)).card) :
    T ≤ (greedyBlockRun v (2 * q) st).sums.card := by
  have hmono := greedyBlockRun_support_mono v st
  have hprogress : ∀ n ≤ 2 * q,
      T ≤ (greedyBlockRun v n st).sums.card ∨
      (2 * q + n) * st.sums.card ≤ 2 * q * (greedyBlockRun v n st).sums.card := by
    intro n
    induction n with
    | zero => intro _; right; simp [greedyBlockRun]
    | succ n ih =>
      intro hn
      have hstepmono := Finset.card_le_card (hmono (Nat.le_succ n))
      rcases ih (by omega) with hdone | hp
      · exact Or.inl (hdone.trans hstepmono)
      · by_cases hdone : T ≤ (greedyBlockRun v n st).sums.card
        · exact Or.inl (hdone.trans hstepmono)
        · right
          have hbase : st.sums.card ≤ (greedyBlockRun v n st).sums.card :=
            Finset.card_le_card (hmono (Nat.zero_le n))
          have hstep := greedyBlockStep_growth v (greedyBlockRun v n st)
            (hS.mono (hmono (Nat.zero_le n))) q hq (hcert n (by omega) (by omega))
          change 2 * q * (greedyBlockRun v n st).sums.card +
            (greedyBlockRun v n st).sums.card ≤
            2 * q * (greedyBlockRun v (n+1) st).sums.card at hstep
          nlinarith
  rcases hprogress (2 * q) le_rfl with hdone | hp
  · exact hdone
  · apply hT.trans
    apply Nat.le_of_mul_le_mul_left (c := 2 * q) _ (by omega)
    nlinarith

/-- The bounded target-stopping routine inherits the proved growth certificate. -/
theorem greedyBlockUntil_reaches (v : ι → G) (st : GreedyBlockState ι G)
    (hS : st.sums.Nonempty) (q T : ℕ) (hq : 1 ≤ q) (hT : T ≤ 2 * st.sums.card)
    (hcert : ∀ n < 2 * q, (greedyBlockRun v n st).sums.card < T →
      2 * (greedyBlockRun v n st).sums.card ≤
        (q • greedyLiveValues v (greedyBlockRun v n st)).card) :
    T ≤ (greedyBlockUntil v T (2 * q) st).sums.card := by
  obtain ⟨k, _, he, hstop⟩ := greedyBlockUntil_eq_run v T (2 * q) st
  rcases hstop with hdone | rfl
  · exact hdone
  · rw [he]
    exact greedyBlockRun_reaches v st hS q T hq hT hcert

theorem greedyBlockRun_add (v : ι → G) (st : GreedyBlockState ι G) (n k : ℕ) :
    greedyBlockRun v k (greedyBlockRun v n st) = greedyBlockRun v (n + k) st := by
  induction k with
  | zero => simp [greedyBlockRun]
  | succ k ih => simp only [greedyBlockRun, ih, Nat.add_assoc]; rfl

/-- Explicit repeated-growth data along the actual run implies that the
bounded greedy loop reaches its final target. Profile/no-restart hypotheses are
needed only during its finite budget and before reaching that target. -/
theorem greedyBlockScales_reaches (v : ι → G) (st : GreedyBlockState ι G)
    (hst : st.Valid v) (c M : ℝ) (a h q0 L T : ℕ) (hc : 0 < c)
    (hM : (2 : ℝ) ^ (L + 1) ≤ M) (ha : 1 ≤ a) (hq0 : 1 ≤ q0)
    (hq0h : q0 ≤ h) (hT : T ≤ 2 ^ L)
    (hprofile : ∀ n < greedyScaleBudget c a h q0 L,
      (greedyBlockRun v n st).sums.card < T →
      GreedyRepeatedProfile v (greedyBlockRun v n st) c M a h q0)
    (hnorestart : ∀ n < greedyScaleBudget c a h q0 L,
      (greedyBlockRun v n st).sums.card < T →
      2 * (T - 1) ≤ (h • greedyLiveValues v (greedyBlockRun v n st)).card) :
    let out := greedyBlockUntil v T (greedyScaleBudget c a h q0 L) st
    out.Valid v ∧ T ≤ out.sums.card ∧
    out.chosen.card ≤ st.chosen.card + greedyScaleBudget c a h q0 L ∧
    out.chosen ∪ out.remaining = st.chosen ∪ st.remaining := by
  let q := greedyScaleQuota c a h q0 L
  have hS : st.sums.Nonempty := by
    rw [hst.2]
    exact ⟨0, zero_mem_labelledSubsetSupport v st.chosen⟩
  have hprefix : ∀ j ≤ L, 2 * (∑ p ∈ Finset.range j, q p) ≤ greedyScaleBudget c a h q0 L := by
    intro j hj
    apply Nat.mul_le_mul_left
    exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono hj) (fun _ _ _ => Nat.zero_le _)
  have hstage : ∀ j ≤ L, ∃ n ≤ 2 * ∑ p ∈ Finset.range j, q p,
      min (2 ^ j) T ≤ (greedyBlockRun v n st).sums.card := by
    intro j
    induction j with
    | zero =>
      intro _
      refine ⟨0, by simp, ?_⟩
      have hspos := Finset.card_pos.mpr hS
      simpa only [pow_zero, greedyBlockRun] using (min_le_left 1 T).trans hspos
    | succ j ih =>
      intro hjL
      obtain ⟨n, hn, hs⟩ := ih (by omega)
      have hj : j < L := by omega
      have hsum : 2 * (∑ p ∈ Finset.range (j+1), q p) =
          2 * (∑ p ∈ Finset.range j, q p) + 2 * q j := by rw [Finset.sum_range_succ]; omega
      by_cases hdone : min (2 ^ (j+1)) T ≤ (greedyBlockRun v n st).sums.card
      · exact ⟨n, by rw [hsum]; omega, hdone⟩
      · have hbelowT : (greedyBlockRun v n st).sums.card < T := by omega
        have hprev : 2 ^ j ≤ (greedyBlockRun v n st).sums.card := by omega
        have hnear : min (2 ^ (j+1)) T ≤ 2 * (greedyBlockRun v n st).sums.card := by
          have := min_le_left (2 ^ (j+1)) T
          rw [pow_succ] at this
          omega
        have hq : 1 ≤ q j := hq0.trans (greedyScaleQuota_bounds c a h q0 L j hq0h).1
        have hcert : ∀ t < 2 * q j,
            (greedyBlockRun v t (greedyBlockRun v n st)).sums.card < min (2 ^ (j+1)) T →
            2 * (greedyBlockRun v t (greedyBlockRun v n st)).sums.card ≤
              (q j • greedyLiveValues v (greedyBlockRun v t (greedyBlockRun v n st))).card := by
          intro t ht hsize
          rw [greedyBlockRun_add] at hsize ⊢
          have hindex : n + t < greedyScaleBudget c a h q0 L := by
            have hp := hprefix (j+1) hjL
            rw [hsum] at hp
            omega
          have hsizeT : (greedyBlockRun v (n+t) st).sums.card < T := by omega
          exact greedyScaleQuota_growth v (greedyBlockRun v (n+t) st) c M a h q0 L T j
            hc hM ha (by omega) hq0h hj hsize
            (hprofile (n+t) hindex hsizeT) (hnorestart (n+t) hindex hsizeT)
        have hreach := greedyBlockUntil_reaches v (greedyBlockRun v n st)
          (hS.mono (greedyBlockRun_support_mono v st (Nat.zero_le n))) (q j)
          (min (2 ^ (j+1)) T) hq hnear hcert
        obtain ⟨k, hk, he, _⟩ := greedyBlockUntil_eq_run v (min (2 ^ (j+1)) T)
          (2 * q j) (greedyBlockRun v n st)
        refine ⟨n+k, by rw [hsum]; omega, ?_⟩
        rw [he, greedyBlockRun_add] at hreach
        exact hreach
  obtain ⟨n, hn, hreach⟩ := hstage L le_rfl
  rw [min_eq_right hT] at hreach
  have hfull : T ≤ (greedyBlockRun v (greedyScaleBudget c a h q0 L) st).sums.card :=
    hreach.trans (Finset.card_le_card (greedyBlockRun_support_mono v st hn))
  obtain ⟨k, hk, he, hstop⟩ := greedyBlockUntil_eq_run v T (greedyScaleBudget c a h q0 L) st
  refine ⟨he.symm ▸ greedyBlockRun_valid v st hst k, ?_, ?_, ?_⟩
  · rcases hstop with hdone | rfl
    · exact hdone
    · rw [he]
      exact hfull
  · rw [he, greedyBlockRun_chosen_card v st hst k]
    omega
  · rw [he]
    exact greedyBlockRun_partition v st k

omit [LinearOrder ι] in
/-- Enlarging a nonnegative real profile exponent to an integer only weakens
the lower bound on scales at most `h`. Thus the integer-exponent analysis
applies to the paper's arbitrary fixed exponent by rounding it upward. -/
theorem greedyRepeatedProfile_of_real_exponent (v : ι → G) (st : GreedyBlockState ι G)
    (c M e : ℝ) (a h q0 : ℕ) (hc : 0 ≤ c) (hM : 0 ≤ M) (he : 0 ≤ e)
    (hea : e ≤ a) (hh : 0 < h)
    (hp : ∀ q : ℕ, q0 ≤ q → q ≤ h →
      c * M * ((q : ℝ) / h) ^ e ≤ ((q • greedyLiveValues v st).card : ℝ)) :
    GreedyRepeatedProfile v st c M a h q0 := by
  intro q hq0 hqh
  have hhR : (0 : ℝ) < h := by exact_mod_cast hh
  have hbase : (q : ℝ) / h ≤ 1 := (div_le_one hhR).mpr (by exact_mod_cast hqh)
  have hpow := Real.rpow_le_rpow_of_exponent_ge' (by positivity : (0 : ℝ) ≤ (q : ℝ) / h)
    hbase he hea
  rw [Real.rpow_natCast] at hpow
  exact (mul_le_mul_of_nonneg_left hpow (mul_nonneg hc hM)).trans (hp q hq0 hqh)

/-- The integer threshold is the least integer at least one quarter of `M`. -/
def greedyQuarterTarget (M : ℕ) : ℕ := (M + 3) / 4

theorem greedyQuarterTarget_bounds (M : ℕ) (hM : 4 ≤ M) :
    1 ≤ greedyQuarterTarget M ∧ M ≤ 4 * greedyQuarterTarget M ∧ greedyQuarterTarget M ≤ M := by
  have hdiv := Nat.mod_add_div (M + 3) 4
  have hmod := Nat.mod_lt (M + 3) (by decide : 0 < 4)
  unfold greedyQuarterTarget
  omega

/-- The chosen logarithmic number of intervals satisfies both conditions of
the quantitative growth proof, including the last fractional quarter interval. -/
theorem greedyQuarterTarget_scale_count (M : ℕ) (hM : 4 ≤ M) :
    greedyQuarterTarget M ≤ 2 ^ Nat.clog 2 (greedyQuarterTarget M) ∧
      2 ^ (Nat.clog 2 (greedyQuarterTarget M) + 1) ≤ M := by
  refine ⟨Nat.le_pow_clog (by decide) _, ?_⟩
  have ht := greedyQuarterTarget_bounds M hM
  by_cases ht1 : greedyQuarterTarget M = 1
  · simp [ht1]
    omega
  · have ht2 : 1 < greedyQuarterTarget M := by omega
    have hL := Nat.clog_pos (by decide : 1 < 2) ht2
    have hp := Nat.pow_pred_clog_lt_self (by decide : 1 < 2) ht2
    have hdiv := Nat.div_mul_le_self (M + 3) 4
    change greedyQuarterTarget M * 4 ≤ M + 3 at hdiv
    simp only [Nat.pred_eq_sub_one] at hp
    have he : Nat.clog 2 (greedyQuarterTarget M) + 1 =
        (Nat.clog 2 (greedyQuarterTarget M) - 1) + 2 := by omega
    rw [he, pow_add]
    norm_num
    omega

/-- The small-scale cutoff used in the paper. -/
noncomputable def greedySqrtCutoff (h : ℕ) : ℕ := ⌈Real.sqrt h⌉₊

theorem greedySqrtCutoff_bounds (h : ℕ) (hh : 1 ≤ h) :
    1 ≤ greedySqrtCutoff h ∧ greedySqrtCutoff h ≤ h ∧
      (greedySqrtCutoff h : ℝ) ≤ 2 * Real.sqrt h := by
  have hhR : (1 : ℝ) ≤ h := by exact_mod_cast hh
  have hs1 : (1 : ℝ) ≤ Real.sqrt h := Real.one_le_sqrt.mpr hhR
  have hsh : Real.sqrt h ≤ h := Real.sqrt_le_iff.mpr ⟨by positivity, by nlinarith⟩
  have hceil := Nat.le_ceil (Real.sqrt (h : ℝ))
  have hceil' := Nat.ceil_lt_add_one (Real.sqrt_nonneg (h : ℝ))
  have hpos : 1 ≤ greedySqrtCutoff h := by
    apply (Nat.cast_le (α := ℝ)).mp
    simpa only [Nat.cast_one, greedySqrtCutoff] using hs1.trans hceil
  refine ⟨hpos, Nat.ceil_le.mpr hsh, ?_⟩
  change (⌈Real.sqrt (h : ℝ)⌉₊ : ℝ) ≤ _
  linarith

/-- A fully explicit version of `ceil(sqrt(h))*log(M+2)=O_eta(h)` under
`N^eta≤h` and `M≤hN+1`. The constant works uniformly for `eta>0`. -/
theorem greedySqrtCutoff_mul_log_le (h N M : ℕ) (hh : 1 ≤ h) (hN : 1 ≤ N)
    (η : ℝ) (hη : 0 < η) (hscale : (N : ℝ) ^ η ≤ h) (hM : M ≤ h * N + 1) :
    (greedySqrtCutoff h : ℝ) * Real.log ((M : ℝ) + 2) ≤ (12 + 4 / η) * h := by
  have hhR : (1 : ℝ) ≤ h := by exact_mod_cast hh
  have hNR : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hhpos : (0 : ℝ) < h := by positivity
  have hNpos : (0 : ℝ) < N := by positivity
  have hMreal : (M : ℝ) ≤ (h : ℝ) * N + 1 := by exact_mod_cast hM
  have hprod : (1 : ℝ) ≤ (h : ℝ) * N := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hhR) (sub_nonneg.mpr hNR)]
  have hlogN : Real.log (N : ℝ) ≤ Real.log (h : ℝ) / η := by
    have hl := Real.log_le_log (Real.rpow_pos_of_pos hNpos η) hscale
    rw [Real.log_rpow hNpos] at hl
    apply (le_div_iff₀ hη).mpr
    nlinarith
  have hlogh : Real.log (h : ℝ) ≤ 2 * Real.sqrt h := by
    have hl := Real.log_le_rpow_div (Nat.cast_nonneg h) (by norm_num : (0 : ℝ) < 1 / 2)
    rw [← Real.sqrt_eq_rpow] at hl
    nlinarith
  have hlog : Real.log ((M : ℝ) + 2) ≤ 4 + (1 + 1 / η) * Real.log (h : ℝ) := by
    have hcomp : (M : ℝ) + 2 ≤ 4 * (h : ℝ) * N := by nlinarith
    have hl := Real.log_le_log (by positivity : (0 : ℝ) < (M : ℝ) + 2) hcomp
    rw [Real.log_mul (by positivity) (ne_of_gt hNpos),
      Real.log_mul (by norm_num : (4 : ℝ) ≠ 0) (ne_of_gt hhpos)] at hl
    have hl4 := Real.log_le_self (by norm_num : (0 : ℝ) ≤ 4)
    simp only [div_eq_mul_inv] at hlogN ⊢
    nlinarith
  have hηinv : 0 ≤ 1 / η := by positivity
  have hlog' : Real.log ((M : ℝ) + 2) ≤ 4 + 2 * (1 + 1 / η) * Real.sqrt h := by
    have hm := mul_le_mul_of_nonneg_left hlogh (by positivity : (0 : ℝ) ≤ 1 + 1 / η)
    nlinarith
  have hcut := (greedySqrtCutoff_bounds h hh).2.2
  have hlogpos : 0 ≤ Real.log ((M : ℝ) + 2) := Real.log_nonneg (by have := (Nat.cast_nonneg M : (0 : ℝ) ≤ M); linarith)
  have hspos := Real.sqrt_nonneg (h : ℝ)
  have hs1 : (1 : ℝ) ≤ Real.sqrt h := Real.one_le_sqrt.mpr hhR
  have hsq := Real.sq_sqrt (Nat.cast_nonneg h)
  have hsh : Real.sqrt h ≤ h := by nlinarith
  calc
    (greedySqrtCutoff h : ℝ) * Real.log ((M : ℝ) + 2) ≤
        (2 * Real.sqrt h) * (4 + 2 * (1 + 1 / η) * Real.sqrt h) :=
      mul_le_mul hcut hlog' hlogpos (by positivity)
    _ = 8 * Real.sqrt h + (4 + 4 / η) * h := by
      calc
        _ = 8 * Real.sqrt h + (4 + 4 / η) * (Real.sqrt h) ^ 2 := by ring
        _ = _ := by rw [hsq]
    _ ≤ (12 + 4 / η) * h := by nlinarith

theorem greedyQuarterTarget_log_count (M : ℕ) (hM : 4 ≤ M) :
    (Nat.clog 2 (greedyQuarterTarget M) : ℝ) ≤
      Real.log ((M : ℝ) + 2) / Real.log 2 + 1 := by
  have ht := greedyQuarterTarget_bounds M hM
  have hTR : (1 : ℝ) ≤ greedyQuarterTarget M := by exact_mod_cast ht.1
  have hlog := Real.logb_nonneg (by norm_num : (1 : ℝ) < 2) hTR
  have hceil := (Nat.ceil_lt_add_one hlog).le
  have he : ⌈Real.logb 2 (greedyQuarterTarget M : ℝ)⌉₊ = Nat.clog 2 (greedyQuarterTarget M) :=
    Real.natCeil_logb_natCast 2 _
  rw [he] at hceil
  have hTpos : (0 : ℝ) < greedyQuarterTarget M := by positivity
  have hlogT := Real.log_le_log hTpos (show (greedyQuarterTarget M : ℝ) ≤ (M : ℝ) + 2 by
    have htM : (greedyQuarterTarget M : ℝ) ≤ M := by exact_mod_cast ht.2.2
    linarith)
  have hdiv := div_le_div_of_nonneg_right hlogT (Real.log_pos (by norm_num : (1 : ℝ) < 2)).le
  exact hceil.trans (add_le_add_right hdiv 1)

/-- Both the minimum scale and the number of scales are now the manuscript's
explicit choices. The resulting small-scale term is linear in `h`. -/
theorem greedySqrtCutoff_mul_scale_count_le (h N M : ℕ) (hh : 1 ≤ h)
    (hN : 1 ≤ N) (hM4 : 4 ≤ M) (η : ℝ) (hη : 0 < η)
    (hscale : (N : ℝ) ^ η ≤ h) (hM : M ≤ h * N + 1) :
    ((greedySqrtCutoff h + 1 : ℕ) : ℝ) * Nat.clog 2 (greedyQuarterTarget M) ≤
      (2 * (12 + 4 / η) / Real.log 2 + 2) * h := by
  have hcut := greedySqrtCutoff_bounds h hh
  have hplus : ((greedySqrtCutoff h + 1 : ℕ) : ℝ) ≤ 2 * greedySqrtCutoff h := by
    exact_mod_cast (show greedySqrtCutoff h + 1 ≤ 2 * greedySqrtCutoff h by omega)
  have hcutH : (greedySqrtCutoff h : ℝ) ≤ h := by exact_mod_cast hcut.2.1
  have hcount := greedyQuarterTarget_log_count M hM4
  have hlog := greedySqrtCutoff_mul_log_le h N M hh hN η hη hscale hM
  have hl2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  calc
    ((greedySqrtCutoff h + 1 : ℕ) : ℝ) * Nat.clog 2 (greedyQuarterTarget M) ≤
        (2 * greedySqrtCutoff h) * (Real.log ((M : ℝ) + 2) / Real.log 2 + 1) :=
      mul_le_mul hplus hcount (Nat.cast_nonneg _) (by positivity)
    _ = 2 * ((greedySqrtCutoff h : ℝ) * Real.log ((M : ℝ) + 2)) / Real.log 2 +
        2 * greedySqrtCutoff h := by ring
    _ ≤ 2 * ((12 + 4 / η) * h) / Real.log 2 + 2 * h := by
      exact add_le_add (div_le_div_of_nonneg_right (by linarith) hl2.le) (by linarith)
    _ = _ := by ring

/-- An explicit constant proving the complete multi-scale selection budget is
`O_{c,a,eta}(h)` under the paper's ambient-size relations. -/
theorem greedyScaleBudget_linear (c : ℝ) (hc : 0 < c) (a h N M : ℕ)
    (ha : 1 ≤ a) (hh : 1 ≤ h) (hN : 1 ≤ N) (hM4 : 4 ≤ M)
    (η : ℝ) (hη : 0 < η) (hscale : (N : ℝ) ^ η ≤ h) (hM : M ≤ h * N + 1) :
    (greedyScaleBudget c a h (greedySqrtCutoff h) (Nat.clog 2 (greedyQuarterTarget M)) : ℝ) ≤
      (2 * ((1 / c) ^ (a : ℝ)⁻¹ / (1 - greedyScaleRatio a) +
        2 * (12 + 4 / η) / Real.log 2 + 2)) * h := by
  have hb := greedyScaleBudget_le c hc a h (greedySqrtCutoff h)
    (Nat.clog 2 (greedyQuarterTarget M)) ha
  have hs := greedySqrtCutoff_mul_scale_count_le h N M hh hN hM4 η hη hscale hM
  calc
    _ ≤ 2 * ((h : ℝ) * (1 / c) ^ (a : ℝ)⁻¹ / (1 - greedyScaleRatio a) +
        (2 * (12 + 4 / η) / Real.log 2 + 2) * h) := by linarith
    _ = _ := by ring

/-- An explicit integer exponent dominating any given real exponent. -/
noncomputable def greedyProfileExponent (e : ℝ) : ℕ := max 1 ⌈e⌉₊

theorem greedyProfileExponent_bounds (e : ℝ) :
    1 ≤ greedyProfileExponent e ∧ e ≤ (greedyProfileExponent e : ℝ) := by
  refine ⟨le_max_left _ _, (Nat.le_ceil e).trans ?_⟩
  exact_mod_cast (le_max_right 1 ⌈e⌉₊)

/-- Complete explicit analysis budget for the paper's quarter-density target. -/
noncomputable def greedyPaperScaleBudget (c : ℝ) (a h M : ℕ) : ℕ :=
  greedyScaleBudget c a h (greedySqrtCutoff h) (Nat.clog 2 (greedyQuarterTarget M))

/-- The actual greedy loop reaches density `M/4` using a number of new copies
bounded by an explicit constant times `h`. All multi-scale certificates have
been derived from the repeated-growth profile and the no-restart bound. -/
theorem greedyQuarterBlock_from_profile (v : ι → G) (st : GreedyBlockState ι G)
    (hst : st.Valid v) (c : ℝ) (hc : 0 < c) (a h N M : ℕ)
    (ha : 1 ≤ a) (hh : 1 ≤ h) (hN : 1 ≤ N) (hM4 : 4 ≤ M)
    (η : ℝ) (hη : 0 < η) (hscale : (N : ℝ) ^ η ≤ h) (hM : M ≤ h * N + 1)
    (hprofile : ∀ n < greedyPaperScaleBudget c a h M,
      (greedyBlockRun v n st).sums.card < greedyQuarterTarget M →
      GreedyRepeatedProfile v (greedyBlockRun v n st) c (M : ℝ) a h (greedySqrtCutoff h))
    (hnorestart : ∀ n < greedyPaperScaleBudget c a h M,
      (greedyBlockRun v n st).sums.card < greedyQuarterTarget M →
      (M : ℝ) / 2 ≤ ((h • greedyLiveValues v (greedyBlockRun v n st)).card : ℝ)) :
    let out := greedyBlockUntil v (greedyQuarterTarget M) (greedyPaperScaleBudget c a h M) st
    out.Valid v ∧ (M : ℝ) / 4 ≤ out.sums.card ∧
    (out.chosen.card : ℝ) ≤ st.chosen.card +
      (2 * ((1 / c) ^ (a : ℝ)⁻¹ / (1 - greedyScaleRatio a) +
        2 * (12 + 4 / η) / Real.log 2 + 2)) * h ∧
    out.chosen ∪ out.remaining = st.chosen ∪ st.remaining := by
  have hcut := greedySqrtCutoff_bounds h hh
  have hcount := greedyQuarterTarget_scale_count M hM4
  have hT := greedyQuarterTarget_bounds M hM4
  have hlow : 4 * (greedyQuarterTarget M - 1) ≤ M := by
    have hd := Nat.div_mul_le_self (M+3) 4
    change greedyQuarterTarget M * 4 ≤ M + 3 at hd
    omega
  have hno : ∀ n < greedyScaleBudget c a h (greedySqrtCutoff h)
      (Nat.clog 2 (greedyQuarterTarget M)),
      (greedyBlockRun v n st).sums.card < greedyQuarterTarget M →
      2 * (greedyQuarterTarget M - 1) ≤
        (h • greedyLiveValues v (greedyBlockRun v n st)).card := by
    intro n hn hs
    have hnore := hnorestart n hn hs
    have hlowR : (4 : ℝ) * (greedyQuarterTarget M - 1 : ℕ) ≤ M := by exact_mod_cast hlow
    apply (Nat.cast_le (α := ℝ)).mp
    push_cast
    nlinarith
  obtain ⟨hv, hreach, hchosen, hp⟩ := greedyBlockScales_reaches v st hst c (M : ℝ)
    a h (greedySqrtCutoff h) (Nat.clog 2 (greedyQuarterTarget M)) (greedyQuarterTarget M)
    hc (by exact_mod_cast hcount.2) ha hcut.1 hcut.2.1 hcount.1 hprofile hno
  refine ⟨hv, ?_, ?_, hp⟩
  · apply (div_le_iff₀ (by norm_num : (0 : ℝ) < 4)).mpr
    have hm := hT.2.1.trans (Nat.mul_le_mul_left 4 hreach)
    exact_mod_cast (by simpa only [Nat.mul_comm] using hm)
  · have hb := greedyScaleBudget_linear c hc a h N M ha hh hN hM4 η hη hscale hM
    have hchosenR : ((greedyBlockUntil v (greedyQuarterTarget M)
        (greedyPaperScaleBudget c a h M) st).chosen.card : ℝ) ≤
        st.chosen.card + (greedyPaperScaleBudget c a h M : ℝ) := by exact_mod_cast hchosen
    exact hchosenR.trans (add_le_add_left hb _)

theorem greedyBlockUntil_of_target_le (v : ι → G) (st : GreedyBlockState ι G)
    (T n : ℕ) (hT : T ≤ st.sums.card) : greedyBlockUntil v T n st = st := by
  cases n <;> simp [greedyBlockUntil, hT]

/-- Tiny quarter-density targets are already met by the empty subset. -/
theorem greedyQuarterBlock_small (v : ι → G) (st : GreedyBlockState ι G)
    (hst : st.Valid v) (M n : ℕ) (hM : M < 4) :
    greedyBlockUntil v (greedyQuarterTarget M) n st = st ∧ (M : ℝ) / 4 ≤ st.sums.card := by
  have hsize : 1 ≤ st.sums.card := by
    apply Finset.card_pos.mpr
    rw [hst.2]
    exact ⟨0, zero_mem_labelledSubsetSupport v st.chosen⟩
  have hT : greedyQuarterTarget M ≤ 1 := by unfold greedyQuarterTarget; omega
  refine ⟨greedyBlockUntil_of_target_le v st _ n (hT.trans hsize), ?_⟩
  have hsizeR : (1 : ℝ) ≤ st.sums.card := by exact_mod_cast hsize
  have hMR : (M : ℝ) < 4 := by exact_mod_cast hM
  linarith

/-- All target sizes, including zero and tiny instances, satisfy the complete
linear-in-`h` greedy block bound once the repeated-growth profile is supplied. -/
theorem greedyQuarterBlock_from_profile_all (v : ι → G) (st : GreedyBlockState ι G)
    (hst : st.Valid v) (c : ℝ) (hc : 0 < c) (a h N M : ℕ)
    (ha : 1 ≤ a) (hh : 1 ≤ h) (hN : 1 ≤ N)
    (η : ℝ) (hη : 0 < η) (hscale : (N : ℝ) ^ η ≤ h) (hM : M ≤ h * N + 1)
    (hprofile : ∀ n < greedyPaperScaleBudget c a h M,
      (greedyBlockRun v n st).sums.card < greedyQuarterTarget M →
      GreedyRepeatedProfile v (greedyBlockRun v n st) c (M : ℝ) a h (greedySqrtCutoff h))
    (hnorestart : ∀ n < greedyPaperScaleBudget c a h M,
      (greedyBlockRun v n st).sums.card < greedyQuarterTarget M →
      (M : ℝ) / 2 ≤ ((h • greedyLiveValues v (greedyBlockRun v n st)).card : ℝ)) :
    let out := greedyBlockUntil v (greedyQuarterTarget M) (greedyPaperScaleBudget c a h M) st
    out.Valid v ∧ (M : ℝ) / 4 ≤ out.sums.card ∧
    (out.chosen.card : ℝ) ≤ st.chosen.card +
      (2 * ((1 / c) ^ (a : ℝ)⁻¹ / (1 - greedyScaleRatio a) +
        2 * (12 + 4 / η) / Real.log 2 + 2)) * h ∧
    out.chosen ∪ out.remaining = st.chosen ∪ st.remaining := by
  by_cases hM4 : 4 ≤ M
  · exact greedyQuarterBlock_from_profile v st hst c hc a h N M ha hh hN hM4
      η hη hscale hM hprofile hnorestart
  · obtain ⟨he, hdense⟩ := greedyQuarterBlock_small v st hst M
      (greedyPaperScaleBudget c a h M) (by omega)
    dsimp only
    rw [he]
    refine ⟨hst, hdense, ?_, rfl⟩
    have hr : 0 < 1 - greedyScaleRatio a := sub_pos.mpr (greedyScaleRatio_bounds a ha).2
    have hl : 0 < Real.log 2 := Real.log_pos (by norm_num)
    have hnonneg : 0 ≤
        (2 * ((1 / c) ^ (a : ℝ)⁻¹ / (1 - greedyScaleRatio a) +
          2 * (12 + 4 / η) / Real.log 2 + 2)) * h := by positivity
    linarith

end Optss
