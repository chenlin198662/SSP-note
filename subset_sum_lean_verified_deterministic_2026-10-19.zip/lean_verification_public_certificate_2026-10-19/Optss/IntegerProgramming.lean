import Optss.Basic
import Mathlib.Algebra.BigOperators.Pi
import Mathlib.Algebra.BigOperators.Ring.Finset

/-!
# Algebraic integer-programming reductions

This file proves the exact feasibility correspondences in §11 of the manuscript:
shifting finite variable bounds, encoding binary choices, adding integer slack
variables, and appending prescribed cardinalities. No proximity theorem or
running-time assertion is assumed or claimed here.
-/

namespace Optss

open scoped BigOperators

variable {ι G : Type*} [Fintype ι] [AddCommGroup G]

/-- Feasibility of the equation with integral lower and upper variable bounds. -/
def BoundedIP (v : ι → G) (l u : ι → ℤ) (t : G) : Prop :=
  ∃ x : ι → ℤ, (∀ i, l i ≤ x i ∧ x i ≤ u i) ∧ weightedSum v x = t

/-- §11: subtracting the lower bounds produces nonnegative bounded counts.
The equivalence also handles inconsistent bounds, with both sides infeasible. -/
theorem boundedIP_iff_countSums (v : ι → G) (l u : ι → ℤ) (t : G) :
    BoundedIP v l u t ↔
      t - weightedSum v l ∈ countSums v (fun i => u i - l i) := by
  constructor
  · rintro ⟨x, hx, hxt⟩
    refine ⟨fun i => x i - l i, ?_, ?_⟩
    · intro i
      have hi := hx i
      dsimp at hi ⊢
      constructor <;> omega
    · rw [weightedSum_sub, hxt]
  · rintro ⟨y, hy, hyt⟩
    refine ⟨fun i => l i + y i, ?_, ?_⟩
    · intro i
      have hi := hy i
      dsimp at hi ⊢
      constructor <;> omega
    · rw [weightedSum_add, hyt]
      abel

/-- Binary integer feasibility is exactly the copy-labelled subset-sum problem. -/
theorem binaryIP_iff_subsetSums (v : ι → G) (t : G) :
    BoundedIP v (fun _ => 0) (fun _ => 1) t ↔ t ∈ subsetSums v := by
  rw [boundedIP_iff_countSums]
  simpa using (mem_subsetSums_iff_binary v t).symm

/-- A restriction of the variable box can never create a solution. -/
theorem boundedIP_mono (v : ι → G) {l u l' u' : ι → ℤ} {t : G}
    (hl : ∀ i, l i ≤ l' i) (hu : ∀ i, u' i ≤ u i)
    (h : BoundedIP v l' u' t) : BoundedIP v l u t := by
  rcases h with ⟨x, hx, hxt⟩
  exact ⟨x, fun i => ⟨(hl i).trans (hx i).1, (hx i).2.trans (hu i)⟩, hxt⟩

/-- §11.2: an upper inequality has an integral, finitely bounded slack whenever
`m` is a known lower bound for its left side. -/
theorem le_iff_exists_bounded_slack (a b m : ℤ) (hma : m ≤ a) :
    a ≤ b ↔ ∃ s : ℤ, 0 ≤ s ∧ s ≤ b - m ∧ a + s = b := by
  constructor
  · intro hab
    exact ⟨b - a, by omega, by omega, by omega⟩
  · rintro ⟨s, hs, _, hab⟩
    omega

/-- §11.2: a two-sided inequality uses one slack variable and one equality. -/
theorem between_iff_exists_bounded_slack (a y b : ℤ) :
    (a ≤ y ∧ y ≤ b) ↔ ∃ s : ℤ, 0 ≤ s ∧ s ≤ b - a ∧ y + s = b := by
  constructor
  · rintro ⟨hay, hyb⟩
    exact ⟨b - y, by omega, by omega, by omega⟩
  · rintro ⟨s, hs, hsa, hyb⟩
    constructor <;> omega

/-- The lower bound used for a row over an integral variable box. -/
theorem weightedSum_ge_box_min (a l u x : ι → ℤ)
    (hx : ∀ i, l i ≤ x i ∧ x i ≤ u i) :
    (∑ i, min (a i * l i) (a i * u i)) ≤ weightedSum a x := by
  simp only [weightedSum, zsmul_eq_mul, Int.cast_id]
  apply Finset.sum_le_sum
  intro i _
  have hi := hx i
  by_cases ha : 0 ≤ a i
  · exact (min_le_left _ _).trans (by nlinarith)
  · exact (min_le_right _ _).trans (by nlinarith)

section Cardinalities

variable {κ : Type*} [DecidableEq ι]

/-- Append one zero-or-one coordinate for every prescribed index set.
The sets may overlap, and `ι` continues to distinguish equal original copies. -/
def cardinalityAugment (v : ι → G) (groups : κ → Finset ι) (i : ι) : G × (κ → ℤ) :=
  (v i, fun j => if i ∈ groups j then 1 else 0)

omit [Fintype ι] in
/-- The appended coordinates count membership in each group. -/
theorem sum_cardinalityAugment (v : ι → G) (groups : κ → Finset ι) (s : Finset ι) :
    (∑ i ∈ s, cardinalityAugment v groups i) =
      (∑ i ∈ s, v i, fun j => ((s ∩ groups j).card : ℤ)) := by
  classical
  apply Prod.ext
  · rw [Prod.fst_sum]
    rfl
  · rw [Prod.snd_sum]
    funext j
    simp [cardinalityAugment, Finset.filter_mem_eq_inter]

omit [Fintype ι] in
/-- §11.1: prescribed cardinalities are equivalent to an ordinary subset sum
with the indicator coordinates appended to each original vector. -/
theorem prescribed_cardinality_iff (v : ι → G) (groups : κ → Finset ι)
    (t : G) (k : κ → ℤ) :
    (∃ s : Finset ι, (∑ i ∈ s, v i) = t ∧
      ∀ j, ((s ∩ groups j).card : ℤ) = k j) ↔
    (t, k) ∈ subsetSums (cardinalityAugment v groups) := by
  constructor
  · rintro ⟨s, hst, hsk⟩
    refine ⟨s, ?_⟩
    rw [sum_cardinalityAugment, hst]
    congr 1
    exact funext hsk
  · rintro ⟨s, hs⟩
    rw [sum_cardinalityAugment] at hs
    refine ⟨s, congrArg Prod.fst hs, ?_⟩
    intro j
    exact congrFun (congrArg Prod.snd hs) j

end Cardinalities

end Optss
