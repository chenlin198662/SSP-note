import Optss.BinaryLongDivision

/-!
# Boolean ripple arithmetic on explicit bit lists

The computation in this module operates on list constructors and Boolean gates.
It uses no natural-number addition, subtraction or comparison to compute the
arithmetic answer. Natural arithmetic appears only in specifications and in
separate visit counters. Lists are little-endian and may have high zero bits.
-/

namespace Optss

/-- A one-bit full adder, expressed entirely by Boolean gates. -/
def bitFullAdd (a b c : Bool) : Bool × Bool :=
  (Bool.xor (Bool.xor a b) c, (a && b) || ((a || b) && c))

theorem bitFullAdd_value (a b c : Bool) :
    (bitFullAdd a b c).1.toNat + 2*(bitFullAdd a b c).2.toNat =
      a.toNat+b.toNat+c.toNat := by
  cases a <;> cases b <;> cases c <;> decide

/-- A one-bit full subtractor: result bit followed by borrow bit. -/
def bitFullSub (a b c : Bool) : Bool × Bool :=
  (Bool.xor (Bool.xor a b) c, ((!a) && b) || ((!(Bool.xor a b)) && c))

theorem bitFullSub_value (a b c : Bool) :
    a.toNat + 2*(bitFullSub a b c).2.toNat =
      b.toNat+c.toNat+(bitFullSub a b c).1.toNat := by
  cases a <;> cases b <;> cases c <;> decide

/-- Ripple-carry addition. The only conditional at the end emits the carry. -/
def bitListAddAux (c : Bool) : List Bool → List Bool → List Bool
  | [], [] => if c then [true] else []
  | a::as, [] =>
    let t := bitFullAdd a false c
    t.1 :: bitListAddAux t.2 as []
  | [], b::bs =>
    let t := bitFullAdd false b c
    t.1 :: bitListAddAux t.2 [] bs
  | a::as, b::bs =>
    let t := bitFullAdd a b c
    t.1 :: bitListAddAux t.2 as bs
termination_by xs ys => xs.length+ys.length

/-- Exact number of bit positions visited, including the final carry case. -/
def bitListAddVisits : List Bool → List Bool → ℕ
  | [], [] => 1
  | _::as, [] => bitListAddVisits as []+1
  | [], _::bs => bitListAddVisits [] bs+1
  | _::as, _::bs => bitListAddVisits as bs+1
termination_by xs ys => xs.length+ys.length

theorem bitListAddAux_correct (xs ys : List Bool) (c : Bool) :
    binaryDigitsValue (bitListAddAux c xs ys) =
      binaryDigitsValue xs+binaryDigitsValue ys+c.toNat := by
  induction xs generalizing ys c with
  | nil =>
    induction ys generalizing c with
    | nil => cases c <;> simp [bitListAddAux, binaryDigitsValue]
    | cons b bs ih =>
      simp only [bitListAddAux, binaryDigitsValue, ih]
      have ht := bitFullAdd_value false b c
      simp only [binaryDigitsValue, Bool.toNat_false] at *
      omega
  | cons a as ih =>
    cases ys with
    | nil =>
      simp only [bitListAddAux, binaryDigitsValue, ih]
      have ht := bitFullAdd_value a false c
      simp only [binaryDigitsValue, Bool.toNat_false] at *
      omega
    | cons b bs =>
      simp only [bitListAddAux, binaryDigitsValue, ih]
      have ht := bitFullAdd_value a b c
      simp only [binaryDigitsValue] at *
      omega

theorem bitListAddVisits_eq (xs ys : List Bool) :
    bitListAddVisits xs ys = max xs.length ys.length+1 := by
  induction xs generalizing ys with
  | nil =>
    induction ys with
    | nil => simp [bitListAddVisits]
    | cons b bs ih => simp [bitListAddVisits, ih]
  | cons a as ih =>
    cases ys with
    | nil => simp [bitListAddVisits, ih]
    | cons b bs => simp only [bitListAddVisits, ih, List.length_cons]; omega

theorem bitListAddAux_length (xs ys : List Bool) (c : Bool) :
    (bitListAddAux c xs ys).length ≤ max xs.length ys.length+1 := by
  induction xs generalizing ys c with
  | nil =>
    induction ys generalizing c with
    | nil => cases c <;> simp [bitListAddAux]
    | cons b bs ih => simpa [bitListAddAux] using Nat.add_le_add_right (ih _) 1
  | cons a as ih =>
    cases ys with
    | nil => simpa [bitListAddAux] using Nat.add_le_add_right (ih [] _) 1
    | cons b bs =>
      have h := ih bs (bitFullAdd a b c).2
      simp only [bitListAddAux, List.length_cons] at *
      omega

/-- Shift with a low bit is one list constructor. -/
def bitListShift (b : Bool) (xs : List Bool) : List Bool := b::xs

@[simp] theorem bitListShift_value (b : Bool) (xs : List Bool) :
    binaryDigitsValue (bitListShift b xs) = 2*binaryDigitsValue xs+b.toNat := rfl

/-- The subtraction output stores the exact fixed-width difference and the
final borrow. No integer comparison determines this borrow. -/
structure BitListSubResult where
  digits : List Bool
  borrow : Bool
  deriving Repr, DecidableEq

def bitListSubAux (c : Bool) : List Bool → List Bool → BitListSubResult
  | [], [] => ⟨[], c⟩
  | a::as, [] =>
    let t := bitFullSub a false c
    let out := bitListSubAux t.2 as []
    ⟨t.1::out.digits, out.borrow⟩
  | [], b::bs =>
    let t := bitFullSub false b c
    let out := bitListSubAux t.2 [] bs
    ⟨t.1::out.digits, out.borrow⟩
  | a::as, b::bs =>
    let t := bitFullSub a b c
    let out := bitListSubAux t.2 as bs
    ⟨t.1::out.digits, out.borrow⟩
termination_by xs ys => xs.length+ys.length

theorem bitListSubAux_length (xs ys : List Bool) (c : Bool) :
    (bitListSubAux c xs ys).digits.length = max xs.length ys.length := by
  induction xs generalizing ys c with
  | nil =>
    induction ys generalizing c with
    | nil => simp [bitListSubAux]
    | cons b bs ih => simp [bitListSubAux, ih]
  | cons a as ih =>
    cases ys with
    | nil => simp [bitListSubAux, ih]
    | cons b bs => simp only [bitListSubAux, List.length_cons, ih]; omega

/-- The fixed-width subtraction identity includes underflow and an incoming
borrow, and therefore covers every internal ripple state. -/
theorem bitListSubAux_correct (xs ys : List Bool) (c : Bool) :
    binaryDigitsValue xs + 2^(max xs.length ys.length)*(bitListSubAux c xs ys).borrow.toNat =
      binaryDigitsValue ys+c.toNat+binaryDigitsValue (bitListSubAux c xs ys).digits := by
  induction xs generalizing ys c with
  | nil =>
    induction ys generalizing c with
    | nil => simp [binaryDigitsValue, bitListSubAux]
    | cons b bs ih =>
      have ht := bitFullSub_value false b c
      have hh := ih (bitFullSub false b c).2
      simp only [bitListSubAux, binaryDigitsValue, List.length_cons, List.length_nil, Nat.zero_max, pow_succ,
        Bool.toNat_false] at *
      nlinarith
  | cons a as ih =>
    cases ys with
    | nil =>
      have ht := bitFullSub_value a false c
      have hh := ih [] (bitFullSub a false c).2
      simp only [bitListSubAux, binaryDigitsValue, List.length_cons, List.length_nil, Nat.max_zero, pow_succ,
        Bool.toNat_false] at *
      nlinarith
    | cons b bs =>
      have ht := bitFullSub_value a b c
      have hh := ih bs (bitFullSub a b c).2
      have hm : max (as.length+1) (bs.length+1) = max as.length bs.length+1 := by omega
      simp only [bitListSubAux, binaryDigitsValue, List.length_cons, hm, pow_succ] at *
      nlinarith

/-- Borrow is precisely the natural comparison, including noncanonical high zeros. -/
theorem bitListSub_borrow_iff (xs ys : List Bool) :
    (bitListSubAux false xs ys).borrow = true ↔ binaryDigitsValue xs < binaryDigitsValue ys := by
  have he := bitListSubAux_correct xs ys false
  have hlt := binaryDigitsValue_lt_pow (bitListSubAux false xs ys).digits
  rw [bitListSubAux_length] at hlt
  constructor
  · intro hb
    rw [hb] at he
    simp only [Bool.toNat_false, Bool.toNat_true, mul_one, add_zero] at he
    omega
  · intro hlt'
    by_contra hb
    have hf : (bitListSubAux false xs ys).borrow = false := Bool.eq_false_iff.mpr hb
    rw [hf] at he
    simp only [Bool.toNat_false, mul_zero, add_zero] at he
    omega

/-- Comparison uses the Boolean ripple borrow, not natural comparison. -/
def bitListLE (xs ys : List Bool) : Bool := !(bitListSubAux false ys xs).borrow

theorem bitListLE_correct (xs ys : List Bool) :
    bitListLE xs ys = true ↔ binaryDigitsValue xs ≤ binaryDigitsValue ys := by
  have h := bitListSub_borrow_iff ys xs
  unfold bitListLE
  cases hb : (bitListSubAux false ys xs).borrow <;> simp_all

/-- Saturating subtraction selects zero exactly on underflow. -/
def bitListSub (xs ys : List Bool) : List Bool :=
  let out := bitListSubAux false xs ys
  if out.borrow then [] else out.digits

theorem bitListSub_correct (xs ys : List Bool) :
    binaryDigitsValue (bitListSub xs ys) = binaryDigitsValue xs-binaryDigitsValue ys := by
  have he := bitListSubAux_correct xs ys false
  unfold bitListSub
  dsimp only
  split_ifs with hb
  · have hlt := (bitListSub_borrow_iff xs ys).mp hb
    simp only [binaryDigitsValue]
    omega
  · have hf : (bitListSubAux false xs ys).borrow = false := Bool.eq_false_iff.mpr hb
    simp only [hf, Bool.toNat_false, mul_zero, add_zero] at he
    omega

/-- Drop only high zero bits, by a single traversal of the explicit list. -/
def bitListTrim : List Bool → List Bool
  | [] => []
  | b::bs =>
    let ts := bitListTrim bs
    if b then b::ts else if ts.isEmpty then [] else b::ts

theorem bitListTrim_value (bs : List Bool) :
    binaryDigitsValue (bitListTrim bs) = binaryDigitsValue bs := by
  induction bs with
  | nil => rfl
  | cons b bs ih =>
    cases b <;> cases ht : bitListTrim bs <;>
      simp [bitListTrim, ht, binaryDigitsValue] at * <;> omega

theorem bitListTrim_length_le (bs : List Bool) : (bitListTrim bs).length ≤ bs.length := by
  induction bs with
  | nil => rfl
  | cons b bs ih =>
    cases b <;> cases ht : bitListTrim bs <;> simp [bitListTrim, ht] at * <;> omega

/-- Trimming agrees with canonical binary digits, while computing directly on
the bit list rather than converting through a natural number. -/
theorem bitListTrim_eq_bits (bs : List Bool) :
    bitListTrim bs = (binaryDigitsValue bs).bits := by
  induction bs with
  | nil => simp [bitListTrim, binaryDigitsValue]
  | cons b bs ih =>
    by_cases hn : binaryDigitsValue bs = 0
    · have ht : bitListTrim bs = [] := by simpa [hn] using ih
      cases b <;> simp [bitListTrim, ht, binaryDigitsValue, hn]
    · have he := Nat.bits_append_bit (binaryDigitsValue bs) b (by simp [hn])
      rw [Nat.bit_val] at he
      rw [binaryDigitsValue, he, ← ih]
      cases b <;> cases ht : bitListTrim bs <;> simp [bitListTrim, ht]
      have hv := bitListTrim_value bs
      rw [ht] at hv
      exact False.elim (hn (by simpa [binaryDigitsValue] using hv.symm))

/-- Canonical list length equals the true magnitude bit length. -/
theorem bitListTrim_length (bs : List Bool) :
    (bitListTrim bs).length = (binaryDigitsValue bs).size := by
  rw [bitListTrim_eq_bits, Nat.size_eq_bits_len]

/-- Exact recurrence for visits of either ripple circuit, including the base
case. Both circuits have the same data-independent traversal shape. -/
def bitListSubVisits : List Bool → List Bool → ℕ := bitListAddVisits

theorem bitListSubVisits_eq (xs ys : List Bool) :
    bitListSubVisits xs ys = max xs.length ys.length+1 := bitListAddVisits_eq xs ys

/-- Trimming visits each list cell once and then the empty tail. -/
def bitListTrimVisits : List Bool → ℕ
  | [] => 1
  | _::bs => bitListTrimVisits bs+1

theorem bitListTrimVisits_eq (bs : List Bool) : bitListTrimVisits bs = bs.length+1 := by
  induction bs with
  | nil => rfl
  | cons b bs ih => simp [bitListTrimVisits, ih]

/-- Explicit Boolean circuit syntax used to count actual gate nodes. -/
inductive BitCircuit where
  | input : Fin 3 → BitCircuit
  | inv : BitCircuit → BitCircuit
  | band : BitCircuit → BitCircuit → BitCircuit
  | bor : BitCircuit → BitCircuit → BitCircuit
  | bxor : BitCircuit → BitCircuit → BitCircuit
  deriving Repr, DecidableEq

def BitCircuit.eval (env : Fin 3 → Bool) : BitCircuit → Bool
  | .input i => env i
  | .inv t => !(t.eval env)
  | .band t u => (t.eval env) && (u.eval env)
  | .bor t u => (t.eval env) || (u.eval env)
  | .bxor t u => Bool.xor (t.eval env) (u.eval env)

def BitCircuit.gates : BitCircuit → ℕ
  | .input _ => 0
  | .inv t => t.gates+1
  | .band t u | .bor t u | .bxor t u => t.gates+u.gates+1

def fullAddCircuits : BitCircuit × BitCircuit :=
  (.bxor (.bxor (.input 0) (.input 1)) (.input 2),
    .bor (.band (.input 0) (.input 1)) (.band (.bor (.input 0) (.input 1)) (.input 2)))

def fullSubCircuits : BitCircuit × BitCircuit :=
  (.bxor (.bxor (.input 0) (.input 1)) (.input 2),
    .bor (.band (.inv (.input 0)) (.input 1))
      (.band (.inv (.bxor (.input 0) (.input 1))) (.input 2)))

theorem fullAddCircuits_correct (env : Fin 3 → Bool) :
    (fullAddCircuits.1.eval env, fullAddCircuits.2.eval env) =
      bitFullAdd (env 0) (env 1) (env 2) := rfl

theorem fullSubCircuits_correct (env : Fin 3 → Bool) :
    (fullSubCircuits.1.eval env, fullSubCircuits.2.eval env) =
      bitFullSub (env 0) (env 1) (env 2) := rfl

theorem fullAddCircuits_gates : fullAddCircuits.1.gates+fullAddCircuits.2.gates = 6 := rfl

theorem fullSubCircuits_gates : fullSubCircuits.1.gates+fullSubCircuits.2.gates = 8 := rfl

/-- Gate-node recurrence for the actual ripple traversal. The base does not
call a full-bit circuit. Structural/list-control steps are counted separately. -/
def bitListRippleGates (g : ℕ) : List Bool → List Bool → ℕ
  | [], [] => 0
  | _::as, [] => g+bitListRippleGates g as []
  | [], _::bs => g+bitListRippleGates g [] bs
  | _::as, _::bs => g+bitListRippleGates g as bs
termination_by xs ys => xs.length+ys.length

theorem bitListRippleGates_eq (g : ℕ) (xs ys : List Bool) :
    bitListRippleGates g xs ys = g*max xs.length ys.length := by
  induction xs generalizing ys with
  | nil =>
    induction ys with
    | nil => simp [bitListRippleGates]
    | cons b bs ih => simp [bitListRippleGates, ih]; ring
  | cons a as ih =>
    cases ys with
    | nil => simp [bitListRippleGates, ih]; ring
    | cons b bs =>
      have hm : max (as.length+1) (bs.length+1) = max as.length bs.length+1 := by omega
      simp only [bitListRippleGates, ih, List.length_cons, hm]
      ring

/-- Exact Boolean gate totals for addition and borrow-based subtraction.
The comparison adds one final Boolean negation to the subtractor count. -/
theorem bitListCircuit_gate_counts (xs ys : List Bool) :
    bitListRippleGates (fullAddCircuits.1.gates+fullAddCircuits.2.gates) xs ys =
        6*max xs.length ys.length ∧
      bitListRippleGates (fullSubCircuits.1.gates+fullSubCircuits.2.gates) xs ys+1 =
        8*max xs.length ys.length+1 := by
  simp only [fullAddCircuits_gates, fullSubCircuits_gates, bitListRippleGates_eq, and_self]

/-- Canonical addition using only ripple gates and high-zero trimming. -/
def bitListAdd (xs ys : List Bool) : List Bool := bitListTrim (bitListAddAux false xs ys)

theorem bitListAdd_correct (xs ys : List Bool) :
    binaryDigitsValue (bitListAdd xs ys) = binaryDigitsValue xs+binaryDigitsValue ys := by
  simp only [bitListAdd, bitListTrim_value, bitListAddAux_correct, Bool.toNat_false, add_zero]

theorem bitListAdd_length (xs ys : List Bool) :
    (bitListAdd xs ys).length = (binaryDigitsValue xs+binaryDigitsValue ys).size := by
  simp only [bitListAdd, bitListTrim_length, bitListAddAux_correct, Bool.toNat_false, add_zero]

theorem bitListSub_length_le (xs ys : List Bool) :
    (bitListSub xs ys).length ≤ max xs.length ys.length := by
  unfold bitListSub
  dsimp only
  split_ifs <;> simp [bitListSubAux_length]

/-- The two complete traversals in canonical addition visit at most twice the
maximum input width plus three cells, including their terminal empty tails. -/
theorem bitListAdd_total_visits (xs ys : List Bool) :
    bitListAddVisits xs ys+bitListTrimVisits (bitListAddAux false xs ys) ≤
      2*max xs.length ys.length+3 := by
  rw [bitListAddVisits_eq, bitListTrimVisits_eq]
  have h := bitListAddAux_length xs ys false
  omega

/-- Subtraction followed by canonical trimming has the same linear traversal
bound, even when saturation returns the empty list. -/
theorem bitListSub_total_visits (xs ys : List Bool) :
    bitListSubVisits xs ys+bitListTrimVisits (bitListSub xs ys) ≤
      2*max xs.length ys.length+2 := by
  rw [bitListSubVisits_eq, bitListTrimVisits_eq]
  have h := bitListSub_length_le xs ys
  omega

end Optss
