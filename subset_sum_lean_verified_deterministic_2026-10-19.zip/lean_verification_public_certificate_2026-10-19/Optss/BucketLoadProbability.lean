import Optss.ColorProbability
import Mathlib.Data.Complex.ExponentialBounds
import Mathlib.Algebra.BigOperators.Ring.Finset

/-!
# Exponentially small bucket-load failure in Appendix A.2

The sample space consists of all assignments of the original labels to bins.
The exponential moment is computed by finite product counting. A proved
Markov inequality and `1+x ≤ exp x` give the load tail, followed by a finite
union bound. No concentration bound or independence hypothesis is assumed.
-/
namespace Optss
open scoped BigOperators
noncomputable section
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Number of fixed witness labels sent to one bucket. -/
def bucketLoad {b : ℕ} (S : Finset ι) (f : ι → Fin b) (p : Fin b) : ℕ :=
  (S.filter (fun i => f i = p)).card

/-- The actual bad event: a witness load exceeds the paper's `8L` bound. -/
def bucketOverloadEvent (S : Finset ι) (b L : ℕ) (p : Fin b) : Finset (ι → Fin b) :=
  Finset.univ.filter (fun f => 8 * L < bucketLoad S f p)

@[simp] theorem mem_bucketOverloadEvent (S : Finset ι) (b L : ℕ)
    (p : Fin b) (f : ι → Fin b) :
    f ∈ bucketOverloadEvent S b L p ↔ 8 * L < bucketLoad S f p := by
  simp [bucketOverloadEvent]

/-- Finite-space Markov bound, proved directly by summing nonnegative weights. -/
theorem uniformProbability_le_mean_div {Ω : Type*} [Fintype Ω] [DecidableEq Ω]
    (A : Finset Ω) (w : Ω → ℝ) (hw : ∀ x, 0 ≤ w x) (a : ℝ) (ha : 0 < a)
    (hA : ∀ x ∈ A, a ≤ w x) :
    uniformProbability A ≤ ((∑ x, w x) / Fintype.card Ω) / a := by
  have hsum : (A.card : ℝ) * a ≤ ∑ x, w x := by
    calc
      _ = ∑ _x ∈ A, a := by simp
      _ ≤ ∑ x ∈ A, w x := Finset.sum_le_sum hA
      _ ≤ ∑ x, w x := Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ A)
        (fun x _ _ => hw x)
  apply (le_div_iff₀ ha).mpr
  unfold uniformProbability
  rw [div_mul_eq_mul_div]
  exact div_le_div_of_nonneg_right hsum (by positivity)

/-- `2^load` factors as one weight per original label, with weight two only
for witness labels assigned to the specified bucket. -/
theorem two_pow_bucketLoad {b : ℕ} (S : Finset ι) (f : ι → Fin b) (p : Fin b) :
    (2 : ℝ) ^ bucketLoad S f p = ∏ i, if i ∈ S ∧ f i = p then (2 : ℝ) else 1 := by
  have hf : (Finset.univ.filter (fun i => i ∈ S ∧ f i = p)) =
      S.filter (fun i => f i = p) := by ext i; simp
  rw [← Finset.prod_filter]
  simp only [hf, Finset.prod_const, bucketLoad]

/-- Exact exponential moment under uniform independent hashing. This also
shows that unused original labels do not affect the witness load law. -/
theorem mean_two_pow_bucketLoad (S : Finset ι) (b : ℕ) (hb : 0 < b) (p : Fin b) :
    (∑ f : ι → Fin b, (2 : ℝ) ^ bucketLoad S f p) /
        Fintype.card (ι → Fin b) = (1 + 1 / (b : ℝ)) ^ S.card := by
  have hb0 : (b : ℝ) ≠ 0 := by exact_mod_cast Nat.ne_of_gt hb
  simp_rw [two_pow_bucketLoad]
  rw [← Fintype.prod_sum (fun (i : ι) (c : Fin b) => if i ∈ S ∧ c = p then (2 : ℝ) else 1)]
  have hcoord (i : ι) :
      (∑ c : Fin b, if i ∈ S ∧ c = p then (2 : ℝ) else 1) =
        if i ∈ S then (b : ℝ) + 1 else b := by
    have heq (c : Fin b) : (if i ∈ S ∧ c = p then (2 : ℝ) else 1) =
        1 + if i ∈ S ∧ c = p then (1 : ℝ) else 0 := by split_ifs <;> norm_num
    simp_rw [heq]
    rw [Finset.sum_add_distrib]
    by_cases hi : i ∈ S <;> simp [hi]
  simp_rw [hcoord]
  have hden : (Fintype.card (ι → Fin b) : ℝ) = ∏ _i : ι, (b : ℝ) := by
    simp [Fintype.card_fun]
  rw [hden, ← Finset.prod_div_distrib]
  have hquot (i : ι) : (if i ∈ S then (b : ℝ) + 1 else b) / b =
      if i ∈ S then 1 + 1 / (b : ℝ) else 1 := by
    by_cases hi : i ∈ S <;> simp [hi, add_div, hb0]
  simp_rw [hquot]
  rw [← Finset.prod_filter]
  simp

/-- The computed moment is at most `4^L` when the expected bucket load is
at most `L`. This bound follows from the exponential function's proved bounds. -/
theorem bucket_moment_le_four_pow (m b L : ℕ) (hb : 0 < b) (hm : m ≤ b * L) :
    (1 + 1 / (b : ℝ)) ^ m ≤ (4 : ℝ) ^ L := by
  have hbR : (0 : ℝ) < b := by exact_mod_cast hb
  have hmR : (m : ℝ) ≤ (b : ℝ) * L := by exact_mod_cast hm
  have hmean : (m : ℝ) * (1 / b) ≤ L := by
    rw [mul_one_div]
    exact (div_le_iff₀ hbR).mpr (by nlinarith)
  calc
    (1 + 1 / (b : ℝ)) ^ m ≤ Real.exp (1 / (b : ℝ)) ^ m :=
      pow_le_pow_left₀ (by positivity) (by simpa [add_comm] using Real.add_one_le_exp (1 / (b : ℝ))) m
    _ = Real.exp ((m : ℝ) * (1 / (b : ℝ))) := (Real.exp_nat_mul _ _).symm
    _ ≤ Real.exp (L : ℝ) := Real.exp_le_exp.mpr hmean
    _ = Real.exp 1 ^ L := by simp [← Real.exp_nat_mul]
    _ ≤ (4 : ℝ) ^ L := pow_le_pow_left₀ (Real.exp_pos _).le
      (Real.exp_one_lt_d9.le.trans (by norm_num)) L

/-- One bucket exceeds `8L` fixed witness labels with probability at most
`2^(-4L)`. The proof in fact obtains the stronger intermediate `64^(-L)`. -/
theorem uniform_bucket_overload_bound (S : Finset ι) (b L : ℕ)
    (hb : 0 < b) (hS : S.card ≤ b * L) (p : Fin b) :
    uniformProbability (bucketOverloadEvent S b L p) ≤ (1 / 2 : ℝ) ^ (4 * L) := by
  have hmarkov := uniformProbability_le_mean_div (bucketOverloadEvent S b L p)
    (fun f => (2 : ℝ) ^ bucketLoad S f p) (fun _ => by positivity)
    ((2 : ℝ) ^ (8 * L)) (by positivity) (by
      intro f hf
      exact pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2)
        (le_of_lt ((mem_bucketOverloadEvent S b L p f).mp hf)))
  rw [mean_two_pow_bucketLoad S b hb p] at hmarkov
  calc
    uniformProbability (bucketOverloadEvent S b L p) ≤
        (1 + 1 / (b : ℝ)) ^ S.card / (2 : ℝ) ^ (8 * L) := hmarkov
    _ ≤ (4 : ℝ) ^ L / (2 : ℝ) ^ (8 * L) :=
      div_le_div_of_nonneg_right (bucket_moment_le_four_pow S.card b L hb hS) (by positivity)
    _ = (1 / 64 : ℝ) ^ L := by rw [pow_mul, ← div_pow]; norm_num
    _ ≤ (1 / 16 : ℝ) ^ L := pow_le_pow_left₀ (by norm_num) (by norm_num) L
    _ = (1 / 2 : ℝ) ^ (4 * L) := by rw [pow_mul]; norm_num

/-- The probability that any bucket violates the permitted witness load is
at most `b * 2^(-4L)`, under the actual uniform hash of all original labels. -/
theorem uniform_any_bucket_overload_bound (S : Finset ι) (b L : ℕ)
    (hb : 0 < b) (hS : S.card ≤ b * L) :
    uniformProbability (Finset.univ.biUnion (bucketOverloadEvent S b L)) ≤
      (b : ℝ) * (1 / 2 : ℝ) ^ (4 * L) := by
  calc
    _ ≤ ∑ p : Fin b, uniformProbability (bucketOverloadEvent S b L p) :=
      uniformProbability_biUnion_le _ _
    _ ≤ ∑ _p : Fin b, (1 / 2 : ℝ) ^ (4 * L) :=
      Finset.sum_le_sum (fun p _ => uniform_bucket_overload_bound S b L hb hS p)
    _ = _ := by simp

/-- Semantic form of the union event, used when conditioning the second
coloring stage on a hash with all witness loads under control. -/
theorem not_mem_any_bucket_overload_iff (S : Finset ι) (b L : ℕ) (f : ι → Fin b) :
    f ∉ Finset.univ.biUnion (bucketOverloadEvent S b L) ↔
      ∀ p, bucketLoad S f p ≤ 8 * L := by
  simp only [Finset.mem_biUnion, Finset.mem_univ, mem_bucketOverloadEvent, true_and,
    not_exists, not_lt]

/-- The natural arithmetic form of `b = max(1,ceil(k/L))` has capacity
at least `k`, including `k=0`. Thus its expected load is at most `L`. -/
theorem rounded_bucket_count_capacity (k L : ℕ) (hL : 0 < L) :
    k ≤ max 1 ((k + L - 1) / L) * L := by
  have hmod := Nat.mod_lt (k + L - 1) hL
  have hdecomp := Nat.mod_add_div (k + L - 1) L
  have hround : k ≤ ((k + L - 1) / L) * L := by
    have hsub : k + L - 1 + 1 = k + L := by omega
    nlinarith [hsub]
  exact hround.trans (Nat.mul_le_mul_right L (le_max_right _ _))

/-- Hashing to the rounded bucket count used by the construction satisfies
the exponential load bound for every witness of size at most `k`. -/
theorem uniform_rounded_bucket_overload_bound (S : Finset ι) (k L : ℕ)
    (hL : 0 < L) (hS : S.card ≤ k) :
    uniformProbability
      (Finset.univ.biUnion (bucketOverloadEvent S (max 1 ((k + L - 1) / L)) L)) ≤
      ((max 1 ((k + L - 1) / L) : ℕ) : ℝ) * (1 / 2 : ℝ) ^ (4 * L) := by
  apply uniform_any_bucket_overload_bound S _ L (by omega)
  exact hS.trans (rounded_bucket_count_capacity k L hL)

/-- An explicit numerical condition allocates at most half the requested
failure budget to the first hashing stage. -/
theorem uniform_bucket_load_half_budget (S : Finset ι) (b L : ℕ)
    (hb : 0 < b) (hS : S.card ≤ b * L) (ζ : ℝ)
    (hbudget : 2 * (b : ℝ) ≤ ζ * 2 ^ (4 * L)) :
    uniformProbability (Finset.univ.biUnion (bucketOverloadEvent S b L)) ≤ ζ / 2 := by
  apply (uniform_any_bucket_overload_bound S b L hb hS).trans
  rw [div_pow, one_pow, mul_one_div]
  apply (div_le_iff₀ (by positivity : (0 : ℝ) < 2 ^ (4 * L))).mpr
  nlinarith

/-- A logarithmic load parameter meets that explicit budget condition. This
separates the checked probability estimate from any later choice of constants. -/
theorem uniform_bucket_load_half_budget_of_log (S : Finset ι) (b L : ℕ)
    (hb : 0 < b) (hS : S.card ≤ b * L) (ζ : ℝ) (hζ : 0 < ζ)
    (hL : ⌈Real.logb 2 (2 * (b : ℝ) / ζ)⌉₊ ≤ 4 * L) :
    uniformProbability (Finset.univ.biUnion (bucketOverloadEvent S b L)) ≤ ζ / 2 := by
  apply uniform_bucket_load_half_budget S b L hb hS ζ
  have hstart := ceil_log_repetitions_sufficient b hb ζ hζ
  have hpow : (2 : ℝ) ^ ⌈Real.logb 2 (2 * (b : ℝ) / ζ)⌉₊ ≤ 2 ^ (4 * L) :=
    pow_le_pow_right₀ (by norm_num) hL
  exact hstart.trans (mul_le_mul_of_nonneg_left hpow hζ.le)

end
end Optss
