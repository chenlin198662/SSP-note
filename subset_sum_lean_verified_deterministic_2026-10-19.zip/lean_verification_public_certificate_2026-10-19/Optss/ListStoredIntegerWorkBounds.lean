import Optss.ListStoredAccessBounds
import Optss.ListStoredPayloadBounds

/-! Storage bounds for integer conversion, row updates, and pair selection. -/
namespace Optss
open scoped BigOperators
variable {r d : ℕ}

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

theorem listStorageFactor_ge_dim (r d : ℕ) : r+d+1 ≤ listStorageFactor r d := by
  have h : (r+d+1)^1 ≤ (r+d+1)^4 := Nat.pow_le_pow_right (by omega) (by decide)
  simp only [pow_one] at h
  unfold listStorageFactor
  omega

theorem listStorageFactor_ge_2048 (r d : ℕ) : 2048 ≤ listStorageFactor r d := by
  have h : 1 ≤ (r+d+1)^4 := one_le_pow₀ (by omega)
  unfold listStorageFactor
  omega

theorem listStoredRationalIntegerRowsStorageWork_le (D : ListBitIntegerMatrixData r d)
    (B : ℕ) (hB : ∀ i j,integerPayload (((listMatrixVector D).get i).get j) ≤ B) :
    listStoredRationalIntegerRowsStorageWork D ≤
      (4*r*d+r+1)*listStorageFactor r d*(B+1) := by
  let U := listStorageFactor r d
  have hU : 2048≤U := listStorageFactor_ge_2048 r d
  have her := listEnumerationWork_factor (r:=r) (d:=d) r (by omega)
  have hed := listEnumerationWork_factor (r:=r) (d:=d) d (by omega)
  have hs : (∑ i : Fin r,∑ j : Fin d,
      (listMatrixReadWork listCopyInteger listCopyIntegerWork D i j+3)) ≤
      r*d*(U*(B+1)+3) := by
    calc
      _ ≤ ∑ _i : Fin r, ∑ _j : Fin d,(U*(B+1)+3) := by
        apply Finset.sum_le_sum
        intro i _
        apply Finset.sum_le_sum
        intro j _
        exact Nat.add_le_add_right (listIntegerReadWork_le D i j B hB) 3
      _ = _ := by simp; ring
  unfold listStoredRationalIntegerRowsStorageWork
  change _ ≤ (4*r*d+r+1)*U*(B+1)
  change listIndexEnumerationWork r ≤ U at her
  change listIndexEnumerationWork d ≤ U at hed
  have hUV : U ≤ U*(B+1) := Nat.le_mul_of_pos_right _ (by omega)
  have hV : 1 ≤ U*(B+1) := by omega
  calc
    _ ≤ U+r*U+r*d*(U*(B+1)+3) :=
      Nat.add_le_add (Nat.add_le_add her (Nat.mul_le_mul_left r hed)) hs
    _ ≤ U*(B+1)+r*(U*(B+1))+r*d*(4*(U*(B+1))) := by
      gcongr
      omega
    _ = _ := by ring

theorem listStoredRationalIntegerRows_payload (D : ListBitIntegerMatrixData r d)
    (B : ℕ) (hB : ∀ i j,integerPayload (((listMatrixVector D).get i).get j) ≤ B) (i : Fin r) (j : Fin d) :
    fractionPayload (((listMatrixVector (listStoredRationalIntegerRows D)).get i).get j) ≤ B+1 := by
  rw [listStoredRationalIntegerRows_eq]
  simpa only [fractionPayload,encodedRationalIntegerRows,get_ofFn,List.length_cons,List.length_nil,
    integerPayload,Nat.zero_add] using Nat.add_le_add_right (hB i j) 1

theorem listStoredIntegerRowUpdateStorageWork_le (D : ListBitIntegerMatrixData r d) (k j : Fin r)
    (c : BitListInteger) (B C : ℕ)
    (hB : ∀ i l,integerPayload (((listMatrixVector D).get i).get l) ≤ B) (hc : integerPayload c ≤ C) :
    listStoredIntegerRowUpdateStorageWork D k j c ≤
      (4*d+4)*listStorageFactor r d*
        (B+C+encodedIntegerRowUpdateWork (listMatrixVector D) k j c+1) := by
  let W := encodedIntegerRowUpdateWork (listMatrixVector D) k j c
  let U := listStorageFactor r d
  let R := B+C+W
  have hU : 2048≤U := listStorageFactor_ge_2048 r d
  have hBR : B≤R := by dsimp [R]; omega
  have hCR : C≤R := by dsimp [R]; omega
  have hWR : W≤R := by dsimp [R]; omega
  have hd := listEnumerationWork_factor (r:=r) (d:=d) d (by omega)
  have hread (i : Fin r) (l : Fin d) :
      listMatrixReadWork listCopyInteger listCopyIntegerWork D i l ≤ U*(R+1) :=
    listIntegerReadWork_le D i l R (fun a b => (hB a b).trans hBR)
  have hcopy : listCopyIntegerWork c ≤ 2*(R+1) := by
    rw [listCopyIntegerWork_eq]
    nlinarith
  let row := BooleanListArray.ofFn fun l => bitListIntegerRowCell
    (listMatrixRead listCopyInteger D k l) (listCopyInteger c) (listMatrixRead listCopyInteger D j l)
  have hr (l : Fin d) : integerPayload (row.toVector.get l) ≤ R := by
    simp only [row,BooleanListArray.ofFn_toVector,get_ofFn,listCopyInteger_eq,
      listMatrixRead_eq _ listCopyInteger_eq,integerPayload]
    have hv := bitListIntegerRowCell_output_le_cost (((listMatrixVector D).get k).get l) c
      (((listMatrixVector D).get j).get l)
    have hs : bitListIntegerRowCellCost (((listMatrixVector D).get k).get l) c
        (((listMatrixVector D).get j).get l) ≤ W :=
      Finset.single_le_sum (f:=fun l : Fin d => bitListIntegerRowCellCost
        (((listMatrixVector D).get k).get l) c (((listMatrixVector D).get j).get l))
        (fun _ _ => Nat.zero_le _) (Finset.mem_univ l)
    exact hv.trans (hs.trans hWR)
  have hwrite := listIntegerWriteWork_le D k row R (fun a b => (hB a b).trans hBR) hr
  have hs : (∑ l : Fin d,(listMatrixReadWork listCopyInteger listCopyIntegerWork D k l+
      listCopyIntegerWork c+listMatrixReadWork listCopyInteger listCopyIntegerWork D j l+2)) ≤
      d*(2*U*(R+1)+2*(R+1)+2) := by
    calc
      _ ≤ ∑ _l : Fin d,(2*U*(R+1)+2*(R+1)+2) := by
        apply Finset.sum_le_sum
        intro l _
        have hk := hread k l
        have hj := hread j l
        nlinarith
      _ = _ := by simp
  change listIndexEnumerationWork d+_+listMatrixWriteWork listCopyIntegerWork D k row+1 ≤ _
  change _ ≤ (4*d+4)*U*(R+1)
  change listMatrixWriteWork listCopyIntegerWork D k row ≤ U*(R+1) at hwrite
  change listIndexEnumerationWork d≤U at hd
  have hUV : U ≤ U*(R+1) := Nat.le_mul_of_pos_right _ (by omega)
  have hV : 1 ≤ U*(R+1) := by omega
  have hVR : 2*(R+1) ≤ U*(R+1) := Nat.mul_le_mul_right (R+1) (by omega)
  have hsub : 2*U*(R+1)+2*(R+1)+2 ≤ 4*(U*(R+1)) := by nlinarith
  calc
    _ ≤ U+d*(2*U*(R+1)+2*(R+1)+2)+U*(R+1)+1 :=
      Nat.add_le_add_right (Nat.add_le_add (Nat.add_le_add hd hs) hwrite) 1
    _ ≤ U*(R+1)+d*(4*(U*(R+1)))+U*(R+1)+U*(R+1) := by gcongr
    _ ≤ (4*d+4)*U*(R+1) := by nlinarith

theorem bitLeastPairWork_le (ps : List (Fin r × Fin r)) :
    bitLeastPairWork ps ≤ (ps.length+1)*8*listStorageFactor r d := by
  let U := listStorageFactor r d
  have hU : 2048≤U := listStorageFactor_ge_2048 r d
  have hd : r+d+1≤U := listStorageFactor_ge_dim r d
  induction ps with
  | nil => simp only [bitLeastPairWork,List.length_nil]; change 1≤8*U; omega
  | cons p ps ih =>
    rw [bitLeastPairWork]
    cases he : bitLeastPair ps with
    | none => simp only [List.length_cons]; change _ ≤ (ps.length+1+1)*8*U; nlinarith
    | some q =>
      have h₁ := (bitIndex_controls_factor (d:=d) p.1 q.1).2.2.1
      have h₂ := (bitIndex_controls_factor (d:=d) p.1 q.1).2.1
      have h₃ := (bitIndex_controls_factor (d:=d) p.2 q.2).1
      change bitIndexLTWork p.1 q.1≤U at h₁
      change bitIndexEQWork p.1 q.1≤U at h₂
      change bitIndexLEWork p.2 q.2≤U at h₃
      simp only [bitPairLEWork,List.length_cons]
      change _ ≤ (ps.length+1+1)*8*U
      nlinarith

end Optss
