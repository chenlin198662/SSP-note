import Optss.BooleanCharacterWork
import Optss.ListRadixTwoWork

/-! Stored negative-frequency character rows. Counters advance by Boolean
ripple addition, and modular reduction/character evaluation use only the
previously verified Boolean answer routines. -/
namespace Optss

/-- The difference may represent N when the remainder is zero; the character
constructor's verified modular reduction then selects the zero class. -/
def bitNegativeCharacter (as ms : List Bool) (p : ℕ) : BitFourierInteger :=
  let r := (bitListDivision as ms).remainder
  bitModularDyadicCharacter (bitListSub ms r) ms p

def bitNegativeCharacterWork (as ms : List Bool) (p : ℕ) : ℕ :=
  let r := (bitListDivision as ms).remainder
  bitListDivisionBitWork as ms+bitListRippleGates 8 ms r+bitListSubVisits ms r+1+
    bitModularDyadicCharacterWork (bitListSub ms r) ms p

theorem bitNegativeCharacter_value {N : ℕ} [NeZero N] (as ms : List Bool)
    (hM : binaryDigitsValue ms=N) (p : ℕ) :
    (bitNegativeCharacter as ms p).value=dyadicCharacterInteger (-(binaryDigitsValue as : ZMod N)) p := by
  have hpos : 0<binaryDigitsValue ms := by rw [hM]; exact NeZero.pos N
  rw [bitNegativeCharacter,bitModularDyadicCharacter_value _ _ hM,bitListSub_correct,
    (bitListDivision_correct as ms hpos).2,hM]
  rw [Nat.cast_sub (Nat.mod_lt _ (NeZero.pos N)).le,ZMod.natCast_self,ZMod.natCast_mod,zero_sub]

theorem bitNegativeCharacter_canonical (as ms : List Bool) (p : ℕ) :
    (bitNegativeCharacter as ms p).Canonical := bitDyadicCharacter_canonical _ _ _

theorem bitNegativeCharacterWork_bound {N : ℕ} [NeZero N] (as ms : List Bool)
    (hM : binaryDigitsValue ms=N) (p : ℕ) :
    bitNegativeCharacterWork as ms p≤64*(as.length+ms.length+2)^2+
      4194304*(N.size+p+72)^2*(characterWorkBits N (p+2)+1)^3 := by
  have hpos : 0<binaryDigitsValue ms := by rw [hM]; exact NeZero.pos N
  have hrem := bitListDivisionDigits_remainder_width as ms hpos
  change (bitListDivision as ms).remainder.length ≤ ms.length at hrem
  have hsub := bitListSub_length_le ms (bitListDivision as ms).remainder
  have hm : max ms.length (bitListDivision as ms).remainder.length=ms.length := max_eq_left hrem
  rw [hm] at hsub
  have hchar := bitModularDyadicCharacterWork_bound (bitListSub ms (bitListDivision as ms).remainder) ms hM p
  have hdiv := bitListDivisionBitWork_bound as ms hpos
  have hmul := Nat.mul_le_mul_right (ms.length+1) (Nat.add_le_add_right hsub 1)
  unfold bitNegativeCharacterWork
  dsimp only
  rw [bitListRippleGates_eq,bitListSubVisits_eq,hm]
  nlinarith only [hchar,hdiv,hmul]

/-- No natural-number counter is used to compute the row. -/
def bitCharacterRow (ms : List Bool) (p : ℕ) (step : List Bool) :
    List Bool → List Bool → List BitFourierInteger
  | [],_ => []
  | _::fuel,counter => bitNegativeCharacter counter ms p::
      bitCharacterRow ms p step fuel (bitListAdd counter step)

def bitCharacterRowWork (ms : List Bool) (p : ℕ) (step : List Bool) :
    List Bool → List Bool → ℕ
  | [],_ => 1
  | _::fuel,counter => bitNegativeCharacterWork counter ms p+
      bitListSignedAddCost false false counter step+
      bitCharacterRowWork ms p step fuel (bitListAdd counter step)+2

theorem bitCharacterRow_length (ms step fuel counter : List Bool) (p : ℕ) :
    (bitCharacterRow ms p step fuel counter).length=fuel.length := by
  induction fuel generalizing counter with
  | nil => rfl
  | cons b fuel ih => simp only [bitCharacterRow,List.length_cons,ih]

theorem bitCharacterRow_get {N : ℕ} [NeZero N] (ms step fuel counter : List Bool)
    (hM : binaryDigitsValue ms=N) (p : ℕ) (i : ℕ) (hi : i<fuel.length) :
    ((bitCharacterRow ms p step fuel counter)[i]'(by rw [bitCharacterRow_length]; exact hi)).value=
      dyadicCharacterInteger (-((binaryDigitsValue counter+i*binaryDigitsValue step : ℕ) : ZMod N)) p := by
  induction fuel generalizing counter i with
  | nil => simp only [List.length_nil] at hi; omega
  | cons b fuel ih =>
    cases i with
    | zero => simpa only [bitCharacterRow,List.getElem_cons_zero,zero_mul,add_zero] using
        bitNegativeCharacter_value counter ms hM p
    | succ i =>
      have h := ih (bitListAdd counter step) i (by simpa only [List.length_cons,Nat.succ_lt_succ_iff] using hi)
      simp only [bitCharacterRow,List.getElem_cons_succ] at ⊢
      rw [h,bitListAdd_correct]
      congr 3
      ring


theorem bitCharacterRowWork_bound {N : ℕ} [NeZero N] (ms step fuel counter : List Bool)
    (hM : binaryDigitsValue ms=N) (p L : ℕ) (hc : BitListCanonical counter)
    (hm : ms.length≤L) (hs : step.length≤L)
    (hbound : (binaryDigitsValue counter+fuel.length*binaryDigitsValue step).size≤L) :
    bitCharacterRowWork ms p step fuel counter≤1+fuel.length*(320*(L+1)^2+
      4194304*(N.size+p+72)^2*(characterWorkBits N (p+2)+1)^3) := by
  induction fuel generalizing counter with
  | nil => simp [bitCharacterRowWork]
  | cons b fuel ih =>
    have hcounter : counter.length≤L := by
      rw [hc.length]
      exact (Nat.size_le_size (Nat.le_add_right _ _)).trans hbound
    have hnext : (binaryDigitsValue (bitListAdd counter step)+fuel.length*binaryDigitsValue step).size≤L := by
      rw [bitListAdd_correct]
      convert hbound using 1 <;> simp only [List.length_cons] <;> congr 1 <;> ring
    have hi := ih (bitListAdd counter step) (bitListTrim_canonical _) hnext
    have hchar := bitNegativeCharacterWork_bound counter ms hM p
    have hchar' : bitNegativeCharacterWork counter ms p≤64*(2*L+2)^2+
        4194304*(N.size+p+72)^2*(characterWorkBits N (p+2)+1)^3 := hchar.trans
      (Nat.add_le_add_right (Nat.mul_le_mul_left 64 (Nat.pow_le_pow_left (by omega : counter.length+ms.length+2≤2*L+2) 2)) _)
    have hadd := bitListSignedAddCost_bound false false counter step L hcounter hs
    rw [bitCharacterRowWork,List.length_cons]
    nlinarith only [hi,hchar',hadd]

theorem bitCharacterRow_get_raw (ms step fuel counter : List Bool)
    (p : ℕ) (hc : BitListCanonical counter) (i : ℕ) (hi : i<fuel.length) :
    (bitCharacterRow ms p step fuel counter)[i]'(by rw [bitCharacterRow_length]; exact hi)=
      bitNegativeCharacter (binaryDigitsValue counter+i*binaryDigitsValue step).bits ms p := by
  induction fuel generalizing counter i with
  | nil => simp only [List.length_nil] at hi; omega
  | cons b fuel ih =>
    cases i with
    | zero =>
      simpa only [bitCharacterRow,List.getElem_cons_zero,zero_mul,add_zero] using
        congrArg (fun cs => bitNegativeCharacter cs ms p) hc
    | succ i =>
      have h := ih (bitListAdd counter step) (bitListTrim_canonical _) i
        (by simpa only [List.length_cons,Nat.succ_lt_succ_iff] using hi)
      simp only [bitCharacterRow,List.getElem_cons_succ] at ⊢
      rw [h,bitListAdd_correct]
      congr 2
      ring

theorem bitCharacterRow_ofFn (ms step fuel counter : List Bool)
    (p : ℕ) (hc : BitListCanonical counter) :
    bitCharacterRow ms p step fuel counter=List.ofFn (fun i : Fin fuel.length =>
      bitNegativeCharacter (binaryDigitsValue counter+i.val*binaryDigitsValue step).bits ms p) := by
  apply List.ext_getElem
  · simp only [bitCharacterRow_length,List.length_ofFn]
  · intro i hi hi'
    rw [List.getElem_ofFn]
    exact bitCharacterRow_get_raw ms step fuel counter p hc i (by simpa only [bitCharacterRow_length] using hi)

end Optss
