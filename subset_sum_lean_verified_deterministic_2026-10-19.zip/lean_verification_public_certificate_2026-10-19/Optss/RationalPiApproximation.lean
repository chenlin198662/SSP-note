import Mathlib.Analysis.SpecialFunctions.Complex.Arctan
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Data.Real.Pi.Bounds

/-! Computable rational approximations to π from two alternating arctangent
series. The error is geometric in the actual finite summation length. -/
namespace Optss
open scoped BigOperators Topology
open Filter

def rationalArctanPartial (x : ℚ) (n : ℕ) : ℚ :=
  ∑ i∈Finset.range (2*n), (-1 : ℚ)^i*x^(2*i+1)/(2*i+1)

theorem rationalArctanPartial_cast (x : ℚ) (n : ℕ) :
    (rationalArctanPartial x n : ℝ)=
      ∑ i∈Finset.range (2*n), (-1 : ℝ)^i*(x : ℝ)^(2*i+1)/(2*i+1) := by
  simp [rationalArctanPartial]

theorem rationalArctanPartial_error (x : ℚ) (hx₀ : 0≤x) (hx₁ : x<1) (n : ℕ) :
    0≤Real.arctan (x : ℝ)-(rationalArctanPartial x n : ℝ) ∧
      Real.arctan (x : ℝ)-(rationalArctanPartial x n : ℝ)≤
        (x : ℝ)^(4*n+1)/(4*n+1) := by
  have hx0 : (0 : ℝ)≤x := by exact_mod_cast hx₀
  have hx1 : (x : ℝ)<1 := by exact_mod_cast hx₁
  let f : ℕ → ℝ := fun i => (x : ℝ)^(2*i+1)/(2*i+1)
  have hmono : Antitone f := by
    intro i j hij
    apply div_le_div₀ (by positivity) (pow_le_pow_of_le_one hx0 hx1.le (by omega))
      (by positivity)
    exact_mod_cast (show 2*i+1≤2*j+1 by omega)
  have hsum := (Real.hasSum_arctan (x := (x : ℝ))
    (by rw [Real.norm_eq_abs,abs_of_nonneg hx0]; exact hx1)).tendsto_sum_nat
  have hlim : Tendsto (fun k => ∑ i∈Finset.range k, (-1 : ℝ)^i*f i)
      atTop (𝓝 (Real.arctan (x : ℝ))) := by
    simpa only [f,mul_div_assoc,Nat.cast_add,Nat.cast_mul,Nat.cast_ofNat,Nat.cast_one] using hsum
  have hlo := Antitone.alternating_series_le_tendsto hlim hmono n
  have hhi := Antitone.tendsto_le_alternating_series hlim hmono n
  rw [Finset.sum_range_succ] at hhi
  simp only [show (-1 : ℝ)^(2*n)=1 by simp,one_mul] at hhi
  have he : (rationalArctanPartial x n : ℝ)=
      ∑ i∈Finset.range (2*n), (-1 : ℝ)^i*f i := by
    rw [rationalArctanPartial_cast]
    simp only [f,mul_div_assoc]
  rw [← he] at hlo hhi
  have hf : f (2*n)=(x : ℝ)^(4*n+1)/(4*n+1) := by
    dsimp [f]
    rw [show 2*(2*n)+1=4*n+1 by omega]
    push_cast
    ring
  rw [hf] at hhi
  exact ⟨sub_nonneg.mpr hlo,by linarith⟩

def rationalPiApproximation (n : ℕ) : ℚ :=
  4*(rationalArctanPartial (1/2) n+rationalArctanPartial (1/3) n)

theorem rationalPiApproximation_error (n : ℕ) :
    0≤Real.pi-(rationalPiApproximation n : ℝ) ∧
      Real.pi-(rationalPiApproximation n : ℝ)≤8*(1/2 : ℝ)^(4*n+1) := by
  have h₂ := rationalArctanPartial_error (1/2) (by norm_num) (by norm_num) n
  have h₃ := rationalArctanPartial_error (1/3) (by norm_num) (by norm_num) n
  norm_num only [Rat.cast_div,Rat.cast_one,Rat.cast_ofNat] at h₂ h₃
  have hpi := Real.arctan_inv_2_add_arctan_inv_3
  norm_num only [← one_div] at hpi
  have hdiv₂ : (1/2 : ℝ)^(4*n+1)/(4*n+1)≤(1/2 : ℝ)^(4*n+1) := by
    apply div_le_self (by positivity)
    have h : (0 : ℝ)≤n := by positivity
    linarith
  have hdiv₃ : (1/3 : ℝ)^(4*n+1)/(4*n+1)≤(1/2 : ℝ)^(4*n+1) := by
    have hden : (1 : ℝ)≤4*n+1 := by
      have h : (0 : ℝ)≤n := Nat.cast_nonneg _
      linarith
    apply (div_le_self (by positivity) hden).trans
    exact pow_le_pow_left₀ (by norm_num) (by norm_num) _
  unfold rationalPiApproximation
  push_cast
  constructor <;> linarith

theorem rationalPiApproximation_abs_error (n : ℕ) :
    |Real.pi-(rationalPiApproximation n : ℝ)|≤8*(1/2 : ℝ)^(4*n+1) := by
  rw [abs_of_nonneg (rationalPiApproximation_error n).1]
  exact (rationalPiApproximation_error n).2

theorem rationalPiApproximation_bounds (n : ℕ) :
    0≤rationalPiApproximation n ∧ rationalPiApproximation n≤4 := by
  have hb := rationalPiApproximation_error n
  have hnonneg : (0 : ℝ)≤rationalPiApproximation n := by
    by_cases hn : n=0
    · subst n
      simp [rationalPiApproximation,rationalArctanPartial]
    · have hp : (1/2 : ℝ)^(4*n+1)≤(1/2 : ℝ)^5 :=
        pow_le_pow_of_le_one (by norm_num) (by norm_num) (by omega)
      have hpi := Real.pi_gt_three
      norm_num at hp
      linarith
  constructor
  · exact_mod_cast hnonneg
  · have h := Real.pi_le_four
    exact_mod_cast (show (rationalPiApproximation n : ℝ)≤4 by linarith)

theorem rationalPiApproximation_precision (p : ℕ) :
    |Real.pi-(rationalPiApproximation (p+2) : ℝ)|≤(1/2 : ℝ)^(p+4) := by
  apply (rationalPiApproximation_abs_error (p+2)).trans
  have hp : (1/2 : ℝ)^(4*(p+2)+1)≤(1/2 : ℝ)^(p+7) :=
    pow_le_pow_of_le_one (by norm_num) (by norm_num) (by omega)
  calc
    _ ≤ 8*(1/2 : ℝ)^(p+7) := mul_le_mul_of_nonneg_left hp (by norm_num)
    _ = _ := by rw [pow_add,pow_add]; norm_num; ring

end Optss
