import Optss.LongSumsetScaleAssembly
import Optss.LongSumsetUniformParameters

/-!
# Long sumsets: actual containing, proper, filled progression existence

All structural inputs are proved in the imported chain. The initial
polynomial-scale theorem is assembled here before converting the paper's
real power hypothesis into its sufficiently-large-ambient formulation.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 2400000
local instance longSumsetExistenceDecEqInt : DecidableEq ℤ := Classical.decEq _

def zeroCenteredProgression : CenteredProgression (Fin 0) ℤ where
  lowerRadius _ := 0
  upperRadius _ := 0
  lower_nonneg _ := le_rfl
  upper_nonneg _ := le_rfl
  map := 0

theorem zeroCenteredProgression_values (s : ℝ) : zeroCenteredProgression.values s = {0} := by
  ext x
  rw [CenteredProgression.mem_values]
  constructor
  · rintro ⟨z, _, hz⟩
    simpa only [zeroCenteredProgression, AddMonoidHom.zero_apply, Finset.mem_singleton] using hz.symm
  · intro hx
    have hx0 : x=0 := Finset.mem_singleton.mp hx
    refine ⟨0, ?_, by simp [zeroCenteredProgression, hx0]⟩
    rw [CenteredProgression.mem_coefficientBox]
    intro i
    exact Fin.elim0 i

theorem zeroCenteredProgression_proper (s : ℝ) : zeroCenteredProgression.Proper s := by
  intro x _ y _ _
  exact Subsingleton.elim _ _

/-- Natural polynomial-scale form, with constants independent of the
input set, ambient interval, and number of summands. -/
theorem long_sumset_polynomial_existence (B : ℕ) :
    ∃ h₀ R : ℕ, ∃ c : ℝ, 0 < c ∧ ∀ (N h : ℕ) (A : Finset ℤ),
      h₀ ≤ h → N+1 ≤ h^B → A ⊆ Finset.Icc 0 (N:ℤ) → 0∈A →
      ∃ d ≤ R, ∃ Q : CenteredProgression (Fin d) ℤ,
        A ⊆ Q.values 1 ∧ Q.Proper (c*h) ∧
        ∃ z : ℤ, (Q.values (c*h)).image (z+·) ⊆ h • A := by
  let R := 4*B+2
  obtain ⟨H₀, hH₀, hsmall⟩ := small_doubling_wide_filling R
  obtain ⟨v, w, L, γlow, hγlow, hparams⟩ := long_sumset_uniform_parameters R
  let a := H₀+v
  let c := min (((2:ℝ)^(w+1+v+w+L))⁻¹) (γlow/2)
  have hc : 0<c := lt_min (by positivity) (by positivity)
  refine ⟨2^(2*max 1 (a+w)), R, c, hc, ?_⟩
  intro N h A hlarge hpoly hA hzero
  obtain ⟨q, hqR, j, haj, hjlog, hstep, hminimal⟩ :=
    dyadic_minimal_rank_at_polynomial_scale_margin A N h B a w hA hzero hpoly hlarge
  have hvj : v ≤ j := by dsimp [a] at haj; omega
  have hHlarge : H₀ ≤ 2^j := by
    have hjp : j ≤ 2^j := Nat.lt_two_pow_self.le
    dsimp [a] at haj
    omega
  have hsmallData := by
    letI : DecidableEq ℤ := Int.instDecidableEq
    apply hsmall q hqR A N (2^j) hzero hA hHlarge
    simpa only [dyadicSumset, pow_succ, mul_comm, mul_assoc] using hstep
  rcases hsmallData with hsingleton | ⟨d, hd, hdq, P, hp, hwidth, _, hcontain, hfill⟩
  · refine ⟨0, by omega, zeroCenteredProgression, ?_, zeroCenteredProgression_proper _, 0, ?_⟩
    · rw [zeroCenteredProgression_values, hsingleton]
    · rw [zeroCenteredProgression_values]
      intro x hx
      obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
      have hy0 : y=0 := Finset.mem_singleton.mp hy
      have hz := zero_mem_integer_repeated_sumset A hzero h
      simpa only [hy0, add_zero, ← Finset.mem_coe, Finset.coe_nsmul] using hz
  · have hdR : d ≤ R := hdq.trans hqR
    have hq : 0<q := hd.trans_le hdq
    obtain ⟨hη, hN₀, hγ, hL, hγlower⟩ := hparams d hd hdR
    let γ := denseLatticeFillingDilation d (rankContainerDensity R)
    let N₀ := denseBoxSummandThreshold d (rankContainerDensity R)
    have hγpos : 0<γ := denseLatticeFillingDilation_pos hd _ (rankContainerDensity_pos R)
    have hfill' : ∀ k : ℕ, N₀ ≤ k → ∃ z : ℤ,
        (P.values (γ*k)).image (z+·) ⊆ k • ((2^j:ℕ) • A) := by
      intro k hk
      obtain ⟨z, hz⟩ := hfill k hk
      refine ⟨z, ?_⟩
      change (↑((P.values (γ*k)).image (z+·)) : Set ℤ) ⊆ ↑(k • ((2^j:ℕ) • A))
      have hz' := Finset.coe_subset.mpr hz
      simpa only [γ, Finset.coe_image, Finset.coe_nsmul] using hz' 
    let b := Nat.log 2 h-w-1
    have hb : b+1+w = Nat.log 2 h := by dsimp [b]; omega
    have hjb : j ≤ b := by dsimp [b]; omega
    have hmin : ∀ p < q, ∀ i, a ≤ i → i ≤ b →
        (3/2:ℝ)*2^p*(dyadicSumset A i).card < (dyadicSumset A (i+1)).card := by
      intro p hp' i hai hib
      exact hminimal p hp' i hai (by omega)
    have hsym : P.lowerRadius = P.upperRadius := funext (fun i => (hwidth i).1)
    have hwr : ∀ i, (2:ℝ)^j ≤ P.upperRadius i := by
      intro i
      have hh := (hwidth i).2
      rw [(hwidth i).1] at hh
      exact_mod_cast hh
    have hcont' : A ⊆ P.values ((2:ℝ)^j)⁻¹ := by exact_mod_cast hcontain
    have hproper := filled_progression_proper_window A hzero a b q hq hdq hmin P hsym
      j v w L N₀ haj hvj hwr (hp.mono hη) hcont' γ hN₀ hγ hfill' hL
    have hhpos : 0<h := by have := Nat.two_pow_pos (2*max 1 (a+w)); omega
    have hhupper : (h:ℝ) ≤ (2:ℝ)^(b+w+2) := by
      have hh := (Nat.lt_pow_succ_log_self (by decide : 1<2) h).le
      have he : b+w+2 = Nat.log 2 h+1 := by omega
      rw [he]
      exact_mod_cast hh
    have htarget : P.Proper ((c*h)*((2:ℝ)^j)⁻¹) :=
      hproper.mono (long_sumset_final_scale_le j b w v w L h c (min_le_left _ _) hhupper)
    have hbudget : N₀*(2^j) ≤ h := by
      calc
        N₀*2^j ≤ 2^w*2^j := Nat.mul_le_mul_right _ hN₀
        _ = 2^(w+j) := (pow_add _ _ _).symm
        _ ≤ 2^(Nat.log 2 h) := Nat.pow_le_pow_right (by decide) (by omega)
        _ ≤ h := Nat.pow_log_le_self 2 (by omega)
    have hHh : 2^j ≤ h := (Nat.pow_le_pow_right (by decide) (by omega : j≤Nat.log 2 h)).trans
      (Nat.pow_log_le_self 2 (by omega))
    have hcγ : c ≤ γ/2 := (min_le_right _ _).trans (by linarith)
    obtain ⟨z, hz⟩ := filled_progression_final_sumset P A hzero (2^j) h N₀
      (Nat.two_pow_pos _) hHh hbudget γ c hγpos.le hcγ hfill'
    let Q := rescaledCenteredProgression P (((2:ℝ)^j)⁻¹) (by positivity)
    refine ⟨d, hdR, Q, ?_, ?_, z, ?_⟩
    · simpa only [Q, rescaledCenteredProgression_values, one_mul] using hcont'
    · exact (rescaledCenteredProgression_proper P _ _ _).mpr htarget
    · simpa only [Q, rescaledCenteredProgression_values, Nat.cast_pow, Nat.cast_ofNat] using hz

/-- Theorem 2.A, including the paper's sufficiently-large ambient interval
and real polynomial lower bound for the number of summands. All constants
depend only on the fixed positive exponent. -/
theorem theorem2A_long_sumsets (α : ℝ) (hα : 0 < α) :
    ∃ R N₀ : ℕ, ∃ c : ℝ, 0 < c ∧ ∀ (N s : ℕ) (X : Finset ℤ),
      N₀ ≤ N → X ⊆ Finset.Icc 0 (N : ℤ) → 0 ∈ X → (N : ℝ)^α ≤ s →
      ∃ d ≤ R, ∃ Q : CenteredProgression (Fin d) ℤ,
        X ⊆ Q.values 1 ∧ Q.Proper (c*s) ∧
        ∃ z : ℤ, (Q.values (c*s)).image (z+·) ⊆ s • X := by
  obtain ⟨h₀, R, c, hc, hex⟩ := long_sumset_polynomial_existence (longSumsetExponent α)
  let N₀ : ℕ := max 2 ⌈(h₀ : ℝ)^α⁻¹⌉₊
  refine ⟨R, N₀, c, hc, ?_⟩
  intro N s X hN hX hzero hscale
  have hN2 : 2 ≤ N := (le_max_left _ _).trans hN
  have hroot : (h₀ : ℝ)^α⁻¹ ≤ N := by
    calc
      (h₀ : ℝ)^α⁻¹ ≤ (⌈(h₀ : ℝ)^α⁻¹⌉₊ : ℝ) := Nat.le_ceil _
      _ ≤ (N₀ : ℝ) := by exact_mod_cast (le_max_right 2 ⌈(h₀ : ℝ)^α⁻¹⌉₊)
      _ ≤ N := by exact_mod_cast hN
  have hh : (h₀ : ℝ) ≤ (N : ℝ)^α := by
    have hp := Real.rpow_le_rpow (Real.rpow_nonneg (by positivity) α⁻¹) hroot hα.le
    rwa [Real.rpow_inv_rpow (by positivity) hα.ne'] at hp
  have hlarge : h₀ ≤ s := by exact_mod_cast hh.trans hscale
  exact hex N s X hlarge (longSumset_polynomial_ambient α hα N s hN2 hscale) hX hzero

end
end Optss
