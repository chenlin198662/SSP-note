import Optss.ComputableBohrConstants
import Optss.DyadicBogolyubovSpectrum

/-!
# The computed Fourier spectrum and its computed difference progression

The dyadic transform is cached once, followed by an actual finite filter of
its energies. The resulting distinct frequency list is passed to the stored
phase-lattice algorithm with an integer-only dimension constant.
-/
namespace Optss
open scoped BigOperators Pointwise
variable {N : ℕ} [NeZero N]

def dyadicSpectrumList (A : Finset (ZMod N)) : List (ZMod N) :=
  let values := dyadicRationalDFT N (dyadicIndicatorData A)
  ((List.finRange N).filter (fun k => decide
    (2*rationalFourierEnergySlack A≤rationalComplexEnergy (values.get k)))).map
      (fun k => (k.val:ZMod N))

theorem fin_natCast_zmod_injective : Function.Injective (fun k : Fin N => (k.val:ZMod N)) := by
  intro i j h
  apply Fin.ext
  have hh := congrArg ZMod.val h
  simpa only [ZMod.val_natCast,Nat.mod_eq_of_lt i.isLt,Nat.mod_eq_of_lt j.isLt] using hh

theorem dyadicSpectrumList_nodup (A : Finset (ZMod N)) : (dyadicSpectrumList A).Nodup := by
  exact (List.nodup_finRange N).filter _ |>.map fin_natCast_zmod_injective

theorem dyadicSpectrumList_toFinset (A : Finset (ZMod N)) :
    (dyadicSpectrumList A).toFinset=dyadicBogolyubovSpectrum A := by
  ext k
  simp only [List.mem_toFinset,dyadicSpectrumList,List.mem_map,List.mem_filter,
    List.mem_finRange,true_and,decide_eq_true_eq,dyadicBogolyubovSpectrum,
    rationalApproximateSpectrum,Finset.mem_filter,Finset.mem_univ]
  constructor
  · rintro ⟨j,hj,hjk⟩
    subst k
    have he : (⟨(j.val:ZMod N).val,(j.val:ZMod N).val_lt⟩:Fin N)=j := by
      apply Fin.ext
      simp only [ZMod.val_natCast,Nat.mod_eq_of_lt j.isLt]
    simpa only [he,true_and] using hj
  · intro hk
    exact ⟨⟨k.val,k.val_lt⟩,hk,ZMod.natCast_zmod_val k⟩

theorem dyadicSpectrumList_length (A : Finset (ZMod N)) :
    (dyadicSpectrumList A).length=(dyadicBogolyubovSpectrum A).card := by
  rw [←dyadicSpectrumList_toFinset,List.toFinset_card_of_nodup (dyadicSpectrumList_nodup A)]

def computedSpectrumBox (A : Finset (ZMod N)) :
    Option (BooleanLatticeBoxResult ((dyadicSpectrumList A).length+1)) :=
  let frequencies := dyadicSpectrumList A
  computedListBohrBox frequencies

theorem computedSpectrumBox_spec (A : Finset (ZMod N)) (hA : A.Nonempty) :
    ∃ box,computedSpectrumBox A=some box ∧
      Set.InjOn (storedPhaseProjection (N:=N) 0 box) (integerBudgetBox (decodedLatticeBoxWidths box)) ∧
      integerProgressionValues (storedPhaseProjection 0 box) (decodedLatticeBoxWidths box)⊆(A+A)-(A+A) ∧
      N≤computableBohrLoss ((dyadicSpectrumList A).length+1)*
        (integerProgressionValues (storedPhaseProjection (N:=N) 0 box) (decodedLatticeBoxWidths box)).card ∧
      (((dyadicSpectrumList A).length+1:ℕ):ℝ)≤1+16*(N:ℝ)^2/(A.card:ℝ)^2 ∧
      (∀ j,BitListCanonical (box.widths.toVector.get j)) := by
  obtain ⟨box,hbox,hproper,hsub,hcard,hcanon⟩ := computedListBohrBox_spec (dyadicSpectrumList A)
  refine ⟨box,hbox,hproper,?_,hcard,?_,hcanon⟩
  · intro x hx
    have hh := hsub hx
    rw [dyadicSpectrumList_toFinset] at hh
    exact dyadicBogolyubovSpectrum_subset_double_difference A hA hh
  · rw [dyadicSpectrumList_length]
    have h := dyadicBogolyubovSpectrum_card A hA
    push_cast
    linarith
end Optss
