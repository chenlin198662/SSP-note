import Optss.CommonPhaseLogarithms

/-!
# Logarithmic phase bounds without restricting the scale

These estimates use `log₂(hN+2)`, so they remain valid for arbitrarily large
scales and for inputs with arbitrary multiplicities.
-/
namespace Optss
set_option maxHeartbeats 1000000

theorem common_product_log_bound (D K V : ℕ) (hD : D ≤ K*V) :
    Nat.log 2 D+1 ≤ (Nat.log 2 K+2)*(Nat.log 2 V+1) := by
  have hk : K < 2^(Nat.log 2 K+1) := Nat.lt_pow_succ_log_self (by decide) K
  have hv : V < 2^(Nat.log 2 V+1) := Nat.lt_pow_succ_log_self (by decide) V
  have hp : K*V < 2^(Nat.log 2 K+1)*2^(Nat.log 2 V+1) :=
    (Nat.mul_le_mul_left K hv.le).trans_lt (Nat.mul_lt_mul_of_pos_right hk (by positivity))
  have he : 2^(Nat.log 2 K+1)*2^(Nat.log 2 V+1) = 2^(Nat.log 2 K+Nat.log 2 V+2) := by
    rw [← pow_add]
    congr 1
    omega
  have hb := hD.trans_lt (hp.trans_eq he)
  by_cases hz : D = 0
  · simp only [hz, Nat.log_zero_right]
    nlinarith
  · have hl := Nat.log_lt_of_lt_pow hz hb
    nlinarith

theorem common_phase_product_log_bound (D K M h N : ℕ)
    (hM : M ≤ h*N+1) (hD : D ≤ K*(M+2)) :
    Nat.log 2 D+1 ≤ (Nat.log 2 (2*K)+2)*(Nat.log 2 (h*N+2)+1) := by
  apply common_product_log_bound
  have hsum : M+2 ≤ 2*(h*N+2) := by omega
  exact hD.trans ((Nat.mul_le_mul_left K hsum).trans_eq (by ring))

theorem common_potential_product_log_bound (M h N : ℕ) (hM : M ≤ h*N+1) :
    Nat.log 2 M+1 ≤ 2*(Nat.log 2 (h*N+2)+1) := by
  simpa using common_product_log_bound M 1 (h*N+2) (by omega)

end Optss
