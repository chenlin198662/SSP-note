import Mathlib.Data.Sym.Card
import Mathlib.LinearAlgebra.LinearIndependent.Basic
import Mathlib.LinearAlgebra.Quotient.Basic
import Mathlib.Algebra.BigOperators.Option
import Mathlib.Algebra.Group.Pointwise.Finset.Basic
import Mathlib.Tactic

/-!
# Exact independent-direction counting

The elementary combinatorial inequalities in Lemmas 6.2 and 10.5 are proved
without a long-sumset growth hypothesis. A multiset of `k` optional directions
encodes every nonnegative coefficient vector of total at most `k`, with absent
terms padded by zero. Independent directions give distinct sums. Independence
in a quotient additionally makes all translated survivor sumsets disjoint.
No asymptotic rank threshold or total-rank-loss estimate is asserted here.
-/

namespace Optss
open scoped BigOperators Pointwise Classical
noncomputable section

section Counting
variable {E : Type*} [AddCommMonoid E] {q k : ℕ}

/-- A multiset of `k` optional labels represents total coefficient at most `k`.
The `none` labels supply exactly the missing zero terms. -/
def paddedDirectionSum (v : Fin q → E) (s : Sym (Option (Fin q)) k) : E :=
  ∑ i, s.val.count (some i) • v i

/-- Counting labels gives the ordinary sum of the padded list of directions. -/
theorem paddedDirectionSum_eq_multiset_sum (v : Fin q → E)
    (s : Sym (Option (Fin q)) k) :
    paddedDirectionSum v s =
      (s.val.map (fun a => Option.elim a 0 v)).sum := by
  have hcount (f : Option (Fin q) → E) (a : Multiset (Option (Fin q))) :
      (a.map f).sum = ∑ i, a.count i • f i := by
    induction a using Multiset.induction_on with
    | empty => simp
    | @cons a s ih =>
      simp only [Multiset.map_cons, Multiset.sum_cons, Multiset.count_cons,
        add_nsmul, Finset.sum_add_distrib, ih]
      simp [ite_smul, add_comm]
  rw [hcount (fun a => Option.elim a 0 v) s.val]
  simp [paddedDirectionSum, Fintype.sum_option]

/-- Stars and bars, stated in the coefficient-simplex orientation used in the paper. -/
theorem card_padded_directions (q k : ℕ) :
    Fintype.card (Sym (Option (Fin q)) k) = (k + q).choose q := by
  rw [Sym.card_sym_eq_choose]
  simp only [Fintype.card_option, Fintype.card_fin]
  have he : q + 1 + k - 1 = k + q := by omega
  rw [he, Nat.choose_symm_add]

/-- The sum of a multiset of members of `U` belongs to the corresponding repeated
sumset. Repeated labels are allowed, as required by the rank potential. -/
theorem multiset_sum_mem_repeatedSumset (U : Finset E) (s : Multiset E)
    (hs : ∀ a ∈ s, a ∈ U) : s.sum ∈ s.card • U := by
  induction s using Multiset.induction_on with
  | empty => simp
  | @cons a s ih =>
    rw [Multiset.sum_cons, Multiset.card_cons, succ_nsmul]
    exact Finset.mem_add.mpr ⟨s.sum, ih (fun b hb => hs b (by simp [hb])),
      a, hs a (by simp), add_comm _ _⟩

/-- Every padded combination is a genuine `k`-fold sum from the old support. -/
theorem paddedDirectionSum_mem (v : Fin q → E) (U : Finset E)
    (hzero : 0 ∈ U) (hv : ∀ i, v i ∈ U) (s : Sym (Option (Fin q)) k) :
    paddedDirectionSum v s ∈ k • U := by
  rw [paddedDirectionSum_eq_multiset_sum]
  have hmem : ∀ a ∈ s.val.map (fun a => Option.elim a 0 v), a ∈ U := by
    intro a ha
    obtain ⟨b, _, rfl⟩ := Multiset.mem_map.mp ha
    cases b with
    | none => exact hzero
    | some i => exact hv i
  have h := multiset_sum_mem_repeatedSumset U _ hmem
  simpa only [Multiset.card_map, s.property] using h

/-- A homomorphism sends the padded sum to the same combination of its images. -/
theorem map_paddedDirectionSum {F : Type*} [AddCommMonoid F]
    (g : E →+ F) (v : Fin q → E) (s : Sym (Option (Fin q)) k) :
    g (paddedDirectionSum v s) = paddedDirectionSum (fun i => g (v i)) s := by
  simp only [paddedDirectionSum, map_sum, map_nsmul]

end Counting

section Independent
variable {R E : Type*} [Semiring R] [CharZero R] [AddCommMonoid E] [Module R E]
  {q k : ℕ}

/-- Linear independence separates all nonnegative combinations, including their
unique zero padding; no independence of the zero vector is assumed. -/
theorem paddedDirectionSum_injective (v : Fin q → E) (hv : LinearIndependent R v) :
    Function.Injective (paddedDirectionSum v : Sym (Option (Fin q)) k → E) := by
  intro s t he
  have hcoeff : (fun i => (s.val.count (some i) : R)) =
      (fun i => (t.val.count (some i) : R)) := by
    apply hv.fintypeLinearCombination_injective
    simpa only [Fintype.linearCombination_apply, Nat.cast_smul_eq_nsmul, paddedDirectionSum] using he
  have hsome (i : Fin q) : s.val.count (some i) = t.val.count (some i) :=
    Nat.cast_injective (congrFun hcoeff i)
  have hcard (a : Sym (Option (Fin q)) k) :
      a.val.count none + ∑ i, a.val.count (some i) = k := by
    have hc := Multiset.sum_count_eq_card (s := Finset.univ) (m := a.val)
      (fun x _ => Finset.mem_univ x)
    simpa only [Fintype.sum_option, a.property] using hc
  have hs := hcard s
  have ht := hcard t
  have hrest : (∑ i, s.val.count (some i)) = ∑ i, t.val.count (some i) :=
    Finset.sum_congr rfl (fun i _ => hsome i)
  rw [hrest] at hs
  have hnone : s.val.count none = t.val.count none := Nat.add_right_cancel (hs.trans ht.symm)
  apply Sym.ext
  apply Multiset.ext.mpr
  intro a
  cases a with
  | none => exact hnone
  | some i => exact hsome i

/-- The elementary rank lower bound in Lemmas 6.2 and 10.5. -/
theorem independent_repeatedSumset_card (v : Fin q → E) (hv : LinearIndependent R v)
    (U : Finset E) (hzero : 0 ∈ U) (hU : ∀ i, v i ∈ U) (k : ℕ) :
    (k + q).choose q ≤ (k • U).card := by
  let f : Sym (Option (Fin q)) k → ↥(k • U) :=
    fun s => ⟨paddedDirectionSum v s, paddedDirectionSum_mem v U hzero hU s⟩
  have hinj : Function.Injective f := by
    intro s t h
    exact paddedDirectionSum_injective v hv (congrArg Subtype.val h)
  have h := Fintype.card_le_of_injective f hinj
  simpa only [card_padded_directions, Fintype.card_coe] using h

end Independent

section Quotient
variable {R E : Type*} [Ring R] [CharZero R] [AddCommGroup E] [Module R E]
  {q k : ℕ}

/-- Quotient independence separates all translated combinations when the
translation vectors lie in the survivor submodule. -/
theorem paddedDirectionSum_add_injective (W : Submodule R E) (v : Fin q → E)
    (hv : LinearIndependent R (fun i => W.mkQ (v i))) (S : Finset E)
    (hS : ∀ a ∈ S, a ∈ W) :
    Function.Injective (fun p : Sym (Option (Fin q)) k × ↥S =>
      paddedDirectionSum v p.1 + p.2.val) := by
  rintro ⟨s, a⟩ ⟨t, b⟩ he
  have ha : W.mkQ a.val = 0 := by
    apply LinearMap.mem_ker.mp
    simpa only [W.ker_mkQ] using hS a.val a.property
  have hb : W.mkQ b.val = 0 := by
    apply LinearMap.mem_ker.mp
    simpa only [W.ker_mkQ] using hS b.val b.property
  have hquot := congrArg W.mkQ he
  simp only [map_add, ha, hb, add_zero] at hquot
  have hst : s = t := by
    apply paddedDirectionSum_injective (fun i => W.mkQ (v i)) hv
    exact (map_paddedDirectionSum W.mkQ.toAddMonoidHom v s).symm.trans
      (hquot.trans (map_paddedDirectionSum W.mkQ.toAddMonoidHom v t))
  subst t
  have hab : a = b := Subtype.ext (add_left_cancel he)
  subst b
  rfl

/-- Exact counting of disjoint translates. No estimate for survivor growth is
needed: the hypothesis specifies only actual containment of the translated sets. -/
theorem independent_modulo_translates_card (W : Submodule R E) (v : Fin q → E)
    (hv : LinearIndependent R (fun i => W.mkQ (v i))) (S T : Finset E)
    (hS : ∀ a ∈ S, a ∈ W)
    (hT : ∀ s : Sym (Option (Fin q)) k, ∀ a ∈ S, paddedDirectionSum v s + a ∈ T) :
    (k + q).choose q * S.card ≤ T.card := by
  let f : Sym (Option (Fin q)) k × ↥S → ↥T :=
    fun p => ⟨paddedDirectionSum v p.1 + p.2.val, hT p.1 p.2.val p.2.property⟩
  have hinj : Function.Injective f := by
    intro p p' h
    exact paddedDirectionSum_add_injective W v hv S hS (congrArg Subtype.val h)
  have h := Fintype.card_le_of_injective f hinj
  simpa only [Fintype.card_prod, card_padded_directions, Fintype.card_coe] using h

omit [CharZero R] in
/-- Repeated sums of survivor vectors stay in their linear span. -/
theorem repeatedSumset_mem_submodule (W : Submodule R E) (S : Finset E)
    (hS : ∀ a ∈ S, a ∈ W) (m : ℕ) : ∀ a ∈ m • S, a ∈ W := by
  induction m with
  | zero =>
    intro a ha
    have ha0 : a = 0 := by simpa using ha
    simp [ha0]
  | succ m ih =>
    intro a ha
    rw [succ_nsmul] at ha
    obtain ⟨b, hb, c, hc, rfl⟩ := Finset.mem_add.mp ha
    exact W.add_mem (ih b hb) (hS c hc)

/-- Equation (33), with explicit integer scales. Choosing `m = k/2` satisfies
`2m ≤ k`. The same inequality is used in Lemma 10.5 before invoking long-sumset
growth. Survivor and old supports may already include both signs and zero. -/
theorem rankLoss_repeatedSumset_counting (W : Submodule R E) (v : Fin q → E)
    (hv : LinearIndependent R (fun i => W.mkQ (v i))) (survivors old : Finset E)
    (hzero : 0 ∈ old) (hvold : ∀ i, v i ∈ old) (hsub : survivors ⊆ old)
    (hspan : ∀ a ∈ survivors, a ∈ W) (m k : ℕ) (hscale : 2 * m ≤ k) :
    (m + q).choose q * (m • survivors).card ≤ (k • old).card := by
  apply independent_modulo_translates_card W v hv (m • survivors) (k • old)
    (repeatedSumset_mem_submodule W survivors hspan m)
  intro s a ha
  have hcombo := paddedDirectionSum_mem v old hzero hvold s
  have haold : a ∈ m • old := Finset.nsmul_subset_nsmul_left hsub ha
  have hboth : paddedDirectionSum v s + a ∈ (m + m) • old := by
    rw [add_nsmul]
    exact Finset.mem_add.mpr ⟨_, hcombo, a, haold, rfl⟩
  exact Finset.nsmul_subset_nsmul_right hzero (by omega) hboth

end Quotient

end
end Optss
