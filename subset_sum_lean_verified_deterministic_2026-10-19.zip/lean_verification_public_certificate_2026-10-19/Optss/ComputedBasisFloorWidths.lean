import Optss.ComputedBasisWidths
import Optss.ListStoredFloorWidths

/-! Actual cofactor-inverse, stored-product, and floor-width computation. -/
namespace Optss
open scoped BigOperators
variable {r m : ℕ}

def computedBasisFloorWidths (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m) :
    BooleanListArray (List Bool) r :=
  let coefficients := constructedListMatrixInverse A
  listStoredVertexFloorWidths coefficients V

def computedBasisFloorWidthsWork (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m) : ℕ :=
  let coefficients := constructedListMatrixInverse A
  constructedListMatrixInverseWork A+listStoredVertexFloorWidthsWork coefficients V+1

theorem computedBasisFloorWidths_value (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) (j : Fin r) :
    binaryDigitsValue ((computedBasisFloorWidths A V).toVector.get j)=
      rationalVertexFloorWidth (rationalCofactorInverse ((rectangularListFractionMatrix A).map bitListFractionValue))
        (storedRationalVertices V) j := by
  rw [computedBasisFloorWidths,listStoredVertexFloorWidths_value _ V
    (constructedListMatrixInverse_wellFormed A hA) hV,constructedListMatrixInverse_value_matrix A hA]

/-- The computed output is exactly the thin-body geometric floor width. -/
theorem computedBasisFloorWidths_eq_basisFloorWidth
    (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hcolumns : ∀ i j,(bitListFractionValue (rectangularListFractionMatrix A i j):ℝ)=b j i)
    (hm : 0<m)
    (hK : IsCompact (convexHull ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))))
    (hne : (convexHull ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))).Nonempty)
    (j : Fin r) :
    binaryDigitsValue ((computedBasisFloorWidths A V).toVector.get j)=
      basisFloorWidth b (convexHull ℝ (rationalVertexSet (storedRationalVertices V) : Set _)) hK hne j := by
  rw [computedBasisFloorWidths_value A V hA hV]
  exact rationalCofactor_floorWidth_eq_basisFloorWidth b _ hcolumns (storedRationalVertices V) hm hK hne j

noncomputable def computedBasisFloorWidthsPolynomial (r m : ℕ) : Polynomial ℕ :=
  constructedInversePolynomial r+(storedVertexFloorWidthsPolynomial r m).comp (computedBasisIntermediateSize r)+1

/-- All intermediate input-size premises are discharged from original data. -/
theorem computedBasisFloorWidthsWork_input_polynomial (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) :
    computedBasisFloorWidthsWork A V≤
      (computedBasisFloorWidthsPolynomial r m).eval (listStoredRationalBits A+listStoredRationalBits V) := by
  let N := listStoredRationalBits A+listStoredRationalBits V
  have ha : listStoredRationalBits A≤N := Nat.le_add_right _ _
  have hv : listStoredRationalBits V≤N := Nat.le_add_left _ _
  have hsize := constructedListMatrixInverse_bits A hA
  have htotal : listStoredRationalBits (constructedListMatrixInverse A)+listStoredRationalBits V≤
      (computedBasisIntermediateSize r).eval N := by
    simp only [computedBasisIntermediateSize,Polynomial.eval_add,Polynomial.eval_C,
      Polynomial.eval_mul,Polynomial.eval_ofNat,Polynomial.eval_X,Polynomial.eval_one]
    exact (Nat.add_le_add hsize hv).trans (by gcongr)
  have hi := (constructedListMatrixInverseWork_input_polynomial A hA).trans
    (natPolynomial_eval_mono (constructedInversePolynomial r) ha)
  have hw := (listStoredVertexFloorWidthsWork_input_polynomial (constructedListMatrixInverse A) V
    (constructedListMatrixInverse_wellFormed A hA) hV).trans
      (natPolynomial_eval_mono (storedVertexFloorWidthsPolynomial r m) htotal)
  unfold computedBasisFloorWidthsWork
  simp only [computedBasisFloorWidthsPolynomial,Polynomial.eval_add,Polynomial.eval_one,Polynomial.eval_comp]
  change _≤(constructedInversePolynomial r).eval N+
    (storedVertexFloorWidthsPolynomial r m).eval ((computedBasisIntermediateSize r).eval N)+1
  exact Nat.add_le_add_right (Nat.add_le_add hi hw) 1
end Optss
