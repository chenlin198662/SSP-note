import Optss.DenseLatticeProgression

/-!
# A uniform finite-copy corollary of dense lattice filling

CFP Corollary 2.17(1) follows by choosing one sufficiently large copy count
and translating an arbitrary dense set to contain zero. All translations,
integer endpoints, and the affine generated subgroup are explicit.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 800000
variable {d : ℕ}

def denseLatticeCorollaryScale (d : ℕ) (c : ℝ) : ℕ :=
  max (denseLatticeOuterScale d)
    (max (denseBoxSummandThreshold d c) ⌈(denseLatticeFillingDilation d c)⁻¹⌉₊)

theorem denseLatticeCorollaryScale_pos (hd : 0 < d) (c : ℝ) :
    0 < denseLatticeCorollaryScale d c :=
  (denseLatticeOuterScale_pos hd).trans_le (le_max_left _ _)

theorem denseLatticeCorollaryScale_fills (hd : 0 < d) (c : ℝ) (hc : 0 < c) :
    1 ≤ denseLatticeFillingDilation d c * denseLatticeCorollaryScale d c := by
  have hγ := denseLatticeFillingDilation_pos hd c hc
  have hceil : ⌈(denseLatticeFillingDilation d c)⁻¹⌉₊ ≤ denseLatticeCorollaryScale d c :=
    (le_max_right _ _).trans (le_max_right _ _)
  have hh := (Nat.le_ceil ((denseLatticeFillingDilation d c)⁻¹)).trans
    (show (⌈(denseLatticeFillingDilation d c)⁻¹⌉₊ : ℝ) ≤
      denseLatticeCorollaryScale d c by exact_mod_cast hceil)
  simpa only [mul_inv_cancel₀ hγ.ne'] using mul_le_mul_of_nonneg_left hh hγ.le

theorem translated_box_dilation_mono (lo : IntVec d) (W : Fin d → ℕ)
    (hW : ∀ j, 1 ≤ W j) (k K : ℕ) (hk : k ≤ K) (P : Finset (IntVec d))
    (hP : ∃ t : IntVec d, P ⊆ fillingIntegerBox
      (fun j => t j + (k : ℤ) * lo j)
      (fun j => t j + (k : ℤ) * (lo j + W j - 1))) :
    ∃ t : IntVec d, P ⊆ fillingIntegerBox
      (fun j => t j + (K : ℤ) * lo j)
      (fun j => t j + (K : ℤ) * (lo j + W j - 1)) := by
  obtain ⟨t, ht⟩ := hP
  refine ⟨fun j => t j + ((k : ℤ) - K) * lo j, ?_⟩
  intro x hx
  have hh := (mem_fillingIntegerBox _ _ _).mp (ht hx)
  rw [mem_fillingIntegerBox]
  intro j
  have hj := hh j
  have hw : (1 : ℤ) ≤ W j := by exact_mod_cast hW j
  have hkk : (k : ℤ) ≤ K := by exact_mod_cast hk
  dsimp
  constructor <;> nlinarith

/-- Centered part of CFP Corollary 2.17(1), with one explicit copy count
depending only on the dimension and density. -/
theorem dense_box_corollary_zero (hd : 0 < d) (c : ℝ) (hc : 0 < c) (hc1 : c ≤ 1)
    (A : Finset (IntVec d)) (lo : IntVec d) (W : Fin d → ℕ)
    (hW : ∀ j, denseBoxWidthThreshold c ≤ W j)
    (hbox : A ⊆ fillingIntegerBox lo (fun j => lo j + W j - 1))
    (hdense : c * (fillingIntegerBox lo (fun j => lo j + W j - 1)).card ≤ A.card)
    (hzero : 0 ∈ A) :
    ∃ P : CenteredProgression (Fin d) (IntVec d),
      Function.Injective P.map ∧ P.map.range = AddSubgroup.closure (A : Set (IntVec d)) ∧
      (∀ j, P.lowerRadius j = P.upperRadius j ∧ 1 ≤ P.lowerRadius j) ∧
      (∀ x ∈ fillingIntegerBox lo (fun j => lo j + W j - 1),
        x ∈ AddSubgroup.closure (A : Set (IntVec d)) → x ∈ P.values 1) ∧
      (∃ t : IntVec d, P.values 1 ⊆ fillingIntegerBox
        (fun j => t j + (denseLatticeCorollaryScale d c : ℤ) * lo j)
        (fun j => t j + (denseLatticeCorollaryScale d c : ℤ) * (lo j + W j - 1))) ∧
      ∃ z : IntVec d, (P.values 1).image (z + ·) ⊆ denseLatticeCorollaryScale d c • A := by
  obtain ⟨P, hinj, hrange, hrad, hcontains, houter, hfill⟩ :=
    dense_generated_lattice_progression hd c hc hc1 A lo W hW hbox hdense hzero
  refine ⟨P, hinj, hrange, hrad, hcontains, ?_, ?_⟩
  · exact translated_box_dilation_mono lo W
      (fun j => (denseBoxWidthThreshold_spec c hc _ (hW j)).1)
      _ _ (le_max_left _ _) _ houter
  · obtain ⟨z, _, hz⟩ := hfill (denseLatticeCorollaryScale d c)
      ((le_max_left _ _).trans (le_max_right _ _))
    exact ⟨z, (Finset.image_subset_image (P.values_mono
      (denseLatticeCorollaryScale_fills hd c hc))).trans hz⟩

theorem fillingIntegerBox_image_translate (lo hi a : IntVec d) :
    (fillingIntegerBox lo hi).image (a + ·) =
      fillingIntegerBox (a + lo) (a + hi) := by
  ext x
  simp only [Finset.mem_image, mem_fillingIntegerBox]
  constructor
  · rintro ⟨y, hy, rfl⟩ j
    exact ⟨add_le_add_left (hy j).1 _, add_le_add_left (hy j).2 _⟩
  · intro hx
    refine ⟨x - a, fun j => ?_, by abel⟩
    have hj := hx j
    change lo j ≤ x j - a j ∧ x j - a j ≤ hi j
    change a j + lo j ≤ x j ∧ x j ≤ a j + hi j at hj
    constructor <;> omega

theorem closure_translate_eq_closure_sub {G : Type*} [AddCommGroup G] [DecidableEq G]
    (A : Finset G) (a : G) (ha : a ∈ A) :
    AddSubgroup.closure ((A.image (-a + ·)) : Set G) = AddSubgroup.closure ((A - A) : Set G) := by
  apply le_antisymm
  · apply (AddSubgroup.closure_le _).mpr
    intro x hx
    obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
    apply AddSubgroup.subset_closure
    change -a + y ∈ (A : Set G) - (A : Set G)
    exact Set.mem_sub.mpr ⟨y, hy, a, ha, by abel⟩
  · apply (AddSubgroup.closure_le _).mpr
    intro x hx
    obtain ⟨y, hy, z, hz, rfl⟩ := Set.mem_sub.mp hx
    have hy' : -a + y ∈ AddSubgroup.closure (A.image (-a + ·) : Set G) :=
      AddSubgroup.subset_closure (Finset.mem_image.mpr ⟨y, hy, rfl⟩)
    have hz' : -a + z ∈ AddSubgroup.closure (A.image (-a + ·) : Set G) :=
      AddSubgroup.subset_closure (Finset.mem_image.mpr ⟨z, hz, rfl⟩)
    convert (AddSubgroup.closure (A.image (-a + ·) : Set G)).sub_mem hy' hz' using 1
    abel

theorem repeatedSumset_image_translate {G : Type*} [AddCommGroup G] [DecidableEq G]
    (A : Finset G) (a : G) (N : ℕ) :
    N • A.image (a + ·) = (N • A).image ((N • a) + ·) := by
  have he (S : Finset G) (b : G) : S.image (b + ·) = {b} + S := by
    ext x
    rw [Finset.mem_image, Finset.mem_add]
    constructor
    · rintro ⟨y, hy, he⟩
      exact ⟨b, Finset.mem_singleton_self _, y, hy, he⟩
    · rintro ⟨z, hz, y, hy, he⟩
      rw [Finset.mem_singleton] at hz
      subst z
      exact ⟨y, hy, he⟩
  rw [he, nsmul_add, Finset.nsmul_singleton, he]

/-- The arbitrary-set version. The translate `a + P` contains the original
box intersected with the affine group `a + ⟨A-A⟩`; its differences form a
basis of the full difference subgroup. -/
theorem dense_box_corollary (hd : 0 < d) (c : ℝ) (hc : 0 < c) (hc1 : c ≤ 1)
    (A : Finset (IntVec d)) (a : IntVec d) (ha : a ∈ A)
    (lo : IntVec d) (W : Fin d → ℕ)
    (hW : ∀ j, denseBoxWidthThreshold c ≤ W j)
    (hbox : A ⊆ fillingIntegerBox lo (fun j => lo j + W j - 1))
    (hdense : c * (fillingIntegerBox lo (fun j => lo j + W j - 1)).card ≤ A.card) :
    ∃ P : CenteredProgression (Fin d) (IntVec d),
      Function.Injective P.map ∧ P.map.range = AddSubgroup.closure ((A - A) : Set (IntVec d)) ∧
      (∀ j, P.lowerRadius j = P.upperRadius j ∧ 1 ≤ P.lowerRadius j) ∧
      (∀ x ∈ fillingIntegerBox lo (fun j => lo j + W j - 1),
        x - a ∈ AddSubgroup.closure ((A - A) : Set (IntVec d)) →
          x ∈ (P.values 1).image (a + ·)) ∧
      (∃ t : IntVec d, (P.values 1).image (a + ·) ⊆ fillingIntegerBox
        (fun j => t j + (denseLatticeCorollaryScale d c : ℤ) * lo j)
        (fun j => t j + (denseLatticeCorollaryScale d c : ℤ) * (lo j + W j - 1))) ∧
      ∃ z : IntVec d, ((P.values 1).image (a + ·)).image (z + ·) ⊆
        denseLatticeCorollaryScale d c • A := by
  let B := A.image (-a + ·)
  let lo' := -a + lo
  have hboxeq : (fillingIntegerBox lo (fun j => lo j + W j - 1)).image (-a + ·) =
      fillingIntegerBox lo' (fun j => lo' j + W j - 1) := by
    rw [fillingIntegerBox_image_translate]
    congr 1
    ext j
    change -a j + (lo j + W j - 1) = (-a j + lo j) + W j - 1
    ring
  have hBbox : B ⊆ fillingIntegerBox lo' (fun j => lo' j + W j - 1) := by
    rw [← hboxeq]
    exact Finset.image_subset_image hbox
  have hBdense : c * (fillingIntegerBox lo' (fun j => lo' j + W j - 1)).card ≤ B.card := by
    rw [← hboxeq, Finset.card_image_of_injective _ (add_right_injective (-a)),
      show B.card = A.card from Finset.card_image_of_injective _ (add_right_injective (-a))]
    exact hdense
  have hBzero : 0 ∈ B := Finset.mem_image.mpr ⟨a, ha, neg_add_cancel a⟩
  obtain ⟨P, hinj, hrange, hrad, hcontains, houter, z, hz⟩ :=
    dense_box_corollary_zero hd c hc hc1 B lo' W hW hBbox hBdense hBzero
  have hΓ := closure_translate_eq_closure_sub A a ha
  change AddSubgroup.closure (B : Set (IntVec d)) = _ at hΓ
  refine ⟨P, hinj, hrange.trans hΓ, hrad, ?_, ?_, ?_⟩
  · intro x hx hxΓ
    have hxB : -a + x ∈ fillingIntegerBox lo' (fun j => lo' j + W j - 1) := by
      rw [← hboxeq]
      exact Finset.mem_image.mpr ⟨x, hx, rfl⟩
    have hxΓ' : -a + x ∈ AddSubgroup.closure (B : Set (IntVec d)) := by
      rw [hΓ]
      convert hxΓ using 1
      abel
    exact Finset.mem_image.mpr ⟨-a+x, hcontains _ hxB hxΓ', by abel⟩
  · obtain ⟨t, ht⟩ := houter
    refine ⟨fun j => a j + t j - (denseLatticeCorollaryScale d c : ℤ) * a j, ?_⟩
    intro x hx
    obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
    have hh := (mem_fillingIntegerBox _ _ _).mp (ht hy)
    rw [mem_fillingIntegerBox]
    intro j
    have hj := hh j
    change t j + _ * (-a j + lo j) ≤ y j ∧ y j ≤ t j + _ * ((-a j + lo j) + W j - 1) at hj
    change _ ≤ a j + y j ∧ a j + y j ≤ _
    dsimp only
    constructor <;> nlinarith only [hj.1, hj.2]
  · let K := denseLatticeCorollaryScale d c
    refine ⟨K • a + z - a, ?_⟩
    intro x hx
    obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
    obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp hy
    have hh := hz (Finset.mem_image.mpr ⟨u, hu, rfl⟩)
    change z + u ∈ K • A.image (-a + ·) at hh
    rw [repeatedSumset_image_translate] at hh
    obtain ⟨w, hw, he⟩ := Finset.mem_image.mp hh
    have he' : (K • a + z - a) + (a + u) = w := by
      rw [smul_neg] at he
      calc
        _ = K • a + (z + u) := by abel
        _ = K • a + (-(K • a) + w) := by rw [he]
        _ = w := by abel
    rwa [he']

end
end Optss
