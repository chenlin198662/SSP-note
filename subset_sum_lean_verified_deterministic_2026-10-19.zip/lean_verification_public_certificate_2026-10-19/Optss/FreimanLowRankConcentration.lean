import Optss.FiniteGenericProjection

/-!
# The generalized two-to-the-dimension theorem

The generic projection is constructed for the finite input. A genuine
hyperplane in its image pulls back to a subset whose affine span has
rank at most `r-1`, with the same positive relative cardinality.
This is Bilu Theorem 5.6, including its generic-position argument.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
set_option maxHeartbeats 1000000
local instance freimanLowRankConcentrationDecEqRealVec (n : ℕ) : DecidableEq (Fin n → ℝ) := Classical.decEq _
variable {E : Type*} [AddCommGroup E] [Module ℝ E] [FiniteDimensional ℝ E]

/-- Transfer an actual target-space concentration bound through the
constructed generic projection. -/
theorem freiman_low_rank_concentration_transfer (r : ℕ) (hr : 0 < r) (ε δ : ℝ)
    (hconc : ∀ U : Finset (Fin r → ℝ), U.Nonempty →
      ((U+U).card:ℝ) < ((2:ℝ)^r-ε)*U.card →
      ∃ f : (Fin r → ℝ) →ₗ[ℝ] ℝ, f ≠ 0 ∧ ∃ t : ℝ,
        δ*U.card ≤ (U.filter (fun x => f x = t)).card) :
    ∀ S : Finset E, S.Nonempty → ((S+S).card:ℝ) < ((2:ℝ)^r-ε)*S.card →
      ∃ T : Finset E, T ⊆ S ∧ δ*S.card ≤ T.card ∧
        Module.finrank ℝ (Submodule.span ℝ ((T-T : Finset E) : Set E)) ≤ r-1 := by
  intro S hS hdoub
  obtain ⟨f, hfinj, hfrank⟩ := finite_set_generic_projection S r hr
  let U := S.image f
  have hUcard : U.card = S.card := Finset.card_image_iff.mpr hfinj
  have hUadd : U+U = (S+S).image f := (Finset.image_add f).symm
  have hUdoub : ((U+U).card:ℝ) < ((2:ℝ)^r-ε)*U.card := by
    rw [hUadd, hUcard]
    exact (Nat.cast_le.mpr Finset.card_image_le).trans_lt hdoub
  obtain ⟨g, hg, t, hmass⟩ := hconc U (hS.image f) hUdoub
  let T := S.filter (fun x => g (f x) = t)
  have hTS : T ⊆ S := Finset.filter_subset _ _
  have hTimage : T.image f = U.filter (fun x => g x = t) := by
    dsimp only [U, T]
    rw [Finset.filter_image]
  have hTcard : (U.filter (fun x => g x = t)).card = T.card := by
    rw [← hTimage]
    exact Finset.card_image_iff.mpr (hfinj.mono hTS)
  refine ⟨T, hTS, ?_, ?_⟩
  · simpa only [hUcard, hTcard] using hmass
  · let L := Submodule.span ℝ ((T-T : Finset E) : Set E)
    have hmap : L.map f ≤ LinearMap.ker g := by
      apply Submodule.map_le_iff_le_comap.mpr
      apply Submodule.span_le.mpr
      intro z hz
      obtain ⟨x, hx, y, hy, rfl⟩ := Finset.mem_sub.mp hz
      change g (f (x-y)) = 0
      rw [map_sub, map_sub, (Finset.mem_filter.mp hx).2, (Finset.mem_filter.mp hy).2, sub_self]
    have hdim := Submodule.finrank_mono hmap
    have hgdim := Module.Dual.finrank_ker_add_one_of_ne_zero hg
    have hcodim : Module.finrank ℝ (Fin r → ℝ) = r := by simp
    rw [hcodim] at hgdim
    have hLrank := hfrank T hTS
    change Module.finrank ℝ (L.map f) = min r (Module.finrank ℝ L) at hLrank
    change Module.finrank ℝ L ≤ r-1
    omega

/-- The concentration constant depends only on the target rank and gap. -/
theorem freiman_low_rank_concentration (r : ℕ) (hr : 0 < r) (ε : ℝ) (hε : 0 < ε) :
    ∃ δ : ℝ, 0 < δ ∧ ∀ S : Finset E, S.Nonempty →
      ((S+S).card:ℝ) < ((2:ℝ)^r-ε)*S.card →
      ∃ T : Finset E, T ⊆ S ∧ δ*S.card ≤ T.card ∧
        Module.finrank ℝ (Submodule.span ℝ ((T-T : Finset E) : Set E)) ≤ r-1 := by
  obtain ⟨δ, hδ, hc⟩ := freiman_hyperplane_concentration r hr ε hε
  exact ⟨δ, hδ, freiman_low_rank_concentration_transfer r hr ε δ hc⟩

omit [AddCommGroup E] [Module ℝ E] [FiniteDimensional ℝ E] in
/-- One constant works in all finite coordinate dimensions simultaneously. -/
theorem freiman_low_rank_concentration_uniform (r : ℕ) (hr : 0 < r) (ε : ℝ) (hε : 0 < ε) :
    ∃ δ : ℝ, 0 < δ ∧ ∀ (d : ℕ) (S : Finset (Fin d → ℝ)), S.Nonempty →
      ((S+S).card:ℝ) < ((2:ℝ)^r-ε)*S.card →
      ∃ T : Finset (Fin d → ℝ), T ⊆ S ∧ δ*S.card ≤ T.card ∧
        Module.finrank ℝ (Submodule.span ℝ ((T-T : Finset (Fin d → ℝ)) : Set (Fin d → ℝ))) ≤ r-1 := by
  obtain ⟨δ, hδ, hc⟩ := freiman_hyperplane_concentration r hr ε hε
  exact ⟨δ, hδ, fun _ => freiman_low_rank_concentration_transfer r hr ε δ hc⟩

/-- The concentrated subset lies in a genuine affine translate of the
specified low-dimensional linear subspace. -/
theorem freiman_low_rank_affine_concentration (r : ℕ) (hr : 0 < r) (ε : ℝ) (hε : 0 < ε) :
    ∃ δ : ℝ, 0 < δ ∧ ∀ S : Finset E, S.Nonempty →
      ((S+S).card:ℝ) < ((2:ℝ)^r-ε)*S.card →
      ∃ (a : E) (L : Submodule ℝ E), Module.finrank ℝ L ≤ r-1 ∧
        δ*S.card ≤ (S.filter (fun x => x-a ∈ L)).card := by
  obtain ⟨δ, hδ, hc⟩ := freiman_low_rank_concentration (E := E) r hr ε hε
  refine ⟨δ, hδ, ?_⟩
  intro S hS hdoub
  obtain ⟨T, hTS, hmass, hdim⟩ := hc S hS hdoub
  have hT : T.Nonempty := by
    have hh : (0:ℝ) < T.card := (mul_pos hδ (by exact_mod_cast hS.card_pos)).trans_le hmass
    exact Finset.card_pos.mp (by exact_mod_cast hh)
  obtain ⟨a, ha⟩ := hT
  refine ⟨a, Submodule.span ℝ ((T-T : Finset E) : Set E), hdim, hmass.trans ?_⟩
  apply Nat.cast_le.mpr
  apply Finset.card_le_card
  intro x hx
  exact Finset.mem_filter.mpr ⟨hTS hx, Submodule.subset_span (Finset.sub_mem_sub hx ha)⟩

end
end Optss
