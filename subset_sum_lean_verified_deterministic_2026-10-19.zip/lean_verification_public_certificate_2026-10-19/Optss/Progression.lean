import Optss.Basic
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Int.Interval
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Algebra.Group.Pointwise.Finset.Basic
import Mathlib.Algebra.Group.Subgroup.Basic

/-!
# Progression boxes and finite growth estimates

This file proves the finite counting implication underlying (7) and (8).
The existence of the containing progression with a filled proper dilate
(Theorem 2.A) is NOT assumed as an axiom or proved here. Instead the resulting
concrete containing/filling/properness data are explicit hypotheses.

Real coefficient endpoints are retained throughout. The uniform floor bounds
include arbitrarily short and zero-width coordinate intervals.
-/
namespace Optss
open scoped BigOperators Pointwise
noncomputable section

/-- A centered GAP description: a real box containing zero and an additive
map from its integer coordinate lattice. This includes nonsymmetric boxes. -/
structure CenteredProgression (ι G : Type*) [AddCommGroup G] where
  lowerRadius : ι → ℝ
  upperRadius : ι → ℝ
  lower_nonneg : ∀ i, 0 ≤ lowerRadius i
  upper_nonneg : ∀ i, 0 ≤ upperRadius i
  map : (ι → ℤ) →+ G

namespace CenteredProgression
variable {ι G : Type*} [Fintype ι] [AddCommGroup G]
local instance : DecidableEq ι := Classical.decEq _
local instance : DecidableEq G := Classical.decEq _

/-- Integer points in the geometric dilation of the coefficient box. -/
def coefficientBox (P : CenteredProgression ι G) (a : ℝ) : Finset (ι → ℤ) :=
  Fintype.piFinset (fun i => Finset.Icc ⌈-(a * P.lowerRadius i)⌉ ⌊a * P.upperRadius i⌋)

/-- The values represented by the geometrically dilated progression. -/
def values (P : CenteredProgression ι G) (a : ℝ) : Finset G := by
  classical
  exact (P.coefficientBox a).image P.map

/-- Properness is injectivity of the coordinate description at the given scale. -/
def Proper (P : CenteredProgression ι G) (a : ℝ) : Prop :=
  Set.InjOn P.map (P.coefficientBox a)

@[simp] theorem mem_coefficientBox (P : CenteredProgression ι G) (a : ℝ) (z : ι → ℤ) :
    z ∈ P.coefficientBox a ↔
      ∀ i, -(a * P.lowerRadius i) ≤ (z i : ℝ) ∧ (z i : ℝ) ≤ a * P.upperRadius i := by
  simp [coefficientBox, Fintype.mem_piFinset, Int.ceil_le, Int.le_floor]

@[simp] theorem mem_values (P : CenteredProgression ι G) (a : ℝ) (x : G) :
    x ∈ P.values a ↔ ∃ z ∈ P.coefficientBox a, P.map z = x := by
  classical
  exact Finset.mem_image

/-- Enlarging the geometric scale preserves the centered coefficient box. -/
theorem coefficientBox_mono (P : CenteredProgression ι G) {a b : ℝ} (hab : a ≤ b) :
    P.coefficientBox a ⊆ P.coefficientBox b := by
  intro z hz
  rw [mem_coefficientBox] at hz ⊢
  intro i
  have hlo := mul_le_mul_of_nonneg_right hab (P.lower_nonneg i)
  have hhi := mul_le_mul_of_nonneg_right hab (P.upper_nonneg i)
  exact ⟨(neg_le_neg hlo).trans (hz i).1, (hz i).2.trans hhi⟩

theorem values_mono (P : CenteredProgression ι G) {a b : ℝ} (hab : a ≤ b) :
    P.values a ⊆ P.values b := by
  exact Finset.image_subset_image (P.coefficientBox_mono hab)

/-- Properness is inherited by smaller geometric dilates, so the constant
in a long-sumset theorem may safely be decreased to at most one. -/
theorem Proper.mono {P : CenteredProgression ι G} {a b : ℝ}
    (hP : P.Proper b) (hab : a ≤ b) : P.Proper a := by
  exact Set.InjOn.mono (P.coefficientBox_mono hab) hP

/-- Exact coefficient volume, including the floor terms on both sides of zero. -/
theorem card_coefficientBox (P : CenteredProgression ι G) {a : ℝ} (ha : 0 ≤ a) :
    (P.coefficientBox a).card =
      ∏ i, (⌊a * P.lowerRadius i⌋₊ + ⌊a * P.upperRadius i⌋₊ + 1) := by
  rw [coefficientBox, Fintype.card_piFinset]
  apply Finset.prod_congr rfl
  intro i _
  rw [Int.card_Icc, Int.ceil_neg,
    ← Int.natCast_floor_eq_floor (mul_nonneg ha (P.lower_nonneg i)),
    ← Int.natCast_floor_eq_floor (mul_nonneg ha (P.upper_nonneg i))]
  omega

theorem card_values_le (P : CenteredProgression ι G) (a : ℝ) :
    (P.values a).card ≤ (P.coefficientBox a).card := by
  classical
  exact Finset.card_image_le

theorem card_values_of_proper (P : CenteredProgression ι G) {a : ℝ} (hP : P.Proper a) :
    (P.values a).card = (P.coefficientBox a).card := by
  classical
  exact Finset.card_image_iff.mpr hP

theorem zero_mem_coefficientBox (P : CenteredProgression ι G) {a : ℝ} (ha : 0 ≤ a) :
    (0 : ι → ℤ) ∈ P.coefficientBox a := by
  apply (P.mem_coefficientBox a 0).mpr
  intro i
  simp only [Pi.zero_apply, Int.cast_zero]
  exact ⟨neg_nonpos.mpr (mul_nonneg ha (P.lower_nonneg i)),
    mul_nonneg ha (P.upper_nonneg i)⟩

theorem zero_mem_values (P : CenteredProgression ι G) {a : ℝ} (ha : 0 ≤ a) :
    (0 : G) ∈ P.values a := by
  exact (P.mem_values a 0).mpr ⟨0, P.zero_mem_coefficientBox ha, map_zero _⟩

theorem coefficientBox_add (P : CenteredProgression ι G) {a b : ℝ}
    {x y : ι → ℤ} (hx : x ∈ P.coefficientBox a) (hy : y ∈ P.coefficientBox b) :
    x + y ∈ P.coefficientBox (a + b) := by
  rw [mem_coefficientBox] at hx hy ⊢
  intro i
  have hxi := hx i
  have hyi := hy i
  simp only [Pi.add_apply, Int.cast_add]
  constructor <;> nlinarith

theorem values_add_subset (P : CenteredProgression ι G) (a b : ℝ) :
    P.values a + P.values b ⊆ P.values (a + b) := by
  classical
  intro z hz
  obtain ⟨x, hx, y, hy, rfl⟩ := Finset.mem_add.mp hz
  obtain ⟨u, hu, rfl⟩ := (P.mem_values a x).mp hx
  obtain ⟨v, hv, rfl⟩ := (P.mem_values b y).mp hy
  exact (P.mem_values (a+b) _).mpr ⟨u+v, P.coefficientBox_add hu hv, map_add _ _ _⟩

/-- Repeated sumsets of a contained set remain in the corresponding geometric
dilation even when the coefficient endpoints are not integers. -/
theorem repeatedSumset_subset (P : CenteredProgression ι G) (X : Finset G)
    (hX : X ⊆ P.values 1) (n : ℕ) : n • X ⊆ P.values n := by
  classical
  induction n with
  | zero => simpa using P.zero_mem_values (by norm_num : (0 : ℝ) ≤ 0)
  | succ n ih =>
      rw [succ_nsmul]
      intro x hx
      obtain ⟨u, hu, v, hv, rfl⟩ := Finset.mem_add.mp hx
      have hmem := P.values_add_subset n 1 (Finset.add_mem_add (ih hu) (hX hv))
      simpa only [Nat.cast_add, Nat.cast_one] using hmem


/-- A floor estimate uniform in the coordinate width, including zero. -/
theorem floor_rescale_lt {a b x : ℝ} (hb : 0 ≤ b) (hx : 0 ≤ x)
    {k : ℕ} (hk : 1 ≤ k) (hba : b ≤ (k : ℝ) * a) :
    ⌊b * x⌋₊ < k * (⌊a * x⌋₊ + 1) := by
  apply (Nat.floor_lt (mul_nonneg hb hx)).mpr
  have hax := Nat.lt_floor_add_one (a*x)
  have hkpos : (0 : ℝ) < k := by exact_mod_cast (lt_of_lt_of_le Nat.zero_lt_one hk)
  have hmul := mul_lt_mul_of_pos_left hax hkpos
  have hbound := mul_le_mul_of_nonneg_right hba hx
  push_cast
  nlinarith

omit [Fintype ι] in
/-- Uniform comparison of the two-sided integer interval widths. No minimum
width or integrality of the original real endpoints is necessary. -/
theorem width_rescale_le (P : CenteredProgression ι G) {a b : ℝ} (hb : 0 ≤ b)
    {k : ℕ} (hk : 1 ≤ k) (hba : b ≤ (k : ℝ) * a) (i : ι) :
    ⌊b * P.lowerRadius i⌋₊ + ⌊b * P.upperRadius i⌋₊ + 1 ≤
      (2*k) * (⌊a * P.lowerRadius i⌋₊ + ⌊a * P.upperRadius i⌋₊ + 1) := by
  have h₁ := floor_rescale_lt hb (P.lower_nonneg i) hk hba
  have h₂ := floor_rescale_lt hb (P.upper_nonneg i) hk hba
  nlinarith

/-- The coefficient-volume growth estimate with an explicit rank-dependent
constant. In particular floors cause no failure for short coordinate widths. -/
theorem card_coefficientBox_rescale_le (P : CenteredProgression ι G)
    {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) {k : ℕ} (hk : 1 ≤ k)
    (hba : b ≤ (k : ℝ) * a) :
    (P.coefficientBox b).card ≤ (2*k) ^ Fintype.card ι * (P.coefficientBox a).card := by
  rw [P.card_coefficientBox ha, P.card_coefficientBox hb]
  calc
    (∏ i, (⌊b * P.lowerRadius i⌋₊ + ⌊b * P.upperRadius i⌋₊ + 1)) ≤
        ∏ i, ((2*k) * (⌊a * P.lowerRadius i⌋₊ + ⌊a * P.upperRadius i⌋₊ + 1)) :=
      Finset.prod_le_prod (fun _ _ => Nat.zero_le _) (fun i _ => P.width_rescale_le hb hk hba i)
    _ = _ := by rw [Finset.prod_mul_distrib]; simp

/-- The finite cardinality implication of the long-sumset input underlying
(7) and (8). The inner dilate must be proper and have an actual translate
inside `sX`; these concrete hypotheses are not an axiom asserting their
existence. For `a=c*s`, choose `k=ceil(t/a)` to obtain the paper's bound. -/
theorem repeated_growth_of_filled_proper (P : CenteredProgression ι G)
    (X : Finset G) (hX : X ⊆ P.values 1) {a : ℝ} (ha : 0 ≤ a)
    (hproper : P.Proper a) (s t k : ℕ) (hk : 1 ≤ k) (ht : (t : ℝ) ≤ k*a)
    (z : G) (hfill : (P.values a).image (z + ·) ⊆ s • X) :
    (t • X).card ≤ (2*k) ^ Fintype.card ι * (s • X).card := by
  have hinner : (P.coefficientBox a).card ≤ (s • X).card := by
    rw [← P.card_values_of_proper hproper,
      ← Finset.card_image_of_injective (P.values a) (add_right_injective z)]
    exact Finset.card_le_card hfill
  calc
    (t • X).card ≤ (P.values t).card := Finset.card_le_card (P.repeatedSumset_subset X hX t)
    _ ≤ (P.coefficientBox t).card := P.card_values_le t
    _ ≤ (2*k) ^ Fintype.card ι * (P.coefficientBox a).card :=
      P.card_coefficientBox_rescale_le ha (by positivity) hk ht
    _ ≤ (2*k) ^ Fintype.card ι * (s • X).card := Nat.mul_le_mul_left _ hinner


/-- Quantitative real-ratio form of (8), with explicit constant `(4/c)^rank`.
Once Theorem 2.A supplies a proper filled `c*s` dilate, this proves the growth
comparison for every `t≥s`, uniformly in all coordinate widths. -/
theorem repeated_growth_ratio (P : CenteredProgression ι G) (X : Finset G)
    (hX : X ⊆ P.values 1) {c : ℝ} (hc : 0 < c) (hc1 : c ≤ 1)
    (s t : ℕ) (hs : 0 < s) (hst : s ≤ t)
    (hproper : P.Proper (c*s)) (z : G)
    (hfill : (P.values (c*s)).image (z + ·) ⊆ s • X) :
    ((t • X).card : ℝ) ≤ (4/c) ^ Fintype.card ι *
      ((t : ℝ) / s) ^ Fintype.card ι * (s • X).card := by
  have hspos : (0 : ℝ) < s := by exact_mod_cast hs
  have htpos : (0 : ℝ) < t := by exact_mod_cast (hs.trans_le hst)
  have hst' : (s : ℝ) ≤ t := by exact_mod_cast hst
  have hcs : 0 < c * (s : ℝ) := mul_pos hc hspos
  let q : ℝ := (t : ℝ) / (c*s)
  let k : ℕ := ⌈q⌉₊
  have hqpos : 0 < q := div_pos htpos hcs
  have hqge : 1 ≤ q := by
    apply (le_div_iff₀ hcs).mpr
    nlinarith
  have hk : 1 ≤ k := Nat.one_le_ceil_iff.mpr hqpos
  have htk : (t : ℝ) ≤ k * (c*s) := by
    have h := mul_le_mul_of_nonneg_right (Nat.le_ceil q) hcs.le
    dsimp only [q] at h
    rw [div_mul_cancel₀ _ hcs.ne'] at h
    exact h
  have hkupper : (2*k : ℕ) ≤ 4*q := by
    have h := Nat.ceil_lt_add_one hqpos.le
    push_cast
    dsimp only [k]
    nlinarith
  have hfinite := P.repeated_growth_of_filled_proper X hX hcs.le hproper s t k hk htk z hfill
  have hreal : ((t • X).card : ℝ) ≤ ((2*k : ℕ) : ℝ) ^ Fintype.card ι * (s • X).card := by
    exact_mod_cast hfinite
  calc
    ((t • X).card : ℝ) ≤ ((2*k : ℕ) : ℝ) ^ Fintype.card ι * (s • X).card := hreal
    _ ≤ (4*q) ^ Fintype.card ι * (s • X).card := by gcongr
    _ = _ := by
      congr 1
      rw [← mul_pow]
      congr 1
      dsimp only [q]
      field_simp

/-- Fixed-factor growth (7) follows from the same filled proper dilate. -/
theorem repeated_growth_fixed_factor (P : CenteredProgression ι G) (X : Finset G)
    (hX : X ⊆ P.values 1) {c : ℝ} (hc : 0 < c) (hc1 : c ≤ 1)
    (s b : ℕ) (hs : 0 < s) (hb : 1 ≤ b)
    (hproper : P.Proper (c*s)) (z : G)
    (hfill : (P.values (c*s)).image (z + ·) ⊆ s • X) :
    (((b*s) • X).card : ℝ) ≤ ((4*b)/c) ^ Fintype.card ι * (s • X).card := by
  have h := P.repeated_growth_ratio X hX hc hc1 s (b*s) hs
    (by simpa using Nat.mul_le_mul_right s hb) hproper z hfill
  have hs0 : (s : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hs)
  simpa [Nat.cast_mul, hs0, ← mul_pow, mul_div_assoc, mul_comm, mul_left_comm] using h

end CenteredProgression

/-- Full generation and the origin exclude every proper coset after any
surjective group homomorphism. Applied to rectangular quotient lattices this
is exactly the reducedness hypothesis in the source of Lemma 2.D. -/
theorem subgroup_eq_top_of_generators_in_coset {G H : Type*}
    [AddCommGroup G] [AddCommGroup H] {A : Set G} (hzero : (0 : G) ∈ A)
    (hgen : AddSubgroup.closure A = ⊤) (f : G →+ H) (hf : Function.Surjective f)
    (L : AddSubgroup H) (z : H) (hcoset : ∀ a ∈ A, f a - z ∈ L) : L = ⊤ := by
  have hz : z ∈ L := by
    have h := hcoset 0 hzero
    simpa using L.neg_mem h
  have hA : A ⊆ L.comap f := by
    intro a ha
    change f a ∈ L
    simpa using L.add_mem (hcoset a ha) hz
  have htop : (⊤ : AddSubgroup G) ≤ L.comap f := by
    rw [← hgen]
    exact (AddSubgroup.closure_le (L.comap f)).mpr hA
  apply top_unique
  intro y _
  obtain ⟨x, rfl⟩ := hf y
  exact htop (by trivial)

end
end Optss
