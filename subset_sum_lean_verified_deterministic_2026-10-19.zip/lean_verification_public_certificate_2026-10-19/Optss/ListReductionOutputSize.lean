import Optss.BooleanLatticeFrontend

/-!
# Physical output size of list-stored rational reduction

The normalization at the last step cannot increase either magnitude list.
The already proved integer-output and denominator-product bounds therefore
control the physical output bits needed by subsequent boxing computations.
-/
namespace Optss
open scoped BigOperators
variable {r d : ℕ}

private theorem outputSize_get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i=f i := by
  change (Vector.ofFn f)[i.val]=f i
  simp

theorem listStoredRationalReduction_lengths (A : ListBitRationalMatrixData r d)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hind : LinearIndependent ℝ (fun i j => (storedRationalMatrix A i j:ℝ)))
    (L : ℕ) (hL : ∀ i j,(rectangularListFractionMatrix A i j).numerator.length≤L ∧
      (rectangularListFractionMatrix A i j).denominator.length≤L) (i : Fin r) (j : Fin d) :
    (rectangularListFractionMatrix (listStoredRationalReduction A).1 i j).numerator.length≤rationalOutputUnscaleBits r d L ∧
      (rectangularListFractionMatrix (listStoredRationalReduction A).1 i j).denominator.length≤rationalOutputUnscaleBits r d L := by
  have he := congrArg Prod.fst (listStoredRationalReduction_eq A)
  dsimp only at he
  rw [structuralEncodedRationalReduction_eq (ioMatrixVector A) hA hind] at he
  have hb := encodedRationalUnscale_operand_lengths (ioMatrixVector A) hA hind L hL
  let cleared := bitListClearRationalInput (ioMatrixVector A)
  let rows := (encodedIntegerReduction cleared.2).rows
  let z := (rows.get i).get j
  have hcell : rectangularListFractionMatrix (listStoredRationalReduction A).1 i j=
      bitListUnscaleInteger cleared.1 z := by
    change (((ioMatrixVector (listStoredRationalReduction A).1).get i).get j)=_
    rw [he]
    simp only [encodedRationalReduction,outputSize_get_ofFn]
    rfl
  rw [hcell]
  have h := bitListNormalizeFraction_lengths z.negative z.digits cleared.1
  exact ⟨h.1.trans (hb.2 i j),h.2.trans hb.1⟩

noncomputable def listReductionOutputSizePolynomial (r d : ℕ) : Polynomial ℕ :=
  Polynomial.C r+Polynomial.C (r*d)*(1+2*
    (Polynomial.C (r*(r+1)+1)*(Polynomial.C (r.size+d.size)+2*((Polynomial.C (r*d)+1)*Polynomial.X+2)+4)+
      Polynomial.C (r*d)*Polynomial.X+1))

theorem listStoredRationalReduction_bits (A : ListBitRationalMatrixData r d)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hind : LinearIndependent ℝ (fun i j => (storedRationalMatrix A i j:ℝ))) :
    listStoredRationalBits (listStoredRationalReduction A).1≤
      (listReductionOutputSizePolynomial r d).eval (listStoredRationalBits A) := by
  have h := listStoredRationalBits_le_of_lengths (listStoredRationalReduction A).1
    (rationalOutputUnscaleBits r d (listStoredRationalBits A))
    (listStoredRationalReduction_lengths A hA hind (listStoredRationalBits A) (listStoredRationalBits_cell A))
  simpa only [listReductionOutputSizePolynomial,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat,
    rationalOutputUnscaleBits] using h
end Optss
