import Optss.DyadicRadixDFT
import Optss.CyclicArrayTransform

/-! Three actual materialized integer FFTs and a pointwise product compute
an approximate cyclic convolution. A common scale is interpreted only in
the correctness statements. -/
namespace Optss

def fourierIntegerArrayValue (n : ℕ) (A : Vector FourierInteger (2^n))
    (x : ZMod (2^n)) : ℂ := fourierIntegerValue (A.get (cyclicArrayIndex n x))

theorem fourierIntegerArrayValue_data (n : ℕ) (A : Vector FourierInteger (2^n)) :
    cyclicVectorData n (fourierIntegerArrayValue n A)=fourierIntegerVectorValue A := by
  have h := cyclicVectorData_value n (fourierIntegerVectorValue A)
  convert h using 1
  congr 1
  funext x
  simp only [fourierIntegerArrayValue,cyclicArrayValue,fourierIntegerVectorValue,vector_get_ofFn]

theorem fixedPointCyclicTransform_decode (n : ℕ) (D : ℤ) (hD : D≠0)
    (T : ℕ → ℕ → FourierInteger) (A : Vector FourierInteger (2^n)) (x : ZMod (2^n)) :
    fourierIntegerArrayValue n (fixedPointRadixTwo D T n A) x/(D : ℂ)^n=
      cyclicArrayTransform n (fun l k => fourierIntegerValue (T l k)/(D : ℂ))
        (fourierIntegerArrayValue n A) x := by
  change fourierIntegerValue ((fixedPointRadixTwo D T n A).get (cyclicArrayIndex n x))/(D : ℂ)^n=
    (radixTwoTransform _ n (cyclicVectorData n (fourierIntegerArrayValue n A))).get (cyclicArrayIndex n x)
  rw [fourierIntegerArrayValue_data n A]
  exact fixedPointRadixTwo_decode D hD T n A (cyclicArrayIndex n x)

theorem fixedPointCyclicTransform_scaled_decode (n : ℕ) (D : ℤ) (hD : D≠0)
    (T : ℕ → ℕ → FourierInteger) (A : Vector FourierInteger (2^n)) (S : ℂ)
    (x : ZMod (2^n)) :
    fourierIntegerArrayValue n (fixedPointRadixTwo D T n A) x/((D : ℂ)^n*S)=
      cyclicArrayTransform n (fun l k => fourierIntegerValue (T l k)/(D : ℂ))
        (fun j => fourierIntegerArrayValue n A j/S) x := by
  have he : (fun j => fourierIntegerArrayValue n A j/S)=
      (fun j => S⁻¹*fourierIntegerArrayValue n A j) := by funext j; ring
  rw [he,cyclicArrayTransform_scale]
  change _=S⁻¹*cyclicArrayTransform n _ (fourierIntegerArrayValue n A) x
  rw [← fixedPointCyclicTransform_decode n D hD T A x]
  ring

def fixedPointCyclicConvolution (n : ℕ) (D : ℤ) (T : ℕ → ℕ → FourierInteger)
    (A B : Vector FourierInteger (2^n)) : Vector FourierInteger (2^n) :=
  let FA := fixedPointRadixTwo D T n A
  let FB := fixedPointRadixTwo D T n B
  let P := Vector.ofFn fun j => FA.get j*FB.get j
  let C := fixedPointRadixTwo D T n P
  Vector.ofFn fun j => C.get (cyclicArrayIndex n (-(j.val : ZMod (2^n))))

theorem fixedPointCyclicConvolution_decode (n : ℕ) (D : ℤ) (hD : D≠0)
    (T : ℕ → ℕ → FourierInteger) (A B : Vector FourierInteger (2^n)) (k : Fin (2^n)) :
    fourierIntegerValue ((fixedPointCyclicConvolution n D T A B).get k)/
      ((2^n : ℕ)*(D : ℂ)^(3*n))=
      cyclicArrayTransform n (fun l i => fourierIntegerValue (T l i)/(D : ℂ))
        (fun j =>
          cyclicArrayTransform n (fun l i => fourierIntegerValue (T l i)/(D : ℂ))
            (fourierIntegerArrayValue n A) j*
          cyclicArrayTransform n (fun l i => fourierIntegerValue (T l i)/(D : ℂ))
            (fourierIntegerArrayValue n B) j)
        (-(k.val : ZMod (2^n)))/(2^n : ℕ) := by
  let FA := fixedPointRadixTwo D T n A
  let FB := fixedPointRadixTwo D T n B
  let P := Vector.ofFn fun j => FA.get j*FB.get j
  let T' := fun l i => fourierIntegerValue (T l i)/(D : ℂ)
  have hp : (fun j => fourierIntegerArrayValue n P j/(D : ℂ)^(2*n))=
      (fun j => cyclicArrayTransform n T' (fourierIntegerArrayValue n A) j*
        cyclicArrayTransform n T' (fourierIntegerArrayValue n B) j) := by
    funext j
    dsimp only [P,fourierIntegerArrayValue]
    rw [vector_get_ofFn,fourierIntegerValue_mul]
    rw [show 2*n=n+n by omega,pow_add]
    rw [mul_div_mul_comm]
    exact congrArg₂ (·*·) (fixedPointCyclicTransform_decode n D hD T A j)
      (fixedPointCyclicTransform_decode n D hD T B j)
  have hc := fixedPointCyclicTransform_scaled_decode n D hD T P ((D : ℂ)^(2*n))
    (-(k.val : ZMod (2^n)))
  rw [← pow_add,show n+2*n=3*n by omega,hp] at hc
  dsimp only [fixedPointCyclicConvolution]
  rw [vector_get_ofFn]
  change fourierIntegerArrayValue n (fixedPointRadixTwo D T n P) (-(k.val : ZMod (2^n)))/
    ((2^n : ℕ)*(D : ℂ)^(3*n))=_
  rw [mul_comm (↑(2^n : ℕ) : ℂ) ((D : ℂ)^(3*n)),← div_div,hc]

theorem fixedPointCyclicConvolution_scaled_decode (n : ℕ) (D : ℤ) (hD : D≠0)
    (T : ℕ → ℕ → FourierInteger) (A B : Vector FourierInteger (2^n))
    (S : ℂ) (k : Fin (2^n)) :
    fourierIntegerValue ((fixedPointCyclicConvolution n D T A B).get k)/
      ((2^n : ℕ)*(D : ℂ)^(3*n)*S^2)=
      cyclicArrayTransform n (fun l i => fourierIntegerValue (T l i)/(D : ℂ))
        (fun j =>
          cyclicArrayTransform n (fun l i => fourierIntegerValue (T l i)/(D : ℂ))
            (fun x => fourierIntegerArrayValue n A x/S) j*
          cyclicArrayTransform n (fun l i => fourierIntegerValue (T l i)/(D : ℂ))
            (fun x => fourierIntegerArrayValue n B x/S) j)
        (-(k.val : ZMod (2^n)))/(2^n : ℕ) := by
  let T' := fun l i => fourierIntegerValue (T l i)/(D : ℂ)
  have hs (C : Vector FourierInteger (2^n)) :
      cyclicArrayTransform n T' (fun x => fourierIntegerArrayValue n C x/S)=
        fun x => S⁻¹*cyclicArrayTransform n T' (fourierIntegerArrayValue n C) x := by
    have hh : (fun x => fourierIntegerArrayValue n C x/S)=
        (fun x => S⁻¹*fourierIntegerArrayValue n C x) := by funext x; ring
    rw [hh,cyclicArrayTransform_scale]
  change _=cyclicArrayTransform n T' (fun j =>
    cyclicArrayTransform n T' (fun x => fourierIntegerArrayValue n A x/S) j*
    cyclicArrayTransform n T' (fun x => fourierIntegerArrayValue n B x/S) j) _/_
  rw [hs A,hs B]
  have hp : (fun j => (S⁻¹*cyclicArrayTransform n T' (fourierIntegerArrayValue n A) j)*
      (S⁻¹*cyclicArrayTransform n T' (fourierIntegerArrayValue n B) j))=
    (fun j => (S^2)⁻¹*(cyclicArrayTransform n T' (fourierIntegerArrayValue n A) j*
      cyclicArrayTransform n T' (fourierIntegerArrayValue n B) j)) := by funext j; ring
  rw [hp,cyclicArrayTransform_scale]
  change _=((S^2)⁻¹*cyclicArrayTransform n T' (fun j =>
    cyclicArrayTransform n T' (fourierIntegerArrayValue n A) j*
    cyclicArrayTransform n T' (fourierIntegerArrayValue n B) j) (-(k.val : ZMod (2^n))))/_
  have hd := fixedPointCyclicConvolution_decode n D hD T A B k
  change _=cyclicArrayTransform n T' _ _/_ at hd
  rw [← div_div,hd]
  ring

def dyadicCyclicConvolution (n p : ℕ) (A B : Vector FourierInteger (2^n)) :
    Vector FourierInteger (2^n) :=
  let T := dyadicCharacterTable n p
  fixedPointCyclicConvolution n (dyadicFourierDenominator p) (dyadicTwiddleFromTable n T) A B

theorem dyadicCyclicConvolution_error (n p : ℕ) (A B : Vector FourierInteger (2^n))
    (M : ℝ) (hM : 0≤M)
    (hA : ∀ j, ‖fourierIntegerValue (A.get j)‖≤M)
    (hB : ∀ j, ‖fourierIntegerValue (B.get j)‖≤M) (k : Fin (2^n)) :
    let E := (n : ℝ)*3^n*(1/2 : ℝ)^p
    ‖fourierIntegerValue ((dyadicCyclicConvolution n p A B).get k)/
      ((2^n : ℕ)*(dyadicFourierDenominator p : ℂ)^(3*n))-
      cyclicConvolution (fourierIntegerArrayValue n A) (fourierIntegerArrayValue n B)
        (k.val : ZMod (2^n))‖≤
      E*(2*(2^n : ℕ)+E)*M^2+(E/(2^n : ℕ))*((2^n : ℕ)+E)^2*M^2 := by
  dsimp only
  have hd := fixedPointCyclicConvolution_decode n (dyadicFourierDenominator p)
    (by exact_mod_cast (dyadicFourierDenominator_pos p).ne')
    (dyadicTwiddleFromTable n (dyadicCharacterTable n p)) A B k
  simp only [Int.cast_natCast] at hd
  change ‖fourierIntegerValue ((fixedPointCyclicConvolution n (dyadicFourierDenominator p)
    (dyadicTwiddleFromTable n (dyadicCharacterTable n p)) A B).get k)/_-_‖≤_
  rw [hd]
  apply approximate_cyclic_convolution _ _ M (by positivity) hM
  · intro f R hR hf x
    exact cyclicArrayTransform_error n _ ((1/2 : ℝ)^p) (by positivity)
      (pow_le_one₀ (by norm_num) (by norm_num))
      (fun l _ i => dyadicTwiddleFromTable_error n p l i) f R hR hf x
  · intro j
    exact hA (cyclicArrayIndex n j)
  · intro j
    exact hB (cyclicArrayIndex n j)

theorem dyadicCyclicConvolution_scaled_error (n p : ℕ) (A B : Vector FourierInteger (2^n))
    (S : ℂ) (M : ℝ) (hM : 0≤M)
    (hA : ∀ j, ‖fourierIntegerValue (A.get j)/S‖≤M)
    (hB : ∀ j, ‖fourierIntegerValue (B.get j)/S‖≤M) (k : Fin (2^n)) :
    let E := (n : ℝ)*3^n*(1/2 : ℝ)^p
    ‖fourierIntegerValue ((dyadicCyclicConvolution n p A B).get k)/
      ((2^n : ℕ)*(dyadicFourierDenominator p : ℂ)^(3*n)*S^2)-
      cyclicConvolution (fun x => fourierIntegerArrayValue n A x/S)
        (fun x => fourierIntegerArrayValue n B x/S) (k.val : ZMod (2^n))‖≤
      E*(2*(2^n : ℕ)+E)*M^2+(E/(2^n : ℕ))*((2^n : ℕ)+E)^2*M^2 := by
  dsimp only
  have hd := fixedPointCyclicConvolution_scaled_decode n (dyadicFourierDenominator p)
    (by exact_mod_cast (dyadicFourierDenominator_pos p).ne')
    (dyadicTwiddleFromTable n (dyadicCharacterTable n p)) A B S k
  simp only [Int.cast_natCast] at hd
  change ‖fourierIntegerValue ((fixedPointCyclicConvolution n (dyadicFourierDenominator p)
    (dyadicTwiddleFromTable n (dyadicCharacterTable n p)) A B).get k)/_-_‖≤_
  rw [hd]
  apply approximate_cyclic_convolution _ _ M (by positivity) hM
  · intro f R hR hf x
    exact cyclicArrayTransform_error n _ ((1/2 : ℝ)^p) (by positivity)
      (pow_le_one₀ (by norm_num) (by norm_num))
      (fun l _ i => dyadicTwiddleFromTable_error n p l i) f R hR hf x
  · intro j
    exact hA (cyclicArrayIndex n j)
  · intro j
    exact hB (cyclicArrayIndex n j)

end Optss
