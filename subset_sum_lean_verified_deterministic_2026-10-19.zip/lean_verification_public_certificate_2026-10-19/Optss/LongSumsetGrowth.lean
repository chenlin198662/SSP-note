import Optss.LongSumsetExistence

/-!
# Unconditional polynomial-scale growth of repeated sumsets

Equations (7) and (8) now follow from the proved existence theorem. The
constants depend only on the exponent, with no progression, growth profile,
or lower bound on the input cardinality among the hypotheses.
-/
namespace Optss
noncomputable section
open scoped Pointwise Classical
local instance longSumsetGrowthDecEqInt : DecidableEq ℤ := Classical.decEq _

/-- Uniform upper growth comparison, the rearranged form of (8). -/
theorem long_sumset_growth_ratio (α : ℝ) (hα : 0 < α) :
    ∃ R N₀ : ℕ, ∃ C : ℝ, 1 ≤ C ∧ ∀ (N s t : ℕ) (X : Finset ℤ),
      N₀ ≤ N → X ⊆ Finset.Icc 0 (N : ℤ) → 0 ∈ X → (N : ℝ)^α ≤ s → s ≤ t →
      ((t • X).card : ℝ) ≤ C*((t : ℝ)/s)^R*(s • X).card := by
  obtain ⟨R, N₀, c₀, hc₀, hex⟩ := theorem2A_long_sumsets α hα
  let c := min c₀ 1
  have hc : 0 < c := lt_min hc₀ zero_lt_one
  have hc1 : c ≤ 1 := min_le_right _ _
  have hbase : 1 ≤ 4/c := by apply (le_div_iff₀ hc).mpr; linarith
  refine ⟨R, max 2 N₀, (4/c)^R, one_le_pow₀ hbase, ?_⟩
  intro N s t X hN hX hzero hscale hst
  have hNpos : (0 : ℝ) < N := by exact_mod_cast (show 0 < N by omega)
  have hspos : (0 : ℝ) < s := (Real.rpow_pos_of_pos hNpos α).trans_le hscale
  have hs : 0 < s := by exact_mod_cast hspos
  obtain ⟨d, hd, P, hcont, hproper, z, hfill⟩ := hex N s X (by omega) hX hzero hscale
  have hcs : c*(s : ℝ) ≤ c₀*s := mul_le_mul_of_nonneg_right (min_le_left _ _) (Nat.cast_nonneg _)
  have hout := P.repeated_growth_ratio X hcont hc hc1 s t hs hst (hproper.mono hcs) z
    ((Finset.image_subset_image (P.values_mono hcs)).trans hfill)
  have hratio : 1 ≤ (t : ℝ)/s := (le_div_iff₀ hspos).mpr (by simpa only [one_mul] using (show (s : ℝ) ≤ t by exact_mod_cast hst))
  simp only [Fintype.card_fin] at hout
  exact hout.trans (mul_le_mul_of_nonneg_right
    (mul_le_mul (pow_le_pow_right₀ hbase hd) (pow_le_pow_right₀ hratio hd)
      (by positivity) (by positivity)) (Nat.cast_nonneg _))

/-- Equation (7), simultaneously for every integral fixed factor `b≥1`. -/
theorem long_sumset_growth_fixed_factor (α : ℝ) (hα : 0 < α) :
    ∃ R N₀ : ℕ, ∃ C : ℝ, 1 ≤ C ∧ ∀ (N s b : ℕ) (X : Finset ℤ),
      N₀ ≤ N → X ⊆ Finset.Icc 0 (N : ℤ) → 0 ∈ X → (N : ℝ)^α ≤ s → 1 ≤ b →
      (((b*s) • X).card : ℝ) ≤ C*(b : ℝ)^R*(s • X).card := by
  obtain ⟨R, N₀, C, hC, hratio⟩ := long_sumset_growth_ratio α hα
  refine ⟨R, max 2 N₀, C, hC, ?_⟩
  intro N s b X hN hX hzero hscale hb
  have hNpos : (0 : ℝ) < N := by exact_mod_cast (show 0 < N by omega)
  have hspos : (0 : ℝ) < s := (Real.rpow_pos_of_pos hNpos α).trans_le hscale
  have hout := hratio N s (b*s) X (by omega) hX hzero hscale
    (by simpa using Nat.mul_le_mul_right s hb)
  simpa only [Nat.cast_mul, mul_div_cancel_right₀ _ hspos.ne'] using hout

/-- Equation (8) in its stated lower-growth form. -/
theorem long_sumset_growth_lower (α : ℝ) (hα : 0 < α) :
    ∃ R N₀ : ℕ, ∃ c : ℝ, 0 < c ∧ ∀ (N s t : ℕ) (X : Finset ℤ),
      N₀ ≤ N → X ⊆ Finset.Icc 0 (N : ℤ) → 0 ∈ X → (N : ℝ)^α ≤ s → s ≤ t →
      c*((s : ℝ)/t)^R*(t • X).card ≤ (s • X).card := by
  obtain ⟨R, N₀, C, hC, hratio⟩ := long_sumset_growth_ratio α hα
  have hCpos : 0 < C := zero_lt_one.trans_le hC
  refine ⟨R, max 2 N₀, C⁻¹, inv_pos.mpr hCpos, ?_⟩
  intro N s t X hN hX hzero hscale hst
  have hNpos : (0 : ℝ) < N := by exact_mod_cast (show 0 < N by omega)
  have hspos : (0 : ℝ) < s := (Real.rpow_pos_of_pos hNpos α).trans_le hscale
  have htpos : (0 : ℝ) < t := hspos.trans_le (by exact_mod_cast hst)
  have hout := hratio N s t X (by omega) hX hzero hscale hst
  have hmul := mul_le_mul_of_nonneg_left hout
    (show 0 ≤ C⁻¹*((s : ℝ)/t)^R by positivity)
  have he : C⁻¹*((s : ℝ)/t)^R*(C*((t : ℝ)/s)^R*(s • X).card) = (s • X).card := by
    rw [div_pow, div_pow]
    field_simp
    <;> ring
  exact hmul.trans_eq he

end
end Optss
