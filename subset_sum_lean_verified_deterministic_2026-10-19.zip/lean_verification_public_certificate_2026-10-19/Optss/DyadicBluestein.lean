import Optss.FixedPointConvolution
import Optss.BluesteinIdentity

/-! Actual integer chirp arrays and an arbitrary-length Boolean-input DFT.
The input is a materialized Boolean array, so reading membership does not
hide a repeated finite-set search. -/
namespace Optss

def fourierIntegerZero : FourierInteger := ⟨0,0⟩

theorem fourierIntegerZero_value : fourierIntegerValue fourierIntegerZero=0 := by
  simp [fourierIntegerValue,fourierIntegerZero]

def cyclicBooleanInput (N : ℕ) [NeZero N] (f : Vector Bool N) (x : ZMod N) : ℂ :=
  if f.get ⟨x.val,x.val_lt⟩ then 1 else 0

theorem cyclicBooleanInput_norm (N : ℕ) [NeZero N] (f : Vector Bool N) (x : ZMod N) :
    ‖cyclicBooleanInput N f x‖≤1 := by
  unfold cyclicBooleanInput
  split_ifs <;> simp

def dyadicBluesteinInput (N n p : ℕ) [NeZero N] (f : Vector Bool N)
    (x : ZMod (2^n)) : FourierInteger :=
  if h : x.val<N then
    if f.get ⟨x.val,h⟩ then dyadicCharacterInteger ((-(x.val : ℤ)^2 : ℤ) : ZMod (2*N)) p
    else fourierIntegerZero
  else fourierIntegerZero

def dyadicBluesteinKernel (N n p : ℕ) [NeZero N] (x : ZMod (2^n)) : FourierInteger :=
  if x.val<2*N-1 then dyadicCharacterInteger ((((x.val : ℤ)-(N : ℤ)+1)^2 : ℤ) : ZMod (2*N)) p
  else fourierIntegerZero

theorem dyadicBluesteinInput_error (N n p : ℕ) [NeZero N] (f : Vector Bool N)
    (x : ZMod (2^n)) :
    ‖fourierIntegerValue (dyadicBluesteinInput N n p f x)/(dyadicFourierDenominator p : ℂ)-
      bluesteinPaddedInput N (2^n) (cyclicBooleanInput N f) x‖≤(1/2 : ℝ)^p := by
  by_cases hx : x.val<N
  · simp only [dyadicBluesteinInput,dif_pos hx,bluesteinPaddedInput,if_pos hx,cyclicBooleanInput,
      ZMod.val_natCast,Nat.mod_eq_of_lt hx]
    split_ifs with hf
    · simpa only [one_mul] using dyadicCharacterInteger_error
        (((-(x.val : ℤ)^2 : ℤ) : ZMod (2*N))) p
    · simp only [fourierIntegerZero_value,zero_div,zero_mul,sub_self,norm_zero]
      positivity
  · simp only [dyadicBluesteinInput,dif_neg hx,bluesteinPaddedInput,if_neg hx,
      fourierIntegerZero_value,zero_div,sub_self,norm_zero]
    positivity

theorem dyadicBluesteinKernel_error (N n p : ℕ) [NeZero N] (x : ZMod (2^n)) :
    ‖fourierIntegerValue (dyadicBluesteinKernel N n p x)/(dyadicFourierDenominator p : ℂ)-
      bluesteinPaddedKernel N (2^n) x‖≤(1/2 : ℝ)^p := by
  unfold dyadicBluesteinKernel bluesteinPaddedKernel
  split_ifs
  · exact dyadicCharacterInteger_error _ p
  · simp only [fourierIntegerZero_value,zero_div,sub_self,norm_zero]
    positivity

theorem dyadicBluesteinInput_norm (N n p : ℕ) [NeZero N] (f : Vector Bool N)
    (x : ZMod (2^n)) :
    ‖fourierIntegerValue (dyadicBluesteinInput N n p f x)/(dyadicFourierDenominator p : ℂ)‖≤2 := by
  have he := dyadicBluesteinInput_error N n p f x
  have hb := bluesteinPaddedInput_norm N (2^n) (cyclicBooleanInput N f) 1 (by norm_num)
    (cyclicBooleanInput_norm N f) x
  have hp : (1/2 : ℝ)^p≤1 := pow_le_one₀ (by norm_num) (by norm_num)
  have ht := norm_sub_norm_le
    (fourierIntegerValue (dyadicBluesteinInput N n p f x)/(dyadicFourierDenominator p : ℂ))
    (bluesteinPaddedInput N (2^n) (cyclicBooleanInput N f) x)
  linarith

theorem dyadicBluesteinKernel_norm (N n p : ℕ) [NeZero N] (x : ZMod (2^n)) :
    ‖fourierIntegerValue (dyadicBluesteinKernel N n p x)/(dyadicFourierDenominator p : ℂ)‖≤2 := by
  have he := dyadicBluesteinKernel_error N n p x
  have hb := bluesteinPaddedKernel_norm N (2^n) x
  have hp : (1/2 : ℝ)^p≤1 := pow_le_one₀ (by norm_num) (by norm_num)
  have ht := norm_sub_norm_le
    (fourierIntegerValue (dyadicBluesteinKernel N n p x)/(dyadicFourierDenominator p : ℂ))
    (bluesteinPaddedKernel N (2^n) x)
  linarith

/-- The output chirp and the three Fourier transforms all share denominator
2^(p+2). The answer contains integers only. -/
def dyadicBluesteinDFT (N n p : ℕ) [NeZero N] (f : Vector Bool N) : Vector FourierInteger N :=
  let A := cyclicVectorData n (dyadicBluesteinInput N n p f)
  let B := cyclicVectorData n (dyadicBluesteinKernel N n p)
  let C := dyadicCyclicConvolution n p A B
  Vector.ofFn fun k => dyadicCharacterInteger ((-(k.val : ℤ)^2 : ℤ) : ZMod (2*N)) p*
    C.get (cyclicArrayIndex n ((k.val+N-1 : ℕ) : ZMod (2^n)))

noncomputable def dyadicConvolutionError (n p : ℕ) : ℝ :=
  let E := (n : ℝ)*3^n*(1/2 : ℝ)^p
  E*(2*(2^n : ℕ)+E)*4+(E/(2^n : ℕ))*((2^n : ℕ)+E)^2*4

theorem dyadicBluestein_convolution_error (N n p : ℕ) [NeZero N] (f : Vector Bool N)
    (k : Fin (2^n)) :
    ‖fourierIntegerValue ((dyadicCyclicConvolution n p
      (cyclicVectorData n (dyadicBluesteinInput N n p f))
      (cyclicVectorData n (dyadicBluesteinKernel N n p))).get k)/
        ((2^n : ℕ)*(dyadicFourierDenominator p : ℂ)^(3*n)*(dyadicFourierDenominator p : ℂ)^2)-
      cyclicConvolution (bluesteinPaddedInput N (2^n) (cyclicBooleanInput N f))
        (bluesteinPaddedKernel N (2^n)) (k.val : ZMod (2^n))‖≤
      dyadicConvolutionError n p+3*(2^n : ℕ)*(1/2 : ℝ)^p := by
  let a := fun x => fourierIntegerValue (dyadicBluesteinInput N n p f x)/(dyadicFourierDenominator p : ℂ)
  let b := fun x => fourierIntegerValue (dyadicBluesteinKernel N n p x)/(dyadicFourierDenominator p : ℂ)
  have hfft := dyadicCyclicConvolution_scaled_error n p
    (cyclicVectorData n (dyadicBluesteinInput N n p f))
    (cyclicVectorData n (dyadicBluesteinKernel N n p))
    (dyadicFourierDenominator p : ℂ) 2 (by norm_num)
    (fun j => by simpa only [cyclicVectorData,vector_get_ofFn] using
      dyadicBluesteinInput_norm N n p f (j.val : ZMod (2^n)))
    (fun j => by simpa only [cyclicVectorData,vector_get_ofFn] using
      dyadicBluesteinKernel_norm N n p (j.val : ZMod (2^n))) k
  have ha : (fun x => fourierIntegerArrayValue n (cyclicVectorData n (dyadicBluesteinInput N n p f)) x/
      (dyadicFourierDenominator p : ℂ))=a := by
    funext x
    simp only [fourierIntegerArrayValue,cyclicVectorData,vector_get_ofFn,cyclicArrayIndex,
      ZMod.natCast_zmod_val,a]
  have hb : (fun x => fourierIntegerArrayValue n (cyclicVectorData n (dyadicBluesteinKernel N n p)) x/
      (dyadicFourierDenominator p : ℂ))=b := by
    funext x
    simp only [fourierIntegerArrayValue,cyclicVectorData,vector_get_ofFn,cyclicArrayIndex,
      ZMod.natCast_zmod_val,b]
  dsimp only at hfft
  rw [ha,hb] at hfft
  have herr := cyclicConvolution_distance_le a
    (bluesteinPaddedInput N (2^n) (cyclicBooleanInput N f)) b (bluesteinPaddedKernel N (2^n))
    1 2 ((1/2 : ℝ)^p) ((1/2 : ℝ)^p) (by norm_num) (by positivity)
    (bluesteinPaddedInput_norm N (2^n) (cyclicBooleanInput N f) 1 (by norm_num) (cyclicBooleanInput_norm N f))
    (dyadicBluesteinKernel_norm N n p) (dyadicBluesteinInput_error N n p f)
    (dyadicBluesteinKernel_error N n p) (k.val : ZMod (2^n))
  have htri := norm_sub_le_norm_sub_add_norm_sub
    (fourierIntegerValue ((dyadicCyclicConvolution n p
      (cyclicVectorData n (dyadicBluesteinInput N n p f))
      (cyclicVectorData n (dyadicBluesteinKernel N n p))).get k)/
        ((2^n : ℕ)*(dyadicFourierDenominator p : ℂ)^(3*n)*(dyadicFourierDenominator p : ℂ)^2))
    (cyclicConvolution a b (k.val : ZMod (2^n)))
    (cyclicConvolution (bluesteinPaddedInput N (2^n) (cyclicBooleanInput N f))
      (bluesteinPaddedKernel N (2^n)) (k.val : ZMod (2^n)))
  unfold dyadicConvolutionError
  dsimp only
  norm_num only [show (2 : ℝ)^2=4 by norm_num] at hfft
  linarith

/-- Fully constructed arbitrary-length DFT accuracy. The sole input
hypothesis is the explicit padding length, discharged by
`bluesteinPadExponent_bounds` for the canonical constructor. -/
theorem dyadicBluesteinDFT_error (N n p : ℕ) [NeZero N]
    (hpad : 3*N-2≤2^n) (f : Vector Bool N) (k : Fin N) :
    ‖fourierIntegerValue ((dyadicBluesteinDFT N n p f).get k)/
      ((2^n : ℕ)*(dyadicFourierDenominator p : ℂ)^(3*n+3))-
      ZMod.dft (cyclicBooleanInput N f) (k.val : ZMod N)‖≤
      2*dyadicConvolutionError n p+7*(2^n : ℕ)*(1/2 : ℝ)^p := by
  let C := dyadicCyclicConvolution n p
    (cyclicVectorData n (dyadicBluesteinInput N n p f))
    (cyclicVectorData n (dyadicBluesteinKernel N n p))
  let x : ZMod (2^n) := ((k.val+N-1 : ℕ) : ZMod (2^n))
  let c : ℂ := fourierIntegerValue (C.get (cyclicArrayIndex n x))/
    ((2^n : ℕ)*(dyadicFourierDenominator p : ℂ)^(3*n)*(dyadicFourierDenominator p : ℂ)^2)
  let C₀ := cyclicConvolution (bluesteinPaddedInput N (2^n) (cyclicBooleanInput N f))
    (bluesteinPaddedKernel N (2^n)) x
  let z : ZMod (2*N) := ((-(k.val : ℤ)^2 : ℤ) : ZMod (2*N))
  let a : ℂ := fourierIntegerValue (dyadicCharacterInteger z p)/(dyadicFourierDenominator p : ℂ)
  have hc : ‖c-C₀‖≤dyadicConvolutionError n p+3*(2^n : ℕ)*(1/2 : ℝ)^p := by
    have h := dyadicBluestein_convolution_error N n p f (cyclicArrayIndex n x)
    simpa only [cyclicArrayIndex,ZMod.natCast_zmod_val] using h
  have ha : ‖a-ZMod.stdAddChar z‖≤(1/2 : ℝ)^p := dyadicCharacterInteger_error z p
  have haNorm : ‖a‖≤2 := by
    have h := norm_sub_norm_le a (ZMod.stdAddChar z)
    rw [AddChar.norm_apply] at h
    have hp : (1/2 : ℝ)^p≤1 := pow_le_one₀ (by norm_num) (by norm_num)
    linarith
  have hC₀ : ‖C₀‖≤(2^n : ℕ) := by
    have h := cyclicConvolution_norm_le
      (bluesteinPaddedInput N (2^n) (cyclicBooleanInput N f)) (bluesteinPaddedKernel N (2^n))
      1 1 (by norm_num)
      (bluesteinPaddedInput_norm N (2^n) (cyclicBooleanInput N f) 1 (by norm_num) (cyclicBooleanInput_norm N f))
      (bluesteinPaddedKernel_norm N (2^n)) x
    simpa only [mul_one] using h
  have hdecode : fourierIntegerValue ((dyadicBluesteinDFT N n p f).get k)/
      ((2^n : ℕ)*(dyadicFourierDenominator p : ℂ)^(3*n+3))=a*c := by
    have hpow : ((2^n : ℕ) : ℂ)*(dyadicFourierDenominator p : ℂ)^(3*n+3)=
        (dyadicFourierDenominator p : ℂ)*
        (((2^n : ℕ) : ℂ)*(dyadicFourierDenominator p : ℂ)^(3*n)*(dyadicFourierDenominator p : ℂ)^2) := by
      rw [pow_add (dyadicFourierDenominator p : ℂ) (3*n) 3]
      ring
    dsimp only [dyadicBluesteinDFT,a,c,C,x,z]
    rw [vector_get_ofFn,fourierIntegerValue_mul,hpow,mul_div_mul_comm]
  rw [hdecode,bluestein_dft N (2^n) hpad]
  change ‖a*c-ZMod.stdAddChar z*C₀‖≤_
  have herr := complex_product_error c C₀ a (ZMod.stdAddChar z)
  rw [mul_comm c a,mul_comm C₀ (ZMod.stdAddChar z)] at herr
  calc
    _ ≤ ‖c-C₀‖*‖a‖+‖C₀‖*‖a-ZMod.stdAddChar z‖ := herr
    _ ≤ (dyadicConvolutionError n p+3*(2^n : ℕ)*(1/2 : ℝ)^p)*2+
        (2^n : ℕ)*(1/2 : ℝ)^p := by
      exact add_le_add
        (mul_le_mul hc haNorm (norm_nonneg _) ((norm_nonneg _).trans hc))
        (mul_le_mul hC₀ ha (norm_nonneg _) (by positivity))
    _ = _ := by ring

def canonicalDyadicDFT (N p : ℕ) [NeZero N] (f : Vector Bool N) : Vector FourierInteger N :=
  dyadicBluesteinDFT N (bluesteinPadExponent N) p f

theorem canonicalDyadicDFT_error (N p : ℕ) [NeZero N] (f : Vector Bool N) (k : Fin N) :
    let n := bluesteinPadExponent N
    ‖fourierIntegerValue ((canonicalDyadicDFT N p f).get k)/
      ((2^n : ℕ)*(dyadicFourierDenominator p : ℂ)^(3*n+3))-
      ZMod.dft (cyclicBooleanInput N f) (k.val : ZMod N)‖≤
      2*dyadicConvolutionError n p+7*(2^n : ℕ)*(1/2 : ℝ)^p :=
  dyadicBluesteinDFT_error N _ p (bluesteinPadExponent_bounds N).1 f k

end Optss
