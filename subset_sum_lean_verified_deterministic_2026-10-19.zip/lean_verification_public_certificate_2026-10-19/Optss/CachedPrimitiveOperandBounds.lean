import Optss.BinaryCachedArithmeticWork

/-!
# Operands for rounding, integer updates and comparisons

The bounds here close the operand side of the remaining scalar primitives.
They are derived from the actual independent integer matrix and include the
rounded coefficient, both integer row cells, and the two final Lovász sides.
-/

namespace Optss
open scoped BigOperators
variable {r d : ℕ}

/-- Exact nearest-integer rounding has magnitude at most twice the reduced
numerator magnitude. This holds for negative values and for zero. -/
theorem rational_round_natAbs_le_twice_num (q : ℚ) :
    (round q).natAbs ≤ 2*q.num.natAbs := by
  have hd : (1:ℚ) ≤ q.den := by exact_mod_cast q.den_pos
  have hn : |q| ≤ (q.num.natAbs:ℚ) := by
    calc
      |q| = |(q.num:ℚ)|/(q.den:ℚ) := by
        conv_lhs => rw [← q.num_div_den]
        rw [abs_div, abs_of_nonneg (by positivity : (0:ℚ) ≤ q.den)]
      _ ≤ |(q.num:ℚ)| := div_le_self (abs_nonneg _) hd
      _ = _ := by rw [Nat.cast_natAbs, Int.cast_abs]
  have hr := round_le q 0
  simp only [Int.cast_zero, sub_zero] at hr
  have ht := abs_sub_le (round q:ℚ) q 0
  rw [sub_zero, sub_zero, abs_sub_comm] at ht
  have hb : ((round q).natAbs:ℚ) ≤ 2*(q.num.natAbs:ℚ) := by
    rw [Nat.cast_natAbs, Int.cast_abs]
    linarith
  exact_mod_cast hb

/-- The actual rational coefficient is an admissible rounding operand. -/
theorem cached_coefficient_operand_bits (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k j : Fin r) :
    RationalBitBound (rationalGsCoefficient (rationalIntegerRows A) k j)
      (cachedArithmeticBits r d H (gramPotential A)) := by
  let K := gsArithmeticBase d H (gramPotential A)
  have hK : 4 ≤ K := by unfold K gsArithmeticBase; omega
  exact cachedOperandMagnitude_to_bits r d K hK
    ((rationalGsCoefficient_size A hA H hH k j).mono
      (cachedOperandMagnitude_ge_pow r d K 4 (by omega) (by omega)))

/-- Rounding the actual coefficient preserves the common operand-bit bound. -/
theorem cached_rounded_coefficient_bits (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k j : Fin r) :
    (round (rationalGsCoefficient (rationalIntegerRows A) k j)).natAbs.size ≤
      cachedArithmeticBits r d H (gramPotential A) := by
  let K := gsArithmeticBase d H (gramPotential A)
  have hK : 4 ≤ K := by unfold K gsArithmeticBase; omega
  have hc := (rationalGsCoefficient_size A hA H hH k j).1
  have hr := rational_round_natAbs_le_twice_num (rationalGsCoefficient (rationalIntegerRows A) k j)
  have hpow : 2*K^4 ≤ K^6 := by
    have htwo : 2 ≤ K^2 := by nlinarith
    calc
      _ ≤ K^2*K^4 := Nat.mul_le_mul_right _ htwo
      _ = _ := by ring
  have hb : (round (rationalGsCoefficient (rationalIntegerRows A) k j)).natAbs ≤
      cachedOperandMagnitude r d K :=
    (hr.trans (Nat.mul_le_mul_left 2 hc)).trans
      (hpow.trans (cachedOperandMagnitude_ge_pow r d K 6 (by omega) le_rfl))
  exact (Nat.size_le_size hb).trans (cachedOperandMagnitude_bits r d K hK)

/-- Both integer operands read from the materialized row array have bounded
magnitude bits, including before that row has been fully size reduced. -/
theorem cached_integer_cell_operand_bits (A : Matrix (Fin r) (Fin d) ℤ)
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (i : Fin r) (j : Fin d) :
    (A i j).natAbs.size ≤ cachedArithmeticBits r d H (gramPotential A) := by
  let K := gsArithmeticBase d H (gramPotential A)
  have hK : 4 ≤ K := by unfold K gsArithmeticBase; omega
  have habs : ((A i j).natAbs:ℤ) ≤ (H:ℤ) := by
    simpa only [Int.natCast_natAbs] using hH i j
  have hh : (A i j).natAbs ≤ H := by exact_mod_cast habs
  have hk : H ≤ K := by unfold K gsArithmeticBase; omega
  have hb : (A i j).natAbs ≤ cachedOperandMagnitude r d K :=
    (hh.trans hk).trans (by simpa only [pow_one] using
      cachedOperandMagnitude_ge_pow r d K 1 (by omega) (by omega))
  exact (Nat.size_le_size hb).trans (cachedOperandMagnitude_bits r d K hK)

/-- The two fully constructed rational operands of the final Lovász
comparison satisfy the same common bound as its arithmetic operations. -/
theorem cached_lovasz_comparison_operand_bits (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (j k : Fin r) :
    let Q := rationalIntegerRows A
    let u := rationalGsCoefficient Q k j
    let x := rationalDot (rationalGramSchmidt Q k) (rationalGramSchmidt Q k)
    let y := rationalDot (rationalGramSchmidt Q j) (rationalGramSchmidt Q j)
    RationalBitBound (4*(x+u*u*y)) (cachedArithmeticBits r d H (gramPotential A)) ∧
      RationalBitBound (3*y) (cachedArithmeticBits r d H (gramPotential A)) := by
  let K := gsArithmeticBase d H (gramPotential A)
  have hK : 4 ≤ K := by unfold K gsArithmeticBase; omega
  obtain ⟨_,_,_,hl,hr⟩ := rationalLovasz_intermediate_sizes A hA H hH j k
  have hm := cachedOperandMagnitude_ge_lovasz r d K (by omega)
  exact ⟨cachedOperandMagnitude_to_bits r d K hK (hl.mono hm),
    cachedOperandMagnitude_to_bits r d K hK (hr.mono hm)⟩

end Optss
