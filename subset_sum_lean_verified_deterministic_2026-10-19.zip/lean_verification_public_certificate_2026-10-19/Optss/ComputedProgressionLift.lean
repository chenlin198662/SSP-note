import Optss.ComputedModelInverseTable
import Optss.FreimanGridLift
import Optss.BooleanListArray

/-!
# Lifting progression generators through the actual inverse table

Only active coordinate generators are looked up. They are materialized once
as a fixed-length list. Zero-width coordinates receive zero. The resulting
integer homomorphism agrees on the entire coefficient box with the proved
Freiman inverse, hence preserves both properness and cardinality.
-/
namespace Optss
open scoped BigOperators Pointwise
variable {r p : ℕ}

def computedInverseValue (table : Array (Option ℤ)) (x : ZMod p) : ℤ :=
  ((table[x.val]?).getD none).getD 0

def computedLiftGeneratorData (table : Array (Option ℤ)) (ρ : IntVec r→+ZMod p)
    (β : Fin r→ℕ) : BooleanListArray ℤ r :=
  BooleanListArray.ofFn fun j => if β j=0 then 0 else computedInverseValue table (ρ (Pi.single j 1))

def computedLiftHom (table : Array (Option ℤ)) (ρ : IntVec r→+ZMod p)
    (β : Fin r→ℕ) : IntVec r→+ℤ :=
  let generators := computedLiftGeneratorData table ρ β
  gridLinearPart generators.toVector.get

theorem computedLiftGeneratorData_get (table : Array (Option ℤ)) (ρ : IntVec r→+ZMod p)
    (β : Fin r→ℕ) (j : Fin r) :
    (computedLiftGeneratorData table ρ β).toVector.get j=
      if β j=0 then 0 else computedInverseValue table (ρ (Pi.single j 1)) := by
  simp [computedLiftGeneratorData,BooleanListArray.ofFn,BooleanListArray.toVector,Vector.get]

theorem unit_mem_integerBudgetBox (β : Fin r→ℕ) (j : Fin r) (hj : 0<β j) :
    Pi.single j (1:ℤ)∈integerBudgetBox β := by
  rw [mem_integerBudgetBox]
  intro i
  by_cases hi : i=j
  · subst i
    simpa only [Pi.single_eq_same,abs_one] using (show (1:ℤ)≤β j by exact_mod_cast hj)
  · simp [Pi.single_apply,hi,Ne.symm hi]

theorem integerHom_coordinate_sum (F : IntVec r→+ℤ) (z : IntVec r) :
    F z=∑ j,z j*F (Pi.single j 1) := by
  have hz : z=∑ j,z j • (Pi.single j (1:ℤ):IntVec r) := by
    ext i
    simp [Finset.sum_apply,Pi.smul_apply,Pi.single_apply]
  conv_lhs => rw [hz,map_sum]
  apply Finset.sum_congr rfl
  intro j _
  simpa only [zsmul_eq_mul,Int.cast_id] using (map_zsmul F (z j) (Pi.single j 1))

theorem computedLiftHom_eq_on_box (table : Array (Option ℤ)) (ρ : IntVec r→+ZMod p)
    (β : Fin r→ℕ) (F : IntVec r→+ℤ)
    (hlookup : ∀ j,0<β j → computedInverseValue table (ρ (Pi.single j 1))=F (Pi.single j 1))
    (z : IntVec r) (hz : z∈integerBudgetBox β) : computedLiftHom table ρ β z=F z := by
  rw [integerHom_coordinate_sum F z]
  change (∑ j,z j • ((computedLiftGeneratorData table ρ β).toVector.get j))=_
  apply Finset.sum_congr rfl
  intro j _
  rw [computedLiftGeneratorData_get]
  by_cases hj : β j=0
  · have hzj := (mem_integerBudgetBox β z).mp hz j
    dsimp only at hzj
    rw [hj] at hzj
    have hzero : z j=0 := by simpa using hzj
    simp [hj,hzero]
  · simp only [hj,↓reduceIte,zsmul_eq_mul,Int.cast_id,hlookup j (Nat.pos_of_ne_zero hj)]

theorem computedLiftHom_spec (A : Finset ℤ) (hA : A.Nonempty) (f : ℤ→ZMod p)
    (hf : FreimanEight A f) (ρ : IntVec r→+ZMod p) (β : Fin r→ℕ)
    (hP : integerProgressionValues ρ β⊆(A.image f+A.image f)-(A.image f+A.image f))
    (hproper : Set.InjOn ρ (integerBudgetBox β))
    (table : Array (Option ℤ))
    (htable : ∀ x∈(A.image f+A.image f)-(A.image f+A.image f),
      table[x.val]?=some (some (modelDifferenceLift A f x))) :
    (∀ z∈integerBudgetBox β,computedLiftHom table ρ β z=modelDifferenceLift A f (ρ z)) ∧
      integerProgressionValues (computedLiftHom table ρ β) β⊆(A+A)-(A+A) ∧
      Set.InjOn (computedLiftHom table ρ β) (integerBudgetBox β) ∧
      (integerProgressionValues (computedLiftHom table ρ β) β).card=(integerProgressionValues ρ β).card := by
  obtain ⟨F,hF,hsub,hinj,hcard⟩ := lift_model_progression A hA f hf ρ β hP hproper
  have he (z : IntVec r) (hz : z∈integerBudgetBox β) : computedLiftHom table ρ β z=F z := by
    apply computedLiftHom_eq_on_box table ρ β F _ z hz
    intro j hj
    have hu := unit_mem_integerBudgetBox β j hj
    have hp := hP (Finset.mem_image.mpr ⟨Pi.single j 1,hu,rfl⟩)
    rw [computedInverseValue,htable _ hp]
    exact (hF _ hu).symm
  have hpvalues : integerProgressionValues (computedLiftHom table ρ β) β=integerProgressionValues F β :=
    Finset.image_congr (fun z hz => he z hz)
  refine ⟨fun z hz => (he z hz).trans (hF z hz),?_,?_,?_⟩
  · rw [hpvalues]
    exact hsub
  · intro z hz w hw heq
    apply hinj hz hw
    simpa only [he z hz,he w hw] using heq
  · rw [hpvalues]
    exact hcard

theorem computedModelProgressionLift_spec (data differences : List ℤ) (n p q : ℕ)
    [NeZero p] (hq : 0<q)
    (hT : (computedModelingPart data n q).toFinset.Nonempty)
    (hf : FreimanEight (computedModelingPart data n q).toFinset
      (fun a => (modelingResidue (n:ZMod q) a:ZMod p)))
    (hdiff : differences.toFinset=
      ((computedModelingPart data n q).toFinset+(computedModelingPart data n q).toFinset)-
        ((computedModelingPart data n q).toFinset+(computedModelingPart data n q).toFinset))
    (ρ : IntVec r→+ZMod p) (β : Fin r→ℕ)
    (hP : integerProgressionValues ρ β⊆
      ((computedModelingPart data n q).toFinset.image (fun a => (modelingResidue (n:ZMod q) a:ZMod p))+
        (computedModelingPart data n q).toFinset.image (fun a => (modelingResidue (n:ZMod q) a:ZMod p)))-
      ((computedModelingPart data n q).toFinset.image (fun a => (modelingResidue (n:ZMod q) a:ZMod p))+
        (computedModelingPart data n q).toFinset.image (fun a => (modelingResidue (n:ZMod q) a:ZMod p))))
    (hproper : Set.InjOn ρ (integerBudgetBox β)) :
    let F := computedLiftHom (computedModelInverseTable differences n p q) ρ β
    integerProgressionValues F β⊆
      ((computedModelingPart data n q).toFinset+(computedModelingPart data n q).toFinset)-
        ((computedModelingPart data n q).toFinset+(computedModelingPart data n q).toFinset) ∧
      Set.InjOn F (integerBudgetBox β) ∧
      (integerProgressionValues F β).card=(integerProgressionValues ρ β).card :=
  (computedLiftHom_spec _ hT _ hf ρ β hP hproper _
    (computedModelInverseTable_lift data differences n p q hq hf hdiff)).2
end Optss
