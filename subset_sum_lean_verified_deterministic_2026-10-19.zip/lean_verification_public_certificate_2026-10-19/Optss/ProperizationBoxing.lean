import Optss.IntegerBasisCoordinates
import Optss.ProgressionCoordinates
import Optss.RationalVertexNormalization

/-!
# Reboxing the primitive quotient as an actual integer GAP

The normalization, independent quotient lattice points, integer coordinate
equivalence, scalar descent and whole-box count are proved for the actual
quotient. A reduced basis of the complete quotient lattice remains the explicit
input; its existence and bit complexity are not asserted by this module.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {G : Type*} [AddCommGroup G]
variable {d : ℕ}

/-- The one-dimensional relation branch reaches the actual rank-zero GAP.
No geometric boxing or basis reduction is needed in this case. -/
theorem primitiveQuotient_rank_zero (p : IntVec 1) (ℓ : IntVec 1 →ₗ[ℤ] ℤ)
    (hp : ℓ p=1) (ρ : IntVec 1 →+ G) (hρ : ρ p=0) (β : Fin 1 → ℕ) :
    integerProgressionValues ρ β = {0} := by
  have hz (x : IntVec 1) : ρ x=0 := by
    rw [← primitiveDescendedHom_quotient p ℓ hp ρ hρ x]
    have hx : primitiveQuotientMap p ℓ hp x = 0 := by
      ext j
      exact Fin.elim0 j
    rw [hx, map_zero]
  ext y
  constructor
  · rintro hy
    obtain ⟨x, _, rfl⟩ := Finset.mem_image.mp hy
    simp [hz]
  · intro hy
    have hy0 : y=0 := Finset.mem_singleton.mp hy
    subst y
    exact Finset.mem_image.mpr ⟨0, by simp [mem_integerBudgetBox, InBox], map_zero _⟩

theorem rank_zero_progression_proper (ρ : IntVec 0 →+ G) (n : Fin 0 → ℕ) (t : ℕ) :
    Set.InjOn ρ (integerBudgetBox (fun j => t*n j)) := by
  intro x _ y _ _
  ext j
  exact Fin.elim0 j

def reboxedPrimitiveHom (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p=1)
    (ρ : IntVec d →+ G) (b : Basis (Fin (d-1)) ℝ (Fin (d-1) → ℝ))
    (hΛ : basisIntegerLattice b = Set.range realVector) : IntVec (d-1) →+ G :=
  (primitiveDescendedHom p ℓ hp ρ).comp
    (integerBasisEquiv b hΛ).toLinearMap.toAddMonoidHom

theorem reboxedPrimitive_contains (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p=1)
    (ρ : IntVec d →+ G) (hρ : ρ p=0) (β : Fin d → ℕ)
    (b : Basis (Fin (d-1)) ℝ (Fin (d-1) → ℝ))
    (hΛ : basisIntegerLattice b = Set.range realVector) (n : Fin (d-1) → ℕ)
    (hbox : integerLinearImageBox (primitiveQuotientMap p ℓ hp) β ⊆ basisCoefficientBox b n) :
    integerProgressionValues ρ β ⊆ integerProgressionValues (reboxedPrimitiveHom p ℓ hp ρ b hΛ) n := by
  intro y hy
  obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hy
  obtain ⟨hmem, hscalar⟩ := primitiveQuotient_preserves_progression ρ p ℓ hp hρ β x hx
  refine Finset.mem_image.mpr
    ⟨(integerBasisEquiv b hΛ).symm (primitiveQuotientMap p ℓ hp x),
      (integerBasisEquiv_box b hΛ n _).mpr (hbox hmem), ?_⟩
  change primitiveDescendedHom p ℓ hp ρ
    (integerBasisEquiv b hΛ ((integerBasisEquiv b hΛ).symm _)) = ρ x
  rw [LinearEquiv.apply_symm_apply]
  exact hscalar

/-- All one-step geometric and scalar conclusions of properization after an
actual reduced full-lattice basis is supplied. The normalization is constructed
before the reduction and is independent of that reduced basis. -/
theorem primitiveQuotient_reboxing (hd : 1 < d)
    (p : IntVec d) (ℓ : IntVec d →ₗ[ℤ] ℤ) (hp : ℓ p=1)
    (ρ : IntVec d →+ G) (hρ : ρ p=0) (β : Fin d → ℕ) (hβ : ∀ j, 1 ≤ β j)
    (t : ℕ) (hbound : InBox (fun j => ((2*t*β j:ℕ):ℤ)) p) :
    ∃ a : (Fin (d-1) → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin (d-1)),
      Nonempty (RationalNormalizationData a) ∧
      ∀ (b : Basis (Fin (d-1)) ℝ (Fin (d-1) → ℝ))
        (hΛ : basisIntegerLattice b = Set.range realVector) (ω : ℝ),
        0 < ω → euclideanOrthogonalityDefect (b.map a.toLinearEquiv) ≤ ω →
        ∃ n : Fin (d-1) → ℕ, (∀ j, 1 ≤ n j) ∧
          integerProgressionValues ρ β ⊆
            integerProgressionValues (reboxedPrimitiveHom p ℓ hp ρ b hΛ) n ∧
          (integerBudgetBox n).card ≤
            (latticeBoxingResidueModulus (d-1) ω)^(d-1)*(1+t)^d*(integerBudgetBox β).card := by
  let π := primitiveQuotientMap p ℓ hp
  let K := integerLinearImageBox π β
  have hK : IsCompact K := integerLinearImageBox_compact π β
  obtain ⟨a, hinner, houter, hrat⟩ := primitiveQuotientBox_rational_normalization hd p ℓ hp β hβ
  refine ⟨a, hrat, ?_⟩
  intro b hΛ ω hω hdefect
  obtain ⟨u, hind, hu⟩ := integerLinearImageBox_independent π
    (primitiveQuotientMap_surjective p ℓ hp) β hβ
  have huΛ (i : Fin (d-1)) : realVector (u i) ∈ basisIntegerLattice b := by
    rw [hΛ]
    exact Set.mem_range_self _
  obtain ⟨n, hn, hsub, _, hcount⟩ := lattice_boxing_and_counting_of_normalization (by omega)
    K hK (integerLinearImageBox_convex π β)
    (fun _ hx => integerLinearImageBox_symmetric π β hx) a hinner houter b ω hω hdefect
    (fun i => realVector (u i)) hind hu huΛ
  refine ⟨n, hn, reboxedPrimitive_contains p ℓ hp ρ hρ β b hΛ n hsub, ?_⟩
  have hc := hcount 1
  simp only [one_smul] at hc
  rw [basisLatticePoints_box_card, basisLatticePoints_standard_card b hΛ K hK] at hc
  have hquot := primitiveQuotient_box_card p ℓ hp β t hbound
  rw [integerBudgetBox_card]
  calc
    _ ≤ (latticeBoxingResidueModulus (d-1) ω)^(d-1)*(integerPoints K hK.isBounded).card := hc
    _ ≤ (latticeBoxingResidueModulus (d-1) ω)^(d-1)*((1+t)^d*(integerBudgetBox β).card) :=
      Nat.mul_le_mul_left _ hquot
    _ = _ := by ring

end
end Optss
