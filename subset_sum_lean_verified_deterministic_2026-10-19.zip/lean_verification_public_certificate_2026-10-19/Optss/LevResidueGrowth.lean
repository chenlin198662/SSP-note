import Optss.FiniteSumsetGrowth
import Mathlib.Data.ZMod.Basic
import Mathlib.Combinatorics.Additive.CauchyDavenport

/-!
# Integer residue-fiber growth

These are actual finite-set components of V. F. Lev's 1997 addendum.
The endpoint-shift argument produces a new integer in every represented
residue class, and is proved here by choosing the maximum in a finite fiber.
-/
namespace Optss
open scoped Pointwise BigOperators

/-- Each residue represented by a sumset receives a new integer when the
last summand contains both endpoints `0` and a positive modulus. -/
theorem residue_new_element (S A : Finset ℤ) (l : ℕ) (hl : 0 < l)
    (_hzero : 0 ∈ A) (hlA : (l : ℤ) ∈ A) (c : ZMod l)
    (hc : c ∈ (S + A).image (fun x : ℤ => (x : ZMod l))) :
    ∃ x ∈ (S + A) \ S, (x : ZMod l) = c := by
  classical
  by_cases hOld : c ∈ S.image (fun x : ℤ => (x : ZMod l))
  · have hfiber : (S.filter (fun x : ℤ => (x : ZMod l) = c)).Nonempty := by
      obtain ⟨x, hx, hxc⟩ := Finset.mem_image.mp hOld
      exact ⟨x, Finset.mem_filter.mpr ⟨hx, hxc⟩⟩
    let F := S.filter (fun x : ℤ => (x : ZMod l) = c)
    let x := F.max' hfiber
    have hxF : x ∈ F := Finset.max'_mem F hfiber
    obtain ⟨hxS, hxc⟩ := Finset.mem_filter.mp hxF
    have hnext : ((x + (l : ℤ) : ℤ) : ZMod l) = c := by simpa using hxc
    refine ⟨x + l, Finset.mem_sdiff.mpr ⟨Finset.mem_add.mpr ⟨x, hxS, l, hlA, rfl⟩, ?_⟩,
      hnext⟩
    intro hmem
    have hF : x + (l : ℤ) ∈ F := Finset.mem_filter.mpr ⟨hmem, hnext⟩
    have := Finset.le_max' F (x + (l : ℤ)) hF
    have hlZ : (0 : ℤ) < l := by exact_mod_cast hl
    change x + (l : ℤ) ≤ x at this
    omega
  · obtain ⟨x, hx, hxc⟩ := Finset.mem_image.mp hc
    refine ⟨x, Finset.mem_sdiff.mpr ⟨hx, ?_⟩, hxc⟩
    intro hxS
    exact hOld (Finset.mem_image.mpr ⟨x, hxS, hxc⟩)

/-- The number of new integers dominates the number of represented residues. -/
theorem residue_sum_growth (S A : Finset ℤ) (l : ℕ) (hl : 0 < l)
    (hzero : 0 ∈ A) (hlA : (l : ℤ) ∈ A) :
    S.card + ((S + A).image (fun x : ℤ => (x : ZMod l))).card ≤ (S + A).card := by
  classical
  have hcard : ((S + A).image (fun x : ℤ => (x : ZMod l))).card ≤ ((S + A) \ S).card := by
    apply Finset.card_le_card_of_surjOn (fun x : ℤ => (x : ZMod l))
    intro c hc
    exact residue_new_element S A l hl hzero hlA c hc
  have hsub : S ⊆ S + A := by
    intro x hx
    exact Finset.mem_add.mpr ⟨x, hx, 0, hzero, by simp⟩
  have := Finset.card_sdiff_add_card_eq_card hsub
  omega

/-- The full-residue case of Lev's growth estimate. -/
theorem residue_sum_growth_of_full (S A : Finset ℤ) (l : ℕ) (hl : 0 < l)
    (hzero : 0 ∈ A) (hlA : (l : ℤ) ∈ A)
    (hfull : ∀ c : ZMod l, c ∈ (S + A).image (fun x : ℤ => (x : ZMod l))) :
    S.card + l ≤ (S + A).card := by
  haveI : NeZero l := ⟨by omega⟩
  have heq : (S + A).image (fun x : ℤ => (x : ZMod l)) = Finset.univ :=
    Finset.eq_univ_of_forall hfull
  simpa only [heq, Finset.card_univ, ZMod.card] using
    residue_sum_growth S A l hl hzero hlA

/-- Integer residues are injective on the half-open standard interval. -/
theorem int_residue_injOn_Ico (l : ℕ) :
    Set.InjOn (fun x : ℤ => (x : ZMod l)) (Set.Ico 0 (l : ℤ)) := by
  intro x hx y hy hxy
  rw [ZMod.intCast_eq_intCast_iff'] at hxy
  simpa only [Int.emod_eq_of_lt hx.1 hx.2, Int.emod_eq_of_lt hy.1 hy.2] using hxy

/-- When an endpoint is deleted, reducing an integer interval modulo its
length cannot identify any of the remaining integers. -/
theorem int_residue_injOn_erase_endpoint (A : Finset ℤ) (l : ℕ)
    (hA : A ⊆ Finset.Icc 0 (l : ℤ)) :
    Set.InjOn (fun x : ℤ => (x : ZMod l)) (A.erase (l : ℤ) : Set ℤ) := by
  apply (int_residue_injOn_Ico l).mono
  intro x hx
  obtain ⟨hne, hx⟩ := Finset.mem_erase.mp hx
  obtain ⟨hlo, hhi⟩ := Finset.mem_Icc.mp (hA hx)
  exact ⟨hlo, by omega⟩

/-- The residue-cardinality correction in Lev's theorem is exactly one
when both endpoints are present, and zero otherwise. -/
theorem interval_residue_card (A : Finset ℤ) (l : ℕ) (hl : 0 < l)
    (hA : A ⊆ Finset.Icc 0 (l : ℤ)) :
    (A.image (fun x : ℤ => (x : ZMod l))).card =
      A.card - if 0 ∈ A ∧ (l : ℤ) ∈ A then 1 else 0 := by
  classical
  have hlZ : (0 : ℤ) < l := by exact_mod_cast hl
  by_cases hend : (l : ℤ) ∈ A
  · by_cases hzero : 0 ∈ A
    · have himage : (A.erase (l : ℤ)).image (fun x : ℤ => (x : ZMod l)) =
          A.image (fun x : ℤ => (x : ZMod l)) := by
        apply Finset.Subset.antisymm (Finset.image_subset_image (Finset.erase_subset _ _))
        intro y hy
        obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hy
        by_cases hxl : x = l
        · exact Finset.mem_image.mpr ⟨0, Finset.mem_erase.mpr ⟨by omega, hzero⟩, by simp [hxl]⟩
        · exact Finset.mem_image.mpr ⟨x, Finset.mem_erase.mpr ⟨hxl, hx⟩, rfl⟩
      rw [← himage, Finset.card_image_of_injOn (int_residue_injOn_erase_endpoint A l hA),
        Finset.card_erase_of_mem hend]
      simp [hzero, hend]
    · have hinj : Set.InjOn (fun x : ℤ => (x : ZMod l)) (A : Set ℤ) := by
        intro x hx y hy hxy
        obtain ⟨hxlo, hxhi⟩ := Finset.mem_Icc.mp (hA hx)
        obtain ⟨hylo, hyhi⟩ := Finset.mem_Icc.mp (hA hy)
        have hxpos : 0 < x := lt_of_le_of_ne hxlo (by rintro rfl; exact hzero hx)
        have hypos : 0 < y := lt_of_le_of_ne hylo (by rintro rfl; exact hzero hy)
        have hneg : (((l : ℤ) - x : ℤ) : ZMod l) = (((l : ℤ) - y : ℤ) : ZMod l) := by
          simpa using congrArg Neg.neg hxy
        have he := int_residue_injOn_Ico l
          (show (l : ℤ) - x ∈ Set.Ico 0 (l : ℤ) from ⟨by omega, by omega⟩)
          (show (l : ℤ) - y ∈ Set.Ico 0 (l : ℤ) from ⟨by omega, by omega⟩) hneg
        omega
      rw [Finset.card_image_of_injOn hinj]
      simp [hzero]
  · have he : A.erase (l : ℤ) = A := Finset.erase_eq_of_not_mem hend
    have hinj := int_residue_injOn_erase_endpoint A l hA
    rw [he] at hinj
    rw [Finset.card_image_of_injOn hinj]
    simp [hend]

/-- The elementary integer sumset bound for a genuine finite family. -/
theorem integer_list_sum_card (L : List (Finset ℤ)) (hL : ∀ A ∈ L, A.Nonempty) :
    (L.map Finset.card).sum ≤ L.sum.card + (L.length - 1) := by
  induction L with
  | nil => simp
  | cons A L ih =>
    have hA := hL A (by simp)
    have htail : ∀ B ∈ L, B.Nonempty := fun B hB => hL B (by simp [hB])
    cases L with
    | nil => simp
    | cons B L =>
      have hK := cauchy_davenport_add_of_linearOrder_isAddCancel hA
        (nonempty_list_sum (B :: L) htail)
      have hI := ih htail
      simp only [List.map_cons, List.sum_cons, List.length_cons, Nat.add_sub_cancel] at *
      omega

/-- A lower bound for the cardinality of each summand fiber propagates to
every fiber of the actual integer sumset. This is integer Cauchy–Davenport
inside the chosen fibers, not a concentration or sumset-growth assumption. -/
theorem integer_list_fiber_card {G : Type*} [AddCommGroup G] [DecidableEq G]
    (f : ℤ →+ G) (L : List (Finset ℤ)) (k : Finset ℤ → ℤ)
    (hk : ∀ A ∈ L, ∀ a ∈ A, k A ≤ (A.filter (fun x => f x = f a)).card)
    (x : ℤ) (hx : x ∈ L.sum) :
    (L.map k).sum - (L.length : ℤ) + 1 ≤
      (L.sum.filter (fun y => f y = f x)).card := by
  induction L generalizing x with
  | nil =>
    simp at hx
    subst x
    simp
    exact ⟨0, by simp⟩
  | cons A L ih =>
    obtain ⟨a, ha, b, hb, rfl⟩ := Finset.mem_add.mp hx
    have hkA := hk A (by simp) a ha
    have hkL : ∀ B ∈ L, ∀ b ∈ B, k B ≤ (B.filter (fun y => f y = f b)).card :=
      fun B hB => hk B (by simp [hB])
    have hI := ih hkL b hb
    let FA := A.filter (fun y => f y = f a)
    let FB := L.sum.filter (fun y => f y = f b)
    have hFA : FA.Nonempty := ⟨a, Finset.mem_filter.mpr ⟨ha, rfl⟩⟩
    have hFB : FB.Nonempty := ⟨b, Finset.mem_filter.mpr ⟨hb, rfl⟩⟩
    have hCD := cauchy_davenport_add_of_linearOrder_isAddCancel hFA hFB
    have hsub : FA + FB ⊆ (A + L.sum).filter (fun y => f y = f (a + b)) := by
      intro y hy
      obtain ⟨u, hu, v, hv, rfl⟩ := Finset.mem_add.mp hy
      obtain ⟨huA, huf⟩ := Finset.mem_filter.mp hu
      obtain ⟨hvL, hvf⟩ := Finset.mem_filter.mp hv
      exact Finset.mem_filter.mpr ⟨Finset.mem_add.mpr ⟨u, huA, v, hvL, rfl⟩,
        by simp only [map_add, huf, hvf]⟩
    have hc := Finset.card_le_card hsub
    have hNat : FA.card + FB.card ≤
        ((A + L.sum).filter (fun y => f y = f (a + b))).card + 1 := by omega
    have hZ : (FA.card : ℤ) + FB.card ≤
        ((A + L.sum).filter (fun y => f y = f (a + b))).card + 1 := by exact_mod_cast hNat
    change k A ≤ (FA.card : ℤ) at hkA
    change (L.map k).sum - (L.length : ℤ) + 1 ≤ (FB.card : ℤ) at hI
    simp only [List.map_cons, List.sum_cons, List.length_cons, Nat.cast_add, Nat.cast_one]
    omega

/-- Every occupied stabilizer coset contains at least the global average
minus all the missing elements of the saturation. -/
theorem occupied_coset_card {G : Type*} [AddCommGroup G] [DecidableEq G]
    (A S : Finset G) (hS : S.Nonempty) (a : G) (ha : a ∈ A) :
    A.card + S.addStab.card ≤ (A ∩ (a +ᵥ S.addStab)).card + (A + S.addStab).card := by
  have hsub : A ∪ (a +ᵥ S.addStab) ⊆ A + S.addStab := by
    apply Finset.union_subset
    · intro x hx
      exact Finset.mem_add.mpr ⟨x, hx, 0, hS.zero_mem_addStab, by simp⟩
    · exact Finset.vadd_finset_subset_add ha
  have hu := Finset.card_le_card hsub
  have hi := Finset.card_inter_add_card_union A (a +ᵥ S.addStab)
  rw [Finset.card_vadd_finset] at hi
  omega

/-- The same occupied-coset estimate for integer preimages. Multiple integer
representatives are allowed; no unjustified injectivity is needed. -/
theorem integer_occupied_coset_card (A : Finset ℤ) (l : ℕ) (S : Finset (ZMod l))
    (hS : S.Nonempty) (a : ZMod l)
    (ha : a ∈ A.image (fun x : ℤ => (x : ZMod l))) :
    (A.image (fun x : ℤ => (x : ZMod l))).card + S.addStab.card ≤
      (A.filter (fun x : ℤ => (x : ZMod l) ∈ a +ᵥ S.addStab)).card +
      (A.image (fun x : ℤ => (x : ZMod l)) + S.addStab).card := by
  classical
  have h := occupied_coset_card (A.image (fun x : ℤ => (x : ZMod l))) S hS a ha
  have hsurj :
      ((A.image (fun x : ℤ => (x : ZMod l))) ∩ (a +ᵥ S.addStab)).card ≤
        (A.filter (fun x : ℤ => (x : ZMod l) ∈ a +ᵥ S.addStab)).card := by
    apply Finset.card_le_card_of_surjOn (fun x : ℤ => (x : ZMod l))
    intro y hy
    obtain ⟨hya, hyc⟩ := Finset.mem_inter.mp hy
    obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hya
    exact ⟨x, Finset.mem_filter.mpr ⟨hx, hyc⟩, rfl⟩
  omega

/-- A residue region missed by the old set can contribute all its integer
representatives, in place of the baseline one new integer per residue. -/
theorem residue_growth_boost (S A : Finset ℤ) (l : ℕ) (hl : 0 < l)
    (hzero : 0 ∈ A) (hlA : (l : ℤ) ∈ A) (C : Finset (ZMod l))
    (hC : C ⊆ (S + A).image (fun x : ℤ => (x : ZMod l)))
    (hCS : Disjoint C (S.image (fun x : ℤ => (x : ZMod l)))) :
    S.card + ((S + A).image (fun x : ℤ => (x : ZMod l))).card +
        ((S + A).filter (fun x : ℤ => (x : ZMod l) ∈ C)).card ≤
      (S + A).card + C.card := by
  classical
  let N := (S + A) \ S
  let F := (S + A).filter (fun x : ℤ => (x : ZMod l) ∈ C)
  let E := N.filter (fun x : ℤ => (x : ZMod l) ∉ C)
  have hF : F ⊆ N := by
    intro x hx
    obtain ⟨hxT, hxC⟩ := Finset.mem_filter.mp hx
    apply Finset.mem_sdiff.mpr
    refine ⟨hxT, ?_⟩
    intro hxS
    exact Finset.disjoint_left.mp hCS hxC (Finset.mem_image.mpr ⟨x, hxS, rfl⟩)
  have hEF : Disjoint E F := by
    apply Finset.disjoint_left.mpr
    intro x hxE hxF
    exact (Finset.mem_filter.mp hxE).2 (Finset.mem_filter.mp hxF).2
  have hunion : E ∪ F ⊆ N := Finset.union_subset (Finset.filter_subset _ _) hF
  have hcard := Finset.card_le_card hunion
  rw [Finset.card_union_of_disjoint hEF] at hcard
  have hE : (((S + A).image (fun x : ℤ => (x : ZMod l))) \ C).card ≤ E.card := by
    apply Finset.card_le_card_of_surjOn (fun x : ℤ => (x : ZMod l))
    intro c hc
    obtain ⟨hcT, hcC⟩ := Finset.mem_sdiff.mp hc
    obtain ⟨x, hx, hxc⟩ := residue_new_element S A l hl hzero hlA c hcT
    exact ⟨x, Finset.mem_filter.mpr ⟨hx, by simpa only [hxc] using hcC⟩, hxc⟩
  have hrescard := Finset.card_sdiff_add_card_eq_card hC
  have hsub : S ⊆ S + A := by
    intro x hx
    exact Finset.mem_add.mpr ⟨x, hx, 0, hzero, by simp⟩
  have hN := Finset.card_sdiff_add_card_eq_card hsub
  change N.card + S.card = (S + A).card at hN
  change S.card + ((S + A).image (fun x : ℤ => (x : ZMod l))).card + F.card ≤ _
  omega

end Optss
