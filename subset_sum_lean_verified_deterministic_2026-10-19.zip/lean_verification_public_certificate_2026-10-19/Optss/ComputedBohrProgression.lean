import Optss.StoredIntegralBasis

/-!
# A computed proper progression in the cyclic Bohr set

The answer uses the actual stored phase basis, cube vertices, Boolean LLL,
floor-width scans, and division. Its generators are read from the returned
integer columns. The small-modulus branch returns the zero-width box.
-/
namespace Optss
open scoped BigOperators
variable {N r : ℕ} [NeZero N]

def computedBohrBox (a : Fin r→ZMod N) (base : Fin r) (cs : List Bool) :
    Option (BooleanLatticeBoxResult r) :=
  if N/16=0 then some ⟨storedPhaseMatrix a base,BooleanListArray.replicate r []⟩
  else computedPhaseBox a base (N/16) cs

def storedPhaseProjection (base : Fin r) (box : BooleanLatticeBoxResult r) : IntVec r→+ZMod N :=
  (phaseCoordinateHom base).comp (storedIntegerSynthesis box.columns)

theorem computedBohrBox_spec (a : Fin r→ZMod N) (base : Fin r) (ha : a base=1)
    (S : Finset (ZMod N)) (hS : ∀ k∈S,∃ j,a j=k)
    (cs : List Bool) (hc : 0<binaryDigitsValue cs)
    (hCJ : latticeBoxingDilation r ((r.factorial:ℝ)*sharpLatticeDefectBound r)≤(binaryDigitsValue cs:ℝ)) :
    ∃ box,computedBohrBox a base cs=some box ∧
      Set.InjOn (storedPhaseProjection (N:=N) base box) (integerBudgetBox (decodedLatticeBoxWidths box)) ∧
      (∀ z∈integerBudgetBox (decodedLatticeBoxWidths box),storedPhaseProjection base box z∈cyclicBohrSet S) ∧
      N≤(16*(2*binaryDigitsValue cs+1))^r*∏ j,(2*decodedLatticeBoxWidths box j+1) ∧
      (∀ j,BitListCanonical (box.widths.toVector.get j)) := by
  have hdensity := phaseLatticeCube_density a base ha
  by_cases hM : N/16=0
  · let box : BooleanLatticeBoxResult r := ⟨storedPhaseMatrix a base,BooleanListArray.replicate r []⟩
    have hw : decodedLatticeBoxWidths box=fun _=>0 := by
      funext j
      simp [decodedLatticeBoxWidths,box,BooleanListArray.replicate,BooleanListArray.toVector,
        Vector.get,binaryDigitsValue]
    refine ⟨box,?_,?_,?_,?_,?_⟩
    · simp only [computedBohrBox,hM,↓reduceIte]
      rfl
    · rw [hw,integerBudgetBox_zero]
      intro x hx y hy _
      exact (Finset.mem_singleton.mp hx).trans (Finset.mem_singleton.mp hy).symm
    · rw [hw,integerBudgetBox_zero]
      intro z hz k hk
      rw [Finset.mem_singleton.mp hz]
      simp
    · rw [hw]
      rw [hM,phaseLatticeCube_zero,Finset.card_singleton,mul_one] at hdensity
      simp only [mul_zero,zero_add,Finset.prod_const_one,mul_one]
      exact hdensity.trans (Nat.pow_le_pow_left (by omega) r)
    · intro j
      simp [box,BooleanListArray.replicate,BooleanListArray.toVector,Vector.get,
        BitListCanonical,binaryDigitsValue]
  · obtain ⟨box,hbox,b,hcols,hΛ,hcanon,hinner,hcard,hB⟩ :=
      computedPhaseBox_spec a base ha (N/16) (by omega) cs hc hCJ
    let σ := storedIntegerSynthesis box.columns
    have hσ : σ=subgroupBasisSynthesisHom (cyclicPhaseLattice a base) b hΛ :=
      storedIntegerSynthesis_eq _ b hΛ box.columns hB hcols
    have hσΓ (z : IntVec r) : σ z∈cyclicPhaseLattice a base := by
      rw [hσ]
      exact subgroupBasisSynthesis_mem _ b hΛ z
    have hσbox (z : IntVec r) (hz : z∈integerBudgetBox (decodedLatticeBoxWidths box)) :
        ∀ j,|σ z j|≤(N/16:ℕ) := by
      have hx := hinner ((subgroupBasisSynthesisHom_box _ b hΛ (decodedLatticeBoxWidths box) z).mp hz)
      rw [mem_realCoefficientBox] at hx
      intro j
      rw [hσ]
      have hj := hx j
      exact (Int.cast_le (R:=ℝ)).mp (by simpa only [Int.cast_abs,Int.cast_natCast] using hj)
    have hshort : 2*(N/16)<N := by have h := Nat.mul_div_le N 16; have hN := NeZero.pos N; omega
    refine ⟨box,?_,?_,?_,?_,hcanon⟩
    · simp only [computedBohrBox,hM,↓reduceIte]
      exact hbox
    · intro x hx y hy he
      have he' : (σ x base:ZMod N)=(σ y base:ZMod N) := he
      have hxy := phase_lattice_projection_injective a base (N/16) hshort
        ⟨hσΓ x,hσbox x hx⟩ ⟨hσΓ y,hσbox y hy⟩ he'
      rw [hσ] at hxy
      exact subgroupBasisSynthesisHom_injective _ b hΛ hxy
    · intro z hz
      apply phase_lattice_small_box_bohr a base S hS (σ z) (hσΓ z)
      intro j
      have hw := hσbox z hz j
      have hd : (16:ℤ)*(N/16:ℕ)≤N := by exact_mod_cast Nat.mul_div_le N 16
      omega
    · calc
        N≤16^r*(phaseLatticeCube a base (N/16)).card := hdensity
        _≤16^r*((2*binaryDigitsValue cs+1)^r*∏ j,(2*decodedLatticeBoxWidths box j+1)) :=
          Nat.mul_le_mul_left _ hcard
        _=_ := by rw [mul_pow]; ring
end Optss
