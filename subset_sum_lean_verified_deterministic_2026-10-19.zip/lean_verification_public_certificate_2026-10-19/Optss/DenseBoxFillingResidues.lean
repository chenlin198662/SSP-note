import Optss.DenseBoxFillingFiniteGroup
import Mathlib.Data.ZMod.Basic

/-!
# Exact bounded-residue correction for dense-box filling

A rectangular sublattice box plus bounded representatives of all its residue
classes contains an ordinary integer box. The erosion at each boundary is
exactly the coordinate bound on the representatives. Residue completeness is
also proved for the actual sum of enough zero-containing generating sets.
The existence of the initial large sublattice box remains a separate task.
-/
namespace Optss
noncomputable section
open scoped BigOperators Pointwise
variable {d : ℕ}

/-- All integer points of a rectangular coordinate interval. -/
def fillingIntegerBox (lo hi : IntVec d) : Finset (IntVec d) :=
  Fintype.piFinset (fun j => Finset.Icc (lo j) (hi j))

@[simp] theorem mem_fillingIntegerBox (lo hi x : IntVec d) :
    x ∈ fillingIntegerBox lo hi ↔ ∀ j, lo j ≤ x j ∧ x j ≤ hi j := by
  simp [fillingIntegerBox, Fintype.mem_piFinset]

/-- A genuine rectangular progression in the sublattice with coordinate steps `v`. -/
def fillingRectangularProgression (v lo hi : IntVec d) : Finset (IntVec d) :=
  (fillingIntegerBox lo hi).image (fun q j => v j * q j)

/-- Exact erosion formula for correcting arbitrary residue representatives.
The representative may depend on the point being filled. -/
theorem filling_box_subset_progression_add_representatives (v lo hi C : IntVec d)
    (hv : ∀ j, 0 < v j) (R : Finset (IntVec d))
    (hR : ∀ r ∈ R, ∀ j, |r j| ≤ C j)
    (hres : ∀ x : IntVec d, ∃ r ∈ R, ∀ j, v j ∣ x j - r j) :
    fillingIntegerBox (fun j => v j * lo j + C j) (fun j => v j * hi j - C j) ⊆
      fillingRectangularProgression v lo hi + R := by
  intro x hx
  obtain ⟨r, hr, hdiv⟩ := hres x
  choose q hq using hdiv
  have hqbox : q ∈ fillingIntegerBox lo hi := by
    rw [mem_fillingIntegerBox]
    intro j
    have hxj := (mem_fillingIntegerBox _ _ _).mp hx j
    have hrj := abs_le.mp (hR r hr j)
    have he := hq j
    constructor
    · apply (mul_le_mul_left (hv j)).mp
      nlinarith
    · apply (mul_le_mul_left (hv j)).mp
      nlinarith
  apply Finset.mem_add.mpr
  refine ⟨fun j => v j * q j, Finset.mem_image.mpr ⟨q, hqbox, rfl⟩, r, hr, ?_⟩
  funext j
  have he := hq j
  change v j * q j + r j = x j
  linarith

/-- The erosion formula transports through an actual translated progression
already contained in a support. -/
theorem filling_translated_box_subset_sum (v lo hi C t : IntVec d)
    (hv : ∀ j, 0 < v j) (P R : Finset (IntVec d))
    (hP : (fillingRectangularProgression v lo hi).image (t + ·) ⊆ P)
    (hR : ∀ r ∈ R, ∀ j, |r j| ≤ C j)
    (hres : ∀ x : IntVec d, ∃ r ∈ R, ∀ j, v j ∣ x j - r j) :
    (fillingIntegerBox (fun j => v j * lo j + C j)
      (fun j => v j * hi j - C j)).image (t + ·) ⊆ P + R := by
  intro y hy
  obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hy
  have hxsum := filling_box_subset_progression_add_representatives v lo hi C hv R hR hres hx
  obtain ⟨p, hp, r, hr, hpr⟩ := Finset.mem_add.mp hxsum
  apply Finset.mem_add.mpr
  refine ⟨t+p, hP (Finset.mem_image.mpr ⟨p, hp, rfl⟩), r, hr, ?_⟩
  rw [add_assoc, hpr]

/-- The coordinatewise quotient by a rectangular integer sublattice. -/
def fillingResidueHom (v : Fin d → ℕ) : IntVec d →+ (∀ j, ZMod (v j)) where
  toFun x j := (x j : ZMod (v j))
  map_zero' := by ext j; simp
  map_add' x y := by ext j; simp

theorem fillingResidueHom_surjective (v : Fin d → ℕ) : Function.Surjective (fillingResidueHom v) := by
  intro y
  choose x hx using (fun j => ZMod.intCast_surjective (y j))
  exact ⟨x, funext hx⟩

/-- Enough actual generating summands supply representatives of every
rectangular residue class. The number needed is at most the quotient size. -/
theorem filling_residues_of_generating_summands (v : Fin d → ℕ) (hv : ∀ j, 0 < v j)
    {n : ℕ} (A : Fin n → Finset (IntVec d)) (hzero : ∀ i, 0 ∈ A i)
    (hgen : ∀ i, AddSubgroup.closure (A i : Set (IntVec d)) = ⊤)
    (hcount : (∏ j, v j) ≤ n+1) (x : IntVec d) :
    ∃ r ∈ ∑ i, A i, ∀ j, (v j : ℤ) ∣ x j - r j := by
  letI : ∀ j, NeZero (v j) := fun j => ⟨ne_of_gt (hv j)⟩
  have hcard : Fintype.card (∀ j, ZMod (v j)) ≤ n+1 := by
    simpa only [Fintype.card_pi, ZMod.card] using hcount
  have he := finiteQuotient_sum_image_eq_univ A hzero hgen
    (fillingResidueHom v) (fillingResidueHom_surjective v) hcard
  have hm : fillingResidueHom v x ∈ (∑ i, A i).image (fillingResidueHom v) := by rw [he]; simp
  obtain ⟨r, hr, heq⟩ := Finset.mem_image.mp hm
  refine ⟨r, hr, fun j => ?_⟩
  exact (ZMod.intCast_eq_intCast_iff_dvd_sub (r j) (x j) (v j)).mp (congrFun heq j)

/-- Combining the proved quotient saturation and geometric correction uses
the same actual residual summands, with no supplied covering hypothesis. -/
theorem filling_translated_box_of_generating_summands
    (v : Fin d → ℕ) (hv : ∀ j, 0 < v j) (lo hi C t : IntVec d) (P : Finset (IntVec d))
    (hP : (fillingRectangularProgression (fun j => (v j : ℤ)) lo hi).image (t + ·) ⊆ P)
    {n : ℕ} (A : Fin n → Finset (IntVec d)) (hzero : ∀ i, 0 ∈ A i)
    (hgen : ∀ i, AddSubgroup.closure (A i : Set (IntVec d)) = ⊤)
    (hcount : (∏ j, v j) ≤ n+1)
    (hbound : ∀ r ∈ ∑ i, A i, ∀ j, |r j| ≤ C j) :
    (fillingIntegerBox (fun j => (v j : ℤ) * lo j + C j)
      (fun j => (v j : ℤ) * hi j - C j)).image (t + ·) ⊆ P + ∑ i, A i := by
  exact filling_translated_box_subset_sum (fun j => (v j : ℤ)) lo hi C t
    (fun j => by change (0 : ℤ) < (v j : ℤ); exact_mod_cast hv j) P (∑ i, A i) hP hbound
    (filling_residues_of_generating_summands v hv A hzero hgen hcount)

/-- Coordinate bounds on each input set give the bound on every actual
residual sum, with exactly one selected element per summand. -/
theorem filling_sum_coordinate_bound {n : ℕ} (A : Fin n → Finset (IntVec d)) (W : IntVec d)
    (hA : ∀ i, ∀ x ∈ A i, ∀ j, |x j| ≤ W j) (r : IntVec d) (hr : r ∈ ∑ i, A i) :
    ∀ j, |r j| ≤ (n : ℤ) * W j := by
  have hr' : r ∈ (List.ofFn A).sum := by simpa only [List.sum_ofFn] using hr
  obtain ⟨x, hx⟩ := Finset.mem_sum_list_ofFn.mp hr'
  have he : (∑ i, (x i : IntVec d)) = r := by simpa only [List.sum_ofFn] using hx
  intro j
  rw [← he, Finset.sum_apply]
  calc
    |∑ i, (x i : IntVec d) j| ≤ ∑ i, |(x i : IntVec d) j| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _i : Fin n, W j := Finset.sum_le_sum (fun i _ => hA i (x i) (x i).property j)
    _ = (n : ℤ) * W j := by simp

/-- A fully checked residue-completion stage from bounded generating inputs.
Only the earlier rectangular-progression stage is an input to this theorem. -/
theorem filling_translated_box_of_bounded_generating_summands
    (v : Fin d → ℕ) (hv : ∀ j, 0 < v j) (lo hi W t : IntVec d) (P : Finset (IntVec d))
    (hP : (fillingRectangularProgression (fun j => (v j : ℤ)) lo hi).image (t + ·) ⊆ P)
    {n : ℕ} (A : Fin n → Finset (IntVec d)) (hzero : ∀ i, 0 ∈ A i)
    (hgen : ∀ i, AddSubgroup.closure (A i : Set (IntVec d)) = ⊤)
    (hcount : (∏ j, v j) ≤ n+1)
    (hbound : ∀ i, ∀ x ∈ A i, ∀ j, |x j| ≤ W j) :
    (fillingIntegerBox (fun j => (v j : ℤ) * lo j + (n : ℤ) * W j)
      (fun j => (v j : ℤ) * hi j - (n : ℤ) * W j)).image (t + ·) ⊆ P + ∑ i, A i := by
  exact filling_translated_box_of_generating_summands v hv lo hi (fun j => (n : ℤ)*W j) t
    P hP A hzero hgen hcount (filling_sum_coordinate_bound A W hbound)

/-- The eroded box is nonempty whenever the initial progression width covers
both correction margins. This makes the required slack explicit. -/
theorem filling_corrected_box_nonempty (v lo hi C : IntVec d)
    (hmargin : ∀ j, 2 * C j ≤ v j * (hi j - lo j)) :
    (fillingIntegerBox (fun j => v j * lo j + C j) (fun j => v j * hi j - C j)).Nonempty := by
  refine ⟨fun j => v j * lo j + C j, ?_⟩
  rw [mem_fillingIntegerBox]
  intro j
  have hj := hmargin j
  constructor
  · exact le_rfl
  · nlinarith

/-- Exact number of lattice points in the box produced by the correction. -/
theorem fillingIntegerBox_card (lo hi : IntVec d) :
    (fillingIntegerBox lo hi).card = ∏ j, (hi j - lo j + 1).toNat := by
  simp only [fillingIntegerBox, Fintype.card_piFinset, Int.card_Icc]
  apply Finset.prod_congr rfl
  intro j _
  congr 1
  ring

end
end Optss
