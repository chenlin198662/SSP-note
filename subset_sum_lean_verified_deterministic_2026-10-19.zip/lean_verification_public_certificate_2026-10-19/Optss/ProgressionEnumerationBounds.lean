import Optss.ProgressionListEnumeration
import Optss.FreimanDescriptionBounds

/-! Ambient bounds for the actual progression enumerator. Properness bounds
the number of coefficient tuples by the ambient interval, while zero extension
puts all recursive tail values and single-coordinate products in the original
progression. Thus cancellation never hides large arithmetic intermediates. -/
namespace Optss
variable {r : ℕ}

theorem progressionValueList_length_ambient (a : Fin r→ℤ) (β : Fin r→ℕ)
    (hp : Set.InjOn (progressionLinearEncoding a) (integerBudgetBox β)) (U : ℕ)
    (hb : ∀ x∈integerProgressionValues (progressionLinearEncoding a).toAddMonoidHom β,|x|≤(U:ℤ)) :
    (progressionValueList r a β).length≤2*U+1 := by
  have hs : integerProgressionValues (progressionLinearEncoding a).toAddMonoidHom β⊆
      Finset.Icc (-(U:ℤ)) U := fun x hx => Finset.mem_Icc.mpr (abs_le.mp (hb x hx))
  have hcard := Finset.card_le_card hs
  rw [←progressionValueList_toFinset,List.toFinset_card_of_nodup (progressionValueList_nodup r a β hp),
    Int.card_Icc] at hcard
  omega

theorem progressionValueListWordWork_ambient (a : Fin r→ℤ) (β : Fin r→ℕ)
    (hp : Set.InjOn (progressionLinearEncoding a) (integerBudgetBox β)) (U : ℕ)
    (hb : ∀ x∈integerProgressionValues (progressionLinearEncoding a).toAddMonoidHom β,|x|≤(U:ℤ)) :
    progressionValueListWordWork r a β≤64*(r+1)*(2*U+1) := by
  have hw := progressionValueListWordWork_bound r a β
  have hl := progressionValueList_length_ambient a β hp U hb
  rw [integerBudgetBox_card,←progressionValueList_length r a β] at hw
  exact hw.trans (Nat.mul_le_mul_left _ hl)

theorem progression_tail_value_mem (a : Fin (r+1)→ℤ) (β : Fin (r+1)→ℕ)
    (x : ℤ) (hx : x∈progressionValueList r (Fin.tail a) (Fin.tail β)) :
    x∈integerProgressionValues (progressionLinearEncoding a).toAddMonoidHom β := by
  obtain ⟨z,hz,rfl⟩ := (mem_progressionValueList _ _ _ _).mp hx
  apply Finset.mem_image.mpr
  refine ⟨Fin.cons 0 z,(integerBudgetBox_cons _ _ _).mpr ⟨by simp,hz⟩,?_⟩
  simpa only [mul_zero,zero_add] using progressionLinearEncoding_cons a 0 z

theorem progression_step_operand_bounds (a : Fin (r+1)→ℤ) (β : Fin (r+1)→ℕ) (U : ℕ)
    (hb : ∀ x∈integerProgressionValues (progressionLinearEncoding a).toAddMonoidHom β,|x|≤(U:ℤ))
    (z : ℤ) (hz : z∈progressionCoefficientList (β 0))
    (x : ℤ) (hx : x∈progressionValueList r (Fin.tail a) (Fin.tail β)) :
    |a 0*z|≤(U:ℤ) ∧ |x|≤(U:ℤ) ∧ |a 0*z+x|≤(U:ℤ) := by
  have hzbound := (mem_progressionCoefficientList _ _).mp hz
  have hzmem : Pi.single 0 z∈integerBudgetBox β := single_mem_integerBudgetBox β 0 z hzbound
  have hterm : a 0*z∈integerProgressionValues (progressionLinearEncoding a).toAddMonoidHom β := by
    apply Finset.mem_image.mpr
    refine ⟨Pi.single 0 z,hzmem,?_⟩
    simp [progressionLinearEncoding,Pi.single_apply,Finset.mul_sum]
  have hsum : a 0*z+x∈progressionValueList (r+1) a β := by
    apply List.mem_flatMap.mpr
    exact ⟨z,hz,List.mem_map.mpr ⟨x,hx,rfl⟩⟩
  have hsum' : a 0*z+x∈integerProgressionValues (progressionLinearEncoding a).toAddMonoidHom β := by
    rw [←progressionValueList_toFinset]
    exact List.mem_toFinset.mpr hsum
  exact ⟨hb _ hterm,hb _ (progression_tail_value_mem a β x hx),hb _ hsum'⟩

/-- Every recursive call retains the same ambient value bound. -/
theorem progression_tail_ambient (a : Fin (r+1)→ℤ) (β : Fin (r+1)→ℕ) (U : ℕ)
    (hb : ∀ x∈integerProgressionValues (progressionLinearEncoding a).toAddMonoidHom β,|x|≤(U:ℤ)) :
    ∀ x∈integerProgressionValues (progressionLinearEncoding (Fin.tail a)).toAddMonoidHom (Fin.tail β),
      |x|≤(U:ℤ) := by
  intro x hx
  apply hb x
  apply progression_tail_value_mem a β x
  rw [←progressionValueList_toFinset,List.mem_toFinset] at hx
  exact hx

end Optss
