import Optss.Basic
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.Card

/-!
# Counted types and separately labelled copies

The exact copy expansion used in the proof of Corollary 1.3 (§11, p.75).
Equal type values are permitted: indices, rather than values, identify copies.
-/

namespace Optss
open scoped BigOperators

variable {ι G : Type*} [Fintype ι] [AddCommGroup G]

/-- Each available copy has both its original type label and its within-type index. -/
abbrev CopyIndex (c : ι → ℕ) := (i : ι) × Fin (c i)

def expandedCopy (v : ι → G) (c : ι → ℕ) : CopyIndex c → G := fun q => v q.1

/-- Count the selected labels of a fixed original type. -/
noncomputable def copyCount (c : ι → ℕ) (s : Finset (CopyIndex c)) (i : ι) : ℤ :=
  by
    classical
    exact ((Finset.univ.filter (fun j : Fin (c i) => Sigma.mk i j ∈ s)).card : ℤ)

omit [Fintype ι] in
theorem copyCount_bounded (c : ι → ℕ) (s : Finset (CopyIndex c)) :
    BoundedCounts (fun i => (c i : ℤ)) (copyCount c s) := by
  classical
  intro i
  constructor
  · exact Int.natCast_nonneg _
  · unfold copyCount
    change ((Finset.univ.filter (fun j : Fin (c i) => Sigma.mk i j ∈ s)).card : ℤ) ≤ (c i : ℤ)
    have hcard := (Finset.univ.filter (fun j : Fin (c i) => Sigma.mk i j ∈ s)).card_le_univ
    have hn : (Finset.univ.filter (fun j : Fin (c i) => Sigma.mk i j ∈ s)).card ≤ c i := by
      simpa using hcard
    exact_mod_cast hn

/-- Summing the labelled copies agrees with summing their per-type counts. -/
theorem sum_expandedCopy (v : ι → G) (c : ι → ℕ) (s : Finset (CopyIndex c)) :
    (∑ q ∈ s, expandedCopy v c q) = weightedSum v (copyCount c s) := by
  classical
  calc
    (∑ q ∈ s, expandedCopy v c q) = ∑ q, if q ∈ s then expandedCopy v c q else 0 := by
      simp
    _ = ∑ i, ∑ j : Fin (c i), if Sigma.mk i j ∈ s then v i else 0 := by
      rw [Fintype.sum_sigma]
      rfl
    _ = weightedSum v (copyCount c s) := by
      unfold weightedSum copyCount
      apply Finset.sum_congr rfl
      intro i _
      rw [← Finset.sum_filter]
      simp

/-- Every bounded integer count is realized by selecting the first copies of each type. -/
theorem exists_copy_selection (c : ι → ℕ) (x : ι → ℤ)
    (hx : BoundedCounts (fun i => (c i : ℤ)) x) :
    ∃ s : Finset (CopyIndex c), copyCount c s = x := by
  classical
  let s : Finset (CopyIndex c) := Finset.univ.filter (fun q => q.2.val < (x q.1).toNat)
  refine ⟨s, ?_⟩
  funext i
  have hi := hx i
  dsimp at hi
  have hle : (x i).toNat ≤ c i := by omega
  have hcard : (Finset.univ.filter (fun j : Fin (c i) => j.val < (x i).toNat)).card =
      (x i).toNat := by
    rw [← Fintype.card_subtype]
    exact Fintype.card_fin_lt_of_le hle
  simpa [copyCount, s, hcard, Int.toNat_of_nonneg (hx i).1] using
    congrArg (fun n : ℕ => (n : ℤ)) hcard

/-- Exact expansion into copies, without assuming that different types have different values. -/
theorem countSums_iff_expanded_subsetSums (v : ι → G) (c : ι → ℕ) (t : G) :
    t ∈ countSums v (fun i => (c i : ℤ)) ↔ t ∈ subsetSums (expandedCopy v c) := by
  constructor
  · rintro ⟨x, hx, hsum⟩
    rcases exists_copy_selection c x hx with ⟨s, hs⟩
    refine ⟨s, ?_⟩
    rw [sum_expandedCopy, hs, hsum]
  · rintro ⟨s, rfl⟩
    exact ⟨copyCount c s, copyCount_bounded c s, (sum_expandedCopy v c s).symm⟩

/-- Expansion has exactly the number of copies advertised by the capacities. -/
theorem card_copyIndex (c : ι → ℕ) : Fintype.card (CopyIndex c) = ∑ i, c i := by
  simp [CopyIndex, Fintype.card_sigma]

end Optss
