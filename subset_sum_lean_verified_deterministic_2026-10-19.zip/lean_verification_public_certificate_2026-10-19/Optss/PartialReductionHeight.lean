import Optss.ReducedLatticeHeight
import Optss.RationalGramSchmidt

/-!
# Heights inside an exact size-reduction sweep

The positive integer prefix Gram determinants bound both Gram-Schmidt lengths
and their inverses. Consequently each nearest-integer row operation increases
`norm + 1` by a polynomial factor when the previously reduced rows are bounded.
The finite trace below records the actual rational implementation's successive
integer matrices, including its initial and final states.
-/

namespace Optss
noncomputable section
open scoped BigOperators
variable {r d : ℕ}

/-- The reciprocal squared Gram-Schmidt length is at most the integer Gram
potential. This uses positivity of both neighboring integer determinants. -/
theorem one_le_gramSchmidt_sq_mul_potential (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (i : Fin r) :
    1 ≤ ‖gramSchmidt ℝ (euclideanIntegerRows A) i‖^2 * gramPotential A := by
  have hlo : (1:ℝ) ≤ (prefixGramDet A ⟨i.val+1, by omega⟩:ℝ) := by
    exact_mod_cast prefixGramDet_pos A hA ⟨i.val+1, by omega⟩
  have hhi : (prefixGramDet A ⟨i.val, by omega⟩:ℝ) ≤ gramPotential A := by
    have hb := prefixGramDet_le_potential A hA ⟨i.val, by omega⟩
    have hpos := prefixGramDet_pos A hA ⟨i.val, by omega⟩
    have hb' : prefixGramDet A ⟨i.val, by omega⟩ ≤ (gramPotential A:ℤ) := by
      simpa only [Int.natCast_natAbs, abs_of_pos hpos] using (Int.ofNat_le.mpr hb)
    exact_mod_cast hb'
  have hid := prefixGramDet_succ_eq A i
  nlinarith [mul_le_mul_of_nonneg_right hhi
    (sq_nonneg ‖gramSchmidt ℝ (euclideanIntegerRows A) i‖)]

/-- A coarse coefficient estimate with an exponent independent of the number
of row operations. It is sufficient for polynomial bit-height bounds. -/
theorem gsCoefficient_abs_le_norm_mul_potential_sq (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k j : Fin r) :
    |gsCoefficient (euclideanIntegerRows A) k j| ≤
      ‖euclideanIntegerRows A k‖ * (gramPotential A:ℝ)^2 := by
  let g := ‖gramSchmidt ℝ (euclideanIntegerRows A) j‖
  let P : ℝ := gramPotential A
  have hP : 1 ≤ P := by
    dsimp [P]
    exact_mod_cast (gramPotential_pos A hA : 1 ≤ gramPotential A)
  have hg0 : 0 ≤ g := norm_nonneg _
  have hg2 : g^2 ≤ P := gramSchmidt_sq_le_potential A hA j
  have hgP : 1 ≤ g^2*P := one_le_gramSchmidt_sq_mul_potential A hA j
  have hgpos : 0 < g^2 := by nlinarith
  have hg : g ≤ P := by nlinarith
  have hin : |inner (gramSchmidt ℝ (euclideanIntegerRows A) j)
      (euclideanIntegerRows A k)| ≤ g * ‖euclideanIntegerRows A k‖ :=
    abs_real_inner_le_norm _ _
  unfold gsCoefficient
  rw [abs_div, abs_of_pos hgpos]
  apply (div_le_iff₀ hgpos).mpr
  calc
    _ ≤ g * ‖euclideanIntegerRows A k‖ := hin
    _ ≤ P * ‖euclideanIntegerRows A k‖ := mul_le_mul_of_nonneg_right hg (norm_nonneg _)
    _ ≤ (‖euclideanIntegerRows A k‖*P^2)*g^2 := by
      nlinarith [mul_le_mul_of_nonneg_left hgP (show 0 ≤ P*‖euclideanIntegerRows A k‖ by positivity)]

/-- Rounding adds at most one to the absolute coefficient bound. -/
theorem round_gsCoefficient_abs_le (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k j : Fin r) :
    |(round (gsCoefficient (euclideanIntegerRows A) k j):ℝ)| ≤
      ‖euclideanIntegerRows A k‖*(gramPotential A:ℝ)^2+1 := by
  have hc := gsCoefficient_abs_le_norm_mul_potential_sq A hA k j
  have hr := abs_sub_round (gsCoefficient (euclideanIntegerRows A) k j)
  have ht := abs_sub_le (round (gsCoefficient (euclideanIntegerRows A) k j):ℝ)
    (gsCoefficient (euclideanIntegerRows A) k j) 0
  rw [sub_zero, sub_zero, abs_sub_comm] at ht
  linarith

/-- One actual integer update has multiplicative, rather than iterated-square,
height growth when the earlier row is bounded. -/
theorem round_reduce_norm_add_one_le (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k j : Fin r)
    (M : ℝ) (hM : 0 ≤ M) (hj : ‖euclideanIntegerRows A j‖ ≤ M) :
    ‖euclideanIntegerRows (reduceVector A j k
      (round (gsCoefficient (euclideanIntegerRows A) k j))) k‖+1 ≤
    (‖euclideanIntegerRows A k‖+1)*(1+((gramPotential A:ℝ)^2+1)*M) := by
  rw [euclideanIntegerRows_reduceVector]
  simp only [reduceVector, Function.update_self]
  have ht := norm_sub_le (euclideanIntegerRows A k)
    ((round (gsCoefficient (euclideanIntegerRows A) k j):ℝ) • euclideanIntegerRows A j)
  rw [norm_smul, Real.norm_eq_abs] at ht
  have hc := round_gsCoefficient_abs_le A hA k j
  have hm := mul_le_mul hc hj (norm_nonneg _) (by positivity :
    0 ≤ ‖euclideanIntegerRows A k‖*(gramPotential A:ℝ)^2+1)
  nlinarith [norm_nonneg (euclideanIntegerRows A k)]

/-- The successive matrices visited by the exact rational per-row sweep.
Both endpoints are included; there are exactly `n+1` states. -/
def integerRowSweepTrace (A : Matrix (Fin r) (Fin d) ℤ) (k : Fin r)
    (n : ℕ) (h : n ≤ k.val) : List (Matrix (Fin r) (Fin d) ℤ) :=
  match n with
  | 0 => [A]
  | n+1 =>
    let j : Fin r := ⟨n, by omega⟩
    let q : ℤ := round (rationalGsCoefficient (rationalIntegerRows A) k j)
    A :: integerRowSweepTrace (Function.update A k (A k - q • A j)) k n (by omega)
termination_by n

theorem integerRowSweepTrace_length (A : Matrix (Fin r) (Fin d) ℤ) (k : Fin r)
    (n : ℕ) (h : n ≤ k.val) : (integerRowSweepTrace A k n h).length = n+1 := by
  induction n generalizing A with
  | zero => simp [integerRowSweepTrace]
  | succ n ih => simp only [integerRowSweepTrace, List.length_cons, ih]

theorem rationalReduceIntegerRow_mem_trace (A : Matrix (Fin r) (Fin d) ℤ) (k : Fin r)
    (n : ℕ) (h : n ≤ k.val) :
    rationalReduceIntegerRow A k n h ∈ integerRowSweepTrace A k n h := by
  induction n generalizing A with
  | zero => simp [integerRowSweepTrace, rationalReduceIntegerRow]
  | succ n ih =>
    rw [integerRowSweepTrace, rationalReduceIntegerRow]
    exact List.mem_cons_of_mem _ (ih _ _)

/-- Every earlier row stays fixed along the trace. -/
theorem integerRowSweepTrace_unchanged (A : Matrix (Fin r) (Fin d) ℤ) (k : Fin r)
    (n : ℕ) (h : n ≤ k.val) (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace A k n h) (i : Fin r) (hik : i ≠ k) :
    B i = A i := by
  induction n generalizing A with
  | zero =>
    have he : B = A := by simpa only [integerRowSweepTrace, List.mem_singleton] using hB
    rw [he]
  | succ n ih =>
    rw [integerRowSweepTrace, List.mem_cons] at hB
    rcases hB with rfl | hB
    · rfl
    · rw [ih _ _ hB]
      exact Function.update_of_ne hik _ _

/-- Every recorded matrix remains independent, preserves the full integer
lattice, and has exactly the starting Gram potential. -/
theorem integerRowSweepTrace_invariants (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k : Fin r)
    (n : ℕ) (h : n ≤ k.val) (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace A k n h) :
    LinearIndependent ℝ (fun i j => (B i j:ℝ)) ∧
    Submodule.span ℤ (Set.range B) = Submodule.span ℤ (Set.range A) ∧
    gramPotential B = gramPotential A := by
  induction n generalizing A with
  | zero =>
    have he : B = A := by simpa only [integerRowSweepTrace, List.mem_singleton] using hB
    subst B
    exact ⟨hA, rfl, rfl⟩
  | succ n ih =>
    rw [integerRowSweepTrace, List.mem_cons] at hB
    rcases hB with he | hB
    · subst B
      exact ⟨hA, rfl, rfl⟩
    · let j : Fin r := ⟨n, by omega⟩
      let q : ℤ := round (rationalGsCoefficient (rationalIntegerRows A) k j)
      let W := reduceVector A j k q
      have hjk : j < k := by change n < k.val; omega
      have hW : LinearIndependent ℝ (fun i l => (W i l:ℝ)) := by
        apply (euclideanIntegerRows_independent_iff W).mp
        rw [euclideanIntegerRows_reduceVector]
        exact (linearIndependent_reduceVector_iff _ j k (ne_of_lt hjk) (q:ℝ)).mpr
          ((euclideanIntegerRows_independent_iff A).mpr hA)
      obtain ⟨hind, hspan, hp⟩ := ih W hW (by omega) hB
      exact ⟨hind, hspan.trans (span_reduceVector A j k (ne_of_lt hjk) q),
        hp.trans (gramPotential_reduceVector A j k hjk q)⟩

/-- All states of the actual descending sweep obey a fixed-factor exponential
height bound. Its logarithm is linear in the number of updates. -/
theorem integerRowSweepTrace_norm_bound (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k : Fin r)
    (n : ℕ) (h : n ≤ k.val) (M : ℝ) (hM : 0 ≤ M)
    (hprev : ∀ j : Fin r, j < k → ‖euclideanIntegerRows A j‖ ≤ M)
    (B : Matrix (Fin r) (Fin d) ℤ) (hB : B ∈ integerRowSweepTrace A k n h) :
    ‖euclideanIntegerRows B k‖+1 ≤
      (‖euclideanIntegerRows A k‖+1)*(1+((gramPotential A:ℝ)^2+1)*M)^n := by
  induction n generalizing A with
  | zero =>
    have he : B = A := by simpa only [integerRowSweepTrace, List.mem_singleton] using hB
    simp only [he, pow_zero, mul_one, le_refl]
  | succ n ih =>
    rw [integerRowSweepTrace, List.mem_cons] at hB
    rcases hB with he | hB
    · subst B
      have hf : (1:ℝ) ≤ 1+((gramPotential A:ℝ)^2+1)*M := by
        have : 0 ≤ ((gramPotential A:ℝ)^2+1)*M := by positivity
        linarith
      exact (le_mul_of_one_le_right (by positivity) (one_le_pow₀ hf))
    · let j : Fin r := ⟨n, by omega⟩
      let q : ℤ := round (rationalGsCoefficient (rationalIntegerRows A) k j)
      let W := reduceVector A j k q
      have hjk : j < k := by change n < k.val; omega
      have hW : LinearIndependent ℝ (fun i l => (W i l:ℝ)) := by
        apply (euclideanIntegerRows_independent_iff W).mp
        rw [euclideanIntegerRows_reduceVector]
        exact (linearIndependent_reduceVector_iff _ j k (ne_of_lt hjk) (q:ℝ)).mpr
          ((euclideanIntegerRows_independent_iff A).mpr hA)
      have hp : gramPotential W = gramPotential A := gramPotential_reduceVector A j k hjk q
      have hwprev : ∀ i : Fin r, i < k → ‖euclideanIntegerRows W i‖ ≤ M := by
        intro i hik
        have he : euclideanIntegerRows W i = euclideanIntegerRows A i := by
          rw [euclideanIntegerRows_reduceVector]
          exact Function.update_of_ne (ne_of_lt hik) _ _
        rw [he]
        exact hprev i hik
      have hmem : B ∈ integerRowSweepTrace W k n (by omega) := hB
      have hind := ih W hW (by omega) hwprev hmem
      rw [hp] at hind
      have hstep : ‖euclideanIntegerRows W k‖+1 ≤
          (‖euclideanIntegerRows A k‖+1)*(1+((gramPotential A:ℝ)^2+1)*M) := by
        dsimp [W, q]
        rw [rationalIntegerCoefficient_round]
        exact round_reduce_norm_add_one_le A hA k j M hM (hprev j hjk)
      calc
        _ ≤ (‖euclideanIntegerRows W k‖+1)*(1+((gramPotential A:ℝ)^2+1)*M)^n := hind
        _ ≤ ((‖euclideanIntegerRows A k‖+1)*(1+((gramPotential A:ℝ)^2+1)*M))*
            (1+((gramPotential A:ℝ)^2+1)*M)^n :=
          mul_le_mul_of_nonneg_right hstep (by positivity)
        _ = _ := by rw [pow_succ]; ring

/-- A single size-reduced row already has the global reduced-row bound; no
condition on later rows is needed. -/
theorem reducedRow_norm_le_potential (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (i : Fin r)
    (hsize : ∀ j : Fin r, j < i → |gsCoefficient (euclideanIntegerRows A) i j| ≤ 1/2) :
    ‖euclideanIntegerRows A i‖ ≤ (r:ℝ)*gramPotential A := by
  have hsum : (∑ j ∈ Finset.Iio i, (gsCoefficient (euclideanIntegerRows A) i j)^2 *
      ‖gramSchmidt ℝ (euclideanIntegerRows A) j‖^2) ≤ (i.val:ℝ)*gramPotential A := by
    calc
      _ ≤ ∑ _j ∈ Finset.Iio i, (gramPotential A:ℝ) := by
        apply Finset.sum_le_sum
        intro j hj
        have hμ := hsize j (Finset.mem_Iio.mp hj)
        have hμsq : (gsCoefficient (euclideanIntegerRows A) i j)^2 ≤ 1 := by
          nlinarith [sq_abs (gsCoefficient (euclideanIntegerRows A) i j),
            abs_nonneg (gsCoefficient (euclideanIntegerRows A) i j)]
        exact (mul_le_mul_of_nonneg_right hμsq (sq_nonneg _)).trans
          (by simpa only [one_mul] using gramSchmidt_sq_le_potential A hA j)
      _ = _ := by simp
  have hi : (i.val:ℝ)+1 ≤ r := by exact_mod_cast i.isLt
  have hown := gramSchmidt_sq_le_potential A hA i
  have hnorm := norm_sq_eq_gs_sq_add (euclideanIntegerRows A) i
  have hs : ‖euclideanIntegerRows A i‖^2 ≤ (r:ℝ)*gramPotential A := by
    nlinarith [mul_le_mul_of_nonneg_right hi (Nat.cast_nonneg (gramPotential A): (0:ℝ)≤gramPotential A)]
  have hr : (1:ℝ) ≤ r := by exact_mod_cast (show 1 ≤ r by have := i.isLt; omega)
  have hp : (1:ℝ) ≤ gramPotential A := by exact_mod_cast (gramPotential_pos A hA : 1 ≤ gramPotential A)
  have hprod : (1:ℝ) ≤ (r:ℝ)*gramPotential A := one_le_mul_of_one_le_of_one_le hr hp
  nlinarith [norm_nonneg (euclideanIntegerRows A i)]

/-- A natural factor whose logarithm controls growth in each inner update. -/
def partialReductionGrowth (r P : ℕ) : ℕ := 1+(P^2+1)*(r*P)

/-- The actual inner trace starting after the first `k` rows of the outer sweep.
Earlier-row bounds are derived from those previous reductions. -/
theorem outerSweep_innerTrace_norm_bound (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k : Fin r)
    (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace (rationalReduceIntegerAll A k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl) :
    ‖euclideanIntegerRows B k‖+1 ≤ (‖euclideanIntegerRows A k‖+1)*
      (partialReductionGrowth r (gramPotential A):ℝ)^k.val := by
  let C := roundReduceIntegerAll A k.val (Nat.le_of_lt k.isLt)
  obtain ⟨hC, _, hsame, hsize⟩ := roundReduceAll_spec (euclideanIntegerRows A)
    ((euclideanIntegerRows_independent_iff A).mpr hA) k.val (Nat.le_of_lt k.isLt)
  rw [← euclideanIntegerRows_roundReduceIntegerAll] at hC hsame hsize
  have hC' : LinearIndependent ℝ (fun i j => (C i j:ℝ)) :=
    (euclideanIntegerRows_independent_iff C).mp hC
  have hp : gramPotential C = gramPotential A := gramPotential_roundReduceIntegerAll A _ _
  have hprev : ∀ j : Fin r, j < k → ‖euclideanIntegerRows C j‖ ≤ (r:ℝ)*gramPotential A := by
    intro j hjk
    rw [← hp]
    exact reducedRow_norm_le_potential C hC' j (fun l hlj => hsize j l hjk hlj)
  rw [rationalReduceIntegerAll_eq] at hB
  have hbound := integerRowSweepTrace_norm_bound C hC' k k.val le_rfl
    ((r:ℝ)*gramPotential A) (by positivity) hprev B hB
  have he : euclideanIntegerRows C k = euclideanIntegerRows A k := hsame k le_rfl
  rw [hp, he] at hbound
  simpa only [partialReductionGrowth, Nat.cast_add, Nat.cast_one, Nat.cast_mul,
    Nat.cast_pow] using hbound

/-- Input coordinate height controls the initial row norm without a positive
width assumption. This also covers an empty coordinate type. -/
theorem integerRow_norm_add_one_le_height (A : Matrix (Fin r) (Fin d) ℤ)
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r) :
    ‖euclideanIntegerRows A k‖+1 ≤ ((d*H^2+2:ℕ):ℝ) := by
  have hs : ‖euclideanIntegerRows A k‖^2 ≤ (d:ℝ)*(H:ℝ)^2 := by
    rw [PiLp.norm_sq_eq_of_L2]
    calc
      _ ≤ ∑ _j : Fin d, (H:ℝ)^2 := by
        apply Finset.sum_le_sum
        intro j _
        have hj : |(A k j:ℝ)| ≤ (H:ℝ) := by exact_mod_cast hH k j
        change |(A k j:ℝ)|^2 ≤ _
        exact pow_le_pow_left₀ (abs_nonneg _) hj 2
      _ = _ := by simp
  push_cast
  nlinarith [sq_nonneg (‖euclideanIntegerRows A k‖-1/2)]

/-- An explicit integer-coordinate bound for every intermediate matrix in the
inner loop of the actual rational full sweep. -/
theorem outerSweep_innerTrace_entry_bound (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r)
    (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace (rationalReduceIntegerAll A k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl) (j : Fin d) :
    (B k j).natAbs ≤ (d*H^2+2)*(partialReductionGrowth r (gramPotential A))^r := by
  have hnorm := outerSweep_innerTrace_norm_bound A hA k B hB
  have hinput := integerRow_norm_add_one_le_height A H hH k
  have hcoord : |(B k j:ℝ)| ≤ ‖euclideanIntegerRows B k‖ := by
    simpa only [euclideanIntegerRows, Matrix.map_apply, Real.norm_eq_abs] using
      PiLp.norm_apply_le (euclideanIntegerRows B k) j
  have hg : (1:ℝ) ≤ partialReductionGrowth r (gramPotential A) := by
    exact_mod_cast (show 1 ≤ partialReductionGrowth r (gramPotential A) by
      unfold partialReductionGrowth; omega)
  have hpower := pow_le_pow_right₀ hg (Nat.le_of_lt k.isLt)
  have hmul := mul_le_mul hinput hpower (by positivity)
    (by positivity : (0:ℝ) ≤ (d*H^2+2:ℕ))
  have hb : |(B k j:ℝ)| ≤ ((d*H^2+2)*(partialReductionGrowth r (gramPotential A))^r:ℕ) := by
    push_cast at hmul ⊢
    linarith
  rw [← Int.cast_abs, ← Int.natCast_natAbs, Int.cast_natCast] at hb
  exact_mod_cast hb

/-- The magnitude bits of every treated-row coordinate are linear in the
number of row updates times the bits of a fixed polynomial in input height
and Gram potential. -/
theorem outerSweep_innerTrace_entry_bits (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r)
    (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace (rationalReduceIntegerAll A k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl) (j : Fin d) :
    (B k j).natAbs.size ≤ (r+1)*(d*H^2+2+partialReductionGrowth r (gramPotential A)).size := by
  have hb := outerSweep_innerTrace_entry_bound A hA H hH k B hB j
  apply nat_size_le_of_le_pow (by omega : 0 < r+1)
  calc
    _ ≤ (d*H^2+2)*partialReductionGrowth r (gramPotential A)^r := hb
    _ ≤ (d*H^2+2+partialReductionGrowth r (gramPotential A))*
        (d*H^2+2+partialReductionGrowth r (gramPotential A))^r :=
      Nat.mul_le_mul (by omega) (Nat.pow_le_pow_left (by omega) _)
    _ = _ := (pow_succ' _ _).symm

/-- At the beginning of any outer-loop iteration, earlier rows already obey
the reduced height bound and all later rows retain their input entries. -/
theorem partialIntegerSweep_entry_le_max (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (n : ℕ) (hn : n ≤ r)
    (i : Fin r) (j : Fin d) :
    (rationalReduceIntegerAll A n hn i j).natAbs ≤ max H (r*gramPotential A) := by
  rw [rationalReduceIntegerAll_eq]
  let C := roundReduceIntegerAll A n hn
  obtain ⟨hC, _, hsame, hsize⟩ := roundReduceAll_spec (euclideanIntegerRows A)
    ((euclideanIntegerRows_independent_iff A).mpr hA) n hn
  rw [← euclideanIntegerRows_roundReduceIntegerAll] at hC hsame hsize
  have hC' : LinearIndependent ℝ (fun i j => (C i j:ℝ)) :=
    (euclideanIntegerRows_independent_iff C).mp hC
  have hp : gramPotential C = gramPotential A := gramPotential_roundReduceIntegerAll A n hn
  change (C i j).natAbs ≤ _
  by_cases hi : i.val < n
  · have hb := reducedRow_norm_le_potential C hC' i (fun l hli => hsize i l hi hli)
    rw [hp] at hb
    have hcoord : |(C i j:ℝ)| ≤ ‖euclideanIntegerRows C i‖ := by
      simpa only [euclideanIntegerRows, Matrix.map_apply, Real.norm_eq_abs] using
        PiLp.norm_apply_le (euclideanIntegerRows C i) j
    have hreal : ((C i j).natAbs:ℝ) ≤ ((r*gramPotential A:ℕ):ℝ) := by
      rw [Int.cast_natAbs, Int.cast_abs, Nat.cast_mul]
      exact hcoord.trans hb
    have hint : (C i j).natAbs ≤ r*gramPotential A := by exact_mod_cast hreal
    exact hint.trans (le_max_right _ _)
  · have he : euclideanIntegerRows C i = euclideanIntegerRows A i := hsame i (by omega)
    have hij : C i j = A i j := by
      have he' := congrArg (fun x : EuclideanSpace ℝ (Fin d) => x j) he
      change (C i j:ℝ) = (A i j:ℝ) at he'
      exact_mod_cast he'
    rw [hij]
    have hb : (A i j).natAbs ≤ H := by
      have hh := hH i j
      rw [← Int.natCast_natAbs] at hh
      exact_mod_cast hh
    exact hb.trans (le_max_left _ _)

/-- One bound covers every coordinate of every intermediate matrix in every
inner loop of the full sweep, including rows not currently being treated. -/
theorem outerSweep_innerTrace_all_entries (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r)
    (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace (rationalReduceIntegerAll A k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl) (i : Fin r) (j : Fin d) :
    (B i j).natAbs ≤ (H+r*gramPotential A+d*H^2+2)*
      partialReductionGrowth r (gramPotential A)^r := by
  by_cases hi : i = k
  · subst i
    exact (outerSweep_innerTrace_entry_bound A hA H hH k B hB j).trans
      (Nat.mul_le_mul_right _ (by omega))
  · have he := integerRowSweepTrace_unchanged _ k k.val le_rfl B hB i hi
    rw [congrFun he j]
    have hb := partialIntegerSweep_entry_le_max A hA H hH k.val
      (Nat.le_of_lt k.isLt) i j
    have hg : 1 ≤ partialReductionGrowth r (gramPotential A)^r := by
      apply one_le_pow₀
      unfold partialReductionGrowth
      omega
    exact hb.trans ((by omega : max H (r*gramPotential A) ≤
      H+r*gramPotential A+d*H^2+2).trans (Nat.le_mul_of_pos_right _ (by omega)))

/-- Uniform magnitude-bit bound for the entire intermediate integer matrix.
The base is a fixed polynomial in rank, ambient dimension, input height and
potential; the multiplier is only `r+1`. -/
theorem outerSweep_innerTrace_all_entry_bits (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r)
    (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace (rationalReduceIntegerAll A k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl) (i : Fin r) (j : Fin d) :
    (B i j).natAbs.size ≤ (r+1)*
      (H+r*gramPotential A+d*H^2+2+partialReductionGrowth r (gramPotential A)).size := by
  have hb := outerSweep_innerTrace_all_entries A hA H hH k B hB i j
  apply nat_size_le_of_le_pow (by omega : 0 < r+1)
  calc
    _ ≤ (H+r*gramPotential A+d*H^2+2)*partialReductionGrowth r (gramPotential A)^r := hb
    _ ≤ (H+r*gramPotential A+d*H^2+2+partialReductionGrowth r (gramPotential A))*
        (H+r*gramPotential A+d*H^2+2+partialReductionGrowth r (gramPotential A))^r :=
      Nat.mul_le_mul (by omega) (Nat.pow_le_pow_left (by omega) _)
    _ = _ := (pow_succ' _ _).symm

end
end Optss
