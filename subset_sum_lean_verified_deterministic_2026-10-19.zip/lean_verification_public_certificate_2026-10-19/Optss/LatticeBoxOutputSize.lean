import Optss.BooleanLatticeBoxWork

/-!
# Literal output-description size of the lattice box

Both the rational basis columns and the canonical binary widths have a
fixed-rank polynomial bound in the original framed input bits.
-/
namespace Optss
open scoped BigOperators
variable {r m : ℕ}

theorem listStoredVertexWidths_lengths (C : ListBitRationalMatrixData r r)
    (V : ListBitRationalMatrixData r m)
    (hC : ∀ i j,(rectangularListFractionMatrix C i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (N : ℕ) (hN : listStoredRationalBits C+listStoredRationalBits V≤N) (j : Fin r) :
    ((listStoredVertexWidths C V).toVector.get j).length≤(r+1)*(2*N+2) := by
  have hp := constructedListMatrixMul_wellFormed C V hC hV
  have hl := constructedListMatrixMul_lengths C V hC hV N
    (by intro i j; have h := listStoredRationalBits_cell C i j; exact ⟨h.1.trans (by omega),h.2.trans (by omega)⟩)
    (by intro i j; have h := listStoredRationalBits_cell V i j; exact ⟨h.1.trans (by omega),h.2.trans (by omega)⟩)
  rw [listStoredVertexWidths,listMatrixWidthScan_get]
  refine booleanVertexWidth_length _ ?_ _ (by positivity) ?_
  · apply (((constructedListMatrixMul C V).toVector.get j).forall_data_iff BitListFraction.WellFormed).mpr
    intro k
    rw [←rectangularListFractionMatrix_row]
    exact hp j k
  · apply (((constructedListMatrixMul C V).toVector.get j).forall_data_iff (fun q => q.numerator.length≤(r+1)*(2*N+2) ∧ q.denominator.length≤(r+1)*(2*N+2))).mpr
    intro k
    rw [←rectangularListFractionMatrix_row]
    exact hl j k

noncomputable def computedBasisWidthLength (r : ℕ) : Polynomial ℕ :=
  Polynomial.C (r+1)*(2*computedBasisIntermediateSize r+2)

theorem computedBasisWidths_lengths (B : ListBitRationalMatrixData r r)
    (V : ListBitRationalMatrixData r m)
    (hB : ∀ i j,(rectangularListFractionMatrix B i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (N : ℕ) (hN : listStoredRationalBits B+listStoredRationalBits V≤N) (j : Fin r) :
    ((computedBasisWidths B V).toVector.get j).length≤(computedBasisWidthLength r).eval N := by
  have hb : listStoredRationalBits B≤N := by omega
  have hv : listStoredRationalBits V≤N := by omega
  have hinv := constructedListMatrixInverse_bits B hB
  have htotal : listStoredRationalBits (constructedListMatrixInverse B)+listStoredRationalBits V≤
      (computedBasisIntermediateSize r).eval N := by
    simp only [computedBasisIntermediateSize,Polynomial.eval_add,Polynomial.eval_C,
      Polynomial.eval_mul,Polynomial.eval_ofNat,Polynomial.eval_X,Polynomial.eval_one]
    exact (Nat.add_le_add hinv hv).trans (by gcongr)
  simpa only [computedBasisWidths,computedBasisWidthLength,Polynomial.eval_mul,Polynomial.eval_C,
    Polynomial.eval_add,Polynomial.eval_ofNat] using
    listStoredVertexWidths_lengths _ V (constructedListMatrixInverse_wellFormed B hB) hV _ htotal j

/-- Row/list framing is counted in both parts of the returned description. -/
def latticeBoxOutputBits (box : BooleanLatticeBoxResult r) : ℕ :=
  listStoredRationalBits box.columns+r+(box.widths.data.map List.length).sum

theorem latticeBoxFinish_columns_bits (A : ListBitRationalMatrixData r r)
    (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetA : (storedRationalMatrix A).det≠0) (hdetG : (storedRationalMatrix G).det≠0)
    (N : ℕ) (hN : listStoredRationalBits A+listStoredRationalBits V+listStoredRationalBits G≤N) :
    listStoredRationalBits (booleanLatticeBoxFinish V (booleanLatticeFrontendFromBasis A V G)).columns≤
      (latticePullbackOutputSize r).eval N := by
  let R := (booleanLatticeFrontendFromBasis A V G).reducedLatticeRows
  let K := (latticePullbackInputSize r).eval N
  have hR := (booleanLatticeFrontendFromBasis_wellFormed A V G hA hV hG hdetA hdetG).2.2.2
  have hRsize : listStoredRationalBits R≤(frontendReducedRowsSize r).eval N :=
    booleanLatticeFrontendFromBasis_reduced_bits A V G hA hG hdetA hdetG N (by omega)
  have hT := listStoredMatrixTranspose_wellFormed R hR
  have hcombined : listStoredRationalBits A+listStoredRationalBits (listStoredMatrixTranspose R)≤K := by
    rw [listStoredMatrixTranspose_square_bits]
    simp only [K,latticePullbackInputSize,Polynomial.eval_add,Polynomial.eval_X]
    exact Nat.add_le_add (by omega) hRsize
  have hlength := constructedListMatrixMul_lengths A (listStoredMatrixTranspose R) hA hT K
    (by intro i j; have h := listStoredRationalBits_cell A i j; exact ⟨h.1.trans (by omega),h.2.trans (by omega)⟩)
    (by intro i j; have h := listStoredRationalBits_cell (listStoredMatrixTranspose R) i j; exact ⟨h.1.trans (by omega),h.2.trans (by omega)⟩)
  have h := listStoredRationalBits_le_of_lengths _ ((r+1)*(2*K+2)) hlength
  change listStoredRationalBits (booleanLatticePullback A R)≤_
  simp only [latticePullbackOutputSize,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_C,Polynomial.eval_one,Polynomial.eval_ofNat]
  change _≤r+r*r*(1+2*(r+1)*(2*K+2))
  convert h using 1; ring

noncomputable def latticeBoxFinishOutputSize (r : ℕ) : Polynomial ℕ :=
  latticePullbackOutputSize r+Polynomial.C r+
    Polynomial.C r*((computedBasisWidthLength r).comp (latticePullbackOutputSize r+Polynomial.X))

theorem latticeBoxFinish_output_bits (A : ListBitRationalMatrixData r r)
    (V : ListBitRationalMatrixData r m) (G : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetA : (storedRationalMatrix A).det≠0) (hdetG : (storedRationalMatrix G).det≠0)
    (N : ℕ) (hN : listStoredRationalBits A+listStoredRationalBits V+listStoredRationalBits G≤N) :
    latticeBoxOutputBits (booleanLatticeBoxFinish V (booleanLatticeFrontendFromBasis A V G))≤
      (latticeBoxFinishOutputSize r).eval N := by
  let out := booleanLatticeFrontendFromBasis A V G
  let B := booleanLatticePullback A out.reducedLatticeRows
  have hR := (booleanLatticeFrontendFromBasis_wellFormed A V G hA hV hG hdetA hdetG).2.2.2
  have hB := constructedListMatrixMul_wellFormed A _ hA (listStoredMatrixTranspose_wellFormed _ hR)
  have hsize : listStoredRationalBits B≤(latticePullbackOutputSize r).eval N :=
    latticeBoxFinish_columns_bits A V G hA hV hG hdetA hdetG N hN
  have hw := computedBasisWidths_lengths B V hB hV ((latticePullbackOutputSize r).eval N+N)
    (Nat.add_le_add hsize (by omega))
  have hs : ((computedBasisWidths B V).data.map List.length).sum≤
      r*(computedBasisWidthLength r).eval ((latticePullbackOutputSize r).eval N+N) := by
    have h := List.sum_le_card_nsmul ((computedBasisWidths B V).data.map List.length)
      ((computedBasisWidthLength r).eval ((latticePullbackOutputSize r).eval N+N)) (by
        intro z hz
        obtain ⟨word,hm,rfl⟩ := List.mem_map.mp hz
        exact ((computedBasisWidths B V).forall_data_iff (fun word => word.length≤_)).mpr hw word hm)
    simpa only [List.length_map,(computedBasisWidths B V).length_eq,nsmul_eq_mul] using h
  change listStoredRationalBits B+r+((computedBasisWidths B V).data.map List.length).sum≤_
  simpa only [latticeBoxFinishOutputSize,Polynomial.eval_add,Polynomial.eval_C,
    Polynomial.eval_mul,Polynomial.eval_comp,Polynomial.eval_X] using Nat.add_le_add (Nat.add_le_add_right hsize r) hs

noncomputable def booleanLatticeBoxOutputSize (r : ℕ) : Polynomial ℕ :=
  (latticeBoxFinishOutputSize r).comp (selectedVertexMatrixSize r+Polynomial.X)

theorem booleanLatticeBox_output_bits (V : ListBitRationalMatrixData r m)
    (G : ListBitRationalMatrixData r r)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hG : ∀ i j,(rectangularListFractionMatrix G i j).WellFormed)
    (hdetG : (storedRationalMatrix G).det≠0)
    (hspan : Submodule.span ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))=⊤)
    (box : BooleanLatticeBoxResult r) (hbox : booleanLatticeBox V G=some box) :
    latticeBoxOutputBits box≤(booleanLatticeBoxOutputSize r).eval
      (listStoredRationalBits V+listStoredRationalBits G) := by
  let N := listStoredRationalBits V+listStoredRationalBits G
  cases he : bitSelectedVertexMatrix V with
  | none => simp [booleanLatticeBox,booleanLatticeFrontend,he] at hbox
  | some A =>
    have hA := bitSelectedVertexMatrix_wellFormed V hV A he
    have hdetA := bitSelectedVertexMatrix_det_ne_zero V hV hspan A he
    have hAsize : listStoredRationalBits A≤(selectedVertexMatrixSize r).eval N := by
      have hb := bitSelectedVertexMatrix_lengths V N (by
        intro i j
        have h := listStoredRationalBits_cell V i j
        exact ⟨h.1.trans (by dsimp [N]; omega),h.2.trans (by dsimp [N]; omega)⟩) A he
      simpa only [selectedVertexMatrixSize,Polynomial.eval_add,Polynomial.eval_mul,
        Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_one,Polynomial.eval_ofNat] using
        listStoredRationalBits_le_of_lengths A N hb
    simp only [booleanLatticeBox,booleanLatticeFrontend,he,Option.map_some] at hbox
    replace hbox := Option.some.inj hbox
    rw [←hbox]
    simpa only [booleanLatticeBoxOutputSize,Polynomial.eval_comp,Polynomial.eval_add,Polynomial.eval_X] using
      latticeBoxFinish_output_bits A V G hA hV hG hdetA hdetG
        ((selectedVertexMatrixSize r).eval N+N) (by
          rw [Nat.add_assoc]
          exact Nat.add_le_add_right hAsize N)
end Optss
