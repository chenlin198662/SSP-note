import Optss.LevUnorderedDensity
import Optss.DenseIntervalFilling

/-!
# Actual long intervals in sums of aperiodic integer sets

The interval is obtained by an explicit alternating partition of the
ordered diameters and the proved density inequalities. No interval
existence or concentration conclusion is assumed.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

private theorem lev_range_sum {M : Type*} [AddCommMonoid M] (f : ℕ → M) (k : ℕ) :
    ((List.range k).map f).sum = ∑ i ∈ Finset.range k, f i := by
  induction k with
  | zero => simp
  | succ k ih => simp [List.range_succ, Finset.sum_range_succ, ih]

/-- Any normalized list lies in its actual summed diameter interval. -/
theorem lev_list_subset_interval (L : List (Finset ℤ × ℕ))
    (hA : ∀ p ∈ L, LevNormalized p.1 p.2) :
    (L.map Prod.fst).sum ⊆ Finset.Icc 0 (L.map (fun p => (p.2 : ℤ))).sum := by
  obtain ⟨A, l, hm, hl, hs, hd⟩ := lev_sorted_enumeration L
  rw [← hs, ← hd]
  exact levPrefixSum_subset_interval A l L.length (fun i hi => (hA _ (hm i hi)).1)

/-- Merge the two dense groups. The balance hypothesis is about their
actual input diameters, and is supplied by the alternating partition below. -/
theorem lev_two_group_interval (L₁ L₂ : List (Finset ℤ × ℕ)) (n k W : ℕ)
    (hn : 3 ≤ n) (h₁ : L₁.length = k) (h₂ : L₂.length = k + 1)
    (hA : ∀ p ∈ L₁ ++ L₂, LevNormalized p.1 p.2)
    (hcard : ∀ p ∈ L₁ ++ L₂, n ≤ p.1.card)
    (hwidth : ∀ p ∈ L₁ ++ L₂, p.2 ≤ W) (hWn : n - 1 ≤ W)
    (hW : (W : ℤ) - 1 ≤ (k + 1 : ℕ) * ((n : ℤ) - 2))
    (hbalance : |(L₁.map (fun p => (p.2 : ℤ))).sum -
      (L₂.map (fun p => (p.2 : ℤ))).sum| ≤ W) :
    ∃ a b : ℤ, Finset.Icc a b ⊆ ((L₁ ++ L₂).map Prod.fst).sum ∧
      2 * (k + 1 : ℕ) * ((n : ℤ) - 1) - W ≤ b - a ∧ (W : ℤ) ≤ b - a := by
  let S₁ := (L₁.map Prod.fst).sum
  let S₂ := (L₂.map Prod.fst).sum
  let D₁ := (L₁.map (fun p => (p.2 : ℤ))).sum
  let D₂ := (L₂.map (fun p => (p.2 : ℤ))).sum
  have hd₁ := lev_list_density_bound_endpoint L₁ n W hn
    (fun p hp => hA p (List.mem_append_left _ hp))
    (fun p hp => hcard p (List.mem_append_left _ hp))
    (fun p hp => hwidth p (List.mem_append_left _ hp)) hWn (by simpa [h₁] using hW)
  have hd₂ := lev_list_density_bound L₂ n hn
    (fun p hp => hA p (List.mem_append_right _ hp))
    (fun p hp => hcard p (List.mem_append_right _ hp))
    (fun p hp => by have := hwidth p (List.mem_append_right _ hp); rw [h₂]; omega)
  change D₁ + (L₁.length + 1 : ℕ) * ((n : ℤ) - 1) - W + 2 ≤ 2 * (S₁.card : ℤ) at hd₁
  change D₂ + (L₂.length : ℤ) * ((n : ℤ) - 1) + 2 ≤ 2 * (S₂.card : ℤ) at hd₂
  rw [h₁] at hd₁
  rw [h₂] at hd₂
  have hC : (W : ℤ) ≤ (k + 1 : ℕ) * ((n : ℤ) - 1) := by
    push_cast at hW ⊢
    nlinarith
  change |D₁ - D₂| ≤ W at hbalance
  rw [abs_le] at hbalance
  have hdense : max D₁ D₂ ≤ (S₁.card : ℤ) + S₂.card - 2 := by
    apply max_le <;> linarith
  have hD₁ : 0 ≤ D₁ := List.sum_nonneg (by intro x hx; obtain ⟨p, hp, rfl⟩ := List.mem_map.mp hx; positivity)
  have hD₂ : 0 ≤ D₂ := List.sum_nonneg (by intro x hx; obtain ⟨p, hp, rfl⟩ := List.mem_map.mp hx; positivity)
  have hfill := dense_interval_subset_sum S₁ S₂ D₁ D₂ hD₁ hD₂
    (lev_list_subset_interval L₁ (fun p hp => hA p (List.mem_append_left _ hp)))
    (lev_list_subset_interval L₂ (fun p hp => hA p (List.mem_append_right _ hp))) hdense
  refine ⟨D₁ + D₂ - ((S₁.card : ℤ) + S₂.card - 2), (S₁.card : ℤ) + S₂.card - 2, ?_, ?_, ?_⟩
  · simpa [List.map_append, List.sum_append, S₁, S₂] using hfill
  · linarith
  · linarith

private theorem lev_alternating_sum {M : Type*} [AddCommMonoid M] (a : ℕ → M) (k : ℕ) :
    (∑ i ∈ Finset.range (2 * k + 1), a i) =
      (∑ i ∈ Finset.range k, a (2 * i + 1)) +
      (∑ i ∈ Finset.range (k + 1), a (2 * i)) := by
  induction k with
  | zero => simp
  | succ k ih =>
    have he : 2 * (k + 1) + 1 = (2 * k + 1) + 1 + 1 := by omega
    rw [he, Finset.sum_range_succ, Finset.sum_range_succ, ih]
    simp only [Finset.sum_range_succ]
    have he' : 2 * k + 1 + 1 = 2 * (k + 1) := by omega
    rw [he']
    simp only [add_assoc, add_left_comm, add_comm]

private theorem lev_alternating_balance (l : ℕ → ℕ) (k W : ℕ)
    (hl : MonotoneOn l (Finset.range (2 * k + 1)))
    (hW : ∀ i < 2 * k + 1, l i ≤ W) :
    |(∑ i ∈ Finset.range k, (l (2 * i + 1) : ℤ)) -
      (∑ i ∈ Finset.range (k + 1), (l (2 * i) : ℤ))| ≤ W := by
  have hp := ordered_diameter_pair_excess (fun i => -(l i : ℤ)) k (by
    intro i j hij hj
    have hm := hl (Finset.mem_range.mpr (by omega)) (Finset.mem_range.mpr (by omega)) hij
    simp only [neg_le_neg_iff]
    exact_mod_cast hm)
  have hz : 0 ≤ ∑ i ∈ Finset.range k, ((l (2 * i + 1) : ℤ) - l (2 * i)) := by
    apply Finset.sum_nonneg
    intro i hi
    have hi' := Finset.mem_range.mp hi
    have hm := hl (Finset.mem_range.mpr (by omega)) (Finset.mem_range.mpr (by omega))
      (show 2 * i ≤ 2 * i + 1 by omega)
    exact sub_nonneg.mpr (by exact_mod_cast hm)
  simp only [neg_sub_neg] at hp
  rw [Finset.sum_sub_distrib] at hp hz
  have hlast := hW (2 * k) (by omega)
  rw [Finset.sum_range_succ, abs_le]
  constructor <;> omega

/-- Lev's odd-summand interval theorem for actual normalized input sets.
The number of summands is `2*k+1`; the displayed width condition is the
integer form of the source's ceiling parameter. -/
theorem lev_list_long_interval (L : List (Finset ℤ × ℕ)) (n k W : ℕ)
    (hn : 3 ≤ n) (hlen : L.length = 2 * k + 1)
    (hA : ∀ p ∈ L, LevNormalized p.1 p.2)
    (hcard : ∀ p ∈ L, n ≤ p.1.card)
    (hwidth : ∀ p ∈ L, p.2 ≤ W) (hWn : n - 1 ≤ W)
    (hW : (W : ℤ) - 1 ≤ (k + 1 : ℕ) * ((n : ℤ) - 2)) :
    ∃ a b : ℤ, Finset.Icc a b ⊆ (L.map Prod.fst).sum ∧
      2 * (k + 1 : ℕ) * ((n : ℤ) - 1) - W ≤ b - a ∧ (W : ℤ) ≤ b - a := by
  obtain ⟨A, l, hm, hl, hs, hd⟩ := lev_sorted_enumeration L
  rw [hlen] at hm hl hs hd
  let L₁ := (List.range k).map (fun i => (A (2 * i + 1), l (2 * i + 1)))
  let L₂ := (List.range (k + 1)).map (fun i => (A (2 * i), l (2 * i)))
  have hmem : ∀ p ∈ L₁ ++ L₂, p ∈ L := by
    intro p hp
    rcases List.mem_append.mp hp with hp | hp
    · obtain ⟨i, hi, rfl⟩ := List.mem_map.mp hp
      exact hm _ (by have := List.mem_range.mp hi; omega)
    · obtain ⟨i, hi, rfl⟩ := List.mem_map.mp hp
      exact hm _ (by have := List.mem_range.mp hi; omega)
  have hbal : |(L₁.map (fun p => (p.2 : ℤ))).sum -
      (L₂.map (fun p => (p.2 : ℤ))).sum| ≤ W := by
    simpa [L₁, L₂, List.map_map, lev_range_sum, Function.comp_def] using
      lev_alternating_balance l k W hl (fun i hi => hwidth _ (hm i hi))
  obtain ⟨a, b, hab, hlen', hlong⟩ := lev_two_group_interval L₁ L₂ n k W hn
    (by simp [L₁]) (by simp [L₂])
    (fun p hp => hA p (hmem p hp)) (fun p hp => hcard p (hmem p hp))
    (fun p hp => hwidth p (hmem p hp)) hWn hW hbal
  refine ⟨a, b, ?_, hlen', hlong⟩
  have hsum : ((L₁ ++ L₂).map Prod.fst).sum = (L.map Prod.fst).sum := by
    rw [← hs]
    simp only [L₁, L₂, List.map_append, List.sum_append, List.map_map, Function.comp_def,
      levPrefixSum, lev_range_sum]
    exact (lev_alternating_sum A k).symm
  rwa [hsum] at hab

end
end Optss
