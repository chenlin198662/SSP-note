import Optss.CountNewton
import Optss.CountPreprocessing

/-!
# Signed correction computation without copy expansion

The finite support uses per-orthant tables built from the original type counts.
An index equivalence connects it to the verified labelled construction. Copy
labels occur only in that proof, never in the definition of the computation.
Cartesian recombination is exact but does not claim fast convolution costs.
-/

namespace Optss
open scoped BigOperators
noncomputable section

theorem selectionPolynomial_equiv {α β R : Type*} [Fintype α] [Fintype β]
    [CommRing R] (e : α ≃ β) (a : β → R) :
    selectionPolynomial (fun i => a (e i)) = selectionPolynomial a :=
  e.prod_comp (fun i => 1 + Polynomial.C (a i) * Polynomial.X)

theorem elementaryCoefficient_equiv {α β R : Type*} [Fintype α] [Fintype β]
    [CommRing R] (e : α ≃ β) (a : β → R) (k : ℕ) :
    elementaryCoefficient (fun i => a (e i)) k = elementaryCoefficient a k := by
  rw [← selectionPolynomial_coeff, selectionPolynomial_equiv, selectionPolynomial_coeff]

theorem newtonTruncatedSupport_equiv {α β σ : Type*} [Fintype α] [Fintype β]
    (e : α ≃ β) (u : β → σ →₀ ℕ) (Δ : σ →₀ ℕ) (kcap : ℕ) :
    newtonTruncatedSupport (fun i => u (e i)) Δ kcap = newtonTruncatedSupport u Δ kcap := by
  unfold newtonTruncatedSupport
  apply Finset.sum_congr rfl
  intro k _
  rw [newtonTruncatedCoefficient_eq, newtonTruncatedCoefficient_eq]
  congr 1
  exact elementaryCoefficient_equiv e (fun i => MvPolynomial.monomial (u i) (1 : ℤ)) k

variable {ι : Type*} [Fintype ι] {d : ℕ}

/-- Restricting types to an orthant and then labelling copies gives exactly the
same available labels as restricting the original copies to that orthant. -/
def orthantCopyEquiv (v : ι → IntVec d) (c : ι → ℕ) (ε : Fin d → Bool) :
    (Σ i : {i // coordinateOrthant (v i) = ε}, Fin (c i)) ≃
      {p : CopyIndex c // coordinateOrthant (expandedCopy v c p) = ε} where
  toFun p := ⟨⟨p.1.val, p.2⟩, p.1.property⟩
  invFun p := ⟨⟨p.val.1, p.property⟩, p.val.2⟩
  left_inv p := by rcases p with ⟨⟨i, hi⟩, j⟩; rfl
  right_inv p := by rcases p with ⟨⟨i, j⟩, hi⟩; rfl

/-- Equality of the actual direct-count and expanded local support polynomials. -/
theorem countOrthantPolynomial_eq_copies (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (ε : Fin d → Bool) :
    countNewtonSupport Δ (fun i : {i // coordinateOrthant (v i) = ε} => c i)
        (fun i => absoluteExponent (v i)) kcap =
      newtonTruncatedSupport
        (fun p : {p : CopyIndex c // coordinateOrthant (expandedCopy v c p) = ε} =>
          absoluteExponent (expandedCopy v c p)) Δ kcap := by
  classical
  rw [countNewtonSupport_eq_copies]
  exact newtonTruncatedSupport_equiv (orthantCopyEquiv v c ε)
    (fun p => absoluteExponent (expandedCopy v c p)) Δ kcap

/-- Finite signed support from direct-count Newton tables. Each polynomial is
computed on types, without creating individual-copy indices. -/
def directCountCorrectionSupport (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) : Finset (IntVec d) := by
  classical
  exact ((Fintype.piFinset (fun ε : Fin d → Bool =>
    (countNewtonSupport Δ (fun i : {i // coordinateOrthant (v i) = ε} => c i)
      (fun i => absoluteExponent (v i)) kcap).support)).image
        (fun e => ∑ ε, orthantDecode ε (e ε))).filter
          (fun t => InBox (fun j => (Δ j : ℤ)) t)

theorem directCountCorrectionSupport_eq_copies (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) :
    directCountCorrectionSupport v c Δ kcap =
      finiteBoundedCorrectionSupport (expandedCopy v c) Δ kcap := by
  classical
  unfold directCountCorrectionSupport finiteBoundedCorrectionSupport
  simp_rw [countOrthantPolynomial_eq_copies]

/-- The direct-count, preprocessed computation meets the manuscript's exact
soundness and required-witness completeness statement. Its remaining complexity
obligations concern representation, preprocessing and fast arithmetic costs. -/
theorem directCountCorrectionSupport_correct (v : ι → IntVec d) (c : ι → ℕ)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) :
    let c' := correctionCapacity v c (fun j => (Δ j : ℤ)) kcap
    let S := directCountCorrectionSupport v c' Δ kcap
    (∀ t ∈ S, t ∈ countSums v (fun i => (c i : ℤ)) ∧ InBox (fun j => (Δ j : ℤ)) t) ∧
    (∀ x, BoundedCounts (fun i => (c i : ℤ)) x → (∑ i, x i) ≤ kcap →
      CountAbsoluteBudget v x (fun j => (Δ j : ℤ)) → weightedSum v x ∈ S) := by
  dsimp only
  rw [directCountCorrectionSupport_eq_copies]
  exact preprocessed_correctionSupport_correct v c Δ kcap

end
end Optss
