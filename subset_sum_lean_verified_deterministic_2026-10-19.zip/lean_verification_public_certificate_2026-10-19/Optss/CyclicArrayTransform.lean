import Optss.ApproximateCyclicConvolution

/-! Function/array interfaces and linearity for the actual materialized
radix-two transform. These maps are interpretations, not array rebuilding
steps in the integer answer routine. -/
namespace Optss

def cyclicArrayIndex (n : ℕ) (x : ZMod (2^n)) : Fin (2^n) := ⟨x.val,x.val_lt⟩

def cyclicArrayValue {R : Type*} (n : ℕ) (A : Vector R (2^n)) (x : ZMod (2^n)) : R :=
  A.get (cyclicArrayIndex n x)

theorem cyclicArrayValue_data {R : Type*} (n : ℕ) (f : ZMod (2^n) → R) :
    cyclicArrayValue n (cyclicVectorData n f)=f := by
  funext x
  simp [cyclicArrayValue,cyclicArrayIndex,cyclicVectorData,vector_get_ofFn]

theorem cyclicVectorData_value {R : Type*} (n : ℕ) (A : Vector R (2^n)) :
    cyclicVectorData n (cyclicArrayValue n A)=A := by
  apply Vector.ext
  intro i hi
  change (Vector.ofFn _).get ⟨i,hi⟩=A.get ⟨i,hi⟩
  rw [vector_get_ofFn]
  unfold cyclicArrayValue
  congr 1
  apply Fin.ext
  simpa only [cyclicArrayIndex,ZMod.val_natCast] using Nat.mod_eq_of_lt hi

def vectorComplexScale {m : ℕ} (c : ℂ) (A : Vector ℂ m) : Vector ℂ m :=
  Vector.ofFn fun j => c*A.get j

theorem vectorComplexScale_even (n : ℕ) (c : ℂ) (A : Vector ℂ (2^(n+1))) :
    radixEvenData n (vectorComplexScale c A)=vectorComplexScale c (radixEvenData n A) := by
  apply Vector.ext
  intro i hi
  change (Vector.ofFn _).get ⟨i,hi⟩=(Vector.ofFn _).get ⟨i,hi⟩
  simp only [vector_get_ofFn,radixEvenData,vectorComplexScale]

theorem vectorComplexScale_odd (n : ℕ) (c : ℂ) (A : Vector ℂ (2^(n+1))) :
    radixOddData n (vectorComplexScale c A)=vectorComplexScale c (radixOddData n A) := by
  apply Vector.ext
  intro i hi
  change (Vector.ofFn _).get ⟨i,hi⟩=(Vector.ofFn _).get ⟨i,hi⟩
  simp only [vector_get_ofFn,radixOddData,vectorComplexScale]

theorem radixTwoTransform_scale (T : ℕ → ℕ → ℂ) (n : ℕ) (c : ℂ) (A : Vector ℂ (2^n)) :
    radixTwoTransform T n (vectorComplexScale c A)=vectorComplexScale c (radixTwoTransform T n A) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [radixTwoTransform,vectorComplexScale_even,vectorComplexScale_odd,ih]
    apply Vector.ext
    intro i hi
    change (Vector.ofFn _).get ⟨i,hi⟩=(Vector.ofFn _).get ⟨i,hi⟩
    simp only [vector_get_ofFn,vectorComplexScale]
    ring

def cyclicArrayTransform (n : ℕ) (T : ℕ → ℕ → ℂ) (f : ZMod (2^n) → ℂ) :
    ZMod (2^n) → ℂ := cyclicArrayValue n (radixTwoTransform T n (cyclicVectorData n f))

theorem cyclicArrayTransform_scale (n : ℕ) (T : ℕ → ℕ → ℂ)
    (c : ℂ) (f : ZMod (2^n) → ℂ) :
    cyclicArrayTransform n T (fun j => c*f j)=fun j => c*cyclicArrayTransform n T f j := by
  have he : cyclicVectorData n (fun j => c*f j)=vectorComplexScale c (cyclicVectorData n f) := by
    apply Vector.ext
    intro i hi
    change (Vector.ofFn _).get ⟨i,hi⟩=(Vector.ofFn _).get ⟨i,hi⟩
    simp only [vector_get_ofFn,cyclicVectorData,vectorComplexScale]
  funext x
  unfold cyclicArrayTransform
  rw [he,radixTwoTransform_scale]
  simp only [cyclicArrayValue,vectorComplexScale,vector_get_ofFn]

theorem cyclicArrayTransform_error (n : ℕ) (T : ℕ → ℕ → ℂ) (ε : ℝ)
    (hε : 0≤ε) (hε₁ : ε≤1)
    (hT : ∀ l<n, ∀ k, ‖T l k-cyclicRadixTwiddle n l k‖≤ε)
    (f : ZMod (2^n) → ℂ) (B : ℝ) (hB : 0≤B) (hf : ∀ j, ‖f j‖≤B)
    (x : ZMod (2^n)) :
    ‖cyclicArrayTransform n T f x-ZMod.dft f x‖≤((n : ℝ)*3^n*ε)*B := by
  have h := approximate_radixTwo_cyclic_dft n f T B ε hB hε hε₁ hf hT (cyclicArrayIndex n x)
  simpa only [cyclicArrayIndex,ZMod.natCast_zmod_val,cyclicArrayTransform,cyclicArrayValue] using h

end Optss
