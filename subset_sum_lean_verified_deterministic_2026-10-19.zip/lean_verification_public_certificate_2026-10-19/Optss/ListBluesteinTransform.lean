import Optss.FourierListPadding
import Optss.DyadicDFTPrecision

/-! Sequential-list Bluestein evaluation. Chirps are cached once, the input
and mirrored kernel are padded by structural fuel, and the output window is
selected by dropping a list prefix. All stored arithmetic is Boolean integer
arithmetic; the decoding maps below occur only in correctness theorems. -/
namespace Optss

set_option maxRecDepth 4096

def bitFourierZero : BitFourierInteger := ⟨⟨false,[]⟩,⟨false,[]⟩⟩

theorem bitFourierZero_value : bitFourierZero.value=fourierIntegerZero := rfl

def listBluesteinTransform (depth : List Bool) (p : ℕ) (input : List Bool) : List BitFourierInteger :=
  let chirps := listBluesteinChirps input p
  let negative := chirps.map Prod.fst
  let positive := chirps.map Prod.snd
  let fuel := radixListFuel depth
  let A := fourierListPad bitFourierZero fuel
    (List.zipWith (fun b z => if b then z else bitFourierZero) input negative)
  let B := fourierListPad bitFourierZero fuel (positive.reverse++positive.tail)
  let C := listCyclicConvolution depth p A B
  List.zipWith bitFourierMul negative (fourierListDrop input.tail C)

theorem chirp_mirror_ofFn (N p : ℕ) [NeZero N] :
    (List.ofFn (fun k : Fin N => dyadicCharacterInteger ((k.val : ZMod (2*N))^2) p)).reverse++
      (List.ofFn (fun k : Fin N => dyadicCharacterInteger ((k.val : ZMod (2*N))^2) p)).tail=
    List.ofFn (fun k : Fin (2*N-1) =>
      dyadicCharacterInteger ((((k.val : ℤ)-(N : ℤ)+1)^2 : ℤ) : ZMod (2*N)) p) := by
  have hN : 0 < N := NeZero.pos N
  apply List.ext_getElem
  · simp only [List.length_append,List.length_reverse,List.length_ofFn,List.length_tail]
    omega
  · intro i hi hi'
    have hiN : i < 2*N-1 := by simpa only [List.length_ofFn] using hi'
    simp only [List.getElem_ofFn]
    by_cases h : i < N
    · rw [List.getElem_append_left (by simpa only [List.length_reverse,List.length_ofFn] using h)]
      simp only [List.getElem_reverse,List.length_ofFn,List.getElem_ofFn]
      congr 1
      have hi : i ≤ N-1 := by omega
      rw [Nat.cast_sub hi,Nat.cast_sub (by omega : 1 ≤ N)]
      push_cast
      ring
    · rw [List.getElem_append_right (by simpa only [List.length_reverse,List.length_ofFn] using Nat.le_of_not_gt h)]
      simp only [List.length_reverse,List.length_ofFn,List.getElem_tail,List.getElem_ofFn]
      congr 1
      rw [Nat.cast_add,Nat.cast_sub (Nat.le_of_not_gt h)]
      push_cast
      ring

theorem listBluesteinChirps_values (input : List Bool) [NeZero input.length] (p : ℕ) :
    (listBluesteinChirps input p).map (fun q => q.1.value)=
      List.ofFn (fun k : Fin input.length => dyadicCharacterInteger (-(k.val : ZMod (2*input.length))^2) p) ∧
    (listBluesteinChirps input p).map (fun q => q.2.value)=
      List.ofFn (fun k : Fin input.length => dyadicCharacterInteger ((k.val : ZMod (2*input.length))^2) p) := by
  have hM : binaryDigitsValue (false::listLengthDigits input)=2*input.length := by
    simp only [binaryDigitsValue,Bool.toNat_false,listLengthDigits_value,add_zero]
  exact ⟨bitChirpPairs_negative_values _ _ _ hM,bitChirpPairs_positive_values _ _ _ hM⟩

theorem listCyclicConvolution_values (depth : List Bool) (p : ℕ)
    (A B : List BitFourierInteger) (VA VB : Vector FourierInteger (2^depth.length))
    (ha : A.map BitFourierInteger.value=List.ofFn VA.get)
    (hb : B.map BitFourierInteger.value=List.ofFn VB.get) :
    (listCyclicConvolution depth p A B).map BitFourierInteger.value=
      List.ofFn (dyadicCyclicConvolution depth.length p VA VB).get := by
  have hla : A.length=2^depth.length := by
    have h := congrArg List.length ha
    simpa only [List.length_map,List.length_ofFn] using h
  have hlb : B.length=2^depth.length := by
    have h := congrArg List.length hb
    simpa only [List.length_map,List.length_ofFn] using h
  let AA : Vector BitFourierInteger (2^depth.length) := Vector.ofFn fun i => A[i.val]'(by omega)
  let BB : Vector BitFourierInteger (2^depth.length) := Vector.ofFn fun i => B[i.val]'(by omega)
  have hAA : List.ofFn AA.get=A := by
    apply List.ext_getElem
    · simpa only [List.length_ofFn] using hla.symm
    · intro i hi hi'
      simp only [List.getElem_ofFn,AA,vector_get_ofFn]
  have hBB : List.ofFn BB.get=B := by
    apply List.ext_getElem
    · simpa only [List.length_ofFn] using hlb.symm
    · intro i hi hi'
      simp only [List.getElem_ofFn,BB,vector_get_ofFn]
  have hva : bitFourierVectorValue AA=VA := by
    apply Vector.ext
    intro i hi
    have hh := congrArg (fun xs => xs[i]?) ha
    simp only [List.getElem?_map,List.getElem?_ofFn,hi,↓reduceDIte] at hh
    rw [List.getElem?_eq_getElem (by omega : i<A.length)] at hh
    change (bitFourierVectorValue AA).get ⟨i,hi⟩=VA.get ⟨i,hi⟩
    simpa only [bitFourierVectorValue,vector_get_ofFn,AA] using Option.some.inj hh
  have hvb : bitFourierVectorValue BB=VB := by
    apply Vector.ext
    intro i hi
    have hh := congrArg (fun xs => xs[i]?) hb
    simp only [List.getElem?_map,List.getElem?_ofFn,hi,↓reduceDIte] at hh
    rw [List.getElem?_eq_getElem (by omega : i<B.length)] at hh
    change (bitFourierVectorValue BB).get ⟨i,hi⟩=VB.get ⟨i,hi⟩
    simpa only [bitFourierVectorValue,vector_get_ofFn,BB] using Option.some.inj hh
  simpa only [hAA,hBB,hva,hvb] using listCyclicConvolution_eq depth p AA BB

theorem listBluesteinTransform_eq (N : ℕ) [NeZero N] (depth : List Bool) (p : ℕ)
    (f : Vector Bool N) (hpad : 3*N-2≤2^depth.length) :
    (listBluesteinTransform depth p (List.ofFn f.get)).map BitFourierInteger.value=
      List.ofFn (dyadicBluesteinDFT N depth.length p f).get := by
  have hN : 0 < N := NeZero.pos N
  let input := List.ofFn f.get
  let chirps := listBluesteinChirps input p
  let neg := chirps.map Prod.fst
  let pos := chirps.map Prod.snd
  let fuel := radixListFuel depth
  let A := fourierListPad bitFourierZero fuel
    (List.zipWith (fun b z => if b then z else bitFourierZero) input neg)
  let B := fourierListPad bitFourierZero fuel (pos.reverse++pos.tail)
  let VA := cyclicVectorData depth.length (dyadicBluesteinInput N depth.length p f)
  let VB := cyclicVectorData depth.length (dyadicBluesteinKernel N depth.length p)
  haveI : NeZero input.length := ⟨by simpa only [input,List.length_ofFn] using NeZero.ne N⟩
  have hM : binaryDigitsValue (false::listLengthDigits input)=2*N := by
    simp only [binaryDigitsValue,Bool.toNat_false,listLengthDigits_value,add_zero,input,List.length_ofFn]
  have hn : neg.map BitFourierInteger.value=List.ofFn (fun k : Fin N =>
      dyadicCharacterInteger (-(k.val : ZMod (2*N))^2) p) := by
    simpa only [neg,chirps,input,List.map_map,Function.comp_def,List.length_ofFn,Fin.coe_cast] using
      bitChirpPairs_negative_values (false::listLengthDigits input) input p hM
  have hp : pos.map BitFourierInteger.value=List.ofFn (fun k : Fin N =>
      dyadicCharacterInteger ((k.val : ZMod (2*N))^2) p) := by
    simpa only [pos,chirps,input,List.map_map,Function.comp_def,List.length_ofFn,Fin.coe_cast] using
      bitChirpPairs_positive_values (false::listLengthDigits input) input p hM
  have hraw : (List.zipWith (fun b z => if b then z else bitFourierZero) input neg).map
      BitFourierInteger.value=List.ofFn (fun k : Fin N => if f.get k then
        dyadicCharacterInteger (-(k.val : ZMod (2*N))^2) p else fourierIntegerZero) := by
    rw [List.map_zipWith]
    have he (b : Bool) (z : BitFourierInteger) :
        (if b then z else bitFourierZero).value=if b then z.value else fourierIntegerZero := by
      cases b <;> rfl
    simp_rw [he]
    rw [← (List.zipWith_map_right (f := BitFourierInteger.value)
      (g := fun (b : Bool) z => if b then z else fourierIntegerZero)),hn]
    exact fourierList_zipWith_ofFn _ _ _
  have ha : A.map BitFourierInteger.value=List.ofFn VA.get := by
    change (fourierListPad bitFourierZero fuel _).map _=_
    rw [fourierListPad_map,bitFourierZero_value,hraw]
    apply List.ext_getElem
    · simp only [fourierListPad_length,fuel,radixListFuel_length,List.length_ofFn]
    · intro i hi hi'
      have hil : i < 2^depth.length := by simpa only [List.length_ofFn] using hi'
      rw [fourierListPad_get _ _ _ _ (by simpa only [fuel,radixListFuel_length] using hil)]
      simp only [List.getElem?_ofFn,List.getElem_ofFn,VA,cyclicVectorData,vector_get_ofFn,
        dyadicBluesteinInput,ZMod.val_natCast,Nat.mod_eq_of_lt hil]
      by_cases hin : i < N
      · simp only [hin,↓reduceDIte,Option.getD_some]
        push_cast
        rfl
      · simp only [hin,↓reduceDIte,Option.getD_none]
  have hb : B.map BitFourierInteger.value=List.ofFn VB.get := by
    change (fourierListPad bitFourierZero fuel _).map _=_
    rw [fourierListPad_map,bitFourierZero_value,List.map_append,List.map_reverse,List.map_tail,hp,
      chirp_mirror_ofFn]
    apply List.ext_getElem
    · simp only [fourierListPad_length,fuel,radixListFuel_length,List.length_ofFn]
    · intro i hi hi'
      have hil : i < 2^depth.length := by simpa only [List.length_ofFn] using hi'
      rw [fourierListPad_get _ _ _ _ (by simpa only [fuel,radixListFuel_length] using hil)]
      simp only [List.getElem?_ofFn,List.getElem_ofFn,VB,cyclicVectorData,vector_get_ofFn,
        dyadicBluesteinKernel,ZMod.val_natCast,Nat.mod_eq_of_lt hil]
      by_cases hin : i < 2*N-1 <;> simp only [hin,↓reduceDIte,↓reduceIte,Option.getD_some,Option.getD_none]
  have hc := listCyclicConvolution_values depth p A B VA VB ha hb
  change (List.zipWith bitFourierMul neg (fourierListDrop input.tail (listCyclicConvolution depth p A B))).map _=_
  rw [List.map_zipWith]
  simp_rw [bitFourierMul_value]
  rw [← List.zipWith_map,hn,fourierListDrop_map,hc,fourierListDrop_eq]
  apply List.ext_getElem
  · simp only [List.length_zipWith,List.length_ofFn,List.length_drop,List.length_tail,input]
    omega
  · intro i hi hi'
    have hiN : i < N := by simpa only [List.length_ofFn] using hi'
    have hiM : N-1+i < 2^depth.length := by omega
    simp only [List.getElem_zipWith,List.getElem_ofFn,List.getElem_drop,List.length_tail,input,
      List.length_ofFn,dyadicBluesteinDFT,vector_get_ofFn,cyclicArrayIndex,ZMod.val_natCast]
    have hix : i+N-1=N-1+i := by omega
    simp only [hix,Nat.mod_eq_of_lt hiM]
    push_cast
    rfl

/-- Canonical small-parameter initializer. Its integer metadata operations are
separate from the Boolean scalar/list work of the transform itself. -/
def listCanonicalDyadicDFT (input : List Bool) : List BitFourierInteger :=
  let n := bluesteinPadExponent input.length
  listBluesteinTransform (List.replicate n false) (dyadicDFTPrecision n) input

theorem listCanonicalDyadicDFT_eq (N : ℕ) [NeZero N] (f : Vector Bool N) :
    (listCanonicalDyadicDFT (List.ofFn f.get)).map BitFourierInteger.value=
      List.ofFn (canonicalDyadicDFT N (dyadicDFTPrecision (bluesteinPadExponent N)) f).get := by
  have h := listBluesteinTransform_eq N (List.replicate (bluesteinPadExponent N) false)
    (dyadicDFTPrecision (bluesteinPadExponent N)) f
    (by simpa only [List.length_replicate] using (bluesteinPadExponent_bounds N).1)
  simpa only [listCanonicalDyadicDFT,List.length_ofFn,List.length_replicate,canonicalDyadicDFT] using h

end Optss
