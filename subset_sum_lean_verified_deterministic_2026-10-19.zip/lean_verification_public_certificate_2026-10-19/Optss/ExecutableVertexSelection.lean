import Optss.RationalVertexNormalization

/-!
# Explicit maximum-determinant vertex selection

The answer routines enumerate all ordered vertex-index tuples and evaluate
one rational determinant per tuple. Scores are materialized before a linear
maximum fold. The selected tuple is proved to supply the very same vertex
basis needed by the geometric normalization argument.

The enumeration has `m^r` candidates. This is appropriate to the paper's fixed
rank and bounded polytope complexity, and is not a variable-rank polynomial
algorithm. Rational-operation and Boolean bit-cost refinements remain separate.
-/
namespace Optss
open scoped BigOperators
variable {m r : ℕ}

/-- Structural Cartesian-power enumeration, with repetitions allowed. -/
def vertexIndexTuples (m : ℕ) : (r : ℕ) → List (Fin r → Fin m)
  | 0 => [Fin.elim0]
  | r+1 => (List.finRange m).flatMap fun i =>
      (vertexIndexTuples m r).map (Fin.cons i)

theorem mem_vertexIndexTuples (t : Fin r → Fin m) : t ∈ vertexIndexTuples m r := by
  induction r with
  | zero =>
    have he : t=Fin.elim0 := by funext i; exact Fin.elim0 i
    simp [vertexIndexTuples,he]
  | succ r ih =>
    apply List.mem_flatMap.mpr
    refine ⟨t 0,by simp,?_⟩
    apply List.mem_map.mpr
    refine ⟨fun i => t i.succ,ih _,?_⟩
    funext i
    exact Fin.cases rfl (fun j => rfl) i

theorem vertexIndexTuples_length (m r : ℕ) : (vertexIndexTuples m r).length = m^r := by
  induction r with
  | zero => simp [vertexIndexTuples]
  | succ r ih =>
    simp only [vertexIndexTuples,List.length_flatMap,List.map_map,Function.comp_def,List.length_map,ih]
    simp [Nat.pow_succ,mul_comm]

/-- Cached rational scores, with a deterministic last-maximum tie rule. -/
def maximumScored {α : Type*} : List (α × ℚ) → Option (α × ℚ)
  | [] => none
  | p::ps => match maximumScored ps with
    | none => some p
    | some q => some (if p.2 ≤ q.2 then q else p)

theorem maximumScored_none {α : Type*} (ps : List (α × ℚ)) :
    maximumScored ps=none ↔ ps=[] := by
  cases ps with
  | nil => simp [maximumScored]
  | cons p ps => simp only [maximumScored]; split <;> simp

theorem maximumScored_spec {α : Type*} (ps : List (α × ℚ)) (p : α × ℚ)
    (hp : maximumScored ps=some p) : p∈ps ∧ ∀ q∈ps,q.2≤p.2 := by
  induction ps generalizing p with
  | nil => simp [maximumScored] at hp
  | cons a ps ih =>
    rw [maximumScored] at hp
    cases he : maximumScored ps with
    | none =>
      rw [he] at hp
      have hp' := Option.some.inj hp
      have hempty := (maximumScored_none ps).mp he
      subst p
      subst ps
      simp
    | some b =>
      rw [he] at hp
      obtain ⟨hb,hmax⟩ := ih b he
      by_cases h : a.2≤b.2
      · simp only [h,↓reduceIte,Option.some.injEq] at hp
        subst p
        refine ⟨List.mem_cons_of_mem _ hb,?_⟩
        intro q hq
        rcases List.mem_cons.mp hq with hq | hq
        · subst q; exact h
        · exact hmax q hq
      · simp only [h,↓reduceIte,Option.some.injEq] at hp
        subst p
        refine ⟨List.mem_cons_self,?_⟩
        intro q hq
        rcases List.mem_cons.mp hq with hq | hq
        · subst q; exact le_rfl
        · exact (hmax q hq).trans (le_of_not_ge h)

def maximumScoredComparisons {α : Type*} : List (α × ℚ) → ℕ
  | [] => 0
  | _::ps => maximumScoredComparisons ps+if (maximumScored ps).isSome then 1 else 0

theorem maximumScoredComparisons_le {α : Type*} (ps : List (α × ℚ)) :
    maximumScoredComparisons ps ≤ ps.length := by
  induction ps with
  | nil => rfl
  | cons p ps ih =>
    rw [maximumScoredComparisons,List.length_cons]
    split_ifs <;> omega

/-- The candidate columns are vertices from the actual input list. -/
def rationalVertexMatrix (V : Fin m → Fin r → ℚ) (t : Fin r → Fin m) :
    Matrix (Fin r) (Fin r) ℚ := fun i j => V (t j) i

/-- Each determinant is evaluated once and retained with its tuple. -/
def scoredVertexTuples (V : Fin m → Fin r → ℚ) : List ((Fin r → Fin m) × ℚ) :=
  (vertexIndexTuples m r).map fun t => (t,|(rationalVertexMatrix V t).det|)

def selectVertexTuple (V : Fin m → Fin r → ℚ) : Option (Fin r → Fin m) :=
  (maximumScored (scoredVertexTuples V)).map Prod.fst

theorem scoredVertexTuples_length (V : Fin m → Fin r → ℚ) :
    (scoredVertexTuples V).length=m^r := by
  rw [scoredVertexTuples,List.length_map,vertexIndexTuples_length]

theorem selectVertexTuple_maximal (V : Fin m → Fin r → ℚ) (t : Fin r → Fin m)
    (ht : selectVertexTuple V=some t) :
    ∀ u : Fin r → Fin m, |(rationalVertexMatrix V u).det| ≤ |(rationalVertexMatrix V t).det| := by
  unfold selectVertexTuple at ht
  cases he : maximumScored (scoredVertexTuples V) with
  | none => simp [he] at ht
  | some p =>
    simp only [he,Option.map_some,Option.some.injEq] at ht
    obtain ⟨hp,hmax⟩ := maximumScored_spec _ p he
    obtain ⟨u,_,hu⟩ := List.mem_map.mp hp
    cases hu
    have hut : u=t := by simpa using ht
    subst t
    intro v
    exact hmax (v,|(rationalVertexMatrix V v).det|)
      (List.mem_map.mpr ⟨v,mem_vertexIndexTuples v,rfl⟩)

theorem selectVertexTuple_exists (V : Fin m → Fin r → ℚ) (u : Fin r → Fin m) :
    ∃ t,selectVertexTuple V=some t := by
  cases he : maximumScored (scoredVertexTuples V) with
  | none =>
    have hn := (maximumScored_none _).mp he
    have hm : (u,|(rationalVertexMatrix V u).det|)∈scoredVertexTuples V :=
      List.mem_map.mpr ⟨u,mem_vertexIndexTuples u,rfl⟩
    simp [hn] at hm
  | some p => exact ⟨p.1,by simp [selectVertexTuple,he]⟩

theorem selectVertexTuple_det_ne_zero (V : Fin m → Fin r → ℚ) (t : Fin r → Fin m)
    (ht : selectVertexTuple V=some t) (u : Fin r → Fin m)
    (hu : (rationalVertexMatrix V u).det≠0) : (rationalVertexMatrix V t).det≠0 := by
  have h := selectVertexTuple_maximal V t ht u
  exact abs_pos.mp ((abs_pos.mpr hu).trans_le h)

/-- Exact determinant-evaluation count of the materializing map. -/
def vertexDeterminantEvaluations {r : ℕ} : List (Fin r → Fin m) → ℕ
  | [] => 0
  | _::ts => vertexDeterminantEvaluations ts+1

theorem vertexDeterminantEvaluations_eq (ts : List (Fin r → Fin m)) :
    vertexDeterminantEvaluations ts=ts.length := by
  induction ts <;> simp_all [vertexDeterminantEvaluations]

theorem selectVertexTuple_counts (V : Fin m → Fin r → ℚ) :
    vertexDeterminantEvaluations (vertexIndexTuples m r)=m^r ∧
      maximumScoredComparisons (scoredVertexTuples V)≤m^r := by
  constructor
  · rw [vertexDeterminantEvaluations_eq,vertexIndexTuples_length]
  · simpa only [scoredVertexTuples_length] using maximumScoredComparisons_le (scoredVertexTuples V)

/-- Real geometry uses precisely the rational input vertex coordinates. -/
def realVertex (V : Fin m → Fin r → ℚ) (i : Fin m) : Fin r → ℝ := fun j => (V i j:ℝ)

noncomputable def rationalVertexSet (V : Fin m → Fin r → ℚ) : Finset (Fin r → ℝ) := by
  classical
  exact Finset.univ.image (realVertex V)

theorem mem_rationalVertexSet (V : Fin m → Fin r → ℚ) (x : Fin r → ℝ) :
    x∈rationalVertexSet V ↔ ∃ i,realVertex V i=x := by
  classical
  simp [rationalVertexSet]

theorem rationalVertexMatrix_cast_det (V : Fin m → Fin r → ℚ) (t : Fin r → Fin m) :
    ((rationalVertexMatrix V t).det:ℝ) =
      (Pi.basisFun ℝ (Fin r)).det (fun j => realVertex V (t j)) := by
  rw [Basis.det_apply]
  have he : (rationalVertexMatrix V t).map (Rat.castHom ℝ) =
      (Pi.basisFun ℝ (Fin r)).toMatrix (fun j => realVertex V (t j)) := by
    ext i j
    simp [rationalVertexMatrix,realVertex,Basis.toMatrix_apply]
  rw [← he]
  exact Rat.cast_det (F:=ℝ) (rationalVertexMatrix V t)

/-- Full span supplies a nonzero candidate to the actual finite search. -/
theorem exists_vertex_tuple_det_ne_zero (V : Fin m → Fin r → ℚ)
    (hspan : Submodule.span ℝ (rationalVertexSet V : Set (Fin r → ℝ))=⊤) :
    ∃ t : Fin r → Fin m,(rationalVertexMatrix V t).det≠0 := by
  classical
  obtain ⟨b,hb⟩ := exists_vertex_basis (Pi.basisFun ℝ (Fin r)) (rationalVertexSet V) hspan
  have hindices : ∀ j,∃ i,realVertex V i=b j := fun j => (mem_rationalVertexSet V _).mp (hb j)
  choose t ht using hindices
  refine ⟨t,?_⟩
  intro hz
  have hcast := rationalVertexMatrix_cast_det V t
  rw [hz,Rat.cast_zero] at hcast
  have he : (fun j => realVertex V (t j))=b := funext ht
  rw [he] at hcast
  exact ((Pi.basisFun ℝ (Fin r)).isUnit_det b).ne_zero hcast.symm

/-- The algorithm succeeds and its selected columns are a genuine real basis.
The basis is only a mathematical view of the returned rational tuple. -/
theorem selectVertexTuple_basis (V : Fin m → Fin r → ℚ)
    (hspan : Submodule.span ℝ (rationalVertexSet V : Set (Fin r → ℝ))=⊤) :
    ∃ t,selectVertexTuple V=some t ∧
      ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
        (∀ j,b j=realVertex V (t j)) ∧
        (∀ j,b j∈rationalVertexSet V) ∧
        ∀ v : Fin r → (Fin r → ℝ), (∀ j,v j∈rationalVertexSet V) →
          |(Pi.basisFun ℝ (Fin r)).det v| ≤ |(Pi.basisFun ℝ (Fin r)).det b| := by
  classical
  obtain ⟨u,hu⟩ := exists_vertex_tuple_det_ne_zero V hspan
  obtain ⟨t,ht⟩ := selectVertexTuple_exists V u
  have hdet := selectVertexTuple_det_ne_zero V t ht u hu
  have hreal : (Pi.basisFun ℝ (Fin r)).det (fun j => realVertex V (t j))≠0 := by
    rw [← rationalVertexMatrix_cast_det]
    exact_mod_cast hdet
  obtain ⟨hli,hsp⟩ := (is_basis_iff_det (Pi.basisFun ℝ (Fin r))).mpr (isUnit_iff_ne_zero.mpr hreal)
  let b : Basis (Fin r) ℝ (Fin r → ℝ) := Basis.mk hli hsp.ge
  have hb : ⇑b=(fun j => realVertex V (t j)) := Basis.coe_mk _ _
  refine ⟨t,ht,b,fun j => congrFun hb j,?_,?_⟩
  · intro j
    rw [congrFun hb j]
    exact (mem_rationalVertexSet V _).mpr ⟨t j,rfl⟩
  · intro v hv
    have hindices : ∀ j,∃ i,realVertex V i=v j := fun j => (mem_rationalVertexSet V _).mp (hv j)
    choose q hq using hindices
    have hmax := selectVertexTuple_maximal V t ht q
    have hmaxR : |((rationalVertexMatrix V q).det:ℝ)|≤|((rationalVertexMatrix V t).det:ℝ)| := by
      exact_mod_cast hmax
    rw [rationalVertexMatrix_cast_det,rationalVertexMatrix_cast_det] at hmaxR
    rw [funext hq,← hb] at hmaxR
    exact hmaxR

/-- The tuple returned by the finite rational search gives the actual two
cube containments and rational inverse certificate used in lattice boxing. -/
theorem selectVertexTuple_normalization (hr : 0<r) (V : Fin m → Fin r → ℚ)
    (hspan : Submodule.span ℝ (rationalVertexSet V : Set (Fin r → ℝ))=⊤)
    (hsym : ∀ x∈rationalVertexSet V,-x∈rationalVertexSet V) :
    ∃ t,selectVertexTuple V=some t ∧
      ∃ b : Basis (Fin r) ℝ (Fin r → ℝ),
        (∀ j,b j=realVertex V (t j)) ∧
        {x : EuclideanSpace ℝ (Fin r) | ∀ j,|x j|≤1/(r:ℝ)} ⊆
          basisEuclideanNormalization b '' convexHull ℝ (rationalVertexSet V : Set _) ∧
        basisEuclideanNormalization b '' convexHull ℝ (rationalVertexSet V : Set _) ⊆
          {x | ∀ j,|x j|≤1} ∧
        Nonempty (RationalNormalizationData (basisEuclideanNormalization b)) := by
  classical
  obtain ⟨t,ht,b,hbt,hb,hmax⟩ := selectVertexTuple_basis V hspan
  have hinner : coordinateCube r (1/(r:ℝ)) ⊆
      b.equivFun '' convexHull ℝ (rationalVertexSet V : Set _) := by
    apply small_cube_subset_convex_of_signed_axes hr
    · rw [basis_coordinates_image_convexHull]
      exact convex_convexHull ℝ _
    · intro j
      refine ⟨b j,subset_convexHull ℝ _ (hb j),?_⟩
      ext i
      simp [Basis.equivFun_self,Pi.single_apply,eq_comm]
    · intro j
      refine ⟨-b j,subset_convexHull ℝ _ (hsym _ (hb j)),?_⟩
      rw [map_neg]
      congr 1
      ext i
      simp [Basis.equivFun_self,Pi.single_apply,eq_comm]
  have houter : b.equivFun '' convexHull ℝ (rationalVertexSet V : Set _) ⊆ coordinateCube r 1 := by
    rw [basis_coordinates_image_convexHull]
    apply convexHull_min _ (convex_coordinateCube r 1)
    rintro _ ⟨x,hx,rfl⟩ j
    exact maximal_determinant_vertex_coordinates (Pi.basisFun ℝ (Fin r)) b
      (rationalVertexSet V) hb hmax hx j
  refine ⟨t,ht,b,hbt,?_,?_,basisEuclideanNormalization_rational b ?_⟩
  · intro x hx
    obtain ⟨y,hy,he⟩ := hinner (show (fun j => x j)∈coordinateCube r (1/(r:ℝ)) from hx)
    refine ⟨y,hy,?_⟩
    ext j
    exact congrFun he j
  · rintro _ ⟨x,hx,rfl⟩ j
    exact houter ⟨x,hx,rfl⟩ j
  · intro i j
    exact ⟨V (t j) i,by rw [hbt]; rfl⟩

end Optss
