import Optss.Zonotope
import Mathlib.Analysis.NormedSpace.HahnBanach.Separation
import Mathlib.Analysis.Normed.Module.FiniteDimension

/-!
# Convex-set estimates used in Lemma 3.5

This file proves the geometric estimates, including the cancellation argument
for the final interior-containment claim. Nonemptiness is explicit: the empty
set is also compact, convex and invariant under negation in Lean.
-/
namespace Optss
open scoped BigOperators Pointwise
noncomputable section

section Algebra
variable {ι E : Type*} [AddCommGroup E] [Module ℝ E]

/-- A convex set containing a point and its negative contains the origin. -/
theorem zero_mem_of_convex_symmetric {C : Set E} (hc : Convex ℝ C)
    (hne : C.Nonempty) (hsym : ∀ x ∈ C, -x ∈ C) : (0 : E) ∈ C := by
  obtain ⟨x, hx⟩ := hne
  have h := hc hx (hsym x hx) (show (0 : ℝ) ≤ 1/2 by norm_num)
    (show (0 : ℝ) ≤ 1/2 by norm_num) (by norm_num)
  simpa using h

/-- Coefficients in `[-1,1]` keep a point in an origin-symmetric convex set. -/
theorem smul_mem_symmetric_convex {C : Set E} (hc : Convex ℝ C)
    (hzero : (0 : E) ∈ C) (hsym : ∀ x ∈ C, -x ∈ C)
    {x : E} (hx : x ∈ C) {a : ℝ} (ha : |a| ≤ 1) : a • x ∈ C := by
  by_cases h : 0 ≤ a
  · exact hc.smul_mem_of_zero_mem hzero hx ⟨h, (le_abs_self a).trans ha⟩
  · have h' : (-a) • (-x) ∈ C :=
      hc.smul_mem_of_zero_mem hzero (hsym x hx)
        ⟨by linarith, (neg_le_abs a).trans ha⟩
    simpa using h'

/-- The sum of `s.card` points of a convex set belongs to its corresponding
geometric dilation. This includes the empty sum if the set contains zero. -/
theorem sum_mem_card_smul {C : Set E} (hc : Convex ℝ C) (hzero : (0 : E) ∈ C)
    (s : Finset ι) (f : ι → E) (hf : ∀ i ∈ s, f i ∈ C) :
    (∑ i ∈ s, f i) ∈ (s.card : ℝ) • C := by
  classical
  by_cases hs : s = ∅
  · subst s
    exact ⟨0, hzero, by simp⟩
  · have hpos : (0 : ℝ) < s.card := by exact_mod_cast Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr hs)
    have hmem : (∑ i ∈ s, (s.card : ℝ)⁻¹ • f i) ∈ C := by
      apply hc.sum_mem
      · intro i hi
        exact inv_nonneg.mpr (le_of_lt hpos)
      · simp [ne_of_gt hpos]
      · exact hf
    refine ⟨_, hmem, ?_⟩
    dsimp only
    rw [Finset.smul_sum]
    apply Finset.sum_congr rfl
    intro i hi
    simp [smul_smul, ne_of_gt hpos]

/-- Increasing the nonnegative dilation scale preserves containment. -/
theorem smul_set_mono_scale {C : Set E} (hc : Convex ℝ C) (hzero : (0 : E) ∈ C)
    {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) : a • C ⊆ b • C := by
  rintro x ⟨y, hy, rfl⟩
  by_cases hb : b = 0
  · have ha0 : a = 0 := by linarith
    exact ⟨0, hzero, by simp [ha0, hb]⟩
  · have hbpos : 0 < b := lt_of_le_of_ne (ha.trans hab) (Ne.symm hb)
    refine ⟨(a / b) • y, hc.smul_mem_of_zero_mem hzero hy ?_, ?_⟩
    · exact ⟨div_nonneg ha hbpos.le, (div_le_one hbpos).mpr hab⟩
    · dsimp only
      rw [smul_smul]
      congr 1
      field_simp

/-- A sum supported on at most `r` terms, each lying in `C`, belongs to `r C`. -/
theorem sum_mem_smul_of_card_le {C : Set E} (hc : Convex ℝ C) (hzero : (0 : E) ∈ C)
    (s : Finset ι) (f : ι → E) (hf : ∀ i ∈ s, f i ∈ C) {r : ℕ}
    (hcard : s.card ≤ r) : (∑ i ∈ s, f i) ∈ (r : ℝ) • C :=
  smul_set_mono_scale hc hzero (by positivity) (by exact_mod_cast hcard)
    (sum_mem_card_smul hc hzero s f hf)

end Algebra

section Topology
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- Minkowski cancellation against a nonempty compact set for a closed convex
set. This is the support-functional argument at the end of Lemma 3.5. -/
theorem mem_of_translate_subset_add {K D : Set E} (hconv : Convex ℝ K)
    (hclosed : IsClosed K) (hcompact : IsCompact D) (hne : D.Nonempty)
    {z : E} (h : {z} + D ⊆ K + D) : z ∈ K := by
  by_contra hz
  obtain ⟨f, u, hK, hz⟩ := geometric_hahn_banach_closed_point hconv hclosed hz
  obtain ⟨d, hd, hmax⟩ := hcompact.exists_isMaxOn hne f.continuous.continuousOn
  have hzd : z + d ∈ K + D := h (Set.add_mem_add (Set.mem_singleton z) hd)
  rcases hzd with ⟨k, hk, d', hd', heq⟩
  have hke := hK k hk
  have hde : f d' ≤ f d := hmax hd'
  have he := congrArg f heq
  simp only [map_add] at he
  linarith

/-- The interior-containment conclusion can be used through any intermediate
outer set: `z+D ⊆ Z ⊆ K+D` forces `z∈K`. -/
theorem mem_of_translate_subset_outer {K D Z : Set E} (hconv : Convex ℝ K)
    (hclosed : IsClosed K) (hcompact : IsCompact D) (hne : D.Nonempty)
    (houter : Z ⊆ K + D) {z : E} (hinner : {z} + D ⊆ Z) : z ∈ K :=
  mem_of_translate_subset_add hconv hclosed hcompact hne (hinner.trans houter)

variable {ι : Type*} [Fintype ι]

/-- A finitely generated zonotope is compact, with no rank assumption on the vectors. -/
theorem isCompact_zonotope (v : ι → E) (c : ι → ℝ) : IsCompact (zonotope v c) := by
  unfold zonotope
  exact isCompact_Icc.image (combinationMap v).continuous_of_finiteDimensional

end Topology
end
end Optss
