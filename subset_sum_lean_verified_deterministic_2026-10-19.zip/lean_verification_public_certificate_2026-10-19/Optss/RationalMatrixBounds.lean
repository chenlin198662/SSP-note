import Optss.RationalArithmeticBounds
import Optss.BinaryRationalCost
import Optss.ExecutableVertexSelection

/-!
# Rational matrix normalization: actual intermediate sizes

These bounds cover products and every finite partial sum in Leibniz
determinants, matrix multiplication, and the explicit cofactor inverse.
They apply to singular matrices as well, using rational division by zero;
only the inverse equations require nonsingularity. The factorial constants
are suitable for the paper's fixed-rank vertex normalization. No variable-rank
polynomial determinant algorithm or machine-time bound is asserted here.
-/
namespace Optss
open scoped BigOperators
variable {r m d : ℕ}

theorem RationalSizeBound.one : RationalSizeBound 1 1 := by
  norm_num [RationalSizeBound]

theorem RationalSizeBound.abs {q : ℚ} {B : ℕ} (h : RationalSizeBound q B) :
    RationalSizeBound |q| B := by
  rcases le_total 0 q with hq | hq
  · simpa only [abs_of_nonneg hq] using h
  · simpa only [abs_of_nonpos hq] using h.neg

theorem rational_prod_size {ι : Type*} (s : Finset ι) (q : ι → ℚ)
    (B : ℕ) (hq : ∀ i∈s,RationalSizeBound (q i) B) :
    RationalSizeBound (∏ i∈s,q i) (B^s.card) := by
  classical
  induction s using Finset.induction_on with
  | empty => simpa using RationalSizeBound.one
  | @insert a s ha ih =>
    rw [Finset.prod_insert ha,Finset.card_insert_of_not_mem ha,pow_succ']
    exact (hq a (Finset.mem_insert_self _ _)).mul
      (ih (fun i hi => hq i (Finset.mem_insert_of_mem hi)))

/-- Explicit executable inverse through row-replacement cofactors. -/
def rationalCofactorInverse (A : Matrix (Fin r) (Fin r) ℚ) :
    Matrix (Fin r) (Fin r) ℚ := fun i j =>
  (A.updateRow j (Pi.single i 1)).det / A.det

theorem rationalCofactorInverse_eq (A : Matrix (Fin r) (Fin r) ℚ) :
    rationalCofactorInverse A=A⁻¹ := by
  ext i j
  simp only [rationalCofactorInverse,Matrix.inv_def,Matrix.smul_apply,
    smul_eq_mul,Ring.inverse_eq_inv,Matrix.adjugate_apply,div_eq_mul_inv,mul_comm]

theorem rationalCofactorInverse_mul (A : Matrix (Fin r) (Fin r) ℚ) (hA : A.det≠0) :
    rationalCofactorInverse A*A=1 ∧ A*rationalCofactorInverse A=1 := by
  rw [rationalCofactorInverse_eq]
  exact ⟨Matrix.nonsing_inv_mul A (isUnit_iff_ne_zero.mpr hA),
    Matrix.mul_nonsing_inv A (isUnit_iff_ne_zero.mpr hA)⟩

/-- A uniform height for all determinant partial-sum accumulators. -/
def rationalDeterminantHeight (r B : ℕ) : ℕ := (2*B^r)^r.factorial

/-- Partial products in each signed Leibniz term have controlled height. -/
theorem rationalDeterminantTerm_size (A : Matrix (Fin r) (Fin r) ℚ)
    (B : ℕ) (hA : ∀ i j,RationalSizeBound (A i j) B)
    (σ : Equiv.Perm (Fin r)) :
    RationalSizeBound (((Equiv.Perm.sign σ:ℤ):ℚ)*∏ i,A (σ i) i) (B^r) := by
  have hp : RationalSizeBound (∏ i,A (σ i) i) (B^r) := by
    simpa using rational_prod_size Finset.univ (fun i => A (σ i) i) B (fun i _ => hA _ _)
  rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with hs | hs
  · simpa only [hs,Units.val_one,Int.cast_one,one_mul] using hp
  · simpa [hs] using hp.neg

/-- Every subset of Leibniz terms, including all accumulation prefixes. -/
theorem rationalDeterminant_partial_size (A : Matrix (Fin r) (Fin r) ℚ)
    (B : ℕ) (hB : 0<B) (hA : ∀ i j,RationalSizeBound (A i j) B)
    (s : Finset (Equiv.Perm (Fin r))) :
    RationalSizeBound (∑ σ∈s,((Equiv.Perm.sign σ:ℤ):ℚ)*∏ i,A (σ i) i)
      (rationalDeterminantHeight r B) := by
  apply (rational_sum_size s _ (B^r) (pow_pos hB _)
    (fun σ _ => rationalDeterminantTerm_size A B hA σ)).mono
  apply Nat.pow_le_pow_right (by positivity)
  simpa only [Fintype.card_perm,Fintype.card_fin] using s.card_le_univ

theorem rationalDeterminant_size (A : Matrix (Fin r) (Fin r) ℚ)
    (B : ℕ) (hB : 0<B) (hA : ∀ i j,RationalSizeBound (A i j) B) :
    RationalSizeBound A.det (rationalDeterminantHeight r B) := by
  rw [Matrix.det_apply']
  simpa using rationalDeterminant_partial_size A B hB hA Finset.univ

theorem rationalUpdateUnitRow_size (A : Matrix (Fin r) (Fin r) ℚ)
    (B : ℕ) (hB : 0<B) (hA : ∀ i j,RationalSizeBound (A i j) B)
    (i j k l : Fin r) :
    RationalSizeBound (A.updateRow j (Pi.single i 1) k l) B := by
  rw [Matrix.updateRow_apply]
  split_ifs
  · by_cases h : l=i
    · subst l; simpa using RationalSizeBound.one.mono hB
    · simp only [Pi.single_apply,h,↓reduceIte]
      exact RationalSizeBound.zero.mono hB
  · exact hA _ _

theorem rationalCofactorInverse_size (A : Matrix (Fin r) (Fin r) ℚ)
    (B : ℕ) (hB : 0<B) (hA : ∀ i j,RationalSizeBound (A i j) B)
    (i j : Fin r) :
    RationalSizeBound (rationalCofactorInverse A i j) (rationalDeterminantHeight r B^2) := by
  simpa only [rationalCofactorInverse,pow_two] using
    (rationalDeterminant_size _ B hB (rationalUpdateUnitRow_size A B hB hA i j)).div
      (rationalDeterminant_size A B hB hA)

/-- Matrix multiplication also controls every partial dot-product accumulator. -/
theorem rationalMatrixMul_partial_size (A : Matrix (Fin r) (Fin d) ℚ)
    (C : Matrix (Fin d) (Fin m) ℚ) (B : ℕ) (hB : 0<B)
    (hA : ∀ i j,RationalSizeBound (A i j) B)
    (hC : ∀ i j,RationalSizeBound (C i j) B)
    (s : Finset (Fin d)) (i : Fin r) (j : Fin m) :
    RationalSizeBound (∑ k∈s,A i k*C k j) ((2*B^2)^d) := by
  apply (rational_sum_size s _ (B^2) (pow_pos hB _)
    (fun k _ => by simpa only [pow_two] using (hA i k).mul (hC k j))).mono
  exact Nat.pow_le_pow_right (by positivity)
    (s.card_le_univ.trans_eq (Fintype.card_fin _))

theorem rationalMatrixMul_size (A : Matrix (Fin r) (Fin d) ℚ)
    (C : Matrix (Fin d) (Fin m) ℚ) (B : ℕ) (hB : 0<B)
    (hA : ∀ i j,RationalSizeBound (A i j) B)
    (hC : ∀ i j,RationalSizeBound (C i j) B) (i : Fin r) (j : Fin m) :
    RationalSizeBound ((A*C) i j) ((2*B^2)^d) := by
  simpa [Matrix.mul_apply] using rationalMatrixMul_partial_size A C B hB hA hC Finset.univ i j

/-- Reduced input bits yield a concrete power-of-two height. -/
theorem RationalBitBound.height {q : ℚ} {L : ℕ} (h : RationalBitBound q L) :
    RationalSizeBound q (2^L) :=
  ⟨(Nat.size_le.mp h.1).le,(Nat.size_le.mp h.2).le⟩

private theorem determinantBase_bits (r L : ℕ) : (2*(2^L)^r).size=r*L+2 := by
  rw [← pow_mul,show 2*2^(L*r)=2^(L*r+1) by ring,Nat.size_pow]
  ring

/-- Determinant bit length is linear in input bit length for fixed rank. -/
theorem rationalDeterminant_bits (A : Matrix (Fin r) (Fin r) ℚ)
    (L : ℕ) (hA : ∀ i j,RationalBitBound (A i j) L) :
    RationalBitBound A.det (r.factorial*(r*L+2)) := by
  have h := (rationalDeterminant_size A (2^L) (by positivity)
    (fun i j => (hA i j).height)).bits (Nat.factorial_pos r)
  simpa only [determinantBase_bits] using h

/-- The same bit bound applies at every determinant partial-sum stage. -/
theorem rationalDeterminant_partial_bits (A : Matrix (Fin r) (Fin r) ℚ)
    (L : ℕ) (hA : ∀ i j,RationalBitBound (A i j) L)
    (s : Finset (Equiv.Perm (Fin r))) :
    RationalBitBound (∑ σ∈s,((Equiv.Perm.sign σ:ℤ):ℚ)*∏ i,A (σ i) i)
      (r.factorial*(r*L+2)) := by
  have h := (rationalDeterminant_partial_size A (2^L) (by positivity)
    (fun i j => (hA i j).height) s).bits (Nat.factorial_pos r)
  simpa only [determinantBase_bits] using h

/-- The explicit cofactor inverse has fixed-rank linear bit growth, with
no artificial lower bound on a nonzero rational determinant. -/
theorem rationalCofactorInverse_bits (A : Matrix (Fin r) (Fin r) ℚ)
    (L : ℕ) (hA : ∀ i j,RationalBitBound (A i j) L) (i j : Fin r) :
    RationalBitBound (rationalCofactorInverse A i j) (2*r.factorial*(r*L+2)) := by
  have hh := rationalCofactorInverse_size A (2^L) (by positivity)
    (fun i j => (hA i j).height) i j
  have hp : 0<2*r.factorial := by have := Nat.factorial_pos r; omega
  have he : rationalDeterminantHeight r (2^L)^2=(2*(2^L)^r)^(2*r.factorial) := by
    unfold rationalDeterminantHeight
    rw [← pow_mul,Nat.mul_comm r.factorial 2]
  rw [he] at hh
  simpa only [determinantBase_bits] using hh.bits hp

/-- Matrix-product output and accumulation widths, including an empty inner dimension. -/
theorem rationalMatrixMul_partial_bits (A : Matrix (Fin r) (Fin d) ℚ)
    (C : Matrix (Fin d) (Fin m) ℚ) (L : ℕ)
    (hA : ∀ i j,RationalBitBound (A i j) L)
    (hC : ∀ i j,RationalBitBound (C i j) L)
    (s : Finset (Fin d)) (i : Fin r) (j : Fin m) :
    RationalBitBound (∑ k∈s,A i k*C k j) ((d+1)*(2*L+2)) := by
  have hh := rationalMatrixMul_partial_size A C (2^L) (by positivity)
    (fun i j => (hA i j).height) (fun i j => (hC i j).height) s i j
  have hmono : (2*(2^L)^2)^d≤(2*(2^L)^2)^(d+1) :=
    Nat.pow_le_pow_right (by positivity) (by omega)
  have hb := (hh.mono hmono).bits (by omega : 0<d+1)
  simpa only [determinantBase_bits] using hb

theorem rationalMatrixMul_bits (A : Matrix (Fin r) (Fin d) ℚ)
    (C : Matrix (Fin d) (Fin m) ℚ) (L : ℕ)
    (hA : ∀ i j,RationalBitBound (A i j) L)
    (hC : ∀ i j,RationalBitBound (C i j) L) (i : Fin r) (j : Fin m) :
    RationalBitBound ((A*C) i j) ((d+1)*(2*L+2)) := by
  simpa [Matrix.mul_apply] using rationalMatrixMul_partial_bits A C L hA hC Finset.univ i j

/-- All candidates, and hence the selected normalization matrix, inherit the
actual input coordinate widths. -/
theorem rationalVertexMatrix_bits (V : Fin m → Fin r → ℚ)
    (L : ℕ) (hV : ∀ i j,RationalBitBound (V i j) L) (t : Fin r → Fin m)
    (i j : Fin r) : RationalBitBound (rationalVertexMatrix V t i j) L := hV _ _

theorem selectedVertex_inverse_bits (V : Fin m → Fin r → ℚ)
    (L : ℕ) (hV : ∀ i j,RationalBitBound (V i j) L) (t : Fin r → Fin m)
    (i j : Fin r) :
    RationalBitBound (rationalCofactorInverse (rationalVertexMatrix V t) i j)
      (2*r.factorial*(r*L+2)) :=
  rationalCofactorInverse_bits _ L (rationalVertexMatrix_bits V L hV t) i j

end Optss
