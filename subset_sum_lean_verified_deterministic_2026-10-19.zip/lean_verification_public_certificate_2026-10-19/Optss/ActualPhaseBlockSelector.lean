import Optss.BoundedBlockSequence

/-!
# Instantiating bounded block sequences with the proved greedy routine

The selector below calls the actual restarting greedy block on every full-rank
surviving subset. The harmless empty selection outside that domain makes the
function total; rank protection proves that branch is never used in a valid
phase prefix.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1200000

variable {ι : Type} [LinearOrder ι] {v : ι → ℤ} {initial : Finset ι} {h : ℕ}

/-- The actual total selector on surviving labelled subsets. -/
def actualPhaseBlock (model : CommonGapLabelModel v initial h) (c : ℝ) (a M : ℕ)
    (s : Finset ι) : GreedyBlockState ι (IntVec model.rank) :=
  if hs : s ⊆ initial ∧ labelSpan ℝ (fun i => realVector (model.coordinates i)) s = ⊤ then
    restartingGreedyBlock model.coordinates s hs.2 model.widths
      (fun i hi => model.boxed i (hs.1 hi)) c a h M
  else greedyBlockSeed model.coordinates s ∅

/-- The scalar restart comparison and dense-block conclusion are proved for
this concrete selector; no block or growth certificate is an input. -/
theorem actual_phase_block_selector (η : ℝ) (hη : 0 < η) :
    ∃ a N₀ : ℕ, ∃ c : ℝ, 1 ≤ a ∧ 0 < c ∧
      ∀ (ι : Type) [LinearOrder ι] (v : ι → ℤ) (initial : Finset ι) (h : ℕ)
        (model : CommonGapLabelModel v initial h) (N M : ℕ),
        N₀ ≤ N → 1 ≤ N → 1 ≤ h → 4 ≤ M → (N : ℝ)^η ≤ h → M ≤ h*N+1 →
        (∀ i ∈ initial, v i ∈ Finset.Icc 0 (N : ℤ)) →
        let B := ⌈(latticeSeedCardBound model.rank model.widths : ℝ)+greedyProfileConstant c a η*h⌉₊
        ∃ F : BoundedBlockSelector model.coordinates initial B,
          F.select = actualPhaseBlock model c a M ∧
          ∀ s ⊆ initial, labelSpan ℝ (fun i => realVector (model.coordinates i)) s = ⊤ →
            0 ∈ (F.select s).sums ∧
            AddSubgroup.closure ((F.select s).sums : Set (IntVec model.rank)) = generatedLattice model.coordinates s ∧
            (2*(h • insert 0 ((F.select s).remaining.image v)).card < M ∨
              (M : ℝ)/4 ≤ (F.select s).sums.card) := by
  obtain ⟨a, N₀, c, ha, hc, hblock⟩ := restarting_greedy_block_from_long_sumsets η hη
  refine ⟨a, N₀, c, ha, hc, ?_⟩
  intro ι _ v initial h model N M hN₀ hN hh hM4 hscale hM hscalar
  let B := ⌈(latticeSeedCardBound model.rank model.widths : ℝ)+greedyProfileConstant c a η*h⌉₊
  have hproper : Set.InjOn model.projection (integerBudgetBox (fun j => h*model.widths j)) := by
    apply model.proper.mono
    intro x hx
    apply (mem_integerBudgetBox _ x).mpr
    intro j
    exact ((mem_integerBudgetBox _ x).mp hx j).trans (by
      dsimp only
      exact_mod_cast Nat.mul_le_mul_right (model.widths j) (show h ≤ 20*h by omega))
  have hgood : ∀ s (hs : s ⊆ initial)
      (hf : labelSpan ℝ (fun i => realVector (model.coordinates i)) s = ⊤),
      let out := actualPhaseBlock model c a M s
      out.Valid model.coordinates ∧ out.chosen ⊆ s ∧ out.remaining = s \ out.chosen ∧
      0 ∈ out.sums ∧ AddSubgroup.closure (out.sums : Set (IntVec model.rank)) = generatedLattice model.coordinates s ∧
      out.chosen.card ≤ B ∧
      (2*(h • insert 0 (out.remaining.image v)).card < M ∨ (M : ℝ)/4 ≤ out.sums.card) := by
    intro s hs hf
    have he : actualPhaseBlock model c a M s =
        restartingGreedyBlock model.coordinates s hf model.widths
          (fun i hi => model.boxed i (hs hi)) c a h M := by
      unfold actualPhaseBlock
      rw [dif_pos ⟨hs, hf⟩]
    rw [he]
    obtain ⟨hv, hsub, hrem, hz, hlat, hsize, _, halt⟩ :=
      hblock ι model.rank model.coordinates s hf model.widths
        (fun i hi => model.boxed i (hs hi)) model.projection N h M hN₀ hN hh hM4 hscale hM
        (fun i hi => (model.represents i (hs hi)) ▸ hscalar i (hs hi)) hproper
    refine ⟨hv, hsub, hrem, hz, hlat, ?_, ?_⟩
    · exact Nat.cast_le.mp (hsize.trans (Nat.le_ceil _))
    · rcases halt with halt | halt
      · apply Or.inl
        change 2*(h • insert 0 ((_ : Finset ι).image model.coordinates)).card < M at halt
        have hsrem : (restartingGreedyBlock model.coordinates s hf model.widths
            (fun i hi => model.boxed i (hs hi)) c a h M).remaining ⊆ initial := by
          rw [hrem]
          exact Finset.sdiff_subset.trans hs
        exact (model.restart_iff _ hsrem M).mp halt
      · exact Or.inr halt
  have hstruct : ∀ s ⊆ initial,
      (actualPhaseBlock model c a M s).Valid model.coordinates ∧
      (actualPhaseBlock model c a M s).chosen ⊆ s ∧
      (actualPhaseBlock model c a M s).remaining = s \ (actualPhaseBlock model c a M s).chosen ∧
      (actualPhaseBlock model c a M s).chosen.card ≤ B := by
    intro s hs
    by_cases hf : labelSpan ℝ (fun i => realVector (model.coordinates i)) s = ⊤
    · have hg := hgood s hs hf
      exact ⟨hg.1, hg.2.1, hg.2.2.1, hg.2.2.2.2.2.1⟩
    · have hn : ¬(s ⊆ initial ∧ labelSpan ℝ (fun i => realVector (model.coordinates i)) s = ⊤) :=
        fun H => hf H.2
      simp only [actualPhaseBlock, dif_neg hn]
      refine ⟨greedyBlockSeed_valid model.coordinates s ∅, ?_, ?_, ?_⟩
      · exact Finset.empty_subset _
      · rfl
      · exact Nat.zero_le B
  let F : BoundedBlockSelector model.coordinates initial B :=
    { select := actualPhaseBlock model c a M
      valid := fun s hs => (hstruct s hs).1
      chosen_subset := fun s hs => (hstruct s hs).2.1
      remaining_eq := fun s hs => (hstruct s hs).2.2.1
      size_le := fun s hs => (hstruct s hs).2.2.2 }
  refine ⟨F, rfl, ?_⟩
  intro s hs hf
  have hg := hgood s hs hf
  exact ⟨hg.2.2.2.1, hg.2.2.2.2.1, hg.2.2.2.2.2.2⟩

end
end Optss
