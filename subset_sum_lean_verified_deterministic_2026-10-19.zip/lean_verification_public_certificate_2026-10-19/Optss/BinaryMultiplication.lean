import Optss.BinaryLongDivision

/-!
# Shift-and-add multiplication with width accounting

The computation uses one shift and at most one addition for each multiplier
bit. Exact values, iteration counts and all partial-product widths are proved.
As for binary division, width charges still need a machine-instruction
refinement before they are called a bit-runtime bound.
-/

namespace Optss

structure BinaryMultiplicationResult where
  value : ℕ
  rounds : ℕ
  widthWork : ℕ
  deriving Repr, DecidableEq

def binaryMultiplicationDigits (m : ℕ) : List Bool → BinaryMultiplicationResult
  | [] => ⟨0,0,0⟩
  | b::bs =>
    let out := binaryMultiplicationDigits m bs
    ⟨2*out.value+(if b then m else 0), out.rounds+1,
      out.widthWork+4*(m.size+out.value.size+2)⟩

def binaryMultiplication (m n : ℕ) : BinaryMultiplicationResult :=
  binaryMultiplicationDigits m n.bits

theorem binaryMultiplicationDigits_correct (m : ℕ) (bs : List Bool) :
    (binaryMultiplicationDigits m bs).value = m*binaryDigitsValue bs := by
  induction bs with
  | nil => simp [binaryMultiplicationDigits, binaryDigitsValue]
  | cons b bs ih =>
    simp only [binaryMultiplicationDigits, binaryDigitsValue, ih]
    cases b <;> simp <;> ring

theorem binaryMultiplicationDigits_rounds (m : ℕ) (bs : List Bool) :
    (binaryMultiplicationDigits m bs).rounds = bs.length := by
  induction bs with
  | nil => rfl
  | cons b bs ih => simp [binaryMultiplicationDigits, ih]

theorem nat_mul_size_le (m n : ℕ) : (m*n).size ≤ m.size+n.size := by
  apply Nat.size_le.mpr
  rw [pow_add]
  exact (Nat.mul_le_mul_right n (Nat.lt_size_self m).le).trans_lt
    (Nat.mul_lt_mul_of_pos_left (Nat.lt_size_self n) (by positivity))

theorem binaryMultiplicationDigits_value_bits (m : ℕ) (bs : List Bool) :
    (binaryMultiplicationDigits m bs).value.size ≤ m.size+bs.length := by
  rw [binaryMultiplicationDigits_correct]
  exact (nat_mul_size_le _ _).trans (Nat.add_le_add_left
    (Nat.size_le.mpr (binaryDigitsValue_lt_pow bs)) _)

theorem binaryMultiplicationDigits_widthWork (m : ℕ) (bs : List Bool) :
    (binaryMultiplicationDigits m bs).widthWork ≤ 4*bs.length*(2*m.size+bs.length+2) := by
  induction bs with
  | nil => simp [binaryMultiplicationDigits]
  | cons b bs ih =>
    have hs := binaryMultiplicationDigits_value_bits m bs
    simp only [binaryMultiplicationDigits, List.length_cons]
    nlinarith

theorem binaryMultiplication_correct (m n : ℕ) : (binaryMultiplication m n).value = m*n := by
  rw [binaryMultiplication, binaryMultiplicationDigits_correct, binaryDigitsValue_bits]

theorem binaryMultiplication_rounds (m n : ℕ) : (binaryMultiplication m n).rounds = n.size := by
  rw [binaryMultiplication, binaryMultiplicationDigits_rounds, Nat.size_eq_bits_len]

theorem binaryMultiplication_widthWork (m n : ℕ) :
    (binaryMultiplication m n).widthWork ≤ 4*n.size*(2*m.size+n.size+2) := by
  simpa only [binaryMultiplication, Nat.size_eq_bits_len] using
    binaryMultiplicationDigits_widthWork m n.bits

end Optss
