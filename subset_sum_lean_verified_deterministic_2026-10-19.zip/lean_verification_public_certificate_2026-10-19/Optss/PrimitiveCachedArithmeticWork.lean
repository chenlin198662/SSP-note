import Optss.CubicCachedArithmeticWork
import Optss.CachedPrimitiveOperandBounds
import Optss.ReductionPrimitives

/-!
# Polynomial charge for every scalar primitive of cached lattice reduction

All rational arithmetic, rounding, comparisons and integer row cells are now
charged by their verified implementations. Operand bounds come from the actual
input and actual partial-sweep traces. This counts scalar Boolean gates and list
visits; container administration, representation conversion and initial fuel
construction remain separately uncharged operations.
-/

namespace Optss

structure CubicReductionBackend where
  primitives : ReductionPrimitives
  constant : ℕ
  positive : 0 < constant
  rational_charge : ∀ (p q : ℚ) (L : ℕ), RationalBitBound p L → RationalBitBound q L →
    (primitives.add p q).2 ≤ constant*(L+1)^3 ∧
    (primitives.sub p q).2 ≤ constant*(L+1)^3 ∧
    (primitives.mul p q).2 ≤ constant*(L+1)^3 ∧
    (primitives.div p q).2 ≤ constant*(L+1)^3
  round_charge : ∀ (p : ℚ) (L : ℕ), RationalBitBound p L →
    (primitives.round p).2 ≤ constant*(L+1)^3
  lt_charge : ∀ (p q : ℚ) (L : ℕ), RationalBitBound p L → RationalBitBound q L →
    (primitives.lt p q).2 ≤ constant*(L+1)^3
  rowCell_charge : ∀ (u c v : ℤ) (L : ℕ), u.natAbs.size ≤ L →
    c.natAbs.size ≤ L → v.natAbs.size ≤ L →
    (primitives.rowCell u c v).2 ≤ constant*(L+1)^3

def CubicReductionBackend.rationalBackend (backend : CubicReductionBackend) : CubicRationalBackend where
  arithmetic := backend.primitives
  constant := backend.constant
  positive := backend.positive
  charge_le := backend.rational_charge

/-- Concrete Boolean-list scalar implementations satisfy every backend law. -/
def booleanCubicReductionBackend : CubicReductionBackend where
  primitives := booleanReductionPrimitives
  constant := 65536
  positive := by decide
  rational_charge := by
    intro p q L hp hq
    have h := booleanReductionPrimitives_scalar_bounds p q 0 0 0 L hp hq
      (by simp) (by simp) (by simp)
    exact ⟨h.1,h.2.1,h.2.2.1,h.2.2.2.1⟩
  round_charge := by
    intro p L hp
    have h := booleanReductionPrimitives_scalar_bounds p p 0 0 0 L hp hp
      (by simp) (by simp) (by simp)
    exact h.2.2.2.2.2.1
  lt_charge := by
    intro p q L hp hq
    have h := booleanReductionPrimitives_scalar_bounds p q 0 0 0 L hp hq
      (by simp) (by simp) (by simp)
    exact h.2.2.2.2.1
  rowCell_charge := by
    intro u c v L hu hc hv
    have h := booleanIntegerRowCell_cost u c v L hu hc hv
    exact h.trans (Nat.mul_le_mul (by decide : 128 ≤ 65536)
      (Nat.pow_le_pow_right (by omega : 1 ≤ L+1) (by omega : 2 ≤ 3)))

namespace PrimitiveWork
open scoped BigOperators
variable {r d : ℕ}

private theorem get_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (i : Fin n) :
    (Vector.ofFn f).get i = f i := by
  change (Vector.ofFn f)[i.val] = f i
  simp

/-- Actual integer row-cell charges, with the array evaluating each cell once. -/
theorem primitiveIntegerRowUpdate_work (backend : CubicReductionBackend)
    (D : IntegerMatrixData r d) (k j : Fin r) (q : ℤ) (L : ℕ)
    (hk : ∀ l, (integerMatrixDataRows D k l).natAbs.size ≤ L)
    (hj : ∀ l, (integerMatrixDataRows D j l).natAbs.size ≤ L)
    (hq : q.natAbs.size ≤ L) :
    (primitiveIntegerRowUpdate backend.primitives D k j q).2 ≤
      d*(backend.constant*(L+1)^3) := by
  unfold primitiveIntegerRowUpdate
  simp only [get_ofFn]
  calc
    _ ≤ ∑ _l : Fin d, backend.constant*(L+1)^3 := by
      apply Finset.sum_le_sum
      intro l _
      exact backend.rowCell_charge _ _ _ L (hk l) hq (hj l)
    _ = _ := by simp

theorem primitiveReduceIntegerRow_cubic_work_of_states (backend : CubicReductionBackend) (D : IntegerMatrixData r d)
    (k : Fin r) (n : ℕ) (hn : n ≤ k.val) (H P : ℕ)
    (hstates : ∀ B ∈ integerRowSweepTrace (integerMatrixDataRows D) k n hn,
      LinearIndependent ℝ (fun i j => (B i j:ℝ)) ∧ gramPotential B ≤ P ∧
        (∀ i j, |B i j| ≤ (H:ℤ))) :
    (primitiveReduceIntegerRow backend.primitives D k n hn).2 ≤
      n*cachedInnerArithmeticBound r d*CubicWork.cachedWorkBound backend.rationalBackend r d H P := by
  induction n generalizing D with
  | zero => simp [primitiveReduceIntegerRow]
  | succ n ih =>
    let A := integerMatrixDataRows D
    have hmem : A ∈ integerRowSweepTrace A k (n+1) hn := by
      rw [integerRowSweepTrace]
      exact List.mem_cons_self
    obtain ⟨hA,hP,hH⟩ := hstates A hmem
    let j : Fin r := ⟨n, by omega⟩
    let T := (meteredGSTable backend.primitives (rationalIntegerRows A) r le_rfl).1
    let coef := meteredGsCoefficient backend.primitives (rationalIntegerRows A) T k j
    let q := (backend.primitives.round coef.1).1
    let W := (primitiveIntegerRowUpdate backend.primitives D k j q).1
    have hq : q = round (rationalGsCoefficient (rationalIntegerRows A) k j) := by
      dsimp only [q, coef, T]
      rw [backend.primitives.round_value, meteredGsCoefficient_value, meteredGSTable_value, cachedGsCoefficient_correct]
    have hW : integerMatrixDataRows W = Function.update A k (A k - q • A j) := by
      dsimp only [W]
      rw [primitiveIntegerRowUpdate_value, integerMatrixDataRows_materialize]
    have htail : ∀ B ∈ integerRowSweepTrace (integerMatrixDataRows W) k n (by omega),
        LinearIndependent ℝ (fun i j => (B i j:ℝ)) ∧ gramPotential B ≤ P ∧
          (∀ i j, |B i j| ≤ (H:ℤ)) := by
      intro B hB
      apply hstates B
      rw [integerRowSweepTrace]
      apply List.mem_cons_of_mem
      simpa only [hW, hq] using hB
    have ht := ih W (by omega) htail
    have htable := CubicWork.meteredGSTable_cubic_work backend.rationalBackend A hA H hH r le_rfl
    have hT : (T.get j).get = rationalGramSchmidt (rationalIntegerRows A) j := by
      dsimp only [T]
      rw [meteredGSTable_value]
      exact cachedGSTable_full_correct _ j
    have hc := CubicWork.meteredGsCoefficient_cubic_work backend.rationalBackend A hA H hH T k j hT
    have hmono := CubicWork.cachedWorkBound_mono backend.rationalBackend r d (H := H) (H' := H) le_rfl hP
    have htable' := htable.trans (Nat.mul_le_mul_left (r*(r*(4*d+1)+d*(2*r+1))) hmono)
    have hc' := hc.trans (Nat.mul_le_mul_left (4*d+1) hmono)
    let L := cachedArithmeticBits r d H (gramPotential A)
    have hcoef : RationalBitBound coef.1 L := by
      dsimp only [coef, T]
      rw [meteredGsCoefficient_value, meteredGSTable_value, cachedGsCoefficient_correct]
      exact cached_coefficient_operand_bits A hA H hH k j
    have hround : (backend.primitives.round coef.1).2 ≤
        CubicWork.cachedWorkBound backend.rationalBackend r d H P :=
      (backend.round_charge coef.1 L hcoef).trans hmono
    have hqbits : q.natAbs.size ≤ L := by
      rw [hq]
      exact cached_rounded_coefficient_bits A hA H hH k j
    have hu := primitiveIntegerRowUpdate_work backend D k j q L
      (cached_integer_cell_operand_bits A H hH k)
      (cached_integer_cell_operand_bits A H hH j) hqbits
    have hu' : (primitiveIntegerRowUpdate backend.primitives D k j q).2 ≤
        2*d*CubicWork.cachedWorkBound backend.rationalBackend r d H P := by
      calc
        _ ≤ d*CubicWork.cachedWorkBound backend.rationalBackend r d H (gramPotential A) := hu
        _ ≤ (2*d)*CubicWork.cachedWorkBound backend.rationalBackend r d H P :=
          Nat.mul_le_mul (by omega) hmono
    rw [primitiveReduceIntegerRow]
    change (meteredGSTable backend.primitives (rationalIntegerRows A) r le_rfl).2 +
      coef.2 + (backend.primitives.round coef.1).2 +
      (primitiveIntegerRowUpdate backend.primitives D k j q).2 +
      (primitiveReduceIntegerRow backend.primitives W k n (by omega)).2 ≤ _
    calc
      _ ≤ (r*(r*(4*d+1)+d*(2*r+1)))*CubicWork.cachedWorkBound backend.rationalBackend r d H P +
          (4*d+1)*CubicWork.cachedWorkBound backend.rationalBackend r d H P +
          CubicWork.cachedWorkBound backend.rationalBackend r d H P +
          2*d*CubicWork.cachedWorkBound backend.rationalBackend r d H P +
          n*cachedInnerArithmeticBound r d*CubicWork.cachedWorkBound backend.rationalBackend r d H P :=
        Nat.add_le_add (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add htable' hc') hround) hu') ht
      _ = _ := by unfold cachedInnerArithmeticBound; ring


theorem primitiveReduceIntegerAll_cubic_work_of_states (backend : CubicReductionBackend) (D : IntegerMatrixData r d)
    (n : ℕ) (hn : n ≤ r) (H P : ℕ)
    (hstates : ∀ (k : Fin r), k.val < n → ∀ B ∈ integerRowSweepTrace
      (rationalReduceIntegerAll (integerMatrixDataRows D) k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl,
      LinearIndependent ℝ (fun i j => (B i j:ℝ)) ∧ gramPotential B ≤ P ∧
        (∀ i j, |B i j| ≤ (H:ℤ))) :
    (primitiveReduceIntegerAll backend.primitives D n hn).2 ≤
      n*r*cachedInnerArithmeticBound r d*CubicWork.cachedWorkBound backend.rationalBackend r d H P := by
  induction n with
  | zero => simp [primitiveReduceIntegerAll]
  | succ n ih =>
    have hi := ih (by omega) (fun k hk => hstates k (by omega))
    let C := (primitiveReduceIntegerAll backend.primitives D n (by omega)).1
    have hC : integerMatrixDataRows C =
        rationalReduceIntegerAll (integerMatrixDataRows D) n (by omega) := by
      dsimp only [C]
      rw [primitiveReduceIntegerAll_value, materializedReduceIntegerAll_eq,
        cachedReduceIntegerAll_eq]
    have hc := primitiveReduceIntegerRow_cubic_work_of_states backend C ⟨n, by omega⟩ n le_rfl H P
      (by intro B hB; exact hstates ⟨n, by omega⟩ (by change n < n+1; omega) B (by simpa only [hC] using hB))
    have hnr : n ≤ r := by omega
    have hc' := hc.trans (Nat.mul_le_mul_right (CubicWork.cachedWorkBound backend.rationalBackend r d H P)
      (Nat.mul_le_mul_right (cachedInnerArithmeticBound r d) hnr))
    rw [primitiveReduceIntegerAll]
    change (primitiveReduceIntegerAll backend.primitives D n (by omega)).2 +
      (primitiveReduceIntegerRow backend.primitives C ⟨n, by omega⟩ n le_rfl).2 ≤ _
    calc
      _ ≤ n*r*cachedInnerArithmeticBound r d*CubicWork.cachedWorkBound backend.rationalBackend r d H P +
          r*cachedInnerArithmeticBound r d*CubicWork.cachedWorkBound backend.rationalBackend r d H P := Nat.add_le_add hi hc'
      _ = _ := by ring

theorem primitiveReduceIntegerAll_cubic_work (backend : CubicReductionBackend) (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ)))
    (H P : ℕ) (hP : gramPotential (integerMatrixDataRows D) ≤ P)
    (hH : ∀ i j, |integerMatrixDataRows D i j| ≤ (H:ℤ)) (n : ℕ) (hn : n ≤ r) :
    (primitiveReduceIntegerAll backend.primitives D n hn).2 ≤
      n*r*cachedInnerArithmeticBound r d*
        CubicWork.cachedWorkBound backend.rationalBackend r d (sweepArithmeticHeight r d H P) P := by
  apply primitiveReduceIntegerAll_cubic_work_of_states backend
  intro k hk B hB
  obtain ⟨hind,hp⟩ := outerSweep_innerTrace_independent_potential
    (integerMatrixDataRows D) hD k B hB
  refine ⟨hind, hp ▸ hP, ?_⟩
  intro i j
  have hb := outerSweep_innerTrace_all_entries (integerMatrixDataRows D) hD H hH k B hB i j
  have hm := sweepArithmeticHeight_mono r d (H := H) (H' := H) le_rfl hP
  have hbound : (B i j).natAbs ≤ sweepArithmeticHeight r d H P := hb.trans hm
  simpa only [Int.natCast_natAbs] using (show ((B i j).natAbs:ℤ) ≤ (sweepArithmeticHeight r d H P:ℤ) by exact_mod_cast hbound)

theorem primitiveLovaszPair_cubic_work (backend : CubicReductionBackend) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (T : RationalGSTable r d)
    (j k : Fin r)
    (hT : ∀ i, (T.get i).get = rationalGramSchmidt (rationalIntegerRows A) i) :
    (primitiveLovaszPair backend.primitives (rationalIntegerRows A) T j k).2 ≤
      (8*d+7)*CubicWork.cachedWorkBound backend.rationalBackend r d H (gramPotential A) := by
  let Q := rationalIntegerRows A
  let K := gsArithmeticBase d H (gramPotential A)
  let L := cachedArithmeticBits r d H (gramPotential A)
  let W := CubicWork.cachedWorkBound backend.rationalBackend r d H (gramPotential A)
  let u := rationalGsCoefficient Q k j
  let x := rationalDot (rationalGramSchmidt Q k) (rationalGramSchmidt Q k)
  let y := rationalDot (rationalGramSchmidt Q j) (rationalGramSchmidt Q j)
  have hK : 4 ≤ K := by unfold K gsArithmeticBase; omega
  have hc : ∀ q, RationalSizeBound q (cachedOperandMagnitude r d K) → RationalBitBound q L :=
    fun q hq => cachedOperandMagnitude_to_bits r d K hK hq
  have hu : RationalBitBound u L := hc _ ((rationalGsCoefficient_size A hA H hH k j).mono
    (cachedOperandMagnitude_ge_pow r d K 4 (by omega) (by omega)))
  have hx : RationalBitBound x L := (cachedDot_operands_bits A hA H hH k k).2
  have hy : RationalBitBound y L := (cachedDot_operands_bits A hA H hH k j).2
  have hconst : ∀ z : ℚ, RationalSizeBound z 4 → RationalBitBound z L := by
    intro z hz
    apply hc z (hz.mono _)
    exact hK.trans (by simpa only [pow_one] using
      cachedOperandMagnitude_ge_pow r d K 1 (by omega) (by omega))
  have hfour : RationalBitBound 4 L := hconst _ (by norm_num [RationalSizeBound])
  have hthree : RationalBitBound 3 L := hconst _ (by norm_num [RationalSizeBound])
  obtain ⟨huu,huy,hxy,_,_⟩ := rationalLovasz_intermediate_sizes A hA H hH j k
  have hm := cachedOperandMagnitude_ge_lovasz r d K (by omega)
  have huu' : RationalBitBound (u*u) L := hc _ (huu.mono hm)
  have huy' : RationalBitBound (u*u*y) L := hc _ (huy.mono hm)
  have hxy' : RationalBitBound (x+u*u*y) L := hc _ (hxy.mono hm)
  have c1 : (backend.primitives.mul u u).2 ≤ W :=
    (backend.rational_charge _ _ L hu hu).2.2.1
  have c2 : (backend.primitives.mul (u*u) y).2 ≤ W :=
    (backend.rational_charge _ _ L huu' hy).2.2.1
  have c3 : (backend.primitives.add x (u*u*y)).2 ≤ W :=
    (backend.rational_charge _ _ L hx huy').1
  have c4 : (backend.primitives.mul 4 (x+u*u*y)).2 ≤ W :=
    (backend.rational_charge _ _ L hfour hxy').2.2.1
  have c5 : (backend.primitives.mul 3 y).2 ≤ W :=
    (backend.rational_charge _ _ L hthree hy).2.2.1
  have nx := CubicWork.meteredSelfDot_cubic_work backend.rationalBackend A hA H k
  have ny := CubicWork.meteredSelfDot_cubic_work backend.rationalBackend A hA H j
  have nc := CubicWork.meteredGsCoefficient_cubic_work backend.rationalBackend A hA H hH T k j (hT j)
  have hcval : cachedGsCoefficient (rationalIntegerRows A) T k j = u := by
    dsimp only [u, Q, cachedGsCoefficient, rationalGsCoefficient]
    rw [hT j]
  rw [primitiveLovaszPair]
  simp only [meteredRationalDot_value, meteredGsCoefficient_value,
    backend.primitives.mul_value, backend.primitives.add_value]
  simp only [hcval, hT]
  change _ ≤ (8*d+7)*W
  obtain ⟨hleft,hright⟩ := cached_lovasz_comparison_operand_bits A hA H hH j k
  have hcompare : (backend.primitives.lt (4*(x+u*u*y)) (3*y)).2 ≤ W :=
    backend.lt_charge _ _ L hleft hright
  have hnx : (meteredRationalDot backend.primitives
      (rationalGramSchmidt Q k) (rationalGramSchmidt Q k)).2 ≤ 2*d*W := nx
  have hny : (meteredRationalDot backend.primitives
      (rationalGramSchmidt Q j) (rationalGramSchmidt Q j)).2 ≤ 2*d*W := ny
  have hnc : (meteredGsCoefficient backend.primitives Q T k j).2 ≤ (4*d+1)*W := nc
  calc
    _ ≤ 2*d*W+2*d*W+(4*d+1)*W+W+W+W+W+W+W :=
      Nat.add_le_add (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add
        (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add (Nat.add_le_add hnx hny) hnc) c1) c2) c3) c4) c5) hcompare
    _ = _ := by ring

theorem primitiveFailingAdjacentPairs_cubic_work (backend : CubicReductionBackend) (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |integerMatrixDataRows D i j| ≤ (H:ℤ)) :
    (primitiveFailingAdjacentPairs backend.primitives D).2 ≤
      cachedSearchArithmeticBound r d*
        CubicWork.cachedWorkBound backend.rationalBackend r d H (gramPotential (integerMatrixDataRows D)) := by
  let A := integerMatrixDataRows D
  let T := (meteredGSTable backend.primitives (rationalIntegerRows A) r le_rfl).1
  let W := CubicWork.cachedWorkBound backend.rationalBackend r d H (gramPotential A)
  have hT : ∀ i, (T.get i).get = rationalGramSchmidt (rationalIntegerRows A) i := by
    intro i
    dsimp only [T]
    rw [meteredGSTable_value]
    exact cachedGSTable_full_correct _ i
  have ht := CubicWork.meteredGSTable_cubic_work backend.rationalBackend A hD H hH r le_rfl
  have hs : (∑ j : Fin r, ∑ k : Fin r,
      if k.val = j.val+1 then
        (primitiveLovaszPair backend.primitives (rationalIntegerRows A) T j k).2
      else 0) ≤ r*r*(8*d+7)*W := by
    calc
      _ ≤ ∑ _j : Fin r, ∑ _k : Fin r, (8*d+7)*W := by
        apply Finset.sum_le_sum
        intro j _
        apply Finset.sum_le_sum
        intro k _
        split_ifs
        · exact primitiveLovaszPair_cubic_work backend A hD H hH T j k hT
        · exact Nat.zero_le _
      _ = _ := by simp; ring
  unfold primitiveFailingAdjacentPairs
  simp only [get_ofFn, apply_ite Prod.snd]
  calc
    _ ≤ r*(r*(4*d+1)+d*(2*r+1))*W + r*r*(8*d+7)*W := Nat.add_le_add ht hs
    _ = _ := by unfold cachedSearchArithmeticBound; ring

theorem primitiveReductionFuel_cubic_work (backend : CubicReductionBackend) (fuel : ℕ) (D : IntegerMatrixData r d)
    (hD : LinearIndependent ℝ (fun i j => (integerMatrixDataRows D i j:ℝ)))
    (H P : ℕ) (hP : gramPotential (integerMatrixDataRows D) ≤ P)
    (hH : ∀ i j, |integerMatrixDataRows D i j| ≤ (H:ℤ)) (hcover : r*P ≤ H) :
    (primitiveReductionFuel backend.primitives fuel D).work ≤
      ((primitiveReductionFuel backend.primitives fuel D).swaps+1)*
        cachedPassArithmeticBound r d*
        CubicWork.cachedWorkBound backend.rationalBackend r d (sweepArithmeticHeight r d H P) P := by
  induction fuel generalizing D with
  | zero => simp [primitiveReductionFuel]
  | succ n ih =>
    let C := (primitiveReduceIntegerAll backend.primitives D r le_rfl).1
    let A := integerMatrixDataRows C
    let tests := primitiveFailingAdjacentPairs backend.primitives C
    let W := CubicWork.cachedWorkBound backend.rationalBackend r d (sweepArithmeticHeight r d H P) P
    have hCeq : C = materializedReduceIntegerAll D r le_rfl := primitiveReduceIntegerAll_value _ _ _ _
    obtain ⟨hC, hpC, hhC⟩ := materializedFullSweep_invariants D hD
    rw [← hCeq] at hC hpC hhC
    have hCA : LinearIndependent ℝ (fun i j => (A i j:ℝ)) := hC
    have hpA : gramPotential A ≤ P := hpC ▸ hP
    have hHA : ∀ i j, |A i j| ≤ (H:ℤ) := by
      intro i j
      exact (hhC i j).trans (by exact_mod_cast (Nat.mul_le_mul_left r hP).trans hcover)
    have hs := primitiveReduceIntegerAll_cubic_work backend D hD H P hP hH r le_rfl
    have ht := primitiveFailingAdjacentPairs_cubic_work backend C hCA H hHA
    have hmono := CubicWork.cachedWorkBound_mono backend.rationalBackend r d (le_sweepArithmeticHeight r d H P) hpA
    have ht' : tests.2 ≤ cachedSearchArithmeticBound r d*W :=
      ht.trans (Nat.mul_le_mul_left _ hmono)
    have hpass : (primitiveReduceIntegerAll backend.primitives D r le_rfl).2+tests.2 ≤
        cachedPassArithmeticBound r d*W := by
      calc
        _ ≤ r*r*cachedInnerArithmeticBound r d*W+cachedSearchArithmeticBound r d*W :=
          Nat.add_le_add hs ht'
        _ = _ := by unfold cachedPassArithmeticBound; ring
    rw [primitiveReductionFuel]
    split_ifs with hbad
    · let p := leastPairInFinset tests.1 hbad
      have hp : p ∈ failingAdjacentPairs A := by
        have hm := leastPairInFinset_mem tests.1 hbad
        change p ∈ tests.1 at hm
        dsimp only [tests] at hm
        rw [primitiveFailingAdjacentPairs_value, cachedFailingAdjacentPairs_eq A hCA] at hm
        exact hm
      have hpair := (mem_failingAdjacentPairs A p).mp hp
      have hdec : gramPotential (swapRows A p.1 p.2) < gramPotential A :=
        gramPotential_swap_lt_of_three_quarters A hCA p.1 p.2 hpair.1 hpair.2
      have hind : LinearIndependent ℝ (fun i j => (swapRows A p.1 p.2 i j:ℝ)) :=
        hCA.comp (Equiv.swap p.1 p.2) (Equiv.swap p.1 p.2).injective
      let E := materializeIntegerMatrix (swapRows A p.1 p.2)
      have hE : LinearIndependent ℝ (fun i j => (integerMatrixDataRows E i j:ℝ)) := by
        simpa only [E, integerMatrixDataRows_materialize] using hind
      have hpE : gramPotential (integerMatrixDataRows E) ≤ P := by
        simpa only [E, integerMatrixDataRows_materialize] using hdec.le.trans hpA
      have hhE : ∀ i j, |integerMatrixDataRows E i j| ≤ (H:ℤ) := by
        intro i j
        simpa only [E, integerMatrixDataRows_materialize, swapRows] using
          hHA ((Equiv.swap p.1 p.2) i) j
      have hi := ih E hE hpE hhE
      change _ + tests.2 + (primitiveReductionFuel backend.primitives n E).work ≤
        ((primitiveReductionFuel backend.primitives n E).swaps+1+1)*cachedPassArithmeticBound r d*W
      calc
        _ ≤ cachedPassArithmeticBound r d*W +
            ((primitiveReductionFuel backend.primitives n E).swaps+1)*cachedPassArithmeticBound r d*W :=
          Nat.add_le_add hpass hi
        _ = _ := by ring
    · simpa only [MeteredLatticeResult.work, MeteredLatticeResult.swaps, zero_add, one_mul] using hpass

theorem primitiveReductionFuel_cubic_initial_work (backend : CubicReductionBackend) (fuel : ℕ)
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) :
    (primitiveReductionFuel backend.primitives fuel (materializeIntegerMatrix A)).work ≤
      ((materializedReductionFuel fuel (materializeIntegerMatrix A)).2+1)*
        (32*(r+1)^4*(d+1))*
        (backend.constant*(8*(2*(r+d)+10)*(2*r+4)*(loopArithmeticBase r d H (gramPotential A)).size+1)^3) := by
  have hind : LinearIndependent ℝ (fun i j =>
      (integerMatrixDataRows (materializeIntegerMatrix A) i j:ℝ)) := by
    simpa only [integerMatrixDataRows_materialize] using hA
  have hh : ∀ i j, |integerMatrixDataRows (materializeIntegerMatrix A) i j| ≤
      (max H (r*gramPotential A):ℕ) := by
    intro i j
    rw [integerMatrixDataRows_materialize]
    exact (hH i j).trans (by exact_mod_cast le_max_left H (r*gramPotential A))
  have hb := primitiveReductionFuel_cubic_work backend fuel (materializeIntegerMatrix A) hind
    (max H (r*gramPotential A)) (gramPotential A)
    (by rw [integerMatrixDataRows_materialize]) hh (le_max_right _ _)
  have he := congrArg Prod.snd (primitiveReductionFuel_value backend.primitives fuel
    (materializeIntegerMatrix A))
  change (primitiveReductionFuel backend.primitives fuel (materializeIntegerMatrix A)).swaps =
    (materializedReductionFuel fuel (materializeIntegerMatrix A)).2 at he
  rw [he] at hb
  exact hb.trans (Nat.mul_le_mul
    (Nat.mul_le_mul_left _ (cachedPassArithmeticBound_le r d))
    (CubicWork.sweep_cachedWorkBound_le backend.rationalBackend r d (max H (r*gramPotential A)) (gramPotential A)))

theorem primitiveCachedData_work_le (backend : CubicReductionBackend) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) :
    (primitiveCachedData backend.primitives A).work ≤
      ((cachedReductionData A).2+1)*(32*(r+1)^4*(d+1))*
        (backend.constant*(8*(2*(r+d)+10)*(2*r+4)*(loopArithmeticBase r d H (gramPotential A)).size+1)^3) := by
  rw [primitiveCachedData_def, cachedReductionData_def]
  exact primitiveReductionFuel_cubic_initial_work backend _ A hA H hH

theorem primitiveCachedData_input_polynomial (backend : CubicReductionBackend) (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) :
    (primitiveCachedData backend.primitives A).work ≤
      (3*(r*(r+1)+1)*(r.size+d.size+2*H.size+4))*(32*(r+1)^4*(d+1))*
        (backend.constant*(8*(2*(r+d)+10)*(2*r+4)*
          (3*H.size+5*r.size+2*d.size+
            8*(r*(r+1)+1)*(r.size+d.size+2*H.size+4)+12)+1)^3) := by
  have hb := primitiveCachedData_work_le backend A hA H hH
  have hs := (cachedIntegerReduction A hA).swapCount_input_bits A H hH
  have hbits := globalSweepArithmeticBase_input_bits A H hH
  change (cachedReductionData A).2+1 ≤ _ at hs
  change (loopArithmeticBase r d H (gramPotential A)).size ≤ _ at hbits
  apply hb.trans
  apply Nat.mul_le_mul
  · exact Nat.mul_le_mul_right _ hs
  · exact Nat.mul_le_mul_left backend.constant (Nat.pow_le_pow_left
      (Nat.add_le_add_right (Nat.mul_le_mul_left _ hbits) 1) 3)

end PrimitiveWork

/-- Polynomial total scalar charge for the actual Boolean implementation.
Every scalar primitive is included; no arithmetic operation is left with a
unit-cost placeholder. Representation conversions, array administration and
initial fuel construction are not part of this scalar counter. -/
theorem booleanPrimitiveCachedData_input_polynomial {r d : ℕ}
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) :
    (primitiveCachedData booleanReductionPrimitives A).work ≤
      (3*(r*(r+1)+1)*(r.size+d.size+2*H.size+4))*(32*(r+1)^4*(d+1))*
        (65536*(8*(2*(r+d)+10)*(2*r+4)*
          (3*H.size+5*r.size+2*d.size+
            8*(r*(r+1)+1)*(r.size+d.size+2*H.size+4)+12)+1)^3) :=
  PrimitiveWork.primitiveCachedData_input_polynomial booleanCubicReductionBackend A hA H hH

end Optss
