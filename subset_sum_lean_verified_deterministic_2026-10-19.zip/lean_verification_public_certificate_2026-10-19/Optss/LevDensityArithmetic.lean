import Mathlib.Algebra.Order.Chebyshev
import Mathlib.Tactic

/-!
# The numerical density estimate in Lev's interval theorem

This proves the ordered-minimum inequality used in Proposition 1 of
V. F. Lev, "Consecutive integers in high-multiplicity sumsets",
arXiv:0806.4580 (2010), pp. 4–8.
Primary source: https://arxiv.org/pdf/0806.4580 .
The proof below replaces the source's red/blue grouping by a chord bound
for a concave minimum and Chebyshev's sum inequality.
-/
namespace Optss
open scoped BigOperators

private theorem lev_weight_sum (k : ℕ) :
    ∑ i ∈ Finset.range k, (2 * (i : ℤ) + 1 - k) = 0 := by
  induction k with
  | zero => simp
  | succ k ih =>
    have h : ∑ i ∈ Finset.range k, (2 * (i : ℤ) + 1 - (k + 1)) =
        (∑ i ∈ Finset.range k, (2 * (i : ℤ) + 1 - k)) - k := by
      calc
        _ = ∑ i ∈ Finset.range k, ((2 * (i : ℤ) + 1 - k) - 1) := by
          apply Finset.sum_congr rfl; intro i hi; ring
        _ = _ := by rw [Finset.sum_sub_distrib]; simp
    rw [Finset.sum_range_succ]
    push_cast
    rw [h, ih]
    ring

/-- A monotone sequence has nonnegative scalar product with the centered
index sequence. -/
theorem lev_centered_weight_nonneg (k : ℕ) (t : ℕ → ℤ)
    (hmono : MonotoneOn t (Finset.range k)) :
    0 ≤ ∑ i ∈ Finset.range k, (2 * (i : ℤ) + 1 - k) * t i := by
  by_cases hk : k = 0
  · subst k; simp
  have hw : MonotoneOn (fun i : ℕ => 2 * (i : ℤ) + 1 - k) (Finset.range k) := by
    intro i hi j hj hij
    exact sub_le_sub_right (add_le_add_right (mul_le_mul_of_nonneg_left
      (by exact_mod_cast hij : (i : ℤ) ≤ j) (by norm_num)) 1) _
  have h := (hw.monovaryOn hmono).sum_mul_sum_le_card_mul_sum
  rw [lev_weight_sum] at h
  simp only [zero_mul, Finset.card_range] at h
  have hk' : (0 : ℤ) < k := by exact_mod_cast Nat.pos_of_ne_zero hk
  exact nonneg_of_mul_nonneg_right h hk'

private theorem lev_min_chord (k i : ℕ) (d t : ℤ) (hi : i < k)
    (_hd : 0 ≤ d) (htlo : d ≤ t) (hthi : t ≤ k * d) :
    ((k : ℤ) - 1) * d + (2 * (i : ℤ) + 1 - k) * (t - d) ≤
      ((k : ℤ) - 1) * min t (2 * ((i : ℤ) + 1) * d - t) := by
  have hi' : (i : ℤ) + 1 ≤ k := by exact_mod_cast hi
  have hi0 : (0 : ℤ) ≤ i := by positivity
  have h₁ := mul_nonneg (show 0 ≤ (k : ℤ) - i - 1 by omega) (sub_nonneg.mpr htlo)
  have h₂ := mul_nonneg hi0 (sub_nonneg.mpr hthi)
  rcases le_total t (2 * ((i : ℤ) + 1) * d - t) with h | h
  · rw [min_eq_left h]
    nlinarith
  · rw [min_eq_right h]
    nlinarith

/-- The exact doubled minimum-sum bound underlying Lev 2010, Proposition
1(ii). This is a numerical theorem, with no assumed sumset-growth premise. -/
theorem lev_ordered_min_sum (k : ℕ) (d : ℤ) (t : ℕ → ℤ) (hd : 0 ≤ d)
    (hmono : MonotoneOn t (Finset.range k))
    (hlo : ∀ i < k, d ≤ t i) (hhi : ∀ i < k, t i ≤ k * d) :
    (k : ℤ) * d ≤ ∑ i ∈ Finset.range k, min (t i) (2 * ((i : ℤ) + 1) * d - t i) := by
  rcases k with _ | k
  · simp
  rcases k with _ | k
  · have ht : t 0 = d := by have h₁ := hlo 0 (by omega); have h₂ := hhi 0 (by omega); norm_num at h₂; exact h₂.antisymm h₁
    simp [ht]; omega
  have hk : (0 : ℤ) < (k + 2 : ℕ) - 1 := by omega
  have hc := Finset.sum_le_sum (fun i (hi : i ∈ Finset.range (k + 2)) =>
    lev_min_chord (k + 2) i d (t i) (Finset.mem_range.mp hi) hd
      (hlo i (Finset.mem_range.mp hi)) (hhi i (Finset.mem_range.mp hi)))
  have hw := lev_centered_weight_nonneg (k + 2) t hmono
  have hs : (∑ i ∈ Finset.range (k + 2),
      ((((k + 2 : ℕ) : ℤ) - 1) * d +
        (2 * (i : ℤ) + 1 - (k + 2 : ℕ)) * (t i - d))) =
      (k + 2 : ℕ) * ((((k + 2 : ℕ) : ℤ) - 1) * d) +
      ∑ i ∈ Finset.range (k + 2), (2 * (i : ℤ) + 1 - (k + 2 : ℕ)) * t i := by
    simp_rw [mul_sub]
    rw [Finset.sum_add_distrib, Finset.sum_sub_distrib]
    simp_rw [← Finset.sum_mul]
    rw [lev_weight_sum]
    simp [nsmul_eq_mul, mul_assoc]
    ring
  rw [hs, ← Finset.mul_sum] at hc
  nlinarith

/-- The one-fewer-summand version used in Proposition 1(i). Appending the
common upper diameter to the ordered sequence gives the exact endpoint loss. -/
theorem lev_ordered_min_sum_endpoint (k : ℕ) (d L : ℤ) (t : ℕ → ℤ) (hd : 0 ≤ d)
    (hmono : MonotoneOn t (Finset.range k))
    (hlo : ∀ i < k, d ≤ t i) (hhi : ∀ i < k, t i ≤ L)
    (hLd : d ≤ L) (hL : L ≤ (k + 1 : ℕ) * d) :
    (k + 1 : ℕ) * d - L ≤
      ∑ i ∈ Finset.range k, min (t i) (2 * ((i : ℤ) + 1) * d - t i) := by
  let u : ℕ → ℤ := fun i => if i < k then t i else L
  have hu : MonotoneOn u (Finset.range (k + 1)) := by
    intro i hi j hj hij
    simp only [Finset.mem_coe, Finset.mem_range] at hi hj
    dsimp [u]
    split_ifs with hik hjk
    · exact hmono (Finset.mem_range.mpr hik) (Finset.mem_range.mpr hjk) hij
    · exact hhi i hik
    · omega
    · rfl
  have he := lev_ordered_min_sum (k + 1) d u hd hu
    (fun i hi => by dsimp [u]; split_ifs with hik; exact hlo i hik; exact hLd)
    (fun i hi => by dsimp [u]; split_ifs with hik; exact (hhi i hik).trans hL; exact hL)
  rw [Finset.sum_range_succ] at he
  have hlast : min (u k) (2 * ((k : ℤ) + 1) * d - u k) = L := by
    simp only [u, lt_self_iff_false, ↓reduceIte]
    rw [min_eq_left]; push_cast at hL; linarith
  have hsum : (∑ i ∈ Finset.range k, min (u i) (2 * ((i : ℤ) + 1) * d - u i)) =
      ∑ i ∈ Finset.range k, min (t i) (2 * ((i : ℤ) + 1) * d - t i) := by
    apply Finset.sum_congr rfl
    intro i hi
    simp [u, Finset.mem_range.mp hi]
  rw [hlast, hsum] at he
  omega

end Optss
