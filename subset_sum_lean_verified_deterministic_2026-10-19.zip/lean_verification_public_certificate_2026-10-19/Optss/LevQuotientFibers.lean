import Optss.LevResidueGrowth
import Optss.DenseBoxFillingFiniteGroup

/-!
# Quotient fibers for Lev's integer sumset growth theorem

All quotients use the actual stabilizer of the residue sumset. The lower
fiber bounds are derived from occupied cosets and integer Cauchy–Davenport.
-/
namespace Optss
noncomputable section
open scoped Pointwise BigOperators

/-- Projection modulo the actual translation stabilizer of a finite set. -/
def stabilizerProjection {G : Type*} [AddCommGroup G] (S : Finset G) :
    G →+ G ⧸ AddAction.stabilizer G (S : Set G) :=
  QuotientAddGroup.mk' (AddAction.stabilizer G (S : Set G))

theorem stabilizerProjection_eq_iff {G : Type*} [AddCommGroup G] [DecidableEq G]
    (S : Finset G) (hS : S.Nonempty) (x y : G) :
    stabilizerProjection S x = stabilizerProjection S y ↔ x ∈ y +ᵥ S.addStab := by
  change (x : G ⧸ AddAction.stabilizer G (S : Set G)) = y ↔ _
  rw [QuotientAddGroup.eq_iff_sub_mem]
  change x - y ∈ (AddAction.stabilizer G (S : Set G) : Set G) ↔ _
  rw [← Finset.coe_addStab hS]
  constructor
  · intro h
    exact Finset.mem_vadd_finset.mpr ⟨x - y, h, by simp [vadd_eq_add, sub_eq_add_neg, add_comm]⟩
  · intro h
    obtain ⟨z, hz, hx⟩ := Finset.mem_vadd_finset.mp h
    have he : x - y = z := by rw [← hx, vadd_eq_add]; abel
    simpa only [he] using hz

/-- An integer map to the stabilizer quotient of the residue group. -/
def integerStabilizerProjection (l : ℕ) (S : Finset (ZMod l)) :
    ℤ →+ ZMod l ⧸ AddAction.stabilizer (ZMod l) (S : Set (ZMod l)) :=
  (stabilizerProjection S).comp (Int.castAddHom (ZMod l))

/-- A uniform lower bound for each occupied quotient fiber, directly from
its actual residue image and its stabilizer saturation. -/
theorem integer_stabilizer_fiber_card (A : Finset ℤ) (l : ℕ) (S : Finset (ZMod l))
    (hS : S.Nonempty) (a : ℤ) (ha : a ∈ A) :
    ((A.image (fun x : ℤ => (x : ZMod l))).card : ℤ) + S.addStab.card -
        (A.image (fun x : ℤ => (x : ZMod l)) + S.addStab).card ≤
      (A.filter (fun x => integerStabilizerProjection l S x =
        integerStabilizerProjection l S a)).card := by
  have h := integer_occupied_coset_card A l S hS (a : ZMod l)
    (Finset.mem_image.mpr ⟨a, ha, rfl⟩)
  have he : (A.filter (fun x => integerStabilizerProjection l S x =
        integerStabilizerProjection l S a)) =
      A.filter (fun x : ℤ => (x : ZMod l) ∈ (a : ZMod l) +ᵥ S.addStab) := by
    ext x
    simp only [Finset.mem_filter]
    change (x ∈ A ∧ stabilizerProjection S (x : ZMod l) =
      stabilizerProjection S (a : ZMod l)) ↔ _
    rw [stabilizerProjection_eq_iff S hS]
  rw [he]
  omega

/-- Quantitative lower bound for every occupied fiber of an actual integer
sumset in the stabilizer quotient. -/
theorem integer_list_stabilizer_fiber_card (L : List (Finset ℤ)) (l : ℕ)
    (S : Finset (ZMod l)) (hS : S.Nonempty) (x : ℤ) (hx : x ∈ L.sum) :
    (L.map (fun A => ((A.image (fun y : ℤ => (y : ZMod l))).card : ℤ) + S.addStab.card -
      (A.image (fun y : ℤ => (y : ZMod l)) + S.addStab).card)).sum - (L.length : ℤ) + 1 ≤
      (L.sum.filter (fun y => integerStabilizerProjection l S y =
        integerStabilizerProjection l S x)).card := by
  refine integer_list_fiber_card _ _ _ ?_ x hx
  intro A _ a ha
  exact integer_stabilizer_fiber_card A l S hS a ha

end
end Optss
