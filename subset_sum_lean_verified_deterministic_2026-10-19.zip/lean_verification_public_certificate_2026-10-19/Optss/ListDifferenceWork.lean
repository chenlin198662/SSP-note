import Optss.ListDifferenceSupport
import Optss.ListBooleanConvolutionWork

/-! Exact source-work accumulation for a structural number of support
doublings followed by one reflected convolution. Thus 8S−8S takes four
support convolutions, and 2S−2S takes two. -/
namespace Optss
set_option maxRecDepth 4096

def listBooleanDoublingsWork (depth : List Bool) : List Bool → List Bool → ℕ
  | [],_ => 1
  | _::steps,input =>
    let doubled := listBooleanConvolution depth input input
    listBooleanConvolutionWork depth input input+listBooleanDoublingsWork depth steps doubled+2

def listBooleanDifferenceWork (depth : List Bool) (steps input : List Bool) : ℕ :=
  let sums := listBooleanDoublings depth steps input
  listBooleanDoublingsWork depth steps input+
    listBooleanConvolutionWork depth sums (listCyclicReflect sums)+2*sums.length+4

theorem listBooleanDoublings_length (depth steps input : List Bool)
    (hinput : input.length=2^depth.length) :
    (listBooleanDoublings depth steps input).length=2^depth.length := by
  induction steps generalizing input with
  | nil => exact hinput
  | cons b steps ih =>
    exact ih _ (listBooleanConvolution_length depth input input hinput hinput)

theorem listBooleanDoublingsWork_bound (depth steps input : List Bool)
    (hinput : input.length=2^depth.length) :
    listBooleanDoublingsWork depth steps input≤
      1+steps.length*(2^depth.length*listBooleanConvolutionWorkFactor depth.length+2) := by
  induction steps generalizing input with
  | nil => simp [listBooleanDoublingsWork]
  | cons b steps ih =>
    have hh := ih (listBooleanConvolution depth input input)
      (listBooleanConvolution_length depth input input hinput hinput)
    have hc := listBooleanConvolutionWork_nearlinear depth input input hinput hinput
    simp only [listBooleanDoublingsWork,List.length_cons]
    nlinarith only [hh,hc]

theorem listBooleanDifference_length (depth steps input : List Bool)
    (hinput : input.length=2^depth.length) :
    (listBooleanDifference depth steps input).length=2^depth.length := by
  have h := listBooleanDoublings_length depth steps input hinput
  exact listBooleanConvolution_length depth _ _ h ((listCyclicReflect_length _).trans h)

theorem listBooleanDifferenceWork_bound (depth steps input : List Bool)
    (hinput : input.length=2^depth.length) :
    listBooleanDifferenceWork depth steps input≤
      (steps.length+1)*(2^depth.length*listBooleanConvolutionWorkFactor depth.length+2)+2*2^depth.length+3 := by
  have hs := listBooleanDoublings_length depth steps input hinput
  have hd := listBooleanDoublingsWork_bound depth steps input hinput
  have hc := listBooleanConvolutionWork_nearlinear depth (listBooleanDoublings depth steps input)
    (listCyclicReflect (listBooleanDoublings depth steps input)) hs ((listCyclicReflect_length _).trans hs)
  dsimp only [listBooleanDifferenceWork]
  rw [hs]
  nlinarith only [hd,hc]

end Optss
