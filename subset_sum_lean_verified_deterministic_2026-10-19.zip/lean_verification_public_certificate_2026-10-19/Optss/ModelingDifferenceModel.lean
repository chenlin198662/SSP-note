import Optss.ModelingParameters
import Optss.ModelingDifferenceLift

/-!
# A dense finite model together with its verified difference-set lift

All prime, multiplier and short-interval choices are made from the bounded
small-doubling integer input. The density and the two-isomorphism belong to
the same actual selected part; neither is an externally supplied certificate.
-/
namespace Optss
open scoped BigOperators Pointwise

/-- The actual finite image of a selected short-interval part. -/
def modelingPartImage (p : ℕ) {q : ℕ} (lam : ZMod q) (T : Finset ℤ) : Finset (ZMod p) :=
  T.image (fun a => (modelingResidue lam a : ZMod p))

/-- Positive density and exact lifting for the same actual model. This is the
interface between the finite Fourier theorem and the integer GAP lift. -/
theorem exists_dense_difference_model (S : Finset ℤ) (hne : S.Nonempty) (u : ℕ)
    (hS : ∀ a ∈ S, 0 ≤ a ∧ a ≤ u) (C : ℚ≥0)
    (hC : ((S + S).card : ℚ≥0) ≤ C * S.card) :
    ∃ p q : ℕ, p.Prime ∧ q.Prime ∧ p ≤ 256 * (u + 1) ∧ q ≤ 1024 * (u + 1) ∧
      ∃ (lam : ZMod q) (T : Finset ℤ), lam ≠ 0 ∧ T ⊆ S ∧ S.card ≤ 8 * T.card ∧
        (modelingPartImage p lam T).card = T.card ∧
        (1 / (128 * (C ^ 16 + 1)) : ℚ≥0) ≤
          ((modelingPartImage p lam T).card : ℚ≥0) / p ∧
        IsAddFreimanIso 2 (modelingDoubleDifference T : Set ℤ)
          (((modelingPartImage p lam T + modelingPartImage p lam T) -
            (modelingPartImage p lam T + modelingPartImage p lam T)) : Set (ZMod p))
          (modelingDifferenceMap p lam) := by
  obtain ⟨p, q, hp, hq, hplower, hpupper, hqmin, hpbound, hqbound⟩ :=
    exists_modeling_primes S u hS
  letI : Fact q.Prime := ⟨hq⟩
  have hqu : 8 * (u : ℤ) < q := by
    have h := (le_max_left (16 * u) (2 * p)).trans_lt hqmin
    omega
  have hpcard : ((modelingDifferences S 8).erase 0).card < p :=
    (Finset.card_erase_le).trans_lt (by omega)
  obtain ⟨lam, T, L, U, hlam, hTS, hcard, hinterval, hwidth, hinj, hmodel⟩ :=
    exists_large_freiman_eight_model S p q u hS hqu hpcard
  have himage : (modelingPartImage p lam T).card = T.card :=
    Finset.card_image_iff.mpr hinj
  have hD := modelingDifferences_card_le S hne C hC
  have hS1 : (1 : ℚ≥0) ≤ S.card := by exact_mod_cast Finset.card_pos.mpr hne
  have hpU : (p : ℚ≥0) ≤ 16 * ((modelingDifferences S 8).card + 1) := by
    exact_mod_cast hpupper.le
  have hST : (S.card : ℚ≥0) ≤ 8 * T.card := by exact_mod_cast hcard
  have hdensity : (p : ℚ≥0) ≤ 128 * (C ^ 16 + 1) * T.card := by
    calc
      (p : ℚ≥0) ≤ 16 * ((modelingDifferences S 8).card + 1) := hpU
      _ ≤ 16 * (C ^ 16 * S.card + 1) := by gcongr
      _ ≤ 16 * ((C ^ 16 + 1) * S.card) := by
        apply mul_le_mul_of_nonneg_left _ (by norm_num)
        calc
          C ^ 16 * S.card + 1 ≤ C ^ 16 * S.card + S.card := add_le_add_left hS1 _
          _ = (C ^ 16 + 1) * S.card := by ring
      _ ≤ 16 * ((C ^ 16 + 1) * (8 * T.card)) := by gcongr
      _ = _ := by ring
  refine ⟨p, q, hp, hq, hpbound, hqbound, lam, T, hlam, hTS, hcard, himage, ?_, ?_⟩
  · rw [himage]
    apply (div_le_div_iff₀ (by positivity) (by exact_mod_cast hp.pos)).mpr
    simpa only [one_mul, mul_one, mul_comm] using hdensity
  · have h := modelingDifferenceMap_freimanIso p T lam L U hinterval hwidth hmodel
    rw [modelingDifferenceMap_image p T lam L U hinterval hwidth] at h
    simpa only [modelingPartImage, Finset.coe_add, Finset.coe_sub] using h

end Optss
