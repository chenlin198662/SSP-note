import Optss.ListStoredVertexWidths

/-!
# Computing the boxing widths from rational basis columns and vertices

This total native routine builds the Boolean cofactor inverse of the actual
input basis matrix, multiplies it by the actual vertex columns, and scans the
stored coordinates for maxima and natural ceilings. Its complete source work
has an explicit fixed-rank polynomial in the combined framed input bits.
For genuine rational basis columns the returned integers equal the widths in
the geometric lattice-boxing proof, not merely some enclosing radii.
-/
namespace Optss
open scoped BigOperators
variable {r m : ℕ}

theorem natPolynomial_eval_mono (p : Polynomial ℕ) {a b : ℕ} (hab : a≤b) : p.eval a≤p.eval b := by
  rw [Polynomial.eval_eq_sum,Polynomial.eval_eq_sum,Polynomial.sum,Polynomial.sum]
  exact Finset.sum_le_sum (fun i _ => Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hab i))

theorem listStoredRationalBits_le_of_lengths {a b : ℕ} (A : ListBitRationalMatrixData a b)
    (L : ℕ) (hbits : ∀ i j,(rectangularListFractionMatrix A i j).numerator.length≤L ∧
      (rectangularListFractionMatrix A i j).denominator.length≤L) :
    listStoredRationalBits A≤a+a*b*(1+2*L) := by
  rw [listStoredRationalBits_eq,bitRationalMatrixSize]
  have hs : (∑ i : Fin a,∑ j : Fin b,
      ((((ioMatrixVector A).get i).get j).numerator.length+
       (((ioMatrixVector A).get i).get j).denominator.length))≤a*b*(2*L) := by
    calc
      _ ≤ ∑ _i : Fin a,∑ _j : Fin b,(2*L) := by
        apply Finset.sum_le_sum
        intro i _
        apply Finset.sum_le_sum
        intro j _
        have h := hbits i j
        change (rectangularListFractionMatrix A i j).numerator.length+
          (rectangularListFractionMatrix A i j).denominator.length≤_
        omega
      _ = _ := by simp; ring
  nlinarith

theorem constructedListMatrixInverse_wellFormed (A : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed) (i j : Fin r) :
    (rectangularListFractionMatrix (constructedListMatrixInverse A) i j).WellFormed := by
  simp only [rectangularListFractionMatrix,constructedListMatrixInverse_eq,listStoredMatrixInverse_eq]
  exact booleanMatrixInverse_wellFormed (listFractionMatrix A) hA i j

theorem constructedListMatrixInverse_lengths (A : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed) (i j : Fin r) :
    (rectangularListFractionMatrix (constructedListMatrixInverse A) i j).numerator.length≤
      2*r.factorial*(r*listStoredRationalBits A+2) ∧
    (rectangularListFractionMatrix (constructedListMatrixInverse A) i j).denominator.length≤
      2*r.factorial*(r*listStoredRationalBits A+2) := by
  simp only [rectangularListFractionMatrix,constructedListMatrixInverse_eq,listStoredMatrixInverse_eq]
  exact booleanMatrixInverse_output_bits (listFractionMatrix A) hA (listStoredRationalBits A)
    (listStoredRationalBits_cell A) i j

theorem constructedListMatrixInverse_bits (A : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed) :
    listStoredRationalBits (constructedListMatrixInverse A)≤
      r+r*r*(1+4*r.factorial*(r*listStoredRationalBits A+2)) := by
  have h := listStoredRationalBits_le_of_lengths (constructedListMatrixInverse A)
    (2*r.factorial*(r*listStoredRationalBits A+2)) (constructedListMatrixInverse_lengths A hA)
  convert h using 1; ring

def computedBasisWidths (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m) :
    BooleanListArray (List Bool) r :=
  let coefficients := constructedListMatrixInverse A
  listStoredVertexWidths coefficients V

def computedBasisWidthsWork (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m) : ℕ :=
  let coefficients := constructedListMatrixInverse A
  constructedListMatrixInverseWork A+listStoredVertexWidthsWork coefficients V+1

theorem constructedListMatrixInverse_value_matrix (A : ListBitRationalMatrixData r r)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed) :
    (rectangularListFractionMatrix (constructedListMatrixInverse A)).map bitListFractionValue=
      rationalCofactorInverse ((rectangularListFractionMatrix A).map bitListFractionValue) := by
  ext i j
  simp only [rectangularListFractionMatrix,constructedListMatrixInverse_eq,listStoredMatrixInverse_eq,Matrix.map_apply]
  exact booleanMatrixInverse_value (listFractionMatrix A) hA i j

theorem computedBasisWidths_value (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) (j : Fin r) :
    binaryDigitsValue ((computedBasisWidths A V).toVector.get j)=
      rationalVertexWidth (rationalCofactorInverse ((rectangularListFractionMatrix A).map bitListFractionValue))
        (storedRationalVertices V) j := by
  rw [computedBasisWidths,listStoredVertexWidths_value _ V
    (constructedListMatrixInverse_wellFormed A hA) hV,constructedListMatrixInverse_value_matrix A hA]

/-- Exact equality with the compact-hull widths used in Lemma3.A. -/
theorem computedBasisWidths_eq_basisIntegerWidth
    (b : Basis (Fin r) ℝ (Fin r → ℝ))
    (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed)
    (hcolumns : ∀ i j,(bitListFractionValue (rectangularListFractionMatrix A i j):ℝ)=b j i)
    (hm : 0<m)
    (hK : IsCompact (convexHull ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))))
    (hne : (convexHull ℝ (rationalVertexSet (storedRationalVertices V) : Set (Fin r → ℝ))).Nonempty)
    (j : Fin r) :
    binaryDigitsValue ((computedBasisWidths A V).toVector.get j)=
      basisIntegerWidth b (convexHull ℝ (rationalVertexSet (storedRationalVertices V) : Set _)) hK hne j := by
  rw [computedBasisWidths_value A V hA hV]
  exact rationalCofactor_width_eq_basisIntegerWidth b _ hcolumns (storedRationalVertices V) hm hK hne j

noncomputable def computedBasisIntermediateSize (r : ℕ) : Polynomial ℕ :=
  Polynomial.C r+Polynomial.C (r*r)*(1+Polynomial.C (4*r.factorial)*(Polynomial.C r*Polynomial.X+2))+Polynomial.X

noncomputable def computedBasisWidthsPolynomial (r m : ℕ) : Polynomial ℕ :=
  constructedInversePolynomial r+(storedVertexWidthsPolynomial r m).comp (computedBasisIntermediateSize r)+1

/-- All intermediate input-size premises are discharged from original data. -/
theorem computedBasisWidthsWork_input_polynomial (A : ListBitRationalMatrixData r r) (V : ListBitRationalMatrixData r m)
    (hA : ∀ i j,(rectangularListFractionMatrix A i j).WellFormed)
    (hV : ∀ i j,(rectangularListFractionMatrix V i j).WellFormed) :
    computedBasisWidthsWork A V≤
      (computedBasisWidthsPolynomial r m).eval (listStoredRationalBits A+listStoredRationalBits V) := by
  let N := listStoredRationalBits A+listStoredRationalBits V
  have ha : listStoredRationalBits A≤N := Nat.le_add_right _ _
  have hv : listStoredRationalBits V≤N := Nat.le_add_left _ _
  have hsize := constructedListMatrixInverse_bits A hA
  have htotal : listStoredRationalBits (constructedListMatrixInverse A)+listStoredRationalBits V≤
      (computedBasisIntermediateSize r).eval N := by
    simp only [computedBasisIntermediateSize,Polynomial.eval_add,Polynomial.eval_C,
      Polynomial.eval_mul,Polynomial.eval_ofNat,Polynomial.eval_X,Polynomial.eval_one]
    exact (Nat.add_le_add hsize hv).trans (by gcongr)
  have hi := (constructedListMatrixInverseWork_input_polynomial A hA).trans
    (natPolynomial_eval_mono (constructedInversePolynomial r) ha)
  have hw := (listStoredVertexWidthsWork_input_polynomial (constructedListMatrixInverse A) V
    (constructedListMatrixInverse_wellFormed A hA) hV).trans
      (natPolynomial_eval_mono (storedVertexWidthsPolynomial r m) htotal)
  unfold computedBasisWidthsWork
  simp only [computedBasisWidthsPolynomial,Polynomial.eval_add,Polynomial.eval_one,Polynomial.eval_comp]
  change _≤(constructedInversePolynomial r).eval N+
    (storedVertexWidthsPolynomial r m).eval ((computedBasisIntermediateSize r).eval N)+1
  exact Nat.add_le_add_right (Nat.add_le_add hi hw) 1
end Optss
