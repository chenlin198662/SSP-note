import Optss.BooleanRationalMatrix

/-!
# Fixed-dimension polynomial scalar bounds for rational matrix construction

A single explicitly displayed cubic polynomial covers each determinant,
cofactor inverse and matrix product at its specified dimensions. The input
parameter is a bound on the original normalized numerator/denominator list
lengths. These are the scalar/copy/expression-visit charges defined by the
actual Boolean evaluator; matrix lookup and construction costs are separate.
-/
namespace Optss
open Polynomial

/-- `count` output expressions, each with at most `nodes` tree nodes. -/
noncomputable def matrixScalarWorkPolynomial (count nodes : ℕ) : Polynomial ℕ :=
  C (count*131072*nodes*(nodes+1)^3)*(X+C 2)^3

theorem expression_charge_le_polynomial (count nodes L : ℕ) :
    count*nodes*RationalExpression.charge nodes L≤
      (matrixScalarWorkPolynomial count nodes).eval L := by
  have hinner : nodes*(L+2)+1≤(nodes+1)*(L+2) := by nlinarith
  have hp := Nat.pow_le_pow_left hinner 3
  have hm := Nat.mul_le_mul_left (count*nodes*131072) hp
  unfold matrixScalarWorkPolynomial RationalExpression.charge
  simp only [eval_mul,eval_C,eval_pow,eval_add,eval_X]
  convert hm using 1 <;> ring

theorem booleanMatrixDeterminantWork_polynomial {r : ℕ}
    (A : Matrix (Fin r) (Fin r) BitListFraction)
    (hA : ∀ i j,(A i j).WellFormed) (L : ℕ)
    (hbits : ∀ i j,(A i j).numerator.length≤L ∧ (A i j).denominator.length≤L) :
    booleanMatrixDeterminantWork A≤
      (matrixScalarWorkPolynomial 1 (RationalExpression.determinantNodes r 1)).eval L := by
  apply (booleanMatrixDeterminantWork_bound A hA L hbits).trans
  simpa only [one_mul] using expression_charge_le_polynomial 1 (RationalExpression.determinantNodes r 1) L

theorem booleanMatrixInverseWork_polynomial {r : ℕ}
    (A : Matrix (Fin r) (Fin r) BitListFraction)
    (hA : ∀ i j,(A i j).WellFormed) (L : ℕ)
    (hbits : ∀ i j,(A i j).numerator.length≤L ∧ (A i j).denominator.length≤L) :
    booleanMatrixInverseWork A≤
      (matrixScalarWorkPolynomial (r*r) (2*RationalExpression.determinantNodes r 1+1)).eval L :=
  (booleanMatrixInverseWork_bound A hA L hbits).trans
    (expression_charge_le_polynomial (r*r) (2*RationalExpression.determinantNodes r 1+1) L)

theorem booleanMatrixMulWork_polynomial {r d m : ℕ}
    (A : Matrix (Fin r) (Fin d) BitListFraction)
    (B : Matrix (Fin d) (Fin m) BitListFraction)
    (hA : ∀ i j,(A i j).WellFormed) (hB : ∀ i j,(B i j).WellFormed) (L : ℕ)
    (hbitsA : ∀ i j,(A i j).numerator.length≤L ∧ (A i j).denominator.length≤L)
    (hbitsB : ∀ i j,(B i j).numerator.length≤L ∧ (B i j).denominator.length≤L) :
    booleanMatrixMulWork A B≤(matrixScalarWorkPolynomial (r*m) (4*d+1)).eval L :=
  (booleanMatrixMulWork_bound A B hA hB L hbitsA hbitsB).trans
    (expression_charge_le_polynomial (r*m) (4*d+1) L)
end Optss
