import Optss.IntegerFiberNormalization

/-!
# Exact periods of finite integer fibers

The period is characterized by actual containment in cosets of integer
subgroups. Primitive affine normalization proves that every such period
divides its positive gcd period, so absence of a proper subperiod is
sufficient for the common-period input in CFP Lemma 2.11.
-/
namespace Optss
noncomputable section

/-- Containment in some translate of `vℤ`. -/
def HasIntegerPeriod (A : Finset ℤ) (v : ℤ) : Prop :=
  ∃ a : ℤ, ∀ x ∈ A, v ∣ x - a

/-- The set spans its coset of `vℤ`: it lies in that coset, but no coset
of any proper nonzero subgroup `v*w*ℤ` with `w > 1`. -/
def HasFullIntegerPeriod (A : Finset ℤ) (v : ℤ) : Prop :=
  HasIntegerPeriod A v ∧ ∀ w : ℤ, 1 < w → ¬HasIntegerPeriod A (v * w)

/-- The centered gcd of an actual primitive affine image is its period. -/
theorem primitive_affine_gcd (A B : Finset ℤ) (a v : ℤ) (l : ℕ)
    (hv : 0 < v) (hB : LevNormalized B l)
    (he : A = B.image (fun x => a + v * x)) :
    A.gcd (fun x => x - a) = v := by
  rw [he, Finset.gcd_image]
  have hf : (fun x => (a + v * x) - a) = (fun x => v * id x) := by funext x; simp
  change B.gcd (fun x => (a + v * x) - a) = v
  rw [hf, Finset.gcd_mul_left, hB.2.2.2, Int.normalize_of_nonneg hv.le, mul_one]

/-- Every possible period divides the gcd period. -/
theorem integer_period_dvd_primitive (A B : Finset ℤ) (a v w : ℤ) (l : ℕ)
    (hv : 0 < v) (hB : LevNormalized B l)
    (he : A = B.image (fun x => a + v * x)) (hw : HasIntegerPeriod A w) : w ∣ v := by
  obtain ⟨t, ht⟩ := hw
  have ha : a ∈ A := by
    rw [he]
    exact Finset.mem_image.mpr ⟨0, hB.2.1, by simp⟩
  rw [← primitive_affine_gcd A B a v l hv hB he]
  apply Finset.dvd_gcd
  intro x hx
  have hh := dvd_sub (ht x hx) (ht a ha)
  simpa using hh

/-- Normalize using the specified full period, deriving that it equals
the primitive period rather than assuming this equality. -/
theorem integer_full_period_normalization (A : Finset ℤ) (u W v : ℤ)
    (hcard : 2 ≤ A.card) (hbox : A ⊆ Finset.Icc u (u + W))
    (hv : 0 < v) (hperiod : HasFullIntegerPeriod A v) :
    ∃ (a : ℤ) (l : ℕ) (B : Finset ℤ),
      LevNormalized B l ∧ B.card = A.card ∧
      A = B.image (fun x => a + v * x) ∧ v * l ≤ W := by
  obtain ⟨a, g, l, B, hg, hB, hc, he, hW, hbound⟩ := integer_fiber_period_bound A u W hcard hbox
  have hvg := integer_period_dvd_primitive A B a g v l hg hB he hperiod.1
  obtain ⟨w, hw⟩ := hvg
  have hwpos : 0 < w := by nlinarith
  have hw1 : w = 1 := by
    by_contra hn
    have hh : 1 < w := by omega
    apply hperiod.2 w hh
    refine ⟨a, ?_⟩
    intro x hx
    rw [he] at hx
    obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
    exact ⟨y, by rw [hw]; ring⟩
  have hgv : g = v := by rw [hw, hw1, mul_one]
  rw [hgv] at he hW
  exact ⟨a, l, B, hB, hc, he, hW⟩

end
end Optss
