import Optss.FreimanGridLift
import Optss.FreimanCoveringBounds

/-!
# From a large modeled progression to a containing progression

This composes the inverse Freiman lift, inclusion in the original double
difference, quantitative covering and real-scale properization. The model
is needed only on the large selected part, as in the paper's eight-part sieve.
-/

namespace Optss
noncomputable section
open scoped Pointwise Classical
variable {G H : Type*} [AddCommGroup G] [AddCommGroup H] [DecidableEq G] [DecidableEq H] [IsAddTorsionFree G]

theorem freiman_model_covering (S T : Finset G) (hS : S.Nonempty)
    (hTS : T⊆S) (hcard : S.card≤8*T.card)
    (f : G → H) (hf : FreimanEight T f)
    (C δ : ℚ≥0) (hδ : 0<δ) (hC : ((S+S).card : ℚ≥0)≤C*S.card)
    {r : ℕ} (ρ : IntVec r →+ H) (β : Fin r → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox β))
    (hP : integerProgressionValues ρ β⊆(T.image f+T.image f)-(T.image f+T.image f))
    (hlarge : δ*T.card≤((integerProgressionValues ρ β).card : ℚ≥0)) (t : ℝ) :
    let K : ℝ := (C^5/(δ/8) : ℚ≥0)
    ∃ d≤r+⌈K⌉₊, ∃ (ρ' : IntVec d →+ G) (γ : Fin d → ℕ),
      S⊆integerProgressionValues ρ' γ ∧
      Set.InjOn ρ' (realDilatedIntegerBox γ t) ∧
      ((integerBudgetBox γ).card : ℚ≥0)≤
        (properizationVolumeFactor (r+⌈K⌉₊) ⌈t⌉₊*(2^r*3^⌈K⌉₊) : ℕ)*C^4*S.card := by
  have hT : T.Nonempty := by
    have hs := Finset.card_pos.mpr hS
    apply Finset.card_pos.mp
    omega
  obtain ⟨ρ₀,_,hP₀,hproper₀,hcard₀⟩ := lift_model_progression T hT f hf ρ β hP hproper
  have hP' : integerProgressionValues ρ₀ β⊆(S+S)-(S+S) := by
    intro x hx
    obtain ⟨u,hu,v,hv,rfl⟩ := Finset.mem_sub.mp (hP₀ hx)
    have hsum : T+T⊆S+S := Finset.add_subset_add hTS hTS
    exact Finset.sub_mem_sub (hsum hu) (hsum hv)
  have hst : (S.card : ℚ≥0)≤8*T.card := by exact_mod_cast hcard
  have hlarge' : (δ/8)*S.card≤((integerProgressionValues ρ₀ β).card : ℚ≥0) := by
    rw [hcard₀]
    calc
      _ ≤ (δ/8)*(8*T.card) := mul_le_mul_of_nonneg_left hst (by positivity)
      _ = δ*T.card := by field_simp; ring
      _ ≤ _ := hlarge
  exact freiman_covering_from_large_progression S hS C (δ/8) (by positivity) hC
    ρ₀ β hproper₀ hP' hlarge' t

omit [IsAddTorsionFree G] [AddCommGroup G] [AddCommGroup H] in
theorem finite_model_card_le [Fintype H] (T : Finset G) (f : G → H)
    (hinj : Set.InjOn f T) : T.card≤Fintype.card H := by
  calc
    T.card = (T.image f).card := (Finset.card_image_iff.mpr hinj).symm
    _ ≤ Fintype.card H := Finset.card_le_univ _

omit [IsAddTorsionFree G] [AddCommGroup G] [AddCommGroup H] in
theorem finite_model_progression_density [Fintype H] (T : Finset G) (f : G → H)
    (hinj : Set.InjOn f T) (P : Finset H) (M : ℕ) (hM : 0<M)
    (hP : Fintype.card H≤M*P.card) :
    (1/(M : ℚ≥0))*T.card≤(P.card : ℚ≥0) := by
  have hm : (0 : ℚ≥0)<M := by exact_mod_cast hM
  have hc : (T.card : ℚ≥0)≤(M : ℚ≥0)*P.card := by
    exact_mod_cast (finite_model_card_le T f hinj).trans hP
  calc
    _ ≤ (1/(M : ℚ≥0))*((M : ℚ≥0)*P.card) := mul_le_mul_of_nonneg_left hc (by positivity)
    _ = _ := by field_simp

/-- The lattice construction naturally gives a bound in terms of the whole
finite model group. Injection of the selected part supplies the required
progression density, so no extra cardinality premise is assumed. -/
theorem freiman_finite_model_covering [Fintype H]
    (S T : Finset G) (hS : S.Nonempty) (hTS : T⊆S) (hcard : S.card≤8*T.card)
    (f : G → H) (hf : FreimanEight T f) (hinj : Set.InjOn f T)
    (C : ℚ≥0) (hC : ((S+S).card : ℚ≥0)≤C*S.card)
    {r : ℕ} (ρ : IntVec r →+ H) (β : Fin r → ℕ)
    (hproper : Set.InjOn ρ (integerBudgetBox β))
    (hP : integerProgressionValues ρ β⊆(T.image f+T.image f)-(T.image f+T.image f))
    (M : ℕ) (hM : 0<M) (hsize : Fintype.card H≤M*(integerProgressionValues ρ β).card)
    (t : ℝ) :
    let K : ℝ := (C^5/((1/(M : ℚ≥0))/8) : ℚ≥0)
    ∃ d≤r+⌈K⌉₊, ∃ (ρ' : IntVec d →+ G) (γ : Fin d → ℕ),
      S⊆integerProgressionValues ρ' γ ∧
      Set.InjOn ρ' (realDilatedIntegerBox γ t) ∧
      ((integerBudgetBox γ).card : ℚ≥0)≤
        (properizationVolumeFactor (r+⌈K⌉₊) ⌈t⌉₊*(2^r*3^⌈K⌉₊) : ℕ)*C^4*S.card := by
  exact freiman_model_covering S T hS hTS hcard f hf C (1/(M : ℚ≥0))
    (by positivity) hC ρ β hproper hP
    (finite_model_progression_density T f hinj _ M hM hsize) t

end
end Optss
