import Optss.BoundedCorrections
import Mathlib.Algebra.Group.Pointwise.Finset.Basic
import Mathlib.Data.List.OfFn
import Mathlib.Data.List.Forall2

/-!
# Iterated Boolean convolution with intermediate clipping

Each stage forms the exact finite Minkowski sum and filters it to the box.
Every result has one choice from every processed support. A prescribed witness
survives whenever each of its partial sums lies in the clipping box; the global
absolute-coordinate budget guarantees this even across different orthants.
No FFT or bit-complexity claim is made.
-/

namespace Optss
open scoped BigOperators Pointwise Classical
noncomputable section

section Generic
variable {G : Type*} [AddCommMonoid G] [DecidableEq G]

/-- One exact Boolean convolution followed by clipping. -/
def clippedMerge (B : Set G) (A C : Finset G) : Finset G :=
  (A + C).filter (fun x => x ∈ B)

/-- Process the finite support list in order, starting from an accumulator. -/
def clippedConvolutionFrom (B : Set G) : Finset G → List (Finset G) → Finset G
  | A, [] => A
  | A, C :: cs => clippedConvolutionFrom B (clippedMerge B A C) cs

/-- The initial support contains exactly the empty sum. -/
def clippedConvolution (B : Set G) (supports : List (Finset G)) : Finset G :=
  clippedConvolutionFrom B {0} supports

/-- Soundness records the actual selected value from each input support. -/
theorem clippedConvolutionFrom_witness (B : Set G) (A : Finset G)
    (supports : List (Finset G)) {t : G}
    (ht : t ∈ clippedConvolutionFrom B A supports) :
    ∃ a ∈ A, ∃ choices : List G,
      List.Forall₂ (fun x S => x ∈ S) choices supports ∧ a + choices.sum = t := by
  induction supports generalizing A with
  | nil => exact ⟨t, ht, [], .nil, by simp⟩
  | cons C cs ih =>
    obtain ⟨b, hb, choices, hchoices, hsum⟩ := ih (clippedMerge B A C) ht
    obtain ⟨hb, _⟩ := Finset.mem_filter.mp hb
    obtain ⟨a, ha, c, hc, rfl⟩ := Finset.mem_add.mp hb
    exact ⟨a, ha, c :: choices, .cons hc hchoices, by simpa [add_assoc] using hsum⟩

theorem clippedConvolution_witness (B : Set G) (supports : List (Finset G))
    {t : G} (ht : t ∈ clippedConvolution B supports) :
    ∃ choices : List G, List.Forall₂ (fun x S => x ∈ S) choices supports ∧
      choices.sum = t := by
  obtain ⟨a, ha, choices, hc, he⟩ := clippedConvolutionFrom_witness B {0} supports ht
  have ha0 : a = 0 := Finset.mem_singleton.mp ha
  exact ⟨choices, hc, by simpa [ha0] using he⟩

/-- Clipping can only remove elements from the unrestricted sumset. -/
theorem clippedConvolutionFrom_subset_sum (B : Set G) (A : Finset G)
    (supports : List (Finset G)) :
    clippedConvolutionFrom B A supports ⊆ A + supports.sum := by
  induction supports generalizing A with
  | nil => simp [clippedConvolutionFrom]
  | cons C cs ih =>
    calc
      clippedConvolutionFrom B A (C :: cs) ⊆ clippedMerge B A C + cs.sum := ih _
      _ ⊆ (A + C) + cs.sum :=
        Finset.add_subset_add (Finset.filter_subset _ _) (Finset.Subset.refl _)
      _ = A + (C :: cs).sum := by simp [add_assoc]

theorem clippedConvolution_subset_sum (B : Set G) (supports : List (Finset G)) :
    clippedConvolution B supports ⊆ supports.sum := by
  simpa only [clippedConvolution, Finset.singleton_zero, zero_add] using
    clippedConvolutionFrom_subset_sum B {0} supports

/-- If the accumulator is in the box, every later output is in the box. -/
theorem clippedConvolutionFrom_mem_box (B : Set G) (A : Finset G)
    (hA : ∀ a ∈ A, a ∈ B) (supports : List (Finset G)) :
    ∀ t ∈ clippedConvolutionFrom B A supports, t ∈ B := by
  induction supports generalizing A with
  | nil => exact hA
  | cons C cs ih =>
    exact ih _ (fun _ h => (Finset.mem_filter.mp h).2)

/-- Every prescribed sequence whose partial sums remain in the box survives all
intermediate filters. This proves retention, including possible cancellation. -/
theorem clippedConvolutionFrom_complete (B : Set G) {A : Finset G} {a : G}
    (ha : a ∈ A) {choices : List G} {supports : List (Finset G)}
    (hc : List.Forall₂ (fun x S => x ∈ S) choices supports)
    (hbox : ∀ n, n ≤ choices.length → a + (choices.take n).sum ∈ B) :
    a + choices.sum ∈ clippedConvolutionFrom B A supports := by
  induction hc generalizing A a with
  | nil => simpa [clippedConvolutionFrom] using ha
  | @cons x C choices supports hx hc ih =>
    have hax : a + x ∈ clippedMerge B A C := by
      apply Finset.mem_filter.mpr
      refine ⟨Finset.mem_add.mpr ⟨a, ha, x, hx, rfl⟩, ?_⟩
      simpa using hbox 1 (by simp)
    have hh : a + x + choices.sum ∈
        clippedConvolutionFrom B (clippedMerge B A C) supports := by
      apply ih hax
      intro n hn
      simpa [List.take_succ_cons, add_assoc] using hbox (n + 1) (by simpa using hn)
    simpa [clippedConvolutionFrom, add_assoc] using hh

theorem clippedConvolution_complete (B : Set G) {choices : List G}
    {supports : List (Finset G)}
    (hc : List.Forall₂ (fun x S => x ∈ S) choices supports)
    (hbox : ∀ n, n ≤ choices.length → (choices.take n).sum ∈ B) :
    choices.sum ∈ clippedConvolution B supports := by
  simpa only [zero_add] using clippedConvolutionFrom_complete B
    (Finset.mem_singleton_self (0 : G)) hc (by simpa only [zero_add] using hbox)

/-- This is exactly a left fold: there is one merge/filter call per list element. -/
theorem clippedConvolutionFrom_eq_foldl (B : Set G) (A : Finset G)
    (supports : List (Finset G)) :
    clippedConvolutionFrom B A supports = supports.foldl (clippedMerge B) A := by
  induction supports generalizing A with
  | nil => rfl
  | cons C cs ih => exact ih _

end Generic

section Partition
variable {ι κ : Type*} [Fintype ι] [Fintype κ] {d : ℕ}

omit [Fintype ι] [Fintype κ] in
/-- Any ordering of distinct partition parts preserves every required global
witness under intermediate clipping, regardless of its coordinate signs. -/
theorem clippedPartitionConvolution_retains (v : ι → IntVec d) (part : ι → κ)
    (Δ : IntVec d) (s : Finset ι) (hbudget : AbsoluteBudget v s Δ)
    (supports : κ → Finset (IntVec d)) (order : List κ) (hnodup : order.Nodup)
    (hmem : ∀ p ∈ order, (∑ i ∈ s.filter (fun i => part i = p), v i) ∈ supports p) :
    (order.map (fun p => ∑ i ∈ s.filter (fun i => part i = p), v i)).sum ∈
      clippedConvolution {t | InBox Δ t} (order.map supports) := by
  apply clippedConvolution_complete
  · rw [List.forall₂_map_left_iff, List.forall₂_map_right_iff, List.forall₂_same]
    exact hmem
  · intro n _
    have h := witness_partition_partial_inBox v part hbudget (order.take n).toFinset
    rwa [List.sum_toFinset _ (hnodup.sublist (List.take_sublist n order)), List.map_take] at h

end Partition

section Orthants
variable {ι : Type*} [Fintype ι] {d : ℕ}

/-- The finite Newton support of one orthant after restoring its coordinate signs. -/
def decodedOrthantSupport (v : ι → IntVec d) (Δ : Fin d →₀ ℕ)
    (kcap : ℕ) (ε : Fin d → Bool) : Finset (IntVec d) :=
  (newtonTruncatedSupport
    (fun i : {i // coordinateOrthant (v i) = ε} => absoluteExponent (v i)) Δ kcap).support.image
      (orthantDecode ε)

/-- The local input arrays have exact labelled-subset semantics. -/
theorem mem_decodedOrthantSupport (v : ι → IntVec d) (Δ : Fin d →₀ ℕ)
    (kcap : ℕ) (ε : Fin d → Bool) (t : IntVec d) :
    t ∈ decodedOrthantSupport v Δ kcap ε ↔
      ∃ s : Finset ι,
        LocalPartitionSelection v (fun i => coordinateOrthant (v i))
          (fun j => (Δ j : ℤ)) kcap ε s ∧ (∑ i ∈ s, v i) = t := by
  rw [← local_orthant_polynomial_iff v Δ kcap ε t]
  simp only [decodedOrthantSupport, Finset.mem_image, MvPolynomial.mem_support_iff]
  have hnonneg := newtonTruncatedSupport_coeff_nonneg
    (fun i : {i // coordinateOrthant (v i) = ε} => absoluteExponent (v i)) Δ
  constructor
  · rintro ⟨e, he, hdecode⟩
    exact ⟨e, by have := hnonneg e kcap; omega, hdecode⟩
  · rintro ⟨e, he, hdecode⟩
    exact ⟨e, ne_of_gt he, hdecode⟩

/-- A fixed exhaustive ordering visits each of the `2^d` orthants once. -/
def orthantOrder (d : ℕ) : List (Fin d → Bool) :=
  List.ofFn (Fintype.equivFin (Fin d → Bool)).symm

theorem orthantOrder_nodup (d : ℕ) : (orthantOrder d).Nodup := by
  exact List.nodup_ofFn.mpr (Equiv.injective _)

theorem orthantOrder_length (d : ℕ) : (orthantOrder d).length = 2 ^ d := by
  simp [orthantOrder, Fintype.card_fun]

/-- The operational signed support construction: one clipped merge per orthant. -/
def iteratedBoundedCorrectionSupport (v : ι → IntVec d) (Δ : Fin d →₀ ℕ)
    (kcap : ℕ) : Finset (IntVec d) :=
  clippedConvolution {t | InBox (fun j => (Δ j : ℤ)) t}
    ((orthantOrder d).map (decodedOrthantSupport v Δ kcap))

/-- Every intermediate-clipping output belongs to the already verified global
Newton support. Intermediate clipping is allowed to discard other outputs. -/
theorem iteratedBoundedCorrectionSupport_subset (v : ι → IntVec d)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) {t : IntVec d}
    (ht : t ∈ iteratedBoundedCorrectionSupport v Δ kcap) :
    t ∈ boundedCorrectionSupport v Δ kcap := by
  have hbox : InBox (fun j => (Δ j : ℤ)) t := by
    apply clippedConvolutionFrom_mem_box _ {0} ?_ _ t ht
    intro z hz
    have hz0 : z = 0 := Finset.mem_singleton.mp hz
    subst z
    intro j
    simp
  have hsum := clippedConvolution_subset_sum
    {t | InBox (fun j => (Δ j : ℤ)) t}
    ((orthantOrder d).map (decodedOrthantSupport v Δ kcap)) ht
  simp only [orthantOrder, List.map_ofFn] at hsum
  obtain ⟨g, hg⟩ := Finset.mem_sum_list_ofFn.mp hsum
  let e := Fintype.equivFin (Fin d → Bool)
  have hlocal (ε : Fin d → Bool) :
      (g (e ε) : IntVec d) ∈ decodedOrthantSupport v Δ kcap ε := by
    simpa [e] using (g (e ε)).property
  have hex (ε : Fin d → Bool) :=
    (mem_decodedOrthantSupport v Δ kcap ε (g (e ε))).mp (hlocal ε)
  choose s hs he using hex
  rw [boundedCorrectionSupport, orthantPolynomialSupport_eq_partitionSupport]
  refine ⟨⟨s, hs, ?_⟩, hbox⟩
  simp only [he]
  calc
    (∑ ε, (g (e ε) : IntVec d)) = ∑ i, (g i : IntVec d) := e.sum_comp (fun i => (g i : IntVec d))
    _ = (List.ofFn fun i => (g i : IntVec d)).sum := List.sum_ofFn.symm
    _ = t := hg

set_option maxHeartbeats 800000 in
/-- Every witness with the global cardinality cap and absolute-coordinate budget
survives the actual sequence of merges and intermediate box filters. -/
theorem iteratedBoundedCorrectionSupport_complete (v : ι → IntVec d)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) (s : Finset ι) (hcard : s.card ≤ kcap)
    (hbudget : AbsoluteBudget v s (fun j => (Δ j : ℤ))) :
    (∑ i ∈ s, v i) ∈ iteratedBoundedCorrectionSupport v Δ kcap := by
  classical
  have hmem (ε : Fin d → Bool) (_hε : ε ∈ orthantOrder d) :
      (∑ i ∈ s.filter (fun i => coordinateOrthant (v i) = ε), v i) ∈
        decodedOrthantSupport v Δ kcap ε := by
    apply (mem_decodedOrthantSupport v Δ kcap ε _).mpr
    refine ⟨s.filter (fun i => coordinateOrthant (v i) = ε), ?_, ?_⟩
    · convert witness_partition_local v (fun i => coordinateOrthant (v i)) hcard hbudget ε using 1
      ext i; simp
    · rfl
  have h := clippedPartitionConvolution_retains v (fun i => coordinateOrthant (v i))
    (fun j => (Δ j : ℤ)) s hbudget (decodedOrthantSupport v Δ kcap)
    (orthantOrder d) (orthantOrder_nodup d) (by
      intro p hp
      convert hmem p hp using 1
      apply Finset.sum_congr
      · ext i; simp
      · intro i hi; rfl)
  have heq : ((orthantOrder d).map
      (fun ε => ∑ i ∈ s.filter (fun i => coordinateOrthant (v i) = ε), v i)).sum =
        ∑ i ∈ s, v i := by
    rw [orthantOrder, List.map_ofFn, List.sum_ofFn]
    simp only [Function.comp_apply]
    rw [(Fintype.equivFin (Fin d → Bool)).symm.sum_comp
      (fun ε => ∑ i ∈ s.filter (fun i => coordinateOrthant (v i) = ε), v i)]
    exact Finset.sum_fiberwise s (fun i => coordinateOrthant (v i)) v
  convert h using 1
  refine heq.symm.trans ?_
  congr 1
  apply List.map_congr_left
  intro ε _
  apply Finset.sum_congr
  · ext i; simp
  · intro i hi; rfl

/-- Both correctness directions for the iterated, clipped Boolean support
computation in Lemma 10.1. The number of merge/filter stages is exactly `2^d`. -/
theorem iteratedBoundedCorrectionSupport_correct (v : ι → IntVec d)
    (Δ : Fin d →₀ ℕ) (kcap : ℕ) :
    (∀ t ∈ iteratedBoundedCorrectionSupport v Δ kcap,
      t ∈ subsetSums v ∧ InBox (fun j => (Δ j : ℤ)) t) ∧
    (∀ s : Finset ι, s.card ≤ kcap → AbsoluteBudget v s (fun j => (Δ j : ℤ)) →
      (∑ i ∈ s, v i) ∈ iteratedBoundedCorrectionSupport v Δ kcap) ∧
    ((orthantOrder d).map (decodedOrthantSupport v Δ kcap)).length = 2 ^ d := by
  refine ⟨?_, ?_, ?_⟩
  · intro t ht
    exact boundedCorrectionSupport_sound v Δ kcap
      (iteratedBoundedCorrectionSupport_subset v Δ kcap ht)
  · exact iteratedBoundedCorrectionSupport_complete v Δ kcap
  · simpa only [List.length_map] using orthantOrder_length d

end Orthants

end
end Optss
