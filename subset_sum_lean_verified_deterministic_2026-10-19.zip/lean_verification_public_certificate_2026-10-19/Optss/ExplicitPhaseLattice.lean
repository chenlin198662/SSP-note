import Optss.BohrPhaseLattice

/-!
# Explicit integer coordinates for the cyclic phase lattice

The distinguished frequency is one. The first basis direction therefore
records that coordinate, and every other direction is a modulus-sized axis.
Division by the modulus computes the unique inverse coordinates; no lattice
basis search or choice is needed to construct these columns.
-/
namespace Optss
open scoped BigOperators
variable {N r : ℕ} [NeZero N]

def phaseIntegerSynthesis (a : Fin r→ZMod N) (base : Fin r) : IntVec r→+IntVec r where
  toFun z i := if i=base then z base else z base*(a i).val+(N:ℤ)*z i
  map_zero' := by ext i; simp
  map_add' x y := by ext i; by_cases hi : i=base <;> simp [hi] <;> ring

def phaseIntegerCoordinates (a : Fin r→ZMod N) (base : Fin r) (v : IntVec r) : IntVec r :=
  fun i => if i=base then v base else (v i-v base*(a i).val)/(N:ℤ)

theorem phaseIntegerSynthesis_mem (a : Fin r→ZMod N) (base : Fin r) (ha : a base=1)
    (z : IntVec r) : phaseIntegerSynthesis a base z∈cyclicPhaseLattice a base := by
  intro i
  change ((if i=base then z base else z base*(a i).val+(N:ℤ)*z i : ℤ):ZMod N)=
    a i*((if base=base then z base else z base*(a base).val+(N:ℤ)*z base : ℤ):ZMod N)
  by_cases hi : i=base
  · simp [hi,ha]
  · simp only [hi,if_false,if_pos,Int.cast_add,Int.cast_mul,Int.cast_natCast,
      ZMod.natCast_zmod_val,ZMod.natCast_self,zero_mul,add_zero]
    ring

theorem phaseIntegerSynthesis_coordinates (a : Fin r→ZMod N) (base : Fin r)
    (v : IntVec r) (hv : v∈cyclicPhaseLattice a base) :
    phaseIntegerSynthesis a base (phaseIntegerCoordinates a base v)=v := by
  ext i
  by_cases hi : i=base
  · simp [phaseIntegerSynthesis,phaseIntegerCoordinates,hi]
  · have hzero : ((v i-v base*(a i).val : ℤ):ZMod N)=0 := by
      simp only [Int.cast_sub,Int.cast_mul,Int.cast_natCast,ZMod.natCast_zmod_val,hv i]
      ring
    have hd : (N:ℤ)∣v i-v base*(a i).val := (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).mp hzero
    have he := Int.ediv_mul_cancel hd
    simp only [phaseIntegerSynthesis,AddMonoidHom.coe_mk,ZeroHom.coe_mk,
      phaseIntegerCoordinates,hi,if_false,if_pos]
    nlinarith

theorem phaseIntegerCoordinates_synthesis (a : Fin r→ZMod N) (base : Fin r) (z : IntVec r) :
    phaseIntegerCoordinates a base (phaseIntegerSynthesis a base z)=z := by
  have hN : (N:ℤ)≠0 := by exact_mod_cast (NeZero.ne N)
  ext i
  by_cases hi : i=base
  · simp [phaseIntegerSynthesis,phaseIntegerCoordinates,hi]
  · simp only [phaseIntegerSynthesis,AddMonoidHom.coe_mk,ZeroHom.coe_mk,
      phaseIntegerCoordinates,hi,if_false,if_pos,add_sub_cancel_left]
    exact Int.mul_ediv_cancel_left _ hN

theorem phaseIntegerSynthesis_injective (a : Fin r→ZMod N) (base : Fin r) :
    Function.Injective (phaseIntegerSynthesis a base) :=
  Function.HasLeftInverse.injective ⟨phaseIntegerCoordinates a base,phaseIntegerCoordinates_synthesis a base⟩

def phaseIntegerColumns (a : Fin r→ZMod N) (base : Fin r) (j : Fin r) : IntVec r :=
  phaseIntegerSynthesis a base (Pi.single j 1)

theorem phaseIntegerColumns_formula (a : Fin r→ZMod N) (base i j : Fin r) :
    phaseIntegerColumns a base j i=
      if j=base then (if i=base then 1 else ((a i).val:ℤ))
      else if i=j then (N:ℤ) else 0 := by
  by_cases hj : j=base <;> by_cases hi : i=base <;> by_cases hij : i=j <;>
    simp_all [phaseIntegerColumns,phaseIntegerSynthesis,Pi.single_apply]

theorem phaseIntegerSynthesis_eq_sum (a : Fin r→ZMod N) (base : Fin r) (z : IntVec r) :
    phaseIntegerSynthesis a base z=∑ j, z j • phaseIntegerColumns a base j := by
  have hz : z=∑ j, z j • (Pi.single j (1:ℤ) : IntVec r) := by
    ext i
    simp [Finset.sum_apply,Pi.smul_apply,Pi.single_apply]
  conv_lhs => rw [hz]
  simp only [map_sum,map_zsmul,phaseIntegerColumns]

theorem phaseIntegerColumns_span (a : Fin r→ZMod N) (base : Fin r) (ha : a base=1) :
    Submodule.span ℤ (Set.range (phaseIntegerColumns a base))=
      (cyclicPhaseLattice a base).toIntSubmodule := by
  apply le_antisymm
  · apply Submodule.span_le.mpr
    rintro _ ⟨j,rfl⟩
    exact phaseIntegerSynthesis_mem a base ha _
  · intro v hv
    rw [←phaseIntegerSynthesis_coordinates a base v hv,phaseIntegerSynthesis_eq_sum]
    apply Submodule.sum_mem
    intro j _
    exact Submodule.smul_mem _ _ (Submodule.subset_span ⟨j,rfl⟩)

end Optss
