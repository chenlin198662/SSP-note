import Optss.ProperizationExistence
import Mathlib.Combinatorics.Additive.RuzsaCovering
import Mathlib.Algebra.BigOperators.Fin

/-!
# Covering a finite set by an enlarged progression

Ruzsa covering supplies a small set of translations of P-P. Appending those
translations as unit-width generators produces an actual containing GAP, with
an explicit rank and coefficient-volume bound. This is the covering step of
the Freiman argument; the large progression P remains a separate input.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {G : Type*} [AddCommGroup G] [DecidableEq G] {r s : ℕ}

def appendProgressionHom (ρ : IntVec r →+ G) (f : Fin s → G) :
    IntVec (r+s) →+ G where
  toFun z := ρ (fun i => z (Fin.castAdd s i)) + ∑ j, z (Fin.natAdd r j) • f j
  map_zero' := by
    change ρ 0 + _ = 0
    simp
  map_add' x y := by
    have hρ := map_add ρ (fun i => x (Fin.castAdd s i)) (fun i => y (Fin.castAdd s i))
    change ρ (fun i => x (Fin.castAdd s i)+y (Fin.castAdd s i)) = _ at hρ
    simp only [Pi.add_apply]
    rw [hρ]
    simp only [add_zsmul,Finset.sum_add_distrib]
    abel

def appendProgressionWidths (β : Fin r → ℕ) (s : ℕ) : Fin (r+s) → ℕ :=
  Fin.addCases (fun i => 2*β i) (fun _ => 1)

theorem appendProgressionHom_apply (ρ : IntVec r →+ G) (f : Fin s → G)
    (u : IntVec r) (v : IntVec s) :
    appendProgressionHom ρ f (Fin.addCases u v) = ρ u+∑ j, v j • f j := by
  simp [appendProgressionHom,Fin.addCases_right]

theorem appendProgressionWidths_card (β : Fin r → ℕ) (s : ℕ) :
    (integerBudgetBox (appendProgressionWidths β s)).card =
      (integerBudgetBox (fun i => 2*β i)).card * 3^s := by
  rw [integerBudgetBox_card,Fin.prod_univ_add]
  simp only [appendProgressionWidths,Fin.addCases_left,Fin.addCases_right]
  rw [← integerBudgetBox_card]
  simp

theorem appendProgressionWidths_card_le (β : Fin r → ℕ) (s : ℕ) :
    (integerBudgetBox (appendProgressionWidths β s)).card ≤
      (2^r*3^s)*(integerBudgetBox β).card := by
  rw [appendProgressionWidths_card]
  have h : (integerBudgetBox (fun i => 2*β i)).card ≤ 2^r*(integerBudgetBox β).card := by
    simp only [integerBudgetBox_card]
    calc
      (∏ i : Fin r, (2*(2*β i)+1)) ≤ ∏ i : Fin r, 2*(2*β i+1) := by
        exact Finset.prod_le_prod' (fun i _ => by omega)
      _ = _ := by rw [Finset.prod_mul_distrib]; simp
  calc
    _ ≤ (2^r*(integerBudgetBox β).card)*3^s := Nat.mul_le_mul_right _ h
    _ = _ := by ring

theorem appendProgression_covers_difference (ρ : IntVec r →+ G) (β : Fin r → ℕ)
    (f : Fin s → G) :
    Finset.univ.image f + (integerProgressionValues ρ β-integerProgressionValues ρ β) ⊆
      integerProgressionValues (appendProgressionHom ρ f) (appendProgressionWidths β s) := by
  intro x hx
  obtain ⟨a,ha,b,hb,rfl⟩ := Finset.mem_add.mp hx
  obtain ⟨j,_,rfl⟩ := Finset.mem_image.mp ha
  obtain ⟨p,hp,q,hq,rfl⟩ := Finset.mem_sub.mp hb
  obtain ⟨u,hu,rfl⟩ := Finset.mem_image.mp hp
  obtain ⟨v,hv,rfl⟩ := Finset.mem_image.mp hq
  refine Finset.mem_image.mpr ⟨Fin.addCases (u-v) (Pi.single j 1),?_,?_⟩
  · rw [mem_integerBudgetBox]
    intro i
    refine Fin.addCases ?_ ?_ i
    · intro k
      simp only [Fin.addCases_left,appendProgressionWidths,Pi.sub_apply]
      have hu' := (mem_integerBudgetBox β u).mp hu k
      have hv' := (mem_integerBudgetBox β v).mp hv k
      dsimp only at hu' hv'
      have h := abs_sub (u k) (v k)
      push_cast
      omega
    · intro k
      simp only [Fin.addCases_right,appendProgressionWidths]
      by_cases hk : k=j <;> simp [Pi.single_apply,hk]
  · rw [appendProgressionHom_apply]
    simp only [map_sub]
    have he : (∑ k : Fin s, (Pi.single j (1:ℤ) : Fin s → ℤ) k • f k) = f j := by
      simp [Pi.single_apply]
    rw [he]
    abel

/-- Enumerate actual covering translations, preserving their exact number. -/
def finsetGenerators (F : Finset G) : Fin F.card → G :=
  fun j => (F.equivFin.symm j).val

omit [AddCommGroup G] in
theorem finsetGenerators_image (F : Finset G) :
    Finset.univ.image (finsetGenerators F) = F := by
  ext x
  simp only [Finset.mem_image,Finset.mem_univ,true_and]
  constructor
  · rintro ⟨j,rfl⟩
    exact (F.equivFin.symm j).property
  · intro hx
    exact ⟨F.equivFin ⟨x,hx⟩,by simp [finsetGenerators]⟩

/-- A progression whose translates have small growth yields an actual
containing progression. No properness of the initial progression is needed. -/
theorem progression_covering (A : Finset G) (ρ : IntVec r →+ G) (β : Fin r → ℕ)
    (K : ℝ) (hK : ((A+integerProgressionValues ρ β).card : ℝ) ≤
      K*(integerProgressionValues ρ β).card) :
    ∃ s ≤ ⌈K⌉₊, ∃ (ρ' : IntVec (r+s) →+ G) (γ : Fin (r+s) → ℕ),
      A ⊆ integerProgressionValues ρ' γ ∧
      (integerBudgetBox γ).card ≤ (2^r*3^s)*(integerBudgetBox β).card := by
  have hP : (integerProgressionValues ρ β).Nonempty :=
    (integerBudgetBox_nonempty β).image ρ
  obtain ⟨F,_,hF,hcover⟩ := Finset.ruzsa_covering_add hP hK
  refine ⟨F.card,?_,appendProgressionHom ρ (finsetGenerators F),
    appendProgressionWidths β F.card,?_,appendProgressionWidths_card_le β F.card⟩
  · exact_mod_cast hF.trans (Nat.le_ceil K)
  · apply hcover.trans
    simpa only [finsetGenerators_image] using
      appendProgression_covers_difference ρ β (finsetGenerators F)

/-- The covering progression may be made proper on any requested real
dilation. Both the rank and enlargement factor are explicit functions of the
initial rank, the covering bound and the requested properness scale. -/
theorem progression_covering_proper [IsAddTorsionFree G]
    (A : Finset G) (ρ : IntVec r →+ G) (β : Fin r → ℕ)
    (K t : ℝ) (hK : ((A+integerProgressionValues ρ β).card : ℝ) ≤
      K*(integerProgressionValues ρ β).card) :
    ∃ d ≤ r+⌈K⌉₊, ∃ (ρ' : IntVec d →+ G) (γ : Fin d → ℕ),
      A ⊆ integerProgressionValues ρ' γ ∧
      Set.InjOn ρ' (realDilatedIntegerBox γ t) ∧
      (integerBudgetBox γ).card ≤
        (properizationVolumeFactor (r+⌈K⌉₊) ⌈t⌉₊*(2^r*3^⌈K⌉₊)) *
          (integerBudgetBox β).card := by
  obtain ⟨s,hs,ρ₀,γ₀,hA,hcard⟩ := progression_covering A ρ β K hK
  obtain ⟨d,hd,ρ',γ,hcont,hproper,hcard'⟩ :=
    theorem2C_properization (r+⌈K⌉₊) t (Nat.add_le_add_left hs r) ρ₀ γ₀
  have hcont' : integerProgressionValues ρ₀ γ₀⊆integerProgressionValues ρ' γ := by
    simpa only [Finset.subset_iff,integerProgressionValues,Finset.mem_image] using hcont
  refine ⟨d,hd,ρ',γ,hA.trans hcont',hproper,?_⟩
  calc
    _ ≤ properizationVolumeFactor (r+⌈K⌉₊) ⌈t⌉₊ *
        ((2^r*3^s)*(integerBudgetBox β).card) :=
      hcard'.trans (Nat.mul_le_mul_left _ hcard)
    _ ≤ properizationVolumeFactor (r+⌈K⌉₊) ⌈t⌉₊ *
        ((2^r*3^⌈K⌉₊)*(integerBudgetBox β).card) := by gcongr; norm_num
    _ = _ := by ring

end
end Optss
