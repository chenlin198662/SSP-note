import Optss.BinaryLongDivision

/-!
# Euclidean normalization using binary long division

Two Euclidean remainders at a time halve the first argument. The executable
algorithm therefore uses its binary length as fuel, and every division is the
checked binary long-division implementation. Work counts are operand-width
charges, not yet a machine-instruction refinement.
-/

namespace Optss

theorem remainder_lt_half (a r : ℕ) (hr : 0 < r) (hra : r < a) :
    2*(a%r) < a := by
  by_cases h : 2*r ≤ a
  · have hm := Nat.mod_lt a hr
    omega
  · rw [Nat.mod_eq_sub_mod hra.le, Nat.mod_eq_of_lt (by omega : a-r < r)]
    omega

theorem remainder_bits_lt (a r : ℕ) (hr : 0 < r) (hra : r < a) :
    (a%r).size < a.size := by
  have hm := remainder_lt_half a r hr hra
  have hs := Nat.size_le_size (show Nat.bit true (a%r) ≤ a by
    simp only [Nat.bit_val, Bool.toNat_true]; omega)
  rw [Nat.size_bit (by simp [Nat.bit_val] : Nat.bit true (a%r) ≠ 0)] at hs
  omega

structure BinaryGcdResult where
  value : ℕ
  divisions : ℕ
  divisionRounds : ℕ
  widthWork : ℕ
  deriving Repr, DecidableEq

/-- Fuel counts pairs of divisions. There is no exhaustive search over the
magnitude of either argument. -/
def binaryGcdFuel : ℕ → ℕ → ℕ → BinaryGcdResult
  | 0, _, b => ⟨b,0,0,0⟩
  | k+1, a, b =>
    if a = 0 then ⟨b,0,0,0⟩ else
      let first := binaryLongDivision b a
      if first.remainder = 0 then ⟨a,1,first.rounds,first.widthWork⟩ else
        let second := binaryLongDivision a first.remainder
        let out := binaryGcdFuel k second.remainder first.remainder
        ⟨out.value, out.divisions+2, out.divisionRounds+first.rounds+second.rounds,
          out.widthWork+first.widthWork+second.widthWork⟩

def binaryGcd (a b : ℕ) : BinaryGcdResult := binaryGcdFuel a.size a b

theorem binaryGcdFuel_correct (fuel a b : ℕ) (hf : a.size ≤ fuel) :
    (binaryGcdFuel fuel a b).value = a.gcd b := by
  induction fuel generalizing a b with
  | zero =>
    have ha : a = 0 := Nat.size_eq_zero.mp (by omega)
    simp [binaryGcdFuel, ha]
  | succ k ih =>
    rw [binaryGcdFuel]
    dsimp only
    split_ifs with ha hr
    · simp [ha]
    · have he := (binaryLongDivision_correct b a (by omega)).2
      change (binaryLongDivision b a).remainder = 0 at hr
      rw [he] at hr
      simpa [hr] using (Nat.gcd_rec a b).symm
    · let r := (binaryLongDivision b a).remainder
      have hrpos : 0 < r := by dsimp [r]; omega
      have hre : r = b%a := (binaryLongDivision_correct b a (by omega)).2
      have hral : r < a := hre ▸ Nat.mod_lt b (by omega)
      have hse := (binaryLongDivision_correct a r hrpos).2
      have hsize : (a%r).size ≤ k := by
        have := remainder_bits_lt a r hrpos hral
        omega
      change (binaryGcdFuel k (binaryLongDivision a r).remainder r).value = a.gcd b
      rw [hse, ih _ _ hsize]
      rw [Nat.gcd_rec a b, ← hre, Nat.gcd_rec r a]

theorem binaryGcd_correct (a b : ℕ) : (binaryGcd a b).value = a.gcd b :=
  binaryGcdFuel_correct _ _ _ le_rfl

/-- Every visited operand fits in the original common bit bound. -/
theorem binaryGcdFuel_work (fuel a b L : ℕ) (ha : a.size ≤ L) (hb : b.size ≤ L) :
    (binaryGcdFuel fuel a b).divisions ≤ 2*fuel ∧
    (binaryGcdFuel fuel a b).divisionRounds ≤ 2*fuel*L ∧
    (binaryGcdFuel fuel a b).widthWork ≤ 16*fuel*L*(2*L+2) := by
  induction fuel generalizing a b with
  | zero => simp [binaryGcdFuel]
  | succ k ih =>
    rw [binaryGcdFuel]
    dsimp only
    split_ifs with haz hrz
    · simp
    · have hba := binaryLongDivision_widthWork b a (by omega)
      have hbr := binaryLongDivision_rounds b a
      dsimp only
      refine ⟨by omega, ?_, ?_⟩
      · rw [hbr]; nlinarith
      · have hh : 8*b.size*(b.size+a.size+2) ≤ 8*L*(2*L+2) := by
          exact Nat.mul_le_mul (Nat.mul_le_mul_left 8 hb) (by omega)
        exact (hba.trans hh).trans (by nlinarith)
    · let r := (binaryLongDivision b a).remainder
      have hrpos : 0 < r := by dsimp [r]; omega
      have hre : r = b%a := (binaryLongDivision_correct b a (by omega)).2
      have hrle : r.size ≤ L := (Nat.size_le_size (hre ▸ (Nat.mod_lt b (by omega)).le)).trans ha
      let s := (binaryLongDivision a r).remainder
      have hse : s = a%r := (binaryLongDivision_correct a r hrpos).2
      have hsle : s.size ≤ L := (Nat.size_le_size (hse ▸ (Nat.mod_lt a hrpos).le)).trans hrle
      obtain ⟨hdiv, hround, hwork⟩ := ih s r hsle hrle
      have hfwork : (binaryLongDivision b a).widthWork ≤ 8*L*(2*L+2) :=
        (binaryLongDivision_widthWork b a (by omega)).trans
          (Nat.mul_le_mul (Nat.mul_le_mul_left 8 hb) (by omega))
      have hswork : (binaryLongDivision a r).widthWork ≤ 8*L*(2*L+2) :=
        (binaryLongDivision_widthWork a r hrpos).trans
          (Nat.mul_le_mul (Nat.mul_le_mul_left 8 ha) (by omega))
      have hfround := binaryLongDivision_rounds b a
      have hsround := binaryLongDivision_rounds a r
      change (binaryGcdFuel k s r).divisions+2 ≤ _ ∧
        (binaryGcdFuel k s r).divisionRounds+(binaryLongDivision b a).rounds+
          (binaryLongDivision a r).rounds ≤ _ ∧
        (binaryGcdFuel k s r).widthWork+(binaryLongDivision b a).widthWork+
          (binaryLongDivision a r).widthWork ≤ _
      refine ⟨by omega, ?_, ?_⟩
      · rw [hfround, hsround]; nlinarith
      · nlinarith

theorem binaryGcd_widthWork (a b : ℕ) :
    (binaryGcd a b).widthWork ≤
      16*(max a.size b.size)^2*(2*max a.size b.size+2) := by
  let L := max a.size b.size
  have h := (binaryGcdFuel_work a.size a b L (le_max_left _ _) (le_max_right _ _)).2.2
  exact h.trans (by dsimp [L]; nlinarith [le_max_left a.size b.size])

theorem binaryGcd_divisions (a b : ℕ) : (binaryGcd a b).divisions ≤ 2*a.size :=
  (binaryGcdFuel_work a.size a b (max a.size b.size) (le_max_left _ _) (le_max_right _ _)).1

end Optss
