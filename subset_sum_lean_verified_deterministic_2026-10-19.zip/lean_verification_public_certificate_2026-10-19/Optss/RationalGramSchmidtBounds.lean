import Optss.RationalGramSchmidt
import Optss.PartialReductionHeight
import Mathlib.LinearAlgebra.Matrix.Adjugate

/-!
# Integral Cramer certificates for rational Gram-Schmidt

A prefix Gram matrix and its integer Cramer vector construct an actual integer
residual. Orthogonality identifies this residual with the prefix determinant
times the Gram-Schmidt vector. This supplies denominators of the executable
rational recurrence rather than postulating bounds on auxiliary real values.
-/

namespace Optss
noncomputable section
open scoped BigOperators Classical
variable {r d m : ℕ}

section OrthogonalUniqueness
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- The vector removed in the Gram-Schmidt step lies in the preceding row span. -/
theorem gramSchmidt_sub_mem_preceding_span (v : Fin r → E) (k : Fin r) :
    v k - gramSchmidt ℝ v k ∈ Submodule.span ℝ (v '' Set.Iio k) := by
  rw [gramSchmidt_def, sub_sub_cancel]
  apply Submodule.sum_mem
  intro i hi
  rw [Submodule.orthogonalProjection_singleton]
  apply Submodule.smul_mem
  rw [← span_gramSchmidt_Iio ℝ v k]
  exact Submodule.subset_span ⟨i, Finset.mem_Iio.mp hi, rfl⟩

/-- Orthogonality and a preceding-span correction identify even a scaled
Gram-Schmidt vector. No independent-family hypothesis is required. -/
theorem eq_smul_gramSchmidt_of_orthogonal (v : Fin r → E) (k : Fin r)
    (D : ℝ) (w : E)
    (hsub : D • v k - w ∈ Submodule.span ℝ (v '' Set.Iio k))
    (horth : ∀ i < k, @inner ℝ E _ w (v i) = 0) :
    w = D • gramSchmidt ℝ v k := by
  let V := Submodule.span ℝ (v '' Set.Iio k)
  have hdiff : w - D • gramSchmidt ℝ v k ∈ V := by
    have h := V.sub_mem (V.smul_mem D (gramSchmidt_sub_mem_preceding_span v k)) hsub
    convert h using 1; module
  have ho : ∀ y ∈ V, @inner ℝ E _ (w - D • gramSchmidt ℝ v k) y = 0 := by
    intro y hy
    induction hy using Submodule.span_induction with
    | mem y hy =>
      obtain ⟨i, hi, rfl⟩ := hy
      rw [inner_sub_left, real_inner_smul_left, horth i hi,
        gramSchmidt_inv_triangular ℝ v hi, mul_zero, sub_zero]
    | zero => simp
    | add x y _ _ hx hy => simp [inner_add_right, hx, hy]
    | smul a x _ hx => simp [inner_smul_right, hx]
  exact sub_eq_zero.mp (inner_self_eq_zero.mp (ho _ hdiff))

end OrthogonalUniqueness

/-- Integer vectors embedded in Euclidean space, as an actual integer-linear map. -/
def gsIntegerEmbedding : IntVec d →ₗ[ℤ] EuclideanSpace ℝ (Fin d) :=
  (((EuclideanSpace.equiv (Fin d) ℝ).symm.toLinearMap).restrictScalars ℤ).comp
    realVector.toIntLinearMap

@[simp] theorem gsIntegerEmbedding_apply (z : IntVec d) (j : Fin d) :
    gsIntegerEmbedding z j = (z j : ℝ) := rfl

theorem gsIntegerEmbedding_inner (x y : IntVec d) :
    @inner ℝ _ _ (gsIntegerEmbedding x) (gsIntegerEmbedding y) =
      ((∑ j, x j*y j : ℤ) : ℝ) := by
  simp [PiLp.inner_apply, gsIntegerEmbedding_apply, mul_comm]

/-- Exact integer cross dot products with a target vector. -/
def integerGramCross (V : Matrix (Fin m) (Fin d) ℤ) (x : IntVec d) : Fin m → ℤ :=
  fun i => ∑ j, V i j * x j

/-- An integer residual from Cramer's rule. -/
def integerCramerResidual (V : Matrix (Fin m) (Fin d) ℤ) (x : IntVec d) : IntVec d :=
  (integerGram V).det • x -
    ∑ i, (integerGram V).cramer (integerGramCross V x) i • V i

/-- The actual integral Cramer residual is orthogonal to every row of the
prefix matrix, directly from `G * cramer(G,q) = det(G) * q`. -/
theorem integerCramerResidual_orthogonal (V : Matrix (Fin m) (Fin d) ℤ)
    (x : IntVec d) (i : Fin m) :
    @inner ℝ _ _ (gsIntegerEmbedding (integerCramerResidual V x))
      (gsIntegerEmbedding (V i)) = 0 := by
  let G := integerGram V
  let q := integerGramCross V x
  let c := G.cramer q
  have hc : ∑ j, G i j * c j = G.det * q i := by
    exact congrFun (Matrix.mulVec_cramer G q) i
  have hreal : (∑ j, (G i j : ℝ) * (c j : ℝ)) = (G.det : ℝ) * (q i : ℝ) := by
    exact_mod_cast hc
  have hx : @inner ℝ _ _ (gsIntegerEmbedding x) (gsIntegerEmbedding (V i)) = (q i : ℝ) := by
    rw [gsIntegerEmbedding_inner]
    simp only [q, integerGramCross, mul_comm]
  have hV (j : Fin m) :
      @inner ℝ _ _ (gsIntegerEmbedding (V j)) (gsIntegerEmbedding (V i)) = (G i j : ℝ) := by
    rw [gsIntegerEmbedding_inner]
    simp only [G, integerGram_apply, mul_comm]
  change @inner ℝ _ _ (gsIntegerEmbedding (G.det • x - ∑ j, c j • V j))
    (gsIntegerEmbedding (V i)) = 0
  rw [map_sub, map_sum, map_smul]
  simp_rw [map_smul]
  simp_rw [← Int.cast_smul_eq_zsmul ℝ]
  rw [inner_sub_left, real_inner_smul_left, sum_inner]
  simp_rw [real_inner_smul_left, hV]
  rw [hx]
  have he : ∑ j, (c j : ℝ) * (G i j : ℝ) = (G.det : ℝ) * (q i : ℝ) := by
    simpa only [mul_comm] using hreal
  rw [he, sub_self]

/-- The integral residual for row `k` computed from exactly its preceding rows. -/
def integerGramSchmidtResidual (A : Matrix (Fin r) (Fin d) ℤ) (k : Fin r) : IntVec d :=
  integerCramerResidual (prefixRows A ⟨k.val, by omega⟩) (A k)

/-- Cramer's residual equals the prefix determinant times the genuine
Gram-Schmidt vector, even when a prefix is dependent. -/
theorem integerGramSchmidtResidual_eq (A : Matrix (Fin r) (Fin d) ℤ) (k : Fin r) :
    gsIntegerEmbedding (integerGramSchmidtResidual A k) =
      (prefixGramDet A ⟨k.val, by omega⟩ : ℝ) •
        gramSchmidt ℝ (euclideanIntegerRows A) k := by
  let V := prefixRows A ⟨k.val, by omega⟩
  let D := (integerGram V).det
  let c := (integerGram V).cramer (integerGramCross V (A k))
  have hrow (i : Fin r) : gsIntegerEmbedding (A i) = euclideanIntegerRows A i := rfl
  apply eq_smul_gramSchmidt_of_orthogonal
  · change (D:ℝ) • euclideanIntegerRows A k -
      gsIntegerEmbedding (D • A k - ∑ i, c i • V i) ∈ _
    rw [map_sub, map_smul, map_sum, ← Int.cast_smul_eq_zsmul ℝ, hrow, sub_sub_cancel]
    apply Submodule.sum_mem
    intro i _
    rw [map_smul, ← Int.cast_smul_eq_zsmul ℝ]
    apply Submodule.smul_mem
    exact Submodule.subset_span ⟨i.castLE (Nat.le_of_lt k.isLt), i.isLt, rfl⟩
  · intro i hi
    let j : Fin k.val := ⟨i.val, hi⟩
    have he : V j = A i := by congr 1
    have ho := integerCramerResidual_orthogonal V (A k) j
    rw [he, hrow] at ho
    exact ho

/-- Every computed rational Gram-Schmidt coordinate has an explicit integral
multiple, with the preceding prefix Gram determinant as multiplier. -/
theorem rationalGramSchmidt_integral_multiple (A : Matrix (Fin r) (Fin d) ℤ)
    (k : Fin r) (j : Fin d) :
    (prefixGramDet A ⟨k.val, by omega⟩ : ℚ) *
      rationalGramSchmidt (rationalIntegerRows A) k j =
        (integerGramSchmidtResidual A k j : ℚ) := by
  have h := congrArg (fun x : EuclideanSpace ℝ (Fin d) => x j)
    (integerGramSchmidtResidual_eq A k)
  have hg := congrArg (fun x : EuclideanSpace ℝ (Fin d) => x j)
    (rationalGramSchmidt_cast (rationalIntegerRows A) k)
  rw [rationalEuclideanRows_integer] at hg
  change ((rationalGramSchmidt (rationalIntegerRows A) k j : ℚ) : ℝ) = gramSchmidt ℝ (euclideanIntegerRows A) k j at hg
  simp only [gsIntegerEmbedding_apply, PiLp.smul_apply, smul_eq_mul] at h
  rw [← hg] at h
  exact_mod_cast h.symm

/-- A certified nonzero integer multiple bounds the reduced rational denominator. -/
theorem rational_den_dvd_of_integral_multiple (q : ℚ) (D n : ℤ)
    (hD : D ≠ 0) (hq : (D:ℚ) * q = n) : (q.den : ℤ) ∣ D := by
  have hq' : q = Rat.divInt n D := by
    rw [Rat.divInt_eq_div]
    apply (eq_div_iff (by exact_mod_cast hD : (D:ℚ) ≠ 0)).mpr
    simpa only [mul_comm] using hq
  rw [hq']
  exact Rat.den_dvd n D

/-- The reduced coordinate denominator divides the actual prefix determinant. -/
theorem rationalGramSchmidt_den_dvd (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k : Fin r) (j : Fin d) :
    ((rationalGramSchmidt (rationalIntegerRows A) k j).den : ℤ) ∣
      prefixGramDet A ⟨k.val, by omega⟩ := by
  exact rational_den_dvd_of_integral_multiple _ _ _
    (ne_of_gt (prefixGramDet_pos A hA _)) (rationalGramSchmidt_integral_multiple A k j)

/-- All reduced coordinate denominators are bounded by the integer Gram potential. -/
theorem rationalGramSchmidt_den_le_potential (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k : Fin r) (j : Fin d) :
    (rationalGramSchmidt (rationalIntegerRows A) k j).den ≤ gramPotential A := by
  have hd := rationalGramSchmidt_den_dvd A hA k j
  have hp := prefixGramDet_pos A hA ⟨k.val, by omega⟩
  have hle := Int.le_of_dvd hp hd
  have hle' : (rationalGramSchmidt (rationalIntegerRows A) k j).den ≤
      (prefixGramDet A ⟨k.val, by omega⟩).natAbs := by
    exact_mod_cast hle.trans Int.le_natAbs
  exact hle'.trans (prefixGramDet_le_potential A hA _)

/-- The numerator certificate for a projection coefficient uses the integer
Cramer residual of its orthogonalized row. -/
theorem rationalGsCoefficient_integral_multiple (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k j : Fin r) :
    (prefixGramDet A ⟨j.val+1, by omega⟩ : ℚ) *
      rationalGsCoefficient (rationalIntegerRows A) k j =
        ((∑ l, integerGramSchmidtResidual A j l * A k l : ℤ) : ℚ) := by
  have hnum := gsIntegerEmbedding_inner (integerGramSchmidtResidual A j) (A k)
  rw [integerGramSchmidtResidual_eq, real_inner_smul_left] at hnum
  change (prefixGramDet A ⟨j.val, by omega⟩:ℝ) *
    @inner ℝ _ _ (gramSchmidt ℝ (euclideanIntegerRows A) j) (euclideanIntegerRows A k) = _ at hnum
  have hratio := prefixGramDet_succ_eq A j
  have hpos : (0:ℝ) < (prefixGramDet A ⟨j.val+1, by omega⟩ : ℝ) := by
    exact_mod_cast prefixGramDet_pos A hA ⟨j.val+1, by omega⟩
  have hn : ‖gramSchmidt ℝ (euclideanIntegerRows A) j‖^2 ≠ 0 := by
    intro hz
    rw [hz, mul_zero] at hratio
    exact (ne_of_gt hpos) hratio
  have he : (prefixGramDet A ⟨j.val+1, by omega⟩:ℝ) *
      gsCoefficient (euclideanIntegerRows A) k j =
        ((∑ l, integerGramSchmidtResidual A j l * A k l : ℤ) : ℝ) := by
    rw [gsCoefficient, hratio]
    convert hnum using 1
    field_simp; ring
  rw [← rationalEuclideanRows_integer A, ← rationalGsCoefficient_cast] at he
  exact_mod_cast he

/-- The reduced projection-coefficient denominator divides the *next* prefix
Gram determinant; no product of prefix determinants is necessary. -/
theorem rationalGsCoefficient_den_dvd (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k j : Fin r) :
    ((rationalGsCoefficient (rationalIntegerRows A) k j).den : ℤ) ∣
      prefixGramDet A ⟨j.val+1, by omega⟩ := by
  exact rational_den_dvd_of_integral_multiple _ _ _
    (ne_of_gt (prefixGramDet_pos A hA _)) (rationalGsCoefficient_integral_multiple A hA k j)

/-- All reduced projection-coefficient denominators are at most the integer
Gram potential, including coefficients used by actual rational rounding. -/
theorem rationalGsCoefficient_den_le_potential (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k j : Fin r) :
    (rationalGsCoefficient (rationalIntegerRows A) k j).den ≤ gramPotential A := by
  have hd := rationalGsCoefficient_den_dvd A hA k j
  have hp := prefixGramDet_pos A hA ⟨j.val+1, by omega⟩
  have hle := Int.le_of_dvd hp hd
  have hle' : (rationalGsCoefficient (rationalIntegerRows A) k j).den ≤
      (prefixGramDet A ⟨j.val+1, by omega⟩).natAbs := by
    exact_mod_cast hle.trans Int.le_natAbs
  exact hle'.trans (prefixGramDet_le_potential A hA _)

/-- Exact relation between the reduced numerator and the real absolute value. -/
theorem rational_num_natAbs_cast (q : ℚ) :
    (q.num.natAbs : ℝ) = |(q:ℝ)| * (q.den:ℝ) := by
  have h : (q:ℝ) * (q.den:ℝ) = (q.num:ℝ) := by
    exact_mod_cast Rat.mul_den_eq_num q
  rw [Int.cast_natAbs, Int.cast_abs, ← h, abs_mul, abs_of_nonneg (show (0:ℝ) ≤ (q.den:ℝ) by positivity)]

/-- The computed orthogonalized coordinates have magnitude at most `P`.
This is a coarse integer bound derived from their actual squared norms. -/
theorem rationalGramSchmidt_abs_le_potential (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k : Fin r) (j : Fin d) :
    |(rationalGramSchmidt (rationalIntegerRows A) k j : ℝ)| ≤ gramPotential A := by
  have hgs := congrArg (fun x : EuclideanSpace ℝ (Fin d) => x j)
    (rationalGramSchmidt_cast (rationalIntegerRows A) k)
  rw [rationalEuclideanRows_integer] at hgs
  change (rationalGramSchmidt (rationalIntegerRows A) k j : ℝ) =
    gramSchmidt ℝ (euclideanIntegerRows A) k j at hgs
  rw [hgs]
  have hc : |gramSchmidt ℝ (euclideanIntegerRows A) k j| ≤
      ‖gramSchmidt ℝ (euclideanIntegerRows A) k‖ := by
    simpa only [Real.norm_eq_abs] using
      PiLp.norm_apply_le (gramSchmidt ℝ (euclideanIntegerRows A) k) j
  have hs := gramSchmidt_sq_le_potential A hA k
  have hP : (1:ℝ) ≤ gramPotential A := by
    exact_mod_cast (gramPotential_pos A hA : 1 ≤ gramPotential A)
  have hn := norm_nonneg (gramSchmidt ℝ (euclideanIntegerRows A) k)
  nlinarith

/-- The reduced numerator of each actual rational Gram-Schmidt coordinate is
bounded by `P²`; its bit length is therefore at most twice the bit length of `P`. -/
theorem rationalGramSchmidt_num_le_potential_sq (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k : Fin r) (j : Fin d) :
    (rationalGramSchmidt (rationalIntegerRows A) k j).num.natAbs ≤ gramPotential A ^ 2 := by
  have hd : ((rationalGramSchmidt (rationalIntegerRows A) k j).den:ℝ) ≤ gramPotential A := by
    exact_mod_cast rationalGramSchmidt_den_le_potential A hA k j
  have hn := rationalGramSchmidt_abs_le_potential A hA k j
  have hm := mul_le_mul hn hd (Nat.cast_nonneg _) (Nat.cast_nonneg (gramPotential A):
    (0:ℝ) ≤ gramPotential A)
  rw [← rational_num_natAbs_cast] at hm
  rw [pow_two]
  exact_mod_cast hm

/-- Explicit reduced numerator and denominator bit bounds for the executable
rational Gram-Schmidt coordinates. -/
theorem rationalGramSchmidt_bits_le (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k : Fin r) (j : Fin d) :
    (rationalGramSchmidt (rationalIntegerRows A) k j).num.natAbs.size ≤
        2 * (gramPotential A).size ∧
      (rationalGramSchmidt (rationalIntegerRows A) k j).den.size ≤ (gramPotential A).size := by
  exact ⟨nat_size_le_of_le_pow (by omega) (rationalGramSchmidt_num_le_potential_sq A hA k j),
    Nat.size_le_size (rationalGramSchmidt_den_le_potential A hA k j)⟩

/-- Actual reduced projection numerators are bounded by the current row norm
and a fixed cubic power of the Gram potential. -/
theorem rationalGsCoefficient_num_le_norm_mul_potential_cube
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k j : Fin r) :
    ((rationalGsCoefficient (rationalIntegerRows A) k j).num.natAbs:ℝ) ≤
      ‖euclideanIntegerRows A k‖ * (gramPotential A:ℝ)^3 := by
  have hc := gsCoefficient_abs_le_norm_mul_potential_sq A hA k j
  rw [← rationalEuclideanRows_integer A, ← rationalGsCoefficient_cast] at hc
  rw [rationalEuclideanRows_integer] at hc
  have hd : ((rationalGsCoefficient (rationalIntegerRows A) k j).den:ℝ) ≤
      gramPotential A := by exact_mod_cast rationalGsCoefficient_den_le_potential A hA k j
  have hm := mul_le_mul hc hd (Nat.cast_nonneg _)
    (by positivity : (0:ℝ) ≤ ‖euclideanIntegerRows A k‖*(gramPotential A:ℝ)^2)
  rw [rational_num_natAbs_cast]
  convert hm using 1; ring

/-- An integer coordinate-height input gives a concrete natural numerator bound. -/
theorem rationalGsCoefficient_num_le_height (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k j : Fin r) :
    (rationalGsCoefficient (rationalIntegerRows A) k j).num.natAbs ≤
      (d*H^2+2)*gramPotential A^3 := by
  have hn := rationalGsCoefficient_num_le_norm_mul_potential_cube A hA k j
  have hr := integerRow_norm_add_one_le_height A H hH k
  have hr' : ‖euclideanIntegerRows A k‖ ≤ (d*H^2+2:ℕ) := by linarith
  have hh := hn.trans (mul_le_mul_of_nonneg_right hr' (by positivity :
    (0:ℝ) ≤ (gramPotential A:ℝ)^3))
  exact_mod_cast hh

/-- Reduced numerator and denominator bits of every coefficient computed on
an integer matrix of height `H`, including exact rounding inputs. -/
theorem rationalGsCoefficient_bits_le_height (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k j : Fin r) :
    (rationalGsCoefficient (rationalIntegerRows A) k j).num.natAbs.size ≤
        4 * (d*H^2+2+gramPotential A).size ∧
      (rationalGsCoefficient (rationalIntegerRows A) k j).den.size ≤ (gramPotential A).size := by
  constructor
  · apply nat_size_le_of_le_pow (by omega : 0 < 4)
    calc
      _ ≤ (d*H^2+2)*gramPotential A^3 := rationalGsCoefficient_num_le_height A hA H hH k j
      _ ≤ (d*H^2+2+gramPotential A)*(d*H^2+2+gramPotential A)^3 :=
        Nat.mul_le_mul (by omega) (Nat.pow_le_pow_left (by omega) _)
      _ = _ := by ring
  · exact Nat.size_le_size (rationalGsCoefficient_den_le_potential A hA k j)

/-- Independence and potential preservation at every actual inner-loop state
of a full rational sweep. -/
theorem outerSweep_innerTrace_independent_potential
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k : Fin r)
    (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace (rationalReduceIntegerAll A k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl) :
    LinearIndependent ℝ (fun i j => (B i j:ℝ)) ∧ gramPotential B = gramPotential A := by
  let C := roundReduceIntegerAll A k.val (Nat.le_of_lt k.isLt)
  obtain ⟨hC, _, _, _⟩ := roundReduceAll_spec (euclideanIntegerRows A)
    ((euclideanIntegerRows_independent_iff A).mpr hA) k.val (Nat.le_of_lt k.isLt)
  rw [← euclideanIntegerRows_roundReduceIntegerAll] at hC
  have hC' : LinearIndependent ℝ (fun i j => (C i j:ℝ)) :=
    (euclideanIntegerRows_independent_iff C).mp hC
  rw [rationalReduceIntegerAll_eq] at hB
  obtain ⟨hind, _, hp⟩ := integerRowSweepTrace_invariants C hC' k k.val le_rfl B hB
  exact ⟨hind, hp.trans (gramPotential_roundReduceIntegerAll A _ _)⟩

/-- All rational Gram-Schmidt coordinates computed at any actual inner-loop
state retain the original potential's numerator and denominator bit bounds. -/
theorem outerSweep_innerTrace_gramSchmidt_bits
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ))) (k : Fin r)
    (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace (rationalReduceIntegerAll A k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl) (i : Fin r) (j : Fin d) :
    (rationalGramSchmidt (rationalIntegerRows B) i j).num.natAbs.size ≤
        2 * (gramPotential A).size ∧
      (rationalGramSchmidt (rationalIntegerRows B) i j).den.size ≤ (gramPotential A).size := by
  obtain ⟨hind, hp⟩ := outerSweep_innerTrace_independent_potential A hA k B hB
  simpa only [hp] using rationalGramSchmidt_bits_le B hind i j

/-- Actual coefficients used throughout a rational row sweep have a single
explicit numerator bound in the input height and original potential. -/
theorem outerSweep_innerTrace_coefficient_num
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r)
    (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace (rationalReduceIntegerAll A k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl) (j : Fin r) :
    (rationalGsCoefficient (rationalIntegerRows B) k j).num.natAbs ≤
      (d*H^2+2)*partialReductionGrowth r (gramPotential A)^r*gramPotential A^3 := by
  obtain ⟨hind, hp⟩ := outerSweep_innerTrace_independent_potential A hA k B hB
  have hn := rationalGsCoefficient_num_le_norm_mul_potential_cube B hind k j
  rw [hp] at hn
  have ht := outerSweep_innerTrace_norm_bound A hA k B hB
  have hi := integerRow_norm_add_one_le_height A H hH k
  have hg : (1:ℝ) ≤ partialReductionGrowth r (gramPotential A) := by
    exact_mod_cast (show 1 ≤ partialReductionGrowth r (gramPotential A) by
      unfold partialReductionGrowth; omega)
  have hx := pow_le_pow_right₀ hg (Nat.le_of_lt k.isLt)
  have hm := mul_le_mul hi hx (by positivity)
    (by positivity : (0:ℝ) ≤ (d*H^2+2:ℕ))
  have hrow : ‖euclideanIntegerRows B k‖ ≤
      (d*H^2+2:ℕ) * (partialReductionGrowth r (gramPotential A):ℝ)^r := by linarith
  have hres := hn.trans (mul_le_mul_of_nonneg_right hrow (by positivity :
    (0:ℝ) ≤ (gramPotential A:ℝ)^3))
  exact_mod_cast hres

/-- An explicit polynomial bit-length bound for every reduced coefficient
actually used during a full rational sweep. This counts representation size,
not the running time of arithmetic primitives. -/
theorem outerSweep_innerTrace_coefficient_bits
    (A : Matrix (Fin r) (Fin d) ℤ)
    (hA : LinearIndependent ℝ (fun i j => (A i j:ℝ)))
    (H : ℕ) (hH : ∀ i j, |A i j| ≤ (H:ℤ)) (k : Fin r)
    (B : Matrix (Fin r) (Fin d) ℤ)
    (hB : B ∈ integerRowSweepTrace (rationalReduceIntegerAll A k.val (Nat.le_of_lt k.isLt))
      k k.val le_rfl) (j : Fin r) :
    (rationalGsCoefficient (rationalIntegerRows B) k j).num.natAbs.size ≤
        (r+4)*(d*H^2+2+partialReductionGrowth r (gramPotential A)+gramPotential A).size ∧
      (rationalGsCoefficient (rationalIntegerRows B) k j).den.size ≤ (gramPotential A).size := by
  obtain ⟨hind, hp⟩ := outerSweep_innerTrace_independent_potential A hA k B hB
  constructor
  · apply nat_size_le_of_le_pow (by omega : 0 < r+4)
    let M := d*H^2+2+partialReductionGrowth r (gramPotential A)+gramPotential A
    calc
      _ ≤ (d*H^2+2)*partialReductionGrowth r (gramPotential A)^r*gramPotential A^3 :=
        outerSweep_innerTrace_coefficient_num A hA H hH k B hB j
      _ ≤ M * M^r * M^3 :=
        Nat.mul_le_mul (Nat.mul_le_mul (by dsimp [M]; omega)
          (Nat.pow_le_pow_left (by dsimp [M]; omega) _))
          (Nat.pow_le_pow_left (by dsimp [M]; omega) _)
      _ = M^(r+4) := by rw [← pow_succ', ← pow_add]
  · simpa only [hp] using Nat.size_le_size (rationalGsCoefficient_den_le_potential B hind k j)

end
end Optss
