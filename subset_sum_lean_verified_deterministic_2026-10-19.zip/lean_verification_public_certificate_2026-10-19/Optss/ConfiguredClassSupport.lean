import Optss.IndependentClassSupport
import Optss.OneClassColorCoding

/-!
# Simultaneous clipped supports from configured color coding

Each class uses the actual two-stage uniform hash/color construction, with
explicit logarithmic parameters. Empty classes return `{0}`. All class samples
are taken from their finite dependent product, and the proved marginal laws
transfer the one-class bound to simultaneous target retention.

Witness cardinality bounds for individual classes are inputs to this module;
the dyadic-class estimates supply them in the signed-budget application.
-/

namespace Optss
noncomputable section
open scoped BigOperators Classical

variable {ι G : Type*} [Fintype ι] [DecidableEq ι] [AddCommGroup G] [DecidableEq G]

/-- Clamp a requested witness cap to the class size. Empty classes use a dummy
positive cap solely to keep the unused random sample nonempty. -/
def classWitnessCap (S : Finset ι) (k : ℕ) : ℕ := max 1 (min k S.card)

def classColorLoad (S : Finset ι) (V : ℕ) (ζ : ℝ) : ℕ :=
  colorLoadParameter (max 1 S.card) V ζ

def classColorBuckets (S : Finset ι) (k V : ℕ) (ζ : ℝ) : ℕ :=
  colorBucketCount (classWitnessCap S k) (classColorLoad S V ζ)

abbrev ConfiguredClassSample (S : Finset ι) (k V : ℕ) (ζ : ℝ) :=
  HashColorSample ι (classColorBuckets S k V ζ) (classColorLoad S V ζ)
    (colorRepetitionCount (classColorBuckets S k V ζ) ζ)

omit [Fintype ι] [DecidableEq ι] in
theorem configuredClassSample_nonempty (S : Finset ι) (k V : ℕ) (ζ : ℝ)
    (hV : 1 ≤ V) (hζ : 0 < ζ) (hζ1 : ζ < 1) :
    Nonempty (ConfiguredClassSample S k V ζ) := by
  have hL : 0 < classColorLoad S V ζ :=
    colorLoadParameter_pos _ V ζ (le_max_left _ _) hV hζ hζ1
  have hb : 0 < classColorBuckets S k V ζ := by
    unfold classColorBuckets colorBucketCount
    omega
  letI : Nonempty (Fin (classColorBuckets S k V ζ)) := ⟨⟨0,hb⟩⟩
  letI : Nonempty (Fin (128*(classColorLoad S V ζ)^2)) := ⟨⟨0,by positivity⟩⟩
  infer_instance

/-- Configured nonempty classes use color coding; an empty class has its exact
singleton support without running any support computation. -/
def configuredClassColorSupport (v : ι → G) (S : Finset ι)
    (B : Set G) [DecidablePred B] (k V : ℕ) (ζ : ℝ)
    (sample : ConfiguredClassSample S k V ζ) : Finset G :=
  if S.Nonempty then oneClassColorSupport v S B sample else {0}

omit [Fintype ι] [DecidableEq ι] in
@[simp] theorem configuredClassColorSupport_empty (v : ι → G)
    (B : Set G) [DecidablePred B] (k V : ℕ) (ζ : ℝ)
    (sample : ConfiguredClassSample (∅ : Finset ι) k V ζ) :
    configuredClassColorSupport v ∅ B k V ζ sample = {0} := by
  simp [configuredClassColorSupport]

omit [Fintype ι] in
/-- Both the exact empty branch and the randomized branch preserve original
class-label witnesses for every random outcome. -/
theorem configuredClassColorSupport_sound (v : ι → G) (S : Finset ι)
    (B : Set G) [DecidablePred B] (k V : ℕ) (ζ : ℝ)
    (sample : ConfiguredClassSample S k V ζ) {t : G}
    (ht : t ∈ configuredClassColorSupport v S B k V ζ sample) :
    ∃ s : Finset ι, s ⊆ S ∧ (∑ i ∈ s, v i) = t := by
  unfold configuredClassColorSupport at ht
  split_ifs at ht with hS
  · exact (oneClassColorSupport_sound v S B sample ht).2
  · have ht0 : t=0 := Finset.mem_singleton.mp ht
    exact ⟨∅, Finset.empty_subset _, by simp [ht0]⟩

/-- Actual missing-witness probability for the configured support, including
empty classes and caps larger than the available number of labels. -/
theorem uniform_configuredClassColorSupport_failure_le (v : ι → G) (S s : Finset ι)
    (B : Set G) [DecidablePred B] (k V : ℕ) (hV : 1 ≤ V)
    (hs : s ⊆ S) (hcard : s.card ≤ k) (hB : (∑ i ∈ s, v i) ∈ B)
    (ζ : ℝ) (hζ : 0 < ζ) (hζ1 : ζ < 1) :
    uniformProbability (Finset.univ.filter (fun sample : ConfiguredClassSample S k V ζ =>
      (∑ i ∈ s, v i) ∉ configuredClassColorSupport v S B k V ζ sample)) ≤ ζ := by
  letI : Nonempty (ConfiguredClassSample S k V ζ) :=
    configuredClassSample_nonempty S k V ζ hV hζ hζ1
  by_cases hS : S.Nonempty
  · have hcap : 1 ≤ classWitnessCap S k := le_max_left _ _
    have hcapm : classWitnessCap S k ≤ max 1 S.card :=
      max_le_max (le_refl 1) (min_le_right _ _)
    have hscap : s.card ≤ classWitnessCap S k :=
      (le_min hcard (Finset.card_le_card hs)).trans (le_max_right _ _)
    obtain ⟨hL, hb, _, _, hcapacity⟩ :=
      color_parameter_bucket_bounds (max 1 S.card) (classWitnessCap S k) V ζ
        hcap hcapm hV hζ hζ1
    have he : Finset.univ.filter (fun sample : ConfiguredClassSample S k V ζ =>
        (∑ i ∈ s, v i) ∉ configuredClassColorSupport v S B k V ζ sample) =
        hashColorFailure v S (∑ i ∈ s, v i) B (classColorBuckets S k V ζ)
          (classColorLoad S V ζ) (colorRepetitionCount (classColorBuckets S k V ζ) ζ) := by
      ext sample
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, mem_hashColorFailure,
        configuredClassColorSupport, if_pos hS]
    rw [he]
    apply uniform_hashColorFailure_le_allowance v S s B _ _ _ hb hL hs
      (hscap.trans hcapacity) hB ζ
    · exact color_parameter_load_budget (max 1 S.card) (classWitnessCap S k) V ζ
        hcap hcapm hV hζ hζ1
    · exact ceil_log_repetitions_sufficient _ hb ζ hζ
  · have hs0 : s = ∅ := Finset.subset_empty.mp
      (by simpa only [Finset.not_nonempty_iff_eq_empty.mp hS] using hs)
    have he : Finset.univ.filter (fun sample : ConfiguredClassSample S k V ζ =>
        (∑ i ∈ s, v i) ∉ configuredClassColorSupport v S B k V ζ sample) = ∅ := by
      ext sample
      simp [configuredClassColorSupport, hS, hs0]
    rw [he]
    simpa only [uniformProbability, Finset.card_empty, Nat.cast_zero, zero_div] using hζ.le

/-- The actual input-label set for one part of a fixed finite partition. -/
def classLabels {g : ℕ} (part : ι → Fin g) (p : Fin g) : Finset ι :=
  Finset.univ.filter (fun i => part i=p)

/-- Class-dependent configured color-coding supports, each clipped to the final
absolute-budget box before the class supports are combined. -/
def configuredClassFamilySupports {d g : ℕ} (v : ι → IntVec d) (part : ι → Fin g)
    (Δ : Fin d →₀ ℕ) (k : Fin g → ℕ) (V : ℕ) (ζ : ℝ) :
    ∀ p, ConfiguredClassSample (classLabels part p) (k p) V ζ → Finset (IntVec d) :=
  fun p => configuredClassColorSupport v (classLabels part p)
    {t | InBox (fun j => (Δ j : ℤ)) t} (k p) V ζ

/-- The fully specified random support for all classes, with intermediate
clipping after each class merge. -/
def configuredSignedClassSupport {d g : ℕ} (v : ι → IntVec d) (part : ι → Fin g)
    (Δ : Fin d →₀ ℕ) (k : Fin g → ℕ) (V : ℕ) (ζ : ℝ)
    (sample : ∀ p, ConfiguredClassSample (classLabels part p) (k p) V ζ) :
    Finset (IntVec d) :=
  randomClassSupport Δ
    (independentClassSupports (configuredClassFamilySupports v part Δ k V ζ)) sample

/-- Every output of the complete class construction is a realizable labelled
subset sum within the final box, for every random outcome. -/
theorem configuredSignedClassSupport_sound {d g : ℕ} (v : ι → IntVec d)
    (part : ι → Fin g) (Δ : Fin d →₀ ℕ) (k : Fin g → ℕ) (V : ℕ) (ζ : ℝ)
    (sample : ∀ p, ConfiguredClassSample (classLabels part p) (k p) V ζ)
    {t : IntVec d} (ht : t ∈ configuredSignedClassSupport v part Δ k V ζ sample) :
    t ∈ subsetSums v ∧ InBox (fun j => (Δ j : ℤ)) t := by
  apply randomClassSupport_sound v part Δ _ ?_ sample ht
  intro p f t ht
  exact configuredClassColorSupport_sound v (classLabels part p) _ (k p) V ζ (f p) ht

/-- A fixed absolute-budget witness's class part obeys the actual configured
one-class probability bound, including the exact empty-class branch. -/
theorem configuredClassFamily_local_failure_le {d g : ℕ} (v : ι → IntVec d)
    (part : ι → Fin g) (Δ : Fin d →₀ ℕ) (k : Fin g → ℕ) (V : ℕ) (hV : 1 ≤ V)
    (ζ : ℝ) (hζ : 0 < ζ) (hζ1 : ζ < 1) (s : Finset ι)
    (hbudget : AbsoluteBudget v s (fun j => (Δ j : ℤ)))
    (hcard : ∀ p, (s.filter (fun i => part i=p)).card ≤ k p) (p : Fin g) :
    uniformProbability (localClassWitnessFailure v part
      (configuredClassFamilySupports v part Δ k V ζ) s p) ≤ ζ := by
  have hsub : s.filter (fun i => part i=p) ⊆ classLabels part p := by
    intro i hi
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ i, (Finset.mem_filter.mp hi).2⟩
  have hpart := absoluteBudget_mono v (Finset.filter_subset (fun i => part i=p) s) hbudget
  have hB := sum_inBox_of_absoluteBudget v hpart
  exact uniform_configuredClassColorSupport_failure_le v (classLabels part p)
    (s.filter (fun i => part i=p)) _ (k p) V hV hsub (hcard p) hB ζ hζ hζ1

/-- Simultaneous completeness for the actual independently sampled configured
class constructions. Every probability premise has been discharged from the
explicit algorithm; only deterministic witness budgets and class caps remain. -/
theorem uniform_configuredSignedClassSupport_failure_le {d g : ℕ} (v : ι → IntVec d)
    (part : ι → Fin g) (Δ : Fin d →₀ ℕ) (k : Fin g → ℕ) (V : ℕ) (hV : 1 ≤ V)
    (ζ : ℝ) (hζ : 0 < ζ) (hζ1 : ζ < 1)
    (T : Finset (IntVec d)) (witness : {t // t ∈ T} → Finset ι)
    (hsum : ∀ t, (∑ i ∈ witness t, v i) = t.val)
    (hbudget : ∀ t, AbsoluteBudget v (witness t) (fun j => (Δ j : ℤ)))
    (hcard : ∀ t p, ((witness t).filter (fun i => part i=p)).card ≤ k p) :
    uniformProbability (Finset.univ.filter
      (fun sample : ∀ p, ConfiguredClassSample (classLabels part p) (k p) V ζ =>
        ∃ t ∈ T, t ∉ configuredSignedClassSupport v part Δ k V ζ sample)) ≤ (T.card*g:ℕ)*ζ := by
  letI : ∀ p, Nonempty (ConfiguredClassSample (classLabels part p) (k p) V ζ) :=
    fun p => configuredClassSample_nonempty (classLabels part p) (k p) V ζ hV hζ hζ1
  apply uniform_independent_simultaneousClassFailure_le v part Δ
    (configuredClassFamilySupports v part Δ k V ζ) T witness hsum hbudget ζ
  intro t p
  exact configuredClassFamily_local_failure_le v part Δ k V hV ζ hζ hζ1
    (witness t) (hbudget t) (hcard t) p

end
end Optss
