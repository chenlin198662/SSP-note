import Optss.CommonBlockWindow

/-!
# The exact reserve support of disjoint actual blocks

Minkowski sums of block supports are exactly the subset sums of their union.
The reserve cardinality and enclosing box follow from the actual block-size
bound, preserving labels even when equal scalar or vector values occur.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 1000000

/-- Supports add exactly when no label is shared. -/
theorem labelledSubsetSupport_union {ι G : Type*} [DecidableEq ι]
    [AddCommGroup G] [DecidableEq G] (v : ι → G) (P Q : Finset ι)
    (hPQ : Disjoint P Q) :
    labelledSubsetSupport v (P ∪ Q) = labelledSubsetSupport v P + labelledSubsetSupport v Q := by
  ext x
  constructor
  · intro hx
    obtain ⟨s, hs, rfl⟩ := (mem_labelledSubsetSupport v _ _).mp hx
    have hQ : s \ P ⊆ Q := by
      intro i hi
      exact (Finset.mem_union.mp (hs (Finset.mem_sdiff.mp hi).1)).resolve_left (Finset.mem_sdiff.mp hi).2
    have he := Finset.sum_union (Finset.disjoint_sdiff_inter s P) (f := v)
    rw [Finset.sdiff_union_inter] at he
    apply Finset.mem_add.mpr
    exact ⟨∑ i ∈ s ∩ P, v i,
      (mem_labelledSubsetSupport v _ _).mpr ⟨s ∩ P, Finset.inter_subset_right, rfl⟩,
      ∑ i ∈ s \ P, v i,
      (mem_labelledSubsetSupport v _ _).mpr ⟨s \ P, hQ, rfl⟩,
      (add_comm _ _).trans he.symm⟩
  · intro hx
    obtain ⟨x, hleft, y, hright, rfl⟩ := Finset.mem_add.mp hx
    obtain ⟨s, hs, rfl⟩ := (mem_labelledSubsetSupport v _ _).mp hleft
    obtain ⟨t, ht, rfl⟩ := (mem_labelledSubsetSupport v _ _).mp hright
    have hst : Disjoint s t := hPQ.mono hs ht
    exact (mem_labelledSubsetSupport v _ _).mpr ⟨s ∪ t, Finset.union_subset_union hs ht,
      Finset.sum_union hst⟩

/-- Exact support of the union of any finite family of disjoint blocks. -/
theorem labelledSubsetSupport_biUnion {ι κ G : Type*} [DecidableEq ι] [DecidableEq κ]
    [AddCommGroup G] [DecidableEq G] (v : ι → G) (I : Finset κ) (P : κ → Finset ι)
    (hdis : (I : Set κ).PairwiseDisjoint P) :
    labelledSubsetSupport v (I.biUnion P) = ∑ i ∈ I, labelledSubsetSupport v (P i) := by
  induction I using Finset.induction_on with
  | empty => simp [labelledSubsetSupport]; rfl
  | @insert i I hi ih =>
    have hd : Disjoint (P i) (I.biUnion P) := by
      apply Finset.disjoint_left.mpr
      intro x hxi hxU
      obtain ⟨j, hj, hxj⟩ := Finset.mem_biUnion.mp hxU
      have hij : i ≠ j := fun he => hi (he ▸ hj)
      exact Finset.disjoint_left.mp
        (hdis (Finset.mem_insert_self _ _) (Finset.mem_insert_of_mem hj) hij) hxi hxj
    rw [Finset.biUnion_insert, labelledSubsetSupport_union v _ _ hd, Finset.sum_insert hi,
      ih (fun a ha b hb hab => hdis (Finset.mem_insert_of_mem ha) (Finset.mem_insert_of_mem hb) hab)]

namespace BoundedBlockSelector
variable {ι : Type} [DecidableEq ι] {d : ℕ} {v : ι → IntVec d}
  {initial : Finset ι} {B : ℕ}

/-- Every actual block support stays inside its allocated coordinate box. -/
theorem block_sums_box (F : BoundedBlockSelector v initial B)
    (w : Fin d → ℕ) (hbox : ∀ i ∈ initial, InCenteredBox w (v i)) (n : ℕ) :
    ∀ x ∈ (F.block n).sums, InCenteredBox (fun j => B*w j) x := by
  have hv := (F.valid _ (F.remaining_subset n)).2
  change (F.block n).sums = labelledSubsetSupport v (F.block n).chosen at hv
  intro x hx
  have hx' : x ∈ labelledSubsetSupport v (F.block n).chosen := by rw [← hv]; exact hx
  have hb := labelledSubsetSupport_inBox v (F.block n).chosen w
    (fun i hi => hbox i (F.remaining_subset n (F.chosen_subset _ (F.remaining_subset n) hi))) x hx'
  intro j
  exact (hb j).trans (by
    dsimp only
    exact_mod_cast Nat.mul_le_mul_right (w j) (F.size_le _ (F.remaining_subset n)))

/-- Actual reserve labels from a consecutive block window. -/
def reserve (F : BoundedBlockSelector v initial B) (start ℓ : ℕ) : Finset ι :=
  (Finset.range ℓ).biUnion (fun t => (F.block (start+t)).chosen)

theorem reserve_subset (F : BoundedBlockSelector v initial B) (start ℓ : ℕ) :
    F.reserve start ℓ ⊆ F.remaining start := by
  intro i hi
  obtain ⟨t, _, hit⟩ := Finset.mem_biUnion.mp hi
  exact F.remaining_antitone (Nat.le_add_right start t)
    (F.chosen_subset _ (F.remaining_subset (start+t)) hit)

theorem reserve_card_le (F : BoundedBlockSelector v initial B) (start ℓ : ℕ) :
    (F.reserve start ℓ).card ≤ ℓ*B := by
  apply Finset.card_biUnion_le.trans
  calc
    _ ≤ ∑ t ∈ Finset.range ℓ, B := Finset.sum_le_sum (fun t _ => F.size_le _ (F.remaining_subset (start+t)))
    _ = ℓ*B := by simp

/-- The support needed by dense-box filling is exactly the support of these
original reserve labels, without reusing any copy. -/
theorem reserve_support (F : BoundedBlockSelector v initial B) (start ℓ : ℕ) :
    labelledSubsetSupport v (F.reserve start ℓ) = ∑ t ∈ Finset.range ℓ, (F.block (start+t)).sums := by
  have hdis : ((Finset.range ℓ) : Set ℕ).PairwiseDisjoint (fun t => (F.block (start+t)).chosen) := by
    intro i _ j _ hij
    rcases lt_or_gt_of_ne hij with hij | hij
    · exact F.blocks_disjoint (Nat.add_lt_add_left hij _)
    · exact (F.blocks_disjoint (Nat.add_lt_add_left hij _)).symm
  rw [reserve, labelledSubsetSupport_biUnion v _ _ hdis]
  apply Finset.sum_congr rfl
  intro t _
  exact (F.valid _ (F.remaining_subset (start+t))).2.symm

end BoundedBlockSelector
end
end Optss
