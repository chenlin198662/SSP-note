import Optss.ProperizationIteration
import Optss.RationalReductionExistence

/-!
# Mathematical properization, with all reduction inputs discharged

The actual rational normalization, integer lattice reduction, full-lattice
boxing and strong rank descent give a containing proper integer GAP. The
enlargement factor below is explicit and depends only on dimension and the
properness scale. This is an existence theorem; no polynomial bit algorithm
or runtime claim is attached to the noncomputable choices in its proof.
-/

namespace Optss
noncomputable section
open scoped BigOperators Pointwise Classical
variable {G : Type*} [AddCommGroup G] [IsAddTorsionFree G]

theorem rationalReductionProperty_bounded (r : ℕ) :
    RationalReductionProperty r (latticeReductionDefectBound r) := by
  intro a hc
  obtain ⟨c⟩ := hc
  exact exists_standard_lattice_basis_bounded_defect a c

/-- An explicit coefficient-volume factor for mathematical properization. -/
def properizationVolumeFactor (d t : ℕ) : ℕ :=
  (properizationIterationFactor latticeReductionDefectBound t d)^d

theorem properizationVolumeFactor_pos (d t : ℕ) : 1 ≤ properizationVolumeFactor d t :=
  one_le_pow₀ (properizationIterationFactor_pos latticeReductionDefectBound t d)

/-- Unconditional containing-GAP properization at every integer scale.
All lattice existence inputs used by the rank induction are now proved. -/
theorem exists_integer_proper_progression {d : ℕ} (ρ : IntVec d →+ G)
    (β : Fin d → ℕ) (t : ℕ) :
    ∃ r ≤ d, ∃ (ρ' : IntVec r →+ G) (γ : Fin r → ℕ),
      integerProgressionValues ρ β ⊆ integerProgressionValues ρ' γ ∧
      Set.InjOn ρ' (integerBudgetBox (fun j => t*γ j)) ∧
      (integerBudgetBox γ).card ≤ properizationVolumeFactor d t*(integerBudgetBox β).card :=
  integerProgression_properization_of_reduction latticeReductionDefectBound t d
    latticeReductionDefectBound_pos (fun k _ => rationalReductionProperty_bounded k) d le_rfl ρ β

/-- Coordinate inequalities for a real-scaled coefficient box. For
nonnegative scales these describe its geometric dilation's integer points. -/
def realDilatedIntegerBox {d : ℕ} (β : Fin d → ℕ) (t : ℝ) : Set (IntVec d) :=
  {x | ∀ j, |(x j:ℝ)| ≤ t*(β j:ℝ)}

theorem realDilatedIntegerBox_subset_ceiling {d : ℕ} (β : Fin d → ℕ) (t : ℝ) :
    realDilatedIntegerBox β t ⊆ integerBudgetBox (fun j => ⌈t⌉₊*β j) := by
  intro x hx
  change x ∈ integerBudgetBox (fun j => ⌈t⌉₊*β j)
  rw [mem_integerBudgetBox]
  intro j
  have h : |(x j:ℝ)| ≤ ((⌈t⌉₊*β j:ℕ):ℝ) := by
    push_cast
    exact (hx j).trans (mul_le_mul_of_nonneg_right (Nat.le_ceil t) (Nat.cast_nonneg _))
  exact_mod_cast h

/-- The paper's real-scale properization statement: rank does not increase,
every original value survives, the entire real `t`-dilate is proper, and the
coefficient-volume factor depends only on the original rank and `t`. -/
theorem exists_real_proper_progression {d : ℕ} (ρ : IntVec d →+ G)
    (β : Fin d → ℕ) (t : ℝ) :
    ∃ r ≤ d, ∃ (ρ' : IntVec r →+ G) (γ : Fin r → ℕ),
      integerProgressionValues ρ β ⊆ integerProgressionValues ρ' γ ∧
      Set.InjOn ρ' (realDilatedIntegerBox γ t) ∧
      (integerBudgetBox γ).card ≤
        properizationVolumeFactor d ⌈t⌉₊*(integerBudgetBox β).card := by
  obtain ⟨r, hr, ρ', γ, hcont, hproper, hcard⟩ := exists_integer_proper_progression ρ β ⌈t⌉₊
  exact ⟨r, hr, ρ', γ, hcont, hproper.mono (realDilatedIntegerBox_subset_ceiling γ t), hcard⟩

/-- Theorem 2.C, with a single explicit volume factor valid for every input
rank at most `R`, in an arbitrary torsion-free abelian group. -/
theorem theorem2C_properization (R : ℕ) (t : ℝ) {d : ℕ} (hd : d ≤ R)
    (ρ : IntVec d →+ G) (β : Fin d → ℕ) :
    ∃ r ≤ R, ∃ (ρ' : IntVec r →+ G) (γ : Fin r → ℕ),
      integerProgressionValues ρ β ⊆ integerProgressionValues ρ' γ ∧
      Set.InjOn ρ' (realDilatedIntegerBox γ t) ∧
      (integerBudgetBox γ).card ≤
        properizationVolumeFactor R ⌈t⌉₊*(integerBudgetBox β).card := by
  obtain ⟨r, hr, ρ', γ, hcont, hproper, hcard⟩ :=
    integerProgression_properization_of_reduction latticeReductionDefectBound ⌈t⌉₊ R
      latticeReductionDefectBound_pos (fun k _ => rationalReductionProperty_bounded k) d hd ρ β
  refine ⟨r, hr.trans hd, ρ', γ, hcont,
    hproper.mono (realDilatedIntegerBox_subset_ceiling γ t), hcard.trans ?_⟩
  exact Nat.mul_le_mul_right _ (pow_le_pow_right₀
    (properizationIterationFactor_pos latticeReductionDefectBound ⌈t⌉₊ R) hd)

/-- The exact integer points of a symmetric real-width coefficient box. -/
def realWidthIntegerBox {d : ℕ} (β : Fin d → ℝ) : Finset (IntVec d) :=
  integerBudgetBox (fun j => ⌊β j⌋₊)

theorem mem_realWidthIntegerBox {d : ℕ} (β : Fin d → ℝ) (hβ : ∀ j, 0 ≤ β j)
    (x : IntVec d) : x ∈ realWidthIntegerBox β ↔ ∀ j, |(x j:ℝ)| ≤ β j := by
  rw [realWidthIntegerBox, mem_integerBudgetBox]
  constructor
  · intro hx j
    have hnat : (x j).natAbs ≤ ⌊β j⌋₊ := by
      have h := hx j
      change |x j| ≤ (⌊β j⌋₊:ℤ) at h
      rw [← Int.natCast_natAbs] at h
      exact Int.ofNat_le.mp h
    have h := (Nat.le_floor_iff (hβ j)).mp hnat
    simpa only [Int.cast_natAbs, Int.cast_abs] using h
  · intro hx j
    have h : ((x j).natAbs:ℝ) ≤ β j := by simpa only [Int.cast_natAbs, Int.cast_abs] using hx j
    have hnat := (Nat.le_floor_iff (hβ j)).mpr h
    have hcast : ((x j).natAbs:ℤ) ≤ (⌊β j⌋₊:ℤ) := by exact_mod_cast hnat
    simpa only [Int.natCast_natAbs] using hcast

/-- Literal real-endpoint version of Theorem 2.C. The floor operation changes
neither the input coefficient set nor its volume, as the preceding membership
equivalence proves. The output has integer widths and is proper on its real
`t`-dilate. -/
theorem theorem2C_real_widths (R : ℕ) (t : ℝ) {d : ℕ} (hd : d ≤ R)
    (ρ : IntVec d →+ G) (β : Fin d → ℝ) (hβ : ∀ j, 0 ≤ β j) :
    ∃ r ≤ R, ∃ (ρ' : IntVec r →+ G) (γ : Fin r → ℕ),
      (realWidthIntegerBox β).image ρ ⊆ integerProgressionValues ρ' γ ∧
      Set.InjOn ρ' (realDilatedIntegerBox γ t) ∧
      (integerBudgetBox γ).card ≤
        properizationVolumeFactor R ⌈t⌉₊*(realWidthIntegerBox β).card ∧
      ∀ x : IntVec d, x ∈ realWidthIntegerBox β ↔ ∀ j, |(x j:ℝ)| ≤ β j := by
  obtain ⟨r, hr, ρ', γ, hcont, hproper, hcard⟩ := theorem2C_properization R t hd ρ (fun j => ⌊β j⌋₊)
  exact ⟨r, hr, ρ', γ, hcont, hproper, hcard, mem_realWidthIntegerBox β hβ⟩

end
end Optss
