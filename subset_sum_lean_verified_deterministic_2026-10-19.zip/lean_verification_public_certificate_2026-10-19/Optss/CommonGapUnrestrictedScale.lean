import Optss.CommonPhaseInputBounds
import Optss.CommonProductLogarithms

/-!
# The common-GAP decomposition at unrestricted scales

The actual phase model, basis protection, greedy blocks, lattice window,
boxing, and dense filling are iterated to termination. All resulting rank,
reserve, outlier and filling constants depend only on the fixed exponent and
rank-protection multiplier. No structural or growth certificate is an input.
-/
namespace Optss
noncomputable section
open scoped Classical Pointwise BigOperators
set_option maxHeartbeats 2400000

/-- Uniform mathematical common-GAP decomposition at every sufficiently large scale,
with no bound on multiplicities or upper bound on the scale. -/
theorem common_gap_unrestricted_scale (η : ℝ) (hη : 0 < η) :
    ∃ N₀ H₀ R Rconst : ℕ, ∃ c₀ : ℝ, 0 < c₀ ∧ ∀ f : ℕ, ∃ Econst : ℕ,
      ∀ (ι : Type) [LinearOrder ι] (scalar : ι → ℤ) (initial : Finset ι) (N h : ℕ),
        N₀ ≤ N → H₀ ≤ h → 1 ≤ N → (N : ℝ)^η ≤ h →
        (∀ i ∈ initial, scalar i ∈ Finset.Icc 1 (N : ℤ)) →
        Nonempty (CommonGapDecomposition scalar initial h (f*h) R
          (Econst*h*(Nat.log 2 (h*N+2)+1)^2) (Rconst*h) c₀) := by
  obtain ⟨N₁, H₁, R, C₁, hmodel⟩ := common_gap_label_model η hη
  obtain ⟨a, N₂, c, ha, hc, hphase⟩ := actual_common_phase_outcome η hη
  let C := max 1 C₁
  have hC : 0 < C := lt_of_lt_of_le zero_lt_one (le_max_left _ _)
  let K := commonPhaseBlockConstant R C c η a
  have hK : 1 ≤ K := le_max_left _ _
  let ℓ := commonWindowLength R K C
  let L := Nat.log 2 (2*commonPhaseDeterminantConstant R C)+2
  let H₀ := max H₁ (max 4 (max ⌈C⌉₊ (commonWindowWidthThreshold R K C)))
  refine ⟨max N₁ N₂, H₀, R, ℓ*K, commonWindowScale R K C,
    (common_window_parameters R K hK C hC).2.1, ?_⟩
  intro f
  let D := max 1 R*(L*ℓ*K+f)
  refine ⟨3*D, ?_⟩
  intro ι _ scalar initial N h hN₀ hH₀ hN hscale hscalar
  let logN := Nat.log 2 (h*N+2)+1
  have hlog : 1 ≤ logN := Nat.le_add_left _ _
  have hH₁ : H₁ ≤ h := (le_max_left _ _).trans hH₀
  have hh4 : 4 ≤ h := (le_max_left 4 _).trans ((le_max_right H₁ _).trans hH₀)
  have hh : 1 ≤ h := by omega
  have hceil : ⌈C⌉₊ ≤ h := (le_max_left _ _).trans
    ((le_max_right 4 _).trans ((le_max_right H₁ _).trans hH₀))
  have hCh : C ≤ h := (Nat.le_ceil C).trans (Nat.cast_le.mpr hceil)
  have hprotect : 2*C < (2*h+1 : ℕ) := by push_cast; linarith
  have hwidth : commonWindowWidthThreshold R K C ≤ 2*h+1 :=
    ((le_max_right _ _).trans ((le_max_right 4 _).trans ((le_max_right H₁ _).trans hH₀))).trans (by omega)
  have hscalar0 : ∀ i ∈ initial, scalar i ∈ Finset.Icc 0 (N : ℤ) := by
    intro i hi
    obtain ⟨hl, hu⟩ := Finset.mem_Icc.mp (hscalar i hi)
    exact Finset.mem_Icc.mpr ⟨by omega, hu⟩
  have phase : ∀ s ⊆ initial,
      (∃ next ⊆ s, 2*(h • insert 0 (next.image scalar)).card <
        (h • insert 0 (s.image scalar)).card ∧ (s \ next).card ≤ D*h*logN) ∨
      Nonempty (CommonGapDecomposition scalar s h (f*h) R (D*h*logN) ((ℓ*K)*h)
        (commonWindowScale R K C)) := by
    intro s hs
    by_cases hsempty : s = ∅
    · subst s
      exact Or.inr ⟨emptyCommonGapDecomposition scalar h (f*h) R _ _ _⟩
    have hsnonempty := Finset.nonempty_iff_ne_empty.mpr hsempty
    have hspos : ∀ i ∈ s, 0 < scalar i := fun i hi =>
      lt_of_lt_of_le (by norm_num) (Finset.mem_Icc.mp (hscalar i (hs hi))).1
    have hsbox : ∀ i ∈ s, scalar i ∈ Finset.Icc 0 (N : ℤ) := fun i hi => hscalar0 i (hs hi)
    obtain ⟨model, hdR, hvol⟩ := hmodel ι scalar s N h ((le_max_left _ _).trans hN₀) hH₁ hscale hsbox
    have hd := model.rank_pos hsnonempty hspos
    let M := (h • insert 0 (s.image scalar)).card
    have hM : M ≤ h*N+1 := labelled_scalar_potential_bound scalar s h N hsbox
    have hM4 : 4 ≤ M := by
      have hp := labelled_positive_potential_lower scalar s hsnonempty hspos h
      omega
    have hvolume : ((integerBudgetBox (fun j => h*model.widths j)).card : ℝ) ≤ C*M :=
      hvol.trans (mul_le_mul_of_nonneg_right (le_max_right 1 C₁) (Nat.cast_nonneg _))
    let B := ⌈(latticeSeedCardBound model.rank model.widths : ℝ)+greedyProfileConstant c a η*h⌉₊
    let n := (Nat.log 2 (model.rank.factorial*∏ j, model.widths j)+1)*ℓ
    let k := n*B+f*h
    have hB : B ≤ K*h := common_phase_block_budget model.widths R h N M hdR hh hN η hη hscale hM C hC.le hvolume c a
    have hlogdet : Nat.log 2 (model.rank.factorial*∏ j, model.widths j)+1 ≤ L*logN :=
      common_phase_product_log_bound _ (commonPhaseDeterminantConstant R C) M h N hM
        (common_phase_determinant_bound model.widths R h M hdR hh C hC.le hvolume)
    have hnb : n*B ≤ L*logN*ℓ*(K*h) := Nat.mul_le_mul (Nat.mul_le_mul_right ℓ hlogdet) hB
    have hk : k ≤ (L*ℓ*K+f)*h*logN := by
      have hf : f*h ≤ f*h*logN := by simpa only [mul_one] using Nat.mul_le_mul_left (f*h) hlog
      dsimp only [k]
      nlinarith
    have hdelete : max 1 R*k ≤ D*h*logN :=
      (Nat.mul_le_mul_left (max 1 R) hk).trans_eq (by dsimp only [D]; ring)
    have hreserve : ℓ*B ≤ (ℓ*K)*h :=
      (Nat.mul_le_mul_left ℓ hB).trans_eq (by ring)
    have halt := hphase ι scalar s h model N R (f*h) C ((le_max_right _ _).trans hN₀)
      hN hh hd hdR hC hscale hsbox hM4 hM hvolume hprotect hwidth
    rcases halt with halt | halt
    · obtain ⟨next, hnsub, hn, hdel⟩ := halt
      exact Or.inl ⟨next, hnsub, hn, hdel.trans hdelete⟩
    · obtain ⟨out⟩ := halt
      exact Or.inr ⟨out.weakenBounds _ _ hdelete hreserve⟩
  obtain ⟨_, _, ⟨out⟩⟩ := common_gap_iterated_decomposition scalar initial h (f*h) R
    (D*h*logN) ((ℓ*K)*h) (commonWindowScale R K C) phase
  refine ⟨out.weakenBounds _ _ ?_ le_rfl⟩
  have hM := labelled_scalar_potential_bound scalar initial h N hscalar0
  have hlogM := common_potential_product_log_bound _ h N hM
  have hlogM' : Nat.log 2 ((h • insert 0 (initial.image scalar)).card)+2 ≤ 3*logN := by omega
  exact (Nat.mul_le_mul_right (D*h*logN) hlogM').trans_eq (by ring)

end
end Optss
