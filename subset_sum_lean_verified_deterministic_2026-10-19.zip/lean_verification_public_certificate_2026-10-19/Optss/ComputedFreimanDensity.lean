import Optss.StoredModelProgression
import Optss.FreimanCoveringBounds

/-! Uniform rank and density for the actual modeled progression. All bounds
come from the original small-doubling input and the actual sieve/part result.
The constants below bound the algorithm; they do not select its answer. -/
namespace Optss
open scoped Pointwise

def computedFreimanModelRatio (C : ℚ≥0) : ℝ := 128*((C:ℝ)^16+1)

noncomputable def computedFreimanRankBound (C : ℚ≥0) : ℕ :=
  ⌈16*(computedFreimanModelRatio C)^2⌉₊+1

def uniformComputedBohrLoss (R : ℕ) : ℕ :=
  (Finset.range (R+1)).sup computableBohrLoss

theorem computableBohrLoss_le_uniform {r R : ℕ} (hr : r≤R) :
    computableBohrLoss r≤uniformComputedBohrLoss R :=
  Finset.le_sup (Finset.mem_range.mpr (by omega))

theorem uniformComputedBohrLoss_pos (R : ℕ) : 0<uniformComputedBohrLoss R :=
  (computableBohrLoss_pos 0).trans_le (computableBohrLoss_le_uniform (Nat.zero_le R))

theorem computedModelingPart_model_ratio (data differences : List ℤ) (u p q n : ℕ)
    (hd : data.Nodup) (hne : data.toFinset.Nonempty) (hD : differences.Nodup)
    (hS : ∀ a∈data,0≤a ∧ a≤u)
    (h8 : differences.toFinset=modelingDifferences data.toFinset 8)
    (hparams : computedModelingParameters differences u=some (p,q,n))
    (C : ℚ≥0) (hC : ((data.toFinset+data.toFinset).card:ℚ≥0)≤C*data.toFinset.card) :
    (p:ℝ)≤computedFreimanModelRatio C*(computedModelingPart data n q).length := by
  obtain ⟨p',q',n',he,hp,hq,hplo,hphi,hql,hpb,hqb,hrest⟩ :=
    computedModelingParameters_correct data.toFinset u differences
      (fun a ha => hS a (List.mem_toFinset.mp ha)) hD h8
  have hparam : p'=p ∧ q'=q ∧ n'=n := by
    simpa only [Option.some.injEq,Prod.mk.injEq] using he.symm.trans hparams
  rcases hparam with ⟨hp',hq',hn'⟩
  subst p'; subst q'; subst n'
  have hdiff := modelingDifferences_card_le data.toFinset hne C hC
  rw [←h8,List.toFinset_card_of_nodup hD,List.toFinset_card_of_nodup hd] at hdiff
  have hdR : (differences.length:ℝ)≤(C:ℝ)^16*data.length := by exact_mod_cast hdiff
  have hpR : (p:ℝ)≤16*((differences.length:ℝ)+1) := by exact_mod_cast hphi.le
  have hlen := computedModelingPart_card data n q hq.pos hd
  have hlenR : (data.length:ℝ)≤8*(computedModelingPart data n q).length := by exact_mod_cast hlen
  have hpos : (1:ℝ)≤data.length := by
    have h := Finset.card_pos.mpr hne
    rw [List.toFinset_card_of_nodup hd] at h
    exact_mod_cast h
  have hCpos : 0≤(C:ℝ)^16 := by positivity
  unfold computedFreimanModelRatio
  calc
    (p:ℝ)≤16*((differences.length:ℝ)+1) := hpR
    _≤16*((C:ℝ)^16*data.length+1) := by gcongr
    _≤16*(((C:ℝ)^16+1)*data.length) := by nlinarith
    _≤16*(((C:ℝ)^16+1)*(8*(computedModelingPart data n q).length)) := by gcongr
    _=_ := by ring

theorem computedFreiman_rank_of_ratio (r p m : ℕ) (hm : 0 < m) (C : ℚ≥0)
    (hpm : (p:ℝ)≤computedFreimanModelRatio C*m)
    (hr : (r:ℝ)≤1+16*(p:ℝ)^2/(m:ℝ)^2) : r≤computedFreimanRankBound C := by
  have hmR : (0:ℝ) < m := by exact_mod_cast hm
  have hD : 0≤computedFreimanModelRatio C := by unfold computedFreimanModelRatio; positivity
  have hs := pow_le_pow_left₀ (Nat.cast_nonneg p) hpm 2
  have hf : 16*(p:ℝ)^2/(m:ℝ)^2≤16*(computedFreimanModelRatio C)^2 := by
    apply (div_le_iff₀ (sq_pos_of_pos hmR)).mpr
    nlinarith
  have hceil := Nat.le_ceil (16*(computedFreimanModelRatio C)^2)
  unfold computedFreimanRankBound
  exact_mod_cast (show (r:ℝ)≤(⌈16*(computedFreimanModelRatio C)^2⌉₊:ℝ)+1 by linarith)

end Optss
