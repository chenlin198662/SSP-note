import SubsetSum.RandomizedFreimanVerified
import SubsetSum.RandomizedSignedBudgetVerified
import SubsetSum.StoredFreimanVerified
import SubsetSum.JohnVerified
import SubsetSum.BinaryScalarVerified
import SubsetSum.BoundedIPBinaryTotalInput
import SubsetSum.BinarySection11Verified
import SubsetSum.BinarySection11TotalInput
import SubsetSum.BinarySection11Complete
import SubsetSum.VectorBinaryVerified
import SubsetSum.VectorBinaryRuntime
import SubsetSum.BinaryRandomizedSubsetSumVerified

set_option Elab.async false
set_option pp.fullNames true

#check SubsetSum.RandomizedFreimanVerified.constructiveFreiman
#print axioms SubsetSum.RandomizedFreimanVerified.constructiveFreiman

#check SubsetSum.RandomizedSignedBudgetVerified.constructiveSignedBudget
#print axioms SubsetSum.RandomizedSignedBudgetVerified.constructiveSignedBudget

#check SubsetSum.StoredFreimanVerified.constructiveFreiman
#print axioms SubsetSum.StoredFreimanVerified.constructiveFreiman

#check SubsetSum.JohnVerified.constructiveJohn
#print axioms SubsetSum.JohnVerified.constructiveJohn

#check SubsetSum.BinaryScalarVerified.constructiveSubsetSum
#print axioms SubsetSum.BinaryScalarVerified.constructiveSubsetSum

#check SubsetSum.BinaryScalarVerified.constructiveSubsetSum_positive
#print axioms SubsetSum.BinaryScalarVerified.constructiveSubsetSum_positive

#check SubsetSum.BoundedIPBinaryVerified.exists_backend
#print axioms SubsetSum.BoundedIPBinaryVerified.exists_backend

#check SubsetSum.BoundedIPBinaryTotalInput.exists_backend
#print axioms SubsetSum.BoundedIPBinaryTotalInput.exists_backend

#check SubsetSum.BoundedIPBinaryTotalInput.exists_backend_all
#print axioms SubsetSum.BoundedIPBinaryTotalInput.exists_backend_all

#check SubsetSum.BinarySection11Verified.exists_bounded_witness
#print axioms SubsetSum.BinarySection11Verified.exists_bounded_witness

#check SubsetSum.BinarySection11Verified.exists_objective
#print axioms SubsetSum.BinarySection11Verified.exists_objective

#check SubsetSum.BinarySection11Verified.exists_interval
#print axioms SubsetSum.BinarySection11Verified.exists_interval

#check SubsetSum.BinarySection11Verified.exists_cardinality
#print axioms SubsetSum.BinarySection11Verified.exists_cardinality

#check SubsetSum.BinarySection11Verified.exists_partition
#print axioms SubsetSum.BinarySection11Verified.exists_partition

#check SubsetSum.BinarySection11Verified.exists_discrepancy
#print axioms SubsetSum.BinarySection11Verified.exists_discrepancy

#check SubsetSum.BinarySection11TotalInput.exists_bounded_witness
#print axioms SubsetSum.BinarySection11TotalInput.exists_bounded_witness

#check SubsetSum.BinarySection11TotalInput.exists_objective
#print axioms SubsetSum.BinarySection11TotalInput.exists_objective

#check SubsetSum.BinarySection11TotalInput.exists_interval
#print axioms SubsetSum.BinarySection11TotalInput.exists_interval

#check SubsetSum.BinarySection11TotalInput.exists_cardinality
#print axioms SubsetSum.BinarySection11TotalInput.exists_cardinality

#check SubsetSum.BinarySection11TotalInput.exists_partition
#print axioms SubsetSum.BinarySection11TotalInput.exists_partition

#check SubsetSum.BinarySection11TotalInput.exists_discrepancy
#print axioms SubsetSum.BinarySection11TotalInput.exists_discrepancy

#check SubsetSum.VectorBinaryVerified.exists_solver
#print axioms SubsetSum.VectorBinaryVerified.exists_solver

#check SubsetSum.VectorBinaryVerified.exists_list_solver
#print axioms SubsetSum.VectorBinaryVerified.exists_list_solver

#check SubsetSum.BinaryRandomizedSubsetSumVerified.constructiveRandomizedSubsetSum
#print axioms SubsetSum.BinaryRandomizedSubsetSumVerified.constructiveRandomizedSubsetSum

#check SubsetSum.BinaryRandomizedSubsetSumVerified.constructiveRandomizedSubsetSum_positive
#print axioms SubsetSum.BinaryRandomizedSubsetSumVerified.constructiveRandomizedSubsetSum_positive

#check SubsetSum.BinaryRandomizedSubsetSumVerified.constructiveRandomizedSetSubsetSum
#print axioms SubsetSum.BinaryRandomizedSubsetSumVerified.constructiveRandomizedSetSubsetSum

#check SubsetSum.BinaryRandomizedSubsetSumVerified.badSeeds_eq_empty
#print axioms SubsetSum.BinaryRandomizedSubsetSumVerified.badSeeds_eq_empty

#check SubsetSum.BinaryRandomizedSubsetSumVerified.failureRatio_zero
#print axioms SubsetSum.BinaryRandomizedSubsetSumVerified.failureRatio_zero

#check SubsetSum.BinaryRandomizedSubsetSumVerified.unitCapacity_feasible
#print axioms SubsetSum.BinaryRandomizedSubsetSumVerified.unitCapacity_feasible

#check SubsetSum.BinaryRandomizedSubsetSumVerified.constructiveRandomizedProgram
#print axioms SubsetSum.BinaryRandomizedSubsetSumVerified.constructiveRandomizedProgram

#check SubsetSum.VectorBinaryRuntime.exists_solver
#print axioms SubsetSum.VectorBinaryRuntime.exists_solver

#check SubsetSum.VectorBinaryRuntime.exists_list_solver
#print axioms SubsetSum.VectorBinaryRuntime.exists_list_solver

#check SubsetSum.BinarySection11Complete.exists_bounded_witness
#print axioms SubsetSum.BinarySection11Complete.exists_bounded_witness

#check SubsetSum.BinarySection11Complete.exists_objective
#print axioms SubsetSum.BinarySection11Complete.exists_objective

#check SubsetSum.BinarySection11Complete.exists_interval
#print axioms SubsetSum.BinarySection11Complete.exists_interval

#check SubsetSum.BinarySection11Complete.exists_cardinality
#print axioms SubsetSum.BinarySection11Complete.exists_cardinality

#check SubsetSum.BinarySection11Complete.exists_partition
#print axioms SubsetSum.BinarySection11Complete.exists_partition

#check SubsetSum.BinarySection11Complete.exists_discrepancy
#print axioms SubsetSum.BinarySection11Complete.exists_discrepancy

