import Optss.BitListIntegerOperations

/-! Measure the actual stored signed input, with operand-width charges for
every counter increment and comparison. The magnitude digits are traversed;
no arbitrary-precision coefficient is treated as a unit-cost machine word. -/
namespace ConvolutionDraft.InputMeasure
open Optss

def count {α : Type} : List α → ℕ × ℕ
  | [] => (0,1)
  | _::xs =>
      let out := count xs
      (out.1+1,out.2+2*out.1.size+6)

theorem count_value {α : Type} (xs : List α) : (count xs).1=xs.length := by
  induction xs <;> simp [count, *]

theorem count_work {α : Type} (xs : List α) (N : ℕ) (h : xs.length≤N) :
    (count xs).2≤1+xs.length*(2*N.size+6) := by
  induction xs with
  | nil => simp [count]
  | cons x xs ih =>
      have ht : xs.length≤N := by simpa using (Nat.le_trans (Nat.le_succ xs.length) h)
      have hi := ih ht
      have hs := Nat.size_le_size ht
      simp only [count,count_value,List.length_cons]
      nlinarith

structure Result where
  length : ℕ
  bits : ℕ
  work : ℕ

def run : List BitListInteger → Result
  | [] => ⟨0,0,1⟩
  | z::zs =>
      let tail := run zs
      let digits := count z.digits
      ⟨tail.length+1,if tail.bits≤digits.1 then digits.1 else tail.bits,
        tail.work+digits.2+2*tail.length.size+tail.bits.size+digits.1.size+10⟩

theorem run_length (xs : List BitListInteger) : (run xs).length=xs.length := by
  induction xs <;> simp [run, *]

theorem run_bits_cons (x : BitListInteger) (xs : List BitListInteger) :
    (run (x::xs)).bits=max (run xs).bits x.digits.length := by
  simp only [run,count_value]
  split_ifs with h
  · exact (max_eq_right h).symm
  · exact (max_eq_left (by omega)).symm

theorem run_bits_bound (xs : List BitListInteger) (B : ℕ)
    (hx : ∀x∈xs,x.digits.length≤B) : (run xs).bits≤B := by
  induction xs with
  | nil => simp [run]
  | cons x xs ih =>
      rw [run_bits_cons]
      exact max_le (ih (fun z hz => hx z (List.mem_cons_of_mem _ hz))) (hx x List.mem_cons_self)

theorem run_bits_covers (xs : List BitListInteger) :
    ∀x∈xs,x.digits.length≤(run xs).bits := by
  induction xs with
  | nil => simp
  | cons x xs ih =>
      intro z hz
      rw [run_bits_cons]
      rcases List.mem_cons.mp hz with rfl | hz
      · exact le_max_right _ _
      · exact (ih z hz).trans (le_max_left _ _)

theorem run_work (xs : List BitListInteger) (B L : ℕ)
    (hx : ∀x∈xs,x.digits.length≤B) (hL : xs.length≤L) :
    (run xs).work≤1+xs.length*(B+1)*(2*L.size+4*B.size+17) := by
  induction xs with
  | nil => simp [run]
  | cons x xs ih =>
      have hxB := hx x List.mem_cons_self
      have htail := fun z hz => hx z (List.mem_cons_of_mem _ hz)
      have ht : xs.length≤L := by simpa using (Nat.le_trans (Nat.le_succ xs.length) hL)
      have hw := ih htail ht
      have hd := count_work x.digits B hxB
      have hb := Nat.size_le_size (run_bits_bound xs B htail)
      have hdB := Nat.size_le_size hxB
      have hc := Nat.size_le_size ht
      have hdwork : (count x.digits).2≤1+B*(2*B.size+6) :=
        hd.trans (by gcongr)
      simp only [run,run_length,count_value,List.length_cons]
      nlinarith

end ConvolutionDraft.InputMeasure
