import ConvolutionDraft.SignedBlockConvolution
import SubsetSum.ExternalCostContracts

namespace ConvolutionDraft.SignedBudget
open Optss Polynomial SubsetSum.ExternalCostContracts

noncomputable def factorPolynomial : Polynomial ℕ :=
  let n : Polynomial ℕ := X
  let p := 5*n+12
  let b := 2*(n*(p+6)+3)+1
  3*(2*(320*(n+3)^2+4194304*(n+p+73)^2*(8192*(n+p+73)^4+1)^3+16)+
    4*(p+3)+4+576*(n+1)*(n*(p+6)+b+3)^2)+
    512*(n*(p+6)+4)^2+14+1048576*(3*n*(p+6)+10)^3+
    64*(n+1)*(p+3)+72

theorem factor_eval (n : ℕ) : factorPolynomial.eval n=listBooleanConvolutionWorkFactor n := by
  simp [factorPolynomial,listBooleanConvolutionWorkFactor,listSupportFFTWorkFactor,dyadicDFTPrecision]

def depth (B L : ℕ) : List Bool :=
  List.replicate ((NaturalBlockConvolution.width B L*L).size) false

theorem depth_fits (B L : ℕ) :
    NaturalBlockConvolution.width B L*L≤2^(depth B L).length := by
  simp only [depth,List.length_replicate]
  exact (Nat.lt_size_self _).le

theorem pow_size_le_twice (n : ℕ) (hn : 0<n) : 2^n.size≤2*n := by
  have hs : 0<n.size := Nat.size_pos.mpr hn
  have hp : 2^(n.size-1)≤n := Nat.lt_size.mp (by omega)
  have he : n.size=(n.size-1)+1 := by omega
  rw [he,pow_succ]
  omega

noncomputable def preparedPolynomial : Polynomial ℕ :=
  1000+16*(factorPolynomial.comp (X+2)+7*(X+3)+17)

theorem work_polynomial (B L : ℕ) (hL : 0<L) (xs ys : List BitListInteger)
    (hlen : xs.length+ys.length≤L) :
    SignedBlockConvolution.work (depth B L) (NaturalBlockConvolution.width B L) L xs ys≤
      (L*(B+L.size+1))*preparedPolynomial.eval (L*(B+L.size+1)+1).size := by
  let S := L*(B+L.size+1)
  let w := NaturalBlockConvolution.width B L
  let n := (depth B L).length
  let z := (S+1).size
  have hnEq : n=(w*L).size := by simp [n,depth,w]
  have hS : 0<S := by dsimp [S]; positivity
  have hw : w≤2*(B+L.size+1) := by dsimp [w,NaturalBlockConvolution.width]; omega
  have hwpos : 0<w := by dsimp [w,NaturalBlockConvolution.width]; omega
  have hwl : w*L≤2*S := by dsimp [S]; nlinarith
  have hpow : 2^n≤4*S := by
    have h := pow_size_le_twice (w*L) (Nat.mul_pos hwpos hL)
    rw [hnEq]
    omega
  have hn : n≤z+2 := by
    have hs := Nat.size_le_size hwl
    have hm := nat_mul_size_le 2 S
    have hmono : S.size≤(S+1).size := Nat.size_le_size (by omega)
    rw [hnEq]
    change (w*L).size≤(S+1).size+2
    have htwo : (2:ℕ).size=2 := by simpa using (Nat.size_pow (n:=1))
    rw [htwo] at hm
    omega
  have hf : listBooleanConvolutionWorkFactor n≤factorPolynomial.eval (z+2) := by
    rw [factor_eval]
    exact listBooleanConvolutionWorkFactor_mono hn
  have hactual := SignedBlockConvolution.work_bound (depth B L) w L xs ys
  have hlinear : (xs.length+ys.length)*(16*w+24)+L*(120*w+320)+72≤1000*S := by
    have hm := Nat.mul_le_mul_right (16*w+24) hlen
    dsimp [S]
    nlinarith
  have hfft : 4*2^n*(listBooleanConvolutionWorkFactor n+7*(n+1)+17)≤
      16*S*(factorPolynomial.eval (z+2)+7*(z+3)+17) := by
    have hfactor : listBooleanConvolutionWorkFactor n+7*(n+1)+17≤
        factorPolynomial.eval (z+2)+7*(z+3)+17 := by omega
    calc
      _≤4*(4*S)*(factorPolynomial.eval (z+2)+7*(z+3)+17) :=
        Nat.mul_le_mul (Nat.mul_le_mul_left 4 hpow) hfactor
      _=_ := by ring
  change _≤S*preparedPolynomial.eval z
  simp only [preparedPolynomial,Polynomial.eval_add,Polynomial.eval_mul,
    Polynomial.eval_ofNat,Polynomial.eval_comp,Polynomial.eval_X]
  change SignedBlockConvolution.work (depth B L) w L xs ys≤_
  change SignedBlockConvolution.work (depth B L) w L xs ys≤
    (xs.length+ys.length)*(16*w+24)+L*(120*w+320)+
      4*2^n*(listBooleanConvolutionWorkFactor n+7*(n+1)+17)+72 at hactual
  nlinarith

theorem polynomial_monomial (P : Polynomial ℕ) (x : ℕ) (hx : 1≤x) :
    P.eval x≤P.eval 1*x^P.natDegree := by
  rw [Polynomial.eval_eq_sum_range,Polynomial.eval_eq_sum_range]
  simp only [one_pow,mul_one,Finset.sum_mul]
  apply Finset.sum_le_sum
  intro i hi
  exact Nat.mul_le_mul_left _ (Nat.pow_le_pow_right hx
    (by have hh := Finset.mem_range.mp hi; omega))

/-- Exact declared budget shape for the complete signed packing/FFT/extraction
    core. Selecting the measured width/length and copying external array
    representations is intentionally left to the separate source frontend. -/
theorem work_fftBudget (B L : ℕ) (hL : 0<L) (xs ys : List BitListInteger)
    (hlen : xs.length+ys.length≤L) :
    SignedBlockConvolution.work (depth B L) (NaturalBlockConvolution.width B L) L xs ys≤
      fftBudget (preparedPolynomial.eval 1) preparedPolynomial.natDegree L B := by
  have h := work_polynomial B L hL xs ys hlen
  have hp := polynomial_monomial preparedPolynomial (L*(B+L.size+1)+1).size
    (Nat.size_pos.mpr (by omega))
  have hh := Nat.mul_le_mul_left (L*(B+L.size+1)) hp
  unfold fftBudget
  nlinarith

end ConvolutionDraft.SignedBudget
