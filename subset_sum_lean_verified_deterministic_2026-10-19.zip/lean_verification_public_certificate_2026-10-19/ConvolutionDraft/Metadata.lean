import ConvolutionDraft.InputMeasure
import ConvolutionDraft.SignedBudget
import Optss.WordBitEncoding
import Optss.LatticeArithmeticInputBits

/-! Executed metadata for the stored bit-list convolution. Native operands in
this file are lengths, not coefficient magnitudes. Every word operation of
the halving encoder is charged a quadratic bit simulation using its actual
operand-width envelope. Thus WordBitEncoding is not used at unit bit cost. -/
namespace ConvolutionDraft.Metadata
open Optss

def bitLength (n : ℕ) : ℕ × ℕ :=
  let encoded := wordBitEncode n
  let counted := InputMeasure.count encoded.digits
  (counted.1,encoded.work*(n.size+2)^2+counted.2+4)

theorem bitLength_value (n : ℕ) : (bitLength n).1=n.size := by
  simp [bitLength,InputMeasure.count_value,wordBitEncode_digits,Nat.size_eq_bits_len]

theorem size_le_self (n : ℕ) : n.size≤n := Nat.size_le.mpr Nat.lt_two_pow_self

theorem bitLength_work (n : ℕ) : (bitLength n).2≤16*(n.size+3)^3 := by
  have hc := InputMeasure.count_work (wordBitEncode n).digits n.size
    (by simp [wordBitEncode_digits,Nat.size_eq_bits_len])
  have hs := size_le_self n.size
  simp only [wordBitEncode_digits,Nat.size_eq_bits_len] at hc
  simp only [bitLength,wordBitEncode_work,wordBitEncode_digits]
  nlinarith

structure Result where
  width : ℕ
  depth : List Bool
  work : ℕ

def run (B L : ℕ) : Result :=
  let lenBits := bitLength L
  let w := 2*(B+lenBits.1)+1
  let packed := w*L
  let encoded := wordBitEncode packed
  let E := L.size+B.size+lenBits.1.size+w.size+packed.size+3
  ⟨w,encoded.digits.map (fun _ => false),
    lenBits.2+encoded.work*(packed.size+2)^2+16*E^2+2*encoded.digits.length+8⟩

theorem run_width (B L : ℕ) : (run B L).width=NaturalBlockConvolution.width B L := by
  simp [run,bitLength_value,NaturalBlockConvolution.width]

theorem run_depth (B L : ℕ) : (run B L).depth=SignedBudget.depth B L := by
  simp [run,bitLength_value,wordBitEncode_digits,List.map_const',Nat.size_eq_bits_len,
    SignedBudget.depth,NaturalBlockConvolution.width]

def budget (G : ℕ) : ℕ :=
  16*(G+3)^3+(16*G+2)*(2*G+2)^2+16*(6*G+3)^2+4*G+8

theorem run_work (B L : ℕ) : (run B L).work≤budget (L.size+B.size+8) := by
  let G := L.size+B.size+8
  let w := NaturalBlockConvolution.width B L
  let packed := w*L
  have hs := size_le_self L.size
  have ha := nat_add_size_le_sum B L.size
  have hm := nat_mul_size_le 2 (B+L.size)
  have hlast := nat_add_size_le_sum (2*(B+L.size)) 1
  have htwo : (2:ℕ).size=2 := by simpa using (Nat.size_pow (n:=1))
  simp only [htwo,Nat.size_one] at hm hlast
  have hw : w.size≤G := by dsimp [w,NaturalBlockConvolution.width,G]; omega
  have hpack := nat_mul_size_le w L
  have hp : packed.size≤2*G := by dsimp [packed,G] at *; omega
  have hlen : L.size≤G := by dsimp [G]; omega
  have hE : L.size+B.size+L.size.size+w.size+packed.size+3≤6*G+3 := by
    dsimp [G] at *
    omega
  have hb := bitLength_work L
  have hb' : (bitLength L).2≤16*(G+3)^3 := hb.trans (by gcongr)
  have he : (wordBitEncode packed).work*(packed.size+2)^2≤(16*G+2)*(2*G+2)^2 := by
    rw [wordBitEncode_work]
    exact Nat.mul_le_mul (by omega) (Nat.pow_le_pow_left (by omega) 2)
  have hmeta : 16*(L.size+B.size+L.size.size+w.size+packed.size+3)^2≤16*(6*G+3)^2 := by
    gcongr
  simp only [run,bitLength_value,wordBitEncode_digits,Nat.size_eq_bits_len]
  change (bitLength L).2+(wordBitEncode packed).work*(packed.size+2)^2+
    16*(L.size+B.size+L.size.size+w.size+packed.size+3)^2+2*packed.size+8≤budget G
  dsimp only [budget]
  omega

end ConvolutionDraft.Metadata
