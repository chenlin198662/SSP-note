import ConvolutionDraft.CanonicalOutput

/-! Array boundary for signed binary storage. `storedRun` consumes actual
signed Boolean words, and `storedWork` charges their scans, copies, metadata,
FFT and extraction. `encode`/`decode` are the mathematical representation
views used by the existing Array Int contract; they are not unit-cost
arbitrary-integer instructions. In particular no native Lean running-time
claim is made for evaluating those views or the extracted Lean program. -/
namespace ConvolutionDraft.ArraySource
open Optss SubsetSum.ExternalCostContracts

def storedRun (xs ys : Array BitListInteger) : Array BitListInteger :=
  (CanonicalOutput.run xs.toList ys.toList).toArray

def storedWork (xs ys : Array BitListInteger) : ℕ :=
  CanonicalOutput.work xs.toList ys.toList

def encode (xs : Array ℤ) : Array BitListInteger := xs.map integerBitRepresentation
def decode (xs : Array BitListInteger) : Array ℤ := xs.map BitListInteger.value

def run (xs ys : Array ℤ) : Array ℤ := decode (storedRun (encode xs) (encode ys))
def bitCost (xs ys : Array ℤ) : ℕ := storedWork (encode xs) (encode ys)

theorem decode_encode (xs : Array ℤ) : decode (encode xs)=xs := by
  simp [decode,encode,Array.map_map,Function.comp_def,integerBitRepresentation_value]

theorem storedRun_size (xs ys : Array BitListInteger) :
    (storedRun xs ys).size=xs.size+ys.size := by
  simp [storedRun,CanonicalOutput.run_length]

theorem output_size (xs ys : Array ℤ) : (run xs ys).size ≤ xs.size+ys.size := by
  simp [run,decode,storedRun_size,encode]

theorem stored_correct (xs ys : Array BitListInteger) (i : ℕ) :
    ((decode (storedRun xs ys))[i]?.getD 0)=
      ExecutablePackedConvolution.signedCoefficient (decode xs).toList (decode ys).toList i := by
  simpa only [decode,storedRun,List.map_toArray,Array.toList_map,List.getElem?_toArray,
    CanonicalOutput.run_values,
    ←List.getD_eq_getElem?_getD] using StoredFrontend.run_coeff xs.toList ys.toList i

theorem run_coefficient (xs ys : Array ℤ) (i : ℕ) : ((run xs ys)[i]?.getD 0)=
    ExecutablePackedConvolution.signedCoefficient xs.toList ys.toList i := by
  rw [run,stored_correct,decode_encode,decode_encode]

theorem integerArray_getD (p : Polynomial ℤ) (n : ℕ)
    (hp : p.natDegree < n) (i : ℕ) : ((integerArray p n)[i]?.getD 0)=p.coeff i := by
  by_cases hi : i < n
  · simp only [integerArray,Array.getElem?_ofFn,dif_pos hi,Option.getD_some]
  · rw [Polynomial.coeff_eq_zero_of_natDegree_lt (hp.trans_le (Nat.le_of_not_gt hi))]
    simp only [integerArray,Array.getElem?_ofFn,dif_neg hi,Option.getD_none]

theorem correct (p q : Polynomial ℤ) (n m : ℕ) (hp : p.natDegree < n)
    (hq : q.natDegree < m) (i : ℕ) :
    ((run (integerArray p n) (integerArray q m))[i]?.getD 0)=(p*q).coeff i := by
  rw [run_coefficient,ExecutablePackedConvolution.signedCoefficient,Polynomial.coeff_mul]
  apply Finset.sum_congr rfl
  intro ab _
  simp only [List.getD_eq_getElem?_getD,Array.getElem?_toList,
    integerArray_getD p n hp,integerArray_getD q m hq]

theorem encode_width (xs : Array ℤ) (B : ℕ) (hx : ∀z∈xs,z.natAbs.size ≤ B) :
    ∀z∈(encode xs).toList,z.digits.length ≤ B := by
  intro z hz
  simp only [encode,Array.toList_map] at hz
  obtain ⟨a,ha,rfl⟩ := List.mem_map.mp hz
  rw [integerBitRepresentation_length]
  exact hx a (by simpa using ha)

theorem cost_arrays (xs ys : Array ℤ) (B : ℕ) (hL : 0 < xs.size+ys.size)
    (hx : ∀z∈xs,z.natAbs.size ≤ B) (hy : ∀z∈ys,z.natAbs.size ≤ B) :
    bitCost xs ys ≤ fftBudget (CanonicalOutput.polynomial.eval 1)
      CanonicalOutput.polynomial.natDegree (xs.size+ys.size) B := by
  have h := CanonicalOutput.work_fftBudget (encode xs).toList (encode ys).toList B
    (encode_width xs B hx) (encode_width ys B hy) (by simpa [encode] using hL)
  simpa only [bitCost,storedWork,Array.length_toList,encode,Array.size_map] using h

theorem cost (p q : Polynomial ℤ) (n m B : ℕ) (hp : p.natDegree < n)
    (hq : q.natDegree < m) (hB : ∀i,(p.coeff i).natAbs.size ≤ B)
    (hC : ∀i,(q.coeff i).natAbs.size ≤ B) :
    bitCost (integerArray p n) (integerArray q m) ≤ 
      fftBudget (CanonicalOutput.polynomial.eval 1) CanonicalOutput.polynomial.natDegree (n+m) B := by
  have h := cost_arrays (integerArray p n) (integerArray q m) B
    (by simp only [integerArray_size]; omega)
    (by
      intro z hz
      simp only [integerArray,Array.mem_ofFn] at hz
      obtain ⟨i,rfl⟩ := hz
      exact hB i)
    (by
      intro z hz
      simp only [integerArray,Array.mem_ofFn] at hz
      obtain ⟨i,rfl⟩ := hz
      exact hC i)
  simpa only [integerArray_size] using h

/-- No external convolution correctness or work assumption is supplied. The
only representation convention is canonical signed Boolean storage, made
explicit by `source_realized` below. -/
noncomputable def source : ExactIntegerConvolution where
  run := run
  bitCost := bitCost
  constant := CanonicalOutput.polynomial.eval 1
  logPower := CanonicalOutput.polynomial.natDegree
  output_size := output_size
  correct := correct
  cost := cost

theorem source_realized (xs ys : Array ℤ) :
    source.run xs ys=decode (storedRun (encode xs) (encode ys)) ∧
    source.bitCost xs ys=storedWork (encode xs) (encode ys) := ⟨rfl,rfl⟩

def Canonical (xs : Array BitListInteger) : Prop :=
  ∀z∈xs,integerBitRepresentation z.value=z

theorem encode_canonical (xs : Array ℤ) : Canonical (encode xs) := by
  intro z hz
  obtain ⟨a,ha,rfl⟩ := Array.mem_map.mp hz
  simp [integerBitRepresentation_value]

theorem encode_decode (xs : Array BitListInteger) (hx : Canonical xs) :
    encode (decode xs)=xs := by
  simp only [encode,decode,Array.map_map]
  have h := Array.map_congr_left (xs:=xs) (f:=integerBitRepresentation ∘ BitListInteger.value)
    (g:=id) hx
  simpa using h

/-- Actual stored arrays satisfying the ordinary canonical representation
invariant have exactly the specified output and the very same recorded work.
The invariant concerns representation only, not algorithm correctness. -/
theorem source_storage_refinement (xs ys : Array BitListInteger)
    (hx : Canonical xs) (hy : Canonical ys) :
    source.run (decode xs) (decode ys)=decode (storedRun xs ys) ∧
    source.bitCost (decode xs) (decode ys)=storedWork xs ys := by
  dsimp only [source]
  simp only [run,bitCost,encode_decode xs hx,encode_decode ys hy,and_self]

theorem stored_output_canonical (xs ys : Array BitListInteger) : Canonical (storedRun xs ys) := by
  intro z hz
  apply CanonicalOutput.run_canonical xs.toList ys.toList z
  simpa [storedRun,Array.mem_def] using hz

theorem representation_independent (xs ys : Array BitListInteger) :
    run (decode xs) (decode ys)=decode (storedRun xs ys) := by
  apply Array.ext
  · simp [run,decode,storedRun_size,encode]
  · intro i h1 h2
    have hh := (run_coefficient (decode xs) (decode ys) i).trans (stored_correct xs ys i).symm
    simpa only [Array.getElem?_eq_getElem h1,Array.getElem?_eq_getElem h2,Option.getD_some] using hh

end ConvolutionDraft.ArraySource
