import ConvolutionDraft.PaddedBinaryMultiplication
import Optss.ExecutablePackedConvolution

namespace ConvolutionDraft.NaturalBlockConvolution
open Optss
open Optss.ExecutablePackedConvolution (model)

def values (xs : List (List Bool)) : List ℕ := xs.map binaryDigitsValue

def width (B L : ℕ) : ℕ := 2*(B+L.size)+1

theorem width_ge (B L : ℕ) : B≤width B L := by unfold width; omega

theorem pack_model (w : ℕ) (xs : List (List Bool))
    (hx : ∀x∈xs,x.length≤w) :
    binaryDigitsValue (FixedWidthBlocks.pack w xs)=(model (values xs)).eval (2^w) := by
  rw [FixedWidthBlocks.pack_value w xs hx,ExecutablePackedConvolution.model_eval]
  induction xs with
  | nil => rfl
  | cons x xs ih =>
      simp only [values,List.map_cons,FixedWidthBlocks.coefficientValue,
        ExecutablePackedConvolution.pack]
      rw [ih (fun y hy => hx y (List.mem_cons_of_mem _ hy))]
      rfl

theorem values_sum_le (B L : ℕ) (xs : List (List Bool))
    (hx : ∀x∈xs,x.length≤B) (hL : xs.length≤L) : (values xs).sum≤L*2^B := by
  have hs := List.sum_le_card_nsmul (values xs) (2^B) (by
    intro z hz
    obtain ⟨word,hw,rfl⟩ := List.mem_map.mp hz
    exact (binaryDigitsValue_lt_pow word).le.trans (Nat.pow_le_pow_right (by decide) (hx word hw)))
  simp only [values,List.length_map,nsmul_eq_mul] at hs
  exact hs.trans (Nat.mul_le_mul_right _ hL)

theorem product_coeff_bound (B L : ℕ) (xs ys : List (List Bool))
    (hx : ∀x∈xs,x.length≤B) (hy : ∀y∈ys,y.length≤B)
    (hL : xs.length+ys.length≤L) (i : ℕ) :
    (model (values xs)*model (values ys)).coeff i<2^(width B L) := by
  have hc := ExecutablePackedConvolution.coeff_le_eval_one (model (values xs)*model (values ys)) i
  rw [Polynomial.eval_mul,ExecutablePackedConvolution.model_eval,
    ExecutablePackedConvolution.model_eval,ExecutablePackedConvolution.pack_one,
    ExecutablePackedConvolution.pack_one] at hc
  have hsx := values_sum_le B L xs hx (by omega)
  have hsy := values_sum_le B L ys hy (by omega)
  have hLpow := (Nat.lt_size_self L).le
  have hp : (model (values xs)*model (values ys)).coeff i≤2^(2*(B+L.size)) := by
    calc
      _≤(L*2^B)*(L*2^B) := hc.trans (Nat.mul_le_mul hsx hsy)
      _≤(2^L.size*2^B)*(2^L.size*2^B) := by gcongr
      _=2^(2*(B+L.size)) := by rw [←pow_add,←pow_add]; congr 1; omega
  exact hp.trans_lt (by unfold width; exact Nat.pow_lt_pow_right (by decide) (by omega))

def run (depth : List Bool) (w k : ℕ) (xs ys : List (List Bool)) : List (List Bool) :=
  FixedWidthBlocks.unpack w k (PaddedBinaryMultiplication.run depth
    (FixedWidthBlocks.pack w xs) (FixedWidthBlocks.pack w ys))

def work (depth : List Bool) (w k : ℕ) (xs ys : List (List Bool)) : ℕ :=
  FixedWidthBlocks.packWork w xs+FixedWidthBlocks.packWork w ys+
    PaddedBinaryMultiplication.work depth (FixedWidthBlocks.pack w xs) (FixedWidthBlocks.pack w ys)+
    FixedWidthBlocks.unpackWork w k+4

theorem run_coeff (depth : List Bool) (B L k : ℕ) (xs ys : List (List Bool))
    (hx : ∀x∈xs,x.length≤B) (hy : ∀y∈ys,y.length≤B)
    (hL : xs.length+ys.length≤L) (hpad : width B L*L≤2^depth.length)
    (i : ℕ) (hi : i<k) :
    ((run depth (width B L) k xs ys).map binaryDigitsValue).getD i 0 =
      (model (values xs)*model (values ys)).coeff i := by
  have hpx := fun x hx' => (hx x hx').trans (width_ge B L)
  have hpy := fun y hy' => (hy y hy').trans (width_ge B L)
  have hn : (FixedWidthBlocks.pack (width B L) xs).length+
      (FixedWidthBlocks.pack (width B L) ys).length≤2^depth.length := by
    rw [FixedWidthBlocks.pack_length,FixedWidthBlocks.pack_length]
    exact (by nlinarith : width B L*xs.length+width B L*ys.length≤width B L*L).trans hpad
  rw [run,FixedWidthBlocks.unpack_getD _ _ _ _ hi,PaddedBinaryMultiplication.run_value _ _ _ hn,
    pack_model _ xs hpx,pack_model _ ys hpy]
  exact packed_convolution_of_coeff_lt _ _ _ (pow_pos (by decide) _)
    (product_coeff_bound B L xs ys hx hy hL) i

theorem work_bound (depth : List Bool) (w k : ℕ) (xs ys : List (List Bool)) :
    work depth w k xs ys≤
      (xs.length+ys.length)*(4*w+4)+k*(7*w+6)+
      2^depth.length*(listBooleanConvolutionWorkFactor depth.length+7*(depth.length+1)+17)+14 := by
  have hp := PaddedBinaryMultiplication.work_bound depth
    (FixedWidthBlocks.pack w xs) (FixedWidthBlocks.pack w ys)
  simp only [work,FixedWidthBlocks.packWork_eq,FixedWidthBlocks.unpackWork_eq]
  nlinarith

end ConvolutionDraft.NaturalBlockConvolution
