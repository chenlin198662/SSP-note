import ConvolutionDraft.CyclicNoAlias
import ConvolutionDraft.FixedWidthBlocks

namespace ConvolutionDraft.PaddedBinaryMultiplication
open Optss

def pad (N : ℕ) (xs : List Bool) : List Bool := FixedWidthBlocks.prepend N xs []

theorem pad_length (N : ℕ) (xs : List Bool) : (pad N xs).length=N := by
  simp [pad,FixedWidthBlocks.prepend_length]

theorem pad_value (N : ℕ) (xs : List Bool) (hx : xs.length≤N) :
    binaryDigitsValue (pad N xs)=binaryDigitsValue xs := by
  simp [pad,FixedWidthBlocks.prepend_value N xs [] hx,binaryDigitsValue]

theorem pad_getD (N : ℕ) (xs : List Bool) (i : ℕ) (hi : i<N) :
    (pad N xs).getD i false=xs.getD i false := by
  induction N generalizing xs i with
  | zero => omega
  | succ N ih =>
      cases i with
      | zero => cases xs <;> simp [pad,FixedWidthBlocks.prepend]
      | succ i =>
          have ht := ih xs.tail i (by omega)
          cases xs <;> simpa [pad,FixedWidthBlocks.prepend] using ht

def run (depth xs ys : List Bool) : List Bool :=
  NormalizedBooleanConvolution.run depth (pad (2^depth.length) xs) (pad (2^depth.length) ys)

def work (depth xs ys : List Bool) : ℕ :=
  2*FixedWidthBlocks.prependWork (2^depth.length)+3+
    NormalizedBooleanConvolution.work depth (pad (2^depth.length) xs) (pad (2^depth.length) ys)

theorem run_value (depth xs ys : List Bool) (h : xs.length+ys.length≤2^depth.length) :
    binaryDigitsValue (run depth xs ys)=binaryDigitsValue xs*binaryDigitsValue ys := by
  obtain ⟨F,hF⟩ := fourier_exists_vector (pad (2^depth.length) xs) _ (pad_length _ _)
  obtain ⟨G,hG⟩ := fourier_exists_vector (pad (2^depth.length) ys) _ (pad_length _ _)
  have hsupport (zs : List Bool) (Z : Vector Bool (2^depth.length))
      (hZ : pad (2^depth.length) zs=List.ofFn Z.get) :
      ∀x,cyclicBooleanNat depth.length Z x≠0 → x.val<zs.length := by
    intro x hx
    by_contra hn
    have hz := pad_getD (2^depth.length) zs x.val x.val_lt
    rw [hZ] at hz
    have hzero : zs.getD x.val false=false := List.getD_eq_default zs false (by omega)
    have he : Z.get (cyclicArrayIndex depth.length x)=false := by
      simpa only [List.getD_eq_getElem?_getD,List.getElem?_ofFn,x.val_lt,↓reduceDIte,
        Option.getD_some,cyclicArrayIndex] using hz.trans hzero
    simp [cyclicBooleanNat,he] at hx
  have hc := CyclicNoAlias.normalized_product depth F G xs.length ys.length h
    (hsupport xs F hF.symm) (hsupport ys G hG.symm)
  rw [hF,hG,pad_value _ xs (by omega),pad_value _ ys (by omega)] at hc
  exact hc

theorem work_bound (depth xs ys : List Bool) :
    work depth xs ys≤2^depth.length*
      (listBooleanConvolutionWorkFactor depth.length+7*(depth.length+1)+17)+7 := by
  have h := NormalizedBooleanConvolution.work_bound depth
    (pad (2^depth.length) xs) (pad (2^depth.length) ys) (pad_length _ _) (pad_length _ _)
  dsimp only [work]
  rw [FixedWidthBlocks.prependWork_eq]
  nlinarith

end ConvolutionDraft.PaddedBinaryMultiplication
