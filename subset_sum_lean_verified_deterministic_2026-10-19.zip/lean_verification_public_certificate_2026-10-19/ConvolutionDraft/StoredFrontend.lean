import ConvolutionDraft.Metadata

/-! Stored-input frontend. Lists of signed Boolean words are the executable
representation. Copies traverse every stored bit; semantic integer decoding
appears only in correctness statements. The final control factor provides a
quadratic bit simulation for the bounded length/address words. -/
namespace ConvolutionDraft.StoredFrontend
open Optss

def copyBits : List Bool → List Bool
  | [] => []
  | b::bs => b::copyBits bs

def copy : List BitListInteger → List BitListInteger
  | [] => []
  | z::zs => ⟨z.negative,copyBits z.digits⟩::copy zs

def copyWork : List BitListInteger → ℕ
  | [] => 1
  | z::zs => 4*z.digits.length+8+copyWork zs

theorem copyBits_eq (bs : List Bool) : copyBits bs=bs := by induction bs <;> simp [copyBits, *]
theorem copy_eq (xs : List BitListInteger) : copy xs=xs := by
  induction xs with
  | nil => rfl
  | cons z zs ih => cases z; simp [copy,copyBits_eq,ih]

theorem copyWork_bound (xs : List BitListInteger) (B : ℕ)
    (h : ∀z∈xs,z.digits.length ≤ B) : copyWork xs ≤ 1+xs.length*(4*B+8) := by
  induction xs with
  | nil => simp [copyWork]
  | cons z zs ih =>
      have hz := h z List.mem_cons_self
      have ht := ih (fun x hx => h x (List.mem_cons_of_mem _ hx))
      simp only [copyWork,List.length_cons]
      nlinarith

def measuredBits (xs ys : List BitListInteger) : ℕ :=
  max (InputMeasure.run xs).bits (InputMeasure.run ys).bits

def core (xs ys : List BitListInteger) : List BitListInteger :=
  let mx := InputMeasure.run xs
  let my := InputMeasure.run ys
  let L := mx.length+my.length
  let meta := Metadata.run (max mx.bits my.bits) L
  SignedBlockConvolution.run meta.depth meta.width L xs ys

def run (xs ys : List BitListInteger) : List BitListInteger :=
  copy (core (copy xs) (copy ys))

def controlBits (B L : ℕ) : ℕ := (SignedBudget.depth B L).length+L.size+B.size+16

def work (xs ys : List BitListInteger) : ℕ :=
  let L := xs.length+ys.length
  let B := measuredBits xs ys
  let meta := Metadata.run B L
  ((InputMeasure.run xs).work+(InputMeasure.run ys).work+meta.work+
    SignedBlockConvolution.work meta.depth meta.width L xs ys+
    copyWork xs+copyWork ys+copyWork (core xs ys)+16)*controlBits B L^2

theorem core_eq (xs ys : List BitListInteger) : core xs ys=
    SignedBlockConvolution.run (SignedBudget.depth (measuredBits xs ys) (xs.length+ys.length))
      (NaturalBlockConvolution.width (measuredBits xs ys) (xs.length+ys.length))
      (xs.length+ys.length) xs ys := by
  simp only [core,measuredBits,InputMeasure.run_length,Metadata.run_depth,Metadata.run_width]

theorem run_eq (xs ys : List BitListInteger) : run xs ys=core xs ys := by simp [run,copy_eq]

theorem run_length (xs ys : List BitListInteger) : (run xs ys).length=xs.length+ys.length := by
  rw [run_eq,core_eq,SignedBlockConvolution.run_length]

theorem measured_covers_left (xs ys : List BitListInteger) :
    ∀z∈xs,z.digits.length  ≤  measuredBits xs ys :=
  fun z hz => (InputMeasure.run_bits_covers xs z hz).trans (le_max_left _ _)

theorem measured_covers_right (xs ys : List BitListInteger) :
    ∀z∈ys,z.digits.length  ≤  measuredBits xs ys :=
  fun z hz => (InputMeasure.run_bits_covers ys z hz).trans (le_max_right _ _)

theorem measured_le (xs ys : List BitListInteger) (B : ℕ)
    (hx : ∀z∈xs,z.digits.length ≤ B) (hy : ∀z∈ys,z.digits.length ≤ B) :
    measuredBits xs ys ≤ B := max_le (InputMeasure.run_bits_bound xs B hx)
      (InputMeasure.run_bits_bound ys B hy)

theorem merge_width (as bs cs ds : List (List Bool)) (w : ℕ)
    (ha : ∀z∈as,z.length ≤ w) (hb : ∀z∈bs,z.length ≤ w)
    (hc : ∀z∈cs,z.length ≤ w) (hd : ∀z∈ds,z.length ≤ w) :
    ∀z∈SignedBlocks.merge as bs cs ds,z.digits.length ≤ w+3 := by
  induction as generalizing bs cs ds with
  | nil => simp [SignedBlocks.merge]
  | cons a as ih =>
      cases bs with
      | nil => simp [SignedBlocks.merge]
      | cons b bs =>
        cases cs with
        | nil => simp [SignedBlocks.merge]
        | cons c cs =>
          cases ds with
          | nil => simp [SignedBlocks.merge]
          | cons d ds =>
              intro z hz
              rcases List.mem_cons.mp hz with rfl | hz
              · exact SignedBlocks.mergeRow_width a b c d w (ha _ List.mem_cons_self)
                  (hb _ List.mem_cons_self) (hc _ List.mem_cons_self) (hd _ List.mem_cons_self)
              · exact ih bs cs ds (fun x hx => ha x (List.mem_cons_of_mem _ hx))
                  (fun x hx => hb x (List.mem_cons_of_mem _ hx))
                  (fun x hx => hc x (List.mem_cons_of_mem _ hx))
                  (fun x hx => hd x (List.mem_cons_of_mem _ hx)) z hz

theorem core_width (xs ys : List BitListInteger) : ∀z∈core xs ys,z.digits.length ≤ 
    NaturalBlockConvolution.width (measuredBits xs ys) (xs.length+ys.length)+3 := by
  rw [core_eq]
  dsimp only [SignedBlockConvolution.run]
  apply merge_width
  all_goals exact SignedBlockConvolution.unpack_width _ _ _

theorem coefficient_zero (xs ys : List ℤ) (i : ℕ) (hi : xs.length+ys.length ≤ i) :
    ExecutablePackedConvolution.signedCoefficient xs ys i=0 := by
  unfold ExecutablePackedConvolution.signedCoefficient
  apply Finset.sum_eq_zero
  intro ab hab
  have hab' := Finset.mem_antidiagonal.mp hab
  by_cases ha : ab.1<xs.length
  · have hb : ys.length ≤ ab.2 := by omega
    rw [List.getD_eq_default ys 0 hb,mul_zero]
  · rw [List.getD_eq_default xs 0 (by omega),zero_mul]

theorem run_coeff (xs ys : List BitListInteger) (i : ℕ) :
    ((run xs ys).map BitListInteger.value).getD i 0=
      ExecutablePackedConvolution.signedCoefficient (xs.map BitListInteger.value)
        (ys.map BitListInteger.value) i := by
  by_cases hi : i<xs.length+ys.length
  · rw [run_eq,core_eq]
    exact SignedBlockConvolution.run_coeff _ _ _ _ xs ys
      (measured_covers_left xs ys) (measured_covers_right xs ys) (by omega)
      (SignedBudget.depth_fits _ _) i hi
  · rw [List.getD_eq_default _ 0 (by simp [run_length]; omega),coefficient_zero]
    simp only [List.length_map]
    omega

end ConvolutionDraft.StoredFrontend
