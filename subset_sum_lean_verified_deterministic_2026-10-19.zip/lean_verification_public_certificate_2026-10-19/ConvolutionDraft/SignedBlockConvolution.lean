import ConvolutionDraft.NaturalBlockConvolution
import ConvolutionDraft.SignedBlocks

namespace ConvolutionDraft.SignedBlockConvolution
open Optss SignedBlocks

theorem unpack_length (w k : ℕ) (xs : List Bool) : (FixedWidthBlocks.unpack w k xs).length=k := by
  induction k generalizing xs <;> simp [FixedWidthBlocks.unpack, *]

theorem unpack_width (w k : ℕ) (xs : List Bool) :
    ∀z∈FixedWidthBlocks.unpack w k xs,z.length≤w := by
  induction k generalizing xs with
  | zero => simp [FixedWidthBlocks.unpack]
  | succ k ih =>
      intro z hz
      simp only [FixedWidthBlocks.unpack,List.mem_cons] at hz
      rcases hz with rfl | hz
      · simp [FixedWidthBlocks.split_length]
      · exact ih _ z hz

def run (depth : List Bool) (w k : ℕ) (xs ys : List BitListInteger) : List BitListInteger :=
  let xp := part false xs
  let xn := part true xs
  let yp := part false ys
  let yn := part true ys
  let pp := NaturalBlockConvolution.run depth w k xp yp
  let pn := NaturalBlockConvolution.run depth w k xp yn
  let np := NaturalBlockConvolution.run depth w k xn yp
  let nn := NaturalBlockConvolution.run depth w k xn yn
  merge pp pn np nn

def work (depth : List Bool) (w k : ℕ) (xs ys : List BitListInteger) : ℕ :=
  let xp := part false xs
  let xn := part true xs
  let yp := part false ys
  let yn := part true ys
  let pp := NaturalBlockConvolution.run depth w k xp yp
  let pn := NaturalBlockConvolution.run depth w k xp yn
  let np := NaturalBlockConvolution.run depth w k xn yp
  let nn := NaturalBlockConvolution.run depth w k xn yn
  8*(xs.length+ys.length)+12+
    NaturalBlockConvolution.work depth w k xp yp+
    NaturalBlockConvolution.work depth w k xp yn+
    NaturalBlockConvolution.work depth w k xn yp+
    NaturalBlockConvolution.work depth w k xn yn+mergeWork pp pn np nn

theorem run_length (depth : List Bool) (w k : ℕ) (xs ys : List BitListInteger) :
    (run depth w k xs ys).length=k := by
  dsimp only [run]
  rw [merge_length]
  all_goals simp only [NaturalBlockConvolution.run,unpack_length]

theorem run_coeff (depth : List Bool) (B L k : ℕ) (xs ys : List BitListInteger)
    (hx : ∀z∈xs,z.digits.length≤B) (hy : ∀z∈ys,z.digits.length≤B)
    (hL : xs.length+ys.length≤L) (hpad : NaturalBlockConvolution.width B L*L≤2^depth.length)
    (i : ℕ) (hi : i<k) :
    ((run depth (NaturalBlockConvolution.width B L) k xs ys).map BitListInteger.value).getD i 0 =
      ExecutablePackedConvolution.signedCoefficient (xs.map BitListInteger.value) (ys.map BitListInteger.value) i := by
  have hco (s t : Bool) := NaturalBlockConvolution.run_coeff depth B L k
    (part s xs) (part t ys) (part_width s xs B hx) (part_width t ys B hy)
    (by simpa only [part_length] using hL) hpad i hi
  dsimp only [run]
  rw [merge_getD]
  · rw [hco false false,hco false true,hco true false,hco true true]
    simp only [NaturalBlockConvolution.values,positive_values,negative_values,
      ExecutablePackedConvolution.model_product_coeff]
    exact ExecutablePackedConvolution.signedCoefficient_split _ _ i
  all_goals simp only [NaturalBlockConvolution.run,unpack_length]
  exact hi

theorem work_bound (depth : List Bool) (w k : ℕ) (xs ys : List BitListInteger) :
    work depth w k xs ys≤
      (xs.length+ys.length)*(16*w+24)+k*(120*w+320)+
      4*2^depth.length*(listBooleanConvolutionWorkFactor depth.length+7*(depth.length+1)+17)+72 := by
  have h1 := NaturalBlockConvolution.work_bound depth w k (part false xs) (part false ys)
  have h2 := NaturalBlockConvolution.work_bound depth w k (part false xs) (part true ys)
  have h3 := NaturalBlockConvolution.work_bound depth w k (part true xs) (part false ys)
  have h4 := NaturalBlockConvolution.work_bound depth w k (part true xs) (part true ys)
  simp only [part_length] at h1 h2 h3 h4
  have hm := mergeWork_bound
    (NaturalBlockConvolution.run depth w k (part false xs) (part false ys))
    (NaturalBlockConvolution.run depth w k (part false xs) (part true ys))
    (NaturalBlockConvolution.run depth w k (part true xs) (part false ys))
    (NaturalBlockConvolution.run depth w k (part true xs) (part true ys)) w
    (unpack_width _ _ _) (unpack_width _ _ _) (unpack_width _ _ _) (unpack_width _ _ _)
  simp only [NaturalBlockConvolution.run,unpack_length] at hm
  dsimp only [work]
  simp only [NaturalBlockConvolution.run]
  nlinarith

end ConvolutionDraft.SignedBlockConvolution
