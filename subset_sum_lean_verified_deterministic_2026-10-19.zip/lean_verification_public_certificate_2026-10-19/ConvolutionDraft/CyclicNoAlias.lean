import ConvolutionDraft.NormalizedBooleanConvolution

/-! Ordinary binary multiplication from an exact cyclic count table when the
two input supports do not wrap. All sums here are proof-only interpretations
of the already stored arrays; they are not alternate answer algorithms. -/
namespace ConvolutionDraft.CyclicNoAlias
open Optss
open scoped BigOperators

def indexEquiv (N : ℕ) [NeZero N] : Fin N ≃ ZMod N where
  toFun i := (i.val : ZMod N)
  invFun x := ⟨x.val,x.val_lt⟩
  left_inv i := by apply Fin.ext; exact (ZMod.val_natCast N i.val).trans (Nat.mod_eq_of_lt i.isLt)
  right_inv x := ZMod.natCast_zmod_val x

theorem weighted_ofFn {N : ℕ} (f : Fin N → ℕ) :
    NormalizedBooleanConvolution.weighted (List.ofFn f)=∑i,f i*2^i.val := by
  induction N with
  | zero => simp [NormalizedBooleanConvolution.weighted]
  | succ N ih =>
      rw [List.ofFn_succ,NormalizedBooleanConvolution.weighted,ih,Fin.sum_univ_succ]
      simp only [Fin.val_zero,pow_zero,Nat.mul_one,Fin.val_succ,pow_succ]
      rw [Finset.mul_sum]
      congr 1
      apply Finset.sum_congr rfl
      intro i _
      ring

theorem weighted_bits (xs : List Bool) :
    NormalizedBooleanConvolution.weighted (xs.map Bool.toNat)=binaryDigitsValue xs := by
  induction xs <;> simp [NormalizedBooleanConvolution.weighted,binaryDigitsValue, *,Nat.add_comm]

theorem weighted_cyclic {N : ℕ} [NeZero N] (f : ZMod N → ℕ) :
    NormalizedBooleanConvolution.weighted (List.ofFn (fun i : Fin N => f (i.val : ZMod N)))=
      ∑x,f x*2^x.val := by
  rw [weighted_ofFn]
  apply Fintype.sum_equiv (indexEquiv N)
  intro i
  change f (i.val : ZMod N)*2^i.val=f (i.val : ZMod N)*2^(i.val : ZMod N).val
  rw [ZMod.val_natCast,Nat.mod_eq_of_lt i.isLt]

theorem no_alias {N : ℕ} [NeZero N] (f g : ZMod N → ℕ) (a b : ℕ)
    (hab : a+b≤N) (hf : ∀x,f x≠0 → x.val<a) (hg : ∀x,g x≠0 → x.val<b) :
    (∑x,cyclicNatConvolution f g x*2^x.val)=
      (∑x,f x*2^x.val)*(∑x,g x*2^x.val) := by
  simp only [cyclicNatConvolution,Finset.sum_mul]
  rw [Finset.sum_comm]
  simp only [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro x _
  calc
    (∑k,f x*g (k-x)*2^k.val)=∑y,f x*g y*2^(x+y).val := by
      symm
      apply Fintype.sum_equiv (Equiv.addLeft x)
      intro y
      simp
    _=∑y,(f x*2^x.val)*(g y*2^y.val) := by
      apply Finset.sum_congr rfl
      intro y _
      by_cases hfx : f x=0
      · simp [hfx]
      by_cases hgy : g y=0
      · simp [hgy]
      have hlt : x.val+y.val<N := by have hx := hf x hfx; have hy := hg y hgy; omega
      rw [ZMod.val_add_of_lt hlt,pow_add]
      ring

theorem boolean_weight (n : ℕ) (f : Vector Bool (2^n)) :
    (∑x,cyclicBooleanNat n f x*2^x.val)=binaryDigitsValue (List.ofFn f.get) := by
  rw [←weighted_cyclic]
  have he : (fun i : Fin (2^n) => cyclicBooleanNat n f (i.val : ZMod (2^n)))=
      fun i => (f.get i).toNat := by
    funext i
    unfold cyclicBooleanNat
    congr 2
    apply Fin.ext
    simp [cyclicArrayIndex,Nat.mod_eq_of_lt i.isLt]
  rw [he]
  simpa only [List.map_ofFn,Function.comp_def] using weighted_bits (List.ofFn f.get)

theorem normalized_product (depth : List Bool) (f g : Vector Bool (2^depth.length))
    (a b : ℕ) (hab : a+b≤2^depth.length)
    (hf : ∀x,cyclicBooleanNat depth.length f x≠0 → x.val<a)
    (hg : ∀x,cyclicBooleanNat depth.length g x≠0 → x.val<b) :
    binaryDigitsValue (NormalizedBooleanConvolution.run depth (List.ofFn f.get) (List.ofFn g.get))=
      binaryDigitsValue (List.ofFn f.get)*binaryDigitsValue (List.ofFn g.get) := by
  rw [NormalizedBooleanConvolution.run_value,weighted_cyclic,
    no_alias _ _ a b hab hf hg,boolean_weight,boolean_weight]

end ConvolutionDraft.CyclicNoAlias
