import ConvolutionDraft.CarryNormalization
import Optss.PackedDigits

/-! Fixed-width little-endian block construction and extraction. Every loop
visits exactly the requested number of bits; no packed Nat arithmetic computes
the answer. Nat arithmetic occurs only in semantic specifications and counters. -/
namespace ConvolutionDraft.FixedWidthBlocks
open Optss

/-- Copy a width-w padded block in front of an already prepared tail. -/
def prepend : ℕ → List Bool → List Bool → List Bool
  | 0, _, tail => tail
  | w+1, xs, tail => xs.headD false :: prepend w xs.tail tail

def prependWork : ℕ → ℕ
  | 0 => 1
  | w+1 => 4+prependWork w

theorem prependWork_eq (w : ℕ) : prependWork w = 4*w+1 := by
  induction w <;> simp [prependWork, *] <;> omega

theorem prepend_length (w : ℕ) (xs tail : List Bool) :
    (prepend w xs tail).length=w+tail.length := by
  induction w generalizing xs <;> simp [prepend, *] <;> omega

theorem prepend_value (w : ℕ) (xs tail : List Bool) (hx : xs.length≤w) :
    binaryDigitsValue (prepend w xs tail)=binaryDigitsValue xs+2^w*binaryDigitsValue tail := by
  induction w generalizing xs with
  | zero =>
      have he : xs=[] := List.length_eq_zero.mp (by omega)
      simp [prepend,he,binaryDigitsValue]
  | succ w ih =>
      have ht : xs.tail.length≤w := by rw [List.length_tail]; omega
      have hv := CarryNormalization.head_tail_value xs
      simp only [prepend,binaryDigitsValue,ih xs.tail ht,pow_succ]
      nlinarith

def pack (w : ℕ) : List (List Bool) → List Bool
  | [] => []
  | x::xs => prepend w x (pack w xs)

def packWork (w : ℕ) : List (List Bool) → ℕ
  | [] => 1
  | _::xs => 3+prependWork w+packWork w xs

theorem packWork_eq (w : ℕ) (xs : List (List Bool)) :
    packWork w xs=1+xs.length*(4*w+4) := by
  induction xs <;> simp [packWork,prependWork_eq, *] <;> ring

theorem pack_length (w : ℕ) (xs : List (List Bool)) :
    (pack w xs).length=w*xs.length := by
  induction xs <;> simp [pack,prepend_length, *,Nat.mul_add,Nat.add_comm]

def coefficientValue (base : ℕ) : List (List Bool) → ℕ
  | [] => 0
  | x::xs => binaryDigitsValue x+base*coefficientValue base xs

theorem pack_value (w : ℕ) (xs : List (List Bool))
    (hx : ∀x∈xs,x.length≤w) :
    binaryDigitsValue (pack w xs)=coefficientValue (2^w) xs := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
      rw [pack,prepend_value w x _ (hx x List.mem_cons_self),coefficientValue]
      rw [ih (fun y hy => hx y (List.mem_cons_of_mem _ hy))]

/-- Read one block and retain the untouched suffix, padding a short block. -/
def split : ℕ → List Bool → List Bool × List Bool
  | 0, xs => ([],xs)
  | w+1, xs =>
      let next := split w xs.tail
      (xs.headD false::next.1,next.2)

def splitWork : ℕ → ℕ
  | 0 => 2
  | w+1 => 7+splitWork w

theorem splitWork_eq (w : ℕ) : splitWork w=7*w+2 := by
  induction w <;> simp [splitWork, *] <;> omega

theorem split_length (w : ℕ) (xs : List Bool) : (split w xs).1.length=w := by
  induction w generalizing xs <;> simp [split, *]

theorem split_tail (w : ℕ) (xs : List Bool) : (split w xs).2=xs.drop w := by
  induction w generalizing xs with
  | zero => simp [split]
  | succ w ih =>
      simp only [split,ih]
      cases xs <;> simp

theorem split_value (w : ℕ) (xs : List Bool) :
    binaryDigitsValue (split w xs).1+2^w*binaryDigitsValue (split w xs).2=
      binaryDigitsValue xs := by
  induction w generalizing xs with
  | zero => simp [split,binaryDigitsValue]
  | succ w ih =>
      have h := ih xs.tail
      have hv := CarryNormalization.head_tail_value xs
      simp only [split,binaryDigitsValue,pow_succ]
      nlinarith

theorem split_mod_div (w : ℕ) (xs : List Bool) :
    binaryDigitsValue (split w xs).1=binaryDigitsValue xs%2^w ∧
    binaryDigitsValue (split w xs).2=binaryDigitsValue xs/2^w := by
  have h := split_value w xs
  have hlt : binaryDigitsValue (split w xs).1<2^w := by
    have hh := binaryDigitsValue_lt_pow (split w xs).1
    simpa only [split_length] using hh
  constructor
  · rw [←h,Nat.add_mul_mod_self_left,Nat.mod_eq_of_lt hlt]
  · rw [←h,Nat.add_mul_div_left _ _ (pow_pos (by decide) _),Nat.div_eq_of_lt hlt]
    omega

def unpack (w : ℕ) : ℕ → List Bool → List (List Bool)
  | 0, _ => []
  | k+1, xs =>
      let next := split w xs
      next.1::unpack w k next.2

def unpackWork (w : ℕ) : ℕ → ℕ
  | 0 => 1
  | k+1 => 4+splitWork w+unpackWork w k

theorem unpackWork_eq (w k : ℕ) : unpackWork w k=1+k*(7*w+6) := by
  induction k <;> simp [unpackWork,splitWork_eq, *] <;> ring

theorem unpack_values (w k : ℕ) (xs : List Bool) :
    (unpack w k xs).map binaryDigitsValue=unpackDigits (2^w) k (binaryDigitsValue xs) := by
  induction k generalizing xs with
  | zero => rfl
  | succ k ih =>
      simp only [unpack,List.map_cons,unpackDigits,ih,(split_mod_div w xs).1,
        (split_mod_div w xs).2]

theorem unpack_getD (w k : ℕ) (xs : List Bool) (i : ℕ) (hi : i<k) :
    ((unpack w k xs).map binaryDigitsValue).getD i 0 =
      binaryDigitsValue xs / (2^w)^i % 2^w := by
  rw [unpack_values,unpackDigits_getD _ _ _ _ hi]

end ConvolutionDraft.FixedWidthBlocks
