import ConvolutionDraft.CarryNormalization
import Optss.ListIntegerConvolution

/-!
The actual cached integer-count FFT followed by Boolean carry propagation.
This returns the base-two weighted value of the CYCLIC count table. Ordinary
large-integer multiplication additionally requires a zero-padding/no-alias
lemma. No such unstated premise is hidden in this endpoint.
-/
namespace ConvolutionDraft.NormalizedBooleanConvolution
open Optss

def weighted : List ℕ → ℕ
  | [] => 0
  | x::xs => x+2*weighted xs

theorem weighted_map (xs : List (List Bool)) :
    CarryNormalization.weightedValue xs = weighted (xs.map binaryDigitsValue) := by
  induction xs with
  | nil => rfl
  | cons x xs ih => simp [weighted,CarryNormalization.weightedValue,ih]

def run (depth f g : List Bool) : List Bool :=
  CarryNormalization.run ((listIntegerConvolution depth f g).map BitListInteger.digits) []

def work (depth f g : List Bool) : ℕ :=
  let counts := listIntegerConvolution depth f g
  listIntegerConvolutionWork depth f g+2*counts.length+1+
    CarryNormalization.work (counts.map BitListInteger.digits) []

theorem counts_values (depth : List Bool) (f g : Vector Bool (2^depth.length)) :
    (listIntegerConvolution depth (List.ofFn f.get) (List.ofFn g.get)).map
      (fun z => binaryDigitsValue z.digits) =
      List.ofFn (fun k : Fin (2^depth.length) =>
        cyclicNatConvolution (cyclicBooleanNat depth.length f)
          (cyclicBooleanNat depth.length g) (k.val : ZMod (2^depth.length))) := by
  have h := congrArg (List.map Int.natAbs) (listIntegerConvolution_eq depth f g)
  simpa only [List.map_map,Function.comp_def,BitListInteger.value,signedBitsValue_natAbs,
    List.map_ofFn,Int.natAbs_natCast] using h

theorem run_value (depth : List Bool) (f g : Vector Bool (2^depth.length)) :
    binaryDigitsValue (run depth (List.ofFn f.get) (List.ofFn g.get)) =
      weighted (List.ofFn (fun k : Fin (2^depth.length) =>
        cyclicNatConvolution (cyclicBooleanNat depth.length f)
          (cyclicBooleanNat depth.length g) (k.val : ZMod (2^depth.length)))) := by
  rw [run,CarryNormalization.run_value,binaryDigitsValue,Nat.add_zero,weighted_map]
  simp only [List.map_map,Function.comp_def,counts_values]

theorem work_bound (depth f g : List Bool)
    (hf : f.length=2^depth.length) (hg : g.length=2^depth.length) :
    work depth f g ≤ 2^depth.length*
      (listBooleanConvolutionWorkFactor depth.length+7*(depth.length+1)+9)+2 := by
  obtain ⟨F,rfl⟩ := fourier_exists_vector f _ hf
  obtain ⟨G,rfl⟩ := fourier_exists_vector g _ hg
  have hlen := listIntegerConvolution_length depth (List.ofFn F.get) (List.ofFn G.get)
    (by simp) (by simp)
  have hw := listIntegerConvolutionWork_bound depth (List.ofFn F.get) (List.ofFn G.get)
    (by simp) (by simp)
  have hcarry := CarryNormalization.work_bound
    ((listIntegerConvolution depth (List.ofFn F.get) (List.ofFn G.get)).map BitListInteger.digits)
    [] (depth.length+1) (by
      intro z hz
      obtain ⟨c,hc,rfl⟩ := List.mem_map.mp hz
      exact listIntegerConvolution_output_width depth F G c hc) (by simp)
  simp only [List.length_map,hlen] at hcarry
  dsimp only [work]
  rw [hlen]
  nlinarith

end ConvolutionDraft.NormalizedBooleanConvolution
