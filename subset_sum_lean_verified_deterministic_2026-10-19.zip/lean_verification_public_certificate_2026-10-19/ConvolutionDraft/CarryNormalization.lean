import Optss.BitListMultiplication

/-!
Linear-in-count ripple normalization of a stored convolution coefficient list.
All answer arithmetic uses Boolean full adders. The tail of each sum is the
next carry, so bounded coefficient widths remain bounded without long division.
Counters count existing full-adder gates, aligned-bit/list visits, and six
outer read/branch/cons operations. They are specifications, not answer oracles.
-/
namespace ConvolutionDraft.CarryNormalization
open Optss

def weightedValue : List (List Bool) → ℕ
  | [] => 0
  | x::xs => binaryDigitsValue x+2*weightedValue xs

def run : List (List Bool) → List Bool → List Bool
  | [], carry => carry
  | x::xs, carry =>
      let sum := bitListAddAux false x carry
      sum.headD false :: run xs sum.tail

def work : List (List Bool) → List Bool → ℕ
  | [], _ => 1
  | x::xs, carry =>
      let sum := bitListAddAux false x carry
      bitListRippleGates 6 x carry + bitListAddVisits x carry + 6 + work xs sum.tail

theorem head_tail_value (xs : List Bool) :
    (xs.headD false).toNat+2*binaryDigitsValue xs.tail = binaryDigitsValue xs := by
  cases xs <;> simp [binaryDigitsValue, Nat.add_comm]

theorem run_value (xs : List (List Bool)) (carry : List Bool) :
    binaryDigitsValue (run xs carry)=weightedValue xs+binaryDigitsValue carry := by
  induction xs generalizing carry with
  | nil => simp [run,weightedValue]
  | cons x xs ih =>
      have hh := head_tail_value (bitListAddAux false x carry)
      rw [bitListAddAux_correct] at hh
      simp only [Bool.toNat_false,Nat.add_zero] at hh
      simp only [run,binaryDigitsValue,weightedValue,ih]
      omega

theorem carry_width (x carry : List Bool) (B : ℕ)
    (hx : x.length≤B) (hc : carry.length≤B) :
    (bitListAddAux false x carry).tail.length≤B := by
  have h := bitListAddAux_length x carry false
  rw [List.length_tail]
  omega

theorem run_length (xs : List (List Bool)) (carry : List Bool) (B : ℕ)
    (hx : ∀x∈xs,x.length≤B) (hc : carry.length≤B) :
    (run xs carry).length≤xs.length+B := by
  induction xs generalizing carry with
  | nil => simpa [run] using hc
  | cons x xs ih =>
      have hw := carry_width x carry B (hx x List.mem_cons_self) hc
      have h := ih _ (fun y hy => hx y (List.mem_cons_of_mem _ hy)) hw
      simp only [run,List.length_cons]
      omega

theorem work_bound (xs : List (List Bool)) (carry : List Bool) (B : ℕ)
    (hx : ∀x∈xs,x.length≤B) (hc : carry.length≤B) :
    work xs carry ≤ 1+xs.length*(7*B+7) := by
  induction xs generalizing carry with
  | nil => simp [work]
  | cons x xs ih =>
      have hxb := hx x List.mem_cons_self
      have hw := carry_width x carry B hxb hc
      have h := ih _ (fun y hy => hx y (List.mem_cons_of_mem _ hy)) hw
      have hm : max x.length carry.length≤B := max_le hxb hc
      simp only [work,bitListRippleGates_eq,bitListAddVisits_eq,List.length_cons]
      nlinarith

end ConvolutionDraft.CarryNormalization
