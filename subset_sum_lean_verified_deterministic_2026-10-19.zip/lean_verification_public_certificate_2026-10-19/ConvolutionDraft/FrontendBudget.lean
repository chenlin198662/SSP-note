import ConvolutionDraft.StoredFrontend

namespace ConvolutionDraft.FrontendBudget
open Optss Polynomial SubsetSum.ExternalCostContracts StoredFrontend

noncomputable def metadataPolynomial : Polynomial ℕ :=
  16*(2*X+11)^3+(32*X+130)*(4*X+18)^2+16*(12*X+51)^2+8*X+40

theorem metadata_eval (z : ℕ) : metadataPolynomial.eval z=Metadata.budget (2*z+8) := by
  simp [metadataPolynomial,Metadata.budget]
  ring

theorem budget_mono {a b : ℕ} (h : a ≤ b) : Metadata.budget a ≤ Metadata.budget b := by
  unfold Metadata.budget
  gcongr

noncomputable def polynomial : Polynomial ℕ :=
  (SignedBudget.preparedPolynomial+metadataPolynomial+6*X+100)*(3*X+18)^2

theorem work_polynomial (xs ys : List BitListInteger) (hL : 0<xs.length+ys.length) :
    work xs ys ≤ 
      let S := (xs.length+ys.length)*(measuredBits xs ys+(xs.length+ys.length).size+1)
      S*polynomial.eval (S+1).size := by
  let L := xs.length+ys.length
  let B := measuredBits xs ys
  let S := L*(B+L.size+1)
  let z := (S+1).size
  let w := NaturalBlockConvolution.width B L
  let n := (SignedBudget.depth B L).length
  have hLp : 0<L := hL
  have hSp : 0<S := by dsimp [S]; positivity
  have hSL : L ≤ S := by dsimp [S]; nlinarith
  have hSB : B ≤ S := by dsimp [S]; nlinarith
  have hLz : L.size ≤ z := Nat.size_le_size (by omega)
  have hBz : B.size ≤ z := Nat.size_le_size (by omega)
  have hw : w ≤ 2*(B+L.size+1) := by dsimp [w,NaturalBlockConvolution.width]; omega
  have hnEq : n=(w*L).size := by simp [n,w,SignedBudget.depth]
  have hn : n ≤ z+2 := by
    have hwl : w*L ≤ 2*S := by dsimp [S]; nlinarith
    have hsize := Nat.size_le_size hwl
    have hm := nat_mul_size_le 2 S
    have htwo : (2:ℕ).size=2 := by simpa using (Nat.size_pow (n:=1))
    rw [htwo] at hm
    have hs : S.size ≤ z := Nat.size_le_size (by omega)
    omega
  have hc : controlBits B L ≤ 3*z+18 := by dsimp only [controlBits]; change n+L.size+B.size+16 ≤ _; omega
  have hm1 := InputMeasure.run_work xs B L (measured_covers_left xs ys) (by dsimp [L]; omega)
  have hm2 := InputMeasure.run_work ys B L (measured_covers_right xs ys) (by dsimp [L]; omega)
  have hmeas : (InputMeasure.run xs).work+(InputMeasure.run ys).work ≤ 2+S*(6*z+17) := by
    have hfactor : 2*L.size+4*B.size+17 ≤ 6*z+17 := by omega
    have hsum : xs.length*(B+1)+ys.length*(B+1) ≤ S := by dsimp [S,L]; nlinarith
    nlinarith
  have hmeta := Metadata.run_work B L
  have hmeta' : (Metadata.run B L).work ≤ S*metadataPolynomial.eval z := by
    have hg : L.size+B.size+8 ≤ 2*z+8 := by omega
    have hh := hmeta.trans (budget_mono hg)
    rw [←metadata_eval] at hh
    exact hh.trans (Nat.le_mul_of_pos_left _ hSp)
  have hcore := SignedBudget.work_polynomial B L hLp xs ys (by rfl)
  have hcopy1 := copyWork_bound xs B (measured_covers_left xs ys)
  have hcopy2 := copyWork_bound ys B (measured_covers_right xs ys)
  have hcopies : copyWork xs+copyWork ys ≤ 2+8*S := by
    dsimp only [S,L]
    nlinarith only [hcopy1,hcopy2,Nat.zero_le B,Nat.zero_le (xs.length+ys.length).size]
  have hout := copyWork_bound (core xs ys) (w+3) (core_width xs ys)
  have hlen : (core xs ys).length=L := by rw [←run_eq,run_length]
  rw [hlen] at hout
  have hout' : copyWork (core xs ys) ≤ 1+28*S := by
    dsimp only [S]
    nlinarith only [hout,hw,Nat.zero_le B,Nat.zero_le L.size]
  have htotal : (InputMeasure.run xs).work+(InputMeasure.run ys).work+
      (Metadata.run B L).work+
      SignedBlockConvolution.work (SignedBudget.depth B L) w L xs ys+
      copyWork xs+copyWork ys+copyWork (core xs ys)+16 ≤ 
      S*(SignedBudget.preparedPolynomial.eval z+metadataPolynomial.eval z+6*z+100) := by
    change SignedBlockConvolution.work (SignedBudget.depth B L) w L xs ys ≤ 
      S*SignedBudget.preparedPolynomial.eval z at hcore
    nlinarith only [hmeas,hmeta',hcore,hcopies,hout',hSp]
  have hfinal := Nat.mul_le_mul htotal (Nat.pow_le_pow_left hc 2)
  dsimp only [work]
  rw [Metadata.run_depth,Metadata.run_width]
  change _ ≤ S*polynomial.eval z
  simpa only [polynomial,Polynomial.eval_mul,Polynomial.eval_add,Polynomial.eval_pow,
    Polynomial.eval_ofNat,Polynomial.eval_X,mul_assoc] using hfinal

theorem work_fftBudget (xs ys : List BitListInteger) (B : ℕ)
    (hx : ∀z∈xs,z.digits.length ≤ B) (hy : ∀z∈ys,z.digits.length ≤ B)
    (hL : 0<xs.length+ys.length) :
    work xs ys ≤ fftBudget (polynomial.eval 1) polynomial.natDegree (xs.length+ys.length) B := by
  have h := work_polynomial xs ys hL
  let S := (xs.length+ys.length)*(measuredBits xs ys+(xs.length+ys.length).size+1)
  have hp := SignedBudget.polynomial_monomial polynomial (S+1).size
    (Nat.size_pos.mpr (by omega))
  have hbudget : work xs ys ≤ fftBudget (polynomial.eval 1) polynomial.natDegree
      (xs.length+ys.length) (measuredBits xs ys) := by
    change work xs ys ≤ S*polynomial.eval (S+1).size at h
    have hh := h.trans (Nat.mul_le_mul_left S hp)
    change work xs ys ≤ polynomial.eval 1*S*(S+1).size^polynomial.natDegree
    exact hh.trans_eq (by ac_rfl)
  exact hbudget.trans (fftBudget_mono _ _ (le_refl _) (measured_le xs ys B hx hy))

end ConvolutionDraft.FrontendBudget
