import ConvolutionDraft.FrontendBudget

namespace ConvolutionDraft.CanonicalOutput
open Optss Polynomial SubsetSum.ExternalCostContracts

/-- Magnitudes produced by the signed Boolean adder are already trimmed.
Only the zero sign must be reset before exposing canonical stored output. -/
def normalize (z : BitListInteger) : BitListInteger :=
  match z.digits with
  | [] => ⟨false,[]⟩
  | _::_ => z

theorem normalize_value (z : BitListInteger) : (normalize z).value=z.value := by
  cases z with
  | mk sign digits => cases digits <;> cases sign <;> simp [normalize,BitListInteger.value,signedBitsValue,binaryDigitsValue]

theorem normalize_representation (z : BitListInteger) (hz : BitListCanonical z.digits) :
    normalize z=integerBitRepresentation z.value := by
  cases z with
  | mk sign digits =>
    cases digits with
    | nil => cases sign <;> simp [normalize,integerBitRepresentation,BitListInteger.value,signedBitsValue,binaryDigitsValue]
    | cons b bs =>
      have hd : b::bs=(binaryDigitsValue (b::bs)).bits := hz
      have hv : 0<binaryDigitsValue (b::bs) := by
        by_contra h
        have he : binaryDigitsValue (b::bs)=0 := by omega
        rw [he] at hd
        simp at hd
      cases sign <;>
        simp [normalize,integerBitRepresentation,BitListInteger.value,signedBitsValue,
          Int.neg_neg_of_pos (show (0:ℤ)<binaryDigitsValue (b::bs) by exact_mod_cast hv),←hd,hv]

theorem merge_canonical (as bs cs ds : List (List Bool)) :
    ∀z∈SignedBlocks.merge as bs cs ds,BitListCanonical z.digits := by
  induction as generalizing bs cs ds with
  | nil => simp [SignedBlocks.merge]
  | cons a as ih =>
      cases bs with
      | nil => simp [SignedBlocks.merge]
      | cons b bs =>
        cases cs with
        | nil => simp [SignedBlocks.merge]
        | cons c cs =>
          cases ds with
          | nil => simp [SignedBlocks.merge]
          | cons d ds =>
            intro z hz
            rcases List.mem_cons.mp hz with rfl | hz
            · exact bitListIntegerAdd_canonical _ _
            · exact ih bs cs ds z hz

theorem frontend_canonical (xs ys : List BitListInteger) :
    ∀z∈StoredFrontend.run xs ys,BitListCanonical z.digits := by
  rw [StoredFrontend.run_eq,StoredFrontend.core_eq]
  exact merge_canonical _ _ _ _

def run (xs ys : List BitListInteger) : List BitListInteger :=
  (StoredFrontend.run xs ys).map normalize

def work (xs ys : List BitListInteger) : ℕ :=
  StoredFrontend.work xs ys+8*(xs.length+ys.length)+8

theorem run_length (xs ys : List BitListInteger) : (run xs ys).length=xs.length+ys.length := by
  simp [run,StoredFrontend.run_length]

theorem run_values (xs ys : List BitListInteger) :
    (run xs ys).map BitListInteger.value=(StoredFrontend.run xs ys).map BitListInteger.value := by
  simp [run,List.map_map,Function.comp_def,normalize_value]

theorem run_canonical (xs ys : List BitListInteger) :
    ∀z∈run xs ys,integerBitRepresentation z.value=z := by
  intro z hz
  obtain ⟨v,hv,rfl⟩ := List.mem_map.mp hz
  rw [normalize_value]
  exact (normalize_representation v (frontend_canonical xs ys v hv)).symm

noncomputable def polynomial : Polynomial ℕ := FrontendBudget.polynomial+16

theorem work_fftBudget (xs ys : List BitListInteger) (B : ℕ)
    (hx : ∀z∈xs,z.digits.length ≤ B) (hy : ∀z∈ys,z.digits.length ≤ B)
    (hL : 0<xs.length+ys.length) :
    work xs ys ≤ fftBudget (polynomial.eval 1) polynomial.natDegree (xs.length+ys.length) B := by
  let L := xs.length+ys.length
  let b := StoredFrontend.measuredBits xs ys
  let S := L*(b+L.size+1)
  let z := (S+1).size
  have hSp : 0<S := by dsimp [S,L]; positivity
  have hLS : L ≤ S := by dsimp [S]; nlinarith only [Nat.zero_le b,Nat.zero_le L.size]
  have h := FrontendBudget.work_polynomial xs ys hL
  change StoredFrontend.work xs ys ≤ S*FrontendBudget.polynomial.eval z at h
  have hw : work xs ys ≤ S*polynomial.eval z := by
    simp only [work,polynomial,Polynomial.eval_add,Polynomial.eval_ofNat]
    change StoredFrontend.work xs ys+8*L+8 ≤ _
    nlinarith only [h,hLS,hSp]
  have hp := SignedBudget.polynomial_monomial polynomial z (Nat.size_pos.mpr (by omega))
  have hb : work xs ys ≤ fftBudget (polynomial.eval 1) polynomial.natDegree L b := by
    change work xs ys ≤ polynomial.eval 1*S*z^polynomial.natDegree
    exact (hw.trans (Nat.mul_le_mul_left S hp)).trans_eq (by ac_rfl)
  exact hb.trans (fftBudget_mono _ _ (le_refl _) (StoredFrontend.measured_le xs ys B hx hy))

end ConvolutionDraft.CanonicalOutput
