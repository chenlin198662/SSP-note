import ConvolutionDraft.FixedWidthBlocks
import Optss.ExecutableSignedConvolution
import Optss.BitListIntegerOperations

namespace ConvolutionDraft.SignedBlocks
open Optss

def part (negative : Bool) (xs : List BitListInteger) : List (List Bool) :=
  xs.map (fun z => if z.negative=negative then z.digits else [])

theorem part_length (negative : Bool) (xs : List BitListInteger) :
    (part negative xs).length=xs.length := by simp [part]

theorem part_width (negative : Bool) (xs : List BitListInteger) (B : ℕ)
    (hx : ∀z∈xs,z.digits.length≤B) : ∀w∈part negative xs,w.length≤B := by
  intro w hw
  obtain ⟨z,hz,rfl⟩ := List.mem_map.mp hw
  split_ifs
  · exact hx z hz
  · simp

theorem positive_values (xs : List BitListInteger) :
    (part false xs).map binaryDigitsValue=
      ExecutablePackedConvolution.positive (xs.map BitListInteger.value) := by
  simp only [part,List.map_map,ExecutablePackedConvolution.positive,Function.comp_def]
  apply List.map_congr_left
  intro z _
  cases hz : z.negative <;> simp [hz,BitListInteger.value,signedBitsValue,binaryDigitsValue]

theorem negative_values (xs : List BitListInteger) :
    (part true xs).map binaryDigitsValue=
      ExecutablePackedConvolution.negative (xs.map BitListInteger.value) := by
  simp only [part,List.map_map,ExecutablePackedConvolution.negative,Function.comp_def]
  apply List.map_congr_left
  intro z _
  cases hz : z.negative <;> simp [hz,BitListInteger.value,signedBitsValue,binaryDigitsValue]

def mergeRow (pp pn np nn : List Bool) : BitListInteger :=
  bitListIntegerAdd
    (bitListIntegerSub (bitListIntegerSub ⟨false,pp⟩ ⟨false,pn⟩) ⟨false,np⟩) ⟨false,nn⟩

def mergeRowWork (pp pn np nn : List Bool) : ℕ :=
  let first := bitListIntegerSub ⟨false,pp⟩ ⟨false,pn⟩
  let second := bitListIntegerSub first ⟨false,np⟩
  bitListIntegerSubCost ⟨false,pp⟩ ⟨false,pn⟩+
    bitListIntegerSubCost first ⟨false,np⟩+bitListIntegerAddCost second ⟨false,nn⟩+8

theorem mergeRow_value (pp pn np nn : List Bool) :
    (mergeRow pp pn np nn).value=(binaryDigitsValue pp : ℤ)-binaryDigitsValue pn-
      binaryDigitsValue np+binaryDigitsValue nn := by
  rw [mergeRow,bitListIntegerAdd_value,bitListIntegerSub_value,bitListIntegerSub_value]
  rfl

theorem mergeRow_width (pp pn np nn : List Bool) (w : ℕ)
    (h1 : pp.length≤w) (h2 : pn.length≤w) (h3 : np.length≤w) (h4 : nn.length≤w) :
    (mergeRow pp pn np nn).digits.length≤w+3 := by
  have ha := bitListIntegerSub_length ⟨false,pp⟩ ⟨false,pn⟩
  have hb := bitListIntegerSub_length (bitListIntegerSub ⟨false,pp⟩ ⟨false,pn⟩) ⟨false,np⟩
  have hc := bitListIntegerAdd_length
    (bitListIntegerSub (bitListIntegerSub ⟨false,pp⟩ ⟨false,pn⟩) ⟨false,np⟩) ⟨false,nn⟩
  change _≤_ at ha hb hc
  unfold mergeRow
  simp only at ha hb hc
  omega

theorem mergeRowWork_bound (pp pn np nn : List Bool) (w : ℕ)
    (h1 : pp.length≤w) (h2 : pn.length≤w) (h3 : np.length≤w) (h4 : nn.length≤w) :
    mergeRowWork pp pn np nn≤92*(w+3)+8 := by
  have ha := bitListIntegerSub_length ⟨false,pp⟩ ⟨false,pn⟩
  have hb := bitListIntegerSub_length (bitListIntegerSub ⟨false,pp⟩ ⟨false,pn⟩) ⟨false,np⟩
  simp only at ha hb
  have hc1 := bitListIntegerSubCost_bound ⟨false,pp⟩ ⟨false,pn⟩ w h1 h2
  have hc2 := bitListIntegerSubCost_bound (bitListIntegerSub ⟨false,pp⟩ ⟨false,pn⟩)
    ⟨false,np⟩ (w+1) (by omega) (by simpa using h3.trans (Nat.le_succ w))
  have hc3 := bitListIntegerAddCost_bound
    (bitListIntegerSub (bitListIntegerSub ⟨false,pp⟩ ⟨false,pn⟩) ⟨false,np⟩)
    ⟨false,nn⟩ (w+2) (by omega) (by simpa using h4.trans (by omega : w≤w+2))
  dsimp only [mergeRowWork]
  omega

def merge : List (List Bool) → List (List Bool) → List (List Bool) → List (List Bool) → List BitListInteger
  | a::as,b::bs,c::cs,d::ds => mergeRow a b c d :: merge as bs cs ds
  | _,_,_,_ => []

def mergeWork : List (List Bool) → List (List Bool) → List (List Bool) → List (List Bool) → ℕ
  | a::as,b::bs,c::cs,d::ds => mergeRowWork a b c d +12+mergeWork as bs cs ds
  | _,_,_,_ => 4

theorem merge_length (as bs cs ds : List (List Bool)) (h1 : bs.length=as.length)
    (h2 : cs.length=as.length) (h3 : ds.length=as.length) :
    (merge as bs cs ds).length=as.length := by
  induction as generalizing bs cs ds with
  | nil => simp [merge]
  | cons a as ih =>
      cases bs <;> cases cs <;> cases ds <;> simp_all [merge]

theorem merge_getD (as bs cs ds : List (List Bool)) (h1 : bs.length=as.length)
    (h2 : cs.length=as.length) (h3 : ds.length=as.length) (i : ℕ) (hi : i<as.length) :
    ((merge as bs cs ds).map BitListInteger.value).getD i 0 =
      (((as.map binaryDigitsValue).getD i 0 : ℕ) : ℤ)-
      (bs.map binaryDigitsValue).getD i 0-(cs.map binaryDigitsValue).getD i 0+
      (ds.map binaryDigitsValue).getD i 0 := by
  induction as generalizing bs cs ds i with
  | nil => simp at hi
  | cons a as ih =>
      cases bs with
      | nil => simp at h1
      | cons b bs =>
        cases cs with
        | nil => simp at h2
        | cons c cs =>
          cases ds with
          | nil => simp at h3
          | cons d ds =>
            cases i with
            | zero => simp [merge,mergeRow_value]
            | succ i =>
                simp only [merge,List.map_cons,List.getD_cons_succ]
                exact ih bs cs ds (by simpa using h1) (by simpa using h2)
                  (by simpa using h3) i (by simpa using hi)

theorem mergeWork_bound (as bs cs ds : List (List Bool)) (w : ℕ)
    (ha : ∀z∈as,z.length≤w) (hb : ∀z∈bs,z.length≤w)
    (hc : ∀z∈cs,z.length≤w) (hd : ∀z∈ds,z.length≤w) :
    mergeWork as bs cs ds≤4+as.length*(92*(w+3)+20) := by
  induction as generalizing bs cs ds with
  | nil => simp [mergeWork]
  | cons a as ih =>
      cases bs with
      | nil => simp [mergeWork]
      | cons b bs =>
        cases cs with
        | nil => simp [mergeWork]
        | cons c cs =>
          cases ds with
          | nil => simp [mergeWork]
          | cons d ds =>
            have hrow := mergeRowWork_bound a b c d w (ha _ List.mem_cons_self)
              (hb _ List.mem_cons_self) (hc _ List.mem_cons_self) (hd _ List.mem_cons_self)
            have ht := ih bs cs ds (fun z hz => ha z (List.mem_cons_of_mem _ hz))
              (fun z hz => hb z (List.mem_cons_of_mem _ hz))
              (fun z hz => hc z (List.mem_cons_of_mem _ hz))
              (fun z hz => hd z (List.mem_cons_of_mem _ hz))
            simp only [mergeWork,List.length_cons]
            nlinarith

end ConvolutionDraft.SignedBlocks
